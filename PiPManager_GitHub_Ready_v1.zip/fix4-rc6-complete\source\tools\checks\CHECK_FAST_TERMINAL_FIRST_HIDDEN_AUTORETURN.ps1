$ErrorActionPreference = "Stop"
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$main = Get-Content -Raw (Join-Path $root "src\PiPManager.Wpf\MainWindow.xaml.cs")
$model = Get-Content -Raw (Join-Path $root "src\PiPManager.Wpf\Models\VideoTabInfo.cs")
$content = Get-Content -Raw (Join-Path $root "src\PiPManager.Extension\content.js")
$bridge = Get-Content -Raw (Join-Path $root "src\PiPManager.Wpf\Services\ExtensionBridgeService.cs")

$checks = [ordered]@{
  "fast loss poll" = $main.Contains("AutoAdvanceLostPipPollMs = 350")
  "direct terminal two samples" = $main.Contains("AutoAdvanceLostPipDirectTerminalMinimumAttempt = 2")
  "missing session three samples" = $main.Contains("AutoAdvanceLostPipMissingMinimumAttempt = 3")
  "stable churn does not cancel same session" = $main.Contains("strongStableChange = stableChanged && string.IsNullOrWhiteSpace(session)")
  "terminal preempts old autoreturn" = $main.Contains("auto-advance-terminal-preempted-old-autoreturn")
  "terminal fast autoreturn state" = $main.Contains("terminal-auto-next-real-change")
  "snapshot event fast tick" = $main.Contains("QueueFastAutoReturnTickFromSnapshot")
  "new video stabilization is 250 ms" = $main.Contains("AutoReturnTerminalAdvanceStabilizeMs = 250")
  "terminal focus lease is 300 ms" =     $main.Contains('string.Equals(state.EligibilityMode, "terminal-auto-next-real-change", StringComparison.OrdinalIgnoreCase)') -and     $main.Contains("? 300") -and     $main.Contains(": navigationFastLease")
  "browser minimization retained" = $main.Contains("auto-return-browser-minimized-after-confirmation")
  "video snapshot terminal fields model" = $model.Contains("public int ReadyState") -and $model.Contains("public bool HasSource")
  "content exports terminal fields" = $content.Contains("readyState: Number(video.readyState") -and $content.Contains("hasSource: !!getVideoSource(video)")
  "bridge imports terminal fields" = $bridge.Contains('ReadyState = GetInt(item, "readyState")') -and $bridge.Contains('HasSource = GetBool(item, "hasSource")')
}

$failed = @()
foreach ($item in $checks.GetEnumerator()) {
  if ($item.Value) { Write-Host ($item.Key + ": OK") }
  else { Write-Host ($item.Key + ": FAIL"); $failed += $item.Key }
}
if ($failed.Count -gt 0) { throw "Fast terminal-first checks failed: $($failed -join ', ')" }
Write-Host "Fast terminal-first hidden AutoReturn checks OK."
