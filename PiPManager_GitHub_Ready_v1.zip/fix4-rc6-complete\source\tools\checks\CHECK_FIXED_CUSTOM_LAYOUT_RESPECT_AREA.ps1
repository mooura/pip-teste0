$ErrorActionPreference = "Stop"
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$settings = Get-Content -Raw (Join-Path $root "src\PiPManager.Wpf\Models\AppSettings.cs")
$xaml = Get-Content -Raw (Join-Path $root "src\PiPManager.Wpf\MainWindow.xaml")
$fixed = Get-Content -Raw (Join-Path $root "src\PiPManager.Wpf\MainWindow.FixedLayout.cs")
$main = Get-Content -Raw (Join-Path $root "src\PiPManager.Wpf\MainWindow.xaml.cs")
$slotState = Get-Content -Raw (Join-Path $root "src\PiPManager.Wpf\MainWindow.SlotState.cs")
$win32 = Get-Content -Raw (Join-Path $root "src\PiPManager.Wpf\Services\Win32.cs")

$timerStart = $fixed.IndexOf('private void FixedLayoutRespectTimerTick()')
$timerEnd = $fixed.IndexOf('private void EnforceFixedPipGeometryTick()', $timerStart)
$timerBody = if ($timerStart -ge 0 -and $timerEnd -gt $timerStart) {
  $fixed.Substring($timerStart, $timerEnd - $timerStart)
} else { '' }

$checks = [ordered]@{
  "settings retain fixed-layout compatibility fields" = $settings.Contains('FixedCustomLayoutEnabled') -and $settings.Contains('RespectFixedLayoutAreaEnabled') -and $settings.Contains('FixedSlotLayout')
  "layout menu exposes one fixed option" = $xaml.Contains('FixedCustomLayoutMenuItem') -and $xaml.Contains('Header="Fixar layout"') -and -not $xaml.Contains('RespectFixedLayoutAreaMenuItem') -and -not $xaml.Contains('RecordFixedLayoutMenuItem')
  "single toggle enables PiP geometry only" = $fixed.Contains('_fixedCustomLayoutEnabled = true;') -and $fixed.Contains('_respectFixedLayoutAreaEnabled = false;') -and $fixed.Contains('FixedLayoutRespectTimerTick();')
  "legacy normal-window state is restored on disable" = $fixed.Contains('RestoreManagedWindows("fixed-layout-disabled")') -and -not $fixed.Contains('RespectFixedLayoutAreaMenuItem_Click')
  "custom slot geometry becomes authority" = $fixed.Contains('RecordFixedLayoutAuthority') -and $fixed.Contains('_fixedSlotLayoutRects') -and $fixed.Contains('BuildUniformFixedLayoutTargets')
  "all ten slots share uniform size source" = $fixed.Contains('uniformWidth') -and $fixed.Contains('uniformHeight') -and $fixed.Contains('requestedWidth') -and $fixed.Contains('requestedHeight')
  "fixed equalize updates authority" = $main.Contains('RecordFixedLayoutAuthority(') -and $main.Contains('equalize-request-fixed-authority')
  "stored slot indexes cannot collapse" = $fixed.Contains('storedAuthority.Length == Slots.Count') -and $main.Contains('HasCompleteFixedLayoutAuthority()')
  "each slot position is periodically enforced without resizing" = $fixed.Contains('EnforceFixedPipGeometryTick') -and $fixed.Contains('QueueApplyFixedSlotGeometry') -and $fixed.Contains('MoveVisual(handle, target.Left, target.Top)') -and $fixed.Contains('sizesPreserved=True')
  "new and reconnected PiPs use fixed slot" = $slotState.Contains('QueueApplyFixedSlotGeometry(slot, "mark-slot-active")') -and $main.Contains('ResolveReconnectGeometryTarget(slot, referenceRect)')
  "every slot is clamped inside monitor" = $fixed.Contains('ClampRectInsideWorkArea') -and $fixed.Contains('area.Right - margin - width') -and $fixed.Contains('area.Bottom - margin - height')
  "arbitrary shape can still calculate diagnostic free rectangle" = $fixed.Contains('ComputeLargestFreeRectangle') -and $fixed.Contains('reserved.Any(candidate.Intersects)')
  "periodic timer only enforces PiP HWNDs" = $timerBody.Contains('EnforceFixedPipGeometryTick();') -and -not $timerBody.Contains('GetForegroundWindow') -and -not $timerBody.Contains('TryConstrainForegroundWindow') -and -not $timerBody.Contains('MoveNormalWindowVisual')
  "external applications have no fixed-layout authority" = $fixed.Contains('pipOnly=True; externalWindowsManaged=False') -and -not $fixed.Contains('TryConstrainForegroundWindow(foreground') -and ([regex]::Matches($fixed, 'TryConstrainForegroundWindow\(').Count -eq 1)
  "legacy external-window methods remain isolated" = $fixed.Contains('Slots.Any(slot => slot.Window?.Handle == hwnd)') -and $fixed.Contains('processId == Environment.ProcessId') -and $fixed.Contains('RestoreManagedWindows("app-closing")')
  "Win32 compatibility helpers remain available" = $win32.Contains('IsZoomed') -and $win32.Contains('GWL_STYLE') -and $win32.Contains('WS_EX_TOOLWINDOW')
  "settings persist fixed state with external authority disabled" = $main.Contains('_settings.RespectFixedLayoutAreaEnabled = false;') -and $main.Contains('_settings.FixedSlotLayout = HasCompleteFixedLayoutAuthority()')
}

$failed = @()
foreach ($item in $checks.GetEnumerator()) {
  if ($item.Value) { Write-Host ($item.Key + ": OK") }
  else { Write-Host ($item.Key + ": FAIL"); $failed += $item.Key }
}

if ($failed.Count -gt 0) {
  throw "Fixed custom layout PiP-only checks failed: $($failed -join ', ')"
}

Write-Host "Single fixed-layout PiP-only checks OK."
