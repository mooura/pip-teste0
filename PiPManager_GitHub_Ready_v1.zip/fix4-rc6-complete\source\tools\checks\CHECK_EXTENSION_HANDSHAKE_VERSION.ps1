$ErrorActionPreference = "Stop"
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path

$bridgePath = Join-Path $root "src\PiPManager.Wpf\Services\ExtensionBridgeService.cs"
$releasePath = Join-Path $root "src\PiPManager.Wpf\Services\ReleaseInfoService.cs"
$backgroundPath = Join-Path $root "src\PiPManager.Extension\background.js"
$contentPath = Join-Path $root "src\PiPManager.Extension\content.js"
$manifestPath = Join-Path $root "src\PiPManager.Extension\manifest.json"

$bridge = Get-Content $bridgePath -Raw
$release = Get-Content $releasePath -Raw
$background = Get-Content $backgroundPath -Raw
$content = Get-Content $contentPath -Raw
$manifest = Get-Content $manifestPath -Raw | ConvertFrom-Json

$prefixMatch = [regex]::Match($release, 'CompatibleExtensionVersionPrefix\s*=\s*"([^"]+)"')
$versionMatch = [regex]::Match($release, 'ExtensionVersion\s*=\s*"([^"]+)"')
if (!$prefixMatch.Success -or !$versionMatch.Success) {
  throw "Could not derive extension compatibility information from ReleaseInfoService.cs."
}
$expectedPrefix = $prefixMatch.Groups[1].Value
$expectedExtensionVersion = $versionMatch.Groups[1].Value
$failed = 0

function Check([string]$name, [bool]$condition) {
  if ($condition) {
    Write-Host "$name`: OK"
  } else {
    Write-Host "$name`: FAIL"
    $script:failed++
  }
}

$releasePrefixNeedle = 'CompatibleExtensionVersionPrefix = "' + $expectedPrefix + '"'
$releaseVersionNeedle = 'ExtensionVersion = "' + $expectedExtensionVersion + '"'
$backgroundPrefixNeedle = "EXPECTED_CONTENT_VERSION_PREFIX = '$expectedPrefix'"
$backgroundVersionNeedle = "BRIDGE_VERSION = '$expectedExtensionVersion-"
$contentVersionNeedle = "CONTENT_VERSION = '$expectedExtensionVersion-"
$hasOldPrefix = $release.Contains('CompatibleExtensionVersionPrefix = "1.4.35."') -or
                $background.Contains("EXPECTED_CONTENT_VERSION_PREFIX = '1.4.35.'")

Check "release extension version" ($release.Contains($releaseVersionNeedle))
Check "release compatible prefix" ($release.Contains($releasePrefixNeedle))
Check "bridge uses release prefix" ($bridge.Contains("ReleaseInfoConstants.CompatibleExtensionVersionPrefix"))
Check "bridge has compatibility helper" ($bridge.Contains("IsCompatibleExtensionVersion"))
Check "bridge has no local hardcoded prefix" (-not [regex]::IsMatch($bridge, 'CompatibleBridgeVersionPrefix\s*=>\s*"\d+\.\d+\.\d+\."'))
Check "background content prefix" ($background.Contains($backgroundPrefixNeedle))
Check "background bridge version" ($background.Contains($backgroundVersionNeedle))
Check "content script version" ($content.Contains($contentVersionNeedle))
Check "manifest extension version" ([string]$manifest.version -eq $expectedExtensionVersion)
Check "old 1.4.35 prefix absent from active handshake files" (-not $hasOldPrefix)

if ($failed -gt 0) {
  throw "Extension handshake version checks failed."
}

Write-Host "Extension handshake version checks OK."
