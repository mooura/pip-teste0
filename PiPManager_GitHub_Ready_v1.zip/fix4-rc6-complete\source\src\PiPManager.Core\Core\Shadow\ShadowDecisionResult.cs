﻿using PiPManager.Core.Automation;
using PiPManager.Core.Slots;

namespace PiPManager.Core.Shadow;

/// <summary>
/// Resultado somente leitura do Shadow Mode.
/// Actions são previsões descritivas; não devem ser executadas nesta fase.
/// </summary>
public sealed record ShadowDecisionResult(
    long Sequence,
    bool Processed,
    bool Accepted,
    bool StateChanged,
    bool Executed,
    string Reason,
    string? IgnoredReason,
    AutomationEvent Event,
    SlotSnapshot? Slot,
    SlotTransition? Transition,
    IReadOnlyList<AutomationAction> PredictedActions,
    DateTimeOffset CreatedAt)
{
    public static ShadowDecisionResult Ignored(
        long sequence,
        AutomationEvent ev,
        string reason,
        bool processed = false)
        => new(
            sequence,
            Processed: processed,
            Accepted: false,
            StateChanged: false,
            Executed: false,
            Reason: reason,
            IgnoredReason: reason,
            Event: ev,
            Slot: null,
            Transition: null,
            PredictedActions: Array.Empty<AutomationAction>(),
            CreatedAt: DateTimeOffset.UtcNow);

    public static ShadowDecisionResult FromDecision(
        long sequence,
        AutomationDecision decision,
        bool executed,
        string reason)
    {
        var applied = decision.Transition.Applied;
        var stateChanged = decision.Transition.Changed;
        var accepted = applied;

        var ignoredReason = applied
            ? null
            : decision.Transition.Reason ?? "evento processado, mas ignorado pela máquina de estados";

        var effectiveReason = applied
            ? reason
            : ignoredReason ?? "evento ignorado";

        return new(
            sequence,
            Processed: true,
            Accepted: accepted,
            StateChanged: stateChanged,
            Executed: executed,
            Reason: effectiveReason,
            IgnoredReason: ignoredReason,
            Event: decision.Event,
            Slot: decision.Slot,
            Transition: decision.Transition,
            PredictedActions: applied && stateChanged ? decision.Actions : Array.Empty<AutomationAction>(),
            CreatedAt: DateTimeOffset.UtcNow);
    }
}
