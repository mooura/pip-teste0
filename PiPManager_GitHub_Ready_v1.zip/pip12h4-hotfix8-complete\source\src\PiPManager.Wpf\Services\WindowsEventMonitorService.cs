﻿using System.Collections.Concurrent;
using System.Runtime.InteropServices;
using Microsoft.Extensions.Hosting;

namespace PiPManager.Wpf.Services;

public enum WindowMonitorEventKind
{
    Created,
    Destroyed,
    Shown,
    Hidden,
    MovedOrResized,
    TitleChanged,
    ForegroundChanged,
    Fake
}

public sealed record WindowMonitorEvent(
    WindowMonitorEventKind Kind,
    IntPtr Hwnd,
    string ProcessName,
    string Title,
    string ClassName,
    DateTimeOffset CreatedAtUtc,
    bool Relevant,
    string Reason);

internal sealed record CachedWindowIdentity(
    string ProcessName,
    string Title,
    string ClassName,
    bool Relevant,
    string Reason,
    DateTimeOffset UpdatedAtUtc);

public interface IWindowEventMonitorService
{
    bool IsActive { get; }
    long TotalReceived { get; }
    long TotalDiscarded { get; }
    WindowMonitorEvent? LastEvent { get; }
    string LastHookError { get; }

    event Action<WindowMonitorEvent>? RelevantEventReceived;

    void MarkPollingObserved(string source);
    void RecordFakeEvent(WindowMonitorEventKind kind, IntPtr hwnd, string processName, string title, string className, bool relevant, string reason);
    WindowEventMonitorSnapshot GetSnapshotForTest();
}

public sealed record WindowEventMonitorSnapshot(
    bool IsActive,
    long TotalReceived,
    long TotalDiscarded,
    string LastEventKind,
    string LastHookError);

public sealed class WindowsEventMonitorService : IHostedService, IDisposable, IWindowEventMonitorService
{
    private const uint WINEVENT_OUTOFCONTEXT = 0x0000;
    private const uint EVENT_SYSTEM_FOREGROUND = 0x0003;
    private const uint EVENT_OBJECT_CREATE = 0x8000;
    private const uint EVENT_OBJECT_DESTROY = 0x8001;
    private const uint EVENT_OBJECT_SHOW = 0x8002;
    private const uint EVENT_OBJECT_HIDE = 0x8003;
    private const uint EVENT_OBJECT_LOCATIONCHANGE = 0x800B;
    private const uint EVENT_OBJECT_NAMECHANGE = 0x800C;
    private const int OBJID_WINDOW = 0;

    private static readonly uint[] HookEvents =
    [
        EVENT_SYSTEM_FOREGROUND,
        EVENT_OBJECT_CREATE,
        EVENT_OBJECT_DESTROY,
        EVENT_OBJECT_SHOW,
        EVENT_OBJECT_HIDE,
        EVENT_OBJECT_LOCATIONCHANGE,
        EVENT_OBJECT_NAMECHANGE
    ];

    private readonly IApplicationHealthService _health;
    private readonly IWindowEventFlowControlService _flowControl;
    private readonly ConcurrentQueue<WindowMonitorEvent> _events = new();
    private readonly ConcurrentDictionary<string, DateTimeOffset> _dedupe = new();
    private readonly ConcurrentDictionary<IntPtr, DateTimeOffset> _lastMovementLogUtcByHwnd = new();
    private readonly ConcurrentDictionary<IntPtr, CachedWindowIdentity> _identityByHwnd = new();
    private const int MovementLogThrottleMs = 1500;
    private readonly List<IntPtr> _hooks = new();
    private readonly object _gate = new();

    private WinEventDelegate? _callback;
    private long _totalReceived;
    private long _totalDiscarded;
    private WindowMonitorEvent? _lastEvent;
    private string _lastHookError = string.Empty;
    private DateTimeOffset _lastPollingObservedUtc = DateTimeOffset.MinValue;
    private DateTimeOffset _lastPollingLogUtc = DateTimeOffset.MinValue;
    private long _suppressedPollingLogs;
    private const int PollingLogThrottleMs = 15000;

    public WindowsEventMonitorService(IApplicationHealthService health)
        : this(health, new WindowEventFlowControlService())
    {
    }

    public WindowsEventMonitorService(IApplicationHealthService health, IWindowEventFlowControlService flowControl)
    {
        _health = health;
        _flowControl = flowControl;
    }

    public bool IsActive
    {
        get
        {
            lock (_gate)
                return _hooks.Count == HookEvents.Length && _hooks.All(hook => hook != IntPtr.Zero);
        }
    }

    public long TotalReceived => Interlocked.Read(ref _totalReceived);
    public long TotalDiscarded => Interlocked.Read(ref _totalDiscarded);

    public WindowMonitorEvent? LastEvent
    {
        get { lock (_gate) return _lastEvent; }
    }

    public string LastHookError
    {
        get { lock (_gate) return _lastHookError; }
    }

    public event Action<WindowMonitorEvent>? RelevantEventReceived;

    public Task StartAsync(CancellationToken cancellationToken)
    {
        try
        {
            _callback = HandleWinEvent;

            foreach (var eventId in HookEvents)
            {
                var hook = SetWinEventHook(
                    eventId,
                    eventId,
                    IntPtr.Zero,
                    _callback,
                    0,
                    0,
                    WINEVENT_OUTOFCONTEXT);

                if (hook == IntPtr.Zero)
                {
                    var error = Marshal.GetLastWin32Error();
                    SetHookError($"SetWinEventHook failed for 0x{eventId:X}: {error}");
                    AppLogger.Warn($"window-event-monitor-hook-start-failed: event=0x{eventId:X}; error={error}");
                    continue;
                }

                lock (_gate)
                    _hooks.Add(hook);
            }

            if (!IsActive)
            {
                var error = string.IsNullOrWhiteSpace(LastHookError)
                    ? $"partial-hook-start: started={_hooks.Count}; expected={HookEvents.Length}"
                    : $"{LastHookError}; partial-hook-start: started={_hooks.Count}; expected={HookEvents.Length}";

                SetHookError(error);
                _health.SetWindowEventHookActive(false);
                _health.SetWindowEventHookFailure(error);
                AppLogger.Warn($"window-event-monitor-partial-start: started={_hooks.Count}; expected={HookEvents.Length}; error={error}");
            }
            else
            {
                AppLogger.Info("window-event-monitor-started: mode=shadow; hooks=specific; allHooks=true; events=create,destroy,show,hide,location,name,foreground");
                _health.SetWindowEventHookActive(true);
                _health.SetLastWindowEvent("started");
            }
        }
        catch (Exception ex)
        {
            SetHookError(ex.Message);
            AppLogger.Warn($"window-event-monitor-start-exception: error={ex.Message}");
            _health.SetWindowEventHookActive(false);
            _health.SetWindowEventHookFailure(ex.Message);
        }

        return Task.CompletedTask;
    }

    public Task StopAsync(CancellationToken cancellationToken)
    {
        Dispose();
        return Task.CompletedTask;
    }

    public void MarkPollingObserved(string source)
    {
        var now = DateTimeOffset.UtcNow;
        _lastPollingObservedUtc = now;
        var last = LastEvent;
        if (last is null)
            return;

        if ((now - _lastPollingLogUtc).TotalMilliseconds < PollingLogThrottleMs)
        {
            Interlocked.Increment(ref _suppressedPollingLogs);
            return;
        }

        _lastPollingLogUtc = now;
        var suppressed = Interlocked.Exchange(ref _suppressedPollingLogs, 0);
        var deltaMs = (now - last.CreatedAtUtc).TotalMilliseconds;
        AppLogger.Info(
            $"window-event-monitor-polling-compare: source={source}; lastEvent={last.Kind}; hwnd=0x{last.Hwnd.ToInt64():X}; " +
            $"process={last.ProcessName}; relevant={last.Relevant}; deltaMs={deltaMs:0}; total={TotalReceived}; " +
            $"discarded={TotalDiscarded}; suppressedSinceLast={suppressed}");
    }

    public void RecordFakeEvent(WindowMonitorEventKind kind, IntPtr hwnd, string processName, string title, string className, bool relevant, string reason)
    {
        if (kind == WindowMonitorEventKind.Destroyed && string.IsNullOrWhiteSpace(processName))
        {
            var cached = ResolveIdentityForDestroyedWindow(hwnd);
            if (cached is not null)
            {
                RecordEvent(kind, hwnd, cached.ProcessName, cached.Title, cached.ClassName, cached.Relevant, "fake-" + cached.Reason, updateCache: false);
                _identityByHwnd.TryRemove(hwnd, out _);
                return;
            }
        }

        RecordEvent(kind, hwnd, processName, title, className, relevant, "fake-" + reason, updateCache: kind != WindowMonitorEventKind.Destroyed);
    }

    public WindowEventMonitorSnapshot GetSnapshotForTest()
    {
        return new WindowEventMonitorSnapshot(
            IsActive,
            TotalReceived,
            TotalDiscarded,
            LastEvent?.Kind.ToString() ?? string.Empty,
            LastHookError);
    }

    private void HandleWinEvent(
        IntPtr hWinEventHook,
        uint eventType,
        IntPtr hwnd,
        int idObject,
        int idChild,
        uint dwEventThread,
        uint dwmsEventTime)
    {
        if (idObject != OBJID_WINDOW || hwnd == IntPtr.Zero)
            return;

        if (!TryMapEventKind(eventType, out var kind))
        {
            Interlocked.Increment(ref _totalDiscarded);
            _health.SetWindowEventTotals(TotalReceived, TotalDiscarded);
            return;
        }

        try
        {
            var identity = kind == WindowMonitorEventKind.Destroyed
                ? ResolveIdentityForDestroyedWindow(hwnd)
                : ResolveLiveIdentity(hwnd);

            if (identity is null)
            {
                Interlocked.Increment(ref _totalDiscarded);
                _health.SetWindowEventTotals(TotalReceived, TotalDiscarded);
                return;
            }

            RecordEvent(
                kind,
                hwnd,
                identity.ProcessName,
                identity.Title,
                identity.ClassName,
                identity.Relevant,
                identity.Reason,
                updateCache: kind != WindowMonitorEventKind.Destroyed);

            if (kind == WindowMonitorEventKind.Destroyed)
                _identityByHwnd.TryRemove(hwnd, out _);
        }
        catch (Exception ex)
        {
            Interlocked.Increment(ref _totalDiscarded);
            SetHookError(ex.Message);
            _health.SetWindowEventHookFailure(ex.Message);
            _health.SetWindowEventTotals(TotalReceived, TotalDiscarded);
        }
    }

    private static bool TryMapEventKind(uint eventType, out WindowMonitorEventKind kind)
    {
        kind = eventType switch
        {
            EVENT_OBJECT_CREATE => WindowMonitorEventKind.Created,
            EVENT_OBJECT_DESTROY => WindowMonitorEventKind.Destroyed,
            EVENT_OBJECT_SHOW => WindowMonitorEventKind.Shown,
            EVENT_OBJECT_HIDE => WindowMonitorEventKind.Hidden,
            EVENT_OBJECT_LOCATIONCHANGE => WindowMonitorEventKind.MovedOrResized,
            EVENT_OBJECT_NAMECHANGE => WindowMonitorEventKind.TitleChanged,
            EVENT_SYSTEM_FOREGROUND => WindowMonitorEventKind.ForegroundChanged,
            _ => default
        };

        return eventType is EVENT_OBJECT_CREATE
            or EVENT_OBJECT_DESTROY
            or EVENT_OBJECT_SHOW
            or EVENT_OBJECT_HIDE
            or EVENT_OBJECT_LOCATIONCHANGE
            or EVENT_OBJECT_NAMECHANGE
            or EVENT_SYSTEM_FOREGROUND;
    }

    private CachedWindowIdentity? ResolveLiveIdentity(IntPtr hwnd)
    {
        var processName = Win32.GetProcessName(hwnd).Trim();
        var title = Win32.GetWindowTitle(hwnd).Trim();
        var className = Win32.GetClass(hwnd).Trim();

        var relevant = IsRelevantWindow(hwnd, processName, title, className, out var reason);
        var identity = new CachedWindowIdentity(
            RedactProcess(processName),
            RedactTitle(title, relevant),
            className,
            relevant,
            reason,
            DateTimeOffset.UtcNow);

        _identityByHwnd[hwnd] = identity;
        return identity;
    }

    private CachedWindowIdentity? ResolveIdentityForDestroyedWindow(IntPtr hwnd)
    {
        if (_identityByHwnd.TryGetValue(hwnd, out var cached))
            return cached with { Reason = cached.Relevant ? cached.Reason + "/destroy-from-cache" : cached.Reason };

        try
        {
            return ResolveLiveIdentity(hwnd);
        }
        catch
        {
            return null;
        }
    }

    private void RecordEvent(
        WindowMonitorEventKind kind,
        IntPtr hwnd,
        string processName,
        string title,
        string className,
        bool relevant,
        string reason,
        bool updateCache)
    {
        var now = DateTimeOffset.UtcNow;

        if (relevant && kind == WindowMonitorEventKind.MovedOrResized &&
            _flowControl.ShouldSuppressMovement(hwnd, now, out _, out _))
        {
            Interlocked.Increment(ref _totalDiscarded);
            _health.SetWindowEventTotals(TotalReceived, TotalDiscarded);
            return;
        }

        var key = kind == WindowMonitorEventKind.MovedOrResized
            ? $"movement:{hwnd.ToInt64():X}"
            : $"{kind}:{hwnd.ToInt64():X}:{processName}:{className}:{title}";
        var dedupeWindowMs = kind == WindowMonitorEventKind.MovedOrResized ? 250 : 120;
        if (_dedupe.TryGetValue(key, out var previous) && (now - previous).TotalMilliseconds < dedupeWindowMs)
        {
            Interlocked.Increment(ref _totalDiscarded);
            _health.SetWindowEventTotals(TotalReceived, TotalDiscarded);
            return;
        }

        _dedupe[key] = now;

        if (_dedupe.Count > 512)
        {
            foreach (var pair in _dedupe.Where(p => (now - p.Value).TotalSeconds > 10).Take(128))
                _dedupe.TryRemove(pair.Key, out _);
        }

        if (updateCache)
        {
            _identityByHwnd[hwnd] = new CachedWindowIdentity(
                processName,
                title,
                className,
                relevant,
                reason,
                now);
        }

        var ev = new WindowMonitorEvent(kind, hwnd, processName, title, className, now, relevant, reason);

        _events.Enqueue(ev);
        while (_events.Count > 256 && _events.TryDequeue(out _)) { }

        Interlocked.Increment(ref _totalReceived);
        lock (_gate) _lastEvent = ev;

        _health.SetLastWindowEvent($"{ev.Kind}; hwnd=0x{hwnd.ToInt64():X}; process={ev.ProcessName}; relevant={ev.Relevant}; reason={ev.Reason}");
        _health.SetWindowEventTotals(TotalReceived, TotalDiscarded);

        if (relevant)
        {
            var shouldLogEvent = ev.Kind != WindowMonitorEventKind.MovedOrResized;
            if (!shouldLogEvent)
            {
                var previousMovementLogUtc = _lastMovementLogUtcByHwnd.TryGetValue(hwnd, out var previousLogUtc)
                    ? previousLogUtc
                    : DateTimeOffset.MinValue;
                shouldLogEvent = (now - previousMovementLogUtc).TotalMilliseconds >= MovementLogThrottleMs;
                if (shouldLogEvent)
                    _lastMovementLogUtcByHwnd[hwnd] = now;
            }

            if (shouldLogEvent)
            {
                AppLogger.Info(
                    $"window-event-monitor-event: kind={ev.Kind}; hwnd=0x{hwnd.ToInt64():X}; process={ev.ProcessName}; " +
                    $"class={ev.ClassName}; title={ev.Title}; relevant={ev.Relevant}; reason={ev.Reason}; total={TotalReceived}; discarded={TotalDiscarded}");
            }

            if (ev.Kind == WindowMonitorEventKind.Destroyed)
                _lastMovementLogUtcByHwnd.TryRemove(hwnd, out _);

            RelevantEventReceived?.Invoke(ev);
        }
    }

    private static bool IsRelevantWindow(IntPtr hwnd, string processName, string title, string className, out string reason)
    {
        reason = "not-relevant";

        if (string.Equals(processName, "PiPManager.Wpf.exe", StringComparison.OrdinalIgnoreCase))
        {
            reason = "own-process";
            return false;
        }

        if (!IsLikelyBrowser(processName))
        {
            reason = "not-browser";
            return false;
        }

        var hasPipTitle =
            title.Contains("Picture-in-Picture", StringComparison.OrdinalIgnoreCase) ||
            title.Contains("Picture in Picture", StringComparison.OrdinalIgnoreCase);

        var isChromiumPipClass =
            className.Contains("Chrome_WidgetWin", StringComparison.OrdinalIgnoreCase) && hasPipTitle;

        var isMozillaPipClass =
            className.Equals("MozillaDialogClass", StringComparison.OrdinalIgnoreCase) && hasPipTitle;

        var isFirefoxPipWindow =
            className.Contains("Mozilla", StringComparison.OrdinalIgnoreCase) && hasPipTitle;

        if (hasPipTitle || isChromiumPipClass || isMozillaPipClass || isFirefoxPipWindow)
        {
            reason = "pip-title-or-pip-class";
            return true;
        }

        reason = "browser-non-pip";
        return false;
    }

    private static bool IsLikelyBrowser(string processName)
    {
        return processName.Equals("zen.exe", StringComparison.OrdinalIgnoreCase) ||
               processName.Equals("firefox.exe", StringComparison.OrdinalIgnoreCase) ||
               processName.Equals("chrome.exe", StringComparison.OrdinalIgnoreCase) ||
               processName.Equals("brave.exe", StringComparison.OrdinalIgnoreCase) ||
               processName.Equals("msedge.exe", StringComparison.OrdinalIgnoreCase) ||
               processName.Equals("chromium.exe", StringComparison.OrdinalIgnoreCase);
    }

    private static string RedactTitle(string title, bool relevant)
    {
        if (string.IsNullOrWhiteSpace(title))
            return "-";

        var isPipTitle = title.Contains("Picture-in-Picture", StringComparison.OrdinalIgnoreCase) ||
            title.Contains("Picture in Picture", StringComparison.OrdinalIgnoreCase);

        if (!relevant || !isPipTitle)
            return "[title-redacted]";

        return title.Length > 64 ? title[..64] + "..." : title;
    }

    private static string RedactProcess(string processName)
    {
        return string.IsNullOrWhiteSpace(processName) ? "-" : processName;
    }

    private void SetHookError(string message)
    {
        lock (_gate) _lastHookError = message;
    }

    public void Dispose()
    {
        List<IntPtr> hooks;
        lock (_gate)
        {
            hooks = _hooks.ToList();
            _hooks.Clear();
        }

        foreach (var hook in hooks)
        {
            try
            {
                if (hook != IntPtr.Zero)
                    UnhookWinEvent(hook);
            }
            catch (Exception ex)
            {
                SetHookError(ex.Message);
                AppLogger.Warn($"window-event-monitor-stop-failed: error={ex.Message}");
            }
        }

        if (hooks.Count > 0)
            AppLogger.Info("window-event-monitor-stopped");

        _health.SetWindowEventHookActive(false);
    }

    private delegate void WinEventDelegate(
        IntPtr hWinEventHook,
        uint eventType,
        IntPtr hwnd,
        int idObject,
        int idChild,
        uint dwEventThread,
        uint dwmsEventTime);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern IntPtr SetWinEventHook(
        uint eventMin,
        uint eventMax,
        IntPtr hmodWinEventProc,
        WinEventDelegate lpfnWinEventProc,
        uint idProcess,
        uint idThread,
        uint dwFlags);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool UnhookWinEvent(IntPtr hWinEventHook);
}
