$ErrorActionPreference = 'Stop'
$root = Resolve-Path (Join-Path $PSScriptRoot '..\..')
$main = Get-Content (Join-Path $root 'src\PiPManager.Wpf\MainWindow.xaml.cs') -Raw
$content = Get-Content (Join-Path $root 'src\PiPManager.Extension\content.js') -Raw
$background = Get-Content (Join-Path $root 'src\PiPManager.Extension\background.js') -Raw
$manifest = Get-Content (Join-Path $root 'src\PiPManager.Extension\manifest.json') -Raw | ConvertFrom-Json

$checks = [ordered]@{
  'manifest is 1.4.39.25' = ([string]$manifest.version -eq '1.4.39.25')
  'indexless target uses asset generation operation identity' = $main.Contains('indexlessAccepted=') -and $main.Contains('tab.NextTargetGeneration <= 0') -and $main.Contains('tab.NextTargetOperationId')
  'same-tab target fallback is bounded' = $main.Contains('same-tab-authoritative-target')
  'offline no-video command is blocked' = $main.Contains('video-command-blocked-offline-no-video')
  'playlist collection root is blocked in WPF' = $main.Contains('video-command-blocked-playlist-collection-root') -and $main.Contains('auto-return-candidate-rejected-playlist-root')
  'playlist collection root is rejected in content' = $content.Contains('playlist-collection-root-no-player')
  'previous requires authoritative navigation context' = $content.Contains('previous-target-not-authoritative') -and $content.Contains('hasSafePreviousNavigationContext()')
  'background does not use unsafe previous history' = $background.Contains('previous-blocked-no-authoritative-player') -and $background.Contains('tabs-goBack-blocked-unsafe-playlist-context')
}

$failed = 0
foreach ($item in $checks.GetEnumerator()) {
  if ($item.Value) { Write-Host ($item.Key + ': OK') -ForegroundColor Green }
  else { Write-Host ($item.Key + ': FAIL') -ForegroundColor Red; $failed++ }
}
if ($failed -gt 0) { throw 'Authoritative CommandTarget + playlist root guard Hotfix 10 checks failed.' }
Write-Host 'Authoritative CommandTarget + playlist root guard Hotfix 10 checks OK.'
