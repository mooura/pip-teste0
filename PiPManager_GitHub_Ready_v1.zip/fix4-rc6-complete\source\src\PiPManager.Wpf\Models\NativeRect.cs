﻿namespace PiPManager.Wpf.Models;

public readonly record struct NativeRect(int Left, int Top, int Right, int Bottom)
{
    public int Width => Math.Max(0, Right - Left);
    public int Height => Math.Max(0, Bottom - Top);
    public int CenterX => Left + Width / 2;
    public int CenterY => Top + Height / 2;
    public bool IsValid => Right > Left && Bottom > Top && Width > 5 && Height > 5;

    public bool Intersects(NativeRect other) => IsValid && other.IsValid &&
        !(Right <= other.Left || Left >= other.Right || Bottom <= other.Top || Top >= other.Bottom);

    public int IntersectionArea(NativeRect other)
    {
        if (!Intersects(other)) return 0;
        var w = Math.Max(0, Math.Min(Right, other.Right) - Math.Max(Left, other.Left));
        var h = Math.Max(0, Math.Min(Bottom, other.Bottom) - Math.Max(Top, other.Top));
        return w * h;
    }

    public bool Contains(int x, int y) => IsValid && x >= Left && x <= Right && y >= Top && y <= Bottom;

    public NativeRect Offset(int dx, int dy) => new(Left + dx, Top + dy, Right + dx, Bottom + dy);
}
