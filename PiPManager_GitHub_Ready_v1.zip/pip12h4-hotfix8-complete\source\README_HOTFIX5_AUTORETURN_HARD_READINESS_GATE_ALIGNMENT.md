# Hotfix 5 — AutoReturn Hard Readiness Gate Alignment

## Motivo

O checker histórico de hard readiness exigia que `hardNotReady` continuasse gerando
deferrals sem limite. O Hotfix 5 substituiu deliberadamente esse comportamento no
auto-next terminal por uma única deferral seguida de observação estrutural passiva.

## Alinhamento

O checker agora valida simultaneamente que:

- ausência de source/estado ended continuam bloqueando tentativa física imediata;
- o caminho de comando manual preserva a readiness mínima após a janela curta;
- `ShouldDeferPhysicalAttemptForReadiness` respeita estritamente `maxReadinessDeferrals`;
- o auto-next terminal entra em `TerminalPassiveWatch` ao atingir o limite;
- o caminho não terminal mantém fallback físico explícito após deferrals limitadas;
- readiness não consome o backoff das tentativas físicas.

Nenhum arquivo executável, protocolo ou versão da extensão foi alterado.
