﻿using System.Runtime.InteropServices;
using System.Threading;

namespace PiPManager.Wpf.Services;

internal enum VideoCommandKind
{
    Previous,
    Next
}

public sealed class VideoCommandService
{
    private const ushort VK_SHIFT = 0x10;
    private const ushort VK_CONTROL = 0x11;
    private const ushort VK_LSHIFT = 0xA0;
    private const ushort VK_LCONTROL = 0xA2;
    private const ushort VK_MENU = 0x12; // Alt
    private const ushort VK_LEFT = 0x25; // Seta esquerda
    private const ushort VK_N = 0x4E;
    private const ushort VK_OEM_6 = 0xDD; // ] / BracketRight
    private const ushort SC_LCONTROL = 0x1D;
    private const ushort SC_LSHIFT = 0x2A;
    private const ushort SC_OEM_6 = 0x1B; // tecla ] em layout US; em alguns layouts o VK funciona melhor.
    private const uint INPUT_KEYBOARD = 1;
    private const uint KEYEVENTF_KEYUP = 0x0002;
    private const uint KEYEVENTF_SCANCODE = 0x0008;
    private const int SW_RESTORE = 9;
    private const int BrowserCloakSafetyTimeoutMs = 3000;
    private static readonly object BrowserCloakSync = new();
    private static BrowserVisibilityLease? _activeBrowserCloak;
    private static long _browserCloakGeneration;
    private static int _pipShortcutSendInputUnsupported;

    private sealed class BrowserVisibilityLease
    {
        internal required IntPtr Hwnd { get; init; }
        internal required int ProcessId { get; init; }
        internal required IntPtr OriginalExStyle { get; init; }
        internal required bool OriginallyLayered { get; init; }
        internal required bool HadLayeredAttributes { get; init; }
        internal required uint OriginalColorKey { get; init; }
        internal required byte OriginalAlpha { get; init; }
        internal required uint OriginalLayeredFlags { get; init; }
        internal required bool HadCustomRegion { get; init; }
        internal required IntPtr OriginalRegion { get; set; }
        internal required bool RegionCloakApplied { get; init; }
        internal long Generation { get; set; }
        internal int Restored;
    }

    internal static string LastInputDiagnostic { get; private set; } = string.Empty;

    [StructLayout(LayoutKind.Sequential)]
    private struct INPUT
    {
        public uint type;
        public InputUnion U;
    }

    [StructLayout(LayoutKind.Explicit)]
    private struct InputUnion
    {
        [FieldOffset(0)] public KEYBDINPUT ki;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct KEYBDINPUT
    {
        public ushort wVk;
        public ushort wScan;
        public uint dwFlags;
        public uint time;
        public IntPtr dwExtraInfo;
    }

    [DllImport("user32.dll", SetLastError = true)]
    private static extern uint SendInput(uint nInputs, INPUT[] pInputs, int cbSize);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, UIntPtr dwExtraInfo);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool SetForegroundWindow(IntPtr hWnd);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool BringWindowToTop(IntPtr hWnd);

    [DllImport("user32.dll")]
    private static extern IntPtr GetForegroundWindow();

    internal static async Task<bool> SendToWindowAsync(IntPtr hWnd, VideoCommandKind command)
    {
        if (hWnd == IntPtr.Zero || !Win32.IsWindow(hWnd))
        {
            LastInputDiagnostic = "hwnd inválido";
            return false;
        }

        try
        {
            Win32.ShowWindow(hWnd, Win32.SW_SHOW);
            Win32.SetWindowPos(hWnd, Win32.HWND_TOPMOST, 0, 0, 0, 0,
                Win32.SWP_NOMOVE | Win32.SWP_NOSIZE | Win32.SWP_NOACTIVATE | Win32.SWP_ASYNCWINDOWPOS);
            BringWindowToTop(hWnd);
            SetForegroundWindow(hWnd);

            await Task.Delay(75).ConfigureAwait(true);

            if (command == VideoCommandKind.Next)
                return SendChord(VK_SHIFT, VK_N);

            return SendChord(VK_MENU, VK_LEFT);
        }
        catch (Exception ex)
        {
            LastInputDiagnostic = ex.Message;
            return false;
        }
    }

    internal static async Task<bool> SendOpenPictureInPictureShortcutToForegroundAsync(
        string? expectedDomain = null,
        string? expectedTitle = null,
        bool foregroundAlreadyVerified = false)
    {
        IntPtr browserHwnd = IntPtr.Zero;
        var shortcutDispatched = false;
        var cloakDiagnostic = "cloak=not-requested";

        try
        {
            var before = DescribeForegroundWindow();
            browserHwnd = FindLikelyBrowserWindow(expectedDomain, expectedTitle);
            var activated = false;

            var browserWasMinimized = browserHwnd != IntPtr.Zero && Win32.IsIconic(browserHwnd);
            var browserReady = false;
            var browserReadyElapsedMs = 0.0;

            if (browserHwnd != IntPtr.Zero)
            {
                cloakDiagnostic = PrepareBrowserForegroundCloak(browserHwnd);
                Win32.DwmFlush();

                var canReuseVerifiedForeground = foregroundAlreadyVerified
                    && GetForegroundWindow() == browserHwnd
                    && !Win32.IsIconic(browserHwnd);
                if (canReuseVerifiedForeground)
                {
                    activated = true;
                    browserReady = true;
                    browserReadyElapsedMs = 0;
                }
                else
                {
                    await Task.Delay(24).ConfigureAwait(true);
                    activated = TryActivateWindow(browserHwnd);
                    Win32.DwmFlush();
                    var readyResult = await WaitForBrowserReadyAfterActivationAsync(
                        browserHwnd,
                        browserWasMinimized ? 650 : 240).ConfigureAwait(true);
                    browserReady = readyResult.Ready;
                    browserReadyElapsedMs = readyResult.ElapsedMs;
                }
            }
            else
            {
                await Task.Delay(80).ConfigureAwait(true);
            }

            var afterActivate = DescribeForegroundWindow();
            var foregroundLooksBrowser = browserHwnd != IntPtr.Zero
                ? GetForegroundWindow() == browserHwnd && !Win32.IsIconic(browserHwnd)
                : ForegroundLooksLikeBrowser();

            if (Volatile.Read(ref _pipShortcutSendInputUnsupported) != 0)
            {
                SendPipChordWithKeybdEventFast();
                shortcutDispatched = true;
                LastInputDiagnostic =
                    $"keybd_event fallback físico rápido enviado por cache de compatibilidade; LeftCtrl+LeftShift+]; fastTiming=16/32ms; {cloakDiagnostic}; foregroundAntes={before}; browserHwnd=0x{browserHwnd.ToInt64():X}; browserWasMinimized={browserWasMinimized}; browserReady={browserReady}; browserReadyElapsedMs={browserReadyElapsedMs:0}; foregroundReused={foregroundAlreadyVerified}; ativado={activated}; foregroundApósAtivar={afterActivate}; foregroundBrowser={foregroundLooksBrowser}";
                return true;
            }

            var vkOk = SendPhysicalPipShortcutWithVk();
            var afterVk = DescribeForegroundWindow();

            if (vkOk)
            {
                shortcutDispatched = true;
                LastInputDiagnostic =
                    $"SendInput físico VK OK; LeftCtrl+LeftShift+]; {cloakDiagnostic}; foregroundAntes={before}; browserHwnd=0x{browserHwnd.ToInt64():X}; browserWasMinimized={browserWasMinimized}; browserReady={browserReady}; browserReadyElapsedMs={browserReadyElapsedMs:0}; foregroundReused={foregroundAlreadyVerified}; ativado={activated}; foregroundApósAtivar={afterActivate}; foregroundBrowser={foregroundLooksBrowser}; foregroundApósEnvio={afterVk}";
                return true;
            }

            var vkError = LastInputDiagnostic;
            var scOk = SendPhysicalPipShortcutWithScancode();
            var afterSc = DescribeForegroundWindow();

            if (scOk)
            {
                shortcutDispatched = true;
                LastInputDiagnostic =
                    $"SendInput físico SCANCODE OK; LeftCtrl+LeftShift+]; {cloakDiagnostic}; vkFalhou={vkError}; foregroundAntes={before}; browserHwnd=0x{browserHwnd.ToInt64():X}; browserWasMinimized={browserWasMinimized}; browserReady={browserReady}; browserReadyElapsedMs={browserReadyElapsedMs:0}; foregroundReused={foregroundAlreadyVerified}; ativado={activated}; foregroundApósAtivar={afterActivate}; foregroundBrowser={foregroundLooksBrowser}; foregroundApósEnvio={afterSc}";
                return true;
            }

            var scError = LastInputDiagnostic;
            if (vkError.Contains("err=87", StringComparison.OrdinalIgnoreCase) &&
                scError.Contains("err=87", StringComparison.OrdinalIgnoreCase))
            {
                Volatile.Write(ref _pipShortcutSendInputUnsupported, 1);
            }

            SendPipChordWithKeybdEventFast();
            shortcutDispatched = true;
            LastInputDiagnostic =
                $"keybd_event fallback físico rápido enviado; LeftCtrl+LeftShift+]; fastTiming=16/32ms; sendInputCachedUnsupported={Volatile.Read(ref _pipShortcutSendInputUnsupported) != 0}; {cloakDiagnostic}; vkFalhou={vkError}; scFalhou={scError}; foregroundAntes={before}; browserHwnd=0x{browserHwnd.ToInt64():X}; browserWasMinimized={browserWasMinimized}; browserReady={browserReady}; browserReadyElapsedMs={browserReadyElapsedMs:0}; foregroundReused={foregroundAlreadyVerified}; ativado={activated}; foregroundApósAtivar={afterActivate}; foregroundBrowser={foregroundLooksBrowser}";
            return true;
        }
        catch (Exception ex)
        {
            LastInputDiagnostic = $"atalho físico erro={ex.Message}; {cloakDiagnostic}; foreground={DescribeForegroundWindow()}";
            return false;
        }
        finally
        {
            // Sucesso mantém o navegador invisível até a minimização do fluxo principal.
            // Falha/retorno antecipado restaura imediatamente; o safety timer é a segunda barreira.
            if (!shortcutDispatched && browserHwnd != IntPtr.Zero)
                RestoreBrowserForegroundCloak(browserHwnd, "shortcut-finally-failure");
        }
    }


    private static async Task<(bool Ready, double ElapsedMs)> WaitForBrowserReadyAfterActivationAsync(IntPtr browserHwnd, int timeoutMs)
    {
        var started = DateTime.UtcNow;
        var deadline = started.AddMilliseconds(Math.Max(100, timeoutMs));
        var stableSamples = 0;

        while (DateTime.UtcNow < deadline)
        {
            var ready = Win32.IsWindow(browserHwnd)
                && !Win32.IsIconic(browserHwnd)
                && GetForegroundWindow() == browserHwnd;

            if (ready)
            {
                stableSamples++;
                if (stableSamples >= 2)
                    return (true, (DateTime.UtcNow - started).TotalMilliseconds);
            }
            else
            {
                stableSamples = 0;
                TryActivateWindow(browserHwnd);
            }

            await Task.Delay(25).ConfigureAwait(true);
        }

        return (false, (DateTime.UtcNow - started).TotalMilliseconds);
    }

    internal static bool TryMinimizeExpectedBrowserWindow(string? expectedDomain = null, string? expectedTitle = null)
    {
        IntPtr browserHwnd = IntPtr.Zero;
        try
        {
            browserHwnd = FindLikelyBrowserWindow(expectedDomain, expectedTitle);
            if (browserHwnd == IntPtr.Zero || !Win32.IsWindow(browserHwnd))
            {
                RestoreBrowserForegroundCloak(IntPtr.Zero, "minimize-browser-not-found");
                LastInputDiagnostic = "minimize-browser: janela esperada não encontrada; cloak restaurado";
                return false;
            }

            var ok = Win32.ShowWindow(browserHwnd, Win32.SW_MINIMIZE);
            var restored = RestoreBrowserForegroundCloak(browserHwnd, "after-minimize");
            LastInputDiagnostic = $"minimize-browser: hwnd=0x{browserHwnd.ToInt64():X}; ok={ok}; cloakRestored={restored}";
            return ok;
        }
        catch (Exception ex)
        {
            RestoreBrowserForegroundCloak(browserHwnd, "minimize-browser-exception");
            LastInputDiagnostic = $"minimize-browser: erro={ex.Message}; cloak restaurado";
            return false;
        }
    }

    private static bool SendPhysicalPipShortcutWithVk()
    {
        var inputs = new[]
        {
            KeyDown(VK_LCONTROL),
            KeyDown(VK_LSHIFT),
            KeyDown(VK_OEM_6),
            KeyUp(VK_OEM_6),
            KeyUp(VK_LSHIFT),
            KeyUp(VK_LCONTROL)
        };

        var sent = SendInput((uint)inputs.Length, inputs, Marshal.SizeOf<INPUT>());
        var error = Marshal.GetLastWin32Error();
        if (sent == inputs.Length)
            return true;

        LastInputDiagnostic = $"SendInput físico VK falhou; enviados={sent}/{inputs.Length}; err={error}";
        return false;
    }

    private static bool SendPhysicalPipShortcutWithScancode()
    {
        var inputs = new[]
        {
            ScanDown(SC_LCONTROL),
            ScanDown(SC_LSHIFT),
            ScanDown(SC_OEM_6),
            ScanUp(SC_OEM_6),
            ScanUp(SC_LSHIFT),
            ScanUp(SC_LCONTROL)
        };

        var sent = SendInput((uint)inputs.Length, inputs, Marshal.SizeOf<INPUT>());
        var error = Marshal.GetLastWin32Error();
        if (sent == inputs.Length)
            return true;

        LastInputDiagnostic = $"SendInput físico SCANCODE falhou; enviados={sent}/{inputs.Length}; err={error}";
        return false;
    }

    internal static string PrepareBrowserForegroundCloak(IntPtr hWnd)
    {
        if (hWnd == IntPtr.Zero || !Win32.IsWindow(hWnd))
            return "browser-foreground-cloak-skipped:invalid-hwnd";

        BrowserVisibilityLease? lease;
        lock (BrowserCloakSync)
        {
            if (_activeBrowserCloak is { } current &&
                Volatile.Read(ref current.Restored) == 0 &&
                current.Hwnd == hWnd &&
                current.ProcessId == Win32.GetProcessId(hWnd))
            {
                current.Generation = ++_browserCloakGeneration;
                ArmBrowserVisibilitySafetyRestore(current);
                return $"browser-foreground-cloak-reused:g={current.Generation}";
            }

            if (_activeBrowserCloak is not null)
                RestoreBrowserVisibilityCore(_activeBrowserCloak, "replaced-by-new-browser");

            var processId = Win32.GetProcessId(hWnd);
            var originalExStyle = Win32.GetWindowLongPtr(hWnd, Win32.GWL_EXSTYLE);
            var originallyLayered = (originalExStyle.ToInt64() & Win32.WS_EX_LAYERED) != 0;
            uint originalColorKey = 0;
            byte originalAlpha = 255;
            uint originalFlags = Win32.LWA_ALPHA;
            var hadAttributes = originallyLayered &&
                Win32.GetLayeredWindowAttributes(hWnd, out originalColorKey, out originalAlpha, out originalFlags);

            var originalRegion = Win32.CreateRectRgn(0, 0, 0, 0);
            var originalRegionType = originalRegion != IntPtr.Zero
                ? Win32.GetWindowRgn(hWnd, originalRegion)
                : 0;
            var hadCustomRegion = originalRegionType > 0;
            if (!hadCustomRegion && originalRegion != IntPtr.Zero)
            {
                Win32.DeleteObject(originalRegion);
                originalRegion = IntPtr.Zero;
            }

            var emptyRegion = Win32.CreateRectRgn(0, 0, 0, 0);
            var regionCloakApplied = emptyRegion != IntPtr.Zero &&
                Win32.SetWindowRgn(hWnd, emptyRegion, false) != 0;
            if (!regionCloakApplied && emptyRegion != IntPtr.Zero)
                Win32.DeleteObject(emptyRegion);

            lease = new BrowserVisibilityLease
            {
                Hwnd = hWnd,
                ProcessId = processId,
                OriginalExStyle = originalExStyle,
                OriginallyLayered = originallyLayered,
                HadLayeredAttributes = hadAttributes,
                OriginalColorKey = hadAttributes ? originalColorKey : 0,
                OriginalAlpha = hadAttributes ? originalAlpha : (byte)255,
                OriginalLayeredFlags = hadAttributes ? originalFlags : Win32.LWA_ALPHA,
                HadCustomRegion = hadCustomRegion,
                OriginalRegion = originalRegion,
                RegionCloakApplied = regionCloakApplied,
                Generation = ++_browserCloakGeneration
            };

            var temporaryStyle = new IntPtr(originalExStyle.ToInt64() | Win32.WS_EX_LAYERED);
            if (!originallyLayered)
                Win32.SetWindowLongPtr(hWnd, Win32.GWL_EXSTYLE, temporaryStyle);

            if (!Win32.SetLayeredWindowAttributes(hWnd, 0, 0, Win32.LWA_ALPHA))
            {
                if (!originallyLayered)
                    Win32.SetWindowLongPtr(hWnd, Win32.GWL_EXSTYLE, originalExStyle);
                return $"browser-foreground-cloak-skipped:set-alpha-failed:{Marshal.GetLastWin32Error()}";
            }

            Win32.SetWindowPos(hWnd, IntPtr.Zero, 0, 0, 0, 0,
                Win32.SWP_NOMOVE | Win32.SWP_NOSIZE | Win32.SWP_NOZORDER | Win32.SWP_NOACTIVATE);
            Win32.DwmFlush();

            _activeBrowserCloak = lease;
            ArmBrowserVisibilitySafetyRestore(lease);
        }

        return $"browser-foreground-cloak-applied:g={lease.Generation};region={lease.RegionCloakApplied}";
    }

    private static void ArmBrowserVisibilitySafetyRestore(BrowserVisibilityLease lease)
    {
        var generation = lease.Generation;
        _ = Task.Run(async () =>
        {
            await Task.Delay(BrowserCloakSafetyTimeoutMs).ConfigureAwait(false);
            lock (BrowserCloakSync)
            {
                if (_activeBrowserCloak == lease &&
                    lease.Generation == generation &&
                    Volatile.Read(ref lease.Restored) == 0)
                {
                    RestoreBrowserVisibilityCore(lease, "safety-timeout");
                }
            }
        });
    }

    internal static bool RestoreBrowserForegroundCloak(IntPtr expectedHwnd, string reason)
    {
        lock (BrowserCloakSync)
        {
            var lease = _activeBrowserCloak;
            if (lease is null)
                return false;

            if (expectedHwnd != IntPtr.Zero && lease.Hwnd != expectedHwnd)
                return false;

            return RestoreBrowserVisibilityCore(lease, reason);
        }
    }

    private static bool RestoreBrowserVisibilityCore(BrowserVisibilityLease lease, string reason)
    {
        if (Interlocked.Exchange(ref lease.Restored, 1) != 0)
            return false;

        try
        {
            if (Win32.IsWindow(lease.Hwnd) && Win32.GetProcessId(lease.Hwnd) == lease.ProcessId)
            {
                if (lease.OriginallyLayered && lease.HadLayeredAttributes)
                {
                    Win32.SetLayeredWindowAttributes(
                        lease.Hwnd,
                        lease.OriginalColorKey,
                        lease.OriginalAlpha,
                        lease.OriginalLayeredFlags);
                }
                else
                {
                    Win32.SetLayeredWindowAttributes(lease.Hwnd, 0, 255, Win32.LWA_ALPHA);
                }

                Win32.SetWindowLongPtr(lease.Hwnd, Win32.GWL_EXSTYLE, lease.OriginalExStyle);

                if (lease.RegionCloakApplied)
                {
                    if (lease.HadCustomRegion && lease.OriginalRegion != IntPtr.Zero)
                    {
                        Win32.SetWindowRgn(lease.Hwnd, lease.OriginalRegion, false);
                        lease.OriginalRegion = IntPtr.Zero;
                    }
                    else
                    {
                        Win32.SetWindowRgn(lease.Hwnd, IntPtr.Zero, false);
                    }
                }
                else if (lease.OriginalRegion != IntPtr.Zero)
                {
                    Win32.DeleteObject(lease.OriginalRegion);
                    lease.OriginalRegion = IntPtr.Zero;
                }

                Win32.SetWindowPos(lease.Hwnd, IntPtr.Zero, 0, 0, 0, 0,
                    Win32.SWP_NOMOVE | Win32.SWP_NOSIZE | Win32.SWP_NOZORDER | Win32.SWP_NOACTIVATE);
                Win32.DwmFlush();
            }
        }
        finally
        {
            if (lease.OriginalRegion != IntPtr.Zero)
            {
                Win32.DeleteObject(lease.OriginalRegion);
                lease.OriginalRegion = IntPtr.Zero;
            }

            if (_activeBrowserCloak == lease)
                _activeBrowserCloak = null;
        }

        return true;
    }

    private static bool TryActivateWindow(IntPtr hWnd)
    {
        if (hWnd == IntPtr.Zero || !Win32.IsWindow(hWnd))
            return false;

        try
        {
            if (Win32.IsIconic(hWnd))
                Win32.ShowWindow(hWnd, SW_RESTORE);
            else
                Win32.ShowWindow(hWnd, Win32.SW_SHOW);

            BringWindowToTop(hWnd);
            return SetForegroundWindow(hWnd);
        }
        catch
        {
            return false;
        }
    }

    private static bool ForegroundLooksLikeBrowser()
    {
        var hwnd = GetForegroundWindow();
        var process = Win32.GetProcessName(hwnd).ToLowerInvariant();
        return process.Contains("firefox") || process.Contains("zen") || process.Contains("chrome") || process.Contains("msedge");
    }

    private static string DescribeForegroundWindow()
    {
        try
        {
            var hwnd = GetForegroundWindow();
            if (hwnd == IntPtr.Zero)
                return "none";

            var process = Win32.GetProcessName(hwnd);
            var title = Win32.GetWindowTitle(hwnd);
            if (title.Length > 80)
                title = title[..80];

            return $"0x{hwnd.ToInt64():X}/{process}/{title}";
        }
        catch (Exception ex)
        {
            return $"erro={ex.Message}";
        }
    }

    private static IntPtr FindLikelyBrowserWindow(string? expectedDomain, string? expectedTitle)
    {
        var best = IntPtr.Zero;
        var bestScore = int.MinValue;
        var expectedTitleText = expectedTitle ?? string.Empty;
        var expectedDomainText = expectedDomain ?? string.Empty;

        try
        {
            Win32.EnumWindows((hWnd, _) =>
            {
                if (!Win32.IsWindow(hWnd) || !Win32.IsWindowVisible(hWnd))
                    return true;

                var process = Win32.GetProcessName(hWnd).ToLowerInvariant();
                var isBrowser = process.Contains("firefox") || process.Contains("zen") || process.Contains("chrome") || process.Contains("msedge");
                if (!isBrowser)
                    return true;

                var title = Win32.GetWindowTitle(hWnd);
                if (string.IsNullOrWhiteSpace(title))
                    return true;

                if (title.Contains("Picture-in-Picture", StringComparison.OrdinalIgnoreCase))
                    return true;

                var score = 10;

                if (!string.IsNullOrWhiteSpace(expectedDomainText) &&
                    title.Contains(expectedDomainText, StringComparison.OrdinalIgnoreCase))
                    score += 80;

                if (!string.IsNullOrWhiteSpace(expectedTitleText))
                {
                    var shortTitle = expectedTitleText.Length > 28 ? expectedTitleText[..28] : expectedTitleText;
                    if (!string.IsNullOrWhiteSpace(shortTitle) &&
                        title.Contains(shortTitle, StringComparison.OrdinalIgnoreCase))
                        score += 50;
                }

                // EnumWindows normalmente vem em ordem Z; empates favorecem o primeiro.
                if (score > bestScore)
                {
                    best = hWnd;
                    bestScore = score;
                }

                return true;
            }, IntPtr.Zero);
        }
        catch { }

        return best;
    }

    private static void SendPipChordWithKeybdEventFast()
    {
        var keys = new[] { VK_LCONTROL, VK_LSHIFT, VK_OEM_6 };
        foreach (var key in keys)
        {
            keybd_event((byte)key, 0, 0, UIntPtr.Zero);
            Thread.Sleep(16);
        }

        Thread.Sleep(32);

        for (var i = keys.Length - 1; i >= 0; i--)
        {
            keybd_event((byte)keys[i], 0, KEYEVENTF_KEYUP, UIntPtr.Zero);
            Thread.Sleep(16);
        }
    }

    private static void SendChordWithKeybdEvent(params ushort[] keys)
    {
        foreach (var key in keys)
        {
            keybd_event((byte)key, 0, 0, UIntPtr.Zero);
            Thread.Sleep(26);
        }

        Thread.Sleep(48);

        for (var i = keys.Length - 1; i >= 0; i--)
        {
            keybd_event((byte)keys[i], 0, KEYEVENTF_KEYUP, UIntPtr.Zero);
            Thread.Sleep(26);
        }
    }

    private static bool SendChord(ushort modifier, ushort key)
    {
        return SendChordRobust(modifier, key);
    }

    private static bool SendChordRobust(params ushort[] keys)
    {
        LastInputDiagnostic = string.Empty;

        if (keys.Length == 0)
        {
            LastInputDiagnostic = "nenhuma tecla";
            return false;
        }

        var inputs = new List<INPUT>();
        foreach (var key in keys)
            inputs.Add(KeyDown(key));

        for (var i = keys.Length - 1; i >= 0; i--)
            inputs.Add(KeyUp(keys[i]));

        var inputArray = inputs.ToArray();
        var expected = inputArray.Length;
        var sent = SendInput((uint)expected, inputArray, Marshal.SizeOf<INPUT>());
        var error = Marshal.GetLastWin32Error();

        if (sent == expected)
        {
            LastInputDiagnostic = $"SendInput batch OK; enviados={sent}/{expected}";
            return true;
        }

        var perKeySent = 0;
        foreach (var input in inputArray)
        {
            var single = new[] { input };
            var singleSent = SendInput(1, single, Marshal.SizeOf<INPUT>());
            if (singleSent == 1) perKeySent++;
            Thread.Sleep(18);
        }

        var perKeyError = Marshal.GetLastWin32Error();
        if (perKeySent == expected)
        {
            LastInputDiagnostic = $"SendInput batch falhou {sent}/{expected}, err={error}; per-key OK {perKeySent}/{expected}";
            return true;
        }

        try
        {
            foreach (var key in keys)
            {
                keybd_event((byte)key, 0, 0, UIntPtr.Zero);
                Thread.Sleep(18);
            }

            for (var i = keys.Length - 1; i >= 0; i--)
            {
                keybd_event((byte)keys[i], 0, KEYEVENTF_KEYUP, UIntPtr.Zero);
                Thread.Sleep(18);
            }

            LastInputDiagnostic = $"SendInput falhou batch={sent}/{expected}, err={error}; per-key={perKeySent}/{expected}, err2={perKeyError}; keybd_event fallback enviado";
            return true;
        }
        catch (Exception ex)
        {
            LastInputDiagnostic = $"SendInput falhou batch={sent}/{expected}, err={error}; per-key={perKeySent}/{expected}, err2={perKeyError}; keybd_event erro={ex.Message}";
            return false;
        }
    }

    private static INPUT KeyDown(ushort vk) => new()
    {
        type = INPUT_KEYBOARD,
        U = new InputUnion
        {
            ki = new KEYBDINPUT { wVk = vk }
        }
    };

    private static INPUT KeyUp(ushort vk) => new()
    {
        type = INPUT_KEYBOARD,
        U = new InputUnion
        {
            ki = new KEYBDINPUT { wVk = vk, dwFlags = KEYEVENTF_KEYUP }
        }
    };

    private static INPUT ScanDown(ushort scan) => new()
    {
        type = INPUT_KEYBOARD,
        U = new InputUnion
        {
            ki = new KEYBDINPUT { wScan = scan, dwFlags = KEYEVENTF_SCANCODE }
        }
    };

    private static INPUT ScanUp(ushort scan) => new()
    {
        type = INPUT_KEYBOARD,
        U = new InputUnion
        {
            ki = new KEYBDINPUT { wScan = scan, dwFlags = KEYEVENTF_SCANCODE | KEYEVENTF_KEYUP }
        }
    };
}
