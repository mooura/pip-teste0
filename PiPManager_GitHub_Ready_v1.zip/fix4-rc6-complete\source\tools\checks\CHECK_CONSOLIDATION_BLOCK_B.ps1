$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path

function Check([string]$label, [bool]$condition) {
    if (-not $condition) { throw "FAIL: $label" }
    Write-Host "$label`: OK"
}

$main = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\MainWindow.xaml.cs') -Raw
$bridge = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\Services\ExtensionBridgeService.cs') -Raw
$manifest = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Extension\manifest.json') -Raw | ConvertFrom-Json
$content = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Extension\content.js') -Raw
$profiles = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Extension\site-profiles.js') -Raw
$runner = Get-Content -LiteralPath (Join-Path $root 'RUN_CORE_TESTS.bat') -Raw

foreach ($file in @(
    'src\PiPManager.Wpf\Models\AutoReturnPolicy.cs',
    'src\PiPManager.Wpf\Models\AutoReturnSlotState.cs',
    'src\PiPManager.Wpf\Models\VideoSwitchPreservationState.cs',
    'src\PiPManager.Wpf\Models\BrowserWindowCandidate.cs',
    'src\PiPManager.Wpf\Services\AutoReturnPolicyCodec.cs',
    'src\PiPManager.Wpf\Services\ExtensionProtocolReader.cs',
    'src\PiPManager.Extension\site-profiles.js',
    'tests\Extension.Tests\site-profiles.test.js',
    'docs\consolidation\PHASE_05_08_BLOCK_B.md'
)) {
    Check "Block B file $file" (Test-Path -LiteralPath (Join-Path $root $file))
}

Check 'AutoReturn state no longer declared inside MainWindow' ($main -notmatch 'private sealed class AutoReturnSlotState')
Check 'video preservation state no longer declared inside MainWindow' ($main -notmatch 'private sealed class VideoSwitchPreservationState')
Check 'AutoReturn policy delegates to codec' ($main.Contains('AutoReturnPolicyCodec.Parse(value)') -and $main.Contains('AutoReturnPolicyCodec.Format(policy)'))
Check 'bridge delegates JSON parsing' ($bridge.Contains('ExtensionProtocolReader.GetString') -and $bridge.Contains('ExtensionProtocolReader.GetStringList'))
Check 'content consumes external profile registry' ($content.Contains('globalThis.PipManagerSiteProfiles.getProfile'))
Check 'domain declarations left content script' (-not $content.Contains('hosts:'))
Check 'capability profiles remain isolated' ($profiles.Contains("id: 'indexed-playlist'") -and $profiles.Contains("id: 'player-controls'") -and $profiles.Contains("id: 'live-rotation'"))

$scripts = @($manifest.content_scripts[0].js)
$profileIndex = [array]::IndexOf($scripts, 'site-profiles.js')
$contentIndex = [array]::IndexOf($scripts, 'content.js')
Check 'profile registry loads before content script' ($profileIndex -ge 0 -and $contentIndex -gt $profileIndex)
Check 'extension profile tests run in gate' ($runner.Contains('tests\Extension.Tests\site-profiles.test.js'))
Check 'Block B checker runs in gate' ($runner.Contains('CHECK_CONSOLIDATION_BLOCK_B.ps1'))

Write-Host 'Consolidation Block B checks OK.' -ForegroundColor Green
