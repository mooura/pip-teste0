$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$main = Get-Content (Join-Path $root 'src\PiPManager.Wpf\MainWindow.xaml.cs') -Raw
$policy = Get-Content (Join-Path $root 'src\PiPManager.Wpf\Services\RuntimeAuthorityPolicy.cs') -Raw
$release = Get-Content (Join-Path $root 'src\PiPManager.Wpf\Services\ReleaseInfoService.cs') -Raw
$runner = Get-Content (Join-Path $root 'RUN_CORE_TESTS.bat') -Raw
$checks = [ordered]@{
  'internal authority option' = $policy.Contains('PIPMANAGER_REACTOR_CAPTURE_MODE')
  'compare is safe default' = $policy.Contains('_ => ReactorCaptureMode.Compare') -and $policy.Contains('_ => "compare"')
  'legacy observe-only option' = $main.Contains('reactorMode == "legacy"')
  'primary authority option' = $main.Contains('reactorMode == "primary"')
  'immediate exact-match confirmation' = $main.Contains('adaptive-immediate-exact-attempt-match')
  '125 ms uncertain confirmation' = $main.Contains('ReactorPrimaryShortConfirmationWaitMs = 125')
  'legacy 350 ms compare window retained' = $main.Contains('ReactorAssistedConfirmationWaitMs = 350')
  'latency metrics emitted' = $main.Contains('windowToCaptureMs=') -and $main.Contains('commandToCaptureMs=')
  'fallback metric emitted' = $main.Contains('fallbackUsed=False')
  'release mode identifies compare default' = $release.Contains('ReactorCompareDefault')
  'checker included in core gate' = $runner.Contains('CHECK_REACTOR_ADAPTIVE_AUTHORITY.ps1')
}
$failed = 0
foreach ($item in $checks.GetEnumerator()) {
  if ($item.Value) { Write-Host "$($item.Key): OK" } else { Write-Host "$($item.Key): FAIL"; $failed++ }
}
if ($failed -gt 0) { throw 'Reactor adaptive authority checks failed.' }
Write-Host 'Reactor adaptive authority checks OK.'
