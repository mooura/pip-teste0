# Fase 12 — segurança do AutoAdvance e recuperação de alvo

- Toda navegação `Next`/`Previous` invalida a geração anterior do observador de perda do PiP.
- Perda do PiP durante preservação de troca não arma um segundo AutoAdvance.
- Snapshot ausente, obsoleto ou temporariamente sem fonte não prova término; o fallback exige `ended=true`.
- Eventos terminais atrasados são rejeitados antes e depois do gate serializado.
- Silent reopen da preservação usa reacquisition fresca e segura na mesma aba, mantendo bloqueio por ambiguidade.
- Telemetria de preview distingue `direct-video`, `cdn-frame-sequence` e `static-image`.
- As regras puras possuem regressões no projeto `PiPManager.Core.Tests`.
