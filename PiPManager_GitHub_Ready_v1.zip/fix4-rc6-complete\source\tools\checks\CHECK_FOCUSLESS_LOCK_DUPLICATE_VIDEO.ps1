$ErrorActionPreference = "Stop"
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$main = Get-Content (Join-Path $root "src\PiPManager.Wpf\MainWindow.xaml.cs") -Raw
$run = Get-Content (Join-Path $root "RUN_CORE_TESTS.bat") -Raw
$failed = 0
function Check($name, $ok) { if ($ok) { Write-Host "$name`: OK" } else { Write-Host "$name`: FAIL"; $script:failed++ } }
Check "focusless final failure releases lock" ($main.Contains('EndOpenPipAttempt(targetSlot, tab, "Abrir sem foco", "falha-final")'))
Check "focusless final failure clears armed state" ($main.Contains('ClearArmedPipPairState(stopTimer: true)'))
Check "friendly retry status" ($main.Contains('SetStatus("Tentativa falhou. Pode tentar novamente.")'))
Check "duplicate active video helper" ($main.Contains('BlockDuplicateActiveVideoOpen'))
Check "normal open duplicate guard" ($main.Contains('BlockDuplicateActiveVideoOpen(tab, "Abrir PiP")'))
Check "focusless duplicate guard" ($main.Contains('BlockDuplicateActiveVideoOpen(tab, "Abrir sem foco")'))
Check "silent duplicate guard" ($main.Contains('BlockDuplicateActiveVideoOpen(tab, "Silencioso")'))
Check "duplicate message identifies slot" ($main.Contains('Esse vídeo já está aberto em PiP no slot'))
Check "checker included in core gate" ($run.Contains('CHECK_FOCUSLESS_LOCK_DUPLICATE_VIDEO.ps1'))
if ($failed -gt 0) { throw "Focusless lock and duplicate video checks failed." }
Write-Host "Focusless lock and duplicate video checks OK."
