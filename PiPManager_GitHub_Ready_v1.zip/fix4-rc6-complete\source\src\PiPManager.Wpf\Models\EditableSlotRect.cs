﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace PiPManager.Wpf.Models;

public sealed class EditableSlotRect : INotifyPropertyChanged
{
    private double _left;
    private double _top;
    private double _width;
    private double _height;
    private PipSlotState _state = PipSlotState.Free;
    private bool _isAutoReturnEnabled;
    private double _sourceAspectRatio = 16.0 / 9.0;
    private double _previewWidth = 68;
    private double _previewHeight = 38;
    private bool _isPortraitAppearance;

    public int Number { get; }

    public PipSlotState State
    {
        get => _state;
        set
        {
            if (_state == value) return;
            _state = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(IsOccupied));
            OnPropertyChanged(nameof(IsLinkedOrOccupied));
            OnPropertyChanged(nameof(StatusText));
            OnPropertyChanged(nameof(DetailText));
            OnPropertyChanged(nameof(AppearanceToolTip));
        }
    }

    public bool IsOccupied => State is PipSlotState.Active or PipSlotState.Hidden;
    public bool IsLinkedOrOccupied => State is not PipSlotState.Free;

    public bool IsAutoReturnEnabled
    {
        get => _isAutoReturnEnabled;
        set
        {
            if (_isAutoReturnEnabled == value) return;
            _isAutoReturnEnabled = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(AutoReturnVisualText));
        }
    }

    public string AutoReturnVisualText => IsAutoReturnEnabled ? "Auto-retorno ON" : "Auto-retorno OFF";

    public double SourceAspectRatio => _sourceAspectRatio;
    public double PreviewWidth => _previewWidth;
    public double PreviewHeight => _previewHeight;
    public bool IsPortraitAppearance => _isPortraitAppearance;
    public string AspectText => IsPortraitAppearance ? "Vertical" : "Normal";
    public string AppearanceToolTip => $"Slot {Number} — {StatusText}\nFormato visual: {AspectText} ({SourceAspectRatio:0.00}:1)";

    public string StatusText => State switch
    {
        PipSlotState.Active => "Ativo",
        PipSlotState.Hidden => "Oculto",
        PipSlotState.Offline => "Reservado",
        PipSlotState.AwaitingPip => "Preparado",
        _ => "Livre"
    };

    public string DetailText => State switch
    {
        PipSlotState.Active => $"PiP • {AspectText}",
        PipSlotState.Hidden => $"Oculto • {AspectText}",
        PipSlotState.Offline => $"Retorno • {AspectText}",
        PipSlotState.AwaitingPip => $"Abrindo • {AspectText}",
        _ => ""
    };

    public double Left { get => _left; set { if (Math.Abs(_left - value) < 0.01) return; _left = value; OnPropertyChanged(); } }
    public double Top { get => _top; set { if (Math.Abs(_top - value) < 0.01) return; _top = value; OnPropertyChanged(); } }
    public double Width { get => _width; set { if (Math.Abs(_width - value) < 0.01) return; _width = value; OnPropertyChanged(); } }
    public double Height { get => _height; set { if (Math.Abs(_height - value) < 0.01) return; _height = value; OnPropertyChanged(); } }

    public EditableSlotRect(int number, double left, double top, double width, double height)
    {
        Number = number;
        _left = left;
        _top = top;
        _width = width;
        _height = height;
    }

    public bool UpdatePreviewAspect(double aspectRatio)
    {
        if (double.IsNaN(aspectRatio) || double.IsInfinity(aspectRatio) || aspectRatio <= 0.05)
            aspectRatio = 16.0 / 9.0;

        aspectRatio = Math.Clamp(aspectRatio, 0.35, 3.0);
        var portrait = aspectRatio < 0.90;
        const double maxWidth = 68;
        const double maxHeight = 48;
        const double minDimension = 24;

        double previewWidth;
        double previewHeight;
        if (aspectRatio >= maxWidth / maxHeight)
        {
            previewWidth = maxWidth;
            previewHeight = Math.Max(minDimension, maxWidth / aspectRatio);
        }
        else
        {
            previewHeight = maxHeight;
            previewWidth = Math.Max(minDimension, maxHeight * aspectRatio);
        }

        var changed = Math.Abs(_sourceAspectRatio - aspectRatio) >= 0.02
            || Math.Abs(_previewWidth - previewWidth) >= 0.5
            || Math.Abs(_previewHeight - previewHeight) >= 0.5
            || _isPortraitAppearance != portrait;
        if (!changed)
            return false;

        _sourceAspectRatio = aspectRatio;
        _previewWidth = previewWidth;
        _previewHeight = previewHeight;
        _isPortraitAppearance = portrait;
        OnPropertyChanged(nameof(SourceAspectRatio));
        OnPropertyChanged(nameof(PreviewWidth));
        OnPropertyChanged(nameof(PreviewHeight));
        OnPropertyChanged(nameof(IsPortraitAppearance));
        OnPropertyChanged(nameof(AspectText));
        OnPropertyChanged(nameof(DetailText));
        OnPropertyChanged(nameof(AppearanceToolTip));
        return true;
    }

    public event PropertyChangedEventHandler? PropertyChanged;
    private void OnPropertyChanged([CallerMemberName] string? propertyName = null) =>
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
}
