﻿using PiPManager.Core.Automation;
using PiPManager.Core.Mapping;
using PiPManager.Core.Slots;

static void AssertTrue(bool condition, string message)
{
    if (!condition)
        throw new Exception("TEST FAILED: " + message);
}

static void TestAutoAdvanceSafetyPolicy()
{
    AssertTrue(!AutoAdvanceSafetyPolicy.ShouldArmLostPipWatch(navigationInProgress: true), "manual next/previous must suppress loss watch");
    AssertTrue(!AutoAdvanceSafetyPolicy.ShouldAcceptPlaybackTerminal(navigationInProgress: true), "terminal arriving during navigation must be ignored");
    AssertTrue(!AutoAdvanceSafetyPolicy.IsProvenTerminalSnapshot(isEnded: false, isPlaying: true, readyState: 4, hasSource: true), "playing ready video must not be terminal");
    AssertTrue(!AutoAdvanceSafetyPolicy.IsProvenTerminalSnapshot(isEnded: false, isPlaying: false, readyState: 0, hasSource: false), "loading source gap must not be terminal");
    AssertTrue(AutoAdvanceSafetyPolicy.IsProvenTerminalSnapshot(isEnded: true, isPlaying: false, readyState: 4, hasSource: true), "ended event must remain a proven terminal");
}

static void TestAutoReturnBurstPolicy()
{
    AssertTrue(
        AutoReturnBurstPolicy.ShouldPreserveLostSlot(autoReturnEnabled: true, hasPairRecoverySignal: true),
        "linked AutoReturn slot must remain reserved before debounce admission");
    AssertTrue(
        !AutoReturnBurstPolicy.ShouldPreserveLostSlot(autoReturnEnabled: false, hasPairRecoverySignal: true),
        "disabled AutoReturn slot must not be reserved by the automatic policy");
    AssertTrue(
        !AutoReturnBurstPolicy.ShouldPreserveLostSlot(autoReturnEnabled: true, hasPairRecoverySignal: false),
        "unlinked slot must not be retained indefinitely");

    var singleMaxAge = AutoReturnBurstPolicy.GetPendingMaxAgeSeconds(1, 45);
    var tenSlotMaxAge = AutoReturnBurstPolicy.GetPendingMaxAgeSeconds(10, 45);
    AssertTrue(singleMaxAge == 45, "single recovery must retain the original max age");
    AssertTrue(tenSlotMaxAge >= 120, "ten-slot burst must have enough queue lifetime");

    var singleLayoutTimeout = AutoReturnBurstPolicy.GetLayoutRecoveryTimeoutMilliseconds(1, 45_000);
    var tenSlotLayoutTimeout = AutoReturnBurstPolicy.GetLayoutRecoveryTimeoutMilliseconds(10, 45_000);
    AssertTrue(singleLayoutTimeout == 45_000, "single layout recovery must retain the original timeout");
    AssertTrue(tenSlotLayoutTimeout == 45_000, "layout recovery timeout must remain an absolute 45 seconds for any burst");

    var expectedRecoverySlots = new HashSet<int> { 1, 2, 6, 9 };
    var recoveredRecoverySlots = new HashSet<int> { 1, 2, 9 };
    AutoReturnBurstPolicy.RemapSlotMembershipAfterSwap(
        expectedRecoverySlots,
        recoveredRecoverySlots,
        firstSlotNumber: 9,
        secondSlotNumber: 5);
    AssertTrue(
        expectedRecoverySlots.SetEquals(new[] { 1, 2, 5, 6 }),
        "slot swap must remap the expected fixed-layout recovery membership");
    AssertTrue(
        recoveredRecoverySlots.SetEquals(new[] { 1, 2, 5 }),
        "slot swap must remap the recovered fixed-layout membership");

    AssertTrue(AutoReturnBurstPolicy.GetRetryDelayMilliseconds(1) == 500, "first retry must wait 500 ms");
    AssertTrue(AutoReturnBurstPolicy.GetRetryDelayMilliseconds(2) == 1_000, "second retry must wait 1000 ms");
    AssertTrue(AutoReturnBurstPolicy.GetRetryDelayMilliseconds(3) == 2_000, "third retry must wait 2000 ms");
    AssertTrue(AutoReturnBurstPolicy.GetRetryDelayMilliseconds(10) == 2_000, "retry backoff must remain capped at 2000 ms");

    AssertTrue(
        !AutoReturnBurstPolicy.ShouldAllowPlaylistSameVideoFallback(true, true, 2_199, 2_200, true, false),
        "playlist navigation must retain a bounded real-change grace period");
    AssertTrue(
        AutoReturnBurstPolicy.ShouldAllowPlaylistSameVideoFallback(true, true, 2_200, 2_200, true, false),
        "explicitly rejected playlist navigation may reopen the current player after the grace period");
    AssertTrue(
        !AutoReturnBurstPolicy.ShouldAllowPlaylistSameVideoFallback(true, false, 10_000, 2_200, true, false),
        "non-playlist navigation must not use the playlist fallback");
    AssertTrue(
        !AutoReturnBurstPolicy.ShouldAllowPlaylistSameVideoFallback(true, true, 10_000, 2_200, false, false),
        "navigation without an authoritative command result must wait for a real video change");
    AssertTrue(
        !AutoReturnBurstPolicy.ShouldAllowPlaylistSameVideoFallback(true, true, 10_000, 2_200, true, true),
        "confirmed navigation must never reopen the old playlist video");

    AssertTrue(
        AutoReturnBurstPolicy.IsPlaybackHardNotReady(hasSource: true, readyState: 0, isEnded: false),
        "HAVE_NOTHING must block a physical AutoReturn shortcut");
    AssertTrue(
        AutoReturnBurstPolicy.IsPlaybackHardNotReady(hasSource: false, readyState: 4, isEnded: false),
        "missing source must block a physical AutoReturn shortcut");
    AssertTrue(
        !AutoReturnBurstPolicy.IsPlaybackHardNotReady(hasSource: true, readyState: 1, isEnded: false),
        "loaded metadata must leave the bounded fallback available");
    AssertTrue(
        AutoReturnBurstPolicy.ShouldDeferPhysicalAttemptForReadiness(
            ready: false, hardNotReady: true, readinessDeferrals: 50, maxReadinessDeferrals: 2),
        "hard-not-ready targets must keep deferring without consuming physical attempts");
    AssertTrue(
        !AutoReturnBurstPolicy.ShouldDeferPhysicalAttemptForReadiness(
            ready: false, hardNotReady: false, readinessDeferrals: 2, maxReadinessDeferrals: 2),
        "soft readiness may use the existing bounded physical fallback");
    AssertTrue(
        AutoReturnBurstPolicy.GetReadinessRetryDelayMilliseconds(hardNotReady: true) == 900,
        "hard-not-ready retry must avoid a tight polling loop");

    AssertTrue(
        AutoReturnBurstPolicy.ShouldRequireRealVideoChangeForNavigation(
            commandResultReceived: true,
            commandConfirmed: true,
            newVideoDetected: false,
            commandAgeMilliseconds: 6_957,
            correlationMilliseconds: 2_200),
        "confirmed navigation must remain authoritative after the short loss-correlation window");
    AssertTrue(
        !AutoReturnBurstPolicy.ShouldRequireRealVideoChangeForNavigation(
            commandResultReceived: true,
            commandConfirmed: false,
            newVideoDetected: false,
            commandAgeMilliseconds: 100,
            correlationMilliseconds: 2_200),
        "authoritatively rejected navigation must not require a new video");
    AssertTrue(
        AutoReturnBurstPolicy.ShouldRequireRealVideoChangeForNavigation(
            commandResultReceived: false,
            commandConfirmed: false,
            newVideoDetected: false,
            commandAgeMilliseconds: 2_199,
            correlationMilliseconds: 2_200),
        "unanswered navigation may use the bounded loss-correlation race guard");
    AssertTrue(
        !AutoReturnBurstPolicy.ShouldRequireRealVideoChangeForNavigation(
            commandResultReceived: false,
            commandConfirmed: false,
            newVideoDetected: false,
            commandAgeMilliseconds: 2_201,
            correlationMilliseconds: 2_200),
        "stale unanswered navigation must not be correlated indefinitely");
    AssertTrue(
        AutoReturnBurstPolicy.HasConfirmedActivePlayback(
            hasSource: true,
            isPlaying: true,
            isEnded: false,
            consecutiveFreshSamples: 2,
            requiredFreshSamples: 2),
        "two fresh playing/source samples must prove active playback despite site readiness quirks");
    AssertTrue(
        !AutoReturnBurstPolicy.HasConfirmedActivePlayback(
            hasSource: true,
            isPlaying: true,
            isEnded: false,
            consecutiveFreshSamples: 1,
            requiredFreshSamples: 2),
        "one active sample must not bypass readiness");
    AssertTrue(
        !AutoReturnBurstPolicy.HasConfirmedActivePlayback(
            hasSource: false,
            isPlaying: true,
            isEnded: false,
            consecutiveFreshSamples: 2,
            requiredFreshSamples: 2),
        "playing without a source must remain blocked");
}

static void TestStaleReconnectDoesNotReactivateResetSlot()
{
    var engine = new AutomationEngine();

    var open = engine.Apply(new UserOpenPipRequested(1, 10, "a1"));
    AssertTrue(open.Slot.State == SlotState.Opening, "slot should be Opening");

    var cap = engine.Apply(new PipWindowCaptured(1, new IntPtr(123), "a1"));
    AssertTrue(cap.Slot.State == SlotState.Active, "slot should be Active after capture");

    var reset = engine.Apply(new SlotResetRequested(1, "reset1"));
    AssertTrue(reset.Slot.State == SlotState.Empty, "slot should be reset to Empty");

    var stale = engine.Apply(new ReconnectSucceeded(1, new IntPtr(456), "a1"));
    AssertTrue(stale.Slot.State == SlotState.Empty, "stale reconnect must not reactivate reset slot");
}

static void TestPipWindowLostRequiresMatchingHwnd()
{
    var engine = new AutomationEngine();

    engine.InitializeSlot(
        slotNumber: 1,
        state: SlotState.Active,
        autoReturnEnabled: true,
        pipHwnd: new IntPtr(123),
        attemptId: "active1");

    var wrong = engine.Apply(new PipWindowLost(1, new IntPtr(999), "lost1"));
    AssertTrue(wrong.Slot.State == SlotState.Active, "wrong HWND must not affect active slot");
    AssertTrue(wrong.Slot.PipHwnd == new IntPtr(123), "wrong HWND must not clear current HWND");
}

static void TestPipWindowLostWithoutCurrentHwndIsIgnored()
{
    var engine = new AutomationEngine();
    var lost = engine.Apply(new PipWindowLost(1, new IntPtr(123), "lost-empty"));
    AssertTrue(lost.Slot.State == SlotState.Empty, "PipWindowLost must be ignored when slot has no current HWND");
}

static void TestReconnectSucceededRequiresReconnectingAndNewValidHwnd()
{
    var engine = new AutomationEngine();

    engine.Apply(new UserOpenPipRequested(1, 10, "a1"));

    var openingSuccess = engine.Apply(new ReconnectSucceeded(1, new IntPtr(123), "a1"));
    AssertTrue(openingSuccess.Slot.State == SlotState.Opening, "ReconnectSucceeded must be ignored outside Reconnecting");

    engine.InitializeSlot(
        slotNumber: 1,
        state: SlotState.Active,
        autoReturnEnabled: true,
        pipHwnd: new IntPtr(123),
        attemptId: "active1");

    var waiting = engine.Apply(new VideoChanged(1, "v2", "key2", "r1"));
    AssertTrue(waiting.Slot.State == SlotState.WaitingForReconnect, "VideoChanged with AutoReturn should wait for reconnect");

    var started = engine.Apply(new ReconnectStarted(1, "r1"));
    AssertTrue(started.Slot.State == SlotState.Reconnecting, "ReconnectStarted should enter Reconnecting");

    var noHwnd = engine.Apply(new ReconnectSucceeded(1, null, "r1"));
    AssertTrue(noHwnd.Slot.State == SlotState.Reconnecting, "ReconnectSucceeded without event HWND must not produce Active");

    var zeroHwnd = engine.Apply(new ReconnectSucceeded(1, IntPtr.Zero, "r1"));
    AssertTrue(zeroHwnd.Slot.State == SlotState.Reconnecting, "ReconnectSucceeded with zero HWND must not produce Active");

    var ok = engine.Apply(new ReconnectSucceeded(1, new IntPtr(456), "r1"));
    AssertTrue(ok.Slot.State == SlotState.Active, "ReconnectSucceeded with new HWND should produce Active");
    AssertTrue(ok.Slot.PipHwnd == new IntPtr(456), "ReconnectSucceeded must store the new HWND from the event");
}

static void TestReconnectRetryQueuedRestoresWaitingBeforeReconnect()
{
    var engine = new AutomationEngine();
    engine.InitializeSlot(
        slotNumber: 1,
        state: SlotState.Failed,
        autoReturnEnabled: true,
        pipHwnd: null,
        attemptId: "failed-attempt");

    var queued = engine.Apply(new ReconnectRetryQueued(1, "retry-attempt"));
    AssertTrue(queued.Slot.State == SlotState.WaitingForReconnect, "retry from Failed must return to WaitingForReconnect first");
    AssertTrue(queued.Slot.AttemptId == "retry-attempt", "retry queue must establish the new attempt identity");

    var started = engine.Apply(new ReconnectStarted(1, "retry-attempt"));
    AssertTrue(started.Slot.State == SlotState.Reconnecting, "retry must enter Reconnecting only after WaitingForReconnect");
}

static async Task TestSchedulerReplacementDoesNotRemoveNewSchedule()
{
    var scheduler = new AutomationScheduler();
    var ran = 0;

    scheduler.Schedule("slot:1", TimeSpan.FromMilliseconds(100), _ =>
    {
        Interlocked.Increment(ref ran);
        return Task.CompletedTask;
    });

    scheduler.Schedule("slot:1", TimeSpan.FromMilliseconds(250), _ =>
    {
        Interlocked.Increment(ref ran);
        return Task.CompletedTask;
    });

    await Task.Delay(150);
    AssertTrue(scheduler.IsScheduled("slot:1"), "old schedule finally must not remove replacement schedule");

    await Task.Delay(200);
    AssertTrue(ran == 1, "only replacement schedule should run");
}

static async Task TestSchedulerConcurrentScheduleRunsOnlyOneCallback()
{
    var scheduler = new AutomationScheduler();
    var ran = 0;
    var tasks = Enumerable.Range(0, 64)
        .Select(i => Task.Run(() =>
        {
            scheduler.Schedule("same-key", TimeSpan.FromMilliseconds(80), _ =>
            {
                Interlocked.Increment(ref ran);
                return Task.CompletedTask;
            });
        }))
        .ToArray();

    await Task.WhenAll(tasks);
    await Task.Delay(250);

    AssertTrue(ran == 1, $"concurrent Schedule calls for same key must run only one callback; ran={ran}");
}

static async Task TestSchedulerReportsCallbackFailure()
{
    var scheduler = new AutomationScheduler();
    var captured = false;

    scheduler.CallbackFailed += (_, _) => captured = true;
    scheduler.Schedule("fail", TimeSpan.FromMilliseconds(10), _ => throw new InvalidOperationException("expected"));

    await Task.Delay(100);
    AssertTrue(captured, "scheduler must expose callback failures");
}

static void TestHiddenLegacyMapsToActiveHidden()
{
    var snapshot = SlotSnapshotMapper.FromLegacy(
        slotNumber: 1,
        legacyStateName: "Hidden",
        autoReturnEnabled: true,
        isLocked: false,
        pipHwnd: new IntPtr(123));

    AssertTrue(snapshot.State == SlotState.Active, "legacy Hidden must map to Active state");
    AssertTrue(snapshot.IsHidden, "legacy Hidden must set IsHidden property");
}

static void TestEngineCanImportLegacySnapshot()
{
    var engine = new AutomationEngine();
    var snapshot = SlotSnapshotMapper.FromLegacy(
        slotNumber: 2,
        legacyStateName: "Hidden",
        autoReturnEnabled: true,
        isLocked: true,
        pipHwnd: new IntPtr(222),
        attemptId: "legacy");

    var imported = engine.ImportSnapshot(snapshot);

    AssertTrue(imported.SlotNumber == 2, "imported slot number should match");
    AssertTrue(imported.State == SlotState.Active, "imported Hidden should remain Active");
    AssertTrue(imported.IsHidden, "imported Hidden should preserve IsHidden");
    AssertTrue(imported.AutoReturnEnabled, "imported AutoReturnEnabled should be preserved");
    AssertTrue(engine.GetSlot(2).PipHwnd == new IntPtr(222), "engine should store imported HWND");
}


static void TestImportSnapshotDoesNotOverwriteNewerState()
{
    var engine = new AutomationEngine();

    var newer = new SlotSnapshot
    {
        SlotNumber = 1,
        State = SlotState.Active,
        AutoReturnEnabled = true,
        PipHwnd = new IntPtr(200),
        AttemptId = "new",
        UpdatedAt = DateTimeOffset.UtcNow.AddSeconds(10)
    };

    var older = new SlotSnapshot
    {
        SlotNumber = 1,
        State = SlotState.Active,
        AutoReturnEnabled = true,
        PipHwnd = new IntPtr(100),
        AttemptId = "old",
        UpdatedAt = DateTimeOffset.UtcNow
    };

    engine.ImportSnapshot(newer);
    var result = engine.ImportSnapshot(older);

    AssertTrue(result.PipHwnd == new IntPtr(200), "older import must not overwrite newer state");
    AssertTrue(engine.GetSlot(1).AttemptId == "new", "older import must preserve newer AttemptId");
}

static void TestImportSnapshotRejectsImpossibleStates()
{
    var engine = new AutomationEngine();

    AssertThrows(() => engine.ImportSnapshot(new SlotSnapshot
    {
        SlotNumber = 1,
        State = SlotState.Active,
        PipHwnd = null,
        UpdatedAt = DateTimeOffset.UtcNow
    }), "Active without HWND must be rejected");

    AssertThrows(() => engine.ImportSnapshot(new SlotSnapshot
    {
        SlotNumber = 1,
        State = SlotState.Empty,
        PipHwnd = new IntPtr(123),
        UpdatedAt = DateTimeOffset.UtcNow
    }), "Empty with HWND must be rejected");

    AssertThrows(() => engine.ImportSnapshot(new SlotSnapshot
    {
        SlotNumber = 1,
        State = SlotState.Reconnecting,
        PipHwnd = null,
        AttemptId = null,
        UpdatedAt = DateTimeOffset.UtcNow
    }), "Reconnecting without AttemptId must be rejected");

    AssertThrows(() => engine.ImportSnapshot(new SlotSnapshot
    {
        SlotNumber = 1,
        State = SlotState.WaitingForReconnect,
        IsHidden = true,
        AttemptId = "r1",
        UpdatedAt = DateTimeOffset.UtcNow
    }), "Hidden non-Active state must be rejected");
}

static void TestMapperDoesNotTreatZeroHwndAsActive()
{
    var snapshot = SlotSnapshotMapper.FromLegacy(
        slotNumber: 1,
        legacyStateName: "UnknownState",
        autoReturnEnabled: true,
        isLocked: false,
        pipHwnd: IntPtr.Zero);

    AssertTrue(snapshot.State == SlotState.Empty, "unknown legacy state with IntPtr.Zero must map to Empty");
    AssertTrue(!snapshot.IsHidden, "zero HWND should not be hidden active");
}

static void TestVideoChangedIgnoredOutsideActive()
{
    var engine = new AutomationEngine();

    engine.InitializeSlot(
        slotNumber: 1,
        state: SlotState.Empty,
        autoReturnEnabled: true);

    var decision = engine.Apply(new VideoChanged(1, "v1", "key1", "r1"));

    AssertTrue(decision.Slot.State == SlotState.Empty, "VideoChanged must be ignored outside Active");
    AssertTrue(decision.Actions.OfType<StartReconnectAction>().Count() == 0, "VideoChanged outside Active must not create reconnect action");
}

static void AssertThrows(Action action, string message)
{
    try
    {
        action();
    }
    catch
    {
        return;
    }

    throw new Exception("TEST FAILED: " + message);
}


static void TestOpenPipRequiresAttemptId()
{
    var engine = new AutomationEngine();
    var decision = engine.Apply(new UserOpenPipRequested(1, 10, ""));
    AssertTrue(decision.Slot.State == SlotState.Empty, "UserOpenPipRequested without AttemptId must be ignored");
}

static void TestPipWindowCapturedRejectsZeroHwnd()
{
    var engine = new AutomationEngine();
    engine.Apply(new UserOpenPipRequested(1, 10, "a1"));

    var decision = engine.Apply(new PipWindowCaptured(1, IntPtr.Zero, "a1"));

    AssertTrue(decision.Slot.State == SlotState.Opening, "PipWindowCaptured with zero HWND must not produce Active");
    AssertTrue(decision.Slot.PipHwnd is null, "PipWindowCaptured with zero HWND must not store HWND");
}

static void TestImportSnapshotEqualTimestampDoesNotOverwrite()
{
    var engine = new AutomationEngine();
    var timestamp = DateTimeOffset.UtcNow;

    var first = new SlotSnapshot
    {
        SlotNumber = 1,
        State = SlotState.Active,
        AutoReturnEnabled = true,
        PipHwnd = new IntPtr(111),
        AttemptId = "first",
        UpdatedAt = timestamp
    };

    var second = first with
    {
        PipHwnd = new IntPtr(222),
        AttemptId = "second",
        UpdatedAt = timestamp
    };

    engine.ImportSnapshot(first);
    var result = engine.ImportSnapshot(second);

    AssertTrue(result.PipHwnd == new IntPtr(111), "equal timestamp import must not overwrite current state");
    AssertTrue(engine.GetSlot(1).AttemptId == "first", "equal timestamp import must preserve current attempt");
}



static void TestResetEmptySlotIsAppliedWithoutStateChange()
{
    var mirror = new PiPManager.Core.Shadow.ShadowModeEventMirror();

    var result = mirror.Mirror(new SlotResetRequested(1, "reset-empty"));

    AssertTrue(result.Processed, "reset over empty slot should be processed");
    AssertTrue(result.Accepted, "reset over empty slot should be applied");
    AssertTrue(!result.StateChanged, "reset Empty -> Empty must not report StateChanged=true");
    AssertTrue(result.Transition?.Applied == true, "reset Empty -> Empty transition should be Applied");
    AssertTrue(result.Transition?.Changed == false, "reset Empty -> Empty transition should not be Changed");
}










static void TestShadowExternalCaptureLossWithoutLinkResetsToEmpty()
{
    var mirror = new PiPManager.Core.Shadow.ShadowModeEventMirror();
    var hwnd = new IntPtr(2000);

    var external = mirror.Mirror(new ExternalPipCaptured(4, hwnd, "external-unlinked"));
    AssertTrue(external.Accepted, "external capture should be accepted");
    AssertTrue(external.Slot?.State == SlotState.Active, "external capture should become Active");

    var reset = mirror.Mirror(new SlotResetRequested(4, "external-loss-without-link"));
    AssertTrue(reset.Accepted, "external unlinked loss should map to reset");
    AssertTrue(reset.Slot?.State == SlotState.Empty, "external unlinked loss should end as Empty");
}

static void TestShadowPreservedSameHwndReturnsWaitingToActive()
{
    var mirror = new PiPManager.Core.Shadow.ShadowModeEventMirror();
    var hwnd = new IntPtr(1900);
    var attemptId = "same-hwnd-cycle";

    mirror.ImportSnapshot(new SlotSnapshot
    {
        SlotNumber = 1,
        State = SlotState.Active,
        AutoReturnEnabled = true,
        PipHwnd = hwnd,
        AttemptId = "active",
        UpdatedAt = DateTimeOffset.UtcNow
    });

    var changed = mirror.Mirror(new VideoChanged(1, "new-video", "new-stable", attemptId));
    AssertTrue(changed.Accepted, "VideoChanged should enter WaitingForReconnect");

    var preserved = mirror.Mirror(new PreservedSameHwndConfirmed(1, hwnd, attemptId));
    AssertTrue(preserved.Accepted, "preserved same HWND should be accepted");
    AssertTrue(preserved.Slot?.State == SlotState.Active, "preserved same HWND should return to Active");
}

static void TestShadowPreservedSameHwndRejectsWrongAttempt()
{
    var mirror = new PiPManager.Core.Shadow.ShadowModeEventMirror();
    var hwnd = new IntPtr(1901);

    mirror.ImportSnapshot(new SlotSnapshot
    {
        SlotNumber = 1,
        State = SlotState.Active,
        AutoReturnEnabled = true,
        PipHwnd = hwnd,
        AttemptId = "active",
        UpdatedAt = DateTimeOffset.UtcNow
    });

    mirror.Mirror(new VideoChanged(1, "new-video", "new-stable", "correct-attempt"));

    var preserved = mirror.Mirror(new PreservedSameHwndConfirmed(1, hwnd, "wrong-attempt"));
    AssertTrue(!preserved.Accepted, "wrong attempt must be rejected");
    AssertTrue(preserved.Slot?.State == SlotState.WaitingForReconnect, "wrong attempt must not return to Active");
}

static void TestShadowExternalCaptureFromEmptyBecomesActive()
{
    var mirror = new PiPManager.Core.Shadow.ShadowModeEventMirror();
    var hwnd = new IntPtr(1800);

    var captured = mirror.Mirror(new ExternalPipCaptured(4, hwnd, "external-capture-slot-4"));

    AssertTrue(captured.Accepted, "external capture from Empty should be accepted");
    AssertTrue(captured.StateChanged, "external capture from Empty should change state");
    AssertTrue(captured.Slot?.State == SlotState.Active, "external capture should produce Active");
    AssertTrue(captured.Slot?.PipHwnd == hwnd, "external capture should store HWND");
}

static void TestShadowExternalCaptureDoesNotOverrideOpening()
{
    var mirror = new PiPManager.Core.Shadow.ShadowModeEventMirror();

    var open = mirror.Mirror(new UserOpenPipRequested(4, 10, "manual-opening"));
    AssertTrue(open.Accepted, "manual open should enter Opening");

    var external = mirror.Mirror(new ExternalPipCaptured(4, new IntPtr(1801), "external-during-opening"));
    AssertTrue(external.Processed, "external capture during Opening should be processed");
    AssertTrue(!external.Accepted, "external capture during Opening should be rejected");
    AssertTrue(external.Slot?.State == SlotState.Opening, "external capture must not override Opening");
}

static void TestShadowManualOpenAfterFailedReconnectCanCaptureNormally()
{
    var mirror = new PiPManager.Core.Shadow.ShadowModeEventMirror();
    var oldHwnd = new IntPtr(1600);
    var newHwnd = new IntPtr(1601);

    mirror.ImportSnapshot(new SlotSnapshot
    {
        SlotNumber = 1,
        State = SlotState.Active,
        AutoReturnEnabled = false,
        PipHwnd = oldHwnd,
        AttemptId = "active",
        UpdatedAt = DateTimeOffset.UtcNow
    });

    var lost = mirror.Mirror(new PipWindowLost(1, oldHwnd, "lost-autoreturn-off"));
    AssertTrue(lost.Accepted, "loss with AutoReturn OFF should be accepted");
    AssertTrue(lost.Slot?.State == SlotState.Failed, "loss with AutoReturn OFF should move to Failed");

    var open = mirror.Mirror(new UserOpenPipRequested(1, 10, "manual-open-after-failed"));
    AssertTrue(open.Accepted, "manual open after Failed should be accepted");
    AssertTrue(open.Slot?.State == SlotState.Opening, "manual open should enter Opening");

    var captured = mirror.Mirror(new PipWindowCaptured(1, newHwnd, "manual-open-after-failed"));
    AssertTrue(captured.Accepted, "manual capture after failed reconnect should be accepted");
    AssertTrue(captured.Slot?.State == SlotState.Active, "manual capture should return slot to Active");
}

static void TestShadowManualOpenAttemptMustDominateReconnectAttempt()
{
    var mirror = new PiPManager.Core.Shadow.ShadowModeEventMirror();
    var oldHwnd = new IntPtr(1700);
    var newHwnd = new IntPtr(1701);

    mirror.ImportSnapshot(new SlotSnapshot
    {
        SlotNumber = 1,
        State = SlotState.Active,
        AutoReturnEnabled = true,
        PipHwnd = oldHwnd,
        AttemptId = "active",
        UpdatedAt = DateTimeOffset.UtcNow
    });

    var lost = mirror.Mirror(new PipWindowLost(1, oldHwnd, "old-reconnect"));
    AssertTrue(lost.Accepted, "loss should create WaitingForReconnect");

    var open = mirror.Mirror(new UserOpenPipRequested(1, 10, "manual-dominates"));
    AssertTrue(open.Accepted, "manual open should be accepted after WaitingForReconnect");
    AssertTrue(open.Slot?.State == SlotState.Opening, "manual open should become Opening");

    var wrongReconnectSuccess = mirror.Mirror(new ReconnectSucceeded(1, newHwnd, "old-reconnect"));
    AssertTrue(!wrongReconnectSuccess.Accepted, "old reconnect success must not dominate manual opening");

    var manualCapture = mirror.Mirror(new PipWindowCaptured(1, newHwnd, "manual-dominates"));
    AssertTrue(manualCapture.Accepted, "manual capture should be accepted after manual open");
    AssertTrue(manualCapture.Slot?.State == SlotState.Active, "manual capture should become Active");
}

static void TestShadowReconnectSuccessRequiresStartedOrdering()
{
    var mirror = new PiPManager.Core.Shadow.ShadowModeEventMirror();
    var hwnd = new IntPtr(1400);
    var newHwnd = new IntPtr(1401);
    var attemptId = "terminal-success-order";

    mirror.ImportSnapshot(new SlotSnapshot
    {
        SlotNumber = 1,
        State = SlotState.Active,
        AutoReturnEnabled = true,
        PipHwnd = hwnd,
        AttemptId = "active",
        UpdatedAt = DateTimeOffset.UtcNow
    });

    mirror.Mirror(new PipWindowLost(1, hwnd, attemptId));

    var directSuccess = mirror.Mirror(new ReconnectSucceeded(1, newHwnd, attemptId));
    AssertTrue(!directSuccess.Accepted, "direct ReconnectSucceeded before ReconnectStarted must be rejected");

    var started = mirror.Mirror(new ReconnectStarted(1, attemptId));
    AssertTrue(started.Accepted, "ReconnectStarted should be accepted");

    var success = mirror.Mirror(new ReconnectSucceeded(1, newHwnd, attemptId));
    AssertTrue(success.Accepted, "ReconnectSucceeded after ReconnectStarted should be accepted");
    AssertTrue(success.Slot?.State == SlotState.Active, "success should return to Active");
}

static void TestShadowReconnectFailedRequiresStartedOrdering()
{
    var mirror = new PiPManager.Core.Shadow.ShadowModeEventMirror();
    var hwnd = new IntPtr(1500);
    var attemptId = "terminal-failed-order";

    mirror.ImportSnapshot(new SlotSnapshot
    {
        SlotNumber = 1,
        State = SlotState.Active,
        AutoReturnEnabled = true,
        PipHwnd = hwnd,
        AttemptId = "active",
        UpdatedAt = DateTimeOffset.UtcNow
    });

    mirror.Mirror(new PipWindowLost(1, hwnd, attemptId));

    var directFailed = mirror.Mirror(new ReconnectFailed(1, "expired", attemptId));
    AssertTrue(!directFailed.Accepted, "direct ReconnectFailed before ReconnectStarted must be rejected");

    var started = mirror.Mirror(new ReconnectStarted(1, attemptId));
    AssertTrue(started.Accepted, "ReconnectStarted should be accepted");

    var failed = mirror.Mirror(new ReconnectFailed(1, "expired", attemptId));
    AssertTrue(failed.Accepted, "ReconnectFailed after ReconnectStarted should be accepted");
    AssertTrue(failed.Slot?.State == SlotState.Failed, "failure should move to Failed");
}

static void TestShadowAutoReturnVideoChangedThenReconnectCycle()
{
    var mirror = new PiPManager.Core.Shadow.ShadowModeEventMirror();
    var hwnd = new IntPtr(1300);
    var newHwnd = new IntPtr(1301);
    var attemptId = "video-before-loss-cycle";

    mirror.ImportSnapshot(new SlotSnapshot
    {
        SlotNumber = 1,
        State = SlotState.Active,
        AutoReturnEnabled = true,
        PipHwnd = hwnd,
        AttemptId = "active",
        UpdatedAt = DateTimeOffset.UtcNow
    });

    var videoChanged = mirror.Mirror(new VideoChanged(1, "new-video", "new-stable", attemptId));
    AssertTrue(videoChanged.Accepted, "VideoChanged should be accepted on Active auto-return slot");
    AssertTrue(videoChanged.Slot?.State == SlotState.WaitingForReconnect, "VideoChanged should move to WaitingForReconnect");

    var lost = mirror.Mirror(new PipWindowLost(1, hwnd, attemptId));
    AssertTrue(lost.Processed, "PipWindowLost after VideoChanged should be processed with same attempt");

    var started = mirror.Mirror(new ReconnectStarted(1, attemptId));
    AssertTrue(started.Accepted, "ReconnectStarted should be accepted with same attempt");

    var success = mirror.Mirror(new ReconnectSucceeded(1, newHwnd, attemptId));
    AssertTrue(success.Accepted, "ReconnectSucceeded should be accepted with same attempt");
    AssertTrue(success.Slot?.State == SlotState.Active, "ReconnectSucceeded should return to Active");
}

static void TestShadowAutoReturnReconnectCycleUsesSameAttempt()
{
    var mirror = new PiPManager.Core.Shadow.ShadowModeEventMirror();
    var hwnd = new IntPtr(1000);
    var reconnectHwnd = new IntPtr(1001);
    var attemptId = "reconnect-cycle-1";

    mirror.ImportSnapshot(new SlotSnapshot
    {
        SlotNumber = 1,
        State = SlotState.Active,
        AutoReturnEnabled = true,
        PipHwnd = hwnd,
        AttemptId = "active",
        UpdatedAt = DateTimeOffset.UtcNow
    });

    var lost = mirror.Mirror(new PipWindowLost(1, hwnd, attemptId));
    AssertTrue(lost.Accepted, "PipWindowLost should be accepted");
    AssertTrue(lost.Slot?.State == SlotState.WaitingForReconnect, "loss should wait for reconnect");

    var started = mirror.Mirror(new ReconnectStarted(1, attemptId));
    AssertTrue(started.Accepted, "ReconnectStarted with same attempt should be accepted");
    AssertTrue(started.Slot?.State == SlotState.Reconnecting, "ReconnectStarted should enter Reconnecting");

    var succeeded = mirror.Mirror(new ReconnectSucceeded(1, reconnectHwnd, attemptId));
    AssertTrue(succeeded.Accepted, "ReconnectSucceeded with same attempt should be accepted");
    AssertTrue(succeeded.Slot?.State == SlotState.Active, "ReconnectSucceeded should return to Active");
    AssertTrue(succeeded.Slot?.PipHwnd == reconnectHwnd, "ReconnectSucceeded should store new HWND");
}

static void TestShadowReconnectOldAttemptIsIgnored()
{
    var mirror = new PiPManager.Core.Shadow.ShadowModeEventMirror();
    var hwnd = new IntPtr(1100);

    mirror.ImportSnapshot(new SlotSnapshot
    {
        SlotNumber = 1,
        State = SlotState.Active,
        AutoReturnEnabled = true,
        PipHwnd = hwnd,
        AttemptId = "active",
        UpdatedAt = DateTimeOffset.UtcNow
    });

    mirror.Mirror(new PipWindowLost(1, hwnd, "new-reconnect"));
    var oldStarted = mirror.Mirror(new ReconnectStarted(1, "old-reconnect"));

    AssertTrue(oldStarted.Processed, "old reconnect start should be processed");
    AssertTrue(!oldStarted.Accepted, "old reconnect start must be ignored");
    AssertTrue(!oldStarted.StateChanged, "old reconnect start must not change state");
}

static void TestShadowReconnectFailedUsesSameAttempt()
{
    var mirror = new PiPManager.Core.Shadow.ShadowModeEventMirror();
    var hwnd = new IntPtr(1200);
    var attemptId = "reconnect-fail";

    mirror.ImportSnapshot(new SlotSnapshot
    {
        SlotNumber = 1,
        State = SlotState.Active,
        AutoReturnEnabled = true,
        PipHwnd = hwnd,
        AttemptId = "active",
        UpdatedAt = DateTimeOffset.UtcNow
    });

    mirror.Mirror(new PipWindowLost(1, hwnd, attemptId));
    mirror.Mirror(new ReconnectStarted(1, attemptId));
    var failed = mirror.Mirror(new ReconnectFailed(1, "timeout", attemptId));

    AssertTrue(failed.Accepted, "ReconnectFailed with same attempt should be accepted");
    AssertTrue(failed.Slot?.State == SlotState.Failed, "ReconnectFailed should move to Failed");
}

static void TestShadowExpiredManualAttemptShouldNotValidateLaterExternalCapture()
{
    var mirror = new PiPManager.Core.Shadow.ShadowModeEventMirror();

    var open = mirror.Mirror(new UserOpenPipRequested(1, 10, "expired-attempt"));
    AssertTrue(open.Accepted, "manual open should enter Opening");

    var cleanup = mirror.Mirror(new SlotResetRequested(1, "real-lock-ended-without-capture"));
    AssertTrue(cleanup.Accepted, "cleanup should be accepted");

    var laterCapture = mirror.Mirror(new PipWindowCaptured(1, new IntPtr(900), "expired-attempt"));
    AssertTrue(laterCapture.Processed, "later capture should be processed");
    AssertTrue(!laterCapture.Accepted, "later capture with expired attempt must not be accepted after cleanup");
    AssertTrue(!laterCapture.StateChanged, "later capture after cleanup must not become Active");
}

static void TestShadowManualOpenCaptureContinuityUsesSameAttempt()
{
    var mirror = new PiPManager.Core.Shadow.ShadowModeEventMirror();
    var attemptId = "manual-attempt-1";

    var open = mirror.Mirror(new UserOpenPipRequested(1, 10, attemptId));
    AssertTrue(open.Accepted, "manual open should enter Opening");

    var captured = mirror.Mirror(new PipWindowCaptured(1, new IntPtr(700), attemptId));
    AssertTrue(captured.Accepted, "capture with same AttemptId should be accepted");
    AssertTrue(captured.StateChanged, "capture should move Opening -> Active");
    AssertTrue(captured.Slot?.State == SlotState.Active, "capture should result in Active");
}

static void TestShadowManualOpenCaptureDifferentAttemptIsRejected()
{
    var mirror = new PiPManager.Core.Shadow.ShadowModeEventMirror();

    var open = mirror.Mirror(new UserOpenPipRequested(1, 10, "manual-attempt-1"));
    AssertTrue(open.Accepted, "manual open should enter Opening");

    var captured = mirror.Mirror(new PipWindowCaptured(1, new IntPtr(700), "manual-attempt-2"));
    AssertTrue(captured.Processed, "different attempt capture should still be processed");
    AssertTrue(!captured.Accepted, "capture with different AttemptId must be rejected");
    AssertTrue(!captured.StateChanged, "capture with different AttemptId must not change state");
}

static void TestShadowCaptureWithoutExpectedOpeningIsRejected()
{
    var mirror = new PiPManager.Core.Shadow.ShadowModeEventMirror();

    mirror.ImportSnapshot(new SlotSnapshot
    {
        SlotNumber = 1,
        State = SlotState.Active,
        AutoReturnEnabled = true,
        PipHwnd = new IntPtr(100),
        AttemptId = "active",
        UpdatedAt = DateTimeOffset.UtcNow
    });

    var result = mirror.Mirror(new PipWindowCaptured(1, new IntPtr(200), "unexpected-capture"));

    AssertTrue(result.Processed, "unexpected capture should be processed");
    AssertTrue(!result.Accepted, "capture outside Opening/Reconnecting must be rejected");
    AssertTrue(!result.StateChanged, "unexpected capture must not change state");
    AssertTrue(!result.Executed, "Shadow Mode must not execute actions");
}

static void TestShadowLossHiddenSnapshotCanBeNormalized()
{
    var mirror = new PiPManager.Core.Shadow.ShadowModeEventMirror();
    var hwnd = new IntPtr(500);

    mirror.ImportSnapshot(new SlotSnapshot
    {
        SlotNumber = 1,
        State = SlotState.Active,
        AutoReturnEnabled = true,
        IsHidden = false,
        PipHwnd = hwnd,
        AttemptId = "active",
        UpdatedAt = DateTimeOffset.UtcNow
    });

    var result = mirror.Mirror(new PipWindowLost(1, hwnd, "lost-hidden-normalized"));

    AssertTrue(result.Accepted, "loss over normalized active snapshot should be accepted");
    AssertTrue(result.Slot?.IsHidden == false, "loss transition result must not keep hidden flag");
}

static void TestShadowHookStyleCaptureAndLossSequence()
{
    var mirror = new PiPManager.Core.Shadow.ShadowModeEventMirror();
    var hwnd = new IntPtr(321);
    var attemptId = "hook-capture";

    mirror.ImportSnapshot(new SlotSnapshot
    {
        SlotNumber = 1,
        State = SlotState.Opening,
        AutoReturnEnabled = true,
        AttemptId = attemptId,
        UpdatedAt = DateTimeOffset.UtcNow
    });

    var captured = mirror.Mirror(new PipWindowCaptured(1, hwnd, attemptId));
    AssertTrue(captured.Accepted, "hook-style capture should be accepted");
    AssertTrue(captured.StateChanged, "hook-style capture should change state to Active");

    var lost = mirror.Mirror(new PipWindowLost(1, hwnd, "hook-lost"));
    AssertTrue(lost.Accepted, "hook-style loss should be accepted");
    AssertTrue(lost.StateChanged, "hook-style loss should move to WaitingForReconnect or Failed");
    AssertTrue(!lost.Executed, "Shadow hook sequence must not execute actions");
}

static void TestShadowModeDoesNotExecuteActions()
{
    var mirror = new PiPManager.Core.Shadow.ShadowModeEventMirror();

    var result = mirror.Mirror(new UserOpenPipRequested(1, 10, "shadow-open"));

    AssertTrue(result.Accepted, "Shadow Mode should accept valid event");
    AssertTrue(!result.Executed, "Shadow Mode must not execute actions");
    AssertTrue(result.PredictedActions.OfType<OpenNativePipAction>().Any(), "Shadow Mode should predict OpenNativePipAction");
}



static void TestShadowModeVideoChangedAutoReturnOffIsAcceptedWithoutStateChange()
{
    var mirror = new PiPManager.Core.Shadow.ShadowModeEventMirror();

    mirror.ImportSnapshot(new SlotSnapshot
    {
        SlotNumber = 1,
        State = SlotState.Active,
        AutoReturnEnabled = false,
        PipHwnd = new IntPtr(123),
        AttemptId = "active",
        VideoSessionId = "old",
        StableVideoKey = "old-key",
        UpdatedAt = DateTimeOffset.UtcNow
    });

    var result = mirror.Mirror(new VideoChanged(1, "new-video", "new-key", "vc1"));

    AssertTrue(result.Processed, "VideoChanged should be processed");
    AssertTrue(result.Accepted, "VideoChanged with AutoReturn OFF should be accepted because it updates metadata");
    AssertTrue(!result.StateChanged, "VideoChanged with AutoReturn OFF should not change the main state");
    AssertTrue(!result.Executed, "Shadow Mode must not execute actions");
    AssertTrue(result.IgnoredReason is null, "accepted metadata update must not expose IgnoredReason");
    AssertTrue(result.PredictedActions.Count == 0, "metadata-only accepted event should not expose predicted actions");
    AssertTrue(result.Slot?.VideoSessionId == "new-video", "VideoChanged should update VideoSessionId");
    AssertTrue(result.Slot?.StableVideoKey == "new-key", "VideoChanged should update StableVideoKey");
}

static void TestShadowModeMarksNoChangeAsIgnored()
{
    var mirror = new PiPManager.Core.Shadow.ShadowModeEventMirror();

    var first = mirror.Mirror(new UserOpenPipRequested(1, 10, "open-1"));
    AssertTrue(first.Accepted, "first open should be accepted because it changes state");
    AssertTrue(first.Processed, "first open should be processed");
    AssertTrue(first.StateChanged, "first open should change state");

    var second = mirror.Mirror(new UserOpenPipRequested(1, 10, "open-2"));
    AssertTrue(second.Processed, "second open should still be processed by the engine");
    AssertTrue(!second.Accepted, "second open while Opening must be marked as not accepted");
    AssertTrue(!second.StateChanged, "second open while Opening must not change state");
    AssertTrue(!second.Executed, "second open must not execute actions");
    AssertTrue(!string.IsNullOrWhiteSpace(second.IgnoredReason), "ignored NoChange event must expose IgnoredReason");
    AssertTrue(second.PredictedActions.Count == 0, "ignored NoChange event must not expose predicted actions");
}

static void TestShadowModeHistoryLimit()
{
    var mirror = new PiPManager.Core.Shadow.ShadowModeEventMirror(
        new AutomationEngine(),
        new PiPManager.Core.Shadow.ShadowModeOptions
        {
            Enabled = true,
            ExecuteActions = false,
            CaptureDecisions = true,
            MaxHistory = 3
        });

    mirror.Mirror(new UserOpenPipRequested(1, 10, "a1"));
    mirror.Mirror(new UserOpenPipRequested(2, 11, "a2"));
    mirror.Mirror(new UserOpenPipRequested(3, 12, "a3"));
    mirror.Mirror(new UserOpenPipRequested(4, 13, "a4"));

    AssertTrue(mirror.History.Count == 3, "Shadow Mode history should respect MaxHistory");
    AssertTrue(mirror.History.First().Sequence == 2, "Shadow Mode should discard oldest entries");
}

static void TestShadowModeDisabledIgnoresEvents()
{
    var mirror = new PiPManager.Core.Shadow.ShadowModeEventMirror(
        new AutomationEngine(),
        new PiPManager.Core.Shadow.ShadowModeOptions
        {
            Enabled = false,
            ExecuteActions = false,
            CaptureDecisions = true,
            MaxHistory = 10
        });

    var result = mirror.Mirror(new UserOpenPipRequested(1, 10, "disabled"));

    AssertTrue(!result.Accepted, "disabled Shadow Mode must ignore events");
    AssertTrue(!result.Executed, "disabled Shadow Mode must not execute actions");
    AssertTrue(result.PredictedActions.Count == 0, "disabled Shadow Mode must not predict actions");
}

static void TestShadowModeRejectsInvalidEventSafely()
{
    var mirror = new PiPManager.Core.Shadow.ShadowModeEventMirror();

    var result = mirror.Mirror(new UserOpenPipRequested(0, 10, "bad-slot"));

    AssertTrue(!result.Accepted, "Shadow Mode should reject invalid event safely");
    AssertTrue(!result.Executed, "Shadow Mode rejected event must not execute actions");
}

TestStaleReconnectDoesNotReactivateResetSlot();
TestAutoAdvanceSafetyPolicy();
TestAutoReturnBurstPolicy();
TestPipWindowLostRequiresMatchingHwnd();
TestPipWindowLostWithoutCurrentHwndIsIgnored();
TestReconnectSucceededRequiresReconnectingAndNewValidHwnd();
TestReconnectRetryQueuedRestoresWaitingBeforeReconnect();
await TestSchedulerReplacementDoesNotRemoveNewSchedule();
await TestSchedulerConcurrentScheduleRunsOnlyOneCallback();
await TestSchedulerReportsCallbackFailure();
TestHiddenLegacyMapsToActiveHidden();
TestEngineCanImportLegacySnapshot();
TestImportSnapshotDoesNotOverwriteNewerState();
TestImportSnapshotRejectsImpossibleStates();
TestMapperDoesNotTreatZeroHwndAsActive();
TestVideoChangedIgnoredOutsideActive();
TestOpenPipRequiresAttemptId();
TestPipWindowCapturedRejectsZeroHwnd();
TestImportSnapshotEqualTimestampDoesNotOverwrite();
TestShadowExternalCaptureLossWithoutLinkResetsToEmpty();
TestShadowPreservedSameHwndReturnsWaitingToActive();
TestShadowPreservedSameHwndRejectsWrongAttempt();
TestShadowExternalCaptureFromEmptyBecomesActive();
TestShadowExternalCaptureDoesNotOverrideOpening();
TestShadowManualOpenAfterFailedReconnectCanCaptureNormally();
TestShadowManualOpenAttemptMustDominateReconnectAttempt();
TestShadowReconnectSuccessRequiresStartedOrdering();
TestShadowReconnectFailedRequiresStartedOrdering();
TestShadowAutoReturnVideoChangedThenReconnectCycle();
TestShadowAutoReturnReconnectCycleUsesSameAttempt();
TestShadowReconnectOldAttemptIsIgnored();
TestShadowReconnectFailedUsesSameAttempt();
TestShadowExpiredManualAttemptShouldNotValidateLaterExternalCapture();
TestShadowManualOpenCaptureContinuityUsesSameAttempt();
TestShadowManualOpenCaptureDifferentAttemptIsRejected();
TestShadowCaptureWithoutExpectedOpeningIsRejected();
TestShadowLossHiddenSnapshotCanBeNormalized();
TestShadowHookStyleCaptureAndLossSequence();
TestResetEmptySlotIsAppliedWithoutStateChange();
TestShadowModeDoesNotExecuteActions();
TestShadowModeMarksNoChangeAsIgnored();
TestShadowModeVideoChangedAutoReturnOffIsAcceptedWithoutStateChange();
TestShadowModeHistoryLimit();
TestShadowModeDisabledIgnoresEvents();
TestShadowModeRejectsInvalidEventSafely();

Console.WriteLine("PiPManager.Core.Tests: OK");
