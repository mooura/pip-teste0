# AutoReturn Correlated Snapshot + Pre-Shortcut Gate

Correção isolada sobre `PIP_FIX2`.

## Motivo

O AutoReturn podia solicitar um snapshot, aguardar apenas um tempo fixo e continuar antes da resposta atualizada da extensão. Isso permitia que um candidato antigo fosse liberado e que o atalho físico fosse enviado enquanto a aba já estava em `no-video`.

## Correção

- Cada snapshot solicitado pelo AutoReturn leva um `requestId` exclusivo.
- A extensão ecoa o mesmo `requestId` em `tabDiscoveryDiagnostic`.
- O aplicativo só aceita uma geração posterior que contenha exatamente esse identificador.
- Timeout, aba ausente, `content-unavailable`, `video-filtered-or-loading` ou `no-video` usam fail-safe e não enviam o atalho.
- Antes de cada tentativa física existe uma segunda barreira correlacionada.
- A postergação usa o cooldown de readiness e preserva `RetryBackoffAttempt`.
- Layout, movimentação, captura, Fixar layout, interface e áudio permanecem fora da alteração.

## Extensão

O arquivo `src/PiPManager.Extension/background.js` foi alterado para transportar e ecoar o `requestId`. Recarregue a extensão temporária no Firefox/Zen antes do teste. A versão declarada continua `1.4.39.5`.

## Logs esperados

```text
auto-return-fresh-snapshot-start: ... correlationId=...
auto-return-fresh-snapshot-correlated-response: ... canProceed=True|False
auto-return-pre-shortcut-fresh-snapshot-deferred: ... physicalShortcutSent=False
auto-return-physical-attempt-deferred-by-correlated-snapshot
```
