﻿param()

$ErrorActionPreference = 'Stop'
$root = Resolve-Path (Join-Path $PSScriptRoot '..\..')
$fixed = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\MainWindow.FixedLayout.cs') -Raw
$main = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\MainWindow.xaml.cs') -Raw
$policy = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Core\Core\Automation\AutoReturnBurstPolicy.cs') -Raw
$coreTests = Get-Content -LiteralPath (Join-Path $root 'tests\PiPManager.Core.Tests\Program.cs') -Raw
$release = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\Services\ReleaseInfoService.cs') -Raw
$project = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\PiPManager.Wpf.csproj') -Raw
$version = Get-Content -LiteralPath (Join-Path $root 'VERSION_STABLE.txt') -Raw
$gate = Get-Content -LiteralPath (Join-Path $root 'RUN_CORE_TESTS.bat') -Raw

$checks = [ordered]@{
  'fixed layout authority is PiP-only' = $fixed.Contains('pipOnly=True; externalWindowsManaged=False') -and -not $fixed.Contains('TryConstrainForegroundWindow(foreground') -and ([regex]::Matches($fixed, 'TryConstrainForegroundWindow\(').Count -eq 1)
  'legacy respect-area setting is forced off' = $fixed.Contains('_respectFixedLayoutAreaEnabled = false;') -and $main.Contains('_settings.RespectFixedLayoutAreaEnabled = false;')
  'fixed-layout timer only enforces PiP geometry' = $fixed.Contains('private void FixedLayoutRespectTimerTick()') -and $fixed.Contains('EnforceFixedPipGeometryTick();')
  'recovery has absolute 45 second deadline' = $fixed.Contains('FixedLayoutRecoveryTimeoutMs = 45_000') -and $fixed.Contains('var recoveryTimeoutMs = FixedLayoutRecoveryTimeoutMs;') -and $policy.Contains('MaxLayoutRecoveryTimeoutMilliseconds = 45_000') -and $coreTests.Contains('tenSlotLayoutTimeout == 45_000')
  'slot swap remaps active recovery cycle' = $fixed.Contains('fixed-layout-recovery-slot-membership-remapped') -and $fixed.Contains('AutoReturnBurstPolicy.RemapSlotMembershipAfterSwap') -and $main.Contains('RemapFixedLayoutRecoverySlotsAfterSwap(source.Number, target.Number, "slot-drag-swap")') -and $coreTests.Contains('expectedRecoverySlots.SetEquals(new[] { 1, 2, 5, 6 })')
  'recovered HWND uses one move-only placement' = $fixed.Contains('fixed-layout-recovery-slot-placed-once') -and $fixed.Contains('resize=False; sizesPreserved=True')
  'recovery finalization suppresses global batch' = $fixed.Contains('globalReflowSuppressed=True') -and $fixed.Contains('unrelatedSlotsMoved=False') -and -not $fixed.Contains('ApplyFixedLayoutToAllActive(completionSource')
  'pending aspect reflow cannot override fixed recovery' = $fixed.Contains('fixed-layout-recovery-pending-aspect-reflow-suppressed')
  'release is RC6 app version' = $release.Contains('AppVersion = "1.5.12.3909"') -and $release.Contains('P0 Optimization RC6') -and $project.Contains('<Version>1.5.12.3909</Version>') -and $version.Contains('Aplicativo: 1.5.12.3909')
  'checker is included in core gate' = $gate.Contains('CHECK_P0_OPTIMIZATION_RC6.ps1')
}

$failed = 0
foreach ($item in $checks.GetEnumerator()) {
  if ($item.Value) { Write-Host ($item.Key + ': OK') }
  else { Write-Host ($item.Key + ': FAIL'); $failed++ }
}

if ($failed -gt 0) { throw 'P0 Optimization RC6 checks failed.' }
Write-Host 'P0 Optimization RC6 checks OK.'
