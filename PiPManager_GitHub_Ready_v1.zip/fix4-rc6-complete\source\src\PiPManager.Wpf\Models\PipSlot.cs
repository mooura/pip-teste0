﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace PiPManager.Wpf.Models;

public sealed class PipSlot : INotifyPropertyChanged
{
    private PipWindowInfo? _window;
    private PipSlotState _state = PipSlotState.Free;
    private string _pairDomain = string.Empty;
    private string _pairStateText = "Sem vínculo";
    private string _pairDetailText = "Slot sem vínculo com aba/vídeo";
    private string _playlistText = string.Empty;
    private bool _isAutoReturnEnabled;
    private bool _isPreloadEnabled;
    private string _nextPreviewTitle = string.Empty;
    private string _nextPreviewThumbnailUrl = string.Empty;
    private string _nextPreviewVideoUrl = string.Empty;
    private string _currentVideoTitle = string.Empty;

    public int Number { get; }

    public PipWindowInfo? Window
    {
        get => _window;
        set
        {
            if (Equals(_window, value)) return;
            _window = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(IsOccupied));
            OnPropertyChanged(nameof(DisplayTitle));
            OnPropertyChanged(nameof(SlotToolTip));
            OnPropertyChanged(nameof(VisualIdentityText));
            OnPropertyChanged(nameof(VisualStateGlyph));
            OnPropertyChanged(nameof(StateBadgeText));
        }
    }

    public bool IsOccupied => Window is not null;

    public bool IsAutoReturnEnabled
    {
        get => _isAutoReturnEnabled;
        set
        {
            if (_isAutoReturnEnabled == value) return;
            _isAutoReturnEnabled = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(AutoReturnVisualText));
            OnPropertyChanged(nameof(SlotToolTip));
        }
    }

    public string AutoReturnVisualText => IsAutoReturnEnabled ? "Auto-retorno ON" : "Auto-retorno OFF";

    public bool IsPreloadEnabled
    {
        get => _isPreloadEnabled;
        set { if (_isPreloadEnabled == value) return; _isPreloadEnabled = value; OnPropertyChanged(); OnPropertyChanged(nameof(PreloadVisualText)); }
    }
    public string PreloadVisualText => IsPreloadEnabled ? "Preload ON" : "Preload OFF";

    public string NextPreviewTitle { get => _nextPreviewTitle; set { var next=value?.Trim() ?? string.Empty; if (_nextPreviewTitle==next) return; _nextPreviewTitle=next; OnPropertyChanged(); OnPropertyChanged(nameof(HasNextPreview)); } }
    public string NextPreviewThumbnailUrl { get => _nextPreviewThumbnailUrl; set { var next=value?.Trim() ?? string.Empty; if (_nextPreviewThumbnailUrl==next) return; _nextPreviewThumbnailUrl=next; OnPropertyChanged(); OnPropertyChanged(nameof(HasNextPreview)); } }
    public string NextPreviewVideoUrl { get => _nextPreviewVideoUrl; set { var next=value?.Trim() ?? string.Empty; if (_nextPreviewVideoUrl==next) return; _nextPreviewVideoUrl=next; OnPropertyChanged(); OnPropertyChanged(nameof(HasAnimatedNextPreview)); OnPropertyChanged(nameof(HasNextPreview)); } }
    public bool HasAnimatedNextPreview => !string.IsNullOrWhiteSpace(NextPreviewVideoUrl);
    public bool HasNextPreview => !string.IsNullOrWhiteSpace(NextPreviewTitle) || !string.IsNullOrWhiteSpace(NextPreviewThumbnailUrl);
    public string CurrentVideoTitle { get => _currentVideoTitle; set { var next=value?.Trim() ?? string.Empty; if (_currentVideoTitle==next) return; _currentVideoTitle=next; OnPropertyChanged(); OnPropertyChanged(nameof(CurrentVideoTitleDisplay)); } }
    public string CurrentVideoTitleDisplay => string.IsNullOrWhiteSpace(CurrentVideoTitle) ? "Sem vídeo vinculado" : CurrentVideoTitle;

    public PipSlotState State
    {
        get => _state;
        set
        {
            if (_state == value) return;
            _state = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(IsHidden));
            OnPropertyChanged(nameof(StatusText));
            OnPropertyChanged(nameof(DisplayTitle));
            OnPropertyChanged(nameof(SlotToolTip));
            OnPropertyChanged(nameof(VisualIdentityText));
            OnPropertyChanged(nameof(VisualStateGlyph));
            OnPropertyChanged(nameof(StateBadgeText));
        }
    }

    public bool IsHidden
    {
        get => State == PipSlotState.Hidden;
        set
        {
            if (value)
            {
                State = PipSlotState.Hidden;
            }
            else if (State == PipSlotState.Hidden)
            {
                State = Window is not null ? PipSlotState.Active : PipSlotState.Free;
            }
        }
    }

    public string StatusText => State switch
    {
        PipSlotState.Active => "Capturado",
        PipSlotState.Hidden => "Oculto",
        PipSlotState.Offline => "Reconectando",
        PipSlotState.AwaitingPip => "Aguardando PiP",
        _ => "Pronto"
    };

    public string PairDomain
    {
        get => _pairDomain;
        set
        {
            var next = value?.Trim() ?? string.Empty;
            if (_pairDomain == next) return;
            _pairDomain = next;
            OnPropertyChanged();
            OnPropertyChanged(nameof(PairVisualText));
            OnPropertyChanged(nameof(SlotToolTip));
            OnPropertyChanged(nameof(VisualIdentityText));
        }
    }

    public string PairStateText
    {
        get => _pairStateText;
        set
        {
            var next = string.IsNullOrWhiteSpace(value) ? "Sem vínculo" : value.Trim();
            if (_pairStateText == next) return;
            _pairStateText = next;
            OnPropertyChanged();
            OnPropertyChanged(nameof(PairVisualText));
            OnPropertyChanged(nameof(SlotToolTip));
            OnPropertyChanged(nameof(VisualIdentityText));
        }
    }

    public string PairDetailText
    {
        get => _pairDetailText;
        set
        {
            var next = string.IsNullOrWhiteSpace(value) ? "Slot sem vínculo com aba/vídeo" : value.Trim();
            if (_pairDetailText == next) return;
            _pairDetailText = next;
            OnPropertyChanged();
            OnPropertyChanged(nameof(SlotToolTip));
            OnPropertyChanged(nameof(VisualIdentityText));
        }
    }

    public string PlaylistText
    {
        get => _playlistText;
        set
        {
            var next = value?.Trim() ?? string.Empty;
            if (_playlistText == next) return;
            _playlistText = next;
            OnPropertyChanged();
            OnPropertyChanged(nameof(HasPlaylistText));
            OnPropertyChanged(nameof(SlotToolTip));
        }
    }

    public bool HasPlaylistText => !string.IsNullOrWhiteSpace(PlaylistText);

    public string PairVisualText
    {
        get
        {
            if (!string.IsNullOrWhiteSpace(PairDomain))
                return PairDomain.Length <= 18 ? PairDomain : PairDomain[..18] + "...";
            return PairStateText;
        }
    }


    public string SlotLabel => $"S{Number}";

    public string VisualStateGlyph => State switch
    {
        PipSlotState.Active => "▶",
        PipSlotState.Hidden => "—",
        PipSlotState.Offline => "↻",
        PipSlotState.AwaitingPip => "…",
        _ => "+"
    };

    public string StateBadgeText => State switch
    {
        PipSlotState.Active => "ATIVO",
        PipSlotState.Hidden => "OCULTO",
        PipSlotState.Offline => "RETORNO",
        PipSlotState.AwaitingPip => "ABRINDO",
        _ => "LIVRE"
    };

    public string VisualIdentityText
    {
        get
        {
            var text = !string.IsNullOrWhiteSpace(PairDomain) ? PairDomain : DisplayTitle;
            return text.Length <= 20 ? text : text[..20] + "…";
        }
    }

    public string SlotToolTip => $"Slot {Number} — {StatusText}\nAuto-retorno: {(IsAutoReturnEnabled ? "ON" : "OFF")}\n{PairDetailText}\nArraste este cartão sobre outro para trocar a posição."
        + (HasPlaylistText ? $"\n{PlaylistText}" : string.Empty);

    public string DisplayTitle => Window?.Title ?? State switch
    {
        PipSlotState.Offline => "Reservado",
        PipSlotState.AwaitingPip => "Preparado",
        _ => "Vazio"
    };

    public PipSlot(int number) => Number = number;

    public void RefreshWindow(PipWindowInfo window) => Window = window;

    public event PropertyChangedEventHandler? PropertyChanged;
    private void OnPropertyChanged([CallerMemberName] string? propertyName = null) =>
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
}
