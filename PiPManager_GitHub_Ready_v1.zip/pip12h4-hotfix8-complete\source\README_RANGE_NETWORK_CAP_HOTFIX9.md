# Range Network Cap Hotfix 9

Version: `1.4.39.24-range-network-cap-hotfix9`

This patch changes only the extension preload network transport. Geometry and WPF handoff code are preserved byte-for-byte from Hotfix 8.

## Network policy

- privileged background `fetch` with `Range: bytes=0-N`;
- `AbortController` enforces a 5-second time cap;
- an 8 MiB hard byte cap is applied even if the origin ignores Range and returns HTTP 200;
- streamed bytes are retained in a temporary, three-entry background cache for at most 90 seconds;
- command handoff records cached bytes and consumes the cache only after the commanded asset becomes current;
- the full-media hidden `<video src=...>` preload path is no longer used, preventing native-media overshoot.

## Expected diagnostics

- `next-preload-range-start`
- `next-preload-range-complete`
- `next-preload-handoff-armed` with `cachedBytes > 0`
- `next-preload-handoff-restored-after-navigation`
- `next-preload-handoff-consumed`

The preview media path is unchanged.
