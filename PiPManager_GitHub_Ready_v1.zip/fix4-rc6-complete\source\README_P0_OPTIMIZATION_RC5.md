# P0 Optimization RC5 — supressão de eventos de visibilidade intencional

## Motivação

O log de homologação da RC4 mostrou que Ocultar/Mostrar restaurava corretamente os PiPs,
mas cada evento `Shown` de uma janela já vinculada ainda entrava no reator de captura,
iniciava validação direta e podia abrir uma espera de pré-armamento de até 900 ms.

## Alterações

- transições intencionais de ocultar/mostrar são armadas por HWND por 1500 ms;
- `Shown`/`Hidden` dessas transições não acionam refresh, Shadow ou AutoReturn;
- candidatos do reator cujo HWND já pertence a um slot são descartados imediatamente;
- eventos `Destroyed` continuam ativos durante a janela de supressão;
- nenhuma alteração na política de AutoReturn, protocolo da extensão ou layout.

## Versões

- Produto: `9.39.03`
- Aplicativo: `1.5.12.3908`
- Extensão: `1.4.39.7`
