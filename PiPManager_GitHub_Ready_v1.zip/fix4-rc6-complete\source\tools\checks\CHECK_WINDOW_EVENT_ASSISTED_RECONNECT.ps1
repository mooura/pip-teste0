$ErrorActionPreference = "Stop"
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$main = Get-Content (Join-Path $root "src\PiPManager.Wpf\MainWindow.xaml.cs") -Raw
$monitor = Get-Content (Join-Path $root "src\PiPManager.Wpf\Services\WindowsEventMonitorService.cs") -Raw

$requiredAny = @(
  @{ Name = "Monitor publishes relevant events"; Text = "event Action<WindowMonitorEvent>? RelevantEventReceived"; Source = $monitor },
  @{ Name = "Monitor invokes relevant event"; Text = "RelevantEventReceived?.Invoke(ev)"; Source = $monitor },
  @{ Name = "Main subscribes to relevant event"; Text = "RelevantEventReceived += OnWindowMonitorRelevantEventReceived"; Source = $main },
  @{ Name = "Main has async handler"; Text = "HandleWindowMonitorRelevantEventAsync"; Source = $main },
  @{ Name = "Created/Shown log"; Text = "window-event-assisted-search"; Source = $main },
  @{ Name = "Destroyed/Hidden log"; Text = "window-event-assisted-loss"; Source = $main },
  @{ Name = "Interpolated event-assisted marker"; Text = 'event-assisted-{ev.Kind}'; Source = $main },
  @{ Name = "Created case"; Text = "case WindowMonitorEventKind.Created"; Source = $main },
  @{ Name = "Shown case"; Text = "case WindowMonitorEventKind.Shown"; Source = $main },
  @{ Name = "Destroyed case"; Text = "case WindowMonitorEventKind.Destroyed"; Source = $main },
  @{ Name = "Hidden case"; Text = "case WindowMonitorEventKind.Hidden"; Source = $main },
  @{ Name = "AutoReturn tick"; Text = "await AutoReturnTickAsync();"; Source = $main },
  @{ Name = "Hwnd not found log"; Text = "auto-return-hwnd-not-found"; Source = $main },
  @{ Name = "Event assist enabled marker"; Text = "eventAssist=enabled"; Source = $main },
  @{ Name = "Refresh existing polling path"; Text = "RefreshCapturedWindows();"; Source = $main },
  @{ Name = "Shared loss cooldown key"; Text = "BuildWindowEventAssistedCooldownKey"; Source = $main },
  @{ Name = "Loss key marker"; Text = "loss:{hwnd}"; Source = $main },
  @{ Name = "Cooldown cleanup"; Text = "CleanupWindowEventAssistedCooldowns"; Source = $main },
  @{ Name = "Cooldown cleanup log"; Text = "window-event-assisted-cooldown-cleanup"; Source = $main },
  @{ Name = "Deduped log"; Text = "window-event-assisted-deduped"; Source = $main }
)

foreach ($item in $requiredAny) {
  if (!$item.Source.Contains($item.Text)) {
    throw "Window event assisted reconnect marker missing: $($item.Name) / $($item.Text)"
  }
}

Write-Host "Window event assisted reconnect checks OK."
