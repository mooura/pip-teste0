﻿$ErrorActionPreference = "Stop"
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$main = Get-Content -Raw (Join-Path $root 'src\PiPManager.Wpf\MainWindow.xaml.cs')
$policy = Get-Content -Raw (Join-Path $root 'src\PiPManager.Core\Core\Automation\AutoReturnBurstPolicy.cs')
$tests = Get-Content -Raw (Join-Path $root 'tests\PiPManager.Core.Tests\Program.cs')
$run = Get-Content -Raw (Join-Path $root 'RUN_CORE_TESTS.bat')

$waitStart = $main.IndexOf('private async Task<(VideoTabInfo Tab, bool Ready)> WaitForAutoReturnTargetPlaybackReadyAsync(')
$waitEnd = if ($waitStart -ge 0) { $main.IndexOf('private VideoTabInfo? FindAutoReturnCandidate(', $waitStart) } else { -1 }
$waitMethod = if ($waitStart -ge 0 -and $waitEnd -gt $waitStart) { $main.Substring($waitStart, $waitEnd - $waitStart) } else { '' }

$checks = [ordered]@{
  'hard readiness policy exists' = $policy.Contains('IsPlaybackHardNotReady') -and $policy.Contains('!hasSource || isEnded')
  'same-video path still blocks missing source' = $waitMethod.Contains('(!realChange && !hardNotReady)') -and $waitMethod.Contains('IsAutoReturnTargetHardNotReady')
  'command target minimal readiness exists' = $waitMethod.Contains('IsCommandNavigationTargetMinimallyReady') -and $waitMethod.Contains('AutoReturnCommandNavigationMinimalReadyGraceMs')
  'identity is recomputed while waiting' = $waitMethod.Contains('realChange = IsRealAutoReturnVideoChange(state, tab);')
  'hard not ready deferral is strictly bounded' = $policy.Contains('return !ready && readinessDeferrals < Math.Max(0, maxReadinessDeferrals);') -and -not $policy.Contains('hardNotReady || readinessDeferrals')
  'terminal hard not ready enters passive watch after bound' = $main.Contains('if (!readiness.Ready && hardNotReady && IsTerminalAutoNextState(state))') -and $main.Contains('state.TerminalPassiveWatch = true;') -and $main.Contains('action=passive-structural-watch')
  'non-terminal bounded fallback remains explicit' = $main.Contains('action=physical-attempt-after-bounded-deferrals')
  'readiness does not consume physical backoff' = $main.Contains('SetAutoReturnReadinessCooldown') -and $main.Contains('physicalRetryBackoffPreserved')
  'hard readiness retry delay is bounded' = $policy.Contains('hardNotReady ? 500 : 300')
  'core regression covers minimal and missing-source readiness' = $tests.Contains('a new command target with source may use the short minimal-readiness grace') -and $tests.Contains('missing source must block a physical AutoReturn shortcut')
  'checker included in core gate' = $run.Contains('CHECK_AUTORETURN_HARD_READINESS_GATE.ps1')
}

$failed = @()
foreach ($item in $checks.GetEnumerator()) {
  if ($item.Value) { Write-Host ($item.Key + ': OK') }
  else { Write-Host ($item.Key + ': FAIL'); $failed += $item.Key }
}
if ($failed.Count -gt 0) { throw "AutoReturn hard readiness checks failed: $($failed -join ', ')" }
Write-Host 'AutoReturn hard readiness gate checks OK.'
