﻿namespace PiPManager.Wpf.Models;

public sealed record DisplayMonitorInfo(
    string DeviceName,
    string Label,
    NativeRect Bounds,
    NativeRect WorkArea,
    bool IsPrimary)
{
    public override string ToString() => Label;
}
