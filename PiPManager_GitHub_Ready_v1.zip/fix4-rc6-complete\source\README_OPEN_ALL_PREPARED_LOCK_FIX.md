﻿# Correção: Abrir todos perde o slot preparado

## Sintoma

O Firefox criava a janela PiP, mas o PiPManager registrava `no-armed-prepared-pip-after-grace`, deixava o slot sem HWND confirmado e avançava o lote como falha.

## Causa

A limpeza periódica de slots com AutoReturn desativado zerava `_armedPipPairTab` e `_armedPipTargetSlotNumber` mesmo quando esses campos pertenciam a uma abertura manual ou ao comando **Abrir todos**. O lock oficial da abertura continuava válido, mas o Reactor ainda dependia exclusivamente do estado transitório apagado.

## Correção

- Cada lock de abertura guarda a aba exata e o proprietário (`User` ou `AutoReturn`).
- A limpeza de AutoReturn preserva tentativas pertencentes ao usuário.
- O Reactor restaura a preparação usando o lock oficial quando o estado transitório estiver ausente.
- O timer legado usa a mesma recuperação.
- O snapshot de HWNDs anterior à abertura é recuperado do `auto-pair proof` quando necessário.

## Marcadores esperados

Em situação de recuperação defensiva pode aparecer:

```text
prepared-state-restored-from-open-lock
auto-return-cleanup-preserved-user-open
```

A janela nova deve terminar com:

```text
window-event-reactor-assisted-capture-accepted
auto-pair-proof-result: result=PASS
open-all-item-pass
```

A extensão permanece na versão `1.4.39.5`.
