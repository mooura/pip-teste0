# Baseline estabilizada 9.39.01

Data: 2026-07-22

Esta baseline congela o comportamento funcional observado antes de novas correções.
Uma mudança deve declarar uma única camada principal e passar pelo gate específico
dessa camada. Antes de gerar ZIP, o gate completo continua obrigatório.

## Evidência de execução

Log de referência: `7dd53f09-bd20-44e6-b738-8f8d6966200d/pasted-text.txt`.

- Abrir todos: 10 fontes detectadas, 10 PiPs presentes, resultado `PASS`.
- Reabertura incremental: resultados `PASS` com itens já ativos preservados.
- AutoReturn: 15 recuperações confirmadas e nenhuma falha final no trecho analisado.
- Layout final do lote: aplicado uma vez com 10 janelas.
- Next manual: possui rota de aba exata e frame confirmado, mas deve ser validado
  separadamente porque não houve comando Next no trecho de referência.
- Avanço ao terminar: fora do escopo desta baseline; não alterar junto com Next manual.

## Limites

- `Navigation`: comando Next/Previous e protocolo da extensão.
- `OpenAll`: descoberta, fila serial, captura e vínculo em lote.
- `AutoReturn`: perda, seleção do alvo e recuperação de HWND.
- `Layout`: geometria, mosaico, proporção e reserva de área.
- `Discovery`: inventário de abas, frames e sessões de vídeo.

Uma correção não deve modificar arquivos de outra camada sem registrar explicitamente
o motivo e executar os gates das duas camadas.

## Comandos

Gate direcionado:

```powershell
.\RUN_STABILIZATION_GATE.ps1 -Layer Navigation
```

Gate obrigatório antes de empacotar:

```powershell
.\RUN_STABILIZATION_GATE.ps1 -Layer All -Full
```
