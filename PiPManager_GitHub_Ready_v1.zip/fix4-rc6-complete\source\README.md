# PiP Manager 9.39.03 — Fix4 RC3 P0 Optimization RC6

Versões:

- Produto: **9.39.03**
- Aplicativo WPF: **1.5.12.3909**
- Extensão: **1.4.39.7**
- Plataforma: **.NET 8 / WPF / Windows x64**
- Núcleo nativo: **PiPManager.Native.dll ABI 100**

Esta versão deriva da RC3 Telemetry e incorpora o pacote P0 de fluidez. A base
funcional permanece `PIP_FIX4_preload_melhorado(3).zip`, a última base estável
fornecida. O comportamento funcional permanece na linha Fix4. Além das correções de
navegação Próximo/Anterior e AutoReturn, esta candidata contém otimizações
internas de fluidez no arraste, persistência e entrega de eventos, sem mudar os
comandos ou layouts disponíveis ao usuário.

## Correções desta candidata

- movimentos do hook de mouse são consolidados antes de chegar ao Dispatcher;
- consultas frequentes do AutoReturn reutilizam configuração normalizada em cache;
- configurações são persistidas com debounce e I/O fora da thread gráfica;
- status e snapshots repetidos da extensão usam estratégia de estado mais recente;
- HWNDs temporariamente perdidos e reservados pelo AutoReturn não entram no modelo
  físico do arraste;
- totais do monitor WinEvent são publicados ao painel de saúde em janelas de 250 ms,
  mantendo os contadores atômicos exatos;
- Próximo e Anterior agora registram o ciclo completo
  `requested → dispatched → confirmed → final-result` com o mesmo
  `operationId`, mesmo quando o AutoReturn está desligado.
- O resultado inclui slot, aba, sessão, stable key, URL, transporte e método;
  no Anterior, o método esperado permanece
  `tabs-goBack-linked-tab-authoritative`.
- Cada comando de navegação recebe um `operationId` único, preservado entre WPF
  e extensão.
- O AutoReturn só reconhece um vídeo novo depois da confirmação do comando e
  ignora snapshots anteriores à confirmação.
- Uma navegação confirmada não pode reabrir o vídeo antigo pelo fallback de
  playlist.
- Uma navegação rejeitada volta ao caminho seguro de reabrir o mesmo vídeo.
- `Anterior` usa o histórico da aba vinculada como autoridade, sem ser bloqueado
  por sessões de vídeo antigas, preloads ou múltiplos players na mesma aba.
- O avanço automático herda a resposta da mesma operação, inclusive quando ela
  chega antes da criação do estado rápido de AutoReturn.
- A confirmação autoritativa continua válida durante toda a vida do estado de
  preservação; a janela de 2,2 segundos cobre somente a corrida anterior à
  resposta da extensão.
- Players que mantêm `readyState=0` podem passar pelo AutoReturn somente após
  duas amostras novas e consecutivas com `playing=true`, fonte válida e vídeo
  não encerrado.
- **Fixar layout** agora possui autoridade exclusiva sobre janelas PiP vinculadas;
  jogos, navegadores e demais aplicativos nunca são movidos ou redimensionados.
- O ciclo de recuperação do layout fixo possui prazo absoluto de 45 segundos,
  independentemente da quantidade de slots.
- Trocas de slots durante uma recuperação remapeiam imediatamente os conjuntos
  esperado/recuperado, preservando a mesma deadline.
- O encerramento da recuperação não aplica mais um lote global: somente o HWND
  recuperado é movido para seu slot, sem alterar tamanhos ou PiPs estáveis.

## Compilação e pacote

No Windows, execute:

```text
BUILD_WINDOWS.bat
```

O script:

1. valida ou recompila o núcleo nativo;
2. executa todos os testes e checks;
3. publica o aplicativo Windows x64;
4. cria `DIST\PiPManager_9.39.03` com a extensão e checksums.

Se qualquer etapa falhar, o pacote final não é criado.

## Validação manual

Depois do build aprovado, siga [VALIDACAO_FINAL_WINDOWS.md](VALIDACAO_FINAL_WINDOWS.md).
O candidato só deve ser promovido a release estável após esse roteiro passar
com o aplicativo e a extensão 1.4.39.7 recarregados.

## Organização

- `src\PiPManager.Wpf`: aplicativo.
- `src\PiPManager.Core`: políticas testáveis.
- `src\PiPManager.Extension`: extensão do navegador.
- `src\PiPManager.Native`: núcleo nativo de layout.
- `tests`: testes automatizados.
- `tools\checks`: gates estruturais e de regressão.

O modo nativo padrão continua **Compare**: o C++ mede o lote e o C# permanece
como autoridade. O modo **Primary** conserva fallback automático para o motor
gerenciado.
