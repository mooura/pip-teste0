﻿using System.IO;
using System.Text;
using PiPManager.Core.Shadow;

namespace PiPManager.Wpf.Services;

public sealed record ShadowParityRecord(
    DateTimeOffset CreatedAt,
    string Source,
    string LegacyOutcome,
    string EventName,
    int SlotNumber,
    string AttemptId,
    bool Processed,
    bool Accepted,
    bool StateChanged,
    bool Executed,
    string Reason,
    string IgnoredReason,
    string ShadowState,
    string ShadowHwnd,
    string PredictedActions);

public sealed class ShadowParityReportService
{
    private readonly object _gate = new();
    private readonly DateTimeOffset _startedAtUtc = DateTimeOffset.UtcNow;
    private readonly List<ShadowParityRecord> _records = new();

    public IReadOnlyList<ShadowParityRecord> Records
    {
        get
        {
            lock (_gate)
                return _records.ToArray();
        }
    }

    public void Add(
        string source,
        string legacyOutcome,
        ShadowDecisionResult result)
    {
        var shadowState = result.Slot?.State.ToString() ?? "null";
        var shadowHwnd = result.Slot?.PipHwnd.HasValue == true
            ? $"0x{result.Slot.PipHwnd.Value.ToInt64():X}"
            : "null";

        var actions = result.PredictedActions.Count == 0
            ? "-"
            : string.Join("|", result.PredictedActions.Select(action => action.Name));

        var record = new ShadowParityRecord(
            DateTimeOffset.UtcNow,
            source,
            legacyOutcome,
            result.Event.Name,
            result.Event.SlotNumber,
            result.Event.AttemptId,
            result.Processed,
            result.Accepted,
            result.StateChanged,
            result.Executed,
            result.Reason,
            result.IgnoredReason ?? "-",
            shadowState,
            shadowHwnd,
            actions);

        lock (_gate)
            _records.Add(record);
    }

    public string BuildTextReport()
    {
        ShadowParityRecord[] records;
        lock (_gate)
            records = _records.ToArray();

        var accepted = records.Count(r => r.Accepted);
        var rejected = records.Count(r => !r.Accepted);
        var changed = records.Count(r => r.StateChanged);
        var ignored = records.Count(r => r.Processed && !r.Accepted);
        var executed = records.Count(r => r.Executed);
        var potentialDivergences = records.Count(IsPotentialDivergence);
        var endedAtUtc = DateTimeOffset.UtcNow;
        var duration = endedAtUtc - _startedAtUtc;
        var finalStateDivergences = CountFinalStateDivergences(records);
        var result = records.Length == 0 ? "INCONCLUSIVE" : potentialDivergences == 0 && finalStateDivergences == 0 && executed == 0 ? "PASS" : "FAIL";

        var sb = new StringBuilder();
        sb.AppendLine("PiPManager Shadow Parity Report");
        sb.AppendLine($"Result={result}");
        sb.AppendLine($"ProductVersion={ReleaseInfoConstants.ProductVersion}");
        sb.AppendLine($"AppVersion={ReleaseInfoConstants.AppVersion}");
        sb.AppendLine($"ExtensionVersion={ReleaseInfoConstants.ExtensionVersion}");
        sb.AppendLine("StartedAtUtc=" + _startedAtUtc.ToString("O"));
        sb.AppendLine("EndedAtUtc=" + endedAtUtc.ToString("O"));
        sb.AppendLine("Duration=" + duration);
        sb.AppendLine("GeneratedUtc=" + endedAtUtc.ToString("O"));
        sb.AppendLine();
        sb.AppendLine("Summary");
        sb.AppendLine($"TotalEvents={records.Length}");
        sb.AppendLine($"Accepted={accepted}");
        sb.AppendLine($"Rejected={rejected}");
        sb.AppendLine($"StateChanged={changed}");
        sb.AppendLine($"Ignored={ignored}");
        sb.AppendLine($"ExecutedByShadow={executed}");
        sb.AppendLine($"PotentialDivergences={potentialDivergences}");
        sb.AppendLine($"FinalStateDivergences={finalStateDivergences}");
        sb.AppendLine();

        sb.AppendLine("ByEvent");
        foreach (var group in records.GroupBy(r => r.EventName).OrderBy(g => g.Key))
        {
            sb.AppendLine($"{group.Key}: total={group.Count()}; accepted={group.Count(r => r.Accepted)}; rejected={group.Count(r => !r.Accepted)}; changed={group.Count(r => r.StateChanged)}");
        }

        sb.AppendLine();
        sb.AppendLine("BySource");
        foreach (var group in records.GroupBy(r => r.Source).OrderBy(g => g.Key))
        {
            sb.AppendLine($"{group.Key}: total={group.Count()}; accepted={group.Count(r => r.Accepted)}; rejected={group.Count(r => !r.Accepted)}");
        }

        sb.AppendLine();
        sb.AppendLine("PotentialDivergences");
        foreach (var r in records.Where(IsPotentialDivergence))
        {
            sb.AppendLine($"{r.CreatedAt:O}; source={r.Source}; legacy={r.LegacyOutcome}; event={r.EventName}; slot={r.SlotNumber}; attempt={r.AttemptId}; accepted={r.Accepted}; stateChanged={r.StateChanged}; shadowState={r.ShadowState}; reason={r.Reason}; ignored={r.IgnoredReason}; actions={r.PredictedActions}");
        }

        sb.AppendLine();
        sb.AppendLine("FinalStateBySlot");
        foreach (var group in records.GroupBy(r => r.SlotNumber).OrderBy(g => g.Key))
        {
            var last = group.OrderBy(r => r.CreatedAt).Last();
            var lastLegacyActive = group.OrderBy(r => r.CreatedAt).LastOrDefault(r =>
                r.LegacyOutcome.Contains("active", StringComparison.OrdinalIgnoreCase) ||
                r.LegacyOutcome.Contains("preserved-same-hwnd", StringComparison.OrdinalIgnoreCase) ||
                r.LegacyOutcome.Contains("capture", StringComparison.OrdinalIgnoreCase));

            var lastAutoReturnOffExpectedFailure = group.OrderBy(r => r.CreatedAt).LastOrDefault(r =>
                r.LegacyOutcome.Contains("autoreturn-disabled", StringComparison.OrdinalIgnoreCase) ||
                r.LegacyOutcome.Contains("auto-return-off", StringComparison.OrdinalIgnoreCase) ||
                r.LegacyOutcome.Contains("AutoRetorno OFF", StringComparison.OrdinalIgnoreCase));

            var finalFailedIsExpected = last.ShadowState.Equals("Failed", StringComparison.OrdinalIgnoreCase) &&
                lastAutoReturnOffExpectedFailure is not null &&
                (lastLegacyActive is null || lastAutoReturnOffExpectedFailure.CreatedAt >= lastLegacyActive.CreatedAt);

            var finalDivergence = !finalFailedIsExpected &&
                lastLegacyActive is not null &&
                !last.ShadowState.Equals("Active", StringComparison.OrdinalIgnoreCase) &&
                !last.ShadowState.Equals("Empty", StringComparison.OrdinalIgnoreCase);

            sb.AppendLine($"slot={group.Key}; finalShadowState={last.ShadowState}; finalEvent={last.EventName}; finalLegacy={last.LegacyOutcome}; finalExpectedFailure={finalFailedIsExpected}; finalPotentialDivergence={finalDivergence}");
        }

        sb.AppendLine();
        sb.AppendLine("RawRecords");
        foreach (var r in records)
        {
            sb.AppendLine($"{r.CreatedAt:O}\tsource={r.Source}\tlegacy={r.LegacyOutcome}\tevent={r.EventName}\tslot={r.SlotNumber}\tattempt={r.AttemptId}\tprocessed={r.Processed}\taccepted={r.Accepted}\tstateChanged={r.StateChanged}\texecuted={r.Executed}\tshadowState={r.ShadowState}\tshadowHwnd={r.ShadowHwnd}\treason={r.Reason}\tignored={r.IgnoredReason}\tactions={r.PredictedActions}");
        }

        return sb.ToString();
    }

    public string SaveTextReport(string directory)
    {
        Directory.CreateDirectory(directory);
        var path = Path.Combine(directory, $"shadow-parity-report-{DateTime.Now:yyyyMMdd-HHmmss}.txt");
        File.WriteAllText(path, BuildTextReport(), Encoding.UTF8);
        return path;
    }


    private static int CountFinalStateDivergences(ShadowParityRecord[] records)
    {
        var count = 0;
        foreach (var group in records.GroupBy(r => r.SlotNumber))
        {
            var ordered = group.OrderBy(r => r.CreatedAt).ToArray();
            if (ordered.Length == 0) continue;
            var last = ordered[^1];
            var lastLegacyActive = ordered.LastOrDefault(r =>
                r.LegacyOutcome.Contains("active", StringComparison.OrdinalIgnoreCase) ||
                r.LegacyOutcome.Contains("preserved-same-hwnd", StringComparison.OrdinalIgnoreCase) ||
                r.LegacyOutcome.Contains("capture", StringComparison.OrdinalIgnoreCase));
            var lastAutoReturnOffExpectedFailure = ordered.LastOrDefault(r =>
                r.LegacyOutcome.Contains("autoreturn-disabled", StringComparison.OrdinalIgnoreCase) ||
                r.LegacyOutcome.Contains("auto-return-off", StringComparison.OrdinalIgnoreCase) ||
                r.LegacyOutcome.Contains("AutoRetorno OFF", StringComparison.OrdinalIgnoreCase));
            var finalFailedIsExpected = last.ShadowState.Equals("Failed", StringComparison.OrdinalIgnoreCase) &&
                lastAutoReturnOffExpectedFailure is not null &&
                (lastLegacyActive is null || lastAutoReturnOffExpectedFailure.CreatedAt >= lastLegacyActive.CreatedAt);
            var finalDivergence = !finalFailedIsExpected && lastLegacyActive is not null &&
                !last.ShadowState.Equals("Active", StringComparison.OrdinalIgnoreCase) &&
                !last.ShadowState.Equals("Empty", StringComparison.OrdinalIgnoreCase);
            if (finalDivergence) count++;
        }
        return count;
    }

    public void Clear()
    {
        lock (_gate)
            _records.Clear();
    }

    public static bool IsPotentialDivergenceForTest(ShadowParityRecord r)
        => IsPotentialDivergence(r);

    private static bool IsPotentialDivergence(ShadowParityRecord r)
    {
        if (r.Executed)
            return true;

        // Eventos ensure-started são idempotentes no Shadow.
        // Se o Core já está em Reconnecting, um ReconnectStarted extra pode ser
        // rejeitado corretamente e não deve ser reportado como divergência.
        if (r.Source.Contains("ensure-started-before", StringComparison.OrdinalIgnoreCase))
            return false;

        if (r.LegacyOutcome.Contains("ensure-started", StringComparison.OrdinalIgnoreCase))
            return false;

        if (r.EventName.Equals("ReconnectStarted", StringComparison.OrdinalIgnoreCase) &&
            !r.Accepted &&
            r.Reason.Contains("fora de", StringComparison.OrdinalIgnoreCase))
        {
            return false;
        }

        if (r.LegacyOutcome.Contains("success", StringComparison.OrdinalIgnoreCase) && !r.Accepted)
            return true;

        if (r.LegacyOutcome.Contains("started", StringComparison.OrdinalIgnoreCase) && !r.Accepted)
            return true;

        if (r.LegacyOutcome.Contains("active", StringComparison.OrdinalIgnoreCase) && !r.Accepted)
            return true;

        if (r.LegacyOutcome.Contains("failed", StringComparison.OrdinalIgnoreCase) && !r.Accepted)
            return true;

        if (r.IgnoredReason != "-" && r.LegacyOutcome.Contains("legacy", StringComparison.OrdinalIgnoreCase))
            return true;

        return false;
    }
}
