﻿# Perfil Jogo — redimensionamento manual independente

- Arraste a borda de qualquer PiP da faixa superior para alterar somente a largura do grupo superior.
- Arraste a borda de qualquer PiP da coluna lateral para alterar somente a largura do grupo lateral.
- Durante o gesto, os outros PiPs acompanham em tempo real; ao soltar, a geometria final é consolidada.
- A posição do slot define o grupo. Um vídeo vertical movido manualmente para o topo segue o grupo superior.
- O grupo não ajustado conserva seu tamanho; ele pode apenas mudar de posição para manter o L conectado.
- Se o tamanho solicitado não couber na tela, o grupo que está sendo arrastado é limitado; o outro grupo não é reduzido silenciosamente.
- As duas larguras são salvas como proporções do monitor e reaplicadas em captura, AutoReturn, Igualar e Fixar layout.
- Layout > Jogo livre permite restaurar o topo, a lateral ou todo o perfil automático.
