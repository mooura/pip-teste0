'use strict';

const fs = require('fs');
const path = require('path');

function assert(condition, message) {
  if (!condition) throw new Error(`TEST FAILED: ${message}`);
}

const root = path.join(__dirname, '..', '..');
const content = fs.readFileSync(path.join(root, 'src', 'PiPManager.Extension', 'content.js'), 'utf8');
const background = fs.readFileSync(path.join(root, 'src', 'PiPManager.Extension', 'background.js'), 'utf8');
const main = fs.readFileSync(path.join(root, 'src', 'PiPManager.Wpf', 'MainWindow.xaml.cs'), 'utf8');
const model = fs.readFileSync(path.join(root, 'src', 'PiPManager.Wpf', 'Models', 'VideoTabInfo.cs'), 'utf8');
const bridge = fs.readFileSync(path.join(root, 'src', 'PiPManager.Wpf', 'Services', 'ExtensionBridgeService.cs'), 'utf8');
const manifest = JSON.parse(fs.readFileSync(path.join(root, 'src', 'PiPManager.Extension', 'manifest.json'), 'utf8'));

assert(manifest.version === '1.4.39.25', 'manifest must be 1.4.39.25');
assert(content.includes("CONTENT_VERSION = '1.4.39.25-command-target-root-guard-hotfix10'"), 'content phase identifier must be synchronized');
assert(background.includes("BRIDGE_VERSION = '1.4.39.25-command-target-root-guard-hotfix10'"), 'background phase identifier must be synchronized');
assert(content.includes('let pipManagerNextTargetGeneration = 0'), 'target generation counter must exist');
assert(content.includes('let pipManagerNextTargetResolutionController = null'), 'strong cancellation controller must exist');
assert(content.includes("lifecycleState: 'RESOLVING_TARGET'"), 'target resolving state must exist');
assert(content.includes("updateNextTargetLifecycle('RESOLVING_MEDIA'"), 'media resolving state must exist');
assert(content.includes("updateNextTargetLifecycle('PRELOADING'"), 'preloading state must exist');
assert(content.includes("updateNextTargetLifecycle('READY'") || content.includes('range-preload-byte-cache-ready'), 'ready state must exist');
assert(content.includes('target.generation === pipManagerNextTargetState.generation'), 'stale target generations must be rejected');
assert(content.includes('target.operationId === pipManagerNextTargetState.operationId'), 'stale operation ids must be rejected');
assert(content.includes('resolvedTargetChangedWithinSameCurrent'), 'a changed next target under the same current item must receive a new generation');
assert(content.includes("abortNextTargetResolution('media-resolution-replaced')"), 'media resolution replacement must abort the prior operation');
assert(content.includes("window.addEventListener('pagehide'"), 'navigation must cancel active target/preload work');
assert(content.includes('sanitizeTargetThumbnail('), 'preview thumbnail must be validated against the authoritative target');
assert(content.includes('buildAuthoritativePreviewPayload(authoritativeTarget)') && content.includes('nextPreviewAssetId: targetResolved ? authoritativePreview.assetId'), 'preview must consume only authoritative resolved media');
assert(background.includes('nextTargetLifecycleState') && background.includes('nextTargetGeneration') && background.includes('nextTargetOperationId'), 'state-machine metadata must be forwarded');
assert(model.includes('NextTargetLifecycleState') && model.includes('NextTargetGeneration') && model.includes('NextTargetOperationId'), 'WPF model must carry target operation identity');
assert(bridge.includes('nextTargetLifecycleState') && bridge.includes('nextTargetGeneration') && bridge.includes('nextTargetOperationId'), 'bridge must parse target operation identity');
assert(main.includes('auto-return-same-video-fallback-deferred-target-resolution'), 'AutoReturn must defer stale same-video fallback');
assert(main.includes('resolverBlocksSameVideoFallback'), 'AutoReturn resolver gate must exist');
assert(main.includes('IsAuthoritativeNextPreview(') && main.includes('TARGET_RESOLVED'), 'preview must require a resolved target');
assert(main.includes('next-equals-current') && main.includes('preview-asset-not-authoritative'), 'preview must reject current asset duplication');

console.log('Next target state machine Phase 3 tests: OK');
