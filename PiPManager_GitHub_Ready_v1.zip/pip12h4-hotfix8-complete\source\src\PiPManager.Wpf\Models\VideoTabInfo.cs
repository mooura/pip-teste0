using System.Globalization;

namespace PiPManager.Wpf.Models;

public sealed class VideoTabInfo
{
    public string VideoSessionId { get; init; } = string.Empty;
    public string StableVideoKey { get; init; } = string.Empty;
    public int TabId { get; init; }
    public int BrowserWindowId { get; init; }
    public int FrameId { get; init; }
    public int VideoIndex { get; init; }
    public int DomIndex { get; init; }
    public int VisualRank { get; init; }
    public string PageInstanceId { get; init; } = string.Empty;
    public string ElementInstanceId { get; init; } = string.Empty;
    public string Title { get; init; } = string.Empty;
    public string Url { get; init; } = string.Empty;
    public string Domain { get; init; } = string.Empty;
    public int VideoCount { get; init; }
    public int IntrinsicVideoWidth { get; init; }
    public int IntrinsicVideoHeight { get; init; }
    public double IntrinsicAspectRatio => IntrinsicVideoWidth > 0 && IntrinsicVideoHeight > 0
        ? IntrinsicVideoWidth / (double)IntrinsicVideoHeight
        : 0.0;
    public bool IsPlaying { get; init; }
    public int ReadyState { get; init; }
    public bool IsPaused { get; init; }
    public bool IsEnded { get; init; }
    public bool HasSource { get; init; }
    public bool IsActiveTab { get; init; }
    public double CurrentTime { get; init; }
    public double Duration { get; init; }
    public long LastSeenUnixMs { get; init; }
    public bool PlaylistDetected { get; init; }
    public string SiteProfileId { get; init; } = string.Empty;
    public string SiteContentKind { get; init; } = "unknown";
    public string SiteNextStrategy { get; init; } = string.Empty;
    public string PlaylistTitle { get; init; } = string.Empty;
    public int PlaylistIndex { get; init; } = -1;
    public string CurrentItemTitle { get; init; } = string.Empty;
    public IReadOnlyList<string> NextTitles { get; init; } = Array.Empty<string>();
    public string NextPreviewTitle { get; init; } = string.Empty;
    public string NextPreviewThumbnailUrl { get; init; } = string.Empty;
    public string NextPreviewVideoUrl { get; init; } = string.Empty;
    public string NextPreviewAssetId { get; init; } = string.Empty;
    public string NextPreviewState { get; init; } = "EMPTY";
    public string NextPreviewDuration { get; init; } = string.Empty;
    public int NextPreviewIndex { get; init; } = -1;
    public string CurrentAssetId { get; init; } = string.Empty;
    public string NextAssetId { get; init; } = string.Empty;
    public string NextTargetStatus { get; init; } = "IDLE";
    public string NextTargetReason { get; init; } = string.Empty;
    public string NextTargetKey { get; init; } = string.Empty;
    public string NextTargetLifecycleState { get; init; } = "IDLE";
    public int NextTargetGeneration { get; init; }
    public string NextTargetOperationId { get; init; } = string.Empty;
    public string NextTargetPageUrl { get; init; } = string.Empty;

    // Estado visual calculado pelo MainWindow para a lista de preparar/vincular PiP.
    // Não participa do vínculo real; é apenas apresentação para evitar seleção duplicada/confusa.
    public int LinkedSlotNumber { get; set; }
    public int PreparedSlotNumber { get; set; }
    public bool IsPreparedForPip { get; set; }

    public string PickerSlotBadge
    {
        get
        {
            if (IsPreparedForPip && PreparedSlotNumber > 0) return $"PREPARADO → PiP {PreparedSlotNumber}";
            if (LinkedSlotNumber > 0) return $"JÁ NO PiP {LinkedSlotNumber}";
            return "DISPONÍVEL";
        }
    }

    public string PickerMainLine => CleanVideoName();

    public string PickerPlaylistLine
    {
        get
        {
            if (!PlaylistDetected) return string.Empty;
            var position = PlaylistIndex >= 0 ? $"item {PlaylistIndex + 1}" : "índice desconhecido";
            var current = string.IsNullOrWhiteSpace(CurrentItemTitle) ? CleanVideoName() : CurrentItemTitle.Trim();
            var next = NextTitles.Count == 0 ? "sem próximos títulos detectados" : $"próximos: {string.Join(" › ", NextTitles.Take(5))}";
            return $"Playlist • {position} • atual: {current} • {next}";
        }
    }

    public string PickerDetailLine
    {
        get
        {
            var state = IsPlaying ? "tocando" : "pausado";
            var domain = string.IsNullOrWhiteSpace(Domain) ? TryDomainFromUrl(Url) : Domain.Trim();
            return $"Aba {TabId} • Vídeo {VideoIndex + 1} • {domain} • {state} • {FormatTime(CurrentTime)}";
        }
    }

    public string PickerLinkLine
    {
        get
        {
            if (IsPreparedForPip && PreparedSlotNumber > 0)
                return $"Preparado para PiP {PreparedSlotNumber}";
            if (LinkedSlotNumber > 0)
                return $"Já vinculado ao PiP {LinkedSlotNumber}";
            return "Disponível";
        }
    }

    // Para vínculo manual/preparado, preferimos a sessão exata do elemento de vídeo.
    // StableVideoKey continua sendo enviado como fallback para o comando, mas não é usado
    // como chave primária porque vídeos parecidos na mesma página podem compartilhar sinais.
    public string PairKey => !string.IsNullOrWhiteSpace(VideoSessionId) ? VideoSessionId : (!string.IsNullOrWhiteSpace(StableVideoKey) ? StableVideoKey : $"tab-{TabId}-video-{VideoIndex}");

    public string DisplayTitle
    {
        get
        {
            var domain = string.IsNullOrWhiteSpace(Domain) ? TryDomainFromUrl(Url) : Domain.Trim();
            var title = string.IsNullOrWhiteSpace(Title) ? Url : Title.Trim();
            if (title.Length > 42) title = title[..42] + "...";
            var state = IsPlaying ? "▶" : "Ⅱ";
            var active = IsActiveTab ? "ativa" : $"aba {TabId}";
            var time = FormatTime(CurrentTime);
            var key = !string.IsNullOrWhiteSpace(ElementInstanceId) ? ShortId(ElementInstanceId) : (string.IsNullOrWhiteSpace(StableVideoKey) ? ShortId(VideoSessionId) : ShortId(StableVideoKey));
            return $"{state} {domain} — {time} — v{VideoIndex + 1} — {active} — {title} — el:{key}";
        }
    }

    public string ShortDescription
    {
        get
        {
            var domain = string.IsNullOrWhiteSpace(Domain) ? TryDomainFromUrl(Url) : Domain.Trim();
            return $"{domain} v{VideoIndex + 1} {FormatTime(CurrentTime)}";
        }
    }

    private string CleanVideoName()
    {
        var title = string.IsNullOrWhiteSpace(Title) ? Url : Title.Trim();

        // Remove contador do título do navegador, exemplo: "(2) Nome ...".
        while (title.StartsWith("(", StringComparison.Ordinal) && title.Contains(')'))
        {
            var close = title.IndexOf(')');
            if (close <= 0 || close + 1 >= title.Length) break;
            var inside = title[1..close];
            if (!inside.All(char.IsDigit)) break;
            title = title[(close + 1)..].Trim();
        }

        var markers = new[]
        {
            " Cam Model:",
            " Cam Model",
            " Free Live",
            " Live Sex",
            " | ",
            " - "
        };

        foreach (var marker in markers)
        {
            var idx = title.IndexOf(marker, StringComparison.OrdinalIgnoreCase);
            if (idx > 0)
            {
                title = title[..idx].Trim();
                break;
            }
        }

        if (string.IsNullOrWhiteSpace(title))
            title = string.IsNullOrWhiteSpace(Domain) ? TryDomainFromUrl(Url) : Domain.Trim();

        return title.Length > 54 ? title[..54] + "..." : title;
    }

    private static string ShortId(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return "sem-id";
        return value.Length <= 12 ? value : value[..12];
    }

    private static string FormatTime(double seconds)
    {
        if (seconds <= 0 || double.IsNaN(seconds) || double.IsInfinity(seconds)) return "00:00";
        var span = TimeSpan.FromSeconds(seconds);
        return span.TotalHours >= 1
            ? $"{(int)span.TotalHours}:{span.Minutes:00}:{span.Seconds:00}"
            : $"{span.Minutes:00}:{span.Seconds:00}";
    }

    private static string TryDomainFromUrl(string url)
    {
        try
        {
            return Uri.TryCreate(url, UriKind.Absolute, out var uri) ? uri.Host.Replace("www.", string.Empty, StringComparison.OrdinalIgnoreCase) : "site";
        }
        catch
        {
            return "site";
        }
    }
}
