$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$xaml = Get-Content (Join-Path $root 'src\PiPManager.Wpf\MainWindow.xaml') -Raw
$main = Get-Content (Join-Path $root 'src\PiPManager.Wpf\MainWindow.xaml.cs') -Raw
$settings = Get-Content (Join-Path $root 'src\PiPManager.Wpf\Models\AppSettings.cs') -Raw
$slot = Get-Content (Join-Path $root 'src\PiPManager.Wpf\Models\PipSlot.cs') -Raw
$checks = [ordered]@{
  'permanent extension indicator' = $xaml.Contains('ExtensionStatusText') -and $xaml.Contains('ExtensionStatusDot')
  'reactor mode indicator' = $xaml.Contains('ReactorModeText') -and $main.Contains('GetReactorCaptureMode()')
  'visible automatic capture toggle' = $xaml.Contains('AutomaticCaptureToggle') -and $main.Contains('automatic-reactor-capture-setting-changed')
  'automatic capture persisted' = $settings.Contains('AutomaticReactorCaptureEnabled') -and $main.Contains('_settings.AutomaticReactorCaptureEnabled')
  'reactor adoption honors toggle' = $main.Contains('reason=automatic-capture-disabled')
  'open buttons disabled during attempt' = $main.Contains('UpdateOpenPipButtonsState') -and $xaml.Contains('OpenPipManualButton')
  'friendly slot states' = $slot.Contains('Aguardando PiP') -and $slot.Contains('Reconectando') -and $slot.Contains('Capturado')
}
$failed=0
foreach($item in $checks.GetEnumerator()) { $ok=[bool]$item.Value; Write-Host ($item.Key + ': ' + $(if($ok){'OK'}else{'FAIL'})); if(-not $ok){$failed++} }
if($failed -gt 0){ throw 'Connection and capture UX checks failed.' }
Write-Host 'Connection and capture UX checks OK.'
