﻿using System.IO;

namespace PiPManager.Wpf.Services;

public interface IShadowDiagnosticsService
{
    string ReportDirectory { get; }
    string Redact(string? value);
}

public sealed class ShadowDiagnosticsService : IShadowDiagnosticsService
{
    public string ReportDirectory
    {
        get
        {
            var appData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            if (string.IsNullOrWhiteSpace(appData))
                appData = AppDomain.CurrentDomain.BaseDirectory;

            return Path.Combine(appData, "PiPManager", "ShadowParityReports");
        }
    }

    public string Redact(string? value)
    {
        if (string.IsNullOrWhiteSpace(value))
            return "-";

        var text = value.Replace("\r", " ").Replace("\n", " ").Trim();

        if (text.Contains("://", StringComparison.OrdinalIgnoreCase))
            return "[url-redacted]";

        if (text.Length > 80)
            return text[..80] + "...";

        return text;
    }
}
