﻿using PiPManager.Wpf.Services;

static void AssertTrue(bool condition, string message)
{
    if (!condition)
        throw new InvalidOperationException(message);
}

var health = new FakeHealthService();
using var monitor = new WindowsEventMonitorService(health);
var fake = new FakeWindowEventMonitorSource(monitor);
var hwnd = new IntPtr(0x123456);

var snapshot = fake.EmitCreateMoveDuplicateDestroyForTest(hwnd);

AssertTrue(snapshot.TotalReceived == 3, $"expected 3 received events, got {snapshot.TotalReceived}");
AssertTrue(snapshot.TotalDiscarded == 1, $"expected 1 discarded duplicate, got {snapshot.TotalDiscarded}");
AssertTrue(snapshot.LastEventKind == WindowMonitorEventKind.Destroyed.ToString(), $"expected last event Destroyed, got {snapshot.LastEventKind}");
AssertTrue(health.WindowEventsReceived == 3, $"health received mismatch: {health.WindowEventsReceived}");
AssertTrue(health.WindowEventsDiscarded == 1, $"health discarded mismatch: {health.WindowEventsDiscarded}");
AssertTrue(health.LastWindowEvent.Contains("Destroyed", StringComparison.OrdinalIgnoreCase), "health last event should contain Destroyed");
AssertTrue(health.LastWindowEvent.Contains("destroy-from-cache", StringComparison.OrdinalIgnoreCase), "destroy should be identified from HWND cache");

Console.WriteLine("WindowEventMonitor fake sequence OK.");

var suppressionHealth = new FakeHealthService();
var flowControl = new WindowEventFlowControlService();
using var suppressionMonitor = new WindowsEventMonitorService(suppressionHealth, flowControl);
var suppressionFake = new FakeWindowEventMonitorSource(suppressionMonitor);
var suppressedHwnd = new IntPtr(0x234567);

flowControl.ArmInternalMovementSuppression(
    new[] { suppressedHwnd },
    generation: 7,
    duration: TimeSpan.FromSeconds(1),
    source: "fake-layout-test");
suppressionFake.EmitMove(suppressedHwnd);

var suppressionSnapshot = suppressionMonitor.GetSnapshotForTest();
var flowSnapshot = flowControl.GetSnapshot();
AssertTrue(suppressionSnapshot.TotalReceived == 0, $"suppressed movement should not be received, got {suppressionSnapshot.TotalReceived}");
AssertTrue(suppressionSnapshot.TotalDiscarded == 1, $"suppressed movement should be discarded once, got {suppressionSnapshot.TotalDiscarded}");
AssertTrue(flowSnapshot.SuppressedInternalMovements == 1, $"flow control suppression count mismatch: {flowSnapshot.SuppressedInternalMovements}");
AssertTrue(flowSnapshot.LastGeneration == 7, $"flow control generation mismatch: {flowSnapshot.LastGeneration}");
AssertTrue(flowSnapshot.LastSource == "fake-layout-test", $"flow control source mismatch: {flowSnapshot.LastSource}");

Console.WriteLine("WindowEventMonitor movement flow-control sequence OK.");

using (var protocolDocument = System.Text.Json.JsonDocument.Parse("""
{
  "title": "Current video",
  "videoIndex": 3,
  "nextPreviewIndex": -1,
  "duration": 125.5,
  "playing": true,
  "nextTitles": ["Two", "Three", "Four", "Five", "Six", "Ignored"]
}
"""))
{
    var root = protocolDocument.RootElement;
    AssertTrue(ExtensionProtocolReader.GetString(root, "title") == "Current video", "protocol title parsing failed");
    AssertTrue(ExtensionProtocolReader.GetInt(root, "videoIndex") == 3, "protocol integer parsing failed");
    AssertTrue(ExtensionProtocolReader.GetInt(root, "missing", -1) == -1, "protocol default integer failed");
    AssertTrue(Math.Abs(ExtensionProtocolReader.GetDouble(root, "duration") - 125.5) < 0.001, "protocol double parsing failed");
    AssertTrue(ExtensionProtocolReader.GetBool(root, "playing"), "protocol boolean parsing failed");
    AssertTrue(ExtensionProtocolReader.GetStringList(root, "nextTitles").Count == 5, "protocol next-title bound failed");
}

Console.WriteLine("Extension protocol reader sequence OK.");

AssertTrue(AutoReturnPolicyCodec.Parse("Discrete") == PiPManager.Wpf.Models.AutoReturnPolicy.Discrete, "discrete AutoReturn policy parsing failed");
AssertTrue(AutoReturnPolicyCodec.Parse("Silencioso") == PiPManager.Wpf.Models.AutoReturnPolicy.Discrete, "legacy silent policy migration failed");
AssertTrue(AutoReturnPolicyCodec.Parse("unexpected") == PiPManager.Wpf.Models.AutoReturnPolicy.Off, "unknown AutoReturn policy must be off");
AssertTrue(AutoReturnPolicyCodec.Format(PiPManager.Wpf.Models.AutoReturnPolicy.Discrete) == "Discreto", "AutoReturn policy formatting failed");

Console.WriteLine("AutoReturn policy codec sequence OK.");

AssertTrue(RuntimeAuthorityPolicy.Resolve(null) == PiPManager.Wpf.Models.ReactorCaptureMode.Compare, "reactor authority default must remain Compare");
AssertTrue(RuntimeAuthorityPolicy.Resolve("primary") == PiPManager.Wpf.Models.ReactorCaptureMode.Primary, "reactor Primary authority parsing failed");
AssertTrue(RuntimeAuthorityPolicy.Resolve("legacy") == PiPManager.Wpf.Models.ReactorCaptureMode.Legacy, "reactor Legacy authority parsing failed");
AssertTrue(RuntimeAuthorityPolicy.Resolve("invalid") == PiPManager.Wpf.Models.ReactorCaptureMode.Compare, "invalid reactor authority must be safe Compare");

Console.WriteLine("Runtime authority policy sequence OK.");

var transform = new GroupTransformEngine();
var originalLayout = new Dictionary<int, PiPManager.Wpf.Models.NativeRect>
{
    [1] = new(500, 100, 820, 280),
    [2] = new(820, 100, 1140, 280),
    [7] = new(2100, 280, 2420, 460),
    [8] = new(2100, 460, 2420, 640)
};
var relativeTemplate = transform.Capture(originalLayout, "DISPLAY-A");
AssertTrue(relativeTemplate.AnchorX == 500 && relativeTemplate.AnchorY == 100, "relative layout anchor capture failed");
AssertTrue(relativeTemplate.Slots.Single(item => item.SlotNumber == 7).OffsetX == 1600, "relative topology offset capture failed");

var translatedTemplate = transform.Translate(relativeTemplate, 120, 80);
var translated = transform.Materialize(translatedTemplate, new(0, 0, 4000, 2000));
AssertTrue(translated[1] == new PiPManager.Wpf.Models.NativeRect(620, 180, 940, 360), "group translation must move slot 1 once");
AssertTrue(translated[7] == new PiPManager.Wpf.Models.NativeRect(2220, 360, 2540, 540), "group translation must preserve the L topology");
AssertTrue(translated[1].Right == translated[2].Left, "adjacent visual rectangles must have an exact seam");

var clamped = transform.Materialize(
    transform.Translate(relativeTemplate, 5000, 5000),
    new PiPManager.Wpf.Models.NativeRect(0, 0, 3000, 1200));
var originalDx = originalLayout[7].Left - originalLayout[1].Left;
var clampedDx = clamped[7].Left - clamped[1].Left;
AssertTrue(originalDx == clampedDx, "monitor clamping must translate the group without deforming offsets");

var oversizedTemplate = transform.Capture(
    new Dictionary<int, PiPManager.Wpf.Models.NativeRect>
    {
        [1] = new(0, 0, 1000, 500),
        [2] = new(1000, 0, 2000, 500),
        [3] = new(1000, 500, 2000, 1000)
    },
    "DISPLAY-A");
var fittedOversized = transform.Materialize(
    oversizedTemplate,
    new PiPManager.Wpf.Models.NativeRect(0, 0, 1920, 1080));
var fittedBounds = new PiPManager.Wpf.Models.NativeRect(
    fittedOversized.Values.Min(rect => rect.Left),
    fittedOversized.Values.Min(rect => rect.Top),
    fittedOversized.Values.Max(rect => rect.Right),
    fittedOversized.Values.Max(rect => rect.Bottom));
AssertTrue(fittedBounds.Left >= 8 && fittedBounds.Right <= 1912, "oversized saved layout must fit the monitor work area");
AssertTrue(fittedBounds.Top >= 8 && fittedBounds.Bottom <= 1072, "oversized saved layout must fit vertically");
AssertTrue(fittedOversized[1].Right == fittedOversized[2].Left, "scaled layout must preserve exact horizontal seams");
AssertTrue(fittedOversized[2].Bottom == fittedOversized[3].Top, "scaled layout must preserve exact vertical seams");

var overlappedAfterPortraitChange = new Dictionary<int, PiPManager.Wpf.Models.NativeRect>
{
    [1] = new(1380, 8, 1636, 152),
    [2] = new(1636, 8, 1892, 377),
    [3] = new(1636, 152, 1892, 297),
    [4] = new(1636, 296, 1892, 441)
};
var reflowed = transform.ReflowWithoutOverlap(
    overlappedAfterPortraitChange,
    new PiPManager.Wpf.Models.NativeRect(0, 0, 1920, 1080));
AssertTrue(reflowed[2].Bottom == reflowed[3].Top, "portrait reflow must place the next slot at the exact lower seam");
AssertTrue(reflowed[3].Bottom == reflowed[4].Top, "portrait reflow must preserve an overlap-free vertical sequence");
AssertTrue(reflowed[1].Right == reflowed[2].Left, "portrait reflow must preserve the horizontal seam before the vertical column");

var anchoredReflow = transform.ReflowFromChangedSlots(
    overlappedAfterPortraitChange,
    [2],
    new PiPManager.Wpf.Models.NativeRect(0, 0, 1920, 1080));
AssertTrue(anchoredReflow[2] == overlappedAfterPortraitChange[2], "changed portrait slot must remain anchored");
AssertTrue(anchoredReflow[1] == overlappedAfterPortraitChange[1], "unaffected non-overlapping slot must remain unchanged");
AssertTrue(anchoredReflow[2].Bottom == anchoredReflow[3].Top, "only the colliding neighbor must move to the exact seam");
AssertTrue(anchoredReflow[3].Bottom == anchoredReflow[4].Top, "collision propagation must keep the remaining column overlap-free");

var browserNaturalResize = new Dictionary<int, PiPManager.Wpf.Models.NativeRect>
{
    [1] = new(100, 100, 220, 180),
    [2] = new(300, 100, 500, 180),
    [3] = new(300, 180, 500, 260)
};
var naturalSizeMosaic = transform.ReflowNaturalSizesAsConnectedMosaic(
    browserNaturalResize,
    [1],
    new PiPManager.Wpf.Models.NativeRect(0, 0, 1920, 1080));
AssertTrue(naturalSizeMosaic[1].Width == 120 && naturalSizeMosaic[1].Height == 80,
    "automatic reflow must preserve the browser size of the changed PiP");
AssertTrue(naturalSizeMosaic[2].Width == 200 && naturalSizeMosaic[2].Height == 80,
    "automatic reflow must preserve every unaffected PiP size");
AssertTrue(naturalSizeMosaic[1].Right == naturalSizeMosaic[2].Left,
    "a size reduction must pull the disconnected neighbor back to the exact seam");
AssertTrue(naturalSizeMosaic[2].Bottom == naturalSizeMosaic[3].Top,
    "the remaining custom-layout component must retain its internal topology");

var disconnectedStair = new[]
{
    new PiPManager.Wpf.Models.NativeRect(100, 100, 220, 180),
    new PiPManager.Wpf.Models.NativeRect(300, 260, 420, 340),
    new PiPManager.Wpf.Models.NativeRect(420, 260, 540, 340)
};
var connectedStair = transform.EnsureSingleConnectedMosaic(
    disconnectedStair,
    new PiPManager.Wpf.Models.NativeRect(0, 0, 1920, 1080));
static bool SharesEdge(PiPManager.Wpf.Models.NativeRect a, PiPManager.Wpf.Models.NativeRect b)
{
    var verticalOverlap = Math.Min(a.Bottom, b.Bottom) - Math.Max(a.Top, b.Top);
    var horizontalOverlap = Math.Min(a.Right, b.Right) - Math.Max(a.Left, b.Left);
    return (verticalOverlap > 0 && (a.Right == b.Left || b.Right == a.Left))
        || (horizontalOverlap > 0 && (a.Bottom == b.Top || b.Bottom == a.Top));
}
AssertTrue(connectedStair.Any(rect => SharesEdge(connectedStair[0], rect) && rect != connectedStair[0]), "disconnected free-layout component must attach to the mosaic");
AssertTrue(connectedStair[2].Left - connectedStair[1].Left == disconnectedStair[2].Left - disconnectedStair[1].Left, "internal stair topology must be preserved while attaching components");

Console.WriteLine("Relative group transform sequence OK.");

var aspectSlot = new PiPManager.Wpf.Models.EditableSlotRect(1, 0, 0, 72, 66)
{
    State = PiPManager.Wpf.Models.PipSlotState.Active
};
AssertTrue(aspectSlot.UpdatePreviewAspect(640.0 / 1120.0), "portrait aspect update should be observed");
AssertTrue(aspectSlot.IsPortraitAppearance, "640x1120 must be classified as portrait");
AssertTrue(aspectSlot.PreviewHeight > aspectSlot.PreviewWidth, "portrait slot preview must be visually vertical");
AssertTrue(aspectSlot.DetailText.Contains("Vertical", StringComparison.Ordinal), "portrait slot label must expose its appearance");

AssertTrue(aspectSlot.UpdatePreviewAspect(1280.0 / 720.0), "landscape aspect update should be observed");
AssertTrue(!aspectSlot.IsPortraitAppearance, "1280x720 must use the normal appearance");
AssertTrue(aspectSlot.PreviewWidth > aspectSlot.PreviewHeight, "normal slot preview must be visually horizontal");

Console.WriteLine("Slot visual aspect sequence OK.");

sealed class FakeHealthService : IApplicationHealthService
{
    public bool BridgeActive => false;
    public string ConnectedExtensionVersion => string.Empty;
    public bool PipDragHookActive => false;
    public int SlotCount => 0;
    public string CoreExecutionMode => "ShadowOnly";
    public string LastOperationalError { get; private set; } = string.Empty;
    public bool WindowEventHookActive { get; private set; }
    public string LastWindowEvent { get; private set; } = string.Empty;
    public long WindowEventsReceived { get; private set; }
    public long WindowEventsDiscarded { get; private set; }
    public string LastWindowEventHookFailure { get; private set; } = string.Empty;

    public void SetBridgeActive(bool active) { }
    public void SetPipDragHookActive(bool active) { }
    public void SetSlotCount(int slotCount) { }
    public void ReportOperationalError(string message) => LastOperationalError = message;
    public void SetWindowEventHookActive(bool active) => WindowEventHookActive = active;
    public void SetLastWindowEvent(string value) => LastWindowEvent = value;
    public void SetWindowEventTotals(long received, long discarded)
    {
        WindowEventsReceived = received;
        WindowEventsDiscarded = discarded;
    }
    public void SetWindowEventHookFailure(string value) => LastWindowEventHookFailure = value;
}
