# PiPManager Fix4 RC6 - Setup & Build Guide

## Overview

This guide covers building, testing, and deploying the **Fix4 RC6** release of PiPManager.

**Branch**: `fix4-rc6`  
**Application Version**: 9.39.03  
**Extension Version**: 1.4.39.7  
**Status**: Stable Release Candidate

## System Requirements

### Minimum
- **OS**: Windows 10 (build 1909) or Windows 11
- **.NET Runtime**: 8.0 or later (Desktop Runtime required)
- **RAM**: 2GB minimum
- **Disk Space**: 500MB for build artifacts

### Development
- **Visual Studio**: 2022 (Community, Professional, or Enterprise)
- **.NET SDK**: 8.0 or later
- **PowerShell**: 5.0 or later
- **Git**: Latest version
- **Firefox**: 90+ (for extension testing)

## Installation

### 1. Clone the Repository

```bash
git clone https://github.com/pip-teste/PiPManager.git
cd PiPManager
git checkout fix4-rc6
```

### 2. Verify .NET Installation

```powershell
dotnet --version
# Should output 8.x.x or higher
```

### 3. Install Dependencies

The build script will automatically restore NuGet packages. For manual installation:

```powershell
dotnet restore
```

## Building the Application

### Quick Build (Release)

```powershell
cd "PiPManager_9.39.03_FIX4_RC3_P0_OPTIMIZATION_RC6_SOURCE"

# Method 1: Using BUILD script
.\BUILD_WINDOWS.bat

# Method 2: Using PowerShell
dotnet build -c Release
```

### Build Output

- **Release Build**: `bin\Release\`
- **Debug Build**: `bin\Debug\`
- **Artifacts**: Executable and supporting DLLs

### Build Options

```powershell
# Debug build with diagnostics
dotnet build -c Debug -v diagnostic

# Release build with specific runtime
dotnet build -c Release -r win-x64

# Clean and rebuild
dotnet clean
dotnet build -c Release
```

## Testing

### Unit Tests

```powershell
# Run all tests
dotnet test

# Run specific test project
dotnet test YourTestProject.csproj

# Run with detailed output
dotnet test -v normal
```

### Manual Testing Checklist

1. **Application Launch**
   - [ ] Application starts without errors
   - [ ] UI loads correctly
   - [ ] Settings are accessible

2. **Tab Occupancy Detection**
   - [ ] Open multiple tabs with videos
   - [ ] Verify tab occupancy notifications appear
   - [ ] Check notification accuracy

3. **PiP Restoration**
   - [ ] Launch PiP window
   - [ ] Close and restart application
   - [ ] Verify PiP window is restored

4. **Layout Management**
   - [ ] Test layout switching
   - [ ] Verify no crashes on layout changes
   - [ ] Check window positioning accuracy

5. **Video Platform Support**
   - [ ] Test YouTube videos
   - [ ] Test Vimeo videos
   - [ ] Test Dailymotion videos
   - [ ] Test Twitch streams

6. **Firefox Extension**
   - [ ] Install extension (see below)
   - [ ] Verify communication with app
   - [ ] Test content script injection
   - [ ] Verify PiP launches from browser

### Debug Testing

```powershell
# Run with DEBUG build
dotnet build -c Debug
# Then test with debugger in Visual Studio
```

### Performance Testing

```powershell
# Run release build for performance
dotnet build -c Release -r win-x64

# Measure startup time
measure-command { .\bin\Release\PiPManager.exe }
```

## Firefox Extension

### Installation (Development)

1. **Open Firefox**
   ```
   Type in address bar: about:debugging#/runtime/this-firefox
   ```

2. **Load Extension**
   - Click "Load Temporary Add-on"
   - Navigate to `Extension/manifest.json`
   - Select the file

3. **Verify Installation**
   - Extension appears in Firefox menu
   - Communication with app works
   - Content scripts inject correctly

### Installation (Production)

The packaged extension (.xpi file) can be installed by:
1. Signing the extension through Firefox Developer Network
2. Distributing through Mozilla Add-ons store
3. Direct installation from file (.xpi)

### Testing Extension Features

```powershell
# Package extension for distribution
# See BUILD_RELEASE.bat for packaging steps
```

## Packaging for Distribution

### Create Release Build

```powershell
.\BUILD_RELEASE.bat
```

Output includes:
- Application executable
- Runtime dependencies
- Extension package (.xpi)
- Documentation files

### Distribution Package Contents

```
PiPManager_Fix4_RC6_Release/
├── PiPManager.exe
├── Dependencies/
│   └── [Required DLLs]
├── Extension/
│   └── PiPManager_1.4.39.7.xpi
├── Documentation/
│   ├── README.md
│   ├── SETUP.md
│   └── CHANGELOG.md
└── LICENSE
```

## Configuration

### Application Settings

Settings are stored in:
- **Windows**: `%APPDATA%\PiPManager\settings.json`

### Default Configuration

```json
{
  "autoRestore": true,
  "multiSlot": true,
  "tabOccupancy": true,
  "debug": false
}
```

### Modifying Settings

1. Close the application
2. Edit `settings.json`
3. Restart application

## Troubleshooting

### Application Won't Start

```powershell
# Check .NET runtime
dotnet --info

# Verify dependencies
Get-ChildItem bin\Release\*.dll

# Run with diagnostics
.\PiPManager.exe --verbose
```

### Build Failures

```powershell
# Clean solution
dotnet clean

# Clear NuGet cache
dotnet nuget locals all --clear

# Restore and rebuild
dotnet restore
dotnet build -c Release
```

### Extension Not Loading

1. Verify manifest.json is valid
2. Check Firefox console for errors
3. Ensure extension and app versions match
4. Reload extension in about:debugging

### Tab Occupancy Not Working

1. Verify browser extension is installed
2. Check Firefox developer console
3. Ensure multiple tabs have videos
4. Restart both app and browser

### Performance Issues

1. Monitor CPU usage during operation
2. Check Task Manager for resource usage
3. Review error logs in app directory
4. Profile with Visual Studio profiler

## Deployment

### Local Deployment

```powershell
# Copy release build to program folder
$source = ".\bin\Release\*"
$dest = "C:\Program Files\PiPManager\"
Copy-Item $source $dest -Recurse -Force

# Create shortcut (optional)
# Run installer script if provided
```

### Uninstallation

```powershell
# Remove program folder
Remove-Item "C:\Program Files\PiPManager\" -Recurse

# Remove settings (optional)
Remove-Item "$env:APPDATA\PiPManager\" -Recurse
```

## Advanced Topics

### Building for Specific Runtime

```powershell
# 64-bit Windows
dotnet publish -c Release -r win-x64

# 32-bit Windows
dotnet publish -c Release -r win-x86
```

### Custom Build Configuration

Edit `.csproj` files to modify:
- Target frameworks
- Output location
- Version information
- Resource inclusion

### Debugging

1. Open solution in Visual Studio 2022
2. Set breakpoints
3. Start debugging (F5)
4. Use Watch windows for variable inspection
5. Use Immediate window for runtime evaluation

## Version Information

- **Application**: 9.39.03
- **Extension**: 1.4.39.7
- **Build Date**: 2026-08-05
- **Stability**: Stable (RC)

## Support & Issues

### Reporting Issues

Include:
1. Complete error message
2. Steps to reproduce
3. System information (Windows version, .NET version)
4. Application version (Help → About)

### Getting Help

1. Check GitHub issues
2. Review documentation
3. Create detailed issue report
4. Follow up with additional information

## Related Documentation

- **README.md** - Project overview
- **VERSIONS.md** - Version history and features
- **CONTRIBUTING.md** - Contribution guidelines
- **LICENSE** - License information

---

**Last Updated**: 2026-08-05  
**Branch**: fix4-rc6  
**Maintainers**: PiPManager Team
