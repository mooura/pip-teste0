$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path

function Check([string]$label, [bool]$condition) {
    if (-not $condition) { throw "FAIL: $label" }
    Write-Host "$label`: OK"
}

$main = Get-Content -Raw -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\MainWindow.xaml.cs')
$background = Get-Content -Raw -LiteralPath (Join-Path $root 'src\PiPManager.Extension\background.js')
$content = Get-Content -Raw -LiteralPath (Join-Path $root 'src\PiPManager.Extension\content.js')
$profiles = Get-Content -Raw -LiteralPath (Join-Path $root 'src\PiPManager.Extension\site-profiles.js')
$boundariesPath = Join-Path $root 'docs\stabilization\layer-boundaries.json'
$baselinePath = Join-Path $root 'docs\stabilization\BASELINE_9_39_01.md'

Check 'stabilization baseline exists' (Test-Path -LiteralPath $baselinePath)
Check 'layer ownership manifest exists' (Test-Path -LiteralPath $boundariesPath)
$boundaries = Get-Content -Raw -LiteralPath $boundariesPath | ConvertFrom-Json
Check 'five functional boundaries declared' (@($boundaries.layers.PSObject.Properties).Count -eq 5)

Check 'manual Next remains exact-tab scoped' ($background.Contains("match = 'manual-same-tab-navigation'") -and $background.Contains('allowSameTabNavigation'))
Check 'manual Next remains frame-targeted' ($background.Contains('sendMessageToTabFrame(tabId, targetFrameId') -and $background.Contains('sendMessageToTabFrame(tabId, retryFrameId'))
Check 'terminal advance remains a separate path' ($background.Contains('terminal-same-tab-no-video-target') -and $content.Contains('pipManagerPlaybackTerminal'))

Check 'Open All continues after an incompatible source' ($main.Contains('failFast=False; continueBatch=True'))
Check 'Open All cleans only its failed reservation' ($main.Contains('Abrir todos/ignorar fonte incompatível'))
Check 'Open All remains dynamic for ten slots' ($main.Contains('var slotCapacity = Slots.Count;') -and $main.Contains('for (var index = 0; index < pending.Count; index++)'))

Check 'AutoReturn remains serialized' ($main.Contains('auto-return-serialization-acquired') -and $main.Contains('auto-return-serialization-released'))
Check 'AutoReturn still requires slot policy' ($main.Contains('IsAutoReturnEnabledForSlot(slot.Number)') -and $main.Contains('policy=SlotDiscrete'))

Check 'capability profiles remain generic' ($profiles.Contains("id: 'indexed-playlist'") -and $profiles.Contains("id: 'player-controls'") -and $profiles.Contains("id: 'generic-player'"))

Write-Host 'Stabilization boundary checks OK.' -ForegroundColor Green
