$ErrorActionPreference = "Stop"
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$main = Get-Content (Join-Path $root "src\PiPManager.Wpf\MainWindow.xaml.cs") -Raw
$coreTests = Get-Content (Join-Path $root "RUN_CORE_TESTS.bat") -Raw
$checks = [ordered]@{
  "generation dictionary" = $main.Contains("_autoReturnCancellationGenerationBySlot")
  "state generation" = $main.Contains("CancellationGeneration = GetAutoReturnCancellationGeneration")
  "cancel increments generation" = $main.Contains("GetAutoReturnCancellationGeneration(slotNumber) + 1")
  "before preflight" = $main.Contains('"before-preflight-send"')
  "before silent send" = $main.Contains('"before-silent-open-send"')
  "before shortcut" = $main.Contains('"immediately-before-shortcut-send"')
  "cooldown not terminal alone" = $main.Contains("if (hadPendingState || hadReconnectAttempt)")
  "checker included in core gate" = $coreTests.Contains("CHECK_AUTORETURN_INFLIGHT_CANCELLATION.ps1")
  "silent success classified before cancellation" = $main.IndexOf("if (silentReopenOk)") -lt $main.IndexOf('IsAutoReturnAttemptCurrent(slot, state, attemptId, "after-silent-stage")')
  "focusless success classified before cancellation" = $main.IndexOf("if (focuslessOk)") -lt $main.IndexOf('IsAutoReturnAttemptCurrent(slot, state, attemptId, "after-focusless-stage")')
}
$failed = @($checks.GetEnumerator() | Where-Object { -not $_.Value })
$checks.GetEnumerator() | ForEach-Object { "{0}: {1}" -f $_.Key, $(if ($_.Value) {"OK"} else {"FAIL"}) }
if ($failed.Count -gt 0) { throw "AutoReturn in-flight cancellation checks failed." }
"AutoReturn in-flight cancellation checks OK."
