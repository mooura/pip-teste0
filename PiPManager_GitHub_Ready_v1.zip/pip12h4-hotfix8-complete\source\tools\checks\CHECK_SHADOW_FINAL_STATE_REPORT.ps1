$ErrorActionPreference = "Stop"
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$servicePath = Join-Path $root "src\PiPManager.Wpf\Services\ShadowParityReportService.cs"
$service = Get-Content $servicePath -Raw

foreach ($required in @(
  "FinalStateBySlot",
  "finalExpectedFailure",
  "lastAutoReturnOffExpectedFailure",
  "autoreturn-disabled",
  "finalPotentialDivergence"
)) {
  if (!$service.Contains($required)) {
    throw "Final state report refinement missing marker: $required"
  }
}

Write-Host "Shadow final state report checks OK."
