$ErrorActionPreference = 'Stop'
$root = Resolve-Path (Join-Path $PSScriptRoot '..\..')
$main = Get-Content (Join-Path $root 'src\PiPManager.Wpf\MainWindow.xaml.cs') -Raw
$state = Get-Content (Join-Path $root 'src\PiPManager.Wpf\Models\AutoReturnSlotState.cs') -Raw
$policy = Get-Content (Join-Path $root 'src\PiPManager.Core\Core\Automation\AutoReturnBurstPolicy.cs') -Raw
$content = Get-Content (Join-Path $root 'src\PiPManager.Extension\content.js') -Raw
$manifest = Get-Content (Join-Path $root 'src\PiPManager.Extension\manifest.json') -Raw
$checks = [ordered]@{
  'manifest is 1.4.39.25' = $manifest.Contains('"version": "1.4.39.25"')
  'terminal generation is dedicated' = $state.Contains('TerminalNavigationGeneration') -and $main.Contains('_terminalAutoNextGenerationBySlot')
  'URL-only transition is pending' = $main.Contains('URL isolada é apenas NAVIGATION_PENDING') -and $main.Contains('auto-return-terminal-navigation-pending') -and $policy.Contains('IsTerminalVideoChangeConfirmed')
  'terminal deadlines are bounded' = $main.Contains('AutoReturnTerminalTargetUnavailableMs = 4000') -and $main.Contains('AutoReturnTerminalPassiveWatchMs = 8000')
  'deferral policy is strictly bounded' = $policy.Contains('readinessDeferrals < Math.Max(0, maxReadinessDeferrals)') -and -not $policy.Contains('hardNotReady || readinessDeferrals')
  'passive watch replaces retry loop' = $main.Contains('auto-return-terminal-readiness-bound-reached') -and $main.Contains('action=passive-structural-watch')
  'terminal fallback has separate identity' = $main.Contains('auto-return-same-video-fallback-blocked-terminal-generation')
  'preload abort proves auxiliary ownership' = $content.Contains('isOwnedNextPreloadVideo') -and $content.Contains('network-pause-blocked-operational-video')
}
$failed = @()
foreach ($entry in $checks.GetEnumerator()) {
  if ($entry.Value) { Write-Host ($entry.Key + ': OK') -ForegroundColor Green }
  else { Write-Host ($entry.Key + ': FAIL') -ForegroundColor Red; $failed += $entry.Key }
}
if ($failed.Count -gt 0) { throw ('Terminal Auto-Next Bounded Readiness Hotfix 5 checks failed: ' + ($failed -join ', ')) }
Write-Host 'Terminal Auto-Next Bounded Readiness Hotfix 5 checks OK.' -ForegroundColor Green
