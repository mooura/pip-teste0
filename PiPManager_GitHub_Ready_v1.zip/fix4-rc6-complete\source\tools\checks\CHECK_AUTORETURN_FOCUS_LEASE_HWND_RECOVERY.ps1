$ErrorActionPreference = "Stop"
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$main = Get-Content (Join-Path $root "src\PiPManager.Wpf\MainWindow.xaml.cs") -Raw
$run = Get-Content (Join-Path $root "RUN_CORE_TESTS.bat") -Raw
$failed = 0
function Check($name, $ok) { if ($ok) { Write-Host "$name`: OK" } else { Write-Host "$name`: FAIL"; $script:failed++ } }
Check "foreground lease after shortcut" ($main.Contains('const int foregroundLeaseMs = 350'))
Check "focus restored after lease" ($main.Contains('auto-return-focusless-foreground-lease-ended'))
Check "two-phase HWND confirmation" ($main.Contains('phase: "foreground-lease"') -and $main.Contains('phase: "post-focus-restore"'))
Check "directed final HWND sweep" ($main.Contains('TryDirectedAutoReturnHwndRecovery'))
Check "directed sweep excludes previous handles" ($main.Contains('!_armedPipExistingHandles.Contains(window.Handle)'))
Check "directed sweep rejects ambiguity" ($main.Contains('ambiguous-candidates'))
Check "directed sweep requires armed attempt match" ($main.Contains('reason=armed-attempt-mismatch'))
Check "checker included in core gate" ($run.Contains('CHECK_AUTORETURN_FOCUS_LEASE_HWND_RECOVERY.ps1'))
if ($failed -gt 0) { throw "AutoReturn focus lease HWND recovery checks failed." }
Write-Host "AutoReturn focus lease HWND recovery checks OK."
