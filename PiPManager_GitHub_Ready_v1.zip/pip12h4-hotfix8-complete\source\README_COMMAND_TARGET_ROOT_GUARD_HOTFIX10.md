# Hotfix 10 — Authoritative indexless CommandTarget + playlist root guard

## Escopo

Correção isolada do bloqueio de Próximo quando a extensão possui `nextAssetId`, `generation` e `operationId`, mas a playlist não expõe índices na URL.

## Regras

- `currentIndex=-1` e `nextIndex=-1` não invalidam um alvo com identidade forte.
- `nextPreviewAssetId`, quando presente, deve ser igual ao `nextAssetId`.
- A recuperação pode usar um único alvo autoritativo da mesma aba vinculada.
- `/playlists` e `/playlist` sem item não são player, alvo de comando ou candidato de AutoReturn.
- `Previous` tenta DOM/controle semântico/índice explícito; `tabs.goBack` só é permitido em `/playlists/<id>?index=N`, com `N>0`.
- Slot offline sem HWND e sem snapshot de vídeo não envia comandos.

## Preservado

Range Cache, preload handoff, geometria, Focus Fix e proteção de propriedade do HWND.
