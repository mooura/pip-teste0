$ErrorActionPreference='Stop'
$root=Resolve-Path (Join-Path $PSScriptRoot '..\..')
$content=Get-Content (Join-Path $root 'src\PiPManager.Extension\content.js') -Raw
$main=Get-Content (Join-Path $root 'src\PiPManager.Wpf\MainWindow.xaml.cs') -Raw
$layout=Get-Content (Join-Path $root 'src\PiPManager.Wpf\MainWindow.Layout.cs') -Raw
$drag=Get-Content (Join-Path $root 'src\PiPManager.Wpf\MainWindow.PipDrag.cs') -Raw
$checks=[ordered]@{
 'buffer source is preserved'=$content.Contains('network-paused-buffer-preserved') -and $content.Contains("video.preload = 'none'")
 'handoff generation waits for current asset'=$content.Contains('handoff-resolution-deferred-until-current')
 'handoff survives document navigation'=$content.Contains('handoff-restored-after-navigation') -and $content.Contains('NEXT_VIDEO_PRELOAD_HANDOFF_STORAGE_KEY')
 'handoff consumes after current confirmation'=$content.Contains("clearNextPreloadHandoff('command-target-became-current', false)") -and $content.Contains('handoff-consumed')
 'manual observed browser rects are separated'=$main.Contains('_lastManualUserRectBySlot') -and $main.Contains('_lastObservedRectBySlot') -and $main.Contains('_lastBrowserAutomaticRectBySlot')
 'unsafe initial geometry has safe fallback'=$main.Contains('slot-navigation-geometry-safe-fallback') -and $main.Contains('prepared-capture-geometry-guard-applied')
 'layout target is clamped before native apply'=$layout.Contains('ClampLayoutTargetToGeometryAuthority')
 'only manual gesture records manual authority'=$drag.Contains('_lastManualUserRectBySlot[slot.Number] = finalRect')
}
$failed=0; foreach($item in $checks.GetEnumerator()){if($item.Value){Write-Host "$($item.Key): OK"}else{Write-Host "$($item.Key): FAIL";$failed++}}
if($failed -gt 0){throw 'Real buffer + trusted manual geometry Hotfix 8 checks failed.'}
Write-Host 'Real buffer + trusted manual geometry Hotfix 8 checks OK.'
