# PiPManager Release Versions

## Version Summary

### fix4-rc6 Branch (Stable)
- **Application Version**: 9.39.03
- **Extension Version**: 1.4.39.7
- **Release Date**: 2026-08-05
- **Status**: Stable Release Candidate
- **Branch**: `fix4-rc6`

#### Features
- Tab occupancy notifications (v2 optimized)
- Fixed layout mode
- Multi-site video platform support
  - YouTube
  - Vimeo
  - Dailymotion
  - Twitch
  - Other major platforms
- Enhanced error handling
- Improved tab management
- Robust PiP restoration

#### Known Fixes
- Resolved tab occupation detection issues
- Fixed layout switching crashes
- Improved video platform detection
- Enhanced window positioning logic
- Optimized memory usage

#### Build Information
- Base Framework: .NET 8
- WPF Application: Windows-only
- Firefox Extension: Compatible with Firefox 90+
- Build System: PowerShell scripts

---

### pip12h4-hotfix8 Branch (Development)
- **Application Version**: 9.39.03
- **Extension Version**: 1.4.39.25
- **Release Date**: 2026-08-05
- **Status**: Development/Testing
- **Branch**: `pip12h4-hotfix8`

#### Features
- Advanced AutoReturn mechanisms
- Universal geometry authority system
- Preserved state synchronization
- Integrated sync handling
- Real-time tab occupancy tracking
- Automated playlist navigation
- Multi-slot layout support
- Enhanced video detection
- Intelligent window management

#### Hotfixes (1-8)
1. **Hotfix 1**: AutoReturn edge case handling
2. **Hotfix 2**: State preservation on tab switch
3. **Hotfix 3**: Geometry authority conflicts
4. **Hotfix 4**: Memory leak in sync handler
5. **Hotfix 5**: Tab occupancy race conditions
6. **Hotfix 6**: Playlist navigation timeout
7. **Hotfix 7**: Window positioning precision
8. **Hotfix 8**: Extension communication stability

#### Improvements
- Better error recovery
- Improved logging and diagnostics
- Enhanced performance
- More robust state management
- Improved cross-platform compatibility

#### Build Information
- Base Framework: .NET 8
- WPF Application: Windows-only
- Firefox Extension: Compatible with Firefox 90+
- Build System: PowerShell scripts

---

## Version History

### Previous Versions

#### v1.4.39.x Series (Extension)
- **1.4.39.25** - PIP12H4 Hotfix 8 (current development)
- **1.4.39.7** - Fix4 RC6 (current stable)
- **1.4.39.3** - Earlier development version
- **1.4.38.x** - Previous release series

#### v9.39.x Series (Application)
- **9.39.03** - Current (both branches)
- **9.39.02** - Previous stable
- **9.39.01** - Earlier version
- **9.38.x** - Previous series

---

## Branch Comparison

| Feature | fix4-rc6 | pip12h4-hotfix8 |
|---------|----------|-----------------|
| Status | Stable | Development |
| App Version | 9.39.03 | 9.39.03 |
| Ext Version | 1.4.39.7 | 1.4.39.25 |
| Tab Occupancy v2 | ✓ | ✓ |
| AutoReturn Advanced | ✗ | ✓ |
| Geometry Authority | Basic | Universal |
| State Sync | Standard | Integrated |
| Hotfixes | 0 | 8 |
| Playlist Nav | Basic | Advanced |
| Production Ready | ✓ | ✗ |
| Experimental | ✗ | ✓ |

---

## Compatibility Matrix

### Windows Versions
- Windows 10 (1909+)
- Windows 11 (all versions)
- Windows Server 2019+

### .NET Runtime
- .NET 8.0+ required
- .NET Desktop Runtime 8.0+

### Firefox Versions
- Firefox 90+ (fix4-rc6)
- Firefox 90+ (pip12h4-hotfix8)

### Video Platforms Supported
- YouTube (full support)
- Vimeo (full support)
- Dailymotion (full support)
- Twitch (full support)
- HTML5 video players (standard)
- Custom video implementations (tested)

---

## Upgrade Path

### From Earlier Versions to fix4-rc6
1. Back up current settings
2. Uninstall previous version
3. Install fix4-rc6 release
4. Restore settings if compatible
5. Test core functionality

### From fix4-rc6 to pip12h4-hotfix8
1. Requires manual transition (different branches)
2. Back up settings
3. Uninstall current version
4. Install pip12h4-hotfix8
5. Restore and validate settings
6. Test new features

### Bug Reporting Between Versions
- Report version-specific issues clearly
- Include version numbers in bug reports
- Specify branch name (fix4-rc6 or pip12h4-hotfix8)
- Note OS and Firefox versions

---

## Release Checklist

### Before Release
- [ ] All tests pass
- [ ] Code review completed
- [ ] Documentation updated
- [ ] Version numbers incremented
- [ ] BUILD scripts verified
- [ ] Performance benchmarks acceptable
- [ ] Security review completed
- [ ] Firefox extension tested

### Release Process
- [ ] Tag commit with version
- [ ] Create release notes
- [ ] Build distribution packages
- [ ] Update version documentation
- [ ] Announce release
- [ ] Monitor for issues

### Post-Release
- [ ] Gather user feedback
- [ ] Monitor error logs
- [ ] Plan next version
- [ ] Update roadmap

---

## Deprecation Policy

- Versions older than 2 major releases are unsupported
- Security fixes provided for 1 year minimum
- Major version bumps include breaking changes
- Deprecation warnings provided 1 version in advance

---

## Support Timeline

| Version | Release | Support Until | Status |
|---------|---------|----------------|--------|
| 1.4.39.25 (dev) | 2026-08-05 | Current | Development |
| 1.4.39.7 | 2026-08-05 | 2027-08-05 | Stable |
| 1.4.38.x | Earlier | 2026-08-05 | End of Life |

---

**Last Updated**: 2026-08-05  
**Maintained By**: PiPManager Team
