# Hotfix 5 - Five-PiP Identity Stability Gate Fix

This package keeps runtime version `1.4.39.21-reconnect-ownership-geometry-hotfix6`.

## Correction

`CHECK_FIVE_PIP_IDENTITY_STABILITY.ps1` previously required an obsolete Portuguese comment string (`StableVideoKey contém sinais de mídia`). The runtime rule itself was already correct.

The checker now validates the actual implementation:

- `stableChangedWithoutStrongIdentity` requires the current `PairKey` to be empty;
- the previous session (`OldSession`) must also be empty;
- only then can `StableVideoKey` churn count as a change;
- with an active session, stable-key churn alone is not a strong video change.

No executable C# or extension behavior was changed.
