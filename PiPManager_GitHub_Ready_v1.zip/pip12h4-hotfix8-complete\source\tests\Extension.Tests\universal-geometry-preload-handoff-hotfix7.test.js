const assert = require('assert');
const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '../..');
const content = fs.readFileSync(path.join(root, 'src/PiPManager.Extension/content.js'), 'utf8');
const main = fs.readFileSync(path.join(root, 'src/PiPManager.Wpf/MainWindow.xaml.cs'), 'utf8');
const drag = fs.readFileSync(path.join(root, 'src/PiPManager.Wpf/MainWindow.PipDrag.cs'), 'utf8');
const fixed = fs.readFileSync(path.join(root, 'src/PiPManager.Wpf/MainWindow.FixedLayout.cs'), 'utf8');

assert(content.includes('NEXT_VIDEO_PRELOAD_NETWORK_WINDOW_MS = 5000'), 'network window must allow useful warming');
assert(content.includes('PRELOAD_HANDOFF_TO_NAVIGATION'), 'preload handoff lifecycle must exist');
assert(content.includes('cancel-skipped-command-handoff'), 'generation cancellation must yield to command handoff');
assert(content.includes('generation-change-preserved-command-handoff'), 'generation transition must preserve matching handoff');
assert(content.includes("reason === 'target-changed'"), 'published target churn must also preserve matching handoff');
assert(content.includes('handoff-consumed'), 'handoff must be released after target becomes current');
assert(content.includes("'PRELOAD_EMPTY'"), 'empty preload must not be reported as READY');
assert(content.includes('NEXT_VIDEO_PRELOAD_MIN_USEFUL_BUFFER_SECONDS = 8'), 'minimum useful buffer must be explicit');
assert(content.includes('NEXT_VIDEO_PRELOAD_MAX_BUFFER_SECONDS = 12'), 'maximum target envelope must be explicit');

assert(main.includes('SlotNavigationGeometryAuthorityState'), 'slot-level geometry authority must exist');
assert(main.includes('slot-navigation-geometry-authority-armed'), 'command must arm slot geometry authority');
assert(main.includes('BindSlotNavigationGeometryAuthority(slot, newWindow.Handle, "CapturePreparedPipWindow", preferredAspectRatio)'), 'prepared capture must bind universal geometry authority');
assert(main.includes('ReconnectGeometryVerifyCheckpointsMs = [0, 150, 400, 900, 1800, 3200, 4200]'), 'late browser inflation checkpoints must cover full window');
assert(main.includes('_lastManualUserRectBySlot'), 'manual stable geometry must survive HWND loss');
assert(main.includes('slot-navigation-geometry-safe-fallback'), 'automatic oversized geometry must not replace trusted manual geometry');
assert(drag.includes('_lastManualUserRectBySlot[slot.Number] = finalRect'), 'only confirmed manual resize may replace stable geometry');
assert(!drag.includes('CancelReconnectGeometryAuthority(handle, "natural-anchor-drag-started")'), 'plain click must not disable geometry protection');
assert(fixed.includes('TryGetSlotNavigationGeometryTarget'), 'fixed layout must yield to slot authority before HWND binding');
console.log('Universal geometry + preload handoff Hotfix 7 checks OK.');
