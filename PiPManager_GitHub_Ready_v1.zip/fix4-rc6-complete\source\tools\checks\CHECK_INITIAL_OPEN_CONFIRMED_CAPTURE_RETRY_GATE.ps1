$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$mainPath = Join-Path $root 'src\PiPManager.Wpf\MainWindow.xaml.cs'
$main = Get-Content $mainPath -Raw

$waitStart = $main.IndexOf('private bool TryGetConfirmedInitialOpenHwnd')
$waitEnd = $main.IndexOf('private async Task OpenPipManualFromSelectedVideoAsync', $waitStart)
$manualStart = $waitEnd
$manualEnd = $main.IndexOf('private async Task OpenPipFocuslessFromSelectedVideoAsync', $manualStart)

if ($waitStart -lt 0 -or $waitEnd -lt 0 -or $manualStart -lt 0 -or $manualEnd -lt 0) {
  throw 'Initial-open retry gate methods were not found.'
}

$gate = $main.Substring($waitStart, $waitEnd - $waitStart)
$manual = $main.Substring($manualStart, $manualEnd - $manualStart)

$retryGuard = $manual.IndexOf('checkpoint: "before-physical-retry"')
$retryStart = $manual.IndexOf('initial-open-physical-shortcut-retry-start')
$sendGuard = $manual.IndexOf('checkpoint: "before-physical-retry-send"')
$retrySend = $manual.IndexOf('initial-open-physical-shortcut-retry-sent')
$fallbackGuard = $manual.IndexOf('checkpoint: "before-extension-fallback"')
$fallbackSend = $manual.IndexOf('fallback requestPictureInPicture enviado por ação do usuário')

$checks = [ordered]@{
  'confirmed HWND requires usable window' = $gate.Contains('PipWindowService.IsUsable(handle)')
  'confirmed HWND requires stored identity' = $gate.Contains('_slotVideoPairs.TryGetValue') -and $gate.Contains('_slotStableVideoPairs.TryGetValue') -and $gate.Contains('_slotPairedTabIds.TryGetValue')
  'pair or stable identity must match' = $gate.Contains('(!pairMatches && !stableMatches)')
  'post-timeout capture is checked' = $gate.Contains('initial-open-post-timeout-capture-confirmed')
  'dispatcher queue is drained before retry decisions' = ([regex]::Matches($manual, [regex]::Escape('System.Windows.Threading.Dispatcher.Yield(DispatcherPriority.Background)'))).Count -ge 3
  'retry cancellation has explicit reason' = $gate.Contains('initial-open-physical-shortcut-retry-cancelled') -and $gate.Contains('reason=slot-already-confirmed')
  'guard runs before retry starts' = $retryGuard -ge 0 -and $retryStart -ge 0 -and $retryGuard -lt $retryStart
  'guard runs before second shortcut send' = $sendGuard -ge 0 -and $retrySend -ge 0 -and $sendGuard -lt $retrySend
  'guard runs before extension fallback' = $fallbackGuard -ge 0 -and $fallbackSend -ge 0 -and $fallbackGuard -lt $fallbackSend
  'confirmed capture still closes matching open lock' = $main.Contains('EndOpenPipAttempt(slot, tab, "captura", "hwnd-capturado")')
}

$failed = 0
foreach ($item in $checks.GetEnumerator()) {
  if ($item.Value) {
    Write-Host ($item.Key + ': OK')
  } else {
    Write-Host ($item.Key + ': FAIL')
    $failed++
  }
}

if ($failed -gt 0) {
  throw 'Initial-open confirmed-capture retry gate checks failed.'
}

Write-Host 'Initial-open confirmed-capture retry gate checks OK.'
