$ErrorActionPreference = 'Stop'

$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$manifestPath = Join-Path $root 'docs\consolidation\test-inventory.json'
$runnerPath = Join-Path $root 'RUN_CORE_TESTS.bat'

function Fail([string]$message) {
    Write-Host "FAIL: $message" -ForegroundColor Red
    exit 1
}

if (-not (Test-Path -LiteralPath $manifestPath)) { Fail 'test inventory manifest is missing' }
if (-not (Test-Path -LiteralPath $runnerPath)) { Fail 'RUN_CORE_TESTS.bat is missing' }

$manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
$runner = Get-Content -LiteralPath $runnerPath -Raw
$checksRoot = Join-Path $root 'tools\checks'
$checks = @(Get-ChildItem -LiteralPath $checksRoot -File -Filter 'CHECK_*.ps1' | Sort-Object Name)
$checkNames = @($checks | ForEach-Object Name)
$conditionalNames = @($manifest.conditionalChecks | ForEach-Object file)

if ($checks.Count -lt [int]$manifest.minimumCheckScripts) {
    Fail "expected at least $($manifest.minimumCheckScripts) CHECK scripts, found $($checks.Count)"
}

$orphans = @($checkNames | Where-Object { $runner -notmatch [regex]::Escape($_) })
if ($orphans.Count -ne [int]$manifest.orphanChecksAllowed) {
    Fail "orphan CHECK scripts: $($orphans -join ', ')"
}

$missingReferences = @(
    [regex]::Matches($runner, 'CHECK_[A-Z0-9_]+\.ps1', 'IgnoreCase') |
        ForEach-Object Value |
        Sort-Object -Unique |
        Where-Object { $_ -notin $checkNames }
)
if ($missingReferences.Count -gt 0) {
    Fail "runner references missing CHECK scripts: $($missingReferences -join ', ')"
}

foreach ($conditional in $conditionalNames) {
    if ($conditional -notin $checkNames) { Fail "declared conditional check is missing: $conditional" }
    if ($runner -notmatch [regex]::Escape($conditional)) { Fail "conditional check is not wired into runner: $conditional" }
}

$alwaysRun = @($checkNames | Where-Object { $_ -notin $conditionalNames })
if ($alwaysRun.Count -lt [int]$manifest.minimumAlwaysRunCheckScripts) {
    Fail "expected at least $($manifest.minimumAlwaysRunCheckScripts) always-run CHECK scripts, found $($alwaysRun.Count)"
}
if ($conditionalNames.Count -ne [int]$manifest.expectedConditionalCheckScripts) {
    Fail "expected $($manifest.expectedConditionalCheckScripts) conditional CHECK scripts, found $($conditionalNames.Count)"
}

foreach ($relativeProject in @($manifest.testProjects)) {
    $normalized = $relativeProject -replace '/', '\'
    if (-not (Test-Path -LiteralPath (Join-Path $root $normalized))) {
        Fail "declared test project is missing: $relativeProject"
    }
    if ($runner -notmatch [regex]::Escape($normalized)) {
        Fail "declared test project is not executed by runner: $relativeProject"
    }
}

$duplicateCalls = @(
    [regex]::Matches($runner, 'CHECK_[A-Z0-9_]+\.ps1', 'IgnoreCase') |
        ForEach-Object Value |
        Group-Object |
        Where-Object Count -gt 1
)
if ($duplicateCalls.Count -gt 0) {
    Fail "duplicate CHECK references in runner: $(($duplicateCalls | ForEach-Object Name) -join ', ')"
}

Write-Host "PASS: Phase 2 test inventory is consistent ($($alwaysRun.Count) always, $($conditionalNames.Count) conditional, $($manifest.testProjects.Count) projects)." -ForegroundColor Green
