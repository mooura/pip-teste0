﻿# Fixed-layout external resize echo dedup

## Runtime symptom

In the Jogo profile with **Fixar layout**, Firefox could settle one PiP at its intrinsic visual size after the manager applied a group batch. When the temporary 3.2-second movement suppression expired, the health monitor classified the same browser-adjusted rectangle as a new external resize every cycle.

Typical sequence before this fix:

```text
PiP redimensionado externamente no slot 10
fixed-aspect-group-reflow-queued
fixed-aspect-group-reflow-applied
```

The same HWND and rectangle could repeat roughly every 3.6 seconds.

## Fix

The manager now retains the last accepted browser-natural rectangle per HWND and slot. A later health sample is treated as an internal echo when:

- fixed layout remains enabled;
- the HWND and slot are unchanged;
- the visual rectangle is equal within 2 px;
- no native border-resize gesture is active.

The first previously unseen browser-natural rectangle still queues one aspect reflow. Repeated copies log:

```text
fixed-layout-external-size-echo-ignored
manualGestureActive=False
reflowQueued=False
```

A real border resize remains authoritative. Active manual gestures bypass the echo cache, and a completed manual resize clears the cached rectangle before committing the new reference.

## State cleanup

The per-HWND echo state is cleared when:

- the user completes a manual resize;
- the HWND is removed from a slot;
- fixed layout is enabled or disabled.

## Preserved behavior

No changes were made to:

- AutoReturn correlated snapshot handling;
- extension protocol or version;
- Jogo topology and aspect authority;
- Equalize group selection;
- native Firefox/Zen border resizing;
- Open All, pairing, playlist, or UI.
