﻿# Atalho Espaço do perfil Jogo

- Opção: `Layout > Atalho Espaço: ocultar/mostrar PiPs`.
- Desativada por padrão e salva nas configurações.
- Quando ativada, registra `Espaço` como atalho global somente enquanto o perfil `Jogo` estiver selecionado.
- `Espaço` reutiliza a mesma autoridade do botão `Ocultar/Mostrar`, preservando posições e estado dos slots.
- Ao trocar para qualquer outro perfil, o atalho é liberado imediatamente e a barra de espaço volta ao aplicativo em foco.
- O registro usa `MOD_NOREPEAT`, evitando alternâncias repetidas ao manter a tecla pressionada.
