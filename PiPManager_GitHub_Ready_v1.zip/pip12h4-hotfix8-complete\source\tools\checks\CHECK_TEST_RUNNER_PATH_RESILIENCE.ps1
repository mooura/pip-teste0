$ErrorActionPreference = "Stop"
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$projectPath = Join-Path $root "tests\PiPManager.WindowEventMonitor.Tests\PiPManager.WindowEventMonitor.Tests.csproj"
$stubPath = Join-Path $root "tests\PiPManager.WindowEventMonitor.Tests\IApplicationHealthService.TestStub.cs"
$project = Get-Content $projectPath -Raw
$checks = [ordered]@{
  "fake tests are framework-dependent" = $project.Contains("<SelfContained>false</SelfContained>")
  "fake tests do not require apphost executable" = $project.Contains("<UseAppHost>false</UseAppHost>")
  "fake tests do not force runtime identifier" = -not $project.Contains("<RuntimeIdentifier>")
  "fake tests do not reference WPF executable project" = -not ($project -match '<ProjectReference[^>]+PiPManager\.Wpf\.csproj')
  "monitor service linked directly" = $project.Contains('WindowsEventMonitorService.cs" Link=')
  "movement flow control linked directly" = $project.Contains('WindowEventFlowControlService.cs" Link=')
  "fake source linked directly" = $project.Contains('FakeWindowEventMonitorSource.cs" Link=')
  "native helper linked directly" = $project.Contains('Win32.cs" Link=')
  "minimal health contract exists" = Test-Path $stubPath
}
$failed = 0
foreach ($entry in $checks.GetEnumerator()) {
  if ($entry.Value) { Write-Host ($entry.Key + ": OK") }
  else { Write-Host ($entry.Key + ": FAIL"); $failed++ }
}
if ($failed -gt 0) { throw "Test runner path resilience checks failed." }
Write-Host "Test runner path resilience checks OK."
