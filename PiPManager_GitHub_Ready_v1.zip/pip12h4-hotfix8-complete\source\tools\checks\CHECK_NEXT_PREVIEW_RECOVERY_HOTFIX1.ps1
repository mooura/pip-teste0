$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$content = Get-Content -Raw (Join-Path $root 'src\PiPManager.Extension\content.js')
$background = Get-Content -Raw (Join-Path $root 'src\PiPManager.Extension\background.js')
$main = Get-Content -Raw (Join-Path $root 'src\PiPManager.Wpf\MainWindow.xaml.cs')
$manifest = Get-Content -Raw (Join-Path $root 'src\PiPManager.Extension\manifest.json') | ConvertFrom-Json
$release = Get-Content -Raw (Join-Path $root 'src\PiPManager.Wpf\Services\ReleaseInfoService.cs')
$runner = Get-Content -Raw (Join-Path $root 'RUN_CORE_TESTS.bat')

$checks = [ordered]@{
  'manifest is 1.4.39.25' = ([string]$manifest.version -eq '1.4.39.25')
  'release metadata is 1.4.39.25' = $release.Contains('ExtensionVersion = "1.4.39.25"')
  'hotfix identifier is synchronized' = $content.Contains("CONTENT_VERSION = '1.4.39.25-command-target-root-guard-hotfix10'") -and $background.Contains("BRIDGE_VERSION = '1.4.39.25-command-target-root-guard-hotfix10'")
  'authoritative navigation fallback exists' = $content.Contains('function tryNavigateAuthoritativeNextTarget(') -and $content.Contains('resolved-target-url:') -and $content.Contains('generic-up-next-url:')
  'generic Up Next discovery exists' = $content.Contains('function findGenericUpNextElement(')
  'bounded transient retries exist' = $content.Contains('const NEXT_TARGET_TRANSIENT_RETRY_DELAYS_MS = Object.freeze([300, 600, 900])') -and $content.Contains('function scheduleNextTargetTransientRetries(')
  'playlist-not-detected is transient first' = $content.Contains("markNextTargetTransientlyResolving('playlist-not-detected')")
  'safe transient recovery exists' = $content.Contains('pipManagerLastResolvedNextTarget') -and $content.Contains('NEXT_TARGET_TRANSIENT_RETRY_DELAYS_MS') -and $content.Contains('reason}-retrying') -and $content.Contains("previewState: 'RESOLVING_TARGET'")
  'page navigation cancels retries' = $content.Contains("window.addEventListener('pagehide'") -and $content.Contains('cancelNextTargetTransientRetries();')
  'Phase 3 AutoReturn guard remains' = $main.Contains('resolverBlocksSameVideoFallback') -and $main.Contains('auto-return-same-video-fallback-deferred-target-resolution')
  'node hotfix regression is wired' = $runner.Contains('next-preview-recovery-hotfix1.test.js')
}

$failed = @()
foreach ($item in $checks.GetEnumerator()) {
  if ($item.Value) { Write-Host ($item.Key + ': OK') }
  else { Write-Host ($item.Key + ': FAIL'); $failed += $item.Key }
}
if ($failed.Count -gt 0) { throw ('Next + Preview Recovery Hotfix 1 checks failed: ' + ($failed -join ', ')) }
Write-Host 'Next + Preview Recovery Hotfix 1 checks OK.'
