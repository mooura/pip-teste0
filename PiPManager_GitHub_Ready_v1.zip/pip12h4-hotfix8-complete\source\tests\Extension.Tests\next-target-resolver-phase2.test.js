'use strict';

const fs = require('fs');
const path = require('path');
const vm = require('vm');

function assert(condition, message) {
  if (!condition) throw new Error(`TEST FAILED: ${message}`);
}

const root = path.join(__dirname, '..', '..');
const content = fs.readFileSync(path.join(root, 'src', 'PiPManager.Extension', 'content.js'), 'utf8');
const background = fs.readFileSync(path.join(root, 'src', 'PiPManager.Extension', 'background.js'), 'utf8');
const release = fs.readFileSync(path.join(root, 'src', 'PiPManager.Wpf', 'Services', 'ReleaseInfoService.cs'), 'utf8');
const manifest = JSON.parse(fs.readFileSync(path.join(root, 'src', 'PiPManager.Extension', 'manifest.json'), 'utf8'));

assert(manifest.version === '1.4.39.25', 'manifest must be 1.4.39.25');
assert(release.includes('ExtensionVersion = "1.4.39.25"'), 'release metadata must be 1.4.39.25');
assert(content.includes("CONTENT_VERSION = '1.4.39.25-command-target-root-guard-hotfix10'"), 'content phase identifier must be present');
assert(background.includes("BRIDGE_VERSION = '1.4.39.25-command-target-root-guard-hotfix10'"), 'background phase identifier must be present');

assert(content.includes('let pipManagerNextTargetState = {'), 'next target authority state must exist');
assert(content.includes("let status = 'TARGET_RESOLVED'"), 'resolved target state must exist');
assert(content.includes("status = 'TARGET_NOT_FOUND'"), 'target-not-found state must exist');
assert(content.includes("status = 'TARGET_SAME_AS_CURRENT'"), 'same-as-current state must exist');
assert(content.includes('function buildNextTargetDescriptor('), 'target descriptor resolver must exist');
assert(content.includes('function publishNextTargetState('), 'target publishing boundary must exist');
assert(content.includes('function startPreloadForResolvedNextTarget()'), 'preload must consume resolved target state');
assert(content.includes("target.status !== 'TARGET_RESOLVED' || target.nextAssetId !== assetId"), 'preload entry must reject unresolved or mismatched targets');
assert(content.includes("target.currentAssetId && target.currentAssetId === assetId"), 'preload entry must reject the current asset');
assert(content.includes('function scheduleNextPreviewVideoResolution(target)'), 'media resolution must consume a resolved target object');
assert(content.includes("'target-resolved'"), 'target resolution diagnostic must exist');
assert(content.includes("sendNextPreloadDiagnostic('target-media-resolved'"), 'target media resolution diagnostic must exist');
assert(!content.includes('const latest = Array.from(pipManagerNextFullMediaCache.entries()).pop()'), 'cache must not choose the latest arbitrary asset');
assert(background.includes('nextTargetStatus'), 'target status must be forwarded in snapshots');
assert(background.includes('currentAssetId') && background.includes('nextAssetId'), 'asset identities must be forwarded');



// Execute the production resolver helpers with a synthetic current/next pair.
const helperStart = content.indexOf('function extractMediaAssetId(');
const helperEnd = content.indexOf('function findNextPreviewVideoUrl(', helperStart);
assert(helperStart >= 0 && helperEnd > helperStart, 'resolver helper region must be found');

const currentAsset = 'aaaaaaaaaaaaaaaaaaaaaaaa';
const nextAsset = 'bbbbbbbbbbbbbbbbbbbbbbbb';
const currentVideo = {
  currentSrc: `https://media.example/${currentAsset}/current.mp4`,
  src: '',
  poster: '',
  attributes: [],
  querySelectorAll() { return []; }
};
const diagnosticEvents = [];
const context = vm.createContext({
  String, Array, Number, Date, URL,
  location: { href: 'https://pmvhaven.com/playlists/demo?index=3', origin: 'https://pmvhaven.com' },
  document: {
    querySelector() { return null; },
    querySelectorAll(selector) { return selector === 'video' ? [currentVideo] : []; }
  },
  getVisibleVideos() { return [{ video: currentVideo }]; },
  isPipManagerAuxiliaryVideo() { return false; },
  normalizeEmbeddedUrl(value) { try { return new URL(String(value || ''), 'https://pmvhaven.com/').href; } catch (_) { return ''; } },
  isPreviewMediaUrl(value) { return /\\.(?:mp4|webm|m3u8)(?:$|[?#])/i.test(String(value || '')); },
  cleanPlaylistTitle(value) { return String(value || '').trim(); },
  findNextVideoPageUrl(_node, assetId) { return assetId ? `https://pmvhaven.com/video/next_${assetId}` : ''; },
  sendNextPreloadDiagnostic(...args) { diagnosticEvents.push(args); },
  cancelNextVideoPreload() {},
  pipManagerNextPreloadAssetId: '',
  pipManagerNextTargetState: { status: 'IDLE', key: '', nextAssetId: '' }
});
vm.runInContext(`${content.slice(helperStart, helperEnd)}\nthis.resolver = { extractMediaAssetId, buildNextTargetDescriptor };`, context);

const resolved = context.resolver.buildNextTargetDescriptor({
  thumbnailUrl: `https://cdn.example/${nextAsset}/thumb.webp`,
  title: 'Next', currentIndex: 3, nextIndex: 4
});
assert(resolved.status === 'TARGET_RESOLVED', 'different next asset must resolve');
assert(resolved.currentAssetId === currentAsset, 'current asset must come from the real player');
assert(resolved.nextAssetId === nextAsset, 'next asset must come from the next card');

const same = context.resolver.buildNextTargetDescriptor({
  thumbnailUrl: `https://cdn.example/${currentAsset}/thumb.webp`,
  title: 'Wrong current fallback', currentIndex: 3, nextIndex: 4
});
assert(same.status === 'TARGET_SAME_AS_CURRENT', 'current asset must never be accepted as next');
assert(same.previewMediaUrl === '', 'same-current target must not expose preview media');

const missing = context.resolver.buildNextTargetDescriptor({ title: 'Missing', currentIndex: 3, nextIndex: 4 });
assert(missing.status === 'TARGET_NOT_FOUND', 'missing next identity must be rejected');

console.log('Next target resolver Phase 2 compatibility tests: OK');
