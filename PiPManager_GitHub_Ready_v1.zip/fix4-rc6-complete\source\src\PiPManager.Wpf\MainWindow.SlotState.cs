﻿using PiPManager.Wpf.Models;

namespace PiPManager.Wpf;

public partial class MainWindow
{
    private int? _awaitingPipSlotNumber;

    private void MarkSlotFree(PipSlot slot)
    {
        slot.State = PipSlotState.Free;
    }

    private void MarkSlotActive(PipSlot slot)
    {
        slot.State = PipSlotState.Active;
        QueueApplyFixedSlotGeometry(slot, "mark-slot-active");
    }

    private void MarkSlotHidden(PipSlot slot)
    {
        slot.State = PipSlotState.Hidden;
    }

    private void MarkSlotOffline(PipSlot slot)
    {
        slot.State = PipSlotState.Offline;
    }

    private void MarkSlotAwaitingPip(PipSlot slot)
    {
        _awaitingPipSlotNumber = slot.Number;
        slot.State = PipSlotState.AwaitingPip;
    }

    private void ClearAwaitingPipSlot(int? slotNumber = null)
    {
        if (_awaitingPipSlotNumber is null) return;
        if (slotNumber is not null && _awaitingPipSlotNumber != slotNumber) return;

        var previousSlot = Slots.FirstOrDefault(item => item.Number == _awaitingPipSlotNumber.Value);
        _awaitingPipSlotNumber = null;
        if (previousSlot is not null)
            RefreshSlotState(previousSlot);
    }

    private void RefreshSlotState(PipSlot slot)
    {
        if (_awaitingPipSlotNumber == slot.Number)
        {
            slot.State = PipSlotState.AwaitingPip;
            return;
        }

        if (slot.IsHidden && slot.Window is not null)
        {
            slot.State = PipSlotState.Hidden;
            return;
        }

        if (slot.Window is not null)
        {
            slot.State = PipSlotState.Active;
            return;
        }

        slot.State = SlotHasVideoPair(slot)
            ? PipSlotState.Offline
            : PipSlotState.Free;
    }

    private void RefreshAllSlotStates()
    {
        foreach (var slot in Slots)
            RefreshSlotState(slot);

        SyncEditableSlotStates();
    }

    private bool SlotHasAssignment(PipSlot? slot)
    {
        if (slot is null) return false;
        return slot.State != PipSlotState.Free || slot.Window is not null || SlotHasVideoPair(slot);
    }
}
