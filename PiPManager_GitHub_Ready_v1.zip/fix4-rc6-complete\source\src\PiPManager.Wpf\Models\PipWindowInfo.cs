﻿namespace PiPManager.Wpf.Models;

public sealed record PipWindowInfo(
    IntPtr Handle,
    int ProcessId,
    string ProcessName,
    string Title,
    string ClassName,
    NativeRect VisualRect,
    int Score
);
