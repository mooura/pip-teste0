﻿using System.IO;

namespace PiPManager.Wpf.Services;

public interface ILogMaintenanceService
{
    void RotateOperationalLogIfNeeded();
    void LogStartupBanner();
}

public sealed class LogMaintenanceService : ILogMaintenanceService
{
    private readonly IReleaseInfoService _releaseInfo;

    public LogMaintenanceService(IReleaseInfoService releaseInfo)
    {
        _releaseInfo = releaseInfo;
    }

    public void RotateOperationalLogIfNeeded()
    {
        try
        {
            var appData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            if (string.IsNullOrWhiteSpace(appData))
                return;

            var logPath = Path.Combine(appData, "PiPManagerWPF", "pip_manager.log");
            if (!File.Exists(logPath))
                return;

            var info = new FileInfo(logPath);
            const long maxBytes = 5L * 1024L * 1024L;
            if (info.Length < maxBytes)
                return;

            var rotated = Path.Combine(info.DirectoryName ?? appData, $"pip_manager-{DateTime.Now:yyyyMMdd-HHmmss}.log");
            File.Move(logPath, rotated, overwrite: false);
        }
        catch
        {
            // Log maintenance must never block application startup.
        }
    }

    public void LogStartupBanner()
    {
        AppLogger.Info(_releaseInfo.StartupBanner);
    }
}
