namespace PiPManager.Core.Automation;

/// <summary>
/// Regras determinísticas para preservar e drenar perdas simultâneas de PiP.
/// Mantém o conhecimento da rajada fora da UI e permite regressão automatizada.
/// </summary>
public static class AutoReturnBurstPolicy
{
    private const int PendingSlotAllowanceSeconds = 10;
    private const int MaxPendingAgeSeconds = 150;
    private const int LayoutSlotAllowanceMilliseconds = 8_000;
    private const int MaxLayoutRecoveryTimeoutMilliseconds = 120_000;
    private const int MaxRetryDelayMilliseconds = 2_000;

    public static bool ShouldPreserveLostSlot(
        bool autoReturnEnabled,
        bool hasPairRecoverySignal) =>
        autoReturnEnabled && hasPairRecoverySignal;

    public static int GetPendingMaxAgeSeconds(int pendingSlotCount, int baseSeconds)
    {
        var normalizedBase = Math.Max(1, baseSeconds);
        var additionalSlots = Math.Max(0, pendingSlotCount - 1);
        return Math.Min(
            MaxPendingAgeSeconds,
            normalizedBase + (additionalSlots * PendingSlotAllowanceSeconds));
    }

    public static int GetLayoutRecoveryTimeoutMilliseconds(int expectedSlotCount, int baseMilliseconds)
    {
        var normalizedBase = Math.Max(1_000, baseMilliseconds);
        var additionalSlots = Math.Max(0, expectedSlotCount - 1);
        return Math.Min(
            MaxLayoutRecoveryTimeoutMilliseconds,
            normalizedBase + (additionalSlots * LayoutSlotAllowanceMilliseconds));
    }

    public static int GetRetryDelayMilliseconds(int retryNumber)
    {
        var normalizedRetry = Math.Max(1, retryNumber);
        var delay = 500 * (1 << Math.Min(2, normalizedRetry - 1));
        return Math.Min(MaxRetryDelayMilliseconds, delay);
    }

    /// <summary>
    /// Identifica o intervalo em que o elemento de vídeo ainda não pode aceitar uma
    /// abertura física de PiP. HAVE_NOTHING (readyState 0), ausência de source ou
    /// estado ended devem aguardar o player se estabilizar em vez de enviar atalhos.
    /// </summary>
    public static bool IsPlaybackHardNotReady(
        bool hasSource,
        int readyState,
        bool isEnded) =>
        !hasSource || isEnded;

    /// <summary>
    /// A espera de readiness é estritamente limitada. Mesmo HAVE_NOTHING não pode
    /// incrementar deferrals para sempre; depois do limite, a camada WPF muda para
    /// observação passiva e aguarda um sinal estrutural real do player.
    /// </summary>
    public static bool ShouldDeferPhysicalAttemptForReadiness(
        bool ready,
        bool hardNotReady,
        int readinessDeferrals,
        int maxReadinessDeferrals)
    {
        _ = hardNotReady;
        return !ready && readinessDeferrals < Math.Max(0, maxReadinessDeferrals);
    }

    public static int GetReadinessRetryDelayMilliseconds(bool hardNotReady) =>
        hardNotReady ? 500 : 300;

    public static bool IsTerminalVideoChangeConfirmed(
        bool sessionChanged,
        bool stableChanged,
        bool urlChanged,
        bool hasSource,
        int readyState,
        bool isEnded)
    {
        var mediaIdentityReady = hasSource && readyState >= 1 && !isEnded;
        return sessionChanged || (mediaIdentityReady && (urlChanged || stableChanged));
    }

    public static bool ShouldAllowPlaylistSameVideoFallback(
        bool requiresRealVideoChange,
        bool playlistDetected,
        double pendingElapsedMilliseconds,
        int graceMilliseconds) =>
        requiresRealVideoChange
        && playlistDetected
        && pendingElapsedMilliseconds >= Math.Max(250, graceMilliseconds);
}
