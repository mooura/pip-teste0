# Hotfix 8 — Real Buffer Handoff + Trusted Manual Geometry

- Keeps the auxiliary media `src` and buffered ranges alive through the Next command.
- Persists handoff metadata in `sessionStorage` across same-tab document navigation.
- Defers next-target generation until the commanded asset becomes current.
- Separates manual, observed, and browser-automatic geometry.
- Uses only a proven manual resize as durable authority; otherwise applies a bounded safe fallback.
- Clamps layout targets before the Win32 batch, preventing a visible oversized flash.
