using System.Text.Json;

namespace PiPManager.Wpf.Services;

internal static class ExtensionProtocolReader
{
    internal static string GetString(JsonElement element, string property) =>
        element.TryGetProperty(property, out var value) && value.ValueKind == JsonValueKind.String
            ? value.GetString() ?? string.Empty
            : string.Empty;

    internal static int GetInt(JsonElement element, string property, int defaultValue = 0)
    {
        try
        {
            return element.TryGetProperty(property, out var value) && value.ValueKind == JsonValueKind.Number
                ? value.GetInt32()
                : defaultValue;
        }
        catch { return defaultValue; }
    }

    internal static IReadOnlyList<string> GetStringList(JsonElement element, string property, int maximum = 5)
    {
        if (!element.TryGetProperty(property, out var value) || value.ValueKind != JsonValueKind.Array)
            return Array.Empty<string>();

        return value.EnumerateArray()
            .Where(item => item.ValueKind == JsonValueKind.String)
            .Select(item => item.GetString()?.Trim() ?? string.Empty)
            .Where(item => !string.IsNullOrWhiteSpace(item))
            .Take(Math.Max(0, maximum))
            .ToArray();
    }

    internal static double GetDouble(JsonElement element, string property)
    {
        try
        {
            return element.TryGetProperty(property, out var value) && value.ValueKind == JsonValueKind.Number
                ? value.GetDouble()
                : 0;
        }
        catch { return 0; }
    }

    internal static long GetLong(JsonElement element, string property)
    {
        try
        {
            return element.TryGetProperty(property, out var value) && value.ValueKind == JsonValueKind.Number
                ? value.GetInt64()
                : 0L;
        }
        catch { return 0L; }
    }

    internal static bool GetBool(JsonElement element, string property) =>
        element.TryGetProperty(property, out var value) &&
        value.ValueKind is JsonValueKind.True or JsonValueKind.False &&
        value.GetBoolean();
}

