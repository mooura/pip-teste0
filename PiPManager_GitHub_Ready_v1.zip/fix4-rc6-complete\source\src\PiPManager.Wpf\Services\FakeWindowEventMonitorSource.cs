﻿namespace PiPManager.Wpf.Services;

public sealed class FakeWindowEventMonitorSource
{
    private readonly IWindowEventMonitorService _monitor;

    public FakeWindowEventMonitorSource(IWindowEventMonitorService monitor)
    {
        _monitor = monitor;
    }

    public void EmitCreate(IntPtr hwnd)
    {
        _monitor.RecordFakeEvent(WindowMonitorEventKind.Created, hwnd, "zen.exe", "Picture-in-Picture", "MozillaWindowClass", true, "create");
    }

    public void EmitMove(IntPtr hwnd)
    {
        _monitor.RecordFakeEvent(WindowMonitorEventKind.MovedOrResized, hwnd, "zen.exe", "Picture-in-Picture", "MozillaWindowClass", true, "move");
    }

    public void EmitDestroy(IntPtr hwnd)
    {
        _monitor.RecordFakeEvent(WindowMonitorEventKind.Destroyed, hwnd, "zen.exe", "Picture-in-Picture", "MozillaWindowClass", true, "destroy");
    }

    public void EmitDestroyFromCache(IntPtr hwnd)
    {
        _monitor.RecordFakeEvent(WindowMonitorEventKind.Destroyed, hwnd, string.Empty, string.Empty, string.Empty, false, "destroy-from-cache-request");
    }

    public WindowEventMonitorSnapshot EmitCreateMoveDuplicateDestroyForTest(IntPtr hwnd)
    {
        EmitCreate(hwnd);
        EmitMove(hwnd);
        EmitMove(hwnd); // deve ser deduplicado pelo monitor
        EmitDestroyFromCache(hwnd);
        return _monitor.GetSnapshotForTest();
    }
}
