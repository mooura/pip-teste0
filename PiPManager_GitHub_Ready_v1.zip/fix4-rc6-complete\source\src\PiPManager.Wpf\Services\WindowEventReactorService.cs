﻿using System.Collections.Concurrent;
using System.Threading.Channels;
using Microsoft.Extensions.Hosting;
using PiPManager.Wpf.Models;

namespace PiPManager.Wpf.Services;

public sealed record WindowEventReactorSnapshot(
    long Enqueued,
    long Processed,
    long Dropped,
    long Coalesced,
    long Batches,
    int LastBatchSize,
    double LastQueueDelayMs,
    double LastBatchWindowMs);

public sealed record WindowEventReactorPipCandidate(
    WindowMonitorEvent SourceEvent,
    PipWindowInfo Window,
    int ValidationAttempt,
    double ValidationLatencyMs);

public interface IWindowEventReactorService
{
    event Action<WindowEventReactorPipCandidate>? AssistedPipCandidateReady;
    WindowEventReactorSnapshot GetSnapshot();
}

/// <summary>
/// Event reactor with legacy authority retained. It coalesces WinEvent bursts outside the WPF UI thread,
/// records Shadow metrics and, only for Created/Shown PiP events, resolves the exact HWND for the
/// prepared-capture flow. The legacy polling timer remains available as a safety fallback.
/// </summary>
public sealed class WindowEventReactorService : BackgroundService, IWindowEventReactorService
{
    private static readonly TimeSpan CoalesceWindow = TimeSpan.FromMilliseconds(75);
    private const int CandidateValidationMaxAttempts = 8;
    private const int CandidateValidationRetryMs = 80;

    private readonly IWindowEventMonitorService _monitor;
    private readonly WindowDiscoveryService _discovery;
    private readonly Channel<WindowMonitorEvent> _channel;
    private readonly ConcurrentDictionary<string, WindowMonitorEvent> _pendingByKey = new();
    private readonly ConcurrentDictionary<IntPtr, byte> _candidateResolutionInFlight = new();

    private long _enqueued;
    private long _processed;
    private long _dropped;
    private long _coalesced;
    private long _batches;
    private int _lastBatchSize;
    private double _lastQueueDelayMs;
    private double _lastBatchWindowMs;
    private long _movementOnlyBatchesSinceLastLog;
    private long _movementOnlyEventsSinceLastLog;
    private DateTimeOffset _lastMovementBatchLogUtc = DateTimeOffset.MinValue;
    private const int MovementBatchLogThrottleMs = 3000;

    public WindowEventReactorService(IWindowEventMonitorService monitor, WindowDiscoveryService discovery)
    {
        _monitor = monitor;
        _discovery = discovery;
        _channel = Channel.CreateBounded<WindowMonitorEvent>(new BoundedChannelOptions(256)
        {
            SingleReader = true,
            SingleWriter = false,
            FullMode = BoundedChannelFullMode.DropOldest,
            AllowSynchronousContinuations = false
        }, droppedEvent =>
        {
            Interlocked.Increment(ref _dropped);
            AppLogger.Warn($"window-event-reactor-dropped: kind={droppedEvent.Kind}; hwnd=0x{droppedEvent.Hwnd.ToInt64():X}; reason=bounded-channel-drop-oldest");
        });
    }

    public event Action<WindowEventReactorPipCandidate>? AssistedPipCandidateReady;

    public WindowEventReactorSnapshot GetSnapshot() => new(
        Interlocked.Read(ref _enqueued),
        Interlocked.Read(ref _processed),
        Interlocked.Read(ref _dropped),
        Interlocked.Read(ref _coalesced),
        Interlocked.Read(ref _batches),
        Volatile.Read(ref _lastBatchSize),
        Volatile.Read(ref _lastQueueDelayMs),
        Volatile.Read(ref _lastBatchWindowMs));

    public override Task StartAsync(CancellationToken cancellationToken)
    {
        _monitor.RelevantEventReceived += OnRelevantEventReceived;
        AppLogger.Info("window-event-reactor-started: mode=shadow-assisted-candidate; capacity=256; fullMode=drop-oldest; coalesceMs=75; candidateValidation=direct-hwnd; candidateRetries=8x80ms; authority=configurable(compare-default); fluency=enabled; fallback=armed-pair-timer");
        return base.StartAsync(cancellationToken);
    }

    public override async Task StopAsync(CancellationToken cancellationToken)
    {
        _monitor.RelevantEventReceived -= OnRelevantEventReceived;
        _channel.Writer.TryComplete();
        await base.StopAsync(cancellationToken).ConfigureAwait(false);
    }

    private void OnRelevantEventReceived(WindowMonitorEvent ev)
    {
        if (_channel.Writer.TryWrite(ev))
            Interlocked.Increment(ref _enqueued);
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        try
        {
            while (await _channel.Reader.WaitToReadAsync(stoppingToken).ConfigureAwait(false))
            {
                if (!_channel.Reader.TryRead(out var first))
                    continue;

                var batchStarted = DateTimeOffset.UtcNow;
                AddOrReplace(first);

                var deadline = batchStarted + CoalesceWindow;
                while (DateTimeOffset.UtcNow < deadline)
                {
                    while (_channel.Reader.TryRead(out var next))
                        AddOrReplace(next);

                    var remaining = deadline - DateTimeOffset.UtcNow;
                    if (remaining <= TimeSpan.Zero)
                        break;

                    await Task.Delay(remaining < TimeSpan.FromMilliseconds(10) ? remaining : TimeSpan.FromMilliseconds(10), stoppingToken)
                        .ConfigureAwait(false);
                }

                while (_channel.Reader.TryRead(out var trailing))
                    AddOrReplace(trailing);

                FlushBatch(batchStarted, stoppingToken);
            }
        }
        catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
        {
            // Normal shutdown.
        }
        catch (Exception ex)
        {
            AppLogger.Warn($"window-event-reactor-failed: error={ex.Message}");
        }
    }

    private void AddOrReplace(WindowMonitorEvent ev)
    {
        var key = BuildCoalesceKey(ev);
        if (!_pendingByKey.TryAdd(key, ev))
        {
            _pendingByKey[key] = ev;
            Interlocked.Increment(ref _coalesced);
        }
    }

    private void FlushBatch(DateTimeOffset batchStarted, CancellationToken stoppingToken)
    {
        var events = _pendingByKey.ToArray();
        _pendingByKey.Clear();
        if (events.Length == 0)
            return;

        var now = DateTimeOffset.UtcNow;
        var oldest = events.Min(item => item.Value.CreatedAtUtc);
        var delayMs = Math.Max(0, (now - oldest).TotalMilliseconds);
        var windowMs = Math.Max(0, (now - batchStarted).TotalMilliseconds);

        Interlocked.Add(ref _processed, events.Length);
        Interlocked.Increment(ref _batches);
        Volatile.Write(ref _lastBatchSize, events.Length);
        Volatile.Write(ref _lastQueueDelayMs, delayMs);
        Volatile.Write(ref _lastBatchWindowMs, windowMs);

        var critical = events.Count(item => item.Value.Kind is WindowMonitorEventKind.Created
            or WindowMonitorEventKind.Destroyed
            or WindowMonitorEventKind.Shown
            or WindowMonitorEventKind.Hidden);
        var movement = events.Count(item => item.Value.Kind == WindowMonitorEventKind.MovedOrResized);

        var movementOnly = critical == 0 && movement == events.Length;
        if (movementOnly)
        {
            Interlocked.Increment(ref _movementOnlyBatchesSinceLastLog);
            Interlocked.Add(ref _movementOnlyEventsSinceLastLog, movement);
            if ((now - _lastMovementBatchLogUtc).TotalMilliseconds >= MovementBatchLogThrottleMs)
            {
                _lastMovementBatchLogUtc = now;
                var aggregatedBatches = Interlocked.Exchange(ref _movementOnlyBatchesSinceLastLog, 0);
                var aggregatedEvents = Interlocked.Exchange(ref _movementOnlyEventsSinceLastLog, 0);
                AppLogger.Info(
                    $"window-event-reactor-shadow-batch: size={events.Length}; critical=0; movement={movement}; " +
                    $"movementBatchesAggregated={aggregatedBatches}; movementEventsAggregated={aggregatedEvents}; " +
                    $"queueDelayMs={delayMs:0.0}; batchWindowMs={windowMs:0.0}; enqueued={Interlocked.Read(ref _enqueued)}; " +
                    $"processed={Interlocked.Read(ref _processed)}; dropped={Interlocked.Read(ref _dropped)}; " +
                    $"coalesced={Interlocked.Read(ref _coalesced)}; authority=configurable");
            }
        }
        else
        {
            AppLogger.Info(
                $"window-event-reactor-shadow-batch: size={events.Length}; critical={critical}; movement={movement}; " +
                $"queueDelayMs={delayMs:0.0}; batchWindowMs={windowMs:0.0}; enqueued={Interlocked.Read(ref _enqueued)}; " +
                $"processed={Interlocked.Read(ref _processed)}; dropped={Interlocked.Read(ref _dropped)}; " +
                $"coalesced={Interlocked.Read(ref _coalesced)}; authority=configurable");
        }

        foreach (var ev in events.Select(item => item.Value)
                     .Where(ev => ev.Relevant && (ev.Kind is WindowMonitorEventKind.Created or WindowMonitorEventKind.Shown)))
        {
            ScheduleAssistedCandidateResolution(ev, stoppingToken);
        }
    }

    private void ScheduleAssistedCandidateResolution(WindowMonitorEvent ev, CancellationToken stoppingToken)
    {
        if (!_candidateResolutionInFlight.TryAdd(ev.Hwnd, 0))
        {
            AppLogger.Info($"window-event-reactor-candidate-deduped: kind={ev.Kind}; hwnd=0x{ev.Hwnd.ToInt64():X}; reason=resolution-already-in-flight");
            return;
        }

        _ = ResolveAssistedCandidateAsync(ev, stoppingToken);
    }

    private async Task ResolveAssistedCandidateAsync(WindowMonitorEvent ev, CancellationToken stoppingToken)
    {
        var started = DateTimeOffset.UtcNow;
        var lastRejection = "not-attempted";

        try
        {
            for (var attempt = 1; attempt <= CandidateValidationMaxAttempts; attempt++)
            {
                if (_discovery.TryGetPipWindow(ev.Hwnd, out var window, out lastRejection) && window is not null)
                {
                    var latencyMs = Math.Max(0, (DateTimeOffset.UtcNow - ev.CreatedAtUtc).TotalMilliseconds);
                    AppLogger.Info(
                        $"window-event-reactor-candidate-ready: kind={ev.Kind}; hwnd=0x{ev.Hwnd.ToInt64():X}; " +
                        $"process={window.ProcessName}; class={window.ClassName}; score={window.Score}; attempt={attempt}; " +
                        $"validationLatencyMs={latencyMs:0.0}; delivery=prepared-capture-assisted");

                    AssistedPipCandidateReady?.Invoke(new WindowEventReactorPipCandidate(ev, window, attempt, latencyMs));
                    return;
                }

                if (attempt < CandidateValidationMaxAttempts)
                    await Task.Delay(CandidateValidationRetryMs, stoppingToken).ConfigureAwait(false);
            }

            var elapsedMs = Math.Max(0, (DateTimeOffset.UtcNow - started).TotalMilliseconds);
            AppLogger.Info(
                $"window-event-reactor-candidate-rejected: kind={ev.Kind}; hwnd=0x{ev.Hwnd.ToInt64():X}; " +
                $"attempts={CandidateValidationMaxAttempts}; elapsedMs={elapsedMs:0.0}; reason={lastRejection}");
        }
        catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
        {
            // Normal shutdown.
        }
        catch (Exception ex)
        {
            AppLogger.Warn($"window-event-reactor-candidate-failed: kind={ev.Kind}; hwnd=0x{ev.Hwnd.ToInt64():X}; error={ex.Message}");
        }
        finally
        {
            _candidateResolutionInFlight.TryRemove(ev.Hwnd, out _);
        }
    }

    private static string BuildCoalesceKey(WindowMonitorEvent ev)
    {
        var category = ev.Kind == WindowMonitorEventKind.MovedOrResized
            ? "movement"
            : ev.Kind.ToString();
        return $"{ev.Hwnd.ToInt64():X}:{category}";
    }
}
