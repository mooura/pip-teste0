$ErrorActionPreference = "Stop"
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$main = Get-Content (Join-Path $root "src\PiPManager.Wpf\MainWindow.xaml.cs") -Raw
$layout = Get-Content (Join-Path $root "src\PiPManager.Wpf\MainWindow.Layout.cs") -Raw
$service = Get-Content (Join-Path $root "src\PiPManager.Wpf\Services\PipWindowService.cs") -Raw
$checks = @(
  @{Name="layout transaction guard"; Ok=$main.Contains("layout-transaction-start") -and $main.Contains("IsLayoutTransactionActive")},
  @{Name="self movement suppression"; Ok=$main.Contains("window-event-layout-self-move-suppressed")},
  @{Name="DWM movement tolerance"; Ok=$main.Contains("LayoutMovePositionTolerancePx = 4") -and $main.Contains("LayoutMoveSizeTolerancePx = 3")},
  @{Name="atomic move and resize batch"; Ok=$service.Contains("MoveAndResizeVisualBatch") -and $service.Contains("BeginDeferWindowPos")},
  @{Name="layout uses atomic batch"; Ok=$layout.Contains("MoveAndResizeVisualBatch(batch") -and $layout.Contains("MoveVisualBatch(batch")},
  @{Name="capture all applies layout"; Ok=$main.Contains("capture-all-stable-layout-debounce-requested")},
  @{Name="lock applies layout once"; Ok=$main.Contains("lock-group-atomic-layout-applied")}
)
$failed = 0
foreach ($check in $checks) {
  if ($check.Ok) { Write-Host ($check.Name + ": OK") } else { Write-Host ($check.Name + ": FAIL"); $failed++ }
}
if ($failed -gt 0) { throw "Atomic layout DWM gap stabilization checks failed." }
Write-Host "Atomic layout DWM gap stabilization checks OK."
