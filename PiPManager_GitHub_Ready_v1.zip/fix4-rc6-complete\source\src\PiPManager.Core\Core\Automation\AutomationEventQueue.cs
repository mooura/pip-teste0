﻿using System.Threading;
using System.Threading.Channels;

namespace PiPManager.Core.Automation;

/// <summary>
/// Fila única de eventos de automação.
/// Produtores múltiplos; consumidor único.
/// </summary>
public sealed class AutomationEventQueue
{
    private readonly Channel<AutomationEvent> _channel =
        Channel.CreateUnbounded<AutomationEvent>(
            new UnboundedChannelOptions
            {
                SingleReader = true,
                SingleWriter = false,
                AllowSynchronousContinuations = false
            });

    public ValueTask PublishAsync(AutomationEvent ev, CancellationToken cancellationToken = default)
        => _channel.Writer.WriteAsync(ev, cancellationToken);

    public IAsyncEnumerable<AutomationEvent> ReadAllAsync(CancellationToken cancellationToken = default)
        => _channel.Reader.ReadAllAsync(cancellationToken);

    public bool TryComplete(Exception? error = null)
        => _channel.Writer.TryComplete(error);
}
