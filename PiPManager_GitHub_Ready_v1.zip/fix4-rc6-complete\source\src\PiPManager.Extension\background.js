﻿'use strict';

const BRIDGE_VERSION = '1.4.39.7-autoreturn-confirmed-lifetime';

const WS_URL = 'ws://127.0.0.1:45151/ws';
let socket = null;
let reconnectTimer = null;
let nextVideoPreloadEnabled = false;
const nextVideoPreloadByTab = new Map();

// Coordenação de preload entre abas: com vários PiPs simultâneos, deixar cada
// aba pré-carregar seu próprio "próximo vídeo" ao mesmo tempo compete por banda
// com os vídeos que já estão em reprodução. Limitamos quantas abas podem ter um
// preload de rede ativo ao mesmo tempo; as demais aguardam liberar um slot.
const MAX_CONCURRENT_NEXT_VIDEO_PRELOADS = 1;
const activeNextVideoPreloadSlots = new Map(); // tabId -> assetId

// videoSessionId -> session info
const videoSessions = new Map();
// stableVideoKey -> latest session info
const stableSessions = new Map();

const SESSIONS_SNAPSHOT_HEARTBEAT_MS = 5000;
const SESSION_SNAPSHOT_TTL_MS = 30000;
const TAB_DISCOVERY_PROBE_TIMEOUT_MS = 1200;
let lastSessionsSnapshotSignature = '';
let lastSessionsSnapshotSentAt = 0;
let lastTabDiscovery = [];
let activeTabDiscoveryPromise = null;

const EXPECTED_CONTENT_VERSION_PREFIX = '1.4.39.7-';

function isExpectedContentVersion(version) {
  return String(version || '').startsWith(EXPECTED_CONTENT_VERSION_PREFIX);
}

async function checkContentCapabilities(tabId, frameId, attemptId, silent, messageType) {
  try {
    const response = await sendMessageToTabFrame(tabId, frameId, {
      type: 'pipManagerCapabilityCheck',
      attemptId,
      expectedContentVersionPrefix: EXPECTED_CONTENT_VERSION_PREFIX
    });

    const contentVersion = response && response.contentVersion ? response.contentVersion : '';
    const hasReacquireBestVisible = !!(response && response.hasReacquireBestVisible);
    const versionOk = isExpectedContentVersion(contentVersion);
    const capabilityOk = messageType !== 'openPictureInPictureReacquireBestVisible' || hasReacquireBestVisible;
    const ok = !!(response && response.ok && versionOk && capabilityOk);

    sendToApp({
      type: 'silentDiagnostic',
      event: ok ? 'content-capability-check-ok' : 'content-capability-check-failed',
      attemptId,
      silent,
      ok,
      reasonCode: ok ? '' : 'content-version-mismatch',
      reason: ok ? '' : 'content capability/version mismatch',
      reasonMessage: ok ? '' : `expected=${EXPECTED_CONTENT_VERSION_PREFIX}; actual=${contentVersion}; hasReacquireBestVisible=${hasReacquireBestVisible}`,
      method: 'capability-check',
      match: '',
      targetStrategy: '',
      tabId,
      frameId,
      contentVersion,
      expectedContentVersion: EXPECTED_CONTENT_VERSION_PREFIX,
      hasReacquireBestVisible,
      hasSilentStrong: !!(response && response.hasSilentStrong),
      pageInstanceId: response && response.pageInstanceId ? response.pageInstanceId : '',
      title: response && response.title ? response.title : '',
      domain: response && response.domain ? response.domain : '',
      ts: Date.now()
    });

    return {
      ok,
      contentVersion,
      hasReacquireBestVisible,
      reasonCode: ok ? '' : 'content-version-mismatch',
      reason: ok ? '' : 'content-capability-check-failed',
      response
    };
  } catch (err) {
    const reason = err && err.message ? err.message : String(err);
    sendToApp({
      type: 'silentDiagnostic',
      event: 'content-capability-check-failed',
      attemptId,
      silent,
      ok: false,
      reasonCode: 'content-version-mismatch',
      reason,
      reasonMessage: reason,
      method: 'capability-check',
      tabId,
      frameId,
      expectedContentVersion: EXPECTED_CONTENT_VERSION_PREFIX,
      ts: Date.now()
    });
    return { ok: false, contentVersion: '', reasonCode: 'content-version-mismatch', reason };
  }
}

function api() {
  return typeof browser !== 'undefined' ? browser : chrome;
}

function log(...args) {
  console.log('[PiP Manager Bridge]', ...args);
}



const __pipManagerBlock53ForcedProbeAttemptIds = new Set();

function forceSilentMultiFrameProbeFromRawMessageBlock53(message, rawText) {
    try {
        const msg = message || {};
        if (msg?.type !== 'silentMultiFrameProbe')
            return;

        const attemptId = msg?.attemptId || `mf53-${Date.now()}`;
        if (__pipManagerBlock53ForcedProbeAttemptIds.has(attemptId)) {
            sendToApp({
                type: 'silentDiagnostic',
                event: 'pip-preserve-silent-multiframe-force-route-deduped-block53',
                attemptId,
                silent: true,
                ok: true,
                result: 'deduped',
                reason: `attemptId=${attemptId}`,
                method: 'silent-multiframe-force-probe-from-raw',
                targetStrategy: 'raw-onmessage-validated',
                tabId: Number(msg?.tabId || msg?.targetTabId || 0),
                frameId: 0,
                contentVersion: BRIDGE_VERSION,
                expectedContentVersion: EXPECTED_CONTENT_VERSION_PREFIX,
                ts: Date.now()
            });
            return;
        }

        __pipManagerBlock53ForcedProbeAttemptIds.add(attemptId);

        const tabId = Number(msg?.tabId || msg?.targetTabId || 0);
        sendToApp({
            type: 'silentDiagnostic',
            event: 'pip-preserve-silent-multiframe-force-route-dispatch-block53',
            attemptId,
            silent: true,
            ok: true,
            result: 'forced-dispatch-from-raw',
            reason: `tabId=${tabId}; hasSession=${!!msg?.targetVideoSessionId}; hasStable=${!!msg?.targetStableVideoKey}; videoIndex=${Number(msg?.videoIndex || 0)}; source=${msg?.source || ''}; sourceAttemptId=${msg?.sourceAttemptId || ''}`,
            reasonMessage: (typeof rawText === 'string' ? rawText : '').slice(0, 500).replace(/\s+/g, ' '),
            method: 'silent-multiframe-force-probe-from-raw',
            targetStrategy: 'raw-onmessage-validated',
            tabId,
            frameId: 0,
            videoIndex: Number(msg?.videoIndex || 0),
            contentVersion: BRIDGE_VERSION,
            expectedContentVersion: EXPECTED_CONTENT_VERSION_PREFIX,
            ts: Date.now()
        });

        Promise.resolve()
            .then(() => silentMultiFrameProbeForTarget(msg, null))
            .then((results) => {
                const list = Array.isArray(results) ? results : [];
                const framesWithVideo = list.filter(r => Number(r?.videoCount || 0) > 0);
                const requestableFrames = list.filter(r => !!r?.hasAnyRequestable);
                const wrongFrameSuspected = list.some(r => !!r?.wrongFrameSuspected);
                const bestFrame = list.slice().sort((a, b) => Number(b?.bestScore || 0) - Number(a?.bestScore || 0))[0] || null;

                sendToApp({
                    type: 'silentDiagnostic',
                    event: 'pip-preserve-silent-multiframe-force-route-completed-block53',
                    attemptId,
                    silent: true,
                    ok: true,
                    result: 'forced-probe-completed',
                    reason: `framesAnswered=${list.length}; framesWithVideo=${framesWithVideo.length}; requestableFrames=${requestableFrames.length}; wrongFrameSuspected=${wrongFrameSuspected}`,
                    reasonMessage: `bestFrame=${bestFrame ? bestFrame.frameId : -1}; bestIndex=${bestFrame ? bestFrame.bestIndex : -1}; bestScore=${bestFrame ? bestFrame.bestScore : 0}`,
                    method: 'silent-multiframe-force-probe-from-raw',
                    targetStrategy: 'raw-onmessage-validated',
                    tabId,
                    frameId: Number(bestFrame?.frameId || 0),
                    videoIndex: Number(bestFrame?.bestIndex || 0),
                    contentVersion: bestFrame?.contentVersion || BRIDGE_VERSION,
                    expectedContentVersion: EXPECTED_CONTENT_VERSION_PREFIX,
                    ts: Date.now()
                });
            })
            .catch((e) => {
                sendToApp({
                    type: 'silentDiagnostic',
                    event: 'pip-preserve-silent-multiframe-force-route-failed-block53',
                    attemptId,
                    silent: true,
                    ok: false,
                    result: 'forced-probe-failed',
                    reasonCode: 'force-probe-failed',
                    reason: e?.message || String(e),
                    method: 'silent-multiframe-force-probe-from-raw',
                    targetStrategy: 'raw-onmessage-validated',
                    tabId,
                    frameId: 0,
                    contentVersion: BRIDGE_VERSION,
                    expectedContentVersion: EXPECTED_CONTENT_VERSION_PREFIX,
                    ts: Date.now()
                });
            });
    } catch (e) {
        try {
            sendToApp({
                type: 'silentDiagnostic',
                event: 'pip-preserve-silent-multiframe-force-route-dispatch-failed-block53',
                attemptId: message?.attemptId || '',
                silent: true,
                ok: false,
                result: 'force-dispatch-failed',
                reasonCode: 'force-dispatch-failed',
                reason: e?.message || String(e),
                method: 'silent-multiframe-force-probe-from-raw',
                targetStrategy: 'raw-onmessage-validated',
                tabId: Number(message?.tabId || message?.targetTabId || 0),
                frameId: 0,
                contentVersion: BRIDGE_VERSION,
                expectedContentVersion: EXPECTED_CONTENT_VERSION_PREFIX,
                ts: Date.now()
            });
        } catch {}
    }
}


function auditRawWebSocketMessageBlock52(rawText, parsedMessage, phase) {
    try {
        const msg = parsedMessage || {};
        const raw = typeof rawText === 'string' ? rawText : '';
        const messageType = msg?.type || '';
        const tabId = Number(msg?.tabId || msg?.targetTabId || 0);
        const attemptId = msg?.attemptId || msg?.sourceAttemptId || '';
        const sourceAttemptId = msg?.sourceAttemptId || '';
        const source = msg?.source || '';
        const rawPreview = raw.slice(0, 500).replace(/\s+/g, ' ');

        sendToApp({
            type: 'silentDiagnostic',
            event: 'pip-preserve-ws-raw-message-received-block52',
            attemptId,
            silent: String(messageType).toLowerCase().includes('silent') || messageType === 'silentMultiFrameProbe',
            ok: true,
            result: 'ws-raw-message-received',
            reasonCode: '',
            reason: `phase=${phase || ''}; type=${messageType}; tabId=${tabId}; source=${source}; sourceAttemptId=${sourceAttemptId}`,
            reasonMessage: rawPreview,
            method: 'background-websocket-raw-audit',
            targetStrategy: 'before-route-if',
            tabId,
            frameId: 0,
            contentVersion: BRIDGE_VERSION,
            expectedContentVersion: EXPECTED_CONTENT_VERSION_PREFIX,
            ts: Date.now()
        });

        if (messageType === 'silentMultiFrameProbe') {
            sendToApp({
                type: 'silentDiagnostic',
                event: 'pip-preserve-ws-raw-silentmultiframe-received-block52',
                attemptId,
                silent: true,
                ok: true,
                result: 'silentMultiFrameProbe-received-before-route',
                reasonCode: '',
                reason: `tabId=${tabId}; hasSession=${!!msg?.targetVideoSessionId}; hasStable=${!!msg?.targetStableVideoKey}; videoIndex=${Number(msg?.videoIndex || 0)}; source=${source}; sourceAttemptId=${sourceAttemptId}`,
                reasonMessage: rawPreview,
                method: 'background-websocket-raw-audit',
                targetStrategy: 'before-silentMultiFrameProbe-route',
                tabId,
                frameId: 0,
                videoIndex: Number(msg?.videoIndex || 0),
                contentVersion: BRIDGE_VERSION,
                expectedContentVersion: EXPECTED_CONTENT_VERSION_PREFIX,
                ts: Date.now()
            });
            try {
                // 9.32.13 Final Stable Clean Patch 3:
                // o force-probe-from-raw do bloco 53 era provisório e duplicava a rota normal.
                // A rota normal silentMultiFrameProbe agora é autoritativa.
                log('pip-preserve-silent-multiframe-force-probe-from-raw-disabled-cleanpatch3', {
                    attemptId: msg && (msg.attemptId || msg.sourceAttemptId || ''),
                    reason: 'normal-route-active'
                });
                void 'block53-force-probe-from-raw-call';
            } catch {}

        }
    } catch (e) {
        try {
            sendToApp({
                type: 'silentDiagnostic',
                event: 'pip-preserve-ws-raw-audit-failed-block52',
                attemptId: '',
                silent: true,
                ok: false,
                result: 'failed',
                reasonCode: 'ws-raw-audit-failed',
                reason: e?.message || String(e),
                method: 'background-websocket-raw-audit',
                targetStrategy: 'before-route-if',
                ts: Date.now()
            });
        } catch {}
    }
}


function connect() {
  if (socket && (socket.readyState === WebSocket.OPEN || socket.readyState === WebSocket.CONNECTING)) return;

  try {
    socket = new WebSocket(WS_URL);
  } catch (_) {
    scheduleReconnect();
    return;
  }

  socket.onopen = () => {
    log('conectado ao app local');
    sendToApp({ type: 'hello', from: 'extension', version: BRIDGE_VERSION });
  };

  socket.onmessage = async (event) => {
    let message;
    try { message = JSON.parse(event.data);
      if (message && message.type === 'authChallenge' && message.token) {
        sendToApp({
          type: 'authConfirm',
          version: BRIDGE_VERSION,
          token: message.token,
          source: 'authChallenge-cleanpatch3',
          ts: Date.now()
        });
        return;
      }
        try {
            auditRawWebSocketMessageBlock52(typeof event?.data === 'string' ? event.data : String(event?.data || ''), message, 'block52-ws-raw-audit-after-json-parse');
        } catch {}

        try {
            logSilentDiagnostic('extension-ws-message-received', {
                attemptId: message?.attemptId || '',
                silent: !!String(message?.type || '').toLowerCase().includes('silent'),
                ok: true,
                reason: `type=${message?.type || ''}; tabId=${message?.tabId || message?.targetTabId || 0}`,
                method: 'websocket-route-audit',
                tabId: Number(message?.tabId || message?.targetTabId || 0)
            });
            if (message?.type === 'silentMultiFrameProbe') {
                logSilentDiagnostic('pip-preserve-silent-multiframe-route-message-received', {
                    attemptId: message?.attemptId || '',
                    silent: true,
                    ok: true,
                    reason: `type=${message?.type}; tabId=${message?.tabId || message?.targetTabId || 0}`,
                    method: 'websocket-route-audit',
                    tabId: Number(message?.tabId || message?.targetTabId || 0)
                });
            }
        } catch {}
 } catch (_) { return; }

    if (message.type === 'videoCommand') {
      await sendVideoCommand(
        message.command,
        message.operationId || '',
        message.targetVideoSessionId || '',
        message.targetStableVideoKey || '',
        message.targetTabId,
        !!message.allowNoVideoTarget,
        !!message.allowSameTabNavigation
      );
    }

    if (message.type === 'nextVideoPreloadSetting') {
      nextVideoPreloadEnabled = !!message.enabled;
      const targetTabId = Number(message.targetTabId || 0);
      if (targetTabId > 0) {
        nextVideoPreloadByTab.set(targetTabId, nextVideoPreloadEnabled);
        await sendMessageToTab(targetTabId, { type: 'pipManagerNextPreloadSetting', enabled: nextVideoPreloadEnabled });
      } else {
        const tabs = await api().tabs.query({});
        await Promise.allSettled(tabs.map(tab => {
          if (!tab.id) return Promise.resolve();
          nextVideoPreloadByTab.set(tab.id, nextVideoPreloadEnabled);
          return sendMessageToTab(tab.id, { type: 'pipManagerNextPreloadSetting', enabled: nextVideoPreloadEnabled });
        }));
      }
      sendToApp({ type: 'pipManagerNextPreloadDiagnostic', event: 'setting-applied', targetTabId, enabled: nextVideoPreloadEnabled, ts: Date.now() });
    }

    if (message.type === 'openPictureInPicture') {
      await openPictureInPictureForTarget(
        message.targetVideoSessionId || '',
        message.targetStableVideoKey || '',
        message.targetTabId,
        true
      );
    }

    if (message.type === 'openPictureInPictureSilent') {
      await openPictureInPictureForTarget(
        message.targetVideoSessionId || '',
        message.targetStableVideoKey || '',
        message.targetTabId,
        false,
        message.attemptId || ''
      );
    }

    if (message.type === 'silentReopenPreflight') {
      await silentReopenPreflightForTarget(
        message.targetVideoSessionId || '',
        message.targetStableVideoKey || '',
        message.targetTabId,
        message.attemptId || ''
      );
    }


    if (message.type === 'silentMultiFrameProbe') {
      await silentMultiFrameProbeForTarget({
        type: 'silentMultiFrameProbe',
        targetVideoSessionId: message.targetVideoSessionId || '',
        targetStableVideoKey: message.targetStableVideoKey || '',
        targetTabId: message.targetTabId,
        tabId: message.tabId || message.targetTabId,
        videoIndex: typeof message.videoIndex === 'number' ? message.videoIndex : 0,
        attemptId: message.attemptId || '',
        sourceAttemptId: message.sourceAttemptId || '',
        source: message.source || 'normal-route'
      }, null);
    }

    if (message.type === 'openPictureInPictureReacquire') {
      await openPictureInPictureForTarget(
        message.targetVideoSessionId || '',
        message.targetStableVideoKey || '',
        message.targetTabId,
        !message.silent,
        message.attemptId || '',
        true
      );
    }

    if (message.type === 'focusVideoTab') {
      await focusVideoTab(Number(message.targetTabId || 0));
    }

    if (message.type === 'requestVideoSessionsSnapshot') {
      await requestAllVideoStates(String(message.requestId || ''));
      sendSessionsSnapshot(true);
    }

    // Handle occupied slots notification from WPF app
    if (message.type === 'notify-occupied-slots') {
      const occupiedSlots = message.occupiedSlots || [];
      
      // Forward to ALL tabs currently loaded
      const tabs = await api().tabs.query({});
      await Promise.allSettled(tabs.map(tab => {
        if (!tab.id) return Promise.resolve();
        return sendMessageToTabFrame(tab.id, 0, {
          type: 'tab-occupied-slots',
          occupiedSlots: occupiedSlots,
          timestamp: message.timestamp
        }).catch(err => {
          // Silent fail - tab might not have content script loaded
        });
      }));
    }
  };

  socket.onclose = () => {
    log('desconectado do app local');
    scheduleReconnect();
  };

  socket.onerror = () => {
    try { socket.close(); } catch (_) {}
  };
}

function scheduleReconnect() {
  if (reconnectTimer) return;
  reconnectTimer = setTimeout(() => {
    reconnectTimer = null;
    connect();
  }, 1200);
}

function sendToApp(payload) {
  if (!socket || socket.readyState !== WebSocket.OPEN) return false;
  try {
    socket.send(JSON.stringify(payload));
    return true;
  } catch (_) {
    return false;
  }
}


function isLikelyAdvertisementSession(session) {
  if (!session) return false;

  const title = String(session.title || '').toLowerCase();
  const domain = String(session.domain || '').replace(/^www\./i, '').toLowerCase();
  const url = String(session.url || '').toLowerCase();
  const flags = String(session.candidateFlags || '').toLowerCase();

  if (session.isLikelyAd === true) return true;
  if (flags.includes('blocked-ad:')) return true;
  if (/\b(outstream\s+ad|ad\s+content|video\s+advertisement|video\s+ad|sponsored\s+video|instream\s+ad|pre[-\s]?roll\s+ad|mobile\s+slider)\b/i.test(title)) return true;

  const knownAdHostSuffixes = [
    'aphroxa.com',
    'trendbuzz.to',
    'quality-traffic.com',
    'contentsserved.com',
    'creative.cambaddies.com',
    'creative.prncams.com',
    'doubleclick.net',
    'googlesyndication.com',
    'adnxs.com',
    'adsrvr.org',
    'criteo.com',
    'taboola.com',
    'outbrain.com'
  ];

  if (knownAdHostSuffixes.some(suffix => domain === suffix || domain.endsWith(`.${suffix}`))) return true;
  if (/(?:[?&](?:campaignid|creativeid|smartpopid|traffictype|adunit|placementid)=|banneriframe|outstream|\/vast(?:\/|\?|$)|\/prebid(?:\/|\?|$)|\/ads?(?:\/|\?|$))/i.test(url)) return true;

  return false;
}

function removeSessionFromCaches(sessionId, session) {
  if (sessionId) videoSessions.delete(sessionId);
  const stableKey = session && session.stableVideoKey;
  if (stableKey && stableSessions.get(stableKey)?.videoSessionId === sessionId) {
    stableSessions.delete(stableKey);
  }
}

function purgeLikelyAdvertisementSessions() {
  for (const [sessionId, session] of Array.from(videoSessions.entries())) {
    if (isLikelyAdvertisementSession(session)) {
      removeSessionFromCaches(sessionId, session);
    }
  }
}

function buildSessionsSnapshotSignature(sessions) {
  return JSON.stringify((sessions || []).map(session => ({
    videoSessionId: session.videoSessionId || '',
    stableVideoKey: session.stableVideoKey || '',
    tabId: Number(session.tabId || 0),
    windowId: Number(session.windowId || 0),
    frameId: Number(session.frameId || 0),
    url: session.url || '',
    intrinsicVideoWidth: Number(session.intrinsicVideoWidth || 0),
    intrinsicVideoHeight: Number(session.intrinsicVideoHeight || 0),
    intrinsicAspectRatio: Number(session.intrinsicAspectRatio || 0),
    isPlaying: !!session.isPlaying,
    readyState: Number(session.readyState || 0),
    paused: !!session.paused,
    ended: !!session.ended,
    hasSource: !!session.hasSource,
    isActiveTab: !!session.isActiveTab,
    playlistDetected: !!session.playlistDetected,
    siteProfileId: session.siteProfileId || '',
    siteContentKind: session.siteContentKind || 'unknown',
    siteNextStrategy: session.siteNextStrategy || '',
    playlistIndex: Number(session.playlistIndex ?? -1),
    currentItemTitle: session.currentItemTitle || '',
    nextTitles: Array.isArray(session.nextTitles) ? session.nextTitles.slice(0, 5) : [],
    nextPreviewTitle: session.nextPreviewTitle || '',
    nextPreviewThumbnailUrl: session.nextPreviewThumbnailUrl || '',
    nextPreviewVideoUrl: session.nextPreviewVideoUrl || '',
    nextPreviewDuration: session.nextPreviewDuration || '',
    nextPreviewIndex: Number(session.nextPreviewIndex ?? -1)
  })));
}

function sendSessionsSnapshot(force = false) {
  purgeLikelyAdvertisementSessions();
  const now = Date.now();
  const sessions = Array.from(videoSessions.values())
    .filter(s => s && s.hasVideo && !isLikelyAdvertisementSession(s) && (now - Number(s.lastSeenUnixMs || 0)) < SESSION_SNAPSHOT_TTL_MS)
    .sort((a, b) => Number(b.isPlaying) - Number(a.isPlaying) || Number(b.isActiveTab) - Number(a.isActiveTab) || String(a.domain).localeCompare(String(b.domain)) || a.videoIndex - b.videoIndex);

  const signature = buildSessionsSnapshotSignature(sessions);
  if (!force
      && signature === lastSessionsSnapshotSignature
      && now - lastSessionsSnapshotSentAt < SESSIONS_SNAPSHOT_HEARTBEAT_MS) {
    return false;
  }

  lastSessionsSnapshotSignature = signature;
  lastSessionsSnapshotSentAt = now;
  sendToApp({
    type: 'videoSessionsSnapshot',
    sessions,
    discovery: lastTabDiscovery,
    discoveryComplete: lastTabDiscovery.length > 0,
    sessionTtlMs: SESSION_SNAPSHOT_TTL_MS
  });
  return true;
}

function sendTabDiscoveryDiagnostic(discovered, requestId = '') {
  const readyTabs = discovered.filter(item => item.sessionCount > 0).length;
  const unavailableTabs = discovered.filter(item => item.status === 'content-unavailable').length;
  sendToApp({
    type: 'tabDiscoveryDiagnostic',
    requestId: requestId || '',
    totalHttpTabs: discovered.length,
    readyTabs,
    unavailableTabs,
    tabs: discovered,
    ts: Date.now()
  });
}

async function requestAllVideoStates(requestIdOverride = '') {
  if (activeTabDiscoveryPromise) {
    const discovered = await activeTabDiscoveryPromise;
    if (requestIdOverride) sendTabDiscoveryDiagnostic(discovered, requestIdOverride);
    return discovered;
  }

  activeTabDiscoveryPromise = (async () => {
    const requestId = requestIdOverride || `discover-${Date.now().toString(36)}`;
    let tabs = [];
    try {
      tabs = (await queryTabs({}) || []).filter(tab => tab && tab.id && isHttpUrl(tab.url));
    } catch (_) {
      lastTabDiscovery = [];
      return [];
    }

    const discovered = await Promise.all(tabs.map(async tab => {
      let frames = [{ frameId: 0, url: tab.url || '' }];
      try {
        const listedFrames = await getAllFrames(tab.id);
        if (Array.isArray(listedFrames) && listedFrames.length > 0) {
          frames = listedFrames
            .filter(frame => Number.isInteger(frame.frameId) && isHttpUrl(frame.url || tab.url))
            .map(frame => ({ frameId: frame.frameId, url: frame.url || tab.url || '' }));
        }
      } catch (_) {}

      const uniqueFrames = Array.from(new Map(frames.map(frame => [frame.frameId, frame])).values());
      const frameResults = await Promise.all(uniqueFrames.map(frame => probeVideoStateFrame(tab, frame, requestId)));
      const responsive = frameResults.filter(result => result.responded);
      const sessionCount = responsive.reduce((sum, result) => sum + result.sessionCount, 0);
      const rawVideoCount = responsive.reduce((sum, result) => sum + result.rawVideoCount, 0);
      const status = sessionCount > 0
        ? 'video-ready'
        : responsive.length > 0
          ? (rawVideoCount > 0 ? 'video-filtered-or-loading' : 'no-video')
          : 'content-unavailable';

      return {
        tabId: tab.id,
        windowId: Number(tab.windowId || 0),
        url: tab.url || '',
        title: tab.title || '',
        frameCount: uniqueFrames.length,
        responsiveFrames: responsive.length,
        sessionCount,
        rawVideoCount,
        status
      };
    }));

    lastTabDiscovery = discovered;
    sendTabDiscoveryDiagnostic(discovered, requestId);
    return discovered;
  })();

  try {
    return await activeTabDiscoveryPromise;
  } finally {
    activeTabDiscoveryPromise = null;
  }
}

async function probeVideoStateFrame(tab, frame, requestId) {
  try {
    const response = await withTimeout(
      sendMessageToTabFrame(tab.id, frame.frameId, { type: 'requestVideoState', requestId }),
      TAB_DISCOVERY_PROBE_TIMEOUT_MS);

    if (!response || !Array.isArray(response.sessions)) {
      return { frameId: frame.frameId, responded: !!response, sessionCount: 0, rawVideoCount: 0 };
    }

    for (const session of response.sessions) {
      const value = normalizeSessionFromContent({
        ...session,
        frameId: frame.frameId,
        isActiveTab: !!response.isActiveTab,
        contentVersion: response.contentVersion || ''
      }, tab, response.videoCount || response.sessions.length);
      if (isLikelyAdvertisementSession(value)) {
        removeSessionFromCaches(value.videoSessionId, value);
        continue;
      }
      videoSessions.set(value.videoSessionId, value);
      stableSessions.set(value.stableVideoKey || value.videoSessionId, value);
    }

    return {
      frameId: frame.frameId,
      responded: true,
      sessionCount: response.sessions.length,
      rawVideoCount: Number(response.rawVideoCount || 0)
    };
  } catch (err) {
    return {
      frameId: frame.frameId,
      responded: false,
      sessionCount: 0,
      rawVideoCount: 0,
      reason: err && err.message ? err.message : String(err)
    };
  }
}

async function requestTabVideoState(tabId) {
  if (!tabId) return;
  try { await sendMessageToTab(tabId, { type: 'requestVideoState' }); } catch (_) {}
}


async function focusVideoTab(tabId) {
  if (!tabId) {
    sendToApp({ type: 'focusTabResult', ok: false, reason: 'no-tab' });
    return;
  }

  try {
    const tab = await getTab(tabId);
    if (tab && tab.windowId) {
      try { await updateWindow(tab.windowId, { focused: true }); } catch (_) {}
    }
    await updateTab(tabId, { active: true });
    sendToApp({ type: 'focusTabResult', ok: true, tabId });
  } catch (err) {
    sendToApp({ type: 'focusTabResult', ok: false, tabId, reason: err && err.message ? err.message : String(err) });
  }
}


function isFreshSession(session, ttlMs = SESSION_SNAPSHOT_TTL_MS) {
  if (!session) return false;
  const lastSeen = Number(session.lastSeenUnixMs || 0);
  return !!session.hasVideo && lastSeen > 0 && (Date.now() - lastSeen) <= ttlMs;
}

function getFreshSessionsForTab(tabId) {
  const id = Number(tabId || 0);
  if (!id) return [];
  return Array.from(videoSessions.values())
    .filter(s => s && Number(s.tabId) === id && isFreshSession(s));
}

function scoreAutoReturnReacquireSession(session, targetVideoSessionId, targetStableVideoKey, targetTabId) {
  if (!session) return -999;
  let score = 0;

  if (Number(session.tabId) === Number(targetTabId || 0)) score += 90;
  if (targetStableVideoKey && session.stableVideoKey === targetStableVideoKey) score += 35;
  if (targetVideoSessionId && session.videoSessionId === targetVideoSessionId) score += 20;

  const width = Number(session.width || session.videoWidth || 0);
  const height = Number(session.height || session.videoHeight || 0);
  const area = Math.max(0, width * height);

  score += Math.min(80, area / 9000);
  if (session.isPlaying) score += 35;
  if (session.isActiveTab) score += 10;
  if (Number(session.duration || 0) >= 30 || Number(session.duration || 0) <= 0) score += 15;
  if (Number(session.currentTime || 0) <= 3) score += 8;

  return score;
}

function resolveBestVisibleSessionForTab(targetVideoSessionId, targetStableVideoKey, targetTabId) {
  const tabIdNumber = Number(targetTabId || 0);
  if (!tabIdNumber) {
    return { tabId: null, targetSession: null, match: 'best-visible-no-tab', ok: false, reason: 'no-target-tab' };
  }

  const candidates = getFreshSessionsForTab(tabIdNumber)
    .map(session => ({
      session,
      score: scoreAutoReturnReacquireSession(session, targetVideoSessionId, targetStableVideoKey, targetTabId)
    }))
    .sort((a, b) => b.score - a.score);

  if (candidates.length === 0) {
    return { tabId: null, targetSession: null, match: 'best-visible-none', ok: false, reason: 'target-player-not-found' };
  }

  const best = candidates[0];
  const second = candidates[1];

  if (second && best.score - second.score < 18) {
    return {
      tabId: null,
      targetSession: null,
      match: 'best-visible-ambiguous',
      ok: false,
      reason: 'best-visible-ambiguous',
      candidateCount: candidates.length,
      bestScore: best.score,
      secondScore: second.score
    };
  }

  return {
    tabId: best.session.tabId,
    targetSession: best.session,
    match: 'best-visible-same-tab',
    ok: true,
    candidateCount: candidates.length,
    bestScore: best.score,
    secondScore: second ? second.score : 0
  };
}

function resolveTargetSession(targetVideoSessionId, targetStableVideoKey, targetTabId, allowExplicitTabFallback) {
  const tabIdNumber = Number(targetTabId || 0);

  // 1) Alvo exato por sessão atual. Só aceita se estiver fresco.
  if (targetVideoSessionId && videoSessions.has(targetVideoSessionId)) {
    const targetSession = videoSessions.get(targetVideoSessionId);
    if (isFreshSession(targetSession)) {
      return { tabId: targetSession.tabId, targetSession, match: 'videoSessionId', ok: true };
    }
  }

  // 2) Fallback por stableVideoKey, preferindo a mesma aba vinculada.
  if (targetStableVideoKey) {
    const matches = Array.from(videoSessions.values())
      .filter(s => s && s.stableVideoKey === targetStableVideoKey && isFreshSession(s));

    if (matches.length === 1) {
      const targetSession = matches[0];
      return { tabId: targetSession.tabId, targetSession, match: 'stableVideoKey', ok: true };
    }

    if (matches.length > 1 && tabIdNumber > 0) {
      const sameTab = matches.filter(s => Number(s.tabId) === tabIdNumber);
      if (sameTab.length === 1) {
        const targetSession = sameTab[0];
        return { tabId: targetSession.tabId, targetSession, match: 'stableVideoKey+tabId', ok: true };
      }
      return { tabId: null, targetSession: null, match: 'stableVideoKey-tab-ambiguous', ok: false, reason: 'stable-target-ambiguous' };
    }

    if (matches.length > 1) {
      return { tabId: null, targetSession: null, match: 'stableVideoKey-ambiguous', ok: false, reason: 'stable-target-ambiguous' };
    }
  }

  // 3) Fallback controlado: se o vínculo aponta para uma aba e nela existe exatamente
  // um player fresco, usa esse player. Isso evita target-player-not-found quando o site
  // recria o elemento <video> e muda videoSessionId/stableVideoKey, mas continua sendo
  // claramente o único player daquela aba.
  if (tabIdNumber > 0) {
    const tabSessions = getFreshSessionsForTab(tabIdNumber);
    if (tabSessions.length === 1) {
      const targetSession = tabSessions[0];
      return { tabId: targetSession.tabId, targetSession, match: 'same-tab-single-player', ok: true };
    }
    if (tabSessions.length > 1) {
      return { tabId: null, targetSession: null, match: 'same-tab-ambiguous', ok: false, reason: 'target-tab-has-multiple-players' };
    }
  }

  if (targetVideoSessionId || targetStableVideoKey) {
    return { tabId: null, targetSession: null, match: 'linked-target-missing', ok: false, reason: 'target-player-not-found' };
  }

  if (allowExplicitTabFallback && tabIdNumber > 0) {
    return { tabId: tabIdNumber, targetSession: null, match: 'explicit-tabId', ok: true };
  }

  return { tabId: null, targetSession: null, match: 'none', ok: false, reason: 'no-linked-target' };
}

function normalizeOpenPipReasonCode(reason) {
  const text = String(reason || '').toLowerCase();
  if (text.includes('gesture') || text.includes('user activation') || text.includes('notallowed')) return 'gesture-required';
  if (text.includes('pip-not-allowed') || text.includes('permission') || text.includes('disabled') || text.includes('not supported')) return 'pip-not-allowed';
  if (text.includes('video-not-ready') || text.includes('ready') || text.includes('metadata')) return 'video-not-ready';
  if (text.includes('target') || text.includes('missing') || text.includes('no-target') || text.includes('not-found') || text.includes('ambiguous')) return 'target-not-found';
  if (text.includes('timeout')) return 'enterpip-timeout';
  if (text.includes('failed') || text.includes('exception')) return 'request-failed';
  if (!text) return '';
  return 'unknown-error';
}



function summarizeMultiFrameProbeResult(result) {
    if (!result) return '';
    const videos = Array.isArray(result.videos) ? result.videos : [];
    return videos.slice(0, 6).map(v => {
        const d = v.diagnostics || {};
        const r = v.rect || {};
        return `#${v.index}:score=${v.score},visible=${v.visible},matchS=${v.matchSession},matchK=${v.matchStable},ready=${d.readyState},pipEnabled=${d.pipEnabled},canRequest=${d.canRequest},ended=${d.ended},muted=${d.muted},size=${r.width}x${r.height}`;
    }).join(' | ');
}

async function silentMultiFrameProbeForTarget(message, ws) {
    const attemptId = message.attemptId || `mfprobe-${Date.now()}`;
    const sourceAttemptId = message.sourceAttemptId || '';
    const probeSource = message.source || '';
    const targetTabId = Number(message.targetTabId || message.tabId || 0);
    const targetVideoSessionId = message.targetVideoSessionId || '';
    const targetStableVideoKey = message.targetStableVideoKey || '';
    const videoIndex = typeof message.videoIndex === 'number' ? message.videoIndex : 0;

    function sendProbeStatus(eventName, data = {}) {
        try {
            logSilentDiagnostic(eventName, {
                attemptId,
                silent: true,
                tabId: targetTabId,
                frameId: Number(data.frameId || 0),
                ok: !!data.ok,
                result: data.result || '',
                found: !!data.found,
                requestAttempted: false,
                enterPipSeen: false,
                reasonCode: data.reasonCode || '',
                reason: data.reason || '',
                reasonMessage: data.reasonMessage || '',
                method: 'silent-multiframe-probe',
                match: data.match || '',
                strategy: data.strategy || '',
                targetStrategy: data.targetStrategy || '',
                domain: data.domain || '',
                title: data.title || '',
                videoIndex: typeof data.videoIndex === 'number' ? data.videoIndex : 0,
                contentVersion: data.contentVersion || '',
                expectedContentVersion: EXPECTED_CONTENT_VERSION_PREFIX
            });
        } catch (e) {
            console.warn('[PiPManager] multi-frame audit log failed', eventName, e);
        }
    }

    sendProbeStatus('pip-preserve-silent-multiframe-route-dispatch', {
        ok: true,
        reason: `dispatch-confirmed-inside-function; type=${message.type || ''}; tabId=${targetTabId}`,
        targetStrategy: 'dispatch-confirmed'
    });

    sendProbeStatus('pip-preserve-silent-multiframe-route-hit', {
        ok: true,
        reason: `type=${message.type || ''}; tabId=${targetTabId}; hasSession=${!!targetVideoSessionId}; hasStable=${!!targetStableVideoKey}; source=${probeSource || ''}; sourceAttemptId=${sourceAttemptId || ''}`,
        targetStrategy: 'route-hit'
    });

    sendProbeStatus('pip-preserve-silent-multiframe-probe-start', {
        ok: true,
        reason: 'start',
        targetStrategy: 'all-frames'
    });

    let frames = [];
    try {
        sendProbeStatus('pip-preserve-silent-multiframe-route-before-getAllFrames', {
            ok: true,
            reason: `tabId=${targetTabId}`
        });

        if (typeof browser !== 'undefined' && browser.webNavigation && browser.webNavigation.getAllFrames) {
            frames = await browser.webNavigation.getAllFrames({ tabId: targetTabId }) || [];

            sendProbeStatus('pip-preserve-silent-multiframe-route-after-getAllFrames', {
                ok: true,
                reason: `frames=${frames.length}`,
                reasonMessage: `frames=${frames.map(f => `${f.frameId}:${f.url || ''}`).join(' | ').slice(0, 700)}`
            });

            sendProbeStatus('pip-preserve-silent-multiframe-probe-frame-list-ok', {
                ok: true,
                reason: `frames=${frames.length}`,
                reasonMessage: `frames=${frames.map(f => `${f.frameId}:${f.url || ''}`).join(' | ').slice(0, 700)}`
            });
        } else {
            sendProbeStatus('pip-preserve-silent-multiframe-probe-frame-list-unavailable', {
                ok: false,
                reasonCode: 'webNavigation-unavailable',
                reason: 'browser.webNavigation.getAllFrames unavailable'
            });
        }
    } catch (e) {
        sendProbeStatus('pip-preserve-silent-multiframe-route-getAllFrames-threw', {
            ok: false,
            reasonCode: 'getAllFrames-threw',
            reason: e?.message || String(e)
        });

        sendProbeStatus('pip-preserve-silent-multiframe-probe-frame-list-failed', {
            ok: false,
            reasonCode: 'frame-list-failed',
            reason: e?.message || String(e)
        });
    }

    if (!frames.length) {
        frames = [{ frameId: 0, url: '' }];
        sendProbeStatus('pip-preserve-silent-multiframe-probe-frame-list-fallback-main-frame', {
            ok: true,
            frameId: 0,
            reason: 'fallback-main-frame'
        });
    }

    const results = [];
    let failures = 0;

    for (const frame of frames) {
        const frameId = Number(frame.frameId || 0);

        sendProbeStatus('pip-preserve-silent-multiframe-route-before-frame-sendMessage', {
            ok: true,
            frameId,
            reason: `tabId=${targetTabId}; frameUrl=${(frame.url || '').slice(0, 300)}`
        });

        try {
            const response = await browser.tabs.sendMessage(targetTabId, {
                type: 'silentMultiFrameProbe',
                targetVideoSessionId,
                targetStableVideoKey,
                videoIndex,
                attemptId
            }, { frameId });

            sendProbeStatus('pip-preserve-silent-multiframe-route-after-frame-sendMessage', {
                ok: !!response,
                frameId,
                reason: response ? 'response-received' : 'empty-response'
            });

            if (!response) {
                failures++;
                sendProbeStatus('pip-preserve-silent-multiframe-probe-frame-empty', {
                    ok: false,
                    frameId,
                    reasonCode: 'empty-frame-response',
                    reason: 'empty frame response'
                });
                continue;
            }

            response.frameId = frameId;
            response.frameUrl = frame.url || '';
            results.push(response);

            const videos = Array.isArray(response.videos) ? response.videos : [];
            const summary = videos.slice(0, 6).map(v => {
                const d = v.diagnostics || {};
                const r = v.rect || {};
                return `#${v.index}:score=${v.score},visible=${v.visible},matchS=${v.matchSession},matchK=${v.matchStable},ready=${d.readyState},pipEnabled=${d.pipEnabled},canRequest=${d.canRequest},ended=${d.ended},muted=${d.muted},size=${r.width}x${r.height}`;
            }).join(' | ');

            sendProbeStatus('pip-preserve-silent-multiframe-probe-frame-result', {
                ok: true,
                frameId,
                domain: response.domain || '',
                title: response.title || '',
                videoIndex: response.targetIndex ?? -1,
                reasonCode: response.wrongFrameSuspected ? 'wrong-frame-suspected' : '',
                reason: summary || `videoCount=${response.videoCount || 0}`,
                reasonMessage: `videoCount=${response.videoCount || 0}; targetFound=${response.targetFound}; bestIndex=${response.bestIndex}; bestScore=${response.bestScore}; targetIndex=${response.targetIndex}; targetScore=${response.targetScore}; hasAnyRequestable=${response.hasAnyRequestable}; wrongFrameSuspected=${response.wrongFrameSuspected}`,
                targetStrategy: response.targetStrategy || '',
                contentVersion: response.contentVersion || ''
            });
        } catch (e) {
            failures++;
            sendProbeStatus('pip-preserve-silent-multiframe-route-frame-sendMessage-threw', {
                ok: false,
                frameId,
                reasonCode: 'sendMessage-threw',
                reason: e?.message || String(e)
            });

            sendProbeStatus('pip-preserve-silent-multiframe-probe-frame-failed', {
                ok: false,
                frameId,
                reasonCode: 'frame-probe-failed',
                reason: e?.message || String(e)
            });
        }
    }

    const framesWithVideo = results.filter(r => Number(r.videoCount || 0) > 0);
    const requestableFrames = results.filter(r => r.hasAnyRequestable);
    const wrongFrameSuspected = results.some(r => r.wrongFrameSuspected);
    const bestFrame = results.slice().sort((a, b) => Number(b.bestScore || 0) - Number(a.bestScore || 0))[0] || null;

    sendProbeStatus('pip-preserve-silent-multiframe-route-before-summary', {
        ok: true,
        reason: `framesListed=${frames.length}; framesAnswered=${results.length}; failures=${failures}`
    });

    sendProbeStatus('pip-preserve-silent-multiframe-probe-summary', {
        ok: true,
        frameId: bestFrame ? bestFrame.frameId : 0,
        domain: bestFrame ? bestFrame.domain : '',
        title: bestFrame ? bestFrame.title : '',
        videoIndex: bestFrame ? bestFrame.bestIndex : -1,
        reasonCode: wrongFrameSuspected ? 'wrong-frame-suspected' : '',
        reason: `framesListed=${frames.length}; framesAnswered=${results.length}; framesFailed=${failures}; framesWithVideo=${framesWithVideo.length}; requestableFrames=${requestableFrames.length}; wrongFrameSuspected=${wrongFrameSuspected}`,
        reasonMessage: `bestFrame=${bestFrame ? bestFrame.frameId : -1}; bestIndex=${bestFrame ? bestFrame.bestIndex : -1}; bestScore=${bestFrame ? bestFrame.bestScore : 0}`,
        targetStrategy: 'summary',
        contentVersion: bestFrame ? bestFrame.contentVersion : ''
    });

    try {
        ws?.send?.(JSON.stringify({
            type: 'silentMultiFrameProbeResult',
            attemptId,
            tabId: targetTabId,
            ok: true,
            framesListed: frames.length,
            framesAnswered: results.length,
            framesFailed: failures,
            framesWithVideo: framesWithVideo.length,
            requestableFrames: requestableFrames.length,
            wrongFrameSuspected,
            bestFrameId: bestFrame ? bestFrame.frameId : -1,
            bestIndex: bestFrame ? bestFrame.bestIndex : -1,
            bestScore: bestFrame ? bestFrame.bestScore : 0
        }));

        sendProbeStatus('pip-preserve-silent-multiframe-route-ws-result-sent', {
            ok: true,
            reason: `framesAnswered=${results.length}; failures=${failures}`
        });
    } catch (e) {
        sendProbeStatus('pip-preserve-silent-multiframe-route-ws-result-send-failed', {
            ok: false,
            reasonCode: 'ws-result-send-failed',
            reason: e?.message || String(e)
        });
    }

    return results;
}


async function runSilentMultiFrameProbeFromPreflightPath(preflightMessage, ws, sourceAttemptId) {
    try {
        const mfAttemptId = `mfpath-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
        const targetTabId = Number(preflightMessage.targetTabId || preflightMessage.tabId || 0);
        logSilentDiagnostic('pip-preserve-silent-multiframe-preflight-path-dispatch', {
            attemptId: mfAttemptId,
            silent: true,
            ok: true,
            tabId: targetTabId,
            reason: `sourcePreflight=${sourceAttemptId || preflightMessage.attemptId || ''}; tabId=${targetTabId}`,
            method: 'silent-multiframe-preflight-path',
            targetStrategy: 'same-path-as-preflight'
        });

        await silentMultiFrameProbeForTarget({
            type: 'silentMultiFrameProbe',
            targetVideoSessionId: preflightMessage.targetVideoSessionId || '',
            targetStableVideoKey: preflightMessage.targetStableVideoKey || '',
            targetTabId,
            tabId: targetTabId,
            videoIndex: typeof preflightMessage.videoIndex === 'number' ? preflightMessage.videoIndex : 0,
            attemptId: mfAttemptId
        }, ws);

        logSilentDiagnostic('pip-preserve-silent-multiframe-preflight-path-completed', {
            attemptId: mfAttemptId,
            silent: true,
            ok: true,
            tabId: targetTabId,
            reason: `sourcePreflight=${sourceAttemptId || preflightMessage.attemptId || ''}`,
            method: 'silent-multiframe-preflight-path',
            targetStrategy: 'same-path-as-preflight'
        });
    } catch (e) {
        logSilentDiagnostic('pip-preserve-silent-multiframe-preflight-path-failed', {
            attemptId: `mfpath-failed-${Date.now()}`,
            silent: true,
            ok: false,
            tabId: Number(preflightMessage?.targetTabId || preflightMessage?.tabId || 0),
            reasonCode: 'preflight-path-multiframe-failed',
            reason: e?.message || String(e),
            method: 'silent-multiframe-preflight-path',
            targetStrategy: 'same-path-as-preflight'
        });
    }
}



function logMultiFrameAtPlayerStatePointFromDiagnostic(diag) {
    try {
        const attemptId = diag?.attemptId || '';
        const tabId = Number(diag?.tabId || 0);
        const frameId = Number(diag?.frameId || 0);
        const domain = diag?.domain || '';
        const title = diag?.title || '';
        const videoIndex = typeof diag?.videoIndex === 'number' ? diag.videoIndex : 0;
        const readyState = Number(diag?.readyState || 0);
        const pipEnabled = String(diag?.pipEnabled).toLowerCase() === 'true' || diag?.pipEnabled === true;
        const canRequest = String(diag?.canRequest).toLowerCase() === 'true' || diag?.canRequest === true;
        const disablePip = String(diag?.disablePip).toLowerCase() === 'true' || diag?.disablePip === true;
        const ended = String(diag?.ended).toLowerCase() === 'true' || diag?.ended === true;
        const muted = String(diag?.muted).toLowerCase() === 'true' || diag?.muted === true;
        const paused = String(diag?.paused).toLowerCase() === 'true' || diag?.paused === true;
        const size = diag?.size || '';

        const requestableVideos = canRequest ? 1 : 0;
        const requestableFrames = canRequest ? 1 : 0;
        const framesAnswered = 1;
        const framesWithVideo = diag?.found ? 1 : 0;
        const videoCount = diag?.found ? 1 : 0;
        const bestScore = (diag?.found ? 100 : 0)
            + (canRequest ? 60 : 0)
            + (pipEnabled ? 25 : 0)
            + (readyState >= 1 ? 10 : 0)
            - (ended ? 80 : 0);
        const wrongFrameSuspected = false;

        logSilentDiagnostic('pip-preserve-silent-multiframe-playerstate-frame-result', {
            attemptId,
            silent: true,
            ok: true,
            tabId,
            frameId,
            domain,
            title,
            videoIndex,
            found: !!diag?.found,
            result: 'derived-from-player-state',
            reasonCode: '',
            reason: `#${videoIndex}:score=${bestScore},ready=${readyState},pipEnabled=${pipEnabled},canRequest=${canRequest},disablePip=${disablePip},ended=${ended},muted=${muted},paused=${paused},size=${size}`,
            reasonMessage: `source=player-state; videoCount=${videoCount}; targetFound=${!!diag?.found}; bestIndex=${videoIndex}; bestScore=${bestScore}; targetIndex=${videoIndex}; targetScore=${bestScore}; requestableVideos=${requestableVideos}; wrongFrameSuspected=${wrongFrameSuspected}`,
            method: 'silent-multiframe-playerstate-injection',
            targetStrategy: 'player-state-exact-point',
            contentVersion: diag?.contentVersion || '',
            expectedContentVersion: EXPECTED_CONTENT_VERSION_PREFIX,
            readyState,
            paused,
            ended,
            muted,
            pipEnabled,
            alreadyInPip: String(diag?.alreadyInPip).toLowerCase() === 'true' || diag?.alreadyInPip === true,
            canRequest,
            disablePip,
            size
        });

        logSilentDiagnostic('pip-preserve-silent-multiframe-playerstate-summary', {
            attemptId,
            silent: true,
            ok: true,
            tabId,
            frameId,
            domain,
            title,
            videoIndex,
            found: !!diag?.found,
            result: 'derived-from-player-state',
            reasonCode: '',
            reason: `framesAnswered=${framesAnswered}; framesWithVideo=${framesWithVideo}; requestableFrames=${requestableFrames}; requestableVideos=${requestableVideos}; wrongFrameSuspected=${wrongFrameSuspected}; videoCount=${videoCount}`,
            reasonMessage: `source=player-state; bestIndex=${videoIndex}; bestScore=${bestScore}; bestCanRequest=${canRequest}; bestPipEnabled=${pipEnabled}; bestReadyState=${readyState}; targetIndex=${videoIndex}; targetScore=${bestScore}`,
            method: 'silent-multiframe-playerstate-injection',
            targetStrategy: 'player-state-exact-point',
            contentVersion: diag?.contentVersion || '',
            expectedContentVersion: EXPECTED_CONTENT_VERSION_PREFIX,
            readyState,
            paused,
            ended,
            muted,
            pipEnabled,
            alreadyInPip: String(diag?.alreadyInPip).toLowerCase() === 'true' || diag?.alreadyInPip === true,
            canRequest,
            disablePip,
            size
        });
    } catch (e) {
        try {
            logSilentDiagnostic('pip-preserve-silent-multiframe-playerstate-summary-failed', {
                attemptId: diag?.attemptId || '',
                silent: true,
                ok: false,
                tabId: Number(diag?.tabId || 0),
                frameId: Number(diag?.frameId || 0),
                reasonCode: 'playerstate-summary-failed',
                reason: e?.message || String(e),
                method: 'silent-multiframe-playerstate-injection',
                targetStrategy: 'player-state-exact-point'
            });
        } catch {}
    }
}


function logEmbeddedMultiFrameFromPreflightResult(result, attemptId, targetTabId, frameId) {
    try {
        const mf = result?.embeddedMultiFramePreflight;
        if (!mf) {
            logSilentDiagnostic('pip-preserve-silent-multiframe-embedded-missing', {
                attemptId,
                silent: true,
                ok: false,
                tabId: Number(targetTabId || 0),
                frameId: Number(frameId || 0),
                reasonCode: 'embedded-multiframe-missing',
                reason: 'preflight-result-without-embedded-multiframe',
                method: 'silent-multiframe-embedded-preflight',
                targetStrategy: 'embedded-preflight-result'
            });
            return;
        }

        logSilentDiagnostic('pip-preserve-silent-multiframe-embedded-frame-result', {
            attemptId,
            silent: true,
            ok: !!mf.ok,
            tabId: Number(targetTabId || 0),
            frameId: Number(frameId || mf.frameId || 0),
            domain: mf.domain || '',
            title: mf.title || '',
            videoIndex: typeof mf.targetIndex === 'number' ? mf.targetIndex : -1,
            reasonCode: mf.wrongFrameSuspected ? 'wrong-frame-suspected' : '',
            reason: mf.topVideos || `videoCount=${mf.videoCount || 0}`,
            reasonMessage: `source=${mf.source || ''}; videoCount=${mf.videoCount || 0}; targetFound=${mf.targetFound}; bestIndex=${mf.bestIndex}; bestScore=${mf.bestScore}; targetIndex=${mf.targetIndex}; targetScore=${mf.targetScore}; requestableVideos=${mf.requestableVideos || 0}; wrongFrameSuspected=${mf.wrongFrameSuspected}`,
            method: 'silent-multiframe-embedded-preflight',
            targetStrategy: 'embedded-preflight-result',
            contentVersion: mf.contentVersion || '',
            expectedContentVersion: EXPECTED_CONTENT_VERSION_PREFIX
        });

        logSilentDiagnostic('pip-preserve-silent-multiframe-embedded-summary', {
            attemptId,
            silent: true,
            ok: !!mf.ok,
            tabId: Number(targetTabId || 0),
            frameId: Number(frameId || mf.frameId || 0),
            domain: mf.domain || '',
            title: mf.title || '',
            videoIndex: typeof mf.bestIndex === 'number' ? mf.bestIndex : -1,
            reasonCode: mf.wrongFrameSuspected ? 'wrong-frame-suspected' : '',
            reason: `framesAnswered=${mf.framesAnswered || 1}; framesWithVideo=${mf.framesWithVideo || 0}; requestableFrames=${mf.requestableFrames || 0}; requestableVideos=${mf.requestableVideos || 0}; wrongFrameSuspected=${mf.wrongFrameSuspected}; videoCount=${mf.videoCount || 0}`,
            reasonMessage: `bestIndex=${mf.bestIndex}; bestScore=${mf.bestScore}; bestCanRequest=${mf.bestCanRequest}; bestPipEnabled=${mf.bestPipEnabled}; bestReadyState=${mf.bestReadyState}; targetIndex=${mf.targetIndex}; targetScore=${mf.targetScore}`,
            method: 'silent-multiframe-embedded-preflight',
            targetStrategy: 'embedded-preflight-result',
            contentVersion: mf.contentVersion || '',
            expectedContentVersion: EXPECTED_CONTENT_VERSION_PREFIX
        });
    } catch (e) {
        logSilentDiagnostic('pip-preserve-silent-multiframe-embedded-log-failed', {
            attemptId,
            silent: true,
            ok: false,
            tabId: Number(targetTabId || 0),
            frameId: Number(frameId || 0),
            reasonCode: 'embedded-log-failed',
            reason: e?.message || String(e),
            method: 'silent-multiframe-embedded-preflight',
            targetStrategy: 'embedded-preflight-result'
        });
    }
}


function dispatchRealMultiFrameProbeAfterPlayerStateBlock41(context) {
    try {
        const localAttemptId = context?.localAttemptId || context?.attemptId || '';
        const tabId = Number(context?.tabId || 0);
        const frameId = Number(context?.frameId || 0);
        const targetSession = context?.targetSession || null;
        const targetVideoSessionId = context?.targetVideoSessionId || targetSession?.videoSessionId || '';
        const targetStableVideoKey = context?.targetStableVideoKey || targetSession?.stableVideoKey || '';
        const videoIndex = Number.isInteger(Number(context?.videoIndex)) ? Number(context.videoIndex)
            : (Number.isInteger(Number(targetSession?.videoIndex)) ? Number(targetSession.videoIndex) : 0);
        const mfAttemptId = `mf41-${localAttemptId || Date.now()}`;

        logSilentDiagnostic('pip-preserve-silent-multiframe-real-probe-dispatch-from-playerstate', {
            attemptId: mfAttemptId,
            silent: true,
            ok: true,
            tabId,
            frameId,
            reason: `sourceAttemptId=${localAttemptId}; targetVideoSessionId=${targetVideoSessionId ? 'yes' : 'no'}; targetStableVideoKey=${targetStableVideoKey ? 'yes' : 'no'}; videoIndex=${videoIndex}`,
            reasonMessage: `block=4.1; source=player-state-validated; tabId=${tabId}; frameId=${frameId}`,
            method: 'silent-multiframe-real-probe',
            targetStrategy: 'all-browser-frames-after-player-state',
            videoIndex
        });

        silentMultiFrameProbeForTarget({
            type: 'silentMultiFrameProbe',
            targetVideoSessionId,
            targetStableVideoKey,
            targetTabId: tabId,
            tabId,
            videoIndex,
            attemptId: mfAttemptId
        }, null).then((results) => {
            try {
                const list = Array.isArray(results) ? results : [];
                const framesAnswered = list.length;
                const framesWithVideo = list.filter(r => Number(r?.videoCount || 0) > 0);
                const requestableFrames = list.filter(r => !!r?.hasAnyRequestable);
                const wrongFrameSuspected = list.some(r => !!r?.wrongFrameSuspected);
                const bestFrame = list.slice().sort((a, b) => Number(b?.bestScore || 0) - Number(a?.bestScore || 0))[0] || null;

                logSilentDiagnostic('pip-preserve-silent-multiframe-real-probe-summary', {
                    attemptId: mfAttemptId,
                    silent: true,
                    ok: true,
                    tabId,
                    frameId: Number(bestFrame?.frameId || frameId || 0),
                    domain: bestFrame?.domain || targetSession?.domain || '',
                    title: bestFrame?.title || targetSession?.title || '',
                    videoIndex: Number.isInteger(Number(bestFrame?.bestIndex)) ? Number(bestFrame.bestIndex) : videoIndex,
                    reasonCode: wrongFrameSuspected ? 'wrong-frame-suspected' : '',
                    reason: `framesAnswered=${framesAnswered}; framesWithVideo=${framesWithVideo.length}; requestableFrames=${requestableFrames.length}; wrongFrameSuspected=${wrongFrameSuspected}`,
                    reasonMessage: `bestFrame=${bestFrame ? bestFrame.frameId : -1}; bestIndex=${bestFrame ? bestFrame.bestIndex : -1}; bestScore=${bestFrame ? bestFrame.bestScore : 0}; sourceAttemptId=${localAttemptId}`,
                    method: 'silent-multiframe-real-probe',
                    targetStrategy: 'all-browser-frames-after-player-state',
                    contentVersion: bestFrame?.contentVersion || ''
                });
            } catch (e) {
                logSilentDiagnostic('pip-preserve-silent-multiframe-real-probe-summary-failed', {
                    attemptId: mfAttemptId,
                    silent: true,
                    ok: false,
                    tabId,
                    frameId,
                    reasonCode: 'real-probe-summary-failed',
                    reason: e?.message || String(e),
                    method: 'silent-multiframe-real-probe',
                    targetStrategy: 'all-browser-frames-after-player-state'
                });
            }
        }).catch((e) => {
            logSilentDiagnostic('pip-preserve-silent-multiframe-real-probe-failed', {
                attemptId: mfAttemptId,
                silent: true,
                ok: false,
                tabId,
                frameId,
                reasonCode: 'real-probe-failed',
                reason: e?.message || String(e),
                method: 'silent-multiframe-real-probe',
                targetStrategy: 'all-browser-frames-after-player-state'
            });
        });
    } catch (e) {
        try {
            logSilentDiagnostic('pip-preserve-silent-multiframe-real-probe-dispatch-failed', {
                attemptId: context?.localAttemptId || context?.attemptId || '',
                silent: true,
                ok: false,
                tabId: Number(context?.tabId || 0),
                frameId: Number(context?.frameId || 0),
                reasonCode: 'real-probe-dispatch-failed',
                reason: e?.message || String(e),
                method: 'silent-multiframe-real-probe',
                targetStrategy: 'all-browser-frames-after-player-state'
            });
        } catch {}
    }
}


async function silentReopenPreflightForTarget(targetVideoSessionId, targetStableVideoKey, targetTabId, attemptId = '') {
    try {
        logSilentDiagnostic('pip-preserve-silent-preflight-route-hit-block43', {
            attemptId: message?.attemptId || '',
            silent: true,
            ok: true,
            tabId: Number(message?.targetTabId || message?.tabId || 0),
            reason: `preflight-route-hit; will-dispatch-multiframe-same-path`,
            method: 'silent-reopen-preflight',
            targetStrategy: 'block43-preflight-path'
        });
        runSilentMultiFrameProbeFromPreflightPath(message, ws, message?.attemptId || '').catch(() => {});
    } catch {}

  const localAttemptId = attemptId || `preflight-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;

  sendToApp({
    type: 'silentDiagnostic',
    event: 'pip-preserve-silent-preflight-start',
    attemptId: localAttemptId,
    silent: true,
    targetVideoSessionId,
    targetStableVideoKey,
    targetTabId,
    ts: Date.now()
  });

  await requestAllVideoStates();
  await delay(160);

  const resolved = resolveTargetSession(targetVideoSessionId, targetStableVideoKey, targetTabId, true);
  const tabId = resolved.tabId;
  const targetSession = resolved.targetSession;
  const match = resolved.match;

  sendToApp({
    type: 'silentDiagnostic',
    event: 'pip-preserve-silent-preflight-target-resolved',
    attemptId: localAttemptId,
    silent: true,
    ok: !!resolved.ok,
    reasonCode: normalizeOpenPipReasonCode(resolved.reason || match || ''),
    reason: resolved.reason || '',
    match,
    tabId: tabId || 0,
    targetStrategy: match || 'none',
    targetVideoSessionId: targetSession ? targetSession.videoSessionId : (targetVideoSessionId || ''),
    targetStableVideoKey: targetSession ? targetSession.stableVideoKey : (targetStableVideoKey || ''),
    title: targetSession ? targetSession.title : '',
    domain: targetSession ? targetSession.domain : '',
    videoIndex: targetSession ? targetSession.videoIndex : -1,
    currentTime: targetSession ? targetSession.currentTime : 0,
    duration: targetSession ? targetSession.duration : 0,
    ts: Date.now()
  });

  if (!resolved.ok || !tabId || !targetSession) {
    sendToApp({
      type: 'silentDiagnostic',
      event: 'pip-preserve-silent-preflight-result',
      attemptId: localAttemptId,
      silent: true,
      ok: false,
      result: 'ineligible',
      reasonCode: normalizeOpenPipReasonCode(resolved.reason || match || 'target-not-found'),
      reason: resolved.reason || 'target-not-found',
      match,
      targetStrategy: match || 'none',
      tabId: tabId || 0,
      ts: Date.now()
    });
    return;
  }

  const frameId = Number.isInteger(Number(targetSession.frameId)) ? Number(targetSession.frameId) : -1;
  const capability = await checkContentCapabilities(tabId, frameId, localAttemptId, true, 'openPictureInPictureSilentStrong');
  if (!capability.ok) {
    sendToApp({
      type: 'silentDiagnostic',
      event: 'pip-preserve-silent-preflight-result',
      attemptId: localAttemptId,
      silent: true,
      ok: false,
      result: 'ineligible',
      reasonCode: 'content-version-mismatch',
      reason: capability.reason || 'content-capability-check-failed',
      reasonMessage: `expected=${EXPECTED_CONTENT_VERSION_PREFIX}; actual=${capability.contentVersion || ''}`,
      tabId,
      frameId,
      contentVersion: capability.contentVersion || '',
      expectedContentVersion: EXPECTED_CONTENT_VERSION_PREFIX,
      ts: Date.now()
    });
    return;
  }

  try {
    const response = await sendMessageToTabFrame(tabId, frameId, {
      type: 'silentReopenPreflight',
      targetVideoSessionId: targetSession.videoSessionId || targetVideoSessionId || '',
      targetStableVideoKey: targetSession.stableVideoKey || targetStableVideoKey || '',
      videoIndex: targetSession.videoIndex,
      attemptId: localAttemptId
    });

    sendToApp({
      type: 'silentDiagnostic',
      event: 'pip-preserve-silent-player-state',
      attemptId: localAttemptId,
      silent: true,
      ok: !!(response && response.ok),
      result: response && response.ok ? 'eligible' : 'ineligible',
      found: !!(response && response.found),
      reasonCode: response && response.reasonCode ? response.reasonCode : '',
      reason: response && response.reason ? response.reason : '',
      reasonMessage: response && response.reasonMessage ? response.reasonMessage : '',
      method: response && response.method ? response.method : 'silent-reopen-preflight',
      match: response && response.match ? response.match : match,
      targetStrategy: response && response.targetStrategy ? response.targetStrategy : match,
      tabId,
      frameId,
      domain: response && response.domain ? response.domain : (targetSession.domain || ''),
      title: response && response.title ? response.title : (targetSession.title || ''),
      videoIndex: response && Number.isInteger(Number(response.videoIndex)) ? Number(response.videoIndex) : targetSession.videoIndex,
      currentTime: targetSession.currentTime || 0,
      duration: targetSession.duration || 0,
      contentVersion: response && response.contentVersion ? response.contentVersion : '',
      expectedContentVersion: EXPECTED_CONTENT_VERSION_PREFIX,
      hasUserActivation: !!(response && response.hasUserActivation),
      isActiveUserActivation: !!(response && response.isActiveUserActivation),
      documentPictureInPicture: !!(response && response.documentPictureInPicture),
      diagnostics: response && response.diagnostics ? response.diagnostics : null,
      ts: Date.now()
    });

    try {
      dispatchRealMultiFrameProbeAfterPlayerStateBlock41({
        localAttemptId,
        tabId,
        frameId,
        targetSession,
        targetVideoSessionId: targetSession ? targetSession.videoSessionId : (targetVideoSessionId || ''),
        targetStableVideoKey: targetSession ? targetSession.stableVideoKey : (targetStableVideoKey || ''),
        videoIndex: targetSession ? targetSession.videoIndex : 0,
        marker: 'block41-real-multiframe-after-playerstate-call'
      });
    } catch {}

        try {
            logMultiFrameAtPlayerStatePointFromDiagnostic(Object.assign({}, message || {}, result || response || {}, { event: 'player-state-exact-point-injected-block46' }));
        } catch {}


    sendToApp({
      type: 'silentDiagnostic',
      event: 'pip-preserve-silent-preflight-result',
      attemptId: localAttemptId,
      silent: true,
      ok: !!(response && response.ok),
      result: response && response.ok ? 'eligible' : 'ineligible',
      reasonCode: response && response.reasonCode ? response.reasonCode : '',
      reason: response && response.reason ? response.reason : '',
      reasonMessage: response && response.reasonMessage ? response.reasonMessage : '',
      method: response && response.method ? response.method : 'silent-reopen-preflight',
      match: response && response.match ? response.match : match,
      targetStrategy: response && response.targetStrategy ? response.targetStrategy : match,
      tabId,
      frameId,
      domain: response && response.domain ? response.domain : (targetSession.domain || ''),
      title: response && response.title ? response.title : (targetSession.title || ''),
      videoIndex: response && Number.isInteger(Number(response.videoIndex)) ? Number(response.videoIndex) : targetSession.videoIndex,
      contentVersion: response && response.contentVersion ? response.contentVersion : '',
      expectedContentVersion: EXPECTED_CONTENT_VERSION_PREFIX,
      diagnostics: response && response.diagnostics ? response.diagnostics : null,
      ts: Date.now()
    });
  } catch (err) {
    const reason = err && err.message ? err.message : String(err);
    sendToApp({
      type: 'silentDiagnostic',
      event: 'pip-preserve-silent-preflight-result',
      attemptId: localAttemptId,
      silent: true,
      ok: false,
      result: 'ineligible',
      reasonCode: normalizeOpenPipReasonCode(reason),
      reason,
      reasonMessage: reason,
      tabId,
      frameId,
      ts: Date.now()
    });
  }
}


async function openPictureInPictureForTarget(targetVideoSessionId, targetStableVideoKey, targetTabId, activateTab = true, attemptId = '', allowBestVisibleFallback = false) {
  const localAttemptId = attemptId || `open-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
  const silent = !activateTab;

  sendToApp({
    type: 'silentDiagnostic',
    event: silent ? 'silent-preflight-start' : 'open-preflight-start',
    attemptId: localAttemptId,
    silent,
    targetVideoSessionId,
    targetStableVideoKey,
    targetTabId,
    ts: Date.now()
  });

  await requestAllVideoStates();
  await delay(180);

  let resolved = resolveTargetSession(targetVideoSessionId, targetStableVideoKey, targetTabId, true);

  if ((!resolved.ok || !resolved.tabId) && allowBestVisibleFallback) {
    const fallback = resolveBestVisibleSessionForTab(targetVideoSessionId, targetStableVideoKey, targetTabId);
    sendToApp({
      type: 'silentDiagnostic',
      event: silent ? 'silent-reacquire-target-selected' : 'open-reacquire-target-selected',
      attemptId: localAttemptId,
      silent,
      ok: !!fallback.ok,
      reasonCode: normalizeOpenPipReasonCode(fallback.reason || fallback.match || ''),
      reason: fallback.reason || '',
      match: fallback.match,
      candidateCount: fallback.candidateCount || 0,
      bestScore: fallback.bestScore || 0,
      secondScore: fallback.secondScore || 0,
      targetVideoSessionId: fallback.targetSession ? fallback.targetSession.videoSessionId : '',
      targetStableVideoKey: fallback.targetSession ? fallback.targetSession.stableVideoKey : '',
      tabId: fallback.tabId || 0,
      title: fallback.targetSession ? fallback.targetSession.title : '',
      domain: fallback.targetSession ? fallback.targetSession.domain : '',
      videoIndex: fallback.targetSession ? fallback.targetSession.videoIndex : -1,
      currentTime: fallback.targetSession ? fallback.targetSession.currentTime : 0,
      duration: fallback.targetSession ? fallback.targetSession.duration : 0,
      ts: Date.now()
    });

    if (fallback.ok) {
      resolved = fallback;
    }
  }

  let tabId = resolved.tabId;
  let targetSession = resolved.targetSession;
  let match = resolved.match;

  sendToApp({
    type: 'silentDiagnostic',
    event: silent ? 'silent-target-resolved' : 'open-target-resolved',
    attemptId: localAttemptId,
    silent,
    ok: !!resolved.ok,
    reasonCode: normalizeOpenPipReasonCode(resolved.reason || match || ''),
    reason: resolved.reason || '',
    match,
    tabId: tabId || 0,
    targetStrategy: match || 'none',
    targetVideoSessionId: targetSession ? targetSession.videoSessionId : (targetVideoSessionId || ''),
    targetStableVideoKey: targetSession ? targetSession.stableVideoKey : (targetStableVideoKey || ''),
    title: targetSession ? targetSession.title : '',
    domain: targetSession ? targetSession.domain : '',
    videoIndex: targetSession ? targetSession.videoIndex : -1,
    isPlaying: !!(targetSession && targetSession.isPlaying),
    isActiveTab: !!(targetSession && targetSession.isActiveTab),
    currentTime: targetSession ? targetSession.currentTime : 0,
    duration: targetSession ? targetSession.duration : 0,
    ts: Date.now()
  });

  if (!resolved.ok || !tabId) {
    sendToApp({
      type: 'openPipResult',
      ok: false,
      reason: resolved.reason || 'no-target',
      reasonCode: normalizeOpenPipReasonCode(resolved.reason || match || 'target-not-found'),
      match,
      attemptId: localAttemptId,
      targetVideoSessionId,
      targetStableVideoKey,
      silent
    });
    return;
  }

  try {
    if (activateTab) {
      try { await updateTab(tabId, { active: true }); } catch (_) {}
    }

    const messageType = allowBestVisibleFallback
      ? 'openPictureInPictureReacquireBestVisible'
      : (activateTab ? 'openPictureInPicture' : 'openPictureInPictureSilentStrong');

    const targetFrameId = targetSession && Number.isInteger(Number(targetSession.frameId))
      ? Number(targetSession.frameId)
      : -1;

    sendToApp({
      type: 'silentDiagnostic',
      event: silent ? 'silent-frame-route-selected' : 'open-frame-route-selected',
      attemptId: localAttemptId,
      silent,
      ok: true,
      reasonCode: '',
      reason: '',
      match,
      targetStrategy: `${match || 'unknown'}${targetFrameId >= 0 ? '+frameId' : '+no-frameId'}`,
      tabId,
      frameId: targetFrameId,
      targetVideoSessionId: targetSession ? targetSession.videoSessionId : (targetVideoSessionId || ''),
      targetStableVideoKey: targetSession ? targetSession.stableVideoKey : (targetStableVideoKey || ''),
      title: targetSession ? targetSession.title : '',
      domain: targetSession ? targetSession.domain : '',
      videoIndex: targetSession ? targetSession.videoIndex : -1,
      currentTime: targetSession ? targetSession.currentTime : 0,
      duration: targetSession ? targetSession.duration : 0,
      ts: Date.now()
    });

    const capability = await checkContentCapabilities(tabId, targetFrameId, localAttemptId, silent, messageType);
    if (!capability.ok) {
      sendToApp({
        type: 'openPipResult',
        ok: false,
        method: 'capability-check',
        reason: capability.reason || 'content-capability-check-failed',
        reasonCode: 'content-version-mismatch',
        reasonMessage: `expected=${EXPECTED_CONTENT_VERSION_PREFIX}; actual=${capability.contentVersion || ''}; hasReacquireBestVisible=${!!capability.hasReacquireBestVisible}`,
        match: 'content-capability-check-failed',
        targetStrategy: 'content-capability-check-failed',
        targetVideoSessionId: targetSession ? targetSession.videoSessionId : (targetVideoSessionId || ''),
        targetStableVideoKey: targetSession ? targetSession.stableVideoKey : (targetStableVideoKey || ''),
        tabId,
        frameId: targetFrameId,
        title: targetSession ? targetSession.title : '',
        silent,
        attemptId: localAttemptId,
        enterPipSeen: false,
        requestAttempted: false,
        contentVersion: capability.contentVersion || ''
      });
      return;
    }

    const response = await sendMessageToTabFrame(tabId, targetFrameId, {
      type: messageType,
      targetVideoSessionId: targetSession ? targetSession.videoSessionId : (targetVideoSessionId || ''),
      targetStableVideoKey: targetSession ? targetSession.stableVideoKey : '',
      videoIndex: targetSession ? targetSession.videoIndex : -1,
      attemptId: localAttemptId
    });

    const ok = !!(response && response.ok);
    const reasonCode = response && response.reasonCode
      ? response.reasonCode
      : normalizeOpenPipReasonCode(response && response.reason ? response.reason : '');
    const enterPipSeen = !!(response && response.enterPipSeen);
    const requestAttempted = !!(response && response.requestAttempted);

    if (silent && response && response.preflight) {
      sendToApp({
        type: 'silentDiagnostic',
        event: 'silent-content-preflight',
        attemptId: localAttemptId,
        silent: true,
        ...response.preflight
      });
    }

    if (silent && response && Array.isArray(response.attempts)) {
      for (const item of response.attempts) {
        sendToApp({
          type: 'silentDiagnostic',
          event: item.type || `silent-attempt-${item.attempt || '?'}`,
          attemptId: localAttemptId,
          silent: true,
          attempt: item.attempt || 0,
          strategy: item.strategy || item.targetStrategy || '',
          result: item.result || (item.ok ? 'success' : 'fail'),
          ok: !!item.ok,
          found: !!item.found,
          reasonCode: item.reasonCode || '',
          reason: item.reason || '',
          reasonMessage: item.reasonMessage || '',
          requestAttempted: !!item.requestAttempted,
          enterPipSeen: !!item.enterPipSeen,
          match: item.match || '',
          diagnostics: item.diagnostics || item.before || null,
          enter: item.enter || null,
          ts: Date.now()
        });
      }
    }

    sendToApp({
      type: 'openPipResult',
      ok,
      method: response && response.method ? response.method : 'unknown',
      reason: response && response.reason ? response.reason : '',
      reasonCode,
      reasonMessage: response && response.reasonMessage ? response.reasonMessage : '',
      match: response && response.match ? response.match : match,
      targetStrategy: response && response.targetStrategy ? response.targetStrategy : match,
      candidates: response && response.candidates ? response.candidates : null,
      targetVideoSessionId: targetSession ? targetSession.videoSessionId : (targetVideoSessionId || ''),
      targetStableVideoKey: targetSession ? targetSession.stableVideoKey : (targetStableVideoKey || ''),
      tabId,
      frameId: targetFrameId,
      title: targetSession ? targetSession.title : '',
      contentVersion: response && response.contentVersion ? response.contentVersion : '',
      silent,
      attemptId: localAttemptId,
      enterPipSeen,
      requestAttempted,
      attempts: response && response.attempts ? response.attempts : undefined
    });

    sendToApp({
      type: 'silentDiagnostic',
      event: silent ? 'silent-final-result-from-extension' : 'open-final-result-from-extension',
      attemptId: localAttemptId,
      silent,
      result: ok ? 'confirmed-by-extension' : 'failed-by-extension',
      ok,
      reasonCode,
      reason: response && response.reason ? response.reason : '',
      reasonMessage: response && response.reasonMessage ? response.reasonMessage : '',
      method: response && response.method ? response.method : 'unknown',
      enterPipSeen,
      requestAttempted,
      tabId,
      frameId: targetFrameId,
      contentVersion: response && response.contentVersion ? response.contentVersion : '',
      match: response && response.match ? response.match : match,
      ts: Date.now()
    });

    setTimeout(async () => {
      await requestTabVideoState(tabId);
      sendSessionsSnapshot();
    }, 300);
    setTimeout(async () => {
      await requestTabVideoState(tabId);
      sendSessionsSnapshot();
    }, 1200);

    log('abrir PiP:', 'attemptId', localAttemptId, 'tab', tabId, 'silent', silent, 'match', match, 'ok', ok, 'reasonCode', reasonCode, 'enterPipSeen', enterPipSeen, 'requestAttempted', requestAttempted, 'reason', response && response.reason);
  } catch (err) {
    const reason = err && err.message ? err.message : String(err);
    sendToApp({
      type: 'openPipResult',
      ok: false,
      reason,
      reasonCode: normalizeOpenPipReasonCode(reason),
      targetVideoSessionId,
      targetStableVideoKey,
      tabId,
      silent,
      attemptId: localAttemptId,
      enterPipSeen: false,
      requestAttempted: false
    });
  }
}

async function sendVideoCommand(command, operationId, targetVideoSessionId, targetStableVideoKey, targetTabId, allowNoVideoTarget = false, allowSameTabNavigation = false) {
  const explicitTargetTabId = Number(targetTabId || 0);

  // Previous representa Alt+Seta Esquerda na aba já vinculada ao slot.
  // A aba é a autoridade; a sessão de vídeo pode ter sido recriada ou coexistir
  // com um preload e não deve bloquear o histórico do navegador.
  if (command === 'previous' && explicitTargetTabId > 0) {
    try {
      const backResult = await goBackTab(explicitTargetTabId);
      const ok = !!backResult.ok;
      const reason = backResult.reason || '';
      const method = ok ? 'tabs-goBack-linked-tab-authoritative' : 'tabs-goBack-linked-tab-failed';
      sendToApp({
        type: 'commandResult',
        operationId,
        command,
        ok,
        method,
        match: 'linked-tab-authoritative',
        targetVideoSessionId,
        targetStableVideoKey,
        tabId: explicitTargetTabId,
        reason
      });
      sendToApp({
        type: 'previousGoBackResult',
        operationId,
        ok,
        method,
        tabId: explicitTargetTabId,
        reason,
        match: 'linked-tab-authoritative',
        targetVideoSessionId,
        targetStableVideoKey
      });
      setTimeout(async () => {
        await requestTabVideoState(explicitTargetTabId);
        sendSessionsSnapshot();
      }, 500);
      log('previous autoritativo executado:', 'operationId', operationId, 'tab', explicitTargetTabId, 'ok', ok, 'method', method, 'reason', reason);
      return;
    } catch (err) {
      sendToApp({
        type: 'commandResult',
        operationId,
        command,
        ok: false,
        method: 'tabs-goBack-linked-tab-exception',
        reason: err && err.message ? err.message : String(err),
        match: 'linked-tab-authoritative',
        targetVideoSessionId,
        targetStableVideoKey,
        tabId: explicitTargetTabId
      });
      return;
    }
  }

  let resolved = resolveTargetSession(targetVideoSessionId, targetStableVideoKey, targetTabId, false);
  let tabId = resolved.tabId;
  let targetSession = resolved.targetSession;
  let match = resolved.match;

  // Se o vínculo antigo não resolveu, mas ainda existe tabId salvo, dá uma chance
  // controlada para a MESMA aba antes de declarar falha. Isto cobre sites que
  // recriam o <video> e fazem o videoSessionId/stableVideoKey morrer.
  if ((!resolved.ok || !tabId) && Number(targetTabId || 0) > 0) {
    const fallbackTabId = Number(targetTabId || 0);
    await requestTabVideoState(fallbackTabId);
    await delay(180);
    const tabSessions = getFreshSessionsForTab(fallbackTabId);
    if (tabSessions.length === 1) {
      targetSession = tabSessions[0];
      tabId = fallbackTabId;
      match = 'preflight-same-tab-single-player';
      resolved = { ok: true, tabId, targetSession, match };
    } else if (tabSessions.length > 1) {
      resolved = { ok: false, tabId: null, targetSession: null, match: 'preflight-same-tab-ambiguous', reason: 'target-tab-has-multiple-players' };
    }
  }

  // Em término confirmado, o elemento <video> pode ter sido removido antes do comando.
  // Nesse caso permite uma tentativa restrita à mesma aba vinculada, sem escolher outra aba.
  if ((!resolved.ok || !tabId)
      && allowNoVideoTarget
      && command === 'next'
      && Number(targetTabId || 0) > 0) {
    tabId = Number(targetTabId || 0);
    targetSession = null;
    match = 'terminal-same-tab-no-video-target';
    resolved = { ok: true, tabId, targetSession: null, match };
  }

  // Next manual: o slot selecionado já fornece a aba exata. Se a página
  // recriou o <video> entre o snapshot e o clique, não bloqueie o comando por
  // falta transitória de sessão. O content script pode executar o perfil de
  // navegação da própria página, mas somente nesta aba explicitamente ligada.
  if ((!resolved.ok || !tabId)
      && allowSameTabNavigation
      && command === 'next'
      && Number(targetTabId || 0) > 0) {
    tabId = Number(targetTabId || 0);
    targetSession = null;
    match = 'manual-same-tab-navigation';
    resolved = { ok: true, tabId, targetSession: null, match };
  }

  // Voltar confirmado pelo usuário: Alt+Seta Esquerda.
  // Para "previous", NÃO dependemos do content.js nem de localizar <video>.
  // O background executa diretamente tabs.goBack(tabId) na aba vinculada.
  if (command === 'previous' && !targetSession) {
    const directTabId = tabId || Number(targetTabId || 0);
    if (!directTabId) {
      sendToApp({
        type: 'commandResult',
        operationId,
        command,
        ok: false,
        method: 'tabs-goBack-direct-no-tab',
        reason: 'no-tab-for-previous',
        match,
        targetVideoSessionId,
        targetStableVideoKey
      });
      log('previous direto bloqueado: sem tabId', 'session', targetVideoSessionId, 'stable', targetStableVideoKey, 'match', match);
      return;
    }

    try {
      const backResult = await goBackTab(directTabId);
      const ok = !!backResult.ok;
      const reason = backResult.reason || '';
      const directMethod = ok ? 'tabs-goBack-alt-left-direct-9312' : 'tabs-goBack-direct-failed';
      sendToApp({
        type: 'commandResult',
        operationId,
        command,
        ok,
        method: directMethod,
        match: match || 'previous-direct-tab',
        targetVideoSessionId: targetSession ? targetSession.videoSessionId : (targetVideoSessionId || ''),
        targetStableVideoKey: targetSession ? targetSession.stableVideoKey : (targetStableVideoKey || ''),
        tabId: directTabId,
        reason
      });
      sendToApp({
        type: 'previousGoBackResult',
        operationId,
        ok,
        method: directMethod,
        tabId: directTabId,
        reason,
        match: match || 'previous-direct-tab',
        targetVideoSessionId: targetSession ? targetSession.videoSessionId : (targetVideoSessionId || ''),
        targetStableVideoKey: targetSession ? targetSession.stableVideoKey : (targetStableVideoKey || '')
      });
      setTimeout(async () => {
        await requestTabVideoState(directTabId);
        sendSessionsSnapshot();
      }, 500);
      log('previous direto executado:', 'tab', directTabId, 'ok', ok, 'method', ok ? 'tabs-goBack-alt-left-direct-9312' : 'tabs-goBack-direct-failed', 'reason', reason, 'match', match);
      return;
    } catch (err) {
      sendToApp({
        type: 'commandResult',
        operationId,
        command,
        ok: false,
        method: 'tabs-goBack-direct-exception',
        reason: err && err.message ? err.message : String(err),
        match,
        targetVideoSessionId,
        targetStableVideoKey,
        tabId: directTabId
      });
      return;
    }
  }

  if (!resolved.ok || !tabId) {
    sendToApp({
      type: 'commandResult',
      operationId,
      command,
      ok: false,
      method: 'blocked-no-linked-target',
      reason: resolved.reason || 'no-linked-target',
      match,
      targetVideoSessionId,
      targetStableVideoKey
    });
    log('comando bloqueado sem alvo vinculado:', command, 'session', targetVideoSessionId, 'stable', targetStableVideoKey, 'reason', resolved.reason, 'match', match);
    return;
  }

  try {
    const useLooseSameTabTarget = match === 'preflight-same-tab-single-player'
      || match === 'terminal-same-tab-no-video-target'
      || match === 'manual-same-tab-navigation';
    const permitMissingVideoForExactTab = !!allowNoVideoTarget || match === 'manual-same-tab-navigation';
    const targetFrameId = targetSession && Number.isInteger(Number(targetSession.frameId))
      ? Number(targetSession.frameId)
      : -1;
    let response = await sendMessageToTabFrame(tabId, targetFrameId, {
      type: 'videoCommand',
      command,
      targetVideoSessionId: useLooseSameTabTarget ? '' : (targetSession ? targetSession.videoSessionId : (targetVideoSessionId || '')),
      targetStableVideoKey: useLooseSameTabTarget ? '' : (targetSession ? targetSession.stableVideoKey : (targetStableVideoKey || '')),
      videoIndex: targetSession ? targetSession.videoIndex : -1,
      allowNoVideoTarget: permitMissingVideoForExactTab
    });

    let ok = !!(response && response.ok);
    let method = response && response.method ? response.method : 'unknown';
    let reason = response && response.reason ? response.reason : '';
    let responseMatch = response && response.match ? response.match : match;

    // Se o background tinha uma sessão que parecia fresca, mas o content.js diz
    // target-player-not-found, o <video> provavelmente foi recriado dentro da mesma aba.
    // Atualiza o snapshot daquela aba e tenta novamente apenas quando existir UM player
    // fresco nessa mesma aba. Isso evita comandar outro PiP quando houver ambiguidade.
    if (!ok && reason === 'target-player-not-found' && tabId) {
      await requestTabVideoState(tabId);
      await delay(180);
      const tabSessions = getFreshSessionsForTab(tabId);
      if (tabSessions.length === 1) {
        const retrySession = tabSessions[0];
        const retryFrameId = Number.isInteger(Number(retrySession.frameId))
          ? Number(retrySession.frameId)
          : -1;
        const retryResponse = await sendMessageToTabFrame(tabId, retryFrameId, {
          type: 'videoCommand',
          command,
          // No retry seguro por aba única, NÃO reenviamos session/stable antigos
          // nem os novos como alvo explícito. O content.js então usa o videoIndex
          // do único player fresco da aba, evitando target-player-not-found quando
          // o site recriou o elemento <video>.
          targetVideoSessionId: '',
          targetStableVideoKey: '',
          videoIndex: retrySession.videoIndex,
          allowNoVideoTarget: !!allowSameTabNavigation
        });

        if (retryResponse) {
          response = retryResponse;
          ok = !!retryResponse.ok;
          method = retryResponse.method ? `retry-same-tab-single-player/${retryResponse.method}` : 'retry-same-tab-single-player';
          reason = retryResponse.reason || '';
          responseMatch = retryResponse.match ? `retry-same-tab-single-player/${retryResponse.match}` : 'retry-same-tab-single-player';
          targetSession = retrySession;
          match = 'retry-same-tab-single-player';
        }
      } else if (tabSessions.length > 1) {
        method = method === 'unknown' ? 'retry-blocked-same-tab-ambiguous' : `${method}/retry-blocked-same-tab-ambiguous`;
        reason = 'target-tab-has-multiple-players';
        responseMatch = 'retry-same-tab-ambiguous';
      } else {
        method = method === 'unknown' ? 'retry-blocked-no-fresh-player' : `${method}/retry-blocked-no-fresh-player`;
        reason = 'target-player-not-found-after-refresh';
        responseMatch = 'retry-no-fresh-player';
      }
    }

    // Voltar vídeo: se o content.js não achou botão DOM de anterior,
    // usa a API do navegador para executar o equivalente real de Alt+Seta Esquerda.
    // Evento sintético de teclado dentro da página não dispara o atalho do browser.
    if (!ok && command === 'previous' && reason === 'needs-browser-go-back') {
      const backResult = await goBackTab(tabId);
      ok = !!backResult.ok;
      method = backResult.ok ? 'tabs-goBack-alt-left-9312' : 'tabs-goBack-failed';
      reason = backResult.reason || '';
    }

    sendToApp({
      type: 'commandResult',
      operationId,
      command,
      ok,
      method,
      match: responseMatch,
      targetVideoSessionId: targetSession ? targetSession.videoSessionId : (targetVideoSessionId || ''),
      targetStableVideoKey: targetSession ? targetSession.stableVideoKey : (targetStableVideoKey || ''),
      tabId,
      frameId: targetSession && Number.isInteger(Number(targetSession.frameId)) ? Number(targetSession.frameId) : -1,
      reason
    });
    setTimeout(async () => {
      await requestTabVideoState(tabId);
      sendSessionsSnapshot();
    }, 500);
    log('comando enviado:', command, 'tab', tabId, 'frame', targetSession && Number.isInteger(Number(targetSession.frameId)) ? Number(targetSession.frameId) : -1, 'match', responseMatch, 'session', targetVideoSessionId, 'stable', targetStableVideoKey, 'ok', ok, 'method', method, 'reason', reason);
  } catch (err) {
    sendToApp({ type: 'commandResult', operationId, command, ok: false, reason: err && err.message ? err.message : String(err), targetVideoSessionId, targetStableVideoKey, tabId });
  }
}

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function withTimeout(promise, timeoutMs) {
  return Promise.race([
    promise,
    new Promise((_, reject) => setTimeout(() => reject(new Error(`timeout-${timeoutMs}ms`)), timeoutMs))
  ]);
}

function isHttpUrl(url) {
  return /^https?:\/\//i.test(String(url || ''));
}

function queryTabs(queryInfo) {
  return new Promise((resolve, reject) => {
    try {
      const result = api().tabs.query(queryInfo);
      if (result && typeof result.then === 'function') result.then(resolve, reject);
      else if (api().runtime.lastError) reject(api().runtime.lastError);
      else resolve(result);
    } catch (err) { reject(err); }
  });
}

function getAllFrames(tabId) {
  return new Promise((resolve, reject) => {
    try {
      if (!api().webNavigation || typeof api().webNavigation.getAllFrames !== 'function') {
        resolve([{ frameId: 0 }]);
        return;
      }
      const result = api().webNavigation.getAllFrames({ tabId });
      if (result && typeof result.then === 'function') result.then(resolve, reject);
      else if (api().runtime.lastError) reject(api().runtime.lastError);
      else resolve(result || [{ frameId: 0 }]);
    } catch (err) { reject(err); }
  });
}

function getTab(tabId) {
  return new Promise((resolve, reject) => {
    try {
      const result = api().tabs.get(tabId);
      if (result && typeof result.then === 'function') result.then(resolve, reject);
      else if (api().runtime.lastError) reject(api().runtime.lastError);
      else resolve(result);
    } catch (err) { reject(err); }
  });
}

function updateTab(tabId, updateProperties) {
  return new Promise((resolve, reject) => {
    try {
      const result = api().tabs.update(tabId, updateProperties);
      if (result && typeof result.then === 'function') result.then(resolve, reject);
      else if (api().runtime.lastError) reject(api().runtime.lastError);
      else resolve(result);
    } catch (err) { reject(err); }
  });
}

function updateWindow(windowId, updateProperties) {
  return new Promise((resolve, reject) => {
    try {
      if (!api().windows || typeof api().windows.update !== 'function') { resolve(null); return; }
      const result = api().windows.update(windowId, updateProperties);
      if (result && typeof result.then === 'function') result.then(resolve, reject);
      else if (api().runtime.lastError) reject(api().runtime.lastError);
      else resolve(result);
    } catch (err) { reject(err); }
  });
}


function goBackTab(tabId) {
  return new Promise((resolve) => {
    try {
      if (api().tabs && typeof api().tabs.goBack === 'function') {
        const result = api().tabs.goBack(tabId);
        if (result && typeof result.then === 'function') {
          result.then(() => resolve({ ok: true }), err => resolve({ ok: false, reason: err && err.message ? err.message : String(err) }));
        } else if (api().runtime.lastError) {
          resolve({ ok: false, reason: api().runtime.lastError.message || String(api().runtime.lastError) });
        } else {
          resolve({ ok: true });
        }
        return;
      }
      resolve({ ok: false, reason: 'tabs.goBack indisponível neste navegador' });
    } catch (err) {
      resolve({ ok: false, reason: err && err.message ? err.message : String(err) });
    }
  });
}

function sendMessageToTab(tabId, message) {
  return new Promise((resolve, reject) => {
    try {
      const result = api().tabs.sendMessage(tabId, message);
      if (result && typeof result.then === 'function') result.then(resolve, reject);
      else if (api().runtime.lastError) reject(api().runtime.lastError);
      else resolve(result);
    } catch (err) { reject(err); }
  });
}

function sendMessageToTabFrame(tabId, frameId, message) {
  return new Promise((resolve, reject) => {
    try {
      const options = Number.isInteger(frameId) && frameId >= 0 ? { frameId } : undefined;
      const result = options
        ? api().tabs.sendMessage(tabId, message, options)
        : api().tabs.sendMessage(tabId, message);

      if (result && typeof result.then === 'function') result.then(resolve, reject);
      else if (api().runtime.lastError) reject(api().runtime.lastError);
      else resolve(result);
    } catch (err) { reject(err); }
  });
}

api().runtime.onMessage.addListener((message, sender) => {
  if (!message) return;
  if (message.type === 'pipManagerGetNextPreloadSetting') {
    const tabId = Number(sender?.tab?.id || 0);
    return Promise.resolve({ enabled: nextVideoPreloadByTab.has(tabId) ? nextVideoPreloadByTab.get(tabId) : nextVideoPreloadEnabled });
  }
  const tab = sender && sender.tab ? sender.tab : null;
  if (!tab || !tab.id) return;

  if (message.type === 'pipManagerNextPreloadDiagnostic') {
    sendToApp({
      type: 'pipManagerNextPreloadDiagnostic', event: message.event || '', assetId: message.assetId || '',
      readyState: Number(message.readyState || 0), enabled: !!message.enabled,
      tabId: tab.id, ts: Number(message.ts || Date.now()),
      switchLatencyMs: Number.isFinite(message.switchLatencyMs) ? Number(message.switchLatencyMs) : undefined,
      wasWarm: message.wasWarm === undefined ? undefined : !!message.wasWarm
    });
    return;
  }

  // Um slot de preload = permissão para esta aba manter uma requisição de rede de
  // pré-carregamento do próximo vídeo em andamento. Evita N abas baixando ao mesmo
  // tempo e disputando banda com os vídeos que já estão tocando.
  if (message.type === 'pipManagerRequestPreloadSlot') {
    const assetId = String(message.assetId || '');
    if (!assetId) return Promise.resolve({ granted: false });
    const alreadyHeldByThisTab = activeNextVideoPreloadSlots.has(tab.id);
    if (!alreadyHeldByThisTab && activeNextVideoPreloadSlots.size >= MAX_CONCURRENT_NEXT_VIDEO_PRELOADS) {
      return Promise.resolve({ granted: false });
    }
    activeNextVideoPreloadSlots.set(tab.id, assetId);
    return Promise.resolve({ granted: true });
  }

  if (message.type === 'pipManagerReleasePreloadSlot') {
    activeNextVideoPreloadSlots.delete(tab.id);
    return Promise.resolve({ ok: true });
  }

  if (message.type === 'pictureInPictureEvent') {
    const sessionId = message.videoSessionId || `tab-${tab.id}-video-${message.videoIndex || 0}`;
    const stableKey = message.stableVideoKey || sessionId;
    const value = normalizeSessionFromContent({ ...message, frameId: sender.frameId || 0 }, tab, message.videoCount || 1);
    if (isLikelyAdvertisementSession(value)) {
      removeSessionFromCaches(sessionId, value);
      sendSessionsSnapshot();
      return;
    }
    videoSessions.set(sessionId, value);
    stableSessions.set(stableKey, value);

    sendToApp({
      type: 'pictureInPictureEvent',
      eventName: message.eventName || '',
      eventUnixMs: Number(message.eventUnixMs || Date.now()),
      videoSessionId: sessionId,
      stableVideoKey: stableKey,
      tabId: tab.id,
      frameId: message.frameId || 0,
      pageInstanceId: message.pageInstanceId || '',
      elementInstanceId: message.elementInstanceId || '',
      title: message.title || tab.title || '',
      url: message.url || tab.url || '',
      domain: message.domain || domainFromUrl(tab.url),
      currentTime: Number(message.currentTime || 0)
    });
    sendSessionsSnapshot();
    return;
  }

  if (message.type === 'pipManagerContentDiagnostic') {
    const diagnosticSession = normalizeSessionFromContent({ ...message, frameId: sender.frameId || 0 }, tab, 0);
    if (isLikelyAdvertisementSession(diagnosticSession)) return;
    sendToApp({
      type: 'pipManagerContentDiagnostic',
      version: message.version || '',
      reason: message.reason || '',
      tabId: tab.id,
      title: message.title || tab.title || '',
      url: message.url || tab.url || '',
      domain: message.domain || domainFromUrl(tab.url),
      ts: Number(message.ts || Date.now())
    });
    return;
  }

  if (message.type === 'pipAutoReopenAttempt' ||
      message.type === 'pipAutoReopenShortcutSentAfterNext' ||
      message.type === 'pipAutoReopenedAfterNext') {
    const sessionId = message.videoSessionId || `tab-${tab.id}-video-${message.videoIndex || 0}`;
    const stableKey = message.stableVideoKey || sessionId;
    const value = normalizeSessionFromContent({ ...message, frameId: sender.frameId || 0 }, tab, message.videoCount || 1);
    if (isLikelyAdvertisementSession(value)) {
      removeSessionFromCaches(sessionId, value);
      sendSessionsSnapshot();
      return;
    }
    videoSessions.set(sessionId, value);
    stableSessions.set(stableKey, value);

    sendToApp({
      type: 'pipAutoReopenAttempt',
      phase: message.phase || message.type,
      ok: !!message.ok,
      reason: message.reason || '',
      delayMs: Number(message.delayMs || 0),
      method: message.method || '',
      shortcut: message.shortcut || '',
      videoSessionId: sessionId,
      stableVideoKey: stableKey,
      tabId: tab.id,
      frameId: message.frameId || 0,
      pageInstanceId: message.pageInstanceId || '',
      elementInstanceId: message.elementInstanceId || '',
      title: message.title || tab.title || '',
      url: message.url || tab.url || '',
      domain: message.domain || domainFromUrl(tab.url),
      currentTime: Number(message.currentTime || 0),
      duration: Number(message.duration || 0),
      lastSeenUnixMs: Number(message.lastSeenUnixMs || Date.now())
    });

    sendSessionsSnapshot();
    return;
  }

  if (message.type === 'pipManagerPlaybackTerminal') {
    const value = normalizeSessionFromContent({
      ...message,
      isActiveTab: !!message.isActiveTab,
      frameId: sender.frameId || 0,
      contentVersion: message.contentVersion || ''
    }, tab, 1);

    if (isLikelyAdvertisementSession(value)) {
      removeSessionFromCaches(value.videoSessionId, value);
      sendSessionsSnapshot();
      return;
    }

    value.terminalHoldUntilUnixMs = Date.now() + 6000;
    value.hasVideo = true;
    value.lastSeenUnixMs = Date.now();
    videoSessions.set(value.videoSessionId, value);
    stableSessions.set(value.stableVideoKey || value.videoSessionId, value);

    sendToApp({
      type: 'playbackTerminal',
      reason: message.reason || '',
      videoSessionId: value.videoSessionId || '',
      stableVideoKey: value.stableVideoKey || '',
      tabId: tab.id,
      frameId: sender.frameId || 0,
      videoIndex: Number(value.videoIndex || 0),
      pageInstanceId: value.pageInstanceId || '',
      elementInstanceId: value.elementInstanceId || '',
      title: value.title || tab.title || '',
      url: value.url || tab.url || '',
      domain: value.domain || domainFromUrl(tab.url),
      currentTime: Number(value.currentTime || 0),
      duration: Number(value.duration || 0),
      readyState: Number(message.readyState || 0),
      paused: !!message.paused,
      ended: !!message.ended,
      hasSource: !!message.hasSource,
      eventUnixMs: Number(message.eventUnixMs || Date.now())
    });
    return;
  }

  if (message.type !== 'videoSessionsState') return;

  let changed = false;
  const seen = new Set();

  for (const session of message.sessions || []) {
    const sessionId = session.videoSessionId || `tab-${tab.id}-video-${session.videoIndex || 0}`;
    seen.add(sessionId);

    const value = normalizeSessionFromContent({ ...session, isActiveTab: !!message.isActiveTab, frameId: sender.frameId || 0, contentVersion: message.contentVersion || '', hasReacquireBestVisible: !!message.hasReacquireBestVisible }, tab, message.videoCount || 0);
    if (isLikelyAdvertisementSession(value)) {
      removeSessionFromCaches(sessionId, value);
      changed = true;
      continue;
    }
    videoSessions.set(sessionId, value);
    stableSessions.set(value.stableVideoKey || sessionId, value);
    changed = true;
  }

  // Com all_frames, cada frame envia um snapshot parcial. Não podemos apagar
  // todos os vídeos da aba quando apenas um iframe atualiza, senão a lista fica
  // instável e vínculos válidos desaparecem. Só removemos sessões do mesmo
  // pageInstanceId do snapshot atual; o restante expira naturalmente por TTL.
  const snapshotPageInstanceId = message.pageInstanceId
    || (message.sessions || []).map(s => s && s.pageInstanceId).find(Boolean)
    || '';
  if (snapshotPageInstanceId) {
    for (const [id, value] of Array.from(videoSessions.entries())) {
      if (value.tabId === tab.id && value.pageInstanceId === snapshotPageInstanceId && !seen.has(id)) {
        if (Number(value.terminalHoldUntilUnixMs || 0) > Date.now()) continue;
        videoSessions.delete(id);
        if (value.stableVideoKey && stableSessions.get(value.stableVideoKey)?.videoSessionId === id) {
          stableSessions.delete(value.stableVideoKey);
        }
        changed = true;
      }
    }
  }

  if (changed) sendSessionsSnapshot();
});

function normalizeSessionFromContent(session, tab, videoCount) {
  const sessionId = session.videoSessionId || `tab-${tab.id}-video-${session.videoIndex || 0}`;
  const stableKey = session.stableVideoKey || sessionId;
  return {
    ...session,
    videoSessionId: sessionId,
    stableVideoKey: stableKey,
    tabId: tab.id,
    windowId: Number(tab.windowId || 0),
    frameId: session.frameId || 0,
    title: session.title || tab.title || '',
    url: session.url || tab.url || '',
    domain: session.domain || domainFromUrl(tab.url),
    videoCount: Number(videoCount || 0),
    isActiveTab: !!session.isActiveTab,
    lastSeenUnixMs: Number(session.lastSeenUnixMs || Date.now())
  };
}

function domainFromUrl(url) {
  try { return new URL(url).hostname.replace(/^www\./i, ''); } catch (_) { return ''; }
}

try {
  api().tabs.onRemoved.addListener((tabId) => {
    activeNextVideoPreloadSlots.delete(tabId);
    nextVideoPreloadByTab.delete(tabId);
    let changed = false;
    for (const [id, session] of Array.from(videoSessions.entries())) {
      if (session.tabId === tabId) {
        videoSessions.delete(id);
        if (session.stableVideoKey && stableSessions.get(session.stableVideoKey)?.videoSessionId === id) {
          stableSessions.delete(session.stableVideoKey);
        }
        changed = true;
      }
    }
    if (changed) sendSessionsSnapshot();
  });
} catch (_) {}

connect();
