# Validação local — P0 Optimization RC1

## Executado neste ambiente

- `site-profiles.test.js`: aprovado;
- `tab-discovery.test.js`: aprovado;
- sintaxe de `background.js`: aprovada;
- sintaxe de `content.js`: aprovada;
- `navigation-transaction.test.js`: aprovado;
- verificação de delimitadores dos arquivos C# alterados: aprovada;
- verificação de whitespace/diff: aprovada com `cr-at-eol` para os arquivos CRLF.

## Limitação do ambiente

Este ambiente Linux não possui o SDK .NET e não tem acesso externo para
instalá-lo. Portanto, o build WPF `net8.0-windows`, os testes C# e os gates
PowerShell precisam ser executados no Windows.

## Validação obrigatória no Windows

1. Execute `BUILD_WINDOWS.bat`.
2. Execute `RUN_CORE_TESTS.bat --ci`.
3. Abra quatro PiPs, trave o grupo e arraste rapidamente por 30 segundos.
4. Repita com dez PiPs no perfil Jogo.
5. Confirme que o grupo acompanha o cursor sem atraso acumulado após soltar.
6. Redimensione manualmente um PiP e use Igualar.
7. Altere posição, layout, AutoReturn e posição da toolbar; feche imediatamente
   e confirme que tudo foi restaurado ao abrir novamente.
8. Produza rajadas de snapshots abrindo várias abas com vídeos e confirme que
   todos os clientes aparecem na lista.
9. Teste Próximo/Anterior, abertura silenciosa e AutoReturn para confirmar que
   `SilentPreflight` e resultados silenciosos continuam sendo processados.
10. Verifique no Gerenciador de Tarefas o uso de CPU em repouso e durante o
    arraste, comparando com a RC3 original.

## Critérios de aprovação

- nenhuma falha de compilação;
- nenhuma regressão nos gates existentes;
- nenhuma perda de vínculo ou sessão em snapshots simultâneos;
- persistência correta mesmo fechando logo após uma alteração;
- ausência de movimento residual depois de soltar o mouse;
- redução perceptível de atraso no arraste do grupo.
