# Consolidação — Fase 2: inventário e gate de testes

Esta fase transforma a situação dos testes em um contrato verificável. Ela não altera código de execução, interface, extensão, transporte, layout ou regras por site.

## Resultado do inventário

- Projetos de teste executáveis no gate: `2`.
- Scripts `CHECK_*.ps1` existentes antes desta fase: `54`.
- Scripts executados sempre antes desta fase: `53`.
- Script condicionado a uma log real: `CHECK_WINDOW_EVENT_REACTOR_ASSISTED_CAPTURE_RUNTIME_LOG.ps1`.
- Scripts órfãos ou desativados sem justificativa: `0`.

O verificador desta fase também faz parte do gate. Portanto, depois da Fase 2 existem `55` scripts, sendo `54` obrigatórios e `1` condicionado a uma log real.

## Tipos de validação existentes

1. `PiPManager.Core.Tests`: testes comportamentais determinísticos do núcleo, máquina de estados, agendamento e Shadow Mode.
2. `PiPManager.WindowEventMonitor.Tests`: teste determinístico do monitor de janelas com fonte falsa.
3. `CHECK_*.ps1`: verificações de regressão estrutural e de integração entre arquivos.
4. Check de runtime: valida uma execução diagnóstica dedicada de corrida pre-arm quando `PIPMANAGER_RUNTIME_LOG` aponta para a log produzida com `PIPMANAGER_DIAGNOSTIC_PREARM_DELAY_MS` habilitado.

## Regra do gate

- Todo `CHECK_*.ps1` precisa ser referenciado por `RUN_CORE_TESTS.bat`.
- Todo projeto de teste declarado precisa ser executado pelo gate.
- Checks condicionais precisam estar explicitamente declarados no manifesto.
- Um arquivo ausente, duplicado ou órfão reprova a suíte.
- Checks estruturais não devem ser confundidos com testes comportamentais.

## Limitações conhecidas

- A maior parte dos scripts PowerShell ainda inspeciona texto-fonte; isso não substitui testes de comportamento.
- O check de runtime depende de interação real com navegador e PiP, executada por `RUN_PREARM_RACE_PROOF.bat`, e permanece condicional. Uma log comum não satisfaz esse cenário por desenho.
- O problema observado no AutoRetorno do perfil de controles do player (`requestPictureInPicture` indisponível / `hwnd-not-found`) é dívida funcional conhecida e não foi alterado nesta fase.

## Critério de conclusão

- Manifesto de testes versionado.
- Gate capaz de detectar scripts órfãos, referências inexistentes e projetos de teste não executados.
- Build e suíte completa verdes sem mudança comportamental.
