$ErrorActionPreference = "Stop"
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$main = Get-Content -Raw (Join-Path $root "src\PiPManager.Wpf\MainWindow.xaml.cs")
$xaml = Get-Content -Raw (Join-Path $root "src\PiPManager.Wpf\MainWindow.xaml")
$bridge = Get-Content -Raw (Join-Path $root "src\PiPManager.Wpf\Services\ExtensionBridgeService.cs")
$content = Get-Content -Raw (Join-Path $root "src\PiPManager.Extension\content.js")
$background = Get-Content -Raw (Join-Path $root "src\PiPManager.Extension\background.js")
$settings = Get-Content -Raw (Join-Path $root "src\PiPManager.Wpf\Models\AppSettings.cs")

$checks = @(
    @{ Name = "terminal event emitted by content"; Ok = $content.Contains("pipManagerPlaybackTerminal") -and $content.Contains("schedulePlaybackTerminalCheck") },
    @{ Name = "pause and buffering do not trigger directly"; Ok = -not $content.Contains("schedulePlaybackTerminalCheck(video, 'pause')") -and $content.Contains("emptiedConfirmed") },
    @{ Name = "terminal event forwarded by background"; Ok = $background.Contains("type: 'playbackTerminal'") },
    @{ Name = "terminal event exposed by bridge"; Ok = $bridge.Contains("PlaybackTerminalReceived") -and $bridge.Contains('type == "playbackTerminal"') },
    @{ Name = "exact linked-slot matching"; Ok = $main.Contains("FindSlotForPlaybackTerminal") -and $main.Contains("auto-advance-terminal-ambiguous-session") },
    @{ Name = "automatic next serialized"; Ok = $main.Contains("_autoAdvanceTerminalGate") -and $main.Contains("SendVideoCommandAsync(") },
    @{ Name = "all slots supported dynamically"; Ok = $main.Contains("Slots") -and -not $main.Contains("Take(5)") },
    @{ Name = "persistent user toggle"; Ok = $xaml.Contains("AutoAdvanceOnEndButton") -and $settings.Contains("AutoAdvanceOnVideoEndEnabled") },
    @{ Name = "cooldown present"; Ok = $main.Contains("AutoAdvanceTerminalCooldownSeconds") -and $main.Contains("_autoAdvanceTerminalCooldownUntilBySlot") },
    @{ Name = "same-tab terminal fallback"; Ok = $background.Contains("terminal-same-tab-no-video-target") -and $content.Contains("allowNoVideoTarget") },
    @{ Name = "terminal session hold"; Ok = $background.Contains("terminalHoldUntilUnixMs") },
    @{ Name = "lost PiP stale-session fallback"; Ok = $main.Contains("ArmAutoAdvanceLostPipWatch") -and $main.Contains("auto-advance-loss-watch-terminal-confirmed") },
    @{ Name = "lost PiP fallback requires stale signal"; Ok = $main.Contains("AutoAdvanceLostPipStaleSignalMs") -and $main.Contains("LastSeenUnixMs") },
    @{ Name = "lost PiP fallback cancels on recovery"; Ok = $main.Contains("reason=pip-recovered") -and $main.Contains("site-already-advanced") },
    @{ Name = "lost PiP fallback supports all slots"; Ok = $main.Contains("_autoAdvanceLostPipWatchGenerationBySlot") -and $main.Contains("slotNumber") }
)

$failed = 0
foreach ($check in $checks) {
    if ($check.Ok) { Write-Host ($check.Name + ": OK") }
    else { Write-Host ($check.Name + ": FAIL"); $failed++ }
}

if ($failed -gt 0) { throw "Auto next on terminal checks failed." }
Write-Host "Auto next on terminal checks OK."
