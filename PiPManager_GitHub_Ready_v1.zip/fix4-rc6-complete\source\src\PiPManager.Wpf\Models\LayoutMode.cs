﻿namespace PiPManager.Wpf.Models;

public enum LayoutMode
{
    GridTwoColumns = 0,
    Horizontal = 1,
    Vertical = 2,
    Custom = 3,
    Jogo = 4
}

public static class LayoutModeExtensions
{
    public static string ToLabel(this LayoutMode mode) => mode switch
    {
        LayoutMode.GridTwoColumns => "2x2",
        LayoutMode.Horizontal => "Horizontal",
        LayoutMode.Vertical => "Vertical",
        LayoutMode.Jogo => "Jogo",
        LayoutMode.Custom => "Layout manual",
        _ => mode.ToString()
    };
}
