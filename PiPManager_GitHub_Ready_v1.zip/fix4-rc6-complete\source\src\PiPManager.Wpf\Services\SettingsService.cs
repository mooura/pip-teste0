﻿using System.IO;
using System.Text.Json;
using PiPManager.Wpf.Models;

namespace PiPManager.Wpf.Services;

public sealed class SettingsService : IDisposable
{
    private const int SaveDebounceMilliseconds = 400;
    private static readonly JsonSerializerOptions SerializerOptions = new() { WriteIndented = true };
    private static string SettingsFile => AppLogger.SettingsFile;

    private readonly object _saveSync = new();
    private readonly SemaphoreSlim _writeGate = new(1, 1);
    private Timer? _saveTimer;
    private Task _workerTask = Task.CompletedTask;
    private string? _pendingJson;
    private string? _lastPersistedJson;
    private DateTime _pendingDueUtc = DateTime.MinValue;
    private long _pendingVersion;
    private long _lastPersistedVersion;
    private bool _workerRunning;
    private bool _disposed;

    public AppSettings Load()
    {
        try
        {
            if (!File.Exists(SettingsFile)) return new AppSettings();
            var json = File.ReadAllText(SettingsFile);
            lock (_saveSync)
                _lastPersistedJson = json;
            return JsonSerializer.Deserialize<AppSettings>(json) ?? new AppSettings();
        }
        catch (Exception ex)
        {
            AppLogger.Error("Falha ao carregar configurações", ex);
            return new AppSettings();
        }
    }

    /// <summary>
    /// Captura o estado atual, consolida chamadas rápidas e grava o JSON fora da
    /// thread gráfica. O último snapshot sempre substitui os anteriores pendentes.
    /// </summary>
    public void Save(AppSettings settings)
    {
        if (settings is null) return;

        string json;
        try
        {
            // O objeto é compartilhado pela MainWindow. Serializar no chamador cria
            // um snapshot consistente antes que outras ações alterem suas coleções.
            json = JsonSerializer.Serialize(settings, SerializerOptions);
        }
        catch (Exception ex)
        {
            AppLogger.Error("Falha ao serializar configurações", ex);
            return;
        }

        lock (_saveSync)
        {
            if (_disposed) return;

            if (string.Equals(json, _pendingJson, StringComparison.Ordinal)
                || (_pendingJson is null && string.Equals(json, _lastPersistedJson, StringComparison.Ordinal)))
            {
                return;
            }

            _pendingJson = json;
            _pendingVersion++;
            _pendingDueUtc = DateTime.UtcNow.AddMilliseconds(SaveDebounceMilliseconds);
            _saveTimer ??= new Timer(OnSaveTimer, null, Timeout.Infinite, Timeout.Infinite);
            _saveTimer.Change(SaveDebounceMilliseconds, Timeout.Infinite);
        }
    }

    /// <summary>
    /// Garante a persistência do snapshot mais recente. Usado no encerramento.
    /// </summary>
    public void Flush()
    {
        try
        {
            FlushAsync().GetAwaiter().GetResult();
        }
        catch (Exception ex)
        {
            AppLogger.Error("Falha ao descarregar configurações pendentes", ex);
        }
    }

    public void Dispose()
    {
        lock (_saveSync)
        {
            if (_disposed) return;
        }

        Flush();

        lock (_saveSync)
        {
            if (_disposed) return;
            _disposed = true;
            _saveTimer?.Dispose();
            _saveTimer = null;
        }

        _writeGate.Dispose();
    }

    private void OnSaveTimer(object? state)
    {
        lock (_saveSync)
        {
            if (_disposed || _pendingJson is null || _workerRunning)
                return;

            StartWorkerLocked();
        }
    }

    private void StartWorkerLocked()
    {
        _workerRunning = true;
        _workerTask = Task.Run(ProcessPendingSavesAsync);
    }

    private async Task ProcessPendingSavesAsync()
    {
        try
        {
            while (true)
            {
                TimeSpan wait;
                lock (_saveSync)
                {
                    if (_pendingJson is null)
                    {
                        _workerRunning = false;
                        return;
                    }

                    wait = _pendingDueUtc - DateTime.UtcNow;
                }

                if (wait > TimeSpan.Zero)
                {
                    await Task.Delay(wait).ConfigureAwait(false);
                    continue;
                }

                string json;
                long version;
                lock (_saveSync)
                {
                    if (_pendingJson is null)
                        continue;

                    // Uma nova chamada Save pode ter estendido o debounce enquanto
                    // este worker despertava. Reavalia antes de retirar o snapshot.
                    if (_pendingDueUtc > DateTime.UtcNow)
                        continue;

                    json = _pendingJson;
                    version = _pendingVersion;
                    _pendingJson = null;
                }

                await PersistSnapshotAsync(json, version).ConfigureAwait(false);
            }
        }
        catch (Exception ex)
        {
            AppLogger.Error("Falha ao salvar configurações em segundo plano", ex);
            lock (_saveSync)
            {
                _workerRunning = false;

                // Uma gravação mais nova pode ter sido enfileirada enquanto o I/O
                // anterior falhava. Rearma o worker para não deixar esse estado preso.
                if (!_disposed && _pendingJson is not null && _saveTimer is not null)
                {
                    var remaining = _pendingDueUtc - DateTime.UtcNow;
                    var delayMs = remaining > TimeSpan.Zero
                        ? Math.Max(50, (int)Math.Ceiling(remaining.TotalMilliseconds))
                        : 50;
                    _saveTimer.Change(delayMs, Timeout.Infinite);
                }
            }
        }
    }

    private async Task PersistSnapshotAsync(string json, long version)
    {
        await _writeGate.WaitAsync().ConfigureAwait(false);
        try
        {
            lock (_saveSync)
            {
                // Protege contra uma conclusão mais antiga após uma gravação nova.
                if (version < _lastPersistedVersion)
                    return;
            }

            WriteJsonAtomically(json);

            lock (_saveSync)
            {
                if (version >= _lastPersistedVersion)
                {
                    _lastPersistedVersion = version;
                    _lastPersistedJson = json;
                }
            }
        }
        finally
        {
            _writeGate.Release();
        }
    }

    private async Task FlushAsync()
    {
        while (true)
        {
            Task worker;
            lock (_saveSync)
            {
                _saveTimer?.Change(Timeout.Infinite, Timeout.Infinite);

                if (_pendingJson is not null)
                    _pendingDueUtc = DateTime.UtcNow;

                if (!_workerRunning && _pendingJson is not null)
                    StartWorkerLocked();

                worker = _workerTask;
            }

            await worker.ConfigureAwait(false);

            lock (_saveSync)
            {
                if (_pendingJson is null && !_workerRunning)
                    break;
            }
        }

        // Aguarda uma gravação já dentro da seção crítica.
        await _writeGate.WaitAsync().ConfigureAwait(false);
        _writeGate.Release();
    }

    private static void WriteJsonAtomically(string json)
    {
        Directory.CreateDirectory(AppLogger.LogDirectory);
        var tmp = SettingsFile + ".tmp";
        File.WriteAllText(tmp, json);
        File.Copy(tmp, SettingsFile, true);
        File.Delete(tmp);
    }
}
