$ErrorActionPreference = "Stop"
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$main = Get-Content -Raw (Join-Path $root "src\PiPManager.Wpf\MainWindow.xaml.cs")

$checks = [ordered]@{
  "terminal busy handoff has bounded signal wait" = $main.Contains("AutoAdvanceTerminalBusyWaitMaxMs = 4500") -and $main.Contains("WaitForPipOperationAvailabilityAsync")
  "terminal wait observes active slot lock" = $main.Contains("openAttemptSlot={_openPipAttemptSlotNumber}") -and $main.Contains("waitMode=signal")
  "terminal handoff success diagnostic exists" = $main.Contains("auto-advance-terminal-handoff-ready")
  "terminal timeout records wait state" = $main.Contains("waitedMs={terminalBusyWaitElapsedMs:0}")
  "autoreturn cancels after foreground lease" = $main.Contains('IsAutoReturnAttemptCurrent(slot, state, attemptId, "after-foreground-lease")')
  "foreground is restored before cancelled return" = $main.Contains("attemptCurrentAfterForegroundLease") -and $main.Contains('cancelado-após-foreground-lease')
  "autoreturn cancels after post restore wait" = $main.Contains('IsAutoReturnAttemptCurrent(slot, state, attemptId, "after-post-restore-wait")') -and $main.Contains('cancelado-após-post-restore')
  "terminal preemption still increments generation" = $main.Contains("auto-advance-terminal-preempted-old-autoreturn") -and $main.Contains("GetAutoReturnCancellationGeneration(slot.Number) + 1")
}

$failed = @()
foreach ($item in $checks.GetEnumerator()) {
  if ($item.Value) { Write-Host ($item.Key + ": OK") }
  else { Write-Host ($item.Key + ": FAIL"); $failed += $item.Key }
}

if ($failed.Count -gt 0) {
  throw "Terminal preempt handoff checks failed: $($failed -join ', ')"
}

Write-Host "Terminal preempt handoff checks OK."
