$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$main = Get-Content (Join-Path $Root 'src\PiPManager.Wpf\MainWindow.xaml.cs') -Raw
$video = Get-Content (Join-Path $Root 'src\PiPManager.Wpf\Services\VideoCommandService.cs') -Raw
$win32 = Get-Content (Join-Path $Root 'src\PiPManager.Wpf\Services\Win32.cs') -Raw
$run = Get-Content (Join-Path $Root 'RUN_CORE_TESTS.bat') -Raw
$checks = @(
  @{ Name='browser activation is adaptive'; Ok=($video -match 'browserWasMinimized \? 650 : 240') },
  @{ Name='verified foreground reuse'; Ok=($video -match 'foregroundAlreadyVerified' -and $video -match 'canReuseVerifiedForeground') },
  @{ Name='AutoReturn foreground verification is adaptive'; Ok=($main -match 'verifyWindowMs = attempt == 1 \? 260 : 420' -and $main -match 'phase=after-extension-focus; adaptive=True') },
  @{ Name='fallback activation delay reduced'; Ok=($video -match 'Task.Delay\(80\)') },
  @{ Name='manual focus wait reduced'; Ok=($main -match 'Task.Delay\(100\)') },
  @{ Name='AutoReturn retry delay reduced'; Ok=($main -match 'delayMs=150') },
  @{ Name='fast post-focus wait'; Ok=($main -match 'var\s+postRestoreWaitMs\s*=\s*navigationFastLease\s*\?\s*450\s*:\s*600') },
  @{ Name='browser minimize API exists'; Ok=($video -match 'TryMinimizeExpectedBrowserWindow') },
  @{ Name='browser minimized only after confirmation'; Ok=($main -match 'browser-minimized-after-confirmation') },
  @{ Name='Win32 minimize constant exists'; Ok=($win32 -match 'SW_MINIMIZE = 6') },
  @{ Name='checker included in core gate'; Ok=($run -match 'CHECK_FAST_OPEN_BROWSER_MINIMIZE.ps1') }
)
$failed=0
foreach($c in $checks){ if($c.Ok){Write-Host "$($c.Name): OK"} else {Write-Host "$($c.Name): FAIL"; $failed++}}
if($failed -gt 0){throw 'Fast open and browser minimize checks failed.'}
Write-Host 'Fast open and browser minimize checks OK.'
