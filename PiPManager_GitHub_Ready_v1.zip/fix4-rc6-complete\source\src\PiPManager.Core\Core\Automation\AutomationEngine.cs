﻿using System.Collections.Concurrent;
using PiPManager.Core.Slots;

namespace PiPManager.Core.Automation;

/// <summary>
/// Fundação do núcleo de automação.
/// Apply é atomicamente protegido para evitar leitura/cálculo/gravação concorrente.
/// O fluxo ideal ainda é consumidor único da fila, mas este lock protege uso acidental direto.
/// </summary>
public sealed class AutomationEngine
{
    private readonly object _gate = new();
    private readonly SlotStateMachine _stateMachine = new();
    private readonly ConcurrentDictionary<int, SlotSnapshot> _slots = new();

    public SlotSnapshot GetSlot(int slotNumber)
    {
        if (slotNumber <= 0)
            throw new ArgumentOutOfRangeException(nameof(slotNumber), "SlotNumber deve ser maior que zero.");

        return _slots.GetOrAdd(slotNumber, SlotSnapshot.EmptySlot);
    }

    public IReadOnlyCollection<SlotSnapshot> GetSnapshot()
        => _slots.Values.OrderBy(s => s.SlotNumber).ToArray();

    /// <summary>
    /// Importa um snapshot legado ou preparado para o novo motor.
    /// Usado por testes, futuro Shadow Mode e ponte de leitura com o modelo antigo.
    /// </summary>
    public SlotSnapshot ImportSnapshot(SlotSnapshot snapshot)
    {
        if (snapshot.SlotNumber <= 0)
            throw new ArgumentOutOfRangeException(nameof(snapshot), "Snapshot.SlotNumber deve ser maior que zero.");

        var normalized = snapshot with
        {
            UpdatedAt = snapshot.UpdatedAt == default ? DateTimeOffset.UtcNow : snapshot.UpdatedAt
        };

        SlotSnapshotValidator.ValidateForImport(normalized);

        lock (_gate)
        {
            if (_slots.TryGetValue(normalized.SlotNumber, out var current) &&
                normalized.UpdatedAt <= current.UpdatedAt)
            {
                return current;
            }

            _slots[normalized.SlotNumber] = normalized;
            return normalized;
        }
    }

    public SlotSnapshot InitializeSlot(
        int slotNumber,
        SlotState state = SlotState.Empty,
        bool autoReturnEnabled = false,
        bool isHidden = false,
        bool isLocked = false,
        IntPtr? pipHwnd = null,
        int? tabId = null,
        string? videoSessionId = null,
        string? stableVideoKey = null,
        string? attemptId = null)
    {
        return ImportSnapshot(new SlotSnapshot
        {
            SlotNumber = slotNumber,
            State = state,
            AutoReturnEnabled = autoReturnEnabled,
            IsHidden = isHidden,
            IsLocked = isLocked,
            PipHwnd = pipHwnd,
            TabId = tabId,
            VideoSessionId = videoSessionId,
            StableVideoKey = stableVideoKey,
            AttemptId = attemptId,
            UpdatedAt = DateTimeOffset.UtcNow
        });
    }

    public void Clear()
    {
        lock (_gate)
            _slots.Clear();
    }

    public AutomationDecision Apply(AutomationEvent ev)
    {
        if (ev.SlotNumber <= 0)
            throw new ArgumentOutOfRangeException(nameof(ev), "AutomationEvent.SlotNumber deve ser maior que zero.");

        lock (_gate)
        {
            var slot = GetSlot(ev.SlotNumber);
            var (next, transition) = _stateMachine.Apply(slot, ev);
            _slots[next.SlotNumber] = next;

            var actions = BuildActions(next, transition, ev);
            return new AutomationDecision(ev, next, transition, actions);
        }
    }

    private static IReadOnlyList<AutomationAction> BuildActions(
        SlotSnapshot slot,
        SlotTransition transition,
        AutomationEvent ev)
    {
        if (!transition.Applied)
            return new AutomationAction[]
            {
                new NoAutomationAction(slot.SlotNumber, ev.AttemptId, transition.Reason ?? "evento ignorado")
            };

        if (!transition.Changed)
            return Array.Empty<AutomationAction>();

        return ev switch
        {
            UserOpenPipRequested e when slot.State == SlotState.Opening =>
                new AutomationAction[] { new OpenNativePipAction(slot.SlotNumber, e.SelectedTabId, e.AttemptId) },

            VideoChanged e when slot.State == SlotState.WaitingForReconnect =>
                new AutomationAction[] { new StartReconnectAction(slot.SlotNumber, e.AttemptId) },

            PipWindowLost e when slot.State == SlotState.WaitingForReconnect =>
                new AutomationAction[] { new StartReconnectAction(slot.SlotNumber, e.AttemptId) },

            _ => Array.Empty<AutomationAction>()
        };
    }
}

public sealed record AutomationDecision(
    AutomationEvent Event,
    SlotSnapshot Slot,
    SlotTransition Transition,
    IReadOnlyList<AutomationAction> Actions);
