# Ferramentas de desenvolvimento

Os 67 verificadores PowerShell ficam em `checks/`.

Use os pontos de entrada mantidos na raiz:

- `RUN_CORE_TESTS.bat --ci`: regressão canônica completa.
- `RUN_STABILIZATION_GATE.ps1 -Layer All -Full`: gate de estabilização completo.
- `RUN_CI.ps1`: mesma entrada usada pelo CI.

Cada verificador resolve a raiz do projeto a partir de `tools/checks`, portanto pode ser executado de qualquer diretório de trabalho.
