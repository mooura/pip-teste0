param(
    [ValidateSet('Navigation', 'OpenAll', 'AutoReturn', 'Layout', 'Discovery', 'All')]
    [string]$Layer = 'All',
    [switch]$Full
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path

function Run-PowerShellCheck([string]$name) {
    Write-Host "`nRunning $name..." -ForegroundColor Cyan
    & powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $root "tools\checks\$name")
    if ($LASTEXITCODE -ne 0) { throw "$name failed with exit code $LASTEXITCODE" }
}

Run-PowerShellCheck 'CHECK_STABILIZATION_BOUNDARIES.ps1'

if ($Layer -in @('Navigation', 'All')) {
    Run-PowerShellCheck 'CHECK_MANUAL_NEXT_SAME_TAB.ps1'
    & node --check (Join-Path $root 'src\PiPManager.Extension\background.js')
    if ($LASTEXITCODE -ne 0) { throw 'Extension/background.js syntax check failed' }
    & node (Join-Path $root 'tests\Extension.Tests\site-profiles.test.js')
    if ($LASTEXITCODE -ne 0) { throw 'Extension site profile tests failed' }
    & node (Join-Path $root 'tests\Extension.Tests\next-target-resolver-phase2.test.js')
    if ($LASTEXITCODE -ne 0) { throw 'Extension next target resolver Phase 2 tests failed' }
    Run-PowerShellCheck 'CHECK_NEXT_TARGET_RESOLVER_PHASE2.ps1'
    & node (Join-Path $root 'tests\Extension.Tests\next-target-state-machine-phase3.test.js')
    if ($LASTEXITCODE -ne 0) { throw 'Extension next target state machine Phase 3 tests failed' }
    Run-PowerShellCheck 'CHECK_NEXT_TARGET_STATE_MACHINE_PHASE3.ps1'
    & node (Join-Path $root 'tests\Extension.Tests\next-preview-recovery-hotfix1.test.js')
    if ($LASTEXITCODE -ne 0) { throw 'Extension next + preview recovery Hotfix 1 tests failed' }
    Run-PowerShellCheck 'CHECK_NEXT_PREVIEW_RECOVERY_HOTFIX1.ps1'
    & node (Join-Path $root 'tests\Extension.Tests\next-preview-readiness-hotfix2.test.js')
    if ($LASTEXITCODE -ne 0) { throw 'Extension authoritative preview + silent readiness Hotfix 2 tests failed' }
    Run-PowerShellCheck 'CHECK_NEXT_PREVIEW_READINESS_HOTFIX2.ps1'
    & node (Join-Path $root 'tests\Extension.Tests\next-command-target-preview-hotfix3.test.js')
    if ($LASTEXITCODE -ne 0) { throw 'Extension immutable command target + preview state Hotfix 3 tests failed' }
    Run-PowerShellCheck 'CHECK_NEXT_COMMAND_TARGET_PREVIEW_HOTFIX3.ps1'
    Run-PowerShellCheck 'CHECK_NEXT_PRIORITY_FAST_RETURN_HOTFIX4.ps1'
    & node (Join-Path $root 'tests\Extension.Tests\terminal-autonext-bounded-readiness-hotfix5.test.js')
    if ($LASTEXITCODE -ne 0) { throw 'Terminal auto-next bounded readiness Hotfix 5 tests failed' }
    Run-PowerShellCheck 'CHECK_TERMINAL_AUTONEXT_BOUNDED_READINESS_HOTFIX5.ps1'
    & node (Join-Path $root 'tests\Extension.Tests\reconnect-ownership-geometry-hotfix6.test.js')
    if ($LASTEXITCODE -ne 0) { throw 'Reconnect ownership + geometry Hotfix 6 tests failed' }
    Run-PowerShellCheck 'CHECK_RECONNECT_OWNERSHIP_GEOMETRY_HOTFIX6.ps1'
    & node (Join-Path $root 'tests\Extension.Tests\universal-geometry-preload-handoff-hotfix7.test.js')
    if ($LASTEXITCODE -ne 0) { throw 'Universal geometry + preload handoff Hotfix 7 tests failed' }
    Run-PowerShellCheck 'CHECK_UNIVERSAL_GEOMETRY_PRELOAD_HANDOFF_HOTFIX7.ps1'
    & node (Join-Path $root 'tests\Extension.Tests\real-buffer-manual-geometry-hotfix8.test.js')
    if ($LASTEXITCODE -ne 0) { throw 'Real buffer + trusted manual geometry Hotfix 8 tests failed' }
    Run-PowerShellCheck 'CHECK_REAL_BUFFER_MANUAL_GEOMETRY_HOTFIX8.ps1'
    & node (Join-Path $root 'tests\Extension.Tests\range-network-cap-hotfix9.test.js')
    if ($LASTEXITCODE -ne 0) { throw 'Range network cap Hotfix 9 tests failed' }
    Run-PowerShellCheck 'CHECK_RANGE_NETWORK_CAP_HOTFIX9.ps1'
    & node (Join-Path $root 'tests\Extension.Tests\command-target-root-guard-hotfix10.test.js')
    if ($LASTEXITCODE -ne 0) { throw 'Authoritative CommandTarget + playlist root guard Hotfix 10 tests failed' }
    Run-PowerShellCheck 'CHECK_COMMAND_TARGET_ROOT_GUARD_HOTFIX10.ps1'
    & node (Join-Path $root 'tests\Extension.Tests\auto-return-preserve-sync-hotfix11.test.js')
    if ($LASTEXITCODE -ne 0) { throw 'AutoReturn preserve synchronization Hotfix 11 tests failed' }
    Run-PowerShellCheck 'CHECK_AUTORETURN_PRESERVE_SYNC_HOTFIX11.ps1'
}

if ($Layer -in @('OpenAll', 'All')) {
    Run-PowerShellCheck 'CHECK_TEN_SLOT_COVERAGE.ps1'
}

if ($Layer -in @('AutoReturn', 'All')) {
    Run-PowerShellCheck 'CHECK_AUTORETURN_TRIGGER_ELIGIBILITY.ps1'
    Run-PowerShellCheck 'CHECK_AUTORETURN_INFLIGHT_CANCELLATION.ps1'
    Run-PowerShellCheck 'CHECK_AUTORETURN_HWND_OWNERSHIP_SERIALIZATION.ps1'
}

if ($Layer -in @('Layout', 'All')) {
    Run-PowerShellCheck 'CHECK_RELATIVE_GROUP_LAYOUT_RECOVERY.ps1'
    Run-PowerShellCheck 'CHECK_MIXED_ASPECT_LAYOUT_STABILITY.ps1'
    Run-PowerShellCheck 'CHECK_ATOMIC_LAYOUT_DWM_GAP_STABILIZATION.ps1'
}

if ($Layer -in @('Discovery', 'All')) {
    & node (Join-Path $root 'tests\Extension.Tests\tab-discovery.test.js')
    if ($LASTEXITCODE -ne 0) { throw 'Extension tab discovery tests failed' }
    Run-PowerShellCheck 'CHECK_PLAYLIST_CONTEXT_DETECTION.ps1'
}

Write-Host "`nBuilding application..." -ForegroundColor Cyan
& dotnet build (Join-Path $root 'src\PiPManager.Wpf\PiPManager.Wpf.csproj') -c Release --no-restore
if ($LASTEXITCODE -ne 0) { throw 'Application build failed' }

if ($Full) {
    Write-Host "`nRunning canonical full regression gate..." -ForegroundColor Cyan
    & cmd /c (Join-Path $root 'RUN_CORE_TESTS.bat')
    if ($LASTEXITCODE -ne 0) { throw 'Canonical full regression gate failed' }
}

Write-Host "`nSTABILIZATION GATE PASSED: layer=$Layer; full=$Full" -ForegroundColor Green
