﻿$ErrorActionPreference = 'Stop'

$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$fixedPath = Join-Path $root 'src\PiPManager.Wpf\MainWindow.FixedLayout.cs'
$layoutPath = Join-Path $root 'src\PiPManager.Wpf\MainWindow.Layout.cs'
$mainPath = Join-Path $root 'src\PiPManager.Wpf\MainWindow.xaml.cs'
$dragPath = Join-Path $root 'src\PiPManager.Wpf\MainWindow.PipDrag.cs'

$fixed = Get-Content -LiteralPath $fixedPath -Raw
$layout = Get-Content -LiteralPath $layoutPath -Raw
$main = Get-Content -LiteralPath $mainPath -Raw
$drag = Get-Content -LiteralPath $dragPath -Raw

# Scope the equalize assertions to the EqualizeCaptured method itself.
# Using IndexOf against the whole MainWindow file is invalid because an
# unrelated fixed-layout branch may legitimately appear earlier in the file.
$equalizeStart = $main.IndexOf('private void EqualizeCaptured()')
$equalizeEnd = if ($equalizeStart -ge 0) {
    $main.IndexOf('private void ToggleAllVisibility()', $equalizeStart)
}
else {
    -1
}
$equalizeMethod = if ($equalizeStart -ge 0 -and $equalizeEnd -gt $equalizeStart) {
    $main.Substring($equalizeStart, $equalizeEnd - $equalizeStart)
}
else {
    ''
}
$equalizeJogoIndex = $equalizeMethod.IndexOf('if (CurrentLayout == LayoutMode.Jogo)')
$equalizeFixedIndex = $equalizeMethod.IndexOf('if (_fixedCustomLayoutEnabled && HasCompleteFixedLayoutAuthority())')
$equalizeGenericGridIndex = $equalizeMethod.IndexOf('.Select(_ => new NativeRect(0, 0, referenceRect.Width, referenceRect.Height))')
$equalizeJogoReturnIndex = if ($equalizeJogoIndex -ge 0) {
    $equalizeMethod.IndexOf('            return;', $equalizeJogoIndex)
}
else {
    -1
}

# Manual resize in Jogo is now deliberately reference-only. The native PiP
# keeps the user-selected size, and Igualar applies that size only to the
# reference slot's visual group.
$groupEqualizeStart = $layout.IndexOf('private IReadOnlyList<NativeRect> BuildJogoReferenceGroupEqualizeTargets(')
$groupEqualizeEnd = if ($groupEqualizeStart -ge 0) {
    $layout.IndexOf('private void InitializeJogoManualPlacement()', $groupEqualizeStart)
}
else {
    -1
}
$groupEqualizeMethod = if ($groupEqualizeStart -ge 0 -and $groupEqualizeEnd -gt $groupEqualizeStart) {
    $layout.Substring($groupEqualizeStart, $groupEqualizeEnd - $groupEqualizeStart)
}
else {
    ''
}

$checks = [ordered]@{
    'fixing Jogo does not silently switch to Custom' =
        $fixed.Contains('if (CurrentLayout == LayoutMode.Jogo)') -and
        $fixed.Contains('Converter silenciosamente para Custom')
    'Jogo fixed application uses intrinsic profile targets' =
        $fixed.Contains('BuildJogoContentAwareTargets(') -and
        $fixed.Contains('profile=Jogo; singleAuthority=True')
    'Jogo targets become the fixed authority' =
        $fixed.Contains('CommitJogoTargetsAsFixedAuthority') -and
        $fixed.Contains('jogo-fixed-authority-committed')
    'Jogo equalize bypasses generic uniform fixed grid' =
        ($equalizeStart -ge 0) -and
        ($equalizeEnd -gt $equalizeStart) -and
        ($equalizeJogoIndex -ge 0) -and
        ($equalizeFixedIndex -gt $equalizeJogoIndex) -and
        ($equalizeGenericGridIndex -gt $equalizeFixedIndex) -and
        ($equalizeJogoReturnIndex -gt $equalizeJogoIndex) -and
        ($equalizeJogoReturnIndex -lt $equalizeFixedIndex) -and
        $equalizeMethod.Contains('BuildJogoReferenceGroupEqualizeTargets(') -and
        $equalizeMethod.Contains('equalize-request-jogo-reference-group') -and
        $equalizeMethod.Contains('jogo-group-equalize-from-last-resize')
    'intrinsic reflow refreshes fixed authority' =
        $layout.Contains('CommitJogoTargetsAsFixedAuthority(') -and
        $layout.Contains('$"mixed-aspect-reflow/{source}"')
    'periodic move-only enforcement compares position only' =
        $fixed.Contains('PositionsEqualWithinTolerance(current, target, FixedLayoutGeometryTolerancePx)') -and
        $fixed.Contains('A aplicação periódica é deliberadamente move-only')
    'manual resize cannot accumulate Jogo drift' =
        ($groupEqualizeStart -ge 0) -and
        ($groupEqualizeEnd -gt $groupEqualizeStart) -and
        $drag.Contains('jogo-manual-resize-reference-only') -and
        $drag.Contains('otherWindowsChanged=False') -and
        $fixed.Contains('jogo-fixed-manual-resize-reference-only') -and
        $fixed.Contains('authority=native-border-reference') -and
        $groupEqualizeMethod.Contains('var sizes = occupied.ToDictionary') -and
        $groupEqualizeMethod.Contains('foreach (var slot in referenceGroup)') -and
        $groupEqualizeMethod.Contains('fitScale') -and
        $equalizeMethod.Contains('otherGroupResize=False')
    'Jogo fixed authority cannot be translated off work area' =
        $fixed.Contains('fixed-layout-authority-offset-ignored') -and
        $fixed.Contains('reason=work-area-anchored')
    'selecting Jogo preserves fixed mode' =
        $main.Contains('mode != LayoutMode.Jogo') -and
        $main.Contains('Jogo e Fixar layout são compatíveis')
    'manual slot swap preserves Jogo positions' =
        $main.Contains('EnableJogoManualPlacementFromCurrentTopology') -and
        $main.Contains('slot-drag-swap/jogo-manual-placement') -and
        $layout.Contains('_jogoVisualSlotOrder') -and
        $layout.Contains('_jogoTopSlotNumbers')
    'manual Jogo placement persists' =
        $main.Contains('JogoManualPlacementEnabled = _jogoManualPlacementEnabled') -and
        $main.Contains('JogoVisualSlotOrder = _jogoVisualSlotOrder') -and
        $main.Contains('JogoTopSlots = _jogoVisualSlotOrder')
    'locked drag ends with one Jogo re-anchor' =
        $drag.Contains('natural-anchor-drag-final/jogo-reanchor') -and
        $drag.Contains('Perfil Jogo fixo restaurado após o ajuste')
}

$failures = @()
foreach ($item in $checks.GetEnumerator()) {
    if ($item.Value) {
        Write-Host "$($item.Key): OK"
    }
    else {
        Write-Host "$($item.Key): FAIL"
        $failures += $item.Key
    }
}

# Regression from the runtime log:
# target=152x203 and current=152x86 at the same Left/Top. Because the
# periodic operation is move-only, this must be considered already positioned.
$target = [pscustomobject]@{ Left = 8; Top = 8; Width = 152; Height = 203 }
$current = [pscustomobject]@{ Left = 8; Top = 8; Width = 152; Height = 86 }
$tolerance = 3
$positionEqual =
    [Math]::Abs($target.Left - $current.Left) -le $tolerance -and
    [Math]::Abs($target.Top - $current.Top) -le $tolerance
$fullGeometryEqual =
    $positionEqual -and
    [Math]::Abs($target.Width - $current.Width) -le $tolerance -and
    [Math]::Abs($target.Height - $current.Height) -le $tolerance

if (-not $positionEqual -or $fullGeometryEqual) {
    $failures += 'move-only enforcement regression model'
}

# A 400x225 reference in a four-item top group on a 1920 px work area
# remains 400x225, while a 500 px side rail is not resized.
$referenceWidth = 400
$referenceHeight = 225
$topCount = 4
$workWidth = 1920
$sideWidthBefore = 500
$fitScale = [Math]::Min(1.0, ($workWidth / $topCount) / $referenceWidth)
$equalizedWidth = [Math]::Round($referenceWidth * $fitScale)
$equalizedHeight = [Math]::Round($referenceHeight * $fitScale)
$sideWidthAfter = $sideWidthBefore
if ($equalizedWidth -ne 400 -or $equalizedHeight -ne 225 -or $sideWidthAfter -ne $sideWidthBefore) {
    $failures += 'Jogo same-group equalize regression model'
}

if ($failures.Count -gt 0) {
    Write-Host 'JOGO FIXED LAYOUT AUTHORITY CHECK FAILED:' -ForegroundColor Red
    $failures | Sort-Object -Unique | ForEach-Object {
        Write-Host "- $_" -ForegroundColor Red
    }
    exit 1
}

Write-Host 'JOGO FIXED LAYOUT AUTHORITY CHECK OK.' -ForegroundColor Green
exit 0
