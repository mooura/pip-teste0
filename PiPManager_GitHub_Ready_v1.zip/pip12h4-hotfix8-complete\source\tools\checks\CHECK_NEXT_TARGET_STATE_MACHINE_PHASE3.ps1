$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$content = Get-Content -Raw (Join-Path $root 'src\PiPManager.Extension\content.js')
$background = Get-Content -Raw (Join-Path $root 'src\PiPManager.Extension\background.js')
$main = Get-Content -Raw (Join-Path $root 'src\PiPManager.Wpf\MainWindow.xaml.cs')
$model = Get-Content -Raw (Join-Path $root 'src\PiPManager.Wpf\Models\VideoTabInfo.cs')
$manifest = Get-Content -Raw (Join-Path $root 'src\PiPManager.Extension\manifest.json') | ConvertFrom-Json
$release = Get-Content -Raw (Join-Path $root 'src\PiPManager.Wpf\Services\ReleaseInfoService.cs')
$runner = Get-Content -Raw (Join-Path $root 'RUN_CORE_TESTS.bat')

$checks = [ordered]@{
  'manifest is 1.4.39.25' = ([string]$manifest.version -eq '1.4.39.25')
  'release metadata is 1.4.39.25' = $release.Contains('ExtensionVersion = "1.4.39.25"')
  'phase identifier is synchronized' = $content.Contains("CONTENT_VERSION = '1.4.39.25-command-target-root-guard-hotfix10'") -and $background.Contains("BRIDGE_VERSION = '1.4.39.25-command-target-root-guard-hotfix10'")
  'target generation exists' = $content.Contains('let pipManagerNextTargetGeneration = 0')
  'strong cancellation exists' = $content.Contains('let pipManagerNextTargetResolutionController = null') -and $content.Contains('function abortNextTargetResolution(')
  'explicit lifecycle states exist' = $content.Contains("lifecycleState: 'RESOLVING_TARGET'") -and $content.Contains("updateNextTargetLifecycle('RESOLVING_MEDIA'") -and $content.Contains("updateNextTargetLifecycle('PRELOADING'") -and ($content.Contains("updateNextTargetLifecycle('READY'") -or $content.Contains('range-preload-byte-cache-ready'))
  'stale generations are rejected' = $content.Contains('target.generation === pipManagerNextTargetState.generation') -and $content.Contains('target.operationId === pipManagerNextTargetState.operationId')
  'same-current target changes increment generation' = $content.Contains('resolvedTargetChangedWithinSameCurrent')
  'navigation cancels operations' = $content.Contains("window.addEventListener('pagehide'")
  'preview consumes authoritative target' = $content.Contains('sanitizeTargetThumbnail(') -and $content.Contains('buildAuthoritativePreviewPayload(authoritativeTarget)') -and $content.Contains('nextPreviewAssetId: targetResolved ? authoritativePreview.assetId') -and $model.Contains('NextPreviewAssetId') -and $main.Contains('IsAuthoritativeNextPreview(')
  'AutoReturn waits for resolver' = $main.Contains('resolverBlocksSameVideoFallback') -and $main.Contains('auto-return-same-video-fallback-deferred-target-resolution')
  'WPF carries target operation identity' = $model.Contains('NextTargetLifecycleState') -and $model.Contains('NextTargetGeneration') -and $model.Contains('NextTargetOperationId')
  'node regression test is wired' = $runner.Contains('next-target-state-machine-phase3.test.js')
}

$failed = @()
foreach ($item in $checks.GetEnumerator()) {
  if ($item.Value) { Write-Host ($item.Key + ': OK') }
  else { Write-Host ($item.Key + ': FAIL'); $failed += $item.Key }
}
if ($failed.Count -gt 0) { throw ('Next Target State Machine Phase 3 checks failed: ' + ($failed -join ', ')) }
Write-Host 'Next Target State Machine Phase 3 checks OK.'
