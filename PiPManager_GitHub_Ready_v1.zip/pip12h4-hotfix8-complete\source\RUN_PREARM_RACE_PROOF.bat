﻿@echo off
setlocal
set "PIPMANAGER_DIAGNOSTIC_PREARM_DELAY_MS=700"
echo PiPManager deterministic pre-arm race proof enabled.
echo Diagnostic delay: %PIPMANAGER_DIAGNOSTIC_PREARM_DELAY_MS% ms
echo.
set "APP=%~dp0DIST\PiPManager_9.39.01\PiPManager.Wpf.exe"
if not exist "%APP%" (
  echo Published executable not found:
  echo %APP%
  echo Run BUILD_WINDOWS.bat first.
  pause
  exit /b 1
)
start "PiPManager PreArm Race Proof" /wait "%APP%"
endlocal
