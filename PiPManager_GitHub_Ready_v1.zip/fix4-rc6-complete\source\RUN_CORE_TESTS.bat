﻿@echo off
setlocal
set CI_MODE=0
if /I "%~1"=="--ci" set CI_MODE=1

cd /d "%~dp0"

echo Running PiPManager.Core.Tests...
dotnet run --project tests\PiPManager.Core.Tests\PiPManager.Core.Tests.csproj -c Release
if errorlevel 1 (
  echo.
  echo CORE TESTS FAILED.
  if "%CI_MODE%"=="0" pause
  exit /b 1
)

echo.
echo CORE TESTS OK.

echo.
echo Running Extension site profile isolation tests...
node "%~dp0tests\Extension.Tests\site-profiles.test.js"
if errorlevel 1 (
  echo.
  echo EXTENSION SITE PROFILE TESTS FAILED.
  if "%CI_MODE%"=="0" pause
  exit /b 1
)

echo.
echo Running Extension tab discovery tests...
node "%~dp0tests\Extension.Tests\tab-discovery.test.js"
if errorlevel 1 (
  echo.
  echo EXTENSION TAB DISCOVERY TESTS FAILED.
  if "%CI_MODE%"=="0" pause
  exit /b 1
)

echo.
echo Checking Extension JavaScript syntax...
node --check "%~dp0src\PiPManager.Extension\background.js"
if errorlevel 1 (
  echo.
  echo EXTENSION BACKGROUND SYNTAX CHECK FAILED.
  if "%CI_MODE%"=="0" pause
  exit /b 1
)
node --check "%~dp0src\PiPManager.Extension\content.js"
if errorlevel 1 (
  echo.
  echo EXTENSION CONTENT SYNTAX CHECK FAILED.
  if "%CI_MODE%"=="0" pause
  exit /b 1
)

echo.
echo Running navigation transaction regression tests...
node "%~dp0tests\Extension.Tests\navigation-transaction.test.js"
if errorlevel 1 (
  echo.
  echo NAVIGATION TRANSACTION TESTS FAILED.
  if "%CI_MODE%"=="0" pause
  exit /b 1
)

echo.
echo Checking correlated Next/Previous command telemetry...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_VIDEO_COMMAND_TELEMETRY.ps1"
if errorlevel 1 (
  echo.
  echo VIDEO COMMAND TELEMETRY CHECK FAILED.
  if "%CI_MODE%"=="0" pause
  exit /b 1
)

echo.
echo Checking Shadow behavior sequences...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_SHADOW_BEHAVIOR_SEQUENCES.ps1"
if errorlevel 1 (
  echo.
  echo SHADOW BEHAVIOR SEQUENCE CHECK FAILED.
  if "%CI_MODE%"=="0" pause
  exit /b 1
)

echo.
echo Checking Shadow hook bindings...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_SHADOW_HOOK_BINDINGS.ps1"
if errorlevel 1 (
  echo.
  echo SHADOW HOOK BINDING CHECK FAILED.
  if "%CI_MODE%"=="0" pause
  exit /b 1
)

echo.
echo Checking Shadow parity report...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_SHADOW_PARITY_REPORT.ps1"
if errorlevel 1 (
  echo.
  echo SHADOW PARITY REPORT CHECK FAILED.
  if "%CI_MODE%"=="0" pause
  exit /b 1
)

echo.
echo Checking Shadow parity classification...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_SHADOW_PARITY_CLASSIFICATION.ps1"
if errorlevel 1 (
  echo.
  echo SHADOW PARITY CLASSIFICATION CHECK FAILED.
  if "%CI_MODE%"=="0" pause
  exit /b 1
)

echo.
echo Checking Shadow final state report...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_SHADOW_FINAL_STATE_REPORT.ps1"
if errorlevel 1 (
  echo.
  echo SHADOW FINAL STATE REPORT CHECK FAILED.
  if "%CI_MODE%"=="0" pause
  exit /b 1
)

echo.
echo Checking Architecture Phase 1...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_ARCHITECTURE_PHASE1.ps1"
if errorlevel 1 (
  echo.
  echo ARCHITECTURE PHASE 1 CHECK FAILED.
  if "%CI_MODE%"=="0" pause
  exit /b 1
)

echo.
echo Checking Extension handshake version...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_EXTENSION_HANDSHAKE_VERSION.ps1"
if errorlevel 1 (
  echo.
  echo EXTENSION HANDSHAKE VERSION CHECK FAILED.
  if "%CI_MODE%"=="0" pause
  exit /b 1
)

echo.
echo Checking Architecture Phase 2...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_ARCHITECTURE_PHASE2.ps1"
if errorlevel 1 (
  echo.
  echo ARCHITECTURE PHASE 2 CHECK FAILED.
  if "%CI_MODE%"=="0" pause
  exit /b 1
)

echo.
echo Checking Architecture Phase 3...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_ARCHITECTURE_PHASE3.ps1"
if errorlevel 1 (
  echo.
  echo ARCHITECTURE PHASE 3 CHECK FAILED.
  if "%CI_MODE%"=="0" pause
  exit /b 1
)

echo.
echo Checking test runner path resilience...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_TEST_RUNNER_PATH_RESILIENCE.ps1"
if errorlevel 1 (
  echo.
  echo TEST RUNNER PATH RESILIENCE CHECK FAILED.
  exit /b 1
)
echo.

echo Running Window Event Monitor fake tests...
dotnet run --project tests\PiPManager.WindowEventMonitor.Tests\PiPManager.WindowEventMonitor.Tests.csproj -c Release
if errorlevel 1 (
  echo.
  echo WINDOW EVENT MONITOR FAKE TESTS FAILED.
  if "%CI_MODE%"=="0" pause
  exit /b 1
)

echo.
echo Checking Window Event Monitor fake source...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_WINDOW_EVENT_MONITOR_FAKE_SOURCE.ps1"
if errorlevel 1 (
  echo.
  echo WINDOW EVENT MONITOR FAKE SOURCE CHECK FAILED.
  if "%CI_MODE%"=="0" pause
  exit /b 1
)

echo.
echo Checking Window Event Assisted Reconnect...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_WINDOW_EVENT_ASSISTED_RECONNECT.ps1"
if errorlevel 1 (
  echo.
  echo WINDOW EVENT ASSISTED RECONNECT CHECK FAILED.
  if "%CI_MODE%"=="0" pause
  exit /b 1
)

echo.
echo Checking Shadow lost before AutoReturn policy...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_SHADOW_LOST_BEFORE_AUTORETURN_POLICY.ps1"
if errorlevel 1 (
  echo.
  echo SHADOW LOST BEFORE AUTORETURN POLICY CHECK FAILED.
  if "%CI_MODE%"=="0" pause
  exit /b 1
)

echo.
echo Checking Automation Engine Shadow...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_AUTOMATION_ENGINE_SHADOW.ps1"
if errorlevel 1 (
  echo.
  echo AUTOMATION ENGINE SHADOW CHECK FAILED.
  if "%CI_MODE%"=="0" pause
  exit /b 1
)

echo.
echo Checking Automation Engine behavior...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_AUTOMATION_ENGINE_BEHAVIOR.ps1"
if errorlevel 1 (
  echo.
  echo AUTOMATION ENGINE BEHAVIOR CHECK FAILED.
  if "%CI_MODE%"=="0" pause
  exit /b 1
)

echo.
echo Checking AutoReturn in-flight cancellation...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_AUTORETURN_INFLIGHT_CANCELLATION.ps1"
if errorlevel 1 (
  echo.
  echo AUTORETURN IN-FLIGHT CANCELLATION CHECK FAILED.
  if "%CI_MODE%"=="0" pause
  exit /b 1
)

echo.
echo Checking AutoReturn trigger eligibility...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_AUTORETURN_TRIGGER_ELIGIBILITY.ps1"
if errorlevel 1 (
  echo.
  echo AUTORETURN TRIGGER ELIGIBILITY CHECK FAILED.
  if "%CI_MODE%"=="0" pause
  exit /b 1
)

echo.
echo Checking AutoReturn disable cancels pending...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_AUTORETURN_DISABLE_CANCELS_PENDING.ps1"
if errorlevel 1 (
  echo.
  echo AUTORETURN DISABLE CANCELS PENDING CHECK FAILED.
  if "%CI_MODE%"=="0" pause
  exit /b 1
)

echo.
echo Checking AutoReturn fresh snapshot no-video gate...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_AUTORETURN_FRESH_SNAPSHOT_NO_VIDEO_GATE.ps1"
if errorlevel 1 (
  echo.
  echo AUTORETURN FRESH SNAPSHOT NO-VIDEO GATE CHECK FAILED.
  if "%CI_MODE%"=="0" pause
  exit /b 1
)

echo.
echo Checking AutoReturn trigger refinements...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_AUTORETURN_TRIGGER_REFINEMENTS.ps1"
if errorlevel 1 (
  echo.
  echo AUTORETURN TRIGGER REFINEMENTS CHECK FAILED.
  if "%CI_MODE%"=="0" pause
  exit /b 1
)

echo.
echo Checking Window Event Reactor Shadow...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_WINDOW_EVENT_REACTOR_SHADOW.ps1"
if errorlevel 1 (
  echo.
  echo WINDOW EVENT REACTOR SHADOW CHECK FAILED.
  if "%CI_MODE%"=="0" pause
  exit /b 1
)

echo.
echo Checking Window Event Reactor Assisted Capture Compile Fix...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_WINDOW_EVENT_REACTOR_ASSISTED_CAPTURE.ps1"
if errorlevel 1 (
  echo.
  echo WINDOW EVENT REACTOR ASSISTED CAPTURE CHECK FAILED.
  if "%CI_MODE%"=="0" pause
  exit /b 1
)

echo.
echo Checking Window Event Reactor deterministic pre-arm diagnostic...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_WINDOW_EVENT_REACTOR_PREARM_DIAGNOSTIC.ps1"
if errorlevel 1 (
  echo.
  echo WINDOW EVENT REACTOR PRE-ARM DIAGNOSTIC CHECK FAILED.
  if "%CI_MODE%"=="0" pause
  exit /b 1
)

echo.
echo Checking Reactor adaptive authority...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_REACTOR_ADAPTIVE_AUTHORITY.ps1"
if errorlevel 1 (
  echo.
  echo REACTOR ADAPTIVE AUTHORITY CHECK FAILED.
  if "%CI_MODE%"=="0" pause
  exit /b 1
)

echo.
echo.
echo Checking Connection and Capture UX...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_CONNECTION_CAPTURE_UX.ps1"
if errorlevel 1 (
  echo.
  echo CONNECTION AND CAPTURE UX CHECK FAILED.
  exit /b 1
)

echo.
echo Checking Connection Capture UX initialization...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_CONNECTION_CAPTURE_UX_INITIALIZATION.ps1"
if errorlevel 1 (
  echo.
  echo CONNECTION CAPTURE UX INITIALIZATION CHECK FAILED.
  exit /b 1
)


echo.
echo Checking focusless lock and duplicate video guard...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_FOCUSLESS_LOCK_DUPLICATE_VIDEO.ps1"
if errorlevel 1 (
  echo.
  echo FOCUSLESS LOCK AND DUPLICATE VIDEO CHECK FAILED.
  exit /b 1
)


echo.
echo Checking Multi-Monitor Layout UX...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_MULTI_MONITOR_LAYOUT_UX.ps1"
if errorlevel 1 (
  echo.
  echo MULTI-MONITOR LAYOUT UX CHECK FAILED.
  exit /b 1
)
echo.
echo Checking AutoReturn Ownership Checker Alignment...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_SLOT_DRAG_VISUAL_IDENTITY_UX.ps1"
if errorlevel 1 (
  echo.
  echo SLOT DRAG AND VISUAL IDENTITY UX CHECK FAILED.
  exit /b 1
)
echo.
echo Checking AutoReturn focus lease and HWND recovery...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_AUTORETURN_FOCUS_LEASE_HWND_RECOVERY.ps1"
if errorlevel 1 (
  echo.
  echo AUTORETURN FOCUS LEASE HWND RECOVERY CHECK FAILED.
  exit /b 1
)

echo.
echo.
echo Checking AutoReturn HWND ownership serialization...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_AUTORETURN_HWND_OWNERSHIP_SERIALIZATION.ps1"
if errorlevel 1 (
  echo.
  echo AUTORETURN HWND OWNERSHIP SERIALIZATION CHECK FAILED.
  exit /b 1
)

echo.
echo Checking five-PiP identity stability...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_FIVE_PIP_IDENTITY_STABILITY.ps1"
if errorlevel 1 (
  echo.
  echo FIVE-PIP IDENTITY STABILITY CHECK FAILED.
  exit /b 1
)

echo.
echo Checking AutoReturn preemptive HWND reservation...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_AUTORETURN_PREEMPTIVE_HWND_RESERVATION.ps1"
if errorlevel 1 (
  echo.
  echo AUTORETURN PREEMPTIVE HWND RESERVATION CHECK FAILED.
  exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_FAST_OPEN_BROWSER_MINIMIZE.ps1"
if errorlevel 1 (echo. & echo FAST OPEN AND BROWSER MINIMIZE CHECK FAILED. & exit /b 1)

echo.
echo Checking initial open browser minimize...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_INITIAL_OPEN_BROWSER_MINIMIZE.ps1"
if errorlevel 1 (
  echo.
  echo INITIAL OPEN BROWSER MINIMIZE CHECK FAILED.
  exit /b 1
)

echo.
echo Checking adaptive browser restore readiness...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_ADAPTIVE_BROWSER_RESTORE_READINESS.ps1"
if errorlevel 1 (
  echo.
  echo ADAPTIVE BROWSER RESTORE READINESS CHECK FAILED.
  exit /b 1
)

echo.
echo Checking Atomic Layout and DWM Gap Stabilization...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_ATOMIC_LAYOUT_DWM_GAP_STABILIZATION.ps1"
if errorlevel 1 (
  echo.
  echo ATOMIC LAYOUT DWM GAP STABILIZATION CHECK FAILED.
  exit /b 1
)

echo.
echo Checking Stable Group Layout Debounce and Physical Shortcut Retry...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_STABLE_GROUP_LAYOUT_DEBOUNCE_PHYSICAL_SHORTCUT_RETRY.ps1"
if errorlevel 1 (
  echo.
  echo STABLE GROUP LAYOUT DEBOUNCE PHYSICAL SHORTCUT RETRY CHECK FAILED.
  exit /b 1
)

echo.
echo Checking Initial Open Confirmed Capture Retry Gate...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_INITIAL_OPEN_CONFIRMED_CAPTURE_RETRY_GATE.ps1"
if errorlevel 1 (
  echo.
  echo INITIAL OPEN CONFIRMED CAPTURE RETRY GATE CHECK FAILED.
  exit /b 1
)

echo.
echo Checking ten-slot coverage...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_TEN_SLOT_COVERAGE.ps1"
if errorlevel 1 (
  echo.
  echo TEN-SLOT COVERAGE CHECK FAILED.
  exit /b 1
)

echo.
echo Checking stabilization boundaries...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_STABILIZATION_BOUNDARIES.ps1"
if errorlevel 1 (
  echo.
  echo STABILIZATION BOUNDARY CHECK FAILED.
  exit /b 1
)

echo.
echo Checking manual Next exact-tab fallback...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_MANUAL_NEXT_SAME_TAB.ps1"
if errorlevel 1 (
  echo.
  echo MANUAL NEXT EXACT-TAB CHECK FAILED.
  exit /b 1
)

echo.
echo Checking automatic next on terminal playback...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_AUTO_NEXT_ON_TERMINAL.ps1"
if errorlevel 1 (
  echo.
  echo AUTO NEXT ON TERMINAL CHECK FAILED.
  exit /b 1
)

echo.
echo Checking mixed-aspect layout stability...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_MIXED_ASPECT_LAYOUT_STABILITY.ps1"
if errorlevel 1 (
  echo.
  echo MIXED-ASPECT LAYOUT STABILITY CHECK FAILED.
  exit /b 1
)

echo.
echo Checking fixed-layout external resize echo dedup...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_FIXED_LAYOUT_EXTERNAL_RESIZE_ECHO_DEDUP.ps1"
if errorlevel 1 (
  echo.
  echo FIXED-LAYOUT EXTERNAL RESIZE ECHO DEDUP CHECK FAILED.
  exit /b 1
)

echo.
echo Checking Jogo ten-PiP profile layout...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_JOGO_PROFILE_LAYOUT.ps1"
if errorlevel 1 (
  echo.
  echo JOGO TEN-PIP PROFILE LAYOUT CHECK FAILED.
  exit /b 1
)

echo.
echo Checking Jogo and fixed-layout single authority...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_JOGO_FIXED_LAYOUT_AUTHORITY.ps1"
if errorlevel 1 (
  echo.
  echo JOGO FIXED LAYOUT AUTHORITY CHECK FAILED.
  exit /b 1
)

echo.
echo Checking Jogo Space hide/show hotkey...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_JOGO_SPACE_HIDE_HOTKEY.ps1"
if errorlevel 1 (
  echo.
  echo JOGO SPACE HIDE/SHOW HOTKEY CHECK FAILED.
  exit /b 1
)

echo.
echo Checking Jogo free-area scale...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_JOGO_FREE_AREA_SCALE.ps1"
if errorlevel 1 (
  echo.
  echo JOGO FREE AREA SCALE CHECK FAILED.
  exit /b 1
)

echo.
echo Checking Jogo dual group border resize...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_JOGO_DUAL_GROUP_RESIZE.ps1"
if errorlevel 1 (
  echo.
  echo JOGO DUAL GROUP RESIZE CHECK FAILED.
  exit /b 1
)

echo.
echo Checking runtime stall guards...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_RUNTIME_STALL_GUARDS.ps1"
if errorlevel 1 (
  echo.
  echo RUNTIME STALL GUARD CHECK FAILED.
  exit /b 1
)


echo.
echo Checking AutoReturn ready-first no-retry...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_AUTORETURN_READY_FIRST_NO_RETRY.ps1"
if errorlevel 1 (
  echo.
  echo AUTORETURN READY-FIRST NO-RETRY CHECK FAILED.
  exit /b 1
)
echo.

echo Checking AutoReturn hard readiness gate...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_AUTORETURN_HARD_READINESS_GATE.ps1"
if errorlevel 1 (
  echo.
  echo AUTORETURN HARD READINESS GATE CHECK FAILED.
  exit /b 1
)
echo.

echo Checking fast terminal-first hidden AutoReturn...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_FAST_TERMINAL_FIRST_HIDDEN_AUTORETURN.ps1"
if errorlevel 1 (
  echo.
  echo FAST TERMINAL-FIRST HIDDEN AUTORETURN CHECK FAILED.
  exit /b 1
)

echo.
echo Checking advertisement video isolation...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_ADVERTISEMENT_VIDEO_ISOLATION.ps1"
if errorlevel 1 (
  echo.
  echo ADVERTISEMENT VIDEO ISOLATION CHECK FAILED.
  exit /b 1
)

echo.
echo Checking terminal preempt handoff...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_TERMINAL_PREEMPT_HANDOFF.ps1"
if errorlevel 1 (
  echo.
  echo TERMINAL PREEMPT HANDOFF CHECK FAILED.
  exit /b 1
)

echo.
echo Checking Fluency Core Phase 1...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_FLUENCY_CORE_PHASE1.ps1"
if errorlevel 1 (
  echo.
  echo FLUENCY CORE PHASE 1 CHECK FAILED.
  exit /b 1
)

echo.
echo Checking Fluency Core Phase 1.1...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_FLUENCY_CORE_PHASE1_1.ps1"
if errorlevel 1 (
  echo.
  echo FLUENCY CORE PHASE 1.1 CHECK FAILED.
  exit /b 1
)

echo.
echo Checking Playback Fluency Guards...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_PLAYBACK_FLUENCY_GUARDS.ps1"
if errorlevel 1 (
  echo.
  echo PLAYBACK FLUENCY GUARD CHECK FAILED.
  exit /b 1
)

echo.
echo Checking Native Layout Engine Phase 1...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_NATIVE_LAYOUT_ENGINE_PHASE1.ps1"
if errorlevel 1 (
  echo.
  echo NATIVE LAYOUT ENGINE PHASE 1 CHECK FAILED.
  exit /b 1
)

echo.
echo Checking Native Layout Engine Phase 1.1...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_NATIVE_LAYOUT_ENGINE_PHASE1_1.ps1"
if errorlevel 1 (
  echo.
  echo NATIVE LAYOUT ENGINE PHASE 1.1 CHECK FAILED.
  exit /b 1
)

echo.
echo Checking Silent Gesture Immediate Fallback...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_SILENT_GESTURE_IMMEDIATE_FALLBACK.ps1"
if errorlevel 1 (
  echo.
  echo SILENT GESTURE IMMEDIATE FALLBACK CHECK FAILED.
  exit /b 1
)

echo.
echo Checking Reconnect Position Restore...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_RECONNECT_POSITION_RESTORE.ps1"
if errorlevel 1 (
  echo.
  echo RECONNECT POSITION RESTORE CHECK FAILED.
  exit /b 1
)

echo.
echo Checking Fixed Custom Layout and Respect Area...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_FIXED_CUSTOM_LAYOUT_RESPECT_AREA.ps1"
if errorlevel 1 (
  echo.
  echo FIXED CUSTOM LAYOUT CHECK FAILED.
  exit /b 1
)

echo.
echo Checking Relative Group Layout and AutoReturn Recovery Coordination...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_RELATIVE_GROUP_LAYOUT_RECOVERY.ps1"
if errorlevel 1 (
  echo.
  echo RELATIVE GROUP LAYOUT AND RECOVERY CHECK FAILED.
  exit /b 1
)

echo.
echo Checking Fixed Area, Ten-Slot Capacity and Aspect UX...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_FIXED_AREA_TEN_SLOT_ASPECT_UX.ps1"
if errorlevel 1 (
  echo.
  echo FIXED AREA, TEN-SLOT CAPACITY AND ASPECT UX CHECK FAILED.
  exit /b 1
)

echo.
echo Checking Browser Foreground Cloak...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_BROWSER_FOREGROUND_CLOAK.ps1"
if errorlevel 1 (
  echo.
  echo BROWSER FOREGROUND CLOAK CHECK FAILED.
  exit /b 1
)

echo.
echo Checking Manual Open Pre-Focus Cloak...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_MANUAL_OPEN_PREFOCUS_CLOAK.ps1"
if errorlevel 1 (
  echo.
  echo MANUAL OPEN PRE-FOCUS CLOAK CHECK FAILED.
  exit /b 1
)

echo.
echo Checking Playlist Context Detection...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_PLAYLIST_CONTEXT_DETECTION.ps1"
if errorlevel 1 (
  echo.
  echo PLAYLIST CONTEXT DETECTION CHECK FAILED.
  exit /b 1
)

echo.
echo Checking P0 Optimization RC4 compatibility...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_P0_OPTIMIZATION_RC4.ps1"
if errorlevel 1 (
  echo.
  echo P0 OPTIMIZATION RC4 COMPATIBILITY CHECK FAILED.
  exit /b 1
)

echo.
echo Checking P0 Optimization RC5...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_P0_OPTIMIZATION_RC5.ps1"
if errorlevel 1 (
  echo.
  echo P0 OPTIMIZATION RC5 CHECK FAILED.
  exit /b 1
)

echo.
echo Checking P0 Optimization RC6...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_P0_OPTIMIZATION_RC6.ps1"
if errorlevel 1 (
  echo.
  echo P0 OPTIMIZATION RC6 CHECK FAILED.
  exit /b 1
)

echo.
echo Checking Consolidation Phase 1 Baseline...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_CONSOLIDATION_PHASE1_BASELINE.ps1"
if errorlevel 1 (
  echo.
  echo CONSOLIDATION PHASE 1 BASELINE CHECK FAILED.
  exit /b 1
)

echo.
echo Checking Consolidation Phase 2 Test Inventory...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_CONSOLIDATION_PHASE2_TEST_INVENTORY.ps1"
if errorlevel 1 (
  echo.
  echo CONSOLIDATION PHASE 2 TEST INVENTORY CHECK FAILED.
  exit /b 1
)

echo.
echo Checking Consolidation Block A ^(Phases 3 and 4^)...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_CONSOLIDATION_BLOCK_A.ps1"
if errorlevel 1 (
  echo.
  echo CONSOLIDATION BLOCK A CHECK FAILED.
  exit /b 1
)

echo.
echo Checking Consolidation Block B ^(Phases 5 to 8^)...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_CONSOLIDATION_BLOCK_B.ps1"
if errorlevel 1 (
  echo.
  echo CONSOLIDATION BLOCK B CHECK FAILED.
  exit /b 1
)

echo.
echo Checking Consolidation Block C ^(Phases 9 to 11^)...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_CONSOLIDATION_BLOCK_C.ps1"
if errorlevel 1 (
  echo.
  echo CONSOLIDATION BLOCK C CHECK FAILED.
  exit /b 1
)

echo.
echo Checking Consolidation Phase 12 ^(AutoAdvance safety and fresh target recovery^)...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_CONSOLIDATION_PHASE12.ps1"
if errorlevel 1 (
  echo.
  echo CONSOLIDATION PHASE 12 CHECK FAILED.
  exit /b 1
)

echo.
if defined PIPMANAGER_RUNTIME_LOG (
  echo Checking Window Event Reactor runtime log...
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_WINDOW_EVENT_REACTOR_ASSISTED_CAPTURE_RUNTIME_LOG.ps1" -LogPath "%PIPMANAGER_RUNTIME_LOG%"
  if errorlevel 1 (
    echo.
    echo WINDOW EVENT REACTOR RUNTIME LOG CHECK FAILED.
    exit /b 1
  )
) else (
  echo Runtime log check skipped: set PIPMANAGER_RUNTIME_LOG to a real PiP Manager log file to enable it.
)

echo ALL TESTS AND CHECKS OK.

if "%CI_MODE%"=="0" pause
exit /b 0
