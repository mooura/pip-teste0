# PiPManager FIX4 RC6 - Tab Occupied Slots Notification System

## Overview
Implemented a notification system where the WPF application sends occupied slot information to all browser tabs, enabling tabs to reorganize their layout and occupy free space when PiPs are positioned in slots.

## Files Modified

### 1. src/PiPManager.Wpf/MainWindow.xaml.cs
**Changes:**
- Added field `_lastSentOccupiedSlotsSignature` at line 35 to track the last sent occupied slots and avoid spam notifications
- Added method `NotifyTabsOfOccupiedSlots()` that:
  - Collects information about occupied slots (slot number, position, dimensions)
  - Creates a signature to avoid duplicate notifications
  - Serializes occupied slots as JSON
  - Calls `_extensionBridge.SendOccupiedSlotsNotificationAsync()` to send message
  - Includes timestamp and comprehensive logging

**Key Features:**
- Filters only usable windows (via `PipWindowService.IsUsable()`)
- Orders slots by slot number for consistency
- Deduplicates based on slot geometry signature
- Handles exceptions gracefully with warning logs

### 2. src/PiPManager.Wpf/Services/ExtensionBridgeService.cs
**Changes:**
- Added new method `SendOccupiedSlotsNotificationAsync(string payload)` that:
  - Accepts pre-serialized JSON payload
  - Forwards to all connected extension clients via `SendTextToOpenClientsAsync()`
  - Follows the same pattern as `SendNextVideoPreloadSettingAsync()` and other methods

### 3. src/PiPManager.Wpf/MainWindow.Layout.cs
**Changes:**
- Added call to `_ = NotifyTabsOfOccupiedSlots();` at line ~201 in the `ApplyTargetsToOccupiedSlots()` method, right after all layout has been applied and before the transaction completes
- This ensures tabs are notified whenever PiP layout changes

**Trigger Points:**
- Method fires whenever PiP positions are applied (move/resize operations)
- Occurs after all visual updates have completed
- Executes before layout transaction ends

### 4. src/PiPManager.Extension/background.js
**Changes:**
- Added message handler for 'notify-occupied-slots' type (lines ~462-479) in the `socket.onmessage` handler
- Handler:
  - Extracts occupied slots array from the message
  - Queries all active browser tabs
  - Forwards the message to each tab's content script using `sendMessageToTabFrame()`
  - Gracefully handles failures (silent fail for tabs without content script)

**Flow:**
```
WPF App -> WebSocket -> background.js -> All Tabs
```

### 5. src/PiPManager.Extension/content.js
**Changes:**
- Added `window.addEventListener('message', ...)` listener (lines ~217-239) to receive messages from background script
- Added function `handleOccupiedSlotsNotification()` (lines ~241-258) that:
  - Stores occupied slots in `window._pipManagerOccupiedSlots` for local access
  - Logs slot information for diagnostics
  - Dispatches a custom event 'pip-manager-occupied-slots' for site layout engines
  - Handles errors gracefully

**Capabilities:**
- Stores slot data for programmatic access
- Console logging for debugging
- Custom event for site integration
- Error handling with warnings

## Message Flow Diagram

```
┌─────────────────────┐
│  WPF Application    │
│  (MainWindow)       │
└──────────┬──────────┘
           │
           │ ApplyTargetsToOccupiedSlots()
           │ + NotifyTabsOfOccupiedSlots()
           │
           ▼
┌─────────────────────────────────────────┐
│  ExtensionBridgeService                 │
│  SendOccupiedSlotsNotificationAsync()    │
└──────────┬──────────────────────────────┘
           │
           ▼
┌─────────────────────────────────────────┐
│  WebSocket (127.0.0.1:45151)            │
│  Message Type: 'notify-occupied-slots'  │
└──────────┬──────────────────────────────┘
           │
           ▼
┌─────────────────────┐
│  background.js      │
│  (Extension)        │
└──────────┬──────────┘
           │
           │ chrome.tabs.query()
           │ sendMessageToTabFrame()
           │
           ├─────────────────┬──────────────────┬─────────────┐
           │                 │                  │             │
           ▼                 ▼                  ▼             ▼
    ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐
    │  content.js  │  │  content.js  │  │  content.js  │  │  content.js  │
    │  (Tab 1)     │  │  (Tab 2)     │  │  (Tab 3)     │  │  (Tab 4)     │
    └──────────────┘  └──────────────┘  └──────────────┘  └──────────────┘
    (All tabs get the message)
    │
    └─ window.dispatchEvent('pip-manager-occupied-slots')
```

## Data Structure

### Occupied Slot Object
```json
{
  "type": "notify-occupied-slots",
  "occupiedSlots": [
    {
      "slotNumber": 1,
      "left": 100,
      "top": 150,
      "right": 400,
      "bottom": 350,
      "width": 300,
      "height": 200,
      "isValid": true
    }
  ],
  "timestamp": 1691234567890000
}
```

## Problem Statement
Previously, tabs didn't have visibility into which slots were occupied by PiPs, causing:
- "Abrir Todos" (Open All) to break due to slot conflicts
- "Agrupar" (Group) to fail due to incorrect layout calculation
- "Fixar Layout" (Fixed Layout) to cause overlaps
- Tabs to remain at fullscreen instead of occupying free space

## Solution Benefits
1. **Real-time Awareness**: Tabs immediately know which slots are occupied
2. **Dynamic Layout**: Sites can reorganize content to avoid PiP windows
3. **No Overlap**: Layout engines can calculate free space accurately
4. **Flexible Integration**: Sites can listen to custom event or access stored data
5. **Deduplication**: Avoids spam notifications when no layout changes occur
6. **Error Resilience**: Graceful handling of tabs without content script
7. **Architecture Aligned**: Uses existing ExtensionBridgeService patterns

## Code Pattern Used

The implementation follows the established pattern in `ExtensionBridgeService`:

```csharp
// In ExtensionBridgeService.cs
internal Task<int> SendOccupiedSlotsNotificationAsync(string payload)
{
    return SendTextToOpenClientsAsync(payload);
}

// In MainWindow.xaml.cs
var payload = System.Text.Json.JsonSerializer.Serialize(message);
await _extensionBridge.SendOccupiedSlotsNotificationAsync(payload);
```

This follows the same pattern as:
- `SendNextVideoPreloadSettingAsync()`
- `SendVideoCommandAsync()`
- `SendOpenPictureInPictureAsync()`

## Verification Steps

### C# Code Verification
- ✓ Field declaration syntax correct (string type with initialization)
- ✓ Method signature matches async Task pattern
- ✓ LINQ queries correctly chain Where/OrderBy/Select
- ✓ Anonymous object creation with correct property names
- ✓ String signature generation and comparison logic
- ✓ ExtensionBridgeService integration using correct method
- ✓ AppLogger calls follow existing conventions
- ✓ Exception handling with try-catch-finally
- ✓ Method call in MainWindow.Layout.cs at correct location
- ✓ New method in ExtensionBridgeService follows established pattern

### JavaScript Code Verification
- ✓ Message handler correctly placed in socket.onmessage
- ✓ Promise.allSettled pattern for tab communication
- ✓ Error handling with .catch() for silent failures
- ✓ window.addEventListener pattern for message routing
- ✓ Custom event dispatch with correct syntax
- ✓ Console logging for diagnostics
- ✓ Error handling in handleOccupiedSlotsNotification
- ✓ Window-scoped storage for slot data

## Testing Recommendations

1. **Unit Tests**: Verify notification serialization and signature generation
2. **Integration Tests**: Test message flow from WPF → extension → tabs
3. **Layout Tests**: Verify layout engines receive and process slot data
4. **Performance Tests**: Ensure deduplication prevents message spam
5. **Error Tests**: Verify graceful handling when tabs lack content scripts
6. **E2E Tests**: Test "Abrir Todos", "Agrupar", "Fixar Layout" operations

## Build Information
- Framework: .NET/C# for WPF
- Extension: Chrome/Edge WebExtension API (JavaScript)
- Protocol: WebSocket (127.0.0.1:45151)
- Message Format: JSON
- Compatibility: Works with existing bridge infrastructure
- Patterns: Follows established ExtensionBridgeService patterns

