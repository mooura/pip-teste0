# Documentação do projeto

Esta pasta mantém documentação e evidências fora da raiz executável.

- `consolidation/`: decisões, manifestos e resultados das fases de consolidação.
- `stabilization/`: baseline estável, limites entre camadas, inventário e recibo do arquivo histórico.

Esses arquivos apoiam auditoria e desenvolvimento. O runtime do PiPManager não depende deles; apenas os verificadores estruturais consultam os manifestos necessários.
