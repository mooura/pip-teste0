'use strict';

const fs = require('fs');
const path = require('path');
const vm = require('vm');

function assert(condition, message) {
  if (!condition) throw new Error(`TEST FAILED: ${message}`);
}

const root = path.join(__dirname, '..', '..');
const content = fs.readFileSync(path.join(root, 'src', 'PiPManager.Extension', 'content.js'), 'utf8');
const background = fs.readFileSync(path.join(root, 'src', 'PiPManager.Extension', 'background.js'), 'utf8');
const main = fs.readFileSync(path.join(root, 'src', 'PiPManager.Wpf', 'MainWindow.xaml.cs'), 'utf8');
const release = fs.readFileSync(path.join(root, 'src', 'PiPManager.Wpf', 'Services', 'ReleaseInfoService.cs'), 'utf8');
const runner = fs.readFileSync(path.join(root, 'RUN_CORE_TESTS.bat'), 'utf8');
const manifest = JSON.parse(fs.readFileSync(path.join(root, 'src', 'PiPManager.Extension', 'manifest.json'), 'utf8'));

assert(manifest.version === '1.4.39.25', 'manifest must be 1.4.39.25');
assert(release.includes('ExtensionVersion = "1.4.39.25"'), 'release metadata must be synchronized');
assert(content.includes("CONTENT_VERSION = '1.4.39.25-command-target-root-guard-hotfix10'"), 'content hotfix identifier must be synchronized');
assert(background.includes("BRIDGE_VERSION = '1.4.39.25-command-target-root-guard-hotfix10'"), 'background hotfix identifier must be synchronized');
assert(content.includes('function tryNavigateAuthoritativeNextTarget('), 'authoritative direct-next fallback must exist');
assert(content.includes('resolved-target-url:'), 'resolved target URL navigation method must exist');
assert(content.includes('generic-up-next-url:'), 'generic Up Next navigation method must exist');
assert(content.includes('function findGenericUpNextElement('), 'generic Up Next discovery must exist');
assert(content.includes('const NEXT_TARGET_TRANSIENT_RETRY_DELAYS_MS = Object.freeze([300, 600, 900])'), 'bounded target retries must be 300/600/900 ms');
assert(content.includes('function markNextTargetTransientlyResolving('), 'transient target state must exist');
assert(content.includes("markNextTargetTransientlyResolving('playlist-not-detected')"), 'playlist-not-detected must enter transient recovery');
assert(content.includes('reason}-retrying') || content.includes('`${reason}-retrying`'), 'transient playlist retry state must exist');
assert(content.includes('let pipManagerLastResolvedNextTarget = null'), 'last safe resolved target must be retained');
assert(content.includes("previewState: 'RESOLVING_TARGET'"), 'Hotfix 3 must clear stale preview while retrying');
assert(content.includes('scheduleNextTargetTransientRetries(resolving.generation, resolving.resolutionIdentity, reason)'), 'transient recovery must schedule bounded retries');
assert(content.includes("window.addEventListener('pagehide'") && content.includes('cancelNextTargetTransientRetries();'), 'navigation must cancel transient retries');
assert(main.includes('string.Equals(tab.NextTargetStatus, "TARGET_RESOLVED"'), 'WPF preview must still require an authoritative resolved target');
assert(main.includes('resolverBlocksSameVideoFallback'), 'Phase 3 AutoReturn guard must remain active');
assert(runner.includes('next-preview-recovery-hotfix1.test.js'), 'hotfix regression test must be wired');

// Exercise the production authoritative-navigation helper with an already resolved target.
const helperStart = content.indexOf('function normalizeCandidateUrl(');
const helperEnd = content.indexOf('function tryAdvanceUrlIndex(', helperStart);
assert(helperStart >= 0 && helperEnd > helperStart, 'hotfix navigation helper region must be found');
const currentAsset = 'aaaaaaaaaaaaaaaaaaaaaaaa';
const nextAsset = 'bbbbbbbbbbbbbbbbbbbbbbbb';
const navigationContext = vm.createContext({
  URL,
  String,
  location: { href: `https://pmvhaven.com/video/current_${currentAsset}`, origin: 'https://pmvhaven.com' },
  pipManagerNextTargetState: {
    status: 'TARGET_RESOLVED',
    currentAssetId: currentAsset,
    nextAssetId: nextAsset,
    pageUrl: `https://pmvhaven.com/video/next_${nextAsset}`,
    title: 'Next'
  },
  getCurrentMediaIdentity() { return { assetId: currentAsset }; },
  extractMediaAssetId(value) { return String(value || '').match(/[a-f0-9]{24}/i)?.[0] || ''; },
  findNextVideoPageUrl(_node, assetId) { return `https://pmvhaven.com/video/next_${assetId}`; },
  getPipManagerSiteProfile() { return { id: 'generic-player', upNextLabels: ['up next'] }; },
  normalizeText(value) { return String(value || '').toLowerCase(); },
  isVisible() { return true; },
  document: { querySelectorAll() { return []; } },
  reportVideoState() {}
});
vm.runInContext(`${content.slice(helperStart, helperEnd)}\nthis.hotfix = { tryNavigateAuthoritativeNextTarget };`, navigationContext);
const navigationResult = navigationContext.hotfix.tryNavigateAuthoritativeNextTarget(null, { match: 'test' }, { id: 'generic-player' });
assert(navigationResult?.ok === true, 'resolved target navigation must succeed');
assert(String(navigationResult.method).startsWith('resolved-target-url:'), 'resolved target URL must be preferred');
assert(navigationContext.location.href.includes(nextAsset), 'navigation must use the authoritative next asset URL');

console.log('Next + preview recovery Hotfix 1 tests: OK');
