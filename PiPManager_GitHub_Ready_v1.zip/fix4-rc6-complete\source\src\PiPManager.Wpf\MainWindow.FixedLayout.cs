﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using PiPManager.Wpf.Models;
using PiPManager.Core.Automation;
using PiPManager.Wpf.Services;

namespace PiPManager.Wpf;

public partial class MainWindow
{
    private const int FixedLayoutSlotVerifyFirstMs = 280;
    private const int FixedLayoutSlotVerifyFinalMs = 1050;
    private const int FixedLayoutWindowRespectPollMs = 250;
    private const int FixedLayoutWindowActivationSettleMs = 120;
    // A reserva usa limites visuais DWM. Margem zero faz a janela comum terminar
    // exatamente onde o primeiro PiP começa, como a borda da área útil do Windows.
    private const int FixedLayoutReservedMarginPx = 0;
    private const int FixedLayoutGeometryTolerancePx = 3;
    private const int FixedLayoutRecoveryQuietMs = 450;
    private const int FixedLayoutRecoveryTimeoutMs = 45_000;

    private bool _fixedCustomLayoutEnabled;
    private bool _respectFixedLayoutAreaEnabled;
    private readonly List<NativeRect> _fixedSlotLayoutRects = [];
    private readonly GroupTransformEngine _groupTransformEngine = new();
    private RelativeGroupLayout? _relativeFixedLayout;
    private readonly Dictionary<int, int> _fixedSlotApplyGenerationBySlot = [];
    private readonly Dictionary<IntPtr, ManagedWindowRestoreState> _fixedLayoutManagedWindows = [];
    private DispatcherTimer? _fixedLayoutRespectTimer;
    private NativeRect _fixedLayoutPrimaryFreeRect;
    private IntPtr _fixedLayoutObservedForeground = IntPtr.Zero;
    private DateTime _fixedLayoutObservedForegroundSinceUtc = DateTime.MinValue;
    private bool _fixedLayoutRespectSuspendedForHidden;
    private int _fixedLayoutAuthorityGeneration;
    private bool _fixedLayoutRecoveryCycleActive;
    private DateTime _fixedLayoutRecoveryStartedUtc = DateTime.MinValue;
    private readonly HashSet<int> _fixedLayoutRecoveryExpectedSlots = [];
    private readonly HashSet<int> _fixedLayoutRecoveryRecoveredSlots = [];
    private CancellationTokenSource? _fixedLayoutRecoverySettleCts;
    private int _fixedLayoutRecoveryGeneration;
    private CancellationTokenSource? _fixedAspectReflowCts;
    private int _fixedAspectReflowGeneration;
    private readonly HashSet<int> _fixedAspectReflowPendingSlots = [];
    private const int FixedLayoutExternalResizeEchoTolerancePx = 2;
    private readonly Dictionary<IntPtr, FixedLayoutResizeEchoState> _fixedLayoutResizeEchoByHwnd = [];

    private sealed record ManagedWindowRestoreState(NativeRect VisualRect, bool WasMaximized);
    private sealed record FixedLayoutResizeEchoState(
        int SlotNumber,
        NativeRect NaturalRect,
        NativeRect PreviousAuthorityRect,
        int FirstObservedLayoutGeneration,
        DateTime FirstObservedUtc);

    private void InitializeFixedLayoutFeature()
    {
        _fixedCustomLayoutEnabled = _settings.FixedCustomLayoutEnabled;
        // Campo legado mantido apenas para compatibilidade de configuração.
        // A autoridade do layout fixo é exclusiva dos HWNDs PiP vinculados.
        _respectFixedLayoutAreaEnabled = false;

        _fixedSlotLayoutRects.Clear();
        _relativeFixedLayout = _settings.RelativeFixedLayout;
        if (_groupTransformEngine.IsComplete(_relativeFixedLayout, Slots.Count))
        {
            MaterializeRelativeFixedAuthority("initialize-relative");
        }
        else
        {
            var storedAuthority = _settings.FixedSlotLayout
                .Take(Slots.Count)
                .Select(item => item.ToRect())
                .ToArray();
            if (storedAuthority.Length == Slots.Count && storedAuthority.All(rect => rect.IsValid))
            {
                _fixedSlotLayoutRects.AddRange(storedAuthority);
                CaptureRelativeFixedAuthority("initialize-migrate-absolute");
            }
        }

        _fixedLayoutRespectTimer = new DispatcherTimer(DispatcherPriority.Background)
        {
            Interval = TimeSpan.FromMilliseconds(FixedLayoutWindowRespectPollMs)
        };
        _fixedLayoutRespectTimer.Tick += (_, _) => FixedLayoutRespectTimerTick();

        UpdateFixedLayoutFreeArea("initialize");
        UpdateFixedLayoutUi();
    }

    private void ActivateLoadedFixedLayout()
    {
        if (!_fixedCustomLayoutEnabled)
        {
            UpdateFixedLayoutUi();
            return;
        }

        EnsureCustomLayoutModeForFixed();
        _respectFixedLayoutAreaEnabled = false;

        // O molde relativo persistido é a autoridade. Ao carregar, apenas o
        // materializamos no monitor atual; não reconstruímos a topologia.
        if (_groupTransformEngine.IsComplete(_relativeFixedLayout, Slots.Count))
            MaterializeRelativeFixedAuthority("loaded-relative");
        else
            RecordFixedLayoutAuthority("loaded-legacy-fallback");
        ApplyFixedLayoutToAllActive("loaded");

        _fixedLayoutObservedForeground = IntPtr.Zero;
        _fixedLayoutObservedForegroundSinceUtc = DateTime.MinValue;
        _fixedLayoutRespectTimer?.Start();
        FixedLayoutRespectTimerTick();

        UpdateFixedLayoutUi();
    }

    private bool HasCompleteFixedLayoutAuthority() =>
        _groupTransformEngine.IsComplete(_relativeFixedLayout, Slots.Count)
        && _fixedSlotLayoutRects.Count == Slots.Count
        && _fixedSlotLayoutRects.All(rect => rect.IsValid);

    private void CaptureRelativeFixedAuthority(string source)
    {
        if (_fixedSlotLayoutRects.Count == 0)
            return;

        var bySlot = _fixedSlotLayoutRects
            .Take(Slots.Count)
            .Select((rect, index) => (SlotNumber: index + 1, Rect: rect))
            .Where(item => item.Rect.IsValid)
            .ToDictionary(item => item.SlotNumber, item => item.Rect);
        if (bySlot.Count != Slots.Count)
            return;

        _relativeFixedLayout = _groupTransformEngine.Capture(
            bySlot,
            GetSelectedLayoutMonitor()?.DeviceName ?? _settings.LayoutMonitorDeviceName,
            dpiScale: 1.0);
        AppLogger.Info(
            $"relative-layout-template-captured: source={source}; anchor={_relativeFixedLayout.AnchorX},{_relativeFixedLayout.AnchorY}; " +
            $"slots={_relativeFixedLayout.Slots.Count}; monitor={_relativeFixedLayout.MonitorDeviceName}");
    }

    private void MaterializeRelativeFixedAuthority(string source)
    {
        if (!_groupTransformEngine.IsComplete(_relativeFixedLayout, Slots.Count))
            return;

        var area = GetSelectedLayoutMonitor()?.WorkArea ?? PipWindowService.GetVirtualScreenBounds();
        var materialized = _groupTransformEngine.Materialize(_relativeFixedLayout, area);
        if (materialized.Count != Slots.Count)
            return;

        _fixedSlotLayoutRects.Clear();
        _fixedSlotLayoutRects.AddRange(Enumerable.Range(1, Slots.Count).Select(number => materialized[number]));

        // Se a âncora precisou ser limitada ao monitor, a nova posição passa a ser
        // a autoridade persistida sem alterar nenhum offset ou tamanho do molde.
        CaptureRelativeFixedAuthority(source + "/clamped");
        AppLogger.Info($"relative-layout-template-materialized: source={source}; bounds={FormatRect(GetBounds(_fixedSlotLayoutRects))}");
    }

    private void MoveRelativeFixedAuthorityToSelectedMonitor(string source)
    {
        if (!_groupTransformEngine.IsComplete(_relativeFixedLayout, Slots.Count))
        {
            RecordFixedLayoutAuthority(source + "/fallback");
            return;
        }

        var monitor = GetSelectedLayoutMonitor();
        var anchor = GetMonitorLayoutAnchor(monitor, Slots.Count);
        _relativeFixedLayout!.AnchorX = anchor.Left;
        _relativeFixedLayout.AnchorY = anchor.Top;
        _relativeFixedLayout.MonitorDeviceName = monitor?.DeviceName ?? string.Empty;
        MaterializeRelativeFixedAuthority(source);
        UpdateFixedLayoutFreeArea(source);
        SaveSettings();
    }

    private bool TryGetFixedSlotRect(int slotNumber, out NativeRect rect)
    {
        rect = default;
        if (!_fixedCustomLayoutEnabled || slotNumber < 1 || slotNumber > _fixedSlotLayoutRects.Count)
            return false;

        rect = _fixedSlotLayoutRects[slotNumber - 1];
        return rect.IsValid;
    }

    private NativeRect ResolveReconnectGeometryTarget(PipSlot slot, NativeRect fallback)
        => TryGetFixedSlotRect(slot.Number, out var fixedRect) ? fixedRect : fallback;

    private void FixedCustomLayoutMenuItem_Click(object sender, RoutedEventArgs e)
    {
        var enabled = FixedCustomLayoutMenuItem.IsChecked == true;
        if (enabled)
        {
            EnsureCustomLayoutModeForFixed();
            _fixedCustomLayoutEnabled = true;
            ClearAllFixedLayoutExternalResizeEchoes("fixed-layout-enabled");
            _respectFixedLayoutAreaEnabled = false;
            _fixedLayoutObservedForeground = IntPtr.Zero;
            _fixedLayoutObservedForegroundSinceUtc = DateTime.MinValue;
            _fixedLayoutRespectTimer?.Start();

            // Fixar captura o desenho atual como molde relativo. Não desloca nem
            // redimensiona os PiPs no momento em que a opção é ativada.
            if (!TryCaptureCurrentFixedLayoutWithoutMoving("menu-enable"))
                RecordFixedLayoutAuthority("menu-enable-fallback");
            FixedLayoutRespectTimerTick();

            SetStatus(HasCompleteFixedLayoutAuthority()
                ? "Layout fixo ativo somente para os PiPs"
                : "Layout fixo ativo; aguardando uma geometria válida dos slots");
        }
        else
        {
            _fixedCustomLayoutEnabled = false;
            ClearAllFixedLayoutExternalResizeEchoes("fixed-layout-disabled");
            _respectFixedLayoutAreaEnabled = false;
            _fixedLayoutRespectTimer?.Stop();
            RestoreManagedWindows("fixed-layout-disabled");
            SetStatus("Layout fixo desativado: PiPs voltaram ao comportamento normal");
        }

        SaveSettings();
        UpdateFixedLayoutUi();
        AppLogger.Info(
            $"fixed-layout-toggle: enabled={_fixedCustomLayoutEnabled}; pipOnly=True; externalWindowsManaged=False; " +
            $"slots={_fixedSlotLayoutRects.Count}; freeRect={FormatRect(_fixedLayoutPrimaryFreeRect)}");
    }

    private void EnsureCustomLayoutModeForFixed()
    {
        // O perfil Jogo continua sendo a autoridade de topologia mesmo quando
        // "Fixar layout" está ativo. Converter silenciosamente para Custom fazia
        // Igualar e o fiscalizador periódico usarem um molde antigo/incompatível.
        if (CurrentLayout == LayoutMode.Jogo)
        {
            _customLayoutActive = false;
            UpdatePanelSlotVisuals();
            RefreshLayoutText();
            return;
        }

        _customLayoutActive = true;
        _settings.LayoutMode = LayoutMode.Custom;
        UpdateJogoSpaceHideHotkeyRegistration("fixed-layout-enter-custom");
        BuildCustomSlotOverlay(forceReset: EditableSlots.Count != Slots.Count);
        UpdatePanelSlotVisuals();
        RefreshLayoutText();
    }

    private bool TryCaptureCurrentFixedLayoutWithoutMoving(string source)
    {
        if (Slots.Count == 0)
            return false;

        EnsureSlotLayoutRects();
        var bySlot = new Dictionary<int, NativeRect>();
        foreach (var slot in Slots.OrderBy(item => item.Number))
        {
            var rect = slot.Window is not null && PipWindowService.IsUsable(slot.Window.Handle)
                ? PipWindowService.GetVisualRect(slot.Window.Handle)
                : default;
            if (!rect.IsValid && slot.Number <= _fixedSlotLayoutRects.Count)
                rect = _fixedSlotLayoutRects[slot.Number - 1];
            if (!rect.IsValid && slot.Number <= _slotLayoutRects.Count)
                rect = _slotLayoutRects[slot.Number - 1];
            if (!rect.IsValid)
                return false;
            bySlot[slot.Number] = rect;
        }

        _relativeFixedLayout = _groupTransformEngine.Capture(
            bySlot,
            GetSelectedLayoutMonitor()?.DeviceName ?? _settings.LayoutMonitorDeviceName,
            dpiScale: 1.0);
        _fixedSlotLayoutRects.Clear();
        _fixedSlotLayoutRects.AddRange(Enumerable.Range(1, Slots.Count).Select(number => bySlot[number]));
        _fixedCustomLayoutEnabled = true;
        _respectFixedLayoutAreaEnabled = false;
        _fixedLayoutAuthorityGeneration++;
        UpdateFixedLayoutFreeArea(source);
        SaveSettings();
        AppLogger.Info(
            $"fixed-layout-captured-without-moving: source={source}; generation={_fixedLayoutAuthorityGeneration}; " +
            $"slots={bySlot.Count}; anchor={_relativeFixedLayout.AnchorX},{_relativeFixedLayout.AnchorY}; " +
            $"bounds={FormatRect(GetBounds(_fixedSlotLayoutRects))}");
        return true;
    }

    private void CommitJogoTargetsAsFixedAuthority(
        IReadOnlyList<PipSlot> occupied,
        IReadOnlyList<NativeRect> targets,
        string source)
    {
        if (!_fixedCustomLayoutEnabled
            || CurrentLayout != LayoutMode.Jogo
            || occupied.Count == 0
            || occupied.Count != targets.Count)
            return;

        EnsureSlotLayoutRects();
        var complete = new NativeRect[Slots.Count];

        for (var index = 0; index < complete.Length; index++)
        {
            var existing = index < _fixedSlotLayoutRects.Count
                ? _fixedSlotLayoutRects[index]
                : default;
            if (!existing.IsValid && index < _slotLayoutRects.Count)
                existing = _slotLayoutRects[index];

            var slot = Slots.FirstOrDefault(item => item.Number == index + 1);
            if (!existing.IsValid
                && slot?.Window is not null
                && PipWindowService.IsUsable(slot.Window.Handle))
            {
                existing = PipWindowService.GetVisualRect(slot.Window.Handle);
            }

            complete[index] = existing;
        }

        for (var index = 0; index < occupied.Count; index++)
        {
            var slotNumber = occupied[index].Number;
            if (slotNumber < 1 || slotNumber > complete.Length || !targets[index].IsValid)
                continue;
            complete[slotNumber - 1] = targets[index];
        }

        if (complete.Any(rect => !rect.IsValid))
        {
            AppLogger.Warn(
                $"jogo-fixed-authority-commit-skipped: source={source}; " +
                $"reason=incomplete-authority; valid={complete.Count(rect => rect.IsValid)}/{complete.Length}");
            return;
        }

        _fixedSlotLayoutRects.Clear();
        _fixedSlotLayoutRects.AddRange(complete);
        CaptureRelativeFixedAuthority(source + "/jogo-profile");
        _fixedLayoutAuthorityGeneration++;
        UpdateFixedLayoutFreeArea(source);
        SaveSettings();
        AppLogger.Info(
            $"jogo-fixed-authority-committed: source={source}; generation={_fixedLayoutAuthorityGeneration}; " +
            $"slots={occupied.Count}; bounds={FormatRect(GetBounds(_fixedSlotLayoutRects))}; " +
            "singleAuthority=True; aspectAuthority=intrinsic-video");
    }

    private void RecordFixedLayoutAuthority(string source, NativeRect? forcedUniformSize = null)
    {
        if (Slots.Count == 0)
            return;

        // No perfil Jogo, nunca reconstrua uma grade uniforme a partir do overlay
        // Custom. O desenho atual/Jogo é capturado como autoridade única.
        if (CurrentLayout == LayoutMode.Jogo)
        {
            if (!TryCaptureCurrentFixedLayoutWithoutMoving(source + "/jogo-current"))
            {
                AppLogger.Warn(
                    $"fixed-layout-authority-record-deferred: source={source}; profile=Jogo; " +
                    "reason=current-geometry-incomplete");
            }
            return;
        }

        EnsureCustomLayoutModeForFixed();
        EnsureSlotLayoutRects();

        var exact = Slots
            .OrderBy(slot => slot.Number)
            .Select(slot => slot.Window is not null && PipWindowService.IsUsable(slot.Window.Handle)
                ? PipWindowService.GetVisualRect(slot.Window.Handle)
                : default)
            .ToArray();

        var templateRects = new List<NativeRect>(Slots.Count);
        for (var index = 0; index < Slots.Count; index++)
        {
            var template = exact.ElementAtOrDefault(index);
            if (!template.IsValid && index < _fixedSlotLayoutRects.Count)
                template = _fixedSlotLayoutRects[index];
            if (!template.IsValid && index < _slotLayoutRects.Count)
                template = _slotLayoutRects[index];
            if (!template.IsValid)
                template = CreateDefaultSlotLayout(Slots.Count).ElementAtOrDefault(index);
            templateRects.Add(template);
        }

        var sizeCandidates = exact.Where(rect => rect.IsValid)
            .Concat(_fixedSlotLayoutRects.Where(rect => rect.IsValid))
            .Concat(_slotLayoutRects.Where(rect => rect.IsValid))
            .ToArray();

        NativeRect explicitReference = default;
        if (forcedUniformSize is { } forced && forced.IsValid)
            explicitReference = forced;

        var uniformWidth = explicitReference.IsValid
            ? explicitReference.Width
            : MedianOrDefault(sizeCandidates.Select(rect => rect.Width), 260);
        var uniformHeight = explicitReference.IsValid
            ? explicitReference.Height
            : MedianOrDefault(sizeCandidates.Select(rect => rect.Height), 150);

        uniformWidth = Math.Max(120, uniformWidth);
        uniformHeight = Math.Max(72, uniformHeight);

        var topologyRects = EditableSlots.Count >= Slots.Count
            ? EditableSlots
                .Take(Slots.Count)
                .Select(slot => new NativeRect(
                    (int)Math.Round(slot.Left),
                    (int)Math.Round(slot.Top),
                    (int)Math.Round(slot.Left + slot.Width),
                    (int)Math.Round(slot.Top + slot.Height)))
                .ToList()
            : templateRects;

        var occupiedBounds = GetBounds(exact.Where(rect => rect.IsValid).ToArray());
        var templateBounds = GetBounds(templateRects);
        var anchor = occupiedBounds.IsValid
            ? occupiedBounds
            : templateBounds.IsValid
                ? templateBounds
                : _lastKnownGroupBounds.IsValid
                    ? _lastKnownGroupBounds
                    : GetMonitorLayoutAnchor(GetSelectedLayoutMonitor(), Slots.Count);

        var authority = BuildUniformFixedLayoutTargets(topologyRects, uniformWidth, uniformHeight, anchor);
        authority = ClampAuthorityToSelectedMonitor(authority);

        if (authority.Count != Slots.Count || authority.Any(rect => !rect.IsValid))
        {
            AppLogger.Warn($"fixed-layout-authority-record-failed: source={source}; slots={Slots.Count}; generated={authority.Count}");
            return;
        }

        _fixedSlotLayoutRects.Clear();
        _fixedSlotLayoutRects.AddRange(authority);
        CaptureRelativeFixedAuthority(source);
        _fixedCustomLayoutEnabled = true;
        _respectFixedLayoutAreaEnabled = false;
        _fixedLayoutAuthorityGeneration++;
        UpdateFixedLayoutFreeArea(source);
        SaveSettings();

        var appliedUniform = _fixedSlotLayoutRects.FirstOrDefault(rect => rect.IsValid);
        AppLogger.Info(
            $"fixed-layout-authority-recorded: source={source}; generation={_fixedLayoutAuthorityGeneration}; " +
            $"slots={_fixedSlotLayoutRects.Count}; requestedUniform={uniformWidth}x{uniformHeight}; " +
            $"appliedUniform={appliedUniform.Width}x{appliedUniform.Height}; " +
            $"bounds={FormatRect(GetBounds(_fixedSlotLayoutRects))}; freeRect={FormatRect(_fixedLayoutPrimaryFreeRect)}");
    }

    private List<NativeRect> BuildUniformFixedLayoutTargets(
        IReadOnlyList<NativeRect> templateRects,
        int requestedWidth,
        int requestedHeight,
        NativeRect anchor)
    {
        if (templateRects.Count == 0)
            return [];

        var items = templateRects
            .Select((rect, index) => new TemplateLayoutItem(
                new Rect(rect.Left, rect.Top, Math.Max(1, rect.Width), Math.Max(1, rect.Height)),
                requestedWidth,
                requestedHeight,
                index))
            .ToArray();

        var rowIndexes = BuildClusterIndexes(items, vertical: true);
        var colIndexes = BuildClusterIndexes(items, vertical: false);
        var rowCount = rowIndexes.Length == 0 ? 0 : rowIndexes.Max() + 1;
        var colCount = colIndexes.Length == 0 ? 0 : colIndexes.Max() + 1;
        if (rowCount <= 0 || colCount <= 0)
            return [];

        var monitor = GetSelectedLayoutMonitor();
        var workArea = monitor?.WorkArea ?? PipWindowService.GetVirtualScreenBounds();
        const int margin = 8;
        var availableWidth = Math.Max(120, workArea.Width - (margin * 2));
        var availableHeight = Math.Max(72, workArea.Height - (margin * 2));

        var width = Math.Max(120, requestedWidth);
        var height = Math.Max(72, requestedHeight);
        for (var attempt = 0; attempt < 4; attempt++)
        {
            var totalWidth = ((Math.Max(0, colCount - 1)) * StepSize(width)) + width;
            var totalHeight = ((Math.Max(0, rowCount - 1)) * StepSize(height)) + height;
            if (totalWidth <= availableWidth && totalHeight <= availableHeight)
                break;

            var scale = Math.Min(
                availableWidth / (double)Math.Max(1, totalWidth),
                availableHeight / (double)Math.Max(1, totalHeight));
            if (scale >= 0.999)
                break;

            width = Math.Max(120, (int)Math.Floor(width * scale));
            height = Math.Max(72, (int)Math.Floor(height * scale));
        }

        var compactWidth = ((Math.Max(0, colCount - 1)) * StepSize(width)) + width;
        var compactHeight = ((Math.Max(0, rowCount - 1)) * StepSize(height)) + height;
        var minLeft = workArea.Left + margin;
        var minTop = workArea.Top + margin;
        var maxLeft = Math.Max(minLeft, workArea.Right - margin - compactWidth);
        var maxTop = Math.Max(minTop, workArea.Bottom - margin - compactHeight);
        var baseLeft = Math.Clamp(anchor.Left, minLeft, maxLeft);
        var baseTop = Math.Clamp(anchor.Top, minTop, maxTop);

        var targets = new NativeRect[items.Length];
        for (var index = 0; index < items.Length; index++)
        {
            var left = baseLeft + (colIndexes[index] * StepSize(width));
            var top = baseTop + (rowIndexes[index] * StepSize(height));
            targets[items[index].Index] = new NativeRect(left, top, left + width, top + height);
        }

        return _groupTransformEngine.EnsureSingleConnectedMosaic(targets, workArea).ToList();
    }

    private static int MedianOrDefault(IEnumerable<int> values, int fallback)
    {
        var ordered = values.Where(value => value > 5).OrderBy(value => value).ToArray();
        return ordered.Length == 0 ? fallback : ordered[ordered.Length / 2];
    }

    private List<NativeRect> ClampAuthorityToSelectedMonitor(IReadOnlyList<NativeRect> source)
    {
        var valid = source.Where(rect => rect.IsValid).ToList();
        if (valid.Count == 0)
            return source.ToList();

        var monitor = GetSelectedLayoutMonitor();
        var area = monitor?.WorkArea ?? PipWindowService.GetVirtualScreenBounds();
        var bounds = GetBounds(valid);
        if (!bounds.IsValid || !area.IsValid)
            return source.ToList();

        const int margin = 8;
        var dx = 0;
        var dy = 0;

        if (bounds.Width <= area.Width - (margin * 2))
        {
            if (bounds.Left < area.Left + margin) dx = area.Left + margin - bounds.Left;
            if (bounds.Right + dx > area.Right - margin) dx += area.Right - margin - (bounds.Right + dx);
        }
        else
        {
            dx = area.Left + margin - bounds.Left;
        }

        if (bounds.Height <= area.Height - (margin * 2))
        {
            if (bounds.Top < area.Top + margin) dy = area.Top + margin - bounds.Top;
            if (bounds.Bottom + dy > area.Bottom - margin) dy += area.Bottom - margin - (bounds.Bottom + dy);
        }
        else
        {
            dy = area.Top + margin - bounds.Top;
        }

        return source
            .Select(rect => ClampRectInsideWorkArea(rect.Offset(dx, dy), area, margin))
            .ToList();
    }

    private static NativeRect ClampRectInsideWorkArea(NativeRect rect, NativeRect area, int margin)
    {
        if (!rect.IsValid || !area.IsValid)
            return rect;

        var availableWidth = Math.Max(1, area.Width - (margin * 2));
        var availableHeight = Math.Max(1, area.Height - (margin * 2));
        var width = Math.Min(rect.Width, availableWidth);
        var height = Math.Min(rect.Height, availableHeight);
        var minLeft = area.Left + margin;
        var minTop = area.Top + margin;
        var maxLeft = Math.Max(minLeft, area.Right - margin - width);
        var maxTop = Math.Max(minTop, area.Bottom - margin - height);
        var left = Math.Clamp(rect.Left, minLeft, maxLeft);
        var top = Math.Clamp(rect.Top, minTop, maxTop);
        return new NativeRect(left, top, left + width, top + height);
    }

    private void ApplyFixedLayoutToAllActive(string source, bool resizeToTargets = false)
    {
        if (!_fixedCustomLayoutEnabled || !HasCompleteFixedLayoutAuthority() || _allHidden)
            return;
        if (_fixedLayoutRecoveryCycleActive && !source.StartsWith("recovery-cycle-final", StringComparison.OrdinalIgnoreCase))
        {
            AppLogger.Info($"fixed-layout-group-apply-deferred: source={source}; recoveryGeneration={_fixedLayoutRecoveryGeneration}");
            return;
        }

        var occupied = GetOccupiedSlotsInNumberOrder()
            .Where(slot => slot.Window is not null && PipWindowService.IsUsable(slot.Window.Handle))
            .ToArray();
        if (occupied.Length == 0)
            return;

        if (CurrentLayout == LayoutMode.Jogo)
        {
            var naturalRects = occupied
                .Select(slot => PipWindowService.GetVisualRect(slot.Window!.Handle))
                .ToArray();
            if (naturalRects.Any(rect => !rect.IsValid))
                return;

            var workArea = GetSelectedLayoutMonitor()?.WorkArea
                ?? PipWindowService.GetVirtualScreenBounds();
            var jogoTargets = BuildJogoContentAwareTargets(
                    occupied,
                    naturalRects,
                    workArea)
                .ToArray();
            if (jogoTargets.Length != occupied.Length || jogoTargets.Any(rect => !rect.IsValid))
                return;

            var mustResize = resizeToTargets || TargetsRequireResize(naturalRects, jogoTargets);
            ApplyTargetsToOccupiedSlots(occupied, jogoTargets, mustResize);
            CommitJogoTargetsAsFixedAuthority(occupied, jogoTargets, source);
            SaveLockedGroupModel(occupied, jogoTargets);
            _lastKnownGroupBounds = GetBounds(jogoTargets);
            RefreshPipDragTargets();
            SaveSettings();
            AppLogger.Info(
                $"fixed-layout-applied-all: source={source}; windows={occupied.Length}; " +
                $"bounds={FormatRect(_lastKnownGroupBounds)}; resize={mustResize}; " +
                $"sizesPreserved={!mustResize}; profile=Jogo; singleAuthority=True");
            return;
        }

        var requestedBySlot = occupied.ToDictionary(
            slot => slot.Number,
            slot =>
            {
                var authority = _fixedSlotLayoutRects[slot.Number - 1];
                if (resizeToTargets)
                    return authority;
                var natural = PipWindowService.GetVisualRect(slot.Window!.Handle);
                return natural.IsValid
                    ? new NativeRect(authority.Left, authority.Top, authority.Left + natural.Width, authority.Top + natural.Height)
                    : authority;
            });
        var arrangedBySlot = resizeToTargets
            ? requestedBySlot
            : _groupTransformEngine.ReflowNaturalSizesAsConnectedMosaic(
                requestedBySlot,
                requestedBySlot.Keys,
                GetSelectedLayoutMonitor()?.WorkArea ?? PipWindowService.GetVirtualScreenBounds());
        var targets = occupied.Select(slot => arrangedBySlot[slot.Number]).ToArray();

        ApplyTargetsToOccupiedSlots(occupied, targets, resizeToTargets);
        for (var index = 0; index < occupied.Length; index++)
            _fixedSlotLayoutRects[occupied[index].Number - 1] = targets[index];
        CaptureRelativeFixedAuthority(source + (resizeToTargets ? "/explicit-resize" : "/natural-size"));
        SaveLockedGroupModel(occupied, targets);
        _lastKnownGroupBounds = GetBounds(targets);
        RefreshPipDragTargets();
        SaveSettings();
        AppLogger.Info($"fixed-layout-applied-all: source={source}; windows={occupied.Length}; bounds={FormatRect(_lastKnownGroupBounds)}; resize={resizeToTargets}; sizesPreserved={!resizeToTargets}");
    }

    private void QueueFixedAspectGroupReflow(IEnumerable<int> resizedSlots, string source)
    {
        if (!_fixedCustomLayoutEnabled || _allHidden)
            return;

        foreach (var number in resizedSlots.Where(number => number >= 1 && number <= Slots.Count))
            _fixedAspectReflowPendingSlots.Add(number);
        if (_fixedAspectReflowPendingSlots.Count == 0)
            return;

        _fixedAspectReflowCts?.Cancel();
        _fixedAspectReflowCts?.Dispose();
        var cts = new CancellationTokenSource();
        _fixedAspectReflowCts = cts;
        var generation = ++_fixedAspectReflowGeneration;
        var slotList = string.Join(",", _fixedAspectReflowPendingSlots.Order());
        AppLogger.Info(
            $"fixed-aspect-group-reflow-queued: generation={generation}; source={source}; " +
            $"slots={slotList}; debounceMs={MixedAspectReflowDebounceMs}");
        _ = ApplyFixedAspectGroupReflowAsync(generation, source, cts);
    }

    private async Task ApplyFixedAspectGroupReflowAsync(
        int generation,
        string source,
        CancellationTokenSource cts)
    {
        try
        {
            await Task.Delay(MixedAspectReflowDebounceMs, cts.Token);
            await Dispatcher.InvokeAsync(() =>
            {
                if (cts.IsCancellationRequested || generation != _fixedAspectReflowGeneration
                    || !_fixedCustomLayoutEnabled || _allHidden)
                    return;
                if (_fixedLayoutRecoveryCycleActive)
                {
                    AppLogger.Info(
                        $"fixed-aspect-group-reflow-deferred: generation={generation}; source={source}; " +
                        $"recoveryGeneration={_fixedLayoutRecoveryGeneration}");
                    return;
                }

                var changedSlots = _fixedAspectReflowPendingSlots.Order().ToArray();
                var authority = Enumerable.Range(1, _fixedSlotLayoutRects.Count)
                    .ToDictionary(number => number, number => _fixedSlotLayoutRects[number - 1]);

                foreach (var slotNumber in changedSlots)
                {
                    var slot = Slots.FirstOrDefault(item => item.Number == slotNumber);
                    if (slot?.Window is null || !PipWindowService.IsUsable(slot.Window.Handle)
                        || !authority.TryGetValue(slotNumber, out var target))
                        continue;

                    var actual = PipWindowService.GetVisualRect(slot.Window.Handle);
                    if (!actual.IsValid)
                        continue;

                    var targetRatio = target.Width / (double)Math.Max(1, target.Height);
                    var actualRatio = actual.Width / (double)Math.Max(1, actual.Height);
                    if (Math.Abs(targetRatio - actualRatio) < 0.12)
                        continue;

                    authority[slotNumber] = new NativeRect(
                        target.Left,
                        target.Top,
                        target.Left + actual.Width,
                        target.Top + actual.Height);
                }

                ReplaceFixedAuthorityAfterAspectChange(authority, changedSlots, source + "/aspect-change");
                ApplyFixedLayoutToAllActive("fixed-aspect-reflow-final");
                foreach (var slotNumber in changedSlots)
                    _fixedAspectReflowPendingSlots.Remove(slotNumber);
                SyncEditableSlotStates();
                PositionToolbar();
                AppLogger.Info(
                    $"fixed-aspect-group-reflow-applied: generation={generation}; source={source}; " +
                    $"slots={string.Join(",", changedSlots)}; bounds={FormatRect(GetBounds(_fixedSlotLayoutRects))}; " +
                    "batchAppliedOnce=True; overlapFree=True");
            }, DispatcherPriority.Background);
        }
        catch (TaskCanceledException)
        {
            AppLogger.Info($"fixed-aspect-group-reflow-cancelled: generation={generation}; source={source}");
        }
        finally
        {
            if (ReferenceEquals(_fixedAspectReflowCts, cts))
            {
                _fixedAspectReflowCts = null;
                cts.Dispose();
            }
        }
    }

    private bool ReplaceFixedAuthorityAfterAspectChange(
        IReadOnlyDictionary<int, NativeRect> authority,
        IReadOnlyCollection<int> changedSlots,
        string source)
    {
        var workArea = GetSelectedLayoutMonitor()?.WorkArea ?? PipWindowService.GetVirtualScreenBounds();
        var repaired = _groupTransformEngine.ReflowNaturalSizesAsConnectedMosaic(authority, changedSlots, workArea);
        if (repaired.Count != Slots.Count)
            return false;

        var ordered = Enumerable.Range(1, Slots.Count).Select(number => repaired[number]).ToArray();
        if (!ordered.Where((rect, index) => rect != _fixedSlotLayoutRects[index]).Any())
            return false;

        _fixedSlotLayoutRects.Clear();
        _fixedSlotLayoutRects.AddRange(ordered);
        CaptureRelativeFixedAuthority(source);
        _fixedLayoutAuthorityGeneration++;
        UpdateFixedLayoutFreeArea(source);
        SaveSettings();
        AppLogger.Info(
            $"fixed-layout-aspect-authority-updated: source={source}; generation={_fixedLayoutAuthorityGeneration}; " +
            $"changedSlots={string.Join(',', changedSlots.Order())}; bounds={FormatRect(GetBounds(_fixedSlotLayoutRects))}; " +
            "unaffectedSlotsPreserved=True; exactSeams=True");
        return true;
    }

    private bool EnsureFixedLayoutAuthorityNonOverlapping(string source)
    {
        if (_fixedSlotLayoutRects.Count != Slots.Count || _fixedSlotLayoutRects.Any(rect => !rect.IsValid))
            return false;

        var authority = Enumerable.Range(1, Slots.Count)
            .ToDictionary(number => number, number => _fixedSlotLayoutRects[number - 1]);
        return ReplaceFixedAuthorityWithNonOverlapping(authority, source);
    }

    private bool ReplaceFixedAuthorityWithNonOverlapping(
        IReadOnlyDictionary<int, NativeRect> authority,
        string source)
    {
        var workArea = GetSelectedLayoutMonitor()?.WorkArea ?? PipWindowService.GetVirtualScreenBounds();
        var repaired = _groupTransformEngine.ReflowWithoutOverlap(authority, workArea);
        if (repaired.Count != Slots.Count)
            return false;

        var ordered = Enumerable.Range(1, Slots.Count).Select(number => repaired[number]).ToArray();
        var changed = ordered.Where((rect, index) => rect != _fixedSlotLayoutRects[index]).Any();
        if (!changed)
            return false;

        _fixedSlotLayoutRects.Clear();
        _fixedSlotLayoutRects.AddRange(ordered);
        CaptureRelativeFixedAuthority(source);
        _fixedLayoutAuthorityGeneration++;
        UpdateFixedLayoutFreeArea(source);
        SaveSettings();
        AppLogger.Info(
            $"fixed-layout-overlap-repaired: source={source}; generation={_fixedLayoutAuthorityGeneration}; " +
            $"bounds={FormatRect(GetBounds(_fixedSlotLayoutRects))}; exactSeams=True");
        return true;
    }

    private void QueueApplyFixedSlotGeometry(PipSlot slot, string source)
    {
        if (!_fixedCustomLayoutEnabled || slot.Window is null || slot.IsHidden || _allHidden)
            return;
        if (!TryGetFixedSlotRect(slot.Number, out var target))
            return;

        if (_fixedLayoutRecoveryCycleActive && _fixedLayoutRecoveryExpectedSlots.Contains(slot.Number))
        {
            if (_fixedLayoutRecoveryRecoveredSlots.Contains(slot.Number))
            {
                AppLogger.InfoAggregated(
                    $"fixed-layout-recovery-slot-already-stable:{slot.Number}",
                    TimeSpan.FromSeconds(2),
                    $"fixed-layout-recovery-slot-skipped: generation={_fixedLayoutRecoveryGeneration}; source={source}; " +
                    $"slot={slot.Number}; reason=already-recovered");
                return;
            }
            ApplyFixedSlotGeometryOnceDuringRecovery(slot, source);
            NotifyFixedLayoutRecoverySlotActive(slot.Number, source);
            return;
        }

        // MarkSlotActive pode ser chamado por monitores periodicos mesmo quando o
        // PiP ja esta exatamente na posicao autorizada. Evite criar uma sequencia
        // assincrona de tres verificacoes para um no-op.
        var currentRect = PipWindowService.GetVisualRect(slot.Window.Handle);
        if (currentRect.IsValid
            && Math.Abs(currentRect.Left - target.Left) <= FixedLayoutGeometryTolerancePx
            && Math.Abs(currentRect.Top - target.Top) <= FixedLayoutGeometryTolerancePx)
        {
            return;
        }

        var generation = _fixedSlotApplyGenerationBySlot.TryGetValue(slot.Number, out var current)
            ? current + 1
            : 1;
        _fixedSlotApplyGenerationBySlot[slot.Number] = generation;
        var handle = slot.Window.Handle;
        _ = ApplyFixedSlotGeometrySequenceAsync(slot.Number, handle, generation, source);
    }

    private async Task ApplyFixedSlotGeometrySequenceAsync(int slotNumber, IntPtr handle, int generation, string source)
    {
        try
        {
            await Dispatcher.InvokeAsync(() => ApplyFixedSlotGeometryNow(slotNumber, handle, generation, source, "immediate"));
            await Task.Delay(FixedLayoutSlotVerifyFirstMs);
            await Dispatcher.InvokeAsync(() => ApplyFixedSlotGeometryNow(slotNumber, handle, generation, source, $"verify-{FixedLayoutSlotVerifyFirstMs}ms"));
            await Task.Delay(FixedLayoutSlotVerifyFinalMs);
            await Dispatcher.InvokeAsync(() => ApplyFixedSlotGeometryNow(slotNumber, handle, generation, source, $"verify-{FixedLayoutSlotVerifyFirstMs + FixedLayoutSlotVerifyFinalMs}ms"));
        }
        catch (Exception ex)
        {
            AppLogger.Error($"Falha ao aplicar geometria fixa no slot {slotNumber}; source={source}", ex);
        }
    }

    private void ApplyFixedSlotGeometryNow(int slotNumber, IntPtr handle, int generation, string source, string phase)
    {
        if (!_fixedCustomLayoutEnabled || _allHidden)
            return;
        if (!_fixedSlotApplyGenerationBySlot.TryGetValue(slotNumber, out var activeGeneration) || activeGeneration != generation)
            return;
        if (!TryGetFixedSlotRect(slotNumber, out var target))
            return;

        if (_manualResizeCandidateHandle == handle)
        {
            AppLogger.InfoAggregated(
                $"fixed-layout-slot-manual-gesture:{slotNumber}",
                TimeSpan.FromSeconds(2),
                $"fixed-layout-slot-apply-skipped: slot={slotNumber}; source={source}; phase={phase}; reason=manual-pip-gesture-active");
            return;
        }

        // Enquanto a nova proporção natural está em estabilização, não imponha a
        // altura antiga. Isso elimina o ciclo antigo: autoridade -> navegador ->
        // autoridade, que deformava e expandia o grupo repetidamente.
        if (_fixedAspectReflowPendingSlots.Contains(slotNumber))
        {
            AppLogger.InfoAggregated(
                $"fixed-layout-slot-aspect-pending:{slotNumber}",
                TimeSpan.FromSeconds(2),
                $"fixed-layout-slot-apply-skipped: slot={slotNumber}; source={source}; phase={phase}; reason=natural-aspect-stabilizing");
            return;
        }

        var slot = Slots.FirstOrDefault(item => item.Number == slotNumber);
        if (slot?.Window is null || slot.Window.Handle != handle || !PipWindowService.IsUsable(handle) || slot.IsHidden)
            return;

        var before = PipWindowService.GetVisualRect(handle);
        var changed = !before.IsValid
            || Math.Abs(before.Left - target.Left) > FixedLayoutGeometryTolerancePx
            || Math.Abs(before.Top - target.Top) > FixedLayoutGeometryTolerancePx;
        if (!changed)
            return;

        _windowEventFlowControl.ArmInternalMovementSuppression(
            [handle],
            generation,
            TimeSpan.FromMilliseconds(1800),
            "fixed-layout-slot-authority");
        PipWindowService.MoveVisual(handle, target.Left, target.Top);

        var after = PipWindowService.GetVisualRect(handle);
        if (after.IsValid)
            slot.RefreshWindow(slot.Window with { VisualRect = after });

        AppLogger.Info(
            $"fixed-layout-slot-applied: phase={phase}; source={source}; slot={slotNumber}; " +
            $"hwnd=0x{handle.ToInt64():X}; changed=True; target={FormatRect(target)}; " +
            $"before={FormatRect(before)}; after={FormatRect(after)}; resize=False; sizesPreserved=True");
    }

    private static bool RectsEqualWithinTolerance(NativeRect left, NativeRect right, int tolerance)
    {
        if (!left.IsValid || !right.IsValid)
            return false;
        return Math.Abs(left.Left - right.Left) <= tolerance
            && Math.Abs(left.Top - right.Top) <= tolerance
            && Math.Abs(left.Width - right.Width) <= tolerance
            && Math.Abs(left.Height - right.Height) <= tolerance;
    }

    private static bool PositionsEqualWithinTolerance(NativeRect left, NativeRect right, int tolerance)
    {
        if (!left.IsValid || !right.IsValid)
            return false;
        return Math.Abs(left.Left - right.Left) <= tolerance
            && Math.Abs(left.Top - right.Top) <= tolerance;
    }

    private bool ShouldSuppressFixedLayoutExternalResizeEcho(
        PipSlot slot,
        NativeRect currentRect,
        NativeRect previousAuthorityRect)
    {
        if (!_fixedCustomLayoutEnabled || slot.Window is null || !currentRect.IsValid)
            return false;

        var handle = slot.Window.Handle;
        var manualGestureActive = handle == _manualResizeCandidateHandle
            && _manualResizeCandidateStartRect.IsValid
            && (Math.Abs(currentRect.Width - _manualResizeCandidateStartRect.Width) > LayoutMoveSizeTolerancePx
                || Math.Abs(currentRect.Height - _manualResizeCandidateStartRect.Height) > LayoutMoveSizeTolerancePx);

        if (manualGestureActive)
        {
            ClearFixedLayoutExternalResizeEcho(handle, "native-manual-resize-active");
            AppLogger.InfoAggregated(
                $"fixed-layout-manual-resize-observed:{handle.ToInt64():X}",
                TimeSpan.FromSeconds(2),
                $"fixed-layout-external-size-manual-gesture-observed: slot={slot.Number}; " +
                $"hwnd=0x{handle.ToInt64():X}; rect={FormatRect(currentRect)}; " +
                "reflowQueued=False; authorityCommittedOnMouseUp=True");
            return true;
        }

        if (_fixedLayoutResizeEchoByHwnd.TryGetValue(handle, out var state)
            && state.SlotNumber == slot.Number
            && RectsEqualWithinTolerance(
                currentRect,
                state.NaturalRect,
                FixedLayoutExternalResizeEchoTolerancePx))
        {
            AppLogger.InfoAggregated(
                $"fixed-layout-external-size-echo:{handle.ToInt64():X}:{state.FirstObservedLayoutGeneration}",
                TimeSpan.FromSeconds(3),
                $"fixed-layout-external-size-echo-ignored: slot={slot.Number}; hwnd=0x{handle.ToInt64():X}; " +
                $"rect={FormatRect(currentRect)}; previousAuthority={FormatRect(previousAuthorityRect)}; " +
                $"firstAuthority={FormatRect(state.PreviousAuthorityRect)}; " +
                $"firstObservedGeneration={state.FirstObservedLayoutGeneration}; " +
                $"currentGeneration={_layoutTransactionGeneration}; " +
                $"ageMs={(int)Math.Max(0, (DateTime.UtcNow - state.FirstObservedUtc).TotalMilliseconds)}; " +
                $"tolerancePx={FixedLayoutExternalResizeEchoTolerancePx}; " +
                "manualGestureActive=False; reflowQueued=False");
            return true;
        }

        _fixedLayoutResizeEchoByHwnd[handle] = new FixedLayoutResizeEchoState(
            slot.Number,
            currentRect,
            previousAuthorityRect,
            _layoutTransactionGeneration,
            DateTime.UtcNow);
        AppLogger.Info(
            $"fixed-layout-external-size-observation-recorded: slot={slot.Number}; hwnd=0x{handle.ToInt64():X}; " +
            $"naturalRect={FormatRect(currentRect)}; previousAuthority={FormatRect(previousAuthorityRect)}; " +
            $"layoutGeneration={_layoutTransactionGeneration}; reflowQueued=True");
        return false;
    }

    private void ClearFixedLayoutExternalResizeEcho(IntPtr handle, string source)
    {
        if (handle == IntPtr.Zero)
            return;
        if (_fixedLayoutResizeEchoByHwnd.Remove(handle))
            AppLogger.Info($"fixed-layout-external-size-echo-cleared: hwnd=0x{handle.ToInt64():X}; source={source}");
    }

    private void ClearAllFixedLayoutExternalResizeEchoes(string source)
    {
        var removed = _fixedLayoutResizeEchoByHwnd.Count;
        _fixedLayoutResizeEchoByHwnd.Clear();
        if (removed > 0)
            AppLogger.Info($"fixed-layout-external-size-echo-cache-cleared: source={source}; removed={removed}");
    }

    private void SetFixedSlotAuthorityRect(int slotNumber, NativeRect rect, string source)
    {
        if (!_fixedCustomLayoutEnabled || !rect.IsValid || slotNumber < 1 || slotNumber > Slots.Count)
            return;

        while (_fixedSlotLayoutRects.Count < Slots.Count)
            _fixedSlotLayoutRects.Add(default);

        var monitor = GetSelectedLayoutMonitor();
        var workArea = monitor?.WorkArea ?? PipWindowService.GetVirtualScreenBounds();
        var clamped = ClampRectInsideWorkArea(rect, workArea, margin: 8);
        _fixedSlotLayoutRects[slotNumber - 1] = clamped;
        CaptureRelativeFixedAuthority(source);
        _fixedLayoutAuthorityGeneration++;
        UpdateFixedLayoutFreeArea(source);
        SaveSettings();
        AppLogger.Info($"fixed-layout-slot-authority-updated: source={source}; slot={slotNumber}; rect={FormatRect(clamped)}; generation={_fixedLayoutAuthorityGeneration}");
    }

    private void CommitManualFixedSlotResize(int slotNumber, NativeRect actualRect)
    {
        if (!_fixedCustomLayoutEnabled || !actualRect.IsValid || !TryGetFixedSlotRect(slotNumber, out var current))
            return;

        if (CurrentLayout == LayoutMode.Jogo)
        {
            AppLogger.Info(
                $"jogo-fixed-manual-resize-reference-only: slot={slotNumber}; actual={FormatRect(actualRect)}; " +
                "authority=native-border-reference; otherSlotsChanged=False; equalizeOnDemand=True");
            return;
        }

        var authority = Enumerable.Range(1, _fixedSlotLayoutRects.Count)
            .ToDictionary(number => number, number => _fixedSlotLayoutRects[number - 1]);
        authority[slotNumber] = new NativeRect(
            current.Left,
            current.Top,
            current.Left + actualRect.Width,
            current.Top + actualRect.Height);

        ReplaceFixedAuthorityAfterAspectChange(authority, [slotNumber], "manual-pip-resize");
        ApplyFixedLayoutToAllActive("manual-pip-resize");
    }

    private void OffsetFixedSlotAuthority(int dx, int dy, string source)
    {
        if (!_fixedCustomLayoutEnabled || (dx == 0 && dy == 0) || _fixedSlotLayoutRects.Count == 0)
            return;

        if (CurrentLayout == LayoutMode.Jogo)
        {
            AppLogger.Info(
                $"fixed-layout-authority-offset-ignored: source={source}; dx={dx}; dy={dy}; " +
                "profile=Jogo; reason=work-area-anchored");
            return;
        }

        if (_groupTransformEngine.IsComplete(_relativeFixedLayout, Slots.Count))
        {
            _relativeFixedLayout = _groupTransformEngine.Translate(_relativeFixedLayout!, dx, dy);
            MaterializeRelativeFixedAuthority(source);
        }
        else
        {
            var shifted = _fixedSlotLayoutRects.Select(rect => rect.Offset(dx, dy)).ToList();
            var clamped = ClampAuthorityToSelectedMonitor(shifted);
            _fixedSlotLayoutRects.Clear();
            _fixedSlotLayoutRects.AddRange(clamped);
            CaptureRelativeFixedAuthority(source);
        }

        _fixedLayoutAuthorityGeneration++;
        UpdateFixedLayoutFreeArea(source);
        SaveSettings();
        AppLogger.Info($"fixed-layout-authority-offset: source={source}; dx={dx}; dy={dy}; generation={_fixedLayoutAuthorityGeneration}; bounds={FormatRect(GetBounds(_fixedSlotLayoutRects))}");
    }

    private void RebuildFixedAuthorityAfterEditorChange(string source)
    {
        if (!_fixedCustomLayoutEnabled)
            return;

        RecordFixedLayoutAuthority(source);
        ApplyFixedLayoutToAllActive(source);
    }

    private void BeginFixedLayoutRecoveryCycle(int lostSlotNumber, string source)
    {
        if (!_fixedCustomLayoutEnabled || !HasCompleteFixedLayoutAuthority())
            return;

        if (!_fixedLayoutRecoveryCycleActive)
        {
            _fixedLayoutRecoveryCycleActive = true;
            _fixedLayoutRecoveryStartedUtc = DateTime.UtcNow;
            _fixedLayoutRecoveryGeneration++;
            _fixedLayoutRecoveryExpectedSlots.Clear();
            _fixedLayoutRecoveryRecoveredSlots.Clear();

            foreach (var slot in Slots.Where(slot =>
                         SlotHasPairRecoverySignal(slot.Number)
                         && IsAutoReturnEnabledForSlot(slot.Number)))
            {
                _fixedLayoutRecoveryExpectedSlots.Add(slot.Number);
                if (slot.Window is not null && PipWindowService.IsUsable(slot.Window.Handle))
                    _fixedLayoutRecoveryRecoveredSlots.Add(slot.Number);
            }
        }

        _fixedLayoutRecoveryExpectedSlots.Add(lostSlotNumber);
        _fixedLayoutRecoveryRecoveredSlots.Remove(lostSlotNumber);
        AppLogger.Info(
            $"fixed-layout-recovery-cycle-started: generation={_fixedLayoutRecoveryGeneration}; source={source}; " +
            $"lostSlot={lostSlotNumber}; expected={string.Join(",", _fixedLayoutRecoveryExpectedSlots.Order())}; " +
            $"alreadyActive={string.Join(",", _fixedLayoutRecoveryRecoveredSlots.Order())}");
        QueueFixedLayoutRecoveryEvaluation(source);
    }

    private void RemapFixedLayoutRecoverySlotsAfterSwap(int firstSlotNumber, int secondSlotNumber, string source)
    {
        if (!_fixedLayoutRecoveryCycleActive || firstSlotNumber == secondSlotNumber)
            return;

        AutoReturnBurstPolicy.RemapSlotMembershipAfterSwap(
            _fixedLayoutRecoveryExpectedSlots,
            _fixedLayoutRecoveryRecoveredSlots,
            firstSlotNumber,
            secondSlotNumber);

        // Revalida pela propriedade atual do slot após a troca. Assim o ciclo
        // acompanha o conteúdo/pareamento movido e não continua esperando o
        // número antigo até o timeout.
        foreach (var slotNumber in _fixedLayoutRecoveryExpectedSlots.ToArray())
        {
            var slot = Slots.FirstOrDefault(item => item.Number == slotNumber);
            if (slot?.Window is not null && PipWindowService.IsUsable(slot.Window.Handle))
                _fixedLayoutRecoveryRecoveredSlots.Add(slotNumber);
            else
                _fixedLayoutRecoveryRecoveredSlots.Remove(slotNumber);
        }

        AppLogger.Info(
            $"fixed-layout-recovery-slot-membership-remapped: generation={_fixedLayoutRecoveryGeneration}; " +
            $"source={source}; first={firstSlotNumber}; second={secondSlotNumber}; " +
            $"expected={string.Join(",", _fixedLayoutRecoveryExpectedSlots.Order())}; " +
            $"recovered={string.Join(",", _fixedLayoutRecoveryRecoveredSlots.Order())}; " +
            "deadlinePreserved=True; globalReflowQueued=False");
        QueueFixedLayoutRecoveryEvaluation(source + "/slot-swap");
    }

    private void ApplyFixedSlotGeometryOnceDuringRecovery(PipSlot slot, string source)
    {
        if (slot.Window is null || slot.IsHidden || !PipWindowService.IsUsable(slot.Window.Handle)
            || !TryGetFixedSlotRect(slot.Number, out var target))
            return;

        var handle = slot.Window.Handle;
        var before = PipWindowService.GetVisualRect(handle);
        if (!before.IsValid
            || Math.Abs(before.Left - target.Left) > FixedLayoutGeometryTolerancePx
            || Math.Abs(before.Top - target.Top) > FixedLayoutGeometryTolerancePx)
        {
            _windowEventFlowControl.ArmInternalMovementSuppression(
                [handle],
                _fixedLayoutRecoveryGeneration,
                TimeSpan.FromMilliseconds(1800),
                "fixed-layout-recovery-slot");
            PipWindowService.MoveVisual(handle, target.Left, target.Top);
        }
        var after = PipWindowService.GetVisualRect(handle);
        if (after.IsValid)
            slot.RefreshWindow(slot.Window with { VisualRect = after });
        AppLogger.Info(
            $"fixed-layout-recovery-slot-placed-once: generation={_fixedLayoutRecoveryGeneration}; source={source}; " +
            $"slot={slot.Number}; hwnd=0x{handle.ToInt64():X}; target={FormatRect(target)}; before={FormatRect(before)}; after={FormatRect(after)}; resize=False; sizesPreserved=True");
    }

    private void NotifyFixedLayoutRecoverySlotActive(int slotNumber, string source)
    {
        if (!_fixedLayoutRecoveryCycleActive || !_fixedLayoutRecoveryExpectedSlots.Contains(slotNumber))
            return;

        _fixedLayoutRecoveryRecoveredSlots.Add(slotNumber);
        AppLogger.Info(
            $"fixed-layout-recovery-slot-active: generation={_fixedLayoutRecoveryGeneration}; source={source}; slot={slotNumber}; " +
            $"recovered={_fixedLayoutRecoveryRecoveredSlots.Count}/{_fixedLayoutRecoveryExpectedSlots.Count}");
        QueueFixedLayoutRecoveryEvaluation(source);
    }

    private void QueueFixedLayoutRecoveryEvaluation(string source)
    {
        if (!_fixedLayoutRecoveryCycleActive)
            return;

        _fixedLayoutRecoverySettleCts?.Cancel();
        _fixedLayoutRecoverySettleCts?.Dispose();
        var cts = new CancellationTokenSource();
        _fixedLayoutRecoverySettleCts = cts;
        var generation = _fixedLayoutRecoveryGeneration;
        _ = EvaluateFixedLayoutRecoveryCycleAsync(generation, source, cts);
    }

    private async Task EvaluateFixedLayoutRecoveryCycleAsync(int generation, string source, CancellationTokenSource cts)
    {
        try
        {
            await Task.Delay(FixedLayoutRecoveryQuietMs, cts.Token);
            await Dispatcher.InvokeAsync(() =>
            {
                if (cts.IsCancellationRequested || !_fixedLayoutRecoveryCycleActive || generation != _fixedLayoutRecoveryGeneration)
                    return;

                foreach (var slotNumber in _fixedLayoutRecoveryExpectedSlots.ToArray())
                {
                    var slot = Slots.FirstOrDefault(item => item.Number == slotNumber);
                    if (slot?.Window is not null && PipWindowService.IsUsable(slot.Window.Handle))
                        _fixedLayoutRecoveryRecoveredSlots.Add(slotNumber);
                    else
                        _fixedLayoutRecoveryRecoveredSlots.Remove(slotNumber);
                }

                var allRecovered = _fixedLayoutRecoveryExpectedSlots.Count > 0
                    && _fixedLayoutRecoveryExpectedSlots.All(_fixedLayoutRecoveryRecoveredSlots.Contains);
                var elapsedMs = (DateTime.UtcNow - _fixedLayoutRecoveryStartedUtc).TotalMilliseconds;
                // Prazo absoluto: uma rajada maior não pode prolongar o bloqueio
                // do layout além dos 45 segundos definidos para a recuperação.
                var recoveryTimeoutMs = FixedLayoutRecoveryTimeoutMs;
                var timedOut = elapsedMs >= recoveryTimeoutMs;
                if (!allRecovered && !timedOut)
                {
                    QueueFixedLayoutRecoveryEvaluation(source + "/waiting");
                    return;
                }

                var expected = string.Join(",", _fixedLayoutRecoveryExpectedSlots.Order());
                var recovered = string.Join(",", _fixedLayoutRecoveryRecoveredSlots.Order());
                _fixedLayoutRecoveryCycleActive = false;
                var completionSource = timedOut
                    ? "recovery-cycle-final-timeout"
                    : "recovery-cycle-final-complete";

                // Cada HWND recuperado já foi colocado uma única vez no seu slot.
                // O lote global antigo movia novamente todos os PiPs e desfazia
                // ajustes manuais ou trocas de slot ocorridas durante a rajada.
                UpdateFixedLayoutFreeArea(completionSource);
                RefreshPipDragTargets();
                SaveSettings();
                AppLogger.Info(
                    $"fixed-layout-recovery-cycle-finalized: generation={generation}; source={source}; " +
                    $"reason={(timedOut ? "timeout" : "all-expected-active")}; elapsedMs={elapsedMs:0}; " +
                    $"timeoutMs={recoveryTimeoutMs}; expected={expected}; recovered={recovered}; " +
                    "batchAppliedOnce=False; globalReflowSuppressed=True; unrelatedSlotsMoved=False; slotGeometryImmutable=True");
                _fixedLayoutRecoveryExpectedSlots.Clear();
                _fixedLayoutRecoveryRecoveredSlots.Clear();
                _fixedLayoutRecoveryStartedUtc = DateTime.MinValue;
                if (_fixedAspectReflowPendingSlots.Count > 0)
                {
                    var suppressedAspectSlots = string.Join(",", _fixedAspectReflowPendingSlots.Order());
                    _fixedAspectReflowPendingSlots.Clear();
                    AppLogger.Info(
                        $"fixed-layout-recovery-pending-aspect-reflow-suppressed: generation={generation}; " +
                        $"slots={suppressedAspectSlots}; reason=fixed-slot-authority-is-immutable");
                }
            }, DispatcherPriority.Background);
        }
        catch (TaskCanceledException)
        {
        }
        finally
        {
            if (ReferenceEquals(_fixedLayoutRecoverySettleCts, cts))
            {
                _fixedLayoutRecoverySettleCts = null;
                cts.Dispose();
            }
        }
    }

    private void UpdateFixedLayoutFreeArea(string source)
    {
        var monitor = GetSelectedLayoutMonitor();
        var workArea = monitor?.WorkArea ?? PipWindowService.GetVirtualScreenBounds();
        _fixedLayoutPrimaryFreeRect = ComputeLargestFreeRectangle(workArea, _fixedSlotLayoutRects);
        AppLogger.Info($"fixed-layout-free-area-updated: source={source}; monitor={monitor?.DeviceName ?? "virtual"}; workArea={FormatRect(workArea)}; reserved={_fixedSlotLayoutRects.Count}; marginPx={FixedLayoutReservedMarginPx}; flushVisualEdge=True; freeRect={FormatRect(_fixedLayoutPrimaryFreeRect)}");
    }

    private static NativeRect ComputeLargestFreeRectangle(NativeRect workArea, IReadOnlyList<NativeRect> reservedRects)
    {
        if (!workArea.IsValid)
            return default;

        var reserved = reservedRects
            .Select(rect => InflateAndClip(rect, FixedLayoutReservedMarginPx, workArea))
            .Where(rect => rect.IsValid)
            .ToArray();
        if (reserved.Length == 0)
            return workArea;

        var xs = new SortedSet<int> { workArea.Left, workArea.Right };
        var ys = new SortedSet<int> { workArea.Top, workArea.Bottom };
        foreach (var rect in reserved)
        {
            xs.Add(rect.Left);
            xs.Add(rect.Right);
            ys.Add(rect.Top);
            ys.Add(rect.Bottom);
        }

        var xValues = xs.ToArray();
        var yValues = ys.ToArray();
        NativeRect best = default;
        long bestArea = 0;
        var bestMinDimension = 0;

        for (var leftIndex = 0; leftIndex < xValues.Length - 1; leftIndex++)
        {
            for (var rightIndex = leftIndex + 1; rightIndex < xValues.Length; rightIndex++)
            {
                var width = xValues[rightIndex] - xValues[leftIndex];
                if (width < 240)
                    continue;

                for (var topIndex = 0; topIndex < yValues.Length - 1; topIndex++)
                {
                    for (var bottomIndex = topIndex + 1; bottomIndex < yValues.Length; bottomIndex++)
                    {
                        var height = yValues[bottomIndex] - yValues[topIndex];
                        if (height < 180)
                            continue;

                        var candidate = new NativeRect(
                            xValues[leftIndex],
                            yValues[topIndex],
                            xValues[rightIndex],
                            yValues[bottomIndex]);
                        if (reserved.Any(candidate.Intersects))
                            continue;

                        var area = (long)candidate.Width * candidate.Height;
                        var minDimension = Math.Min(candidate.Width, candidate.Height);
                        if (area > bestArea || (area == bestArea && minDimension > bestMinDimension))
                        {
                            best = candidate;
                            bestArea = area;
                            bestMinDimension = minDimension;
                        }
                    }
                }
            }
        }

        return best.IsValid ? best : default;
    }

    private static NativeRect InflateAndClip(NativeRect rect, int margin, NativeRect bounds)
    {
        if (!rect.IsValid || !bounds.IsValid || !rect.Intersects(bounds))
            return default;

        return new NativeRect(
            Math.Max(bounds.Left, rect.Left - margin),
            Math.Max(bounds.Top, rect.Top - margin),
            Math.Min(bounds.Right, rect.Right + margin),
            Math.Min(bounds.Bottom, rect.Bottom + margin));
    }

    private void FixedLayoutRespectTimerTick()
    {
        if (!_fixedCustomLayoutEnabled)
            return;

        // "Fixar layout" possui autoridade exclusivamente sobre os HWNDs PiP
        // vinculados aos slots. Aplicativos externos, jogos e navegadores nunca
        // são reposicionados ou redimensionados por esta função.
        if (!_allHidden
            && !IsPipOperationBusy()
            && string.IsNullOrWhiteSpace(_activeAutoReturnAttemptId)
            && !_fixedLayoutRecoveryCycleActive
            && !_naturalAnchorDragActive
            && !IsLayoutTransactionActive()
            && !Win32.IsLeftMouseButtonDown())
        {
            EnforceFixedPipGeometryTick();
        }
    }

    private void EnforceFixedPipGeometryTick()
    {
        if (!HasCompleteFixedLayoutAuthority())
            return;

        foreach (var slot in Slots.Where(slot => slot.Window is not null && !slot.IsHidden))
        {
            var handle = slot.Window!.Handle;
            if (!PipWindowService.IsUsable(handle) || !TryGetFixedSlotRect(slot.Number, out var target))
                continue;

            var current = PipWindowService.GetVisualRect(handle);
            // A aplicação periódica é deliberadamente move-only. Comparar tamanho
            // aqui criava um loop infinito: detectava altura diferente, mas o
            // aplicador nunca redimensionava, então reenfileirava a cada 250 ms.
            if (!PositionsEqualWithinTolerance(current, target, FixedLayoutGeometryTolerancePx))
                QueueApplyFixedSlotGeometry(slot, "fixed-layout-periodic-enforcement");
        }
    }

    private void TryConstrainForegroundWindow(IntPtr hwnd, string source)
    {
        if (!ShouldRespectNormalWindow(hwnd, out var processName, out var title, out var className))
            return;

        var current = Win32.GetWindowVisualRect(hwnd);
        if (!current.IsValid)
            return;

        var monitor = GetSelectedLayoutMonitor();
        var monitorBounds = monitor?.Bounds ?? PipWindowService.GetVirtualScreenBounds();
        if (!monitorBounds.Contains(current.CenterX, current.CenterY))
            return;

        var overlapsReserved = _fixedSlotLayoutRects.Any(rect => rect.IsValid && current.Intersects(rect));
        var isMaximized = Win32.IsZoomed(hwnd);
        if (!overlapsReserved && !isMaximized)
            return;

        var target = _fixedLayoutPrimaryFreeRect;
        if (!target.IsValid || target.Width < 240 || target.Height < 180)
            return;
        if (RectsEqualWithinTolerance(current, target, 4))
            return;

        if (!_fixedLayoutManagedWindows.ContainsKey(hwnd))
            _fixedLayoutManagedWindows[hwnd] = new ManagedWindowRestoreState(current, isMaximized);

        if (isMaximized)
            Win32.ShowWindow(hwnd, 9); // SW_RESTORE

        MoveNormalWindowVisual(hwnd, target);
        var after = Win32.GetWindowVisualRect(hwnd);
        AppLogger.Info(
            $"fixed-layout-window-constrained: source={source}; hwnd=0x{hwnd.ToInt64():X}; process={processName}; " +
            $"class={className}; title={title}; maximized={isMaximized}; overlap={overlapsReserved}; " +
            $"target={FormatRect(target)}; before={FormatRect(current)}; after={FormatRect(after)}");
    }

    private bool ShouldRespectNormalWindow(IntPtr hwnd, out string processName, out string title, out string className)
    {
        processName = string.Empty;
        title = string.Empty;
        className = string.Empty;

        if (hwnd == IntPtr.Zero || !Win32.IsWindow(hwnd) || !Win32.IsWindowVisible(hwnd) || Win32.IsIconic(hwnd))
            return false;
        if (Slots.Any(slot => slot.Window?.Handle == hwnd))
            return false;

        var processId = Win32.GetProcessId(hwnd);
        if (processId <= 0 || processId == Environment.ProcessId)
            return false;

        processName = Win32.GetProcessName(hwnd);
        title = Win32.GetWindowTitle(hwnd);
        className = Win32.GetClass(hwnd);
        if (string.IsNullOrWhiteSpace(title))
            return false;

        if (string.Equals(processName, "explorer.exe", StringComparison.OrdinalIgnoreCase)
            || string.Equals(className, "Shell_TrayWnd", StringComparison.OrdinalIgnoreCase)
            || string.Equals(className, "Progman", StringComparison.OrdinalIgnoreCase)
            || string.Equals(className, "WorkerW", StringComparison.OrdinalIgnoreCase))
            return false;

        if (title.Contains("Picture-in-Picture", StringComparison.OrdinalIgnoreCase)
            || title.Contains("Picture in picture", StringComparison.OrdinalIgnoreCase)
            || string.Equals(className, "MozillaDialogClass", StringComparison.OrdinalIgnoreCase))
            return false;

        var style = Win32.GetWindowLongPtr(hwnd, Win32.GWL_STYLE).ToInt64();
        var exStyle = Win32.GetWindowLongPtr(hwnd, Win32.GWL_EXSTYLE).ToInt64();
        if ((style & Win32.WS_CHILD) != 0 || (exStyle & Win32.WS_EX_TOOLWINDOW) != 0)
            return false;

        var rect = Win32.GetWindowVisualRect(hwnd);
        return rect.IsValid && rect.Width >= 300 && rect.Height >= 180;
    }

    private static void MoveNormalWindowVisual(IntPtr hwnd, NativeRect target)
    {
        var raw = Win32.GetWindowRectActual(hwnd);
        var visual = Win32.GetWindowVisualRect(hwnd);
        if (!raw.IsValid || !visual.IsValid || !target.IsValid)
            return;

        var offsetX = raw.Left - visual.Left;
        var offsetY = raw.Top - visual.Top;
        var extraWidth = Math.Max(0, raw.Width - visual.Width);
        var extraHeight = Math.Max(0, raw.Height - visual.Height);
        _ = Win32.SetWindowPos(
            hwnd,
            IntPtr.Zero,
            target.Left + offsetX,
            target.Top + offsetY,
            Math.Max(240, target.Width + extraWidth),
            Math.Max(180, target.Height + extraHeight),
            Win32.SWP_NOZORDER | Win32.SWP_NOACTIVATE | Win32.SWP_ASYNCWINDOWPOS);
    }

    private void RestoreManagedWindows(string source)
    {
        if (_fixedLayoutManagedWindows.Count == 0)
            return;

        var restored = 0;
        foreach (var item in _fixedLayoutManagedWindows.ToArray())
        {
            var hwnd = item.Key;
            var state = item.Value;
            if (!Win32.IsWindow(hwnd) || !state.VisualRect.IsValid)
                continue;

            Win32.ShowWindow(hwnd, 9); // SW_RESTORE
            MoveNormalWindowVisual(hwnd, state.VisualRect);
            if (state.WasMaximized)
                Win32.ShowWindow(hwnd, 3); // SW_MAXIMIZE
            restored++;
        }

        _fixedLayoutManagedWindows.Clear();
        _fixedLayoutObservedForeground = IntPtr.Zero;
        _fixedLayoutObservedForegroundSinceUtc = DateTime.MinValue;
        AppLogger.Info($"fixed-layout-managed-windows-restored: source={source}; restored={restored}");
    }

    private void StopFixedLayoutFeatureForClosing()
    {
        _fixedLayoutRecoverySettleCts?.Cancel();
        _fixedLayoutRecoverySettleCts?.Dispose();
        _fixedLayoutRespectTimer?.Stop();
        RestoreManagedWindows("app-closing");
    }

    private void UpdateFixedLayoutUi()
    {
        if (FixedCustomLayoutMenuItem is not null)
            FixedCustomLayoutMenuItem.IsChecked = _fixedCustomLayoutEnabled;

        RefreshLayoutText();
    }

    private void RefreshLayoutText()
    {
        if (LayoutText is null)
            return;

        var freeSuffix = CurrentLayout == LayoutMode.Jogo && _jogoFreeAreaEnabled
            ? $" • Livre: {JogoFreeAreaText}"
            : string.Empty;
        var fixedSuffix = _fixedCustomLayoutEnabled ? " • Fixo" : string.Empty;
        LayoutText.Text = CurrentLayout.ToLabel() + freeSuffix + fixedSuffix;
    }
}
