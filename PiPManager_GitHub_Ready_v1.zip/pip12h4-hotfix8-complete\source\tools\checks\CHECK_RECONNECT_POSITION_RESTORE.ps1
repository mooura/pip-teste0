$ErrorActionPreference = "Stop"
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$main = Get-Content -Raw (Join-Path $root "src\PiPManager.Wpf\MainWindow.xaml.cs")
$fixed = Get-Content -Raw (Join-Path $root "src\PiPManager.Wpf\MainWindow.FixedLayout.cs")
$drag = Get-Content -Raw (Join-Path $root "src\PiPManager.Wpf\MainWindow.PipDrag.cs")

$checks = [ordered]@{
  "reconnect geometry helper exists" = $main.Contains('RestoreReconnectedWindowPosition(')
  "restore uses the saved pre-loss rectangle" = $main.Contains('pending.Window.VisualRect.IsValid') -and $main.Contains('return pending.Window.VisualRect')
  "restore enforces position and size" = $main.Contains('PipWindowService.MoveAndResizeVisual(newHandle, referenceRect)') -and $main.Contains('sizePreserved=True; resize=True')
  "oversized fixed target is clamped to previous footprint" = $main.Contains('reconnect-oversized-layout-target-clamped') -and $main.Contains('IsReconnectGeometryOversized')
  "Firefox late geometry changes are verified at bounded checkpoints" = $main.Contains('VerifyReconnectedWindowGeometryAsync') -and $main.Contains('ReconnectGeometryVerifyCheckpointsMs = [0, 150, 400, 900, 1800, 3200, 4200]')
  "delayed verification remains bound to the same slot and HWND" = $main.Contains('slot.Window.Handle != newHandle') -and $main.Contains('slot-or-hwnd-changed')
  "monitor blocks browser-driven size inflation" = $main.Contains('TryEnforceReconnectGeometryAuthority(slot, rect, "Monitor de PiP")') -and $main.Contains('reason=browser-size-inflation-blocked')
  "fixed layout yields during reconnect authority" = $fixed.Contains('reason=reconnect-geometry-authority-active')
  "manual user resize cancels temporary authority" = $drag.Contains('CancelReconnectGeometryAuthority(handle, "manual-resize-committed")')
  "stable capture replacement restores geometry" = $main.Contains('RestoreReconnectedWindowPosition(slot, handle, replacement.Handle, reconnectReference, "CapturePipsStable")')
  "intelligent reconnect restores geometry" = $main.Contains('RestoreReconnectedWindowPosition(slot, oldHandle, replacement.Handle, reconnectReference, $"ApplyIntelligentReconnect/{source}")')
  "monitor reconnect restores geometry" = $main.Contains('RestoreReconnectedWindowPosition(slot, handle, replacement.Handle, reconnectReference, $"TryReconnectSlotWindow/{source}")')
  "prepared AutoReturn capture restores geometry before layout persistence" = $main.Contains('BindSlotNavigationGeometryAuthority(slot, newWindow.Handle, "CapturePreparedPipWindow", preferredAspectRatio)')
}

$failed = @()
foreach ($item in $checks.GetEnumerator()) {
  if ($item.Value) { Write-Host ($item.Key + ": OK") }
  else { Write-Host ($item.Key + ": FAIL"); $failed += $item.Key }
}

if ($failed.Count -gt 0) {
  throw "Reconnect geometry restore checks failed: $($failed -join ', ')"
}

Write-Host "Reconnect geometry restore checks OK."
