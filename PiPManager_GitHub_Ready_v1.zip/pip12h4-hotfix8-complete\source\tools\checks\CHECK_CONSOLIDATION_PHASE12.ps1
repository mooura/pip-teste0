$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path

function Check([string]$label, [bool]$condition) {
    if (-not $condition) { throw "FAIL: $label" }
    Write-Host "$label`: OK"
}

$main = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\MainWindow.xaml.cs') -Raw
$policy = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Core\Core\Automation\AutoAdvanceSafetyPolicy.cs') -Raw
$tests = Get-Content -LiteralPath (Join-Path $root 'tests\PiPManager.Core.Tests\Program.cs') -Raw
$background = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Extension\background.js') -Raw

Check 'manual navigation cancels prior loss-watch generation' ($main.Contains('CancelAutoAdvanceLostPipWatch(slot.Number, $"video-command-{commandText}")'))
Check 'loss watch is suppressed while navigation is active' ($main.Contains('auto-advance-loss-watch-suppressed') -and $policy.Contains('ShouldArmLostPipWatch'))
Check 'late terminal is rejected before and after serialization gate' ($main.Contains('reason=navigation-in-progress-after-gate') -and $policy.Contains('ShouldAcceptPlaybackTerminal'))
Check 'only ended snapshots prove loss-watch terminal' ($policy.Contains('isEnded && !isPlaying'))
Check 'missing or stale snapshots remain observational' ($main.Contains('reason=terminal-not-proven'))
Check 'silent preservation requests fresh same-tab target' ($main.Contains('SendOpenPictureInPictureReacquireAsync') -and $main.Contains('pip-preserve-silent-fresh-target-requested'))
Check 'reacquire remains ambiguity-safe' ($background.Contains("match: 'best-visible-ambiguous'") -and $background.Contains("reason: 'best-visible-ambiguous'"))
Check 'preview telemetry distinguishes CDN frame sequence' ($main.Contains('animationMode=') -and $main.Contains('cdn-frame-sequence') -and $main.Contains('direct-video'))
Check 'core policy regression tests exist' ($tests.Contains('TestAutoAdvanceSafetyPolicy') -and $tests.Contains('loading source gap must not be terminal'))

Write-Host 'Consolidation Phase 12 checks OK.' -ForegroundColor Green
