$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$main = Get-Content (Join-Path $root 'src\PiPManager.Wpf\MainWindow.xaml.cs') -Raw
$xaml = Get-Content (Join-Path $root 'src\PiPManager.Wpf\MainWindow.xaml') -Raw
$checks = [ordered]@{
  'initialization completion guard exists' = $main.Contains('private bool _initializationComplete;')
  'toggle handler ignores initialization events' = $main.Contains('if (!_initializationComplete || _suppressAutomaticCaptureToggleEvents || AutomaticCaptureToggle is null)')
  'programmatic toggle updates are suppressed' = $main.Contains('_suppressAutomaticCaptureToggleEvents = true;') -and $main.Contains('_suppressAutomaticCaptureToggleEvents = false;')
  'settings save is guarded during initialization' = $main.Contains('if (!_initializationComplete)') -and $main.Contains('private void SaveSettings()')
  'initialization completes after settings and UI setup' = $main.Contains('_initializationComplete = true;') -and $main.Contains('UpdateConnectionAndAutomationUx();')
  'toggle still exposes checked and unchecked handlers' = $xaml.Contains('Checked="AutomaticCaptureToggle_Changed"') -and $xaml.Contains('Unchecked="AutomaticCaptureToggle_Changed"')
}
$failed=0
foreach($item in $checks.GetEnumerator()) { if($item.Value){ Write-Host "$($item.Key): OK" } else { Write-Host "$($item.Key): FAIL"; $failed++ } }
if($failed -gt 0){ throw 'Connection Capture UX initialization checks failed.' }
Write-Host 'Connection Capture UX initialization checks OK.'
