# AutoReturn Late Capture + Browser Visibility Focus Fix

This package preserves the Hotfix 9 extension and network Range cache unchanged.

## Runtime issue reproduced

The PiP HWND could be captured by `CapturePreparedPipWindow` immediately before the foreground lease deadline. The timed wait then exited without a final slot read, returned zero, and the AutoReturn operation was cancelled even though the slot already owned the new PiP. Because the success classification was skipped, the expected browser was not minimized and could remain visibly in front.

## Fix

- Re-read the slot once after the timed HWND wait expires.
- Reconcile a usable HWND claimed by the active attempt before either cancellation checkpoint.
- Treat a late captured HWND as a successful focusless capture.
- On a genuine cancellation after the physical shortcut:
  - restore the previous foreground;
  - minimize the browser when the previous foreground was another application;
  - restore only the cloak when the browser itself was previously foreground.

## Expected diagnostics

Successful race reconciliation:

```text
auto-return-monitor-confirmed-post-timeout
auto-return-focusless-late-capture-reconciled
auto-return-browser-minimized-after-confirmation
auto-return-final-result: result=confirmed
```

True cancellation cleanup:

```text
auto-return-cancelled-browser-visibility-cleanup
```

The extension version remains `1.4.39.24-range-network-cap-hotfix9`.
