'use strict';

const fs = require('fs');
const path = require('path');
const vm = require('vm');

function assert(condition, message) {
  if (!condition) throw new Error(`TEST FAILED: ${message}`);
}

const root = path.join(__dirname, '..', '..', 'src', 'PiPManager.Extension');
const content = fs.readFileSync(path.join(root, 'content.js'), 'utf8');
const background = fs.readFileSync(path.join(root, 'background.js'), 'utf8');

assert(content.includes("'2g': 30000"), '2G timeout must be 30 seconds');
assert(content.includes("'3g': 45000"), '3G timeout must be 45 seconds');
assert(content.includes("'4g': 90000"), '4G timeout must be 90 seconds');
assert(content.includes('NEXT_VIDEO_PRELOAD_MAX_RETRIES = 2'), 'preload must have exactly two retries');
assert(content.includes('const baseMs = 900'), 'backoff base must be 900ms');
assert(content.includes('Math.pow(1.5, attempt)'), 'backoff factor must be 1.5');
assert(content.includes('Math.min(delayMs, 5000)'), 'backoff cap must be 5 seconds');
assert(content.includes('new PreloadLRUCache(3)'), 'three-entry preload cache must be active');
assert(content.includes("sendNextPreloadDiagnostic('max-retries-exceeded'"), 'max retry diagnostic must exist');
for (const field of ['networkType', 'timeoutMs', 'backoffMs', 'attempt', 'delayMs', 'bufferedSeconds']) {
  assert(background.includes(`${field}:`), `background must forward ${field}`);
}

// Execute the current production policy helpers rather than duplicating formulas.
const policyStart = content.indexOf('function getNetworkType()');
const policyEnd = content.indexOf('function isNetworkEligibleForPreload()', policyStart);
assert(policyStart >= 0 && policyEnd > policyStart, 'policy source region must be found');
const policyContext = vm.createContext({ navigator: { connection: { effectiveType: '4g' } }, String, Math });
vm.runInContext(`${content.slice(policyStart, policyEnd)}\nthis.policy = { getNetworkType, getAdaptivePreloadTimeout, getExponentialBackoffMs };`, policyContext);
assert(policyContext.policy.getNetworkType() === '4g', 'network type must be read from navigator.connection');
assert(policyContext.policy.getAdaptivePreloadTimeout() === 90000, '4G timeout calculation must be 90000ms');
policyContext.navigator.connection.effectiveType = '3g';
assert(policyContext.policy.getAdaptivePreloadTimeout() === 45000, '3G timeout calculation must be 45000ms');
policyContext.navigator.connection.effectiveType = '2g';
assert(policyContext.policy.getAdaptivePreloadTimeout() === 30000, '2G timeout calculation must be 30000ms');
assert(policyContext.policy.getExponentialBackoffMs(0) === 900, 'first retry delay must be 900ms');
assert(policyContext.policy.getExponentialBackoffMs(1) === 1350, 'second retry delay must be 1350ms');
assert(policyContext.policy.getExponentialBackoffMs(2) === 2025, 'third formula step must be 2025ms');
assert(policyContext.policy.getExponentialBackoffMs(20) === 5000, 'backoff must be capped at 5000ms');

// Execute the production three-entry cache. Re-setting a key promotes it before capacity eviction.
const classStart = content.indexOf('class PreloadLRUCache');
const classEnd = content.indexOf('const pipManagerPreloadCache', classStart);
assert(classStart >= 0 && classEnd > classStart, 'LRU source region must be found');
const lruContext = vm.createContext({ Map });
vm.runInContext(`${content.slice(classStart, classEnd)}\nthis.PreloadLRUCache = PreloadLRUCache;`, lruContext);
const lru = new lruContext.PreloadLRUCache(3);
lru.set('a', { id: 'a' });
lru.set('b', { id: 'b' });
lru.set('c', { id: 'c' });
lru.set('a', { id: 'a2' });
lru.set('d', { id: 'd' });
assert(!lru.has('b'), 'oldest non-refreshed entry must be evicted');
assert(lru.has('a') && lru.get('a').id === 'a2', 'refreshed entry must remain cached');
assert(lru.cache.size === 3, 'cache must retain exactly three entries');

console.log('Adaptive preload policy tests: OK');
