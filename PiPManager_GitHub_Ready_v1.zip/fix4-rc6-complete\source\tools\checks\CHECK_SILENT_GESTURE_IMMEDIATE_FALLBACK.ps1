$ErrorActionPreference = "Stop"
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$main = Get-Content -Raw (Join-Path $root "src\PiPManager.Wpf\MainWindow.xaml.cs")

$checks = [ordered]@{
  "gesture-required is the only immediate silent fallback reason" = $main.Contains('IsSilentReopenImmediateFallbackReason') -and $main.Contains('return string.Equals(reasonCode, "gesture-required"')
  "silent HWND wait accepts a bound abort attempt" = $main.Contains('abortOnSilentFailureAttemptId = null')
  "silent result aborts the active wait" = $main.Contains('auto-return-focusless-hwnd-wait-aborted-by-silent-result')
  "silent attempt id is bound to the 3600ms wait" = $main.Contains('abortOnSilentFailureAttemptId: silentAttemptId')
  "fallback remains the existing discrete path" = $main.Contains('pip-preserve-silent-reopen-fast-fallback') -and $main.Contains('fallback=discrete-immediate')
}

$failed = @()
foreach ($item in $checks.GetEnumerator()) {
  if ($item.Value) { Write-Host ($item.Key + ": OK") }
  else { Write-Host ($item.Key + ": FAIL"); $failed += $item.Key }
}

if ($failed.Count -gt 0) {
  throw "Silent gesture immediate fallback checks failed: $($failed -join ', ')"
}

Write-Host "Silent gesture immediate fallback checks OK."
