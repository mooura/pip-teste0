# Validação local — P0 Optimization RC5

- Estrutura C# verificada por balanceamento de delimitadores.
- Testes JavaScript da extensão executados.
- Gate textual RC5 verifica supressão por HWND, deduplicação de slot já proprietário e preservação de eventos Destroyed.
- Compilação WPF completa deve ser executada no Windows com `BUILD_WINDOWS.bat`.
