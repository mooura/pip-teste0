$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$content = Get-Content -Raw (Join-Path $root 'src\PiPManager.Extension\content.js')
$background = Get-Content -Raw (Join-Path $root 'src\PiPManager.Extension\background.js')
$manifest = Get-Content -Raw (Join-Path $root 'src\PiPManager.Extension\manifest.json') | ConvertFrom-Json
$release = Get-Content -Raw (Join-Path $root 'src\PiPManager.Wpf\Services\ReleaseInfoService.cs')
$runner = Get-Content -Raw (Join-Path $root 'RUN_CORE_TESTS.bat')

$checks = [ordered]@{
  'manifest is 1.4.39.25' = ([string]$manifest.version -eq '1.4.39.25')
  'release metadata is 1.4.39.25' = $release.Contains('ExtensionVersion = "1.4.39.25"')
  'phase identifier is synchronized' = $content.Contains("CONTENT_VERSION = '1.4.39.25-command-target-root-guard-hotfix10'") -and $background.Contains("BRIDGE_VERSION = '1.4.39.25-command-target-root-guard-hotfix10'")
  'next target authority exists' = $content.Contains('let pipManagerNextTargetState = {')
  'resolver separates target identity' = $content.Contains('function buildNextTargetDescriptor(') -and $content.Contains('function publishNextTargetState(')
  'preload consumes only resolved target' = $content.Contains('function startPreloadForResolvedNextTarget()') -and $content.Contains("target.status !== 'TARGET_RESOLVED' || target.nextAssetId !== assetId")
  'current asset cannot be preloaded' = $content.Contains('target.currentAssetId && target.currentAssetId === assetId')
  'arbitrary latest-cache fallback removed' = -not $content.Contains('const latest = Array.from(pipManagerNextFullMediaCache.entries()).pop()')
  'target fields forwarded to app' = $background.Contains('nextTargetStatus') -and $background.Contains('currentAssetId') -and $background.Contains('nextAssetId')
  'node regression test is wired' = $runner.Contains('next-target-resolver-phase2.test.js')
}

$failed = @()
foreach ($item in $checks.GetEnumerator()) {
  if ($item.Value) { Write-Host ($item.Key + ': OK') }
  else { Write-Host ($item.Key + ': FAIL'); $failed += $item.Key }
}
if ($failed.Count -gt 0) { throw ('Next Target Resolver Phase 2 checks failed: ' + ($failed -join ', ')) }
Write-Host 'Next Target Resolver Phase 2 checks OK.'
