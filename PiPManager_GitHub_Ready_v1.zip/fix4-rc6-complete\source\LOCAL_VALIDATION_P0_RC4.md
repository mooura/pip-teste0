# Validação local — P0 Optimization RC4

## Evidência do teste Windows

- nenhum `[ERROR]` foi registrado;
- capturas manuais e AutoReturn terminaram confirmados;
- o reator informou `dropped=0`;
- o motor nativo e o gerenciado mantiveram paridade nos lotes observados;
- os avisos repetidos vinham de slots propositalmente preservados durante a
  recuperação, não de HWND duplicado.

## Validação executada neste ambiente

- reprodução exata do gate que falhou na RC3, agora aprovado;
- verificação da ordem `ShouldPreserveLostSlot` → `lossDebounceReserved` → `preserved.Add`;

- testes JavaScript da extensão;
- verificações estáticas dos blocos P0;
- coerência de produto, aplicativo e extensão;
- integridade do manifesto e do ZIP.

A compilação WPF final e os gates PowerShell devem ser executados no Windows
com `BUILD_WINDOWS.bat`.
