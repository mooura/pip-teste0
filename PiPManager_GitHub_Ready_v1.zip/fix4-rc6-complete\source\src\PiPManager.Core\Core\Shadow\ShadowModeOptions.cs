﻿namespace PiPManager.Core.Shadow;

/// <summary>
/// Opções do Shadow Mode. Por segurança, ExecuteActions deve permanecer false.
/// </summary>
public sealed record ShadowModeOptions
{
    public bool Enabled { get; init; } = true;

    /// <summary>
    /// Deve permanecer false enquanto o novo motor estiver apenas observando.
    /// </summary>
    public bool ExecuteActions { get; init; } = false;

    public bool CaptureDecisions { get; init; } = true;

    public int MaxHistory { get; init; } = 500;
}
