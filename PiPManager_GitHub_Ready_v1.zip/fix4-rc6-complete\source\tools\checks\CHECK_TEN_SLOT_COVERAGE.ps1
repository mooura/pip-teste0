﻿$ErrorActionPreference = "Stop"
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$mainPath = Join-Path $root "src\PiPManager.Wpf\MainWindow.xaml.cs"
$xamlPath = Join-Path $root "src\PiPManager.Wpf\MainWindow.xaml"
$layoutPath = Join-Path $root "src\PiPManager.Wpf\Services\LayoutService.cs"
$settingsPath = Join-Path $root "src\PiPManager.Wpf\Models\AppSettings.cs"

$main = Get-Content -Raw -LiteralPath $mainPath
$xaml = Get-Content -Raw -LiteralPath $xamlPath
$layout = Get-Content -Raw -LiteralPath $layoutPath
$settings = Get-Content -Raw -LiteralPath $settingsPath

$failures = New-Object System.Collections.Generic.List[string]

function Check-Contains([string]$name, [string]$text, [string]$needle) {
    if ($text.Contains($needle)) {
        Write-Host "$name`: OK"
    } else {
        Write-Host "$name`: FAIL"
        $script:failures.Add($name)
    }
}

function Check-True([string]$name, [bool]$condition) {
    if ($condition) {
        Write-Host "$name`: OK"
    } else {
        Write-Host "$name`: FAIL"
        $script:failures.Add($name)
    }
}

Check-Contains "settings slot count persists" $settings "public int SlotCount { get; set; }"
Check-Contains "startup clamps slots to ten" $main "SetSlotCount(Math.Clamp(_settings.SlotCount, 1, 10));"
Check-Contains "slot setter clamps to ten" $main "count = Math.Clamp(count, 1, 10);"
Check-Contains "next free slot grows until ten" $main "if (Slots.Count < 10)"
Check-Contains "next free slot appends one slot" $main "SetSlotCount(Slots.Count + 1);"
Check-True "open all capacity follows the ten-slot collection" ($main.Contains("var slotCapacity = Slots.Count;") -and $main.Contains("var availableCapacity = Math.Max(0, slotCapacity - activeWindowCount);"))
Check-Contains "open all reports ten-slot capacity" $main "maxSlots={slotCapacity}"
Check-Contains "open all processes dynamic pending count" $main "for (var index = 0; index < pending.Count; index++)"
Check-Contains "open all forces next free slot" $main "forceNextFreeSlot: true"
Check-Contains "open all confirms each linked slot" $main "WaitForOpenAllPairConfirmationAsync(current, timeoutMs: 4500)"
Check-Contains "open all does not fail fast on one incompatible source" $main "failFast=False; continueBatch=True"
Check-Contains "open all cleans failed slot before continuing" $main "Abrir todos/ignorar fonte incompatível"
Check-Contains "open all clears disabled stale reservations" $main "open-all-disabled-autoreturn-reservations-cleared"
Check-Contains "prepared open owns new HWND before smart reconnect" $main "smart-reconnect-blocked-by-prepared-open"
Check-Contains "generic reconnect uses open lock rather than volatile armed state" $main "if (!_openPipAttemptInProgress && !_openAllPipsInProgress)"
Check-Contains "open attempt retains exact tab context" $main "_openPipAttemptTab = tab;"
Check-Contains "open attempt records ownership" $main "_openPipAttemptOwner = owner;"
Check-Contains "disabled AutoReturn cleanup preserves user open" $main "IsActiveUserOpenPipAttemptForSlot(slotNumber)"
Check-Contains "prepared state restores from active open lock" $main 'TryRestorePreparedPipStateFromOpenAttempt("reactor-candidate-entry")'
Check-Contains "reactor pre-arm wait retries open lock context" $main 'TryRestorePreparedPipStateFromOpenAttempt("reactor-pre-arm-wait")'
Check-Contains "reactor final capture accepts restored context" $main 'TryRestorePreparedPipStateFromOpenAttempt("reactor-final-capture")'
Check-Contains "legacy timer accepts restored open context" $main 'TryRestorePreparedPipStateFromOpenAttempt("armed-pip-timer")'
Check-Contains "restored context uses proof baseline handles" $main "_autoPairProofExistingHandles.ToHashSet()"
Check-Contains "batch reconnect is blocked during user open" $main "smart-reconnect-batch-blocked-by-prepared-open"
Check-Contains "auto return tick yields to open all" $main "auto-return-deferred-by-open-operation: checkpoint=tick"
Check-Contains "auto return rechecks after physical gate" $main 'DeferAutoReturnForOpenOperation(slot, state, attemptId, "after-physical-gate")'
Check-Contains "open all acquires exclusive physical authority" $main "open-all-physical-authority-acquired"
Check-Contains "open all releases exclusive physical authority" $main "open-all-physical-authority-released"
Check-Contains "ownership checks all slots" $main "!Slots.Any(other => other.Number != slot.Number && other.Window?.Handle == window.Handle)"
Check-Contains "auto return state is keyed by slot" $main "Dictionary<int, AutoReturnSlotState> _autoReturnStatesBySlot"
Check-Contains "auto return setting is keyed by slot" $main "Dictionary<int, bool> _slotAutoReturnDiscreteBySlot"
Check-Contains "saved auto return settings accept slot ten" $main ".Where(item => item.Key >= 1 && item.Key <= 10)"
Check-Contains "horizontal layout uses input count" $layout "new List<NativeRect>(rects.Count)"
Check-Contains "grid rows derive from input count" $layout "Math.Ceiling(rects.Count / 2.0)"
Check-Contains "layout iterates every rect" $layout "for (var i = 0; i < rects.Count; i++)"

for ($i = 1; $i -le 10; $i++) {
    $slotMenuNeedle = 'Tag="{0}" Click="SlotCountMenuItem_Click"' -f $i
    Check-Contains "slot menu exposes $i" $xaml $slotMenuNeedle
}

$openAllStart = $main.IndexOf("private async Task OpenAllDetectedPipsAsync()", [System.StringComparison]::Ordinal)
$openAllEnd = $main.IndexOf("private async Task<PipSlot?> WaitForOpenAllPairConfirmationAsync", [System.StringComparison]::Ordinal)
Check-True "open all method boundaries found" ($openAllStart -ge 0 -and $openAllEnd -gt $openAllStart)
if ($openAllStart -ge 0 -and $openAllEnd -gt $openAllStart) {
    $openAll = $main.Substring($openAllStart, $openAllEnd - $openAllStart)
    Check-True "open all has no five-slot cap" (-not $openAll.Contains("Take(5)"))
    Check-True "open all has no six-slot cap" (-not $openAll.Contains("Take(6)"))
    Check-True "open all has no fixed five-item loop" (-not ($openAll -match "index\s*<\s*5\b"))
    Check-True "open all has no fixed six-item loop" (-not ($openAll -match "index\s*<\s*6\b"))
}

if ($failures.Count -gt 0) {
    throw "Ten-slot coverage checks failed: $($failures -join ', ')"
}

Write-Host "Ten-slot coverage checks OK."
