# Validação local — P0 Optimization RC6

## Base

- Produto: 9.39.03
- Aplicativo: 1.5.12.3909
- Extensão: 1.4.39.7
- Base imediata: P0 Optimization RC5

## Evidência do log

- janela externa `FC26.exe` foi indevidamente classificada para restrição;
- ciclo de recuperação registrou `elapsedMs=101012` e `timeoutMs=101000`;
- houve troca de slot 9 para 5 durante o ciclo;
- no timeout, sete PiPs receberam um lote global move-only.

## Garantias RC6

- timer periódico chama apenas `EnforceFixedPipGeometryTick`;
- configuração legada `RespectFixedLayoutAreaEnabled` é persistida como `false`;
- deadline de recuperação é constante em 45.000 ms;
- troca de slots remapeia expected/recovered;
- finalização não chama `ApplyFixedLayoutToAllActive`;
- pending aspect reflow é suprimido no fechamento do ciclo;
- posição recuperada é aplicada com `resize=False` e `sizesPreserved=True`.

## Limitação do ambiente

Este ambiente não possui .NET SDK, WPF nem PowerShell. A compilação e todos os
checks PowerShell devem ser executados no Windows com `BUILD_WINDOWS.bat`.
