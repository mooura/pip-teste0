'use strict';

const fs = require('fs');
const path = require('path');

function assert(condition, message) {
  if (!condition) throw new Error(`TEST FAILED: ${message}`);
}

const root = path.join(__dirname, '..', '..', 'src', 'PiPManager.Extension');
const background = fs.readFileSync(path.join(root, 'background.js'), 'utf8');
const content = fs.readFileSync(path.join(root, 'content.js'), 'utf8');

assert(background.includes('SESSION_SNAPSHOT_TTL_MS = 30000'), 'session retention must tolerate background-tab throttling');
assert(background.includes('Promise.all(tabs.map'), 'tab discovery must probe tabs in parallel');
assert(background.includes('probeVideoStateFrame'), 'tab discovery must merge direct frame responses');
assert(background.includes('tabDiscoveryDiagnostic'), 'missing tabs must have an explicit diagnostic');
assert(background.includes("requestId: requestId || ''"), 'tab discovery must echo the app correlation id');
assert(background.includes("requestAllVideoStates(String(message.requestId || ''))"), 'snapshot requests must carry the correlation id into discovery');
assert(background.includes('windowId: Number(tab.windowId || 0)'), 'session identity must retain the browser window id');
assert(content.includes("type: 'pipManagerVideoStateResponse'"), 'content script must return sessions directly to the probe');
assert(content.includes('rawVideoCount'), 'probe must distinguish no video from filtered/loading video');

console.log('Extension tab discovery tests: OK');
