$ErrorActionPreference = "Stop"
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$mainPath = Join-Path $root "src\PiPManager.Wpf\MainWindow.xaml.cs"
$runCorePath = Join-Path $root "RUN_CORE_TESTS.bat"
$main = Get-Content $mainPath -Raw
$runCore = Get-Content $runCorePath -Raw
$failed = 0
function Check([string]$name, [bool]$ok) {
  if ($ok) { Write-Host "$name`: OK" } else { Write-Host "$name`: FAIL"; $script:failed++ }
}
Check "diagnostic environment variable" ($main.Contains('PIPMANAGER_DIAGNOSTIC_PREARM_DELAY_MS'))
Check "diagnostic delay is bounded" ($main.Contains('Math.Clamp(parsed, 0, ReactorPreArmDiagnosticDelayMaxMs)'))
Check "diagnostic delay max below grace" ($main.Contains('ReactorPreArmDiagnosticDelayMaxMs = 700') -and $main.Contains('ReactorAssistedPreArmGraceMs = 900'))
Check "normal path arms immediately" ($main.Contains('ArmPreparedPipPair(targetSlot, tab, "manual-open/normal")'))
Check "diagnostic path arms after shortcut" ($main.IndexOf('SendOpenPictureInPictureShortcutToForegroundAsync') -lt $main.IndexOf('ArmPreparedPipPair(targetSlot, tab, "manual-open/diagnostic-delayed")'))
Check "diagnostic marker" ($main.Contains('window-event-reactor-pre-arm-diagnostic-delay'))
Check "prepared-state marker" ($main.Contains('window-event-reactor-prepared-state-armed'))
Check "checker included in core gate" ($runCore.Contains('CHECK_WINDOW_EVENT_REACTOR_PREARM_DIAGNOSTIC.ps1'))
if ($failed -gt 0) { throw "Window Event Reactor pre-arm diagnostic checks failed." }
Write-Host "Window Event Reactor pre-arm diagnostic checks OK."
