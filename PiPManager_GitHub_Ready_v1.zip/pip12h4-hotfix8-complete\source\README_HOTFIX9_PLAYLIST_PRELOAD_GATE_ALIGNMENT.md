# Hotfix 9 — Playlist Preload Gate Alignment

## Motivo

O Hotfix 9 substituiu deliberadamente o preload integral por um elemento `<video>` oculto por um transporte de rede controlado no background da extensão. O checker legado `CHECK_PLAYLIST_CONTEXT_DETECTION.ps1` ainda exigia literalmente `video.preload = 'auto'`, apesar de `CHECK_RANGE_NETWORK_CAP_HOTFIX9.ps1` e o teste de stream já exigirem a arquitetura oposta.

## Alteração

A verificação antiga:

- `next full MP4 is preloaded in Firefox`

foi substituída por:

- `next full media uses range-controlled preload`

O gate agora comprova conjuntamente:

1. resolução da URL completa por `readNuxtFullVideoUrl`;
2. delegação do content script por `pipManagerStartRangePreload`;
3. cabeçalho HTTP `Range` no background;
4. uso de `AbortController`;
5. ausência do preload integral legado `video.preload = 'auto'`.

## Escopo

Nenhum arquivo de runtime, C#, extensão, manifesto ou versão foi alterado. Esta correção modifica somente o checker estático e a documentação. A versão permanece `1.4.39.24-range-network-cap-hotfix9`.
