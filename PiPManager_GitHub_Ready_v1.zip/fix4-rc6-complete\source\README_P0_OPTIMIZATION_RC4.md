# P0 Optimization RC4 — correção do gate e isolamento do arraste

## Origem

A RC3 foi reprovada somente pelo gate estático de estabilidade de layout: o código
usava o campo de tupla `LossDebounceReserved`, enquanto o checker legado procurava
a variável local `lossDebounceReserved` com comparação sensível a maiúsculas.
O comportamento funcional já estava presente. A RC4 torna essa reserva explícita
no código e mantém o gate forte, sem relaxar a validação.


O teste de execução com dez PiPs confirmou que o P0 permaneceu funcional, sem
erros fatais e com o reator processando todos os lotes (`dropped=0`). O log
mostrou, porém, duas fontes remanescentes de pressão:

1. slots com HWND já perdido, preservados corretamente para AutoReturn, ainda
   eram consultados pelo modelo físico do arraste e geravam avisos repetidos de
   retângulo inválido;
2. cada LOCATIONCHANGE filtrado atualizava imediatamente o painel de saúde,
   adquirindo um lock mesmo quando o evento já seria descartado por fluxo ou
   deduplicação.

## Alterações

- o modelo de arraste passa a receber somente slots com HWND utilizável;
- slots perdidos continuam integralmente preservados para AutoReturn;
- referências perdidas são registradas em uma única linha agregada por gesto;
- o diagnóstico de retângulo inválido só examina HWNDs ainda utilizáveis;
- publicação dos totais do WinEvent para o serviço de saúde foi consolidada em
  janelas de 250 ms; os contadores atômicos continuam exatos;
- nenhuma política de captura, pareamento, AutoReturn ou extensão foi alterada.

## Versões

- Produto: `9.39.03`
- Aplicativo: `1.5.12.3907`
- Extensão: `1.4.39.7`
