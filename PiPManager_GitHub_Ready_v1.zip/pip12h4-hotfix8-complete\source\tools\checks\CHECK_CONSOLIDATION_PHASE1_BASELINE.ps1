$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$baselinePath = Join-Path $root 'docs\consolidation\baseline.json'
$notesPath = Join-Path $root 'docs\consolidation\PHASE_01_BASELINE.md'
$failed = 0

function Check($name, $ok) {
  if ($ok) { Write-Host "$name`: OK" }
  else { Write-Host "$name`: FAIL"; $script:failed++ }
}

Check 'baseline manifest exists' (Test-Path $baselinePath)
Check 'baseline documentation exists' (Test-Path $notesPath)

$baseline = Get-Content $baselinePath -Raw | ConvertFrom-Json
$release = Get-Content (Join-Path $root 'src\PiPManager.Wpf\Services\ReleaseInfoService.cs') -Raw
$manifest = Get-Content (Join-Path $root 'src\PiPManager.Extension\manifest.json') -Raw | ConvertFrom-Json
$version = Get-Content (Join-Path $root 'VERSION_STABLE.txt') -Raw
$runner = Get-Content (Join-Path $root 'RUN_CORE_TESTS.bat') -Raw

Check 'baseline phase is one' ($baseline.phase -eq 1)
Check 'product version matches release' ($release.Contains("ProductVersion = `"$($baseline.productVersion)`"") -and $version.Contains("Produto: $($baseline.productVersion)"))
Check 'app version matches release' ($release.Contains("AppVersion = `"$($baseline.appVersion)`"") -and $version.Contains("App: $($baseline.appVersion)"))
Check 'extension version matches manifest and release' ($manifest.version -eq $baseline.extensionVersion -and $release.Contains("ExtensionVersion = `"$($baseline.extensionVersion)`""))
Check 'Firefox extension identity retained' ($manifest.browser_specific_settings.gecko.id -eq 'pip-manager-bridge@local')
Check 'manifest generation recorded' ($manifest.manifest_version -eq $baseline.manifestVersion)
Check 'native compare default recorded' ($version.Contains("Modo padrão: $($baseline.nativeLayoutDefault)"))
Check 'native ABI recorded' ($version.Contains("ABI $($baseline.nativeAbi)"))

$essential = @(
  'src\PiPManager.Wpf\PiPManager.Wpf.csproj',
  'src\PiPManager.Wpf\MainWindow.xaml',
  'src\PiPManager.Wpf\MainWindow.xaml.cs',
  'src\PiPManager.Core\PiPManager.Core.csproj',
  'tests\PiPManager.Core.Tests\PiPManager.Core.Tests.csproj',
  'tests\PiPManager.WindowEventMonitor.Tests\PiPManager.WindowEventMonitor.Tests.csproj',
  'src\PiPManager.Extension\content.js',
  'src\PiPManager.Extension\background.js',
  'src\PiPManager.Native\PiPManager.Native.cpp'
)
Check 'essential baseline files exist' (($essential | Where-Object { -not (Test-Path (Join-Path $root $_)) }).Count -eq 0)

$checks = Get-ChildItem (Join-Path $root 'tools\checks') -Filter 'CHECK_*.ps1' -File | Where-Object { $_.Name -ne 'CHECK_CONSOLIDATION_PHASE1_BASELINE.ps1' }
$missingFromRunner = @($checks | Where-Object { -not $runner.Contains($_.Name) })
Check 'all pre-existing checks remain in core gate' ($missingFromRunner.Count -eq 0)

$notes = Get-Content $notesPath -Raw
foreach ($profile in $baseline.criticalProfiles) {
  Check "profile $profile documented" ($notes.IndexOf($profile, [StringComparison]::OrdinalIgnoreCase) -ge 0)
}
Check 'known limitations documented' ($notes.Contains('Limitações conhecidas'))
Check 'no-regression scenarios documented' ($notes.Contains('Cenários críticos'))

if ($failed -gt 0) { throw 'Consolidation phase 1 baseline checks failed.' }
Write-Host 'Consolidation phase 1 baseline checks OK.'
