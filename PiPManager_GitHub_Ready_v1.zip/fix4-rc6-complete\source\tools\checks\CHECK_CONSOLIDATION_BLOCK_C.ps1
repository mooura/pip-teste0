$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path

function Check([string]$label, [bool]$condition) {
    if (-not $condition) { throw "FAIL: $label" }
    Write-Host "$label`: OK"
}

$main = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\MainWindow.xaml.cs') -Raw
$layout = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\MainWindow.Layout.cs') -Raw
$settings = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\Models\AppSettings.cs') -Raw
$policy = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\Services\RuntimeAuthorityPolicy.cs') -Raw
$coordinator = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\Services\AutomationCoordinator.cs') -Raw
$release = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\Services\ReleaseInfoService.cs') -Raw
$benchmark = Get-Content -LiteralPath (Join-Path $root 'docs\consolidation\native-layout-benchmark.json') -Raw | ConvertFrom-Json
$cleanup = Get-Content -LiteralPath (Join-Path $root 'docs\consolidation\cleanup-manifest.json') -Raw | ConvertFrom-Json
$historyReceipt = Get-Content -LiteralPath (Join-Path $root 'docs\stabilization\history-archive.json') -Raw | ConvertFrom-Json
$runner = Get-Content -LiteralPath (Join-Path $root 'RUN_CORE_TESTS.bat') -Raw

Check 'runtime authority policy exists' (Test-Path -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\Services\RuntimeAuthorityPolicy.cs'))
Check 'authority environment variable has one owner' ($policy.Contains('PIPMANAGER_REACTOR_CAPTURE_MODE'))
Check 'MainWindow delegates authority resolution' ($main.Contains('RuntimeAuthorityPolicy.ResolveWireValue()'))
Check 'Reactor Compare remains safe default' ($policy.Contains('_ => ReactorCaptureMode.Compare'))
Check 'Shadow coordinator remains observe-only' ($coordinator.Contains('public bool ShadowOnly => true'))
Check 'benchmark project exists' (Test-Path -LiteralPath (Join-Path $root 'benchmarks\PiPManager.LayoutBenchmarks\PiPManager.LayoutBenchmarks.csproj'))
Check 'benchmark used ten windows' ([int]$benchmark.scenario.windows -eq 10)
Check 'benchmark used at least 1000 iterations' ([int]$benchmark.scenario.iterations -ge 1000)
Check 'managed p95 is below one millisecond' ([double]$benchmark.managed.P95Ms -lt 1.0)
Check 'native path was not faster in measured scenario' ([double]$benchmark.nativeToManagedRatio -gt 1.0)
Check 'managed layout is new-install default' ($settings.Contains('NativeLayoutEngineMode { get; set; } = "Off"') -and $layout.Contains(': NativeLayoutEngineMode.Off;'))
Check 'release metadata records managed default' ($release.Contains('ManagedLayoutDefault'))
Check 'history documents archived externally' (
    [int]$historyReceipt.archivedFiles -eq [int]$cleanup.archivedHistoryDocuments -and
    [int]$historyReceipt.releaseDocuments -eq [int]$cleanup.movedReleaseDocuments -and
    [string]$historyReceipt.archiveFile -eq [string]$cleanup.historyArchive -and
    [string]$historyReceipt.sha256 -match '^[A-F0-9]{64}$')
Check 'history archive removed from active source' (-not (Test-Path -LiteralPath (Join-Path $root 'HISTORY')))
Check 'no loose release documents remain' (@(Get-ChildItem -LiteralPath $root -File | Where-Object { $_.Name -like 'NOTAS_*' -or $_.Name -like 'RELEASE_NOTES_*' -or $_.Name -like 'VALIDATION_*' }).Count -eq 0)
Check 'obsolete backup directory removed' (-not (Test-Path -LiteralPath (Join-Path $root '_backup')))
$gitignore = Get-Content -LiteralPath (Join-Path $root '.gitignore') -Raw
Check 'generated directories are ignored' ($gitignore.Contains('**/bin/') -and $gitignore.Contains('**/obj/') -and $gitignore.Contains('**/TestResults/') -and $gitignore.Contains('**/publish/'))
Check 'Block C checker runs in gate' ($runner.Contains('CHECK_CONSOLIDATION_BLOCK_C.ps1'))

Write-Host 'Consolidation Block C checks OK.' -ForegroundColor Green
