﻿'use strict';

const CONTENT_VERSION = '1.4.39.7-autoreturn-confirmed-lifetime';

const PIP_MANAGER_SITE_PROFILES = globalThis.PipManagerSiteProfiles.profiles;

function getPipManagerSiteProfile() {
  return globalThis.PipManagerSiteProfiles.getProfile({ location, document });
}

// Identidade dinâmica do site: o nome é sempre lido da própria página visitada,
// nunca de uma tabela fixa de domínios. Serve só para exibição/diagnóstico/cache;
// as decisões de PiP/próximo/anterior continuam vindo das capacidades detectadas.
function getPipManagerSiteIdentity() {
  const readMeta = (selector) => {
    try {
      const el = document.querySelector(selector);
      const value = el && (el.getAttribute('content') || el.getAttribute('href'));
      return value ? String(value).trim() : '';
    } catch (_) {
      return '';
    }
  };

  const domain = String(location.hostname || '').replace(/^www\./i, '').toLowerCase();
  const readableFromDomain = domain ? domain.split('.').slice(0, -1).join('.') || domain : '';

  const candidates = [
    { source: 'application-name', value: readMeta('meta[name="application-name" i]') },
    { source: 'og:site_name', value: readMeta('meta[property="og:site_name" i]') },
    { source: 'title', value: (document.title || '').trim() },
    { source: 'domain', value: readableFromDomain }
  ];

  const best = candidates.find(item => item.value);
  return {
    name: best ? best.value : (domain || 'desconhecido'),
    source: best ? best.source : 'domain',
    domain
  };
}

const PIP_MANAGER_AUXILIARY_HOST_SUFFIXES = [
  'extensions.strpst.com',
  'assets.chapturist.com',
  'happyleafmotion.com',
  'crme7srv.com',
  'rtbsuperhub.com',
  'doubleclick.net',
  'googlesyndication.com',
  'adnxs.com',
  'adsrvr.org'
];

function isPipManagerAuxiliaryContext() {
  try {
    if (window.top === window) return false;
    const host = String(location.hostname || '').replace(/^www\./i, '').toLowerCase();
    if (!host) return false;
    if (PIP_MANAGER_AUXILIARY_HOST_SUFFIXES.some(suffix => host === suffix || host.endsWith(`.${suffix}`)))
      return true;
    return /(^|\.)(ads?|adservice|adserver|creative|promo|banner|rtb|tracking|syndicate)\./i.test(host);
  } catch (_) {
    return false;
  }
}

const PIP_MANAGER_AUXILIARY_CONTEXT = isPipManagerAuxiliaryContext();

const PAGE_INSTANCE_ID = Math.random().toString(36).slice(2, 10);
const ELEMENT_SESSION_PREFIX = `sess-${PAGE_INSTANCE_ID}`;
let ELEMENT_INSTANCE_COUNTER = 0;

function nextElementInstanceId() {
  ELEMENT_INSTANCE_COUNTER += 1;
  return `el-${ELEMENT_INSTANCE_COUNTER.toString(36)}-${Date.now().toString(36)}`;
}

function api() {
  return typeof browser !== 'undefined' ? browser : chrome;
}

function getPipManagerCapabilities() {
  const siteProfile = getPipManagerSiteProfile();
  const siteIdentity = getPipManagerSiteIdentity();
  return {
    ok: true,
    contentVersion: CONTENT_VERSION,
    pageInstanceId: PAGE_INSTANCE_ID,
    url: location.href,
    title: document.title || '',
    domain: location.hostname.replace(/^www\./i, ''),
    siteName: siteIdentity.name,
    siteNameSource: siteIdentity.source,
    siteProfileId: siteProfile.id,
    siteContentKind: siteProfile.contentKind || 'unknown',
    siteNextStrategy: siteProfile.nextShortcut ? 'keyboard-confirmed' : 'semantic-dom-scan',
    hasReacquireBestVisible: typeof openPictureInPictureReacquireBestVisible === 'function'
      || typeof openPictureInPictureReacquireBestVisibleGlobal === 'function',
    hasSilentStrong: typeof openPictureInPictureSilentStrongForTarget === 'function',
    hasOpenPip: typeof openPictureInPictureForTarget === 'function',
    ts: Date.now()
  };
}

api().runtime.onMessage.addListener((message) => {
  if (!message || PIP_MANAGER_AUXILIARY_CONTEXT) return;

  if (message.type === 'requestVideoState') {
    const snapshot = buildVideoStateSnapshot();
    reportVideoState(true, snapshot);
    sendContentVersionDiagnostic('loaded');
    return Promise.resolve({
      ...getPipManagerCapabilities(),
      type: 'pipManagerVideoStateResponse',
      videoCount: snapshot.sessions.length,
      rawVideoCount: snapshot.rawVideoCount,
      isActiveTab: snapshot.isActiveTab,
      sessions: snapshot.sessions,
      snapshotUnixMs: snapshot.snapshotUnixMs
    });
  }

  if (message.type === 'pipManagerCapabilityCheck') {
    return Promise.resolve(getPipManagerCapabilities());
  }

  if (message.type === 'pipManagerNextPreloadSetting') {
    setNextVideoPreloadEnabled(!!message.enabled);
    return Promise.resolve({ ok: true, enabled: pipManagerNextPreloadEnabled });
  }

  if (message.type === 'openPictureInPicture') {
    return openPictureInPictureForTarget(
      message.targetVideoSessionId || '',
      message.targetStableVideoKey || '',
      Number(message.videoIndex)
    ).then((result) => {
      setTimeout(reportVideoState, 350);
      return result;
    });
  }

  if (message.type === 'openPictureInPictureSilentStrong') {
    return openPictureInPictureSilentStrongForTarget(
      message.targetVideoSessionId || '',
      message.targetStableVideoKey || '',
      Number(message.videoIndex),
      message.attemptId || ''
    ).then((result) => {
      setTimeout(reportVideoState, 250);
      setTimeout(reportVideoState, 900);
      return result;
    });
  }

  if (message.type === 'silentReopenPreflight') {
    return runSilentReopenPreflight(
      message.targetVideoSessionId || '',
      message.targetStableVideoKey || '',
      Number(message.videoIndex),
      message.attemptId || ''
    );
  }


  if (message.type === 'silentMultiFrameProbe') {
    return runSilentMultiFrameProbe(
      message.targetVideoSessionId || '',
      message.targetStableVideoKey || '',
      Number(message.videoIndex),
      message.attemptId || ''
    );
  }

  if (message.type === 'openPictureInPictureReacquireBestVisible') {
    const caps = getPipManagerCapabilities();
    if (!caps.hasReacquireBestVisible) {
      return Promise.resolve({
        ok: false,
        reason: 'content-capability-missing',
        reasonCode: 'content-version-mismatch',
        reasonMessage: 'openPictureInPictureReacquireBestVisible unavailable',
        match: 'capability-check-failed',
        targetStrategy: 'capability-check-failed',
        contentVersion: caps.contentVersion,
        capabilities: caps
      });
    }

    return openPictureInPictureReacquireBestVisible(
      message.targetVideoSessionId || '',
      message.targetStableVideoKey || '',
      Number(message.videoIndex),
      message.attemptId || ''
    ).then((result) => {
      setTimeout(reportVideoState, 250);
      setTimeout(reportVideoState, 900);
      return { ...result, contentVersion: caps.contentVersion, capabilities: caps };
    });
  }

  if (message.type !== 'videoCommand') return;

  const result = runVideoCommand(
    message.command,
    message.targetVideoSessionId || '',
    message.targetStableVideoKey || '',
    Number(message.videoIndex),
    !!message.allowNoVideoTarget
  );

  setTimeout(reportVideoState, 350);
  return Promise.resolve(result);
});

// Listen for occupied slots from background
window.addEventListener('message', (event) => {
  if (event.source !== window) return;
  
  const message = event.data;
  if (message && message.type === 'tab-occupied-slots' && message.occupiedSlots) {
    handleOccupiedSlotsNotification(message.occupiedSlots);
  }
});

// Handle occupied slots notification from background
function handleOccupiedSlotsNotification(occupiedSlots) {
  try {
    // Store for local use if needed
    window._pipManagerOccupiedSlots = occupiedSlots;
    
    // Log for diagnostics
    if (occupiedSlots.length > 0) {
      console.log('[PiPManager] Occupied slots:', occupiedSlots.map(s => 
        `Slot ${s.slotNumber}: ${s.width}×${s.height} @ (${s.left},${s.top})`
      ).join(' | '));
    }
    
    // Dispatch event for site layout engines to listen
    window.dispatchEvent(new CustomEvent('pip-manager-occupied-slots', {
      detail: { occupiedSlots }
    }));
  } catch (err) {
    console.warn('[PiPManager] Error handling occupied slots:', err);
  }
}


// 9.31.18: funções globais garantidas para reaquisição.
// A 9.31.17 chamava openPictureInPictureReacquireBestVisible, mas em alguns content scripts
// a função não ficava disponível no escopo do listener. Estas declarações ficam no topo global.
function findBestVisibleVideoForReacquireGlobal(videoIndex) {
  const videos = getVisibleVideos();
  if (!videos.length) return { video: null, match: 'best-visible-none', candidates: [] };

  const candidates = videos
    .map(item => {
      const diag = getVideoDiagnostics(item.video);
      const quality = item.quality || {};
      let score = Number(quality.score || 0);
      score += Math.min(80, Number(quality.area || 0) / 9000);
      if (!item.video.paused && !item.video.ended) score += 35;
      if (diag.readyState >= 1) score += 20;
      if (diag.readyState >= 2) score += 10;
      if (Number.isInteger(videoIndex) && videoIndex >= 0 && (item.visualRank === videoIndex || item.domIndex === videoIndex)) score += 25;
      if (diag.width >= 480 && diag.height >= 260) score += 15;
      if (diag.currentTime <= 3) score += 6;
      return { item, diag, score };
    })
    .sort((a, b) => b.score - a.score);

  const best = candidates[0];
  if (!best) return { video: null, match: 'best-visible-none', candidates: [] };

  const second = candidates[1];
  if (second && best.score - second.score < 12) {
    return {
      video: null,
      match: 'best-visible-ambiguous',
      candidates: candidates.slice(0, 3).map(c => ({ score: c.score, diagnostics: c.diag }))
    };
  }

  return {
    video: best.item.video,
    item: best.item,
    match: 'best-visible-video-same-tab',
    targetStrategy: 'best-visible-video-same-tab',
    score: best.score,
    candidates: candidates.slice(0, 3).map(c => ({ score: c.score, diagnostics: c.diag }))
  };
}

async function openPictureInPictureReacquireBestVisibleGlobal(targetVideoSessionId, targetStableVideoKey, videoIndex, attemptId) {
  const exact = findTargetVideo(targetVideoSessionId, targetStableVideoKey, videoIndex);
  const lookup = exact.video
    ? exact
    : findBestVisibleVideoForReacquireGlobal(videoIndex);

  if (!lookup.video) {
    return {
      ok: false,
      attemptId,
      reason: 'target-player-not-found',
      reasonCode: 'target-not-found',
      reasonMessage: 'best-visible-target-not-found',
      match: lookup.match || 'none',
      targetStrategy: lookup.targetStrategy || lookup.match || 'none',
      requestAttempted: false,
      enterPipSeen: false,
      candidates: lookup.candidates || []
    };
  }

  const diag = getVideoDiagnostics(lookup.video);
  const result = await tryRequestPictureInPictureSilent(
    lookup.video,
    lookup,
    `reacquire-best-visible:${lookup.match || 'unknown'}`,
    1200,
    attemptId
  );

  return {
    ...result,
    diagnostics: diag,
    targetStrategy: lookup.targetStrategy || lookup.match || 'unknown',
    candidates: lookup.candidates || []
  };
}

// Mantém os nomes que o listener/background já chamam.
var findBestVisibleVideoForReacquire = findBestVisibleVideoForReacquireGlobal;
var openPictureInPictureReacquireBestVisible = openPictureInPictureReacquireBestVisibleGlobal;

async function openPictureInPictureForTarget(targetVideoSessionId, targetStableVideoKey, videoIndex) {
  let lookup = findTargetVideo(targetVideoSessionId, targetStableVideoKey, videoIndex);

  if ((targetVideoSessionId || targetStableVideoKey) && !lookup.video) {
    const fallback = findBestVisibleVideoForReacquire(videoIndex);
    if (fallback.video) {
      lookup = {
        ...fallback,
        match: `best-visible-after-target-miss:${fallback.match}`,
        targetStrategy: `best-visible-after-target-miss:${fallback.match}`
      };
    } else {
      return { ok: false, reason: 'target-player-not-found', reasonCode: 'target-not-found', match: lookup.match };
    }
  }

  const target = lookup.video;
  if (!target) return { ok: false, reason: 'no-video-found', reasonCode: 'target-not-found', match: lookup.match };

  try {
    try { target.scrollIntoView({ block: 'center', inline: 'center' }); } catch (_) {}
    try { target.focus && target.focus(); } catch (_) {}

    if (document.pictureInPictureElement === target) {
      return { ok: true, method: 'already-in-picture-in-picture', match: lookup.match };
    }

    // Orientado à capacidade do player, não ao site: tenta os mecanismos disponíveis
    // em ordem, um único ciclo, sem repetir o mesmo atalho inutilmente. Cada player
    // pode ter um mix diferente de capacidades mesmo dentro do mesmo domínio (duas
    // abas do mesmo site podem ter players diferentes).
    const attempted = [];

    if (document.pictureInPictureEnabled && typeof target.requestPictureInPicture === 'function' && !target.disablePictureInPicture) {
      attempted.push('standard-pip-api');
      try {
        await target.requestPictureInPicture();
        return { ok: true, method: 'requestPictureInPicture', match: lookup.match, capability: 'standard-pip-api' };
      } catch (_) {
        // API existe mas rejeitou (ex.: falta de gesto do usuário, disablePictureInPicture
        // dinâmico). Continua para as próximas capacidades em vez de desistir aqui.
      }
    }

    // clickFirstVisible já busca em raízes shadow DOM abertas via getCandidateRoots
    // (ver collectOpenShadowRoots), então um único chamado cobre tanto DOM comum
    // quanto controles dentro de shadow DOM.
    attempted.push('dom-pip-control', 'shadow-dom-control');
    if (clickFirstVisible([
      '[aria-label*="Picture-in-Picture" i]',
      '[title*="Picture-in-Picture" i]',
      '[aria-label*="Picture in Picture" i]',
      '[title*="Picture in Picture" i]',
      '[aria-label*="Imagem em imagem" i]',
      '[title*="Imagem em imagem" i]',
      'button[class*="pip" i]',
      'button[aria-label*="PiP" i]'
    ], target)) {
      return { ok: true, method: 'dom-pip-button', match: lookup.match, capability: 'dom-pip-control' };
    }

    // Nenhuma capacidade de PiP encontrada neste player, neste instante. Retorna um
    // motivo estável e normalizado — o app não deve repetir o mesmo atalho físico
    // indefinidamente para este alvo, apenas registrar que este player não suporta PiP.
    return {
      ok: false,
      reason: 'player-pip-not-supported',
      reasonCode: 'player-pip-not-supported',
      match: lookup.match,
      capabilitiesAttempted: attempted
    };
  } catch (err) {
    return { ok: false, reason: err && err.message ? err.message : String(err), method: 'requestPictureInPicture-failed', match: lookup.match };
  }
}


function delay(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }

function normalizePipReasonCode(reason) {
  const text = String(reason || '').toLowerCase();

  if (text.includes('notallowed') || text.includes('gesture') || text.includes('user activation') || text.includes('useractivation')) {
    return 'gesture-required';
  }

  if (text.includes('disablepictureinpicture') || text.includes('not supported') || text.includes('not available') || text.includes('not allowed') || text.includes('permission')) {
    return 'pip-not-allowed';
  }

  if (text.includes('ready') || text.includes('metadata') || text.includes('load') || text.includes('network')) {
    return 'video-not-ready';
  }

  if (text.includes('target') || text.includes('not found') || text.includes('missing') || text.includes('ambiguous') || text.includes('no-video')) {
    return 'target-not-found';
  }

  if (text.includes('timeout')) return 'enterpip-timeout';
  if (text.includes('failed') || text.includes('exception')) return 'request-failed';
  return 'unknown-error';
}

function getVideoDiagnostics(video) {
  if (!video) {
    return {
      found: false,
      reasonCode: 'target-not-found'
    };
  }

  const rect = video.getBoundingClientRect();
  const readyState = Number(video.readyState || 0);
  const width = Math.round(rect.width || video.videoWidth || 0);
  const height = Math.round(rect.height || video.videoHeight || 0);
  const disabled = !!video.disablePictureInPicture;
  const canRequest = typeof video.requestPictureInPicture === 'function';
  const pipEnabled = !!document.pictureInPictureEnabled;

  let reasonCode = '';
  if (!canRequest || !pipEnabled || disabled) reasonCode = 'pip-not-allowed';
  else if (readyState < 1 || width <= 0 || height <= 0) reasonCode = 'video-not-ready';

  return {
    found: true,
    reasonCode,
    readyState,
    paused: !!video.paused,
    ended: !!video.ended,
    muted: !!video.muted,
    currentTime: Number(video.currentTime || 0),
    duration: Number(video.duration || 0),
    width,
    height,
    canRequest,
    pipEnabled,
    disablePictureInPicture: disabled,
    inPictureInPicture: document.pictureInPictureElement === video,
    srcHash: hashString(getVideoSource(video))
  };
}

function waitForEnterPictureInPicture(video, timeoutMs) {
  return new Promise((resolve) => {
    if (document.pictureInPictureElement === video) {
      resolve({
        ok: true,
        enterPipSeen: true,
        reasonCode: 'already-in-pip',
        method: 'already-in-picture-in-picture',
        eventTs: Date.now()
      });
      return;
    }

    let done = false;
    const finish = (result) => {
      if (done) return;
      done = true;
      try { video.removeEventListener('enterpictureinpicture', onEnter, true); } catch (_) {}
      clearTimeout(timer);
      resolve(result);
    };

    const onEnter = () => {
      const rect = video.getBoundingClientRect();
      finish({
        ok: true,
        enterPipSeen: true,
        reasonCode: '',
        method: 'enterpictureinpicture-event',
        eventTs: Date.now(),
        videoRect: {
          x: Math.round(rect.x || 0),
          y: Math.round(rect.y || 0),
          width: Math.round(rect.width || 0),
          height: Math.round(rect.height || 0)
        },
        documentTitle: document.title || ''
      });
    };

    const timer = setTimeout(() => finish({
      ok: false,
      enterPipSeen: false,
      reasonCode: 'enterpip-timeout',
      method: 'enterpictureinpicture-timeout',
      eventTs: 0
    }), timeoutMs);

    try { video.addEventListener('enterpictureinpicture', onEnter, true); } catch (_) {}
  });
}

async function tryRequestPictureInPictureSilent(video, lookup, attemptName, timeoutMs, attemptId) {
  const startedAt = Date.now();
  const before = getVideoDiagnostics(video);
  if (!before.found) {
    return {
      ok: false,
      attemptId,
      reasonCode: 'target-not-found',
      reason: 'target-not-found',
      reasonMessage: 'target-not-found',
      method: attemptName,
      match: lookup.match,
      targetStrategy: lookup.match || 'none',
      requestAttempted: false,
      enterPipSeen: false,
      startedAt,
      before
    };
  }

  if (before.inPictureInPicture) {
    return {
      ok: true,
      attemptId,
      reasonCode: 'already-in-pip',
      reason: 'already-in-pip',
      reasonMessage: 'already-in-pip',
      method: `${attemptName}:already-in-pip`,
      match: lookup.match,
      targetStrategy: lookup.match || 'unknown',
      requestAttempted: false,
      enterPipSeen: true,
      startedAt,
      before,
      after: before
    };
  }

  if (before.reasonCode === 'pip-not-allowed') {
    return {
      ok: false,
      attemptId,
      reasonCode: 'pip-not-allowed',
      reason: 'picture-in-picture-api-not-allowed',
      reasonMessage: 'picture-in-picture-api-not-allowed',
      method: attemptName,
      match: lookup.match,
      targetStrategy: lookup.match || 'unknown',
      requestAttempted: false,
      enterPipSeen: false,
      startedAt,
      before
    };
  }

  if (before.reasonCode === 'video-not-ready') {
    await delay(180);
  }

  try {
    try { video.dispatchEvent(new Event('mousemove', { bubbles: true })); } catch (_) {}
    try { video.dispatchEvent(new MouseEvent('mouseover', { bubbles: true, view: window })); } catch (_) {}

    const waitEnter = waitForEnterPictureInPicture(video, timeoutMs);
    await video.requestPictureInPicture();
    const enter = await waitEnter;
    const after = getVideoDiagnostics(video);

    if (document.pictureInPictureElement === video || enter.ok) {
      return {
        ok: true,
        attemptId,
        reasonCode: enter.reasonCode || '',
        reason: enter.reasonCode || '',
        reasonMessage: enter.reasonCode || '',
        method: `${attemptName}:requestPictureInPicture`,
        match: lookup.match,
        targetStrategy: lookup.match || 'unknown',
        requestAttempted: true,
        enterPipSeen: !!enter.enterPipSeen || !!enter.ok,
        startedAt,
        finishedAt: Date.now(),
        before,
        after,
        enter
      };
    }

    return {
      ok: false,
      attemptId,
      reasonCode: enter.reasonCode || 'enterpip-timeout',
      reason: 'enterpictureinpicture-timeout',
      reasonMessage: 'enterpictureinpicture-timeout',
      method: `${attemptName}:requestPictureInPicture`,
      match: lookup.match,
      targetStrategy: lookup.match || 'unknown',
      requestAttempted: true,
      enterPipSeen: !!enter.enterPipSeen,
      startedAt,
      finishedAt: Date.now(),
      before,
      after,
      enter
    };
  } catch (err) {
    const reason = err && err.message ? err.message : String(err);
    const code = normalizePipReasonCode(reason);
    return {
      ok: false,
      attemptId,
      reasonCode: code === 'unknown-error' ? 'request-failed' : code,
      reason,
      reasonMessage: reason,
      method: `${attemptName}:requestPictureInPicture-exception`,
      match: lookup.match,
      targetStrategy: lookup.match || 'unknown',
      requestAttempted: true,
      enterPipSeen: false,
      startedAt,
      finishedAt: Date.now(),
      before,
      after: getVideoDiagnostics(video)
    };
  }
}


function classifySilentIneligibility(diagnostics, lookup) {
  if (!lookup || !lookup.video) return 'target-not-found';
  if (!diagnostics || !diagnostics.found) return 'target-not-found';
  if (!diagnostics.pipEnabled) return 'pip-api-disabled';
  if (!diagnostics.canRequest) return 'pip-method-unavailable';
  if (diagnostics.disablePictureInPicture) return 'pip-disabled-by-video';
  if (diagnostics.readyState < 1) return 'player-not-ready';
  if (diagnostics.width <= 0 || diagnostics.height <= 0) return 'no-visible-video';
  if (diagnostics.ended) return 'video-ended';
  return diagnostics.reasonCode || '';
}


function buildEmbeddedMultiFramePreflightSummary(targetVideoSessionId, targetStableVideoKey, videoIndex) {
  try {
    const videos = Array.from(document.querySelectorAll('video'));
    const states = videos.map((video, index) => {
      let diagnostics;
      try {
        diagnostics = typeof getVideoDiagnostics === 'function'
          ? getVideoDiagnostics(video)
          : {
              readyState: video.readyState || 0,
              paused: !!video.paused,
              ended: !!video.ended,
              muted: !!video.muted,
              pipEnabled: !!document.pictureInPictureEnabled,
              alreadyInPip: document.pictureInPictureElement === video,
              canRequest: !!(document.pictureInPictureEnabled && video.requestPictureInPicture && !video.disablePictureInPicture),
              disablePip: !!video.disablePictureInPicture
            };
      } catch {
        diagnostics = { readyState: 0, paused: true, ended: false, muted: false, pipEnabled: false, alreadyInPip: false, canRequest: false, disablePip: false };
      }

      const rect = video.getBoundingClientRect ? video.getBoundingClientRect() : { width: 0, height: 0, left: 0, top: 0 };
      const visible = !!(rect && rect.width >= 80 && rect.height >= 45);
      const sessionId = video.dataset ? (video.dataset.pipManagerVideoSessionId || video.dataset.videoSessionId || '') : '';
      let stableKey = '';
      try { stableKey = typeof buildStableVideoKey === 'function' ? buildStableVideoKey(video, index) : ''; } catch {}

      const matchSession = !!targetVideoSessionId && sessionId === targetVideoSessionId;
      const matchStable = !!targetStableVideoKey && stableKey === targetStableVideoKey;
      const score = (matchSession ? 100 : 0)
        + (matchStable ? 80 : 0)
        + (visible ? 25 : 0)
        + (diagnostics.canRequest ? 60 : 0)
        + (diagnostics.pipEnabled ? 25 : 0)
        + ((diagnostics.readyState || 0) >= 1 ? 10 : 0)
        - (diagnostics.ended ? 80 : 0);

      return {
        index,
        score,
        visible,
        matchSession,
        matchStable,
        sessionId,
        stableKey,
        readyState: diagnostics.readyState || 0,
        paused: !!diagnostics.paused,
        ended: !!diagnostics.ended,
        muted: !!diagnostics.muted,
        pipEnabled: !!diagnostics.pipEnabled,
        canRequest: !!diagnostics.canRequest,
        disablePip: !!diagnostics.disablePip,
        alreadyInPip: !!diagnostics.alreadyInPip,
        width: Math.round(rect?.width || 0),
        height: Math.round(rect?.height || 0),
        left: Math.round(rect?.left || 0),
        top: Math.round(rect?.top || 0)
      };
    }).sort((a, b) => b.score - a.score);

    let target = null;
    try {
      target = typeof findTargetVideo === 'function'
        ? findTargetVideo(targetVideoSessionId, targetStableVideoKey, videoIndex)
        : null;
    } catch {}

    const targetIndex = typeof target?.index === 'number' ? target.index : -1;
    const targetState = states.find(v => v.index === targetIndex) || null;
    const best = states[0] || null;
    const framesAnswered = 1;
    const framesWithVideo = videos.length > 0 ? 1 : 0;
    const requestableVideos = states.filter(v => v.canRequest);
    const requestableFrames = requestableVideos.length > 0 ? 1 : 0;
    const currentTargetBlocked = !!(targetState && !targetState.canRequest);
    const wrongFrameSuspected = currentTargetBlocked && requestableVideos.length > 0;

    const topVideos = states.slice(0, 6).map(v => `#${v.index}:score=${v.score},visible=${v.visible},matchS=${v.matchSession},matchK=${v.matchStable},ready=${v.readyState},pipEnabled=${v.pipEnabled},canRequest=${v.canRequest},ended=${v.ended},muted=${v.muted},size=${v.width}x${v.height}`).join(' | ');

    return {
      ok: true,
      source: 'embedded-preflight-content',
      frameId: 0,
      domain: location.hostname,
      title: document.title,
      videoCount: videos.length,
      framesAnswered,
      framesWithVideo,
      requestableFrames,
      requestableVideos: requestableVideos.length,
      wrongFrameSuspected,
      targetFound: !!target?.video,
      targetIndex,
      targetScore: targetState ? targetState.score : 0,
      bestIndex: best ? best.index : -1,
      bestScore: best ? best.score : 0,
      bestCanRequest: best ? !!best.canRequest : false,
      bestPipEnabled: best ? !!best.pipEnabled : false,
      bestReadyState: best ? best.readyState : 0,
      topVideos,
      contentVersion: typeof CONTENT_VERSION !== 'undefined' ? CONTENT_VERSION : ''
    };
  } catch (e) {
    return {
      ok: false,
      source: 'embedded-preflight-content',
      frameId: 0,
      domain: location.hostname,
      title: document.title,
      error: e?.message || String(e),
      videoCount: 0,
      framesAnswered: 1,
      framesWithVideo: 0,
      requestableFrames: 0,
      requestableVideos: 0,
      wrongFrameSuspected: false,
      targetFound: false,
      targetIndex: -1,
      targetScore: 0,
      bestIndex: -1,
      bestScore: 0,
      topVideos: '',
      contentVersion: typeof CONTENT_VERSION !== 'undefined' ? CONTENT_VERSION : ''
    };
  }
}


function emitContentSilentDiagnosticDirect(eventName, payload) {
  try {
    const data = Object.assign({
      type: 'silentDiagnostic',
      event: eventName,
      attemptId: payload?.attemptId || '',
      silent: true,
      attempt: 0,
      ok: !!payload?.ok,
      result: payload?.result || '',
      found: !!payload?.found,
      requestAttempted: false,
      enterPipSeen: false,
      reasonCode: payload?.reasonCode || '',
      reason: payload?.reason || '',
      reasonMessage: payload?.reasonMessage || '',
      method: payload?.method || 'silent-multiframe-content-direct-log',
      match: payload?.match || '',
      strategy: payload?.strategy || '',
      targetStrategy: payload?.targetStrategy || 'content-direct',
      tabId: payload?.tabId || 0,
      frameId: payload?.frameId || 0,
      domain: payload?.domain || location.hostname,
      title: payload?.title || document.title,
      videoIndex: typeof payload?.videoIndex === 'number' ? payload.videoIndex : 0,
      currentTime: Number(payload?.currentTime || 0),
      duration: Number(payload?.duration || 0),
      contentVersion: typeof CONTENT_VERSION !== 'undefined' ? CONTENT_VERSION : '',
      expectedContentVersion: '',
      hasReacquireBestVisible: false,
      hasUserActivation: !!navigator.userActivation,
      isActiveUserActivation: !!(navigator.userActivation && navigator.userActivation.isActive),
      documentPictureInPicture: typeof documentPictureInPicture !== 'undefined',
      readyState: Number(payload?.readyState || 0),
      paused: !!payload?.paused,
      ended: !!payload?.ended,
      muted: !!payload?.muted,
      pipEnabled: !!payload?.pipEnabled,
      alreadyInPip: !!payload?.alreadyInPip,
      canRequest: !!payload?.canRequest,
      disablePip: !!payload?.disablePip,
      size: payload?.size || ''
    }, payload || {});

    // Use every viable channel. The background already forwards silentDiagnostic to the app.
    try {
      if (typeof browser !== 'undefined' && browser.runtime && browser.runtime.sendMessage) {
        browser.runtime.sendMessage(data).catch(() => {});
      }
    } catch {}

    try {
      if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
        chrome.runtime.sendMessage(data, () => void chrome.runtime.lastError);
      }
    } catch {}

    try {
      window.postMessage(Object.assign({}, data, { source: 'pip-manager-content-direct-diagnostic' }), '*');
    } catch {}
  } catch {}
}

function emitMultiFrameContentSummaryDirect(targetVideoSessionId, targetStableVideoKey, videoIndex, attemptId, phase) {
  try {
    const mf = typeof buildEmbeddedMultiFramePreflightSummary === 'function'
      ? buildEmbeddedMultiFramePreflightSummary(targetVideoSessionId, targetStableVideoKey, videoIndex)
      : null;

    if (!mf) {
      emitContentSilentDiagnosticDirect('pip-preserve-silent-multiframe-content-summary-missing', {
        attemptId,
        ok: false,
        result: 'missing',
        reasonCode: 'content-summary-missing',
        reason: `phase=${phase || ''}; buildEmbeddedMultiFramePreflightSummary unavailable`,
        reasonMessage: 'content direct multi-frame summary missing',
        method: 'silent-multiframe-content-direct-log',
        targetStrategy: 'content-direct'
      });
      return null;
    }

    emitContentSilentDiagnosticDirect('pip-preserve-silent-multiframe-content-frame-result', {
      attemptId,
      ok: !!mf.ok,
      result: mf.ok ? 'ok' : 'failed',
      found: !!mf.targetFound,
      reasonCode: mf.wrongFrameSuspected ? 'wrong-frame-suspected' : '',
      reason: mf.topVideos || `videoCount=${mf.videoCount || 0}`,
      reasonMessage: `phase=${phase || ''}; source=${mf.source || ''}; videoCount=${mf.videoCount || 0}; targetFound=${mf.targetFound}; bestIndex=${mf.bestIndex}; bestScore=${mf.bestScore}; targetIndex=${mf.targetIndex}; targetScore=${mf.targetScore}; requestableVideos=${mf.requestableVideos || 0}; wrongFrameSuspected=${mf.wrongFrameSuspected}`,
      method: 'silent-multiframe-content-direct-log',
      targetStrategy: 'content-direct-frame',
      domain: mf.domain || location.hostname,
      title: mf.title || document.title,
      videoIndex: typeof mf.targetIndex === 'number' ? mf.targetIndex : -1,
      frameId: Number(mf.frameId || 0),
      readyState: Number(mf.bestReadyState || 0),
      pipEnabled: !!mf.bestPipEnabled,
      canRequest: !!mf.bestCanRequest,
      size: `videos=${mf.videoCount || 0}`
    });

    emitContentSilentDiagnosticDirect('pip-preserve-silent-multiframe-content-summary', {
      attemptId,
      ok: !!mf.ok,
      result: mf.ok ? 'ok' : 'failed',
      found: !!mf.targetFound,
      reasonCode: mf.wrongFrameSuspected ? 'wrong-frame-suspected' : '',
      reason: `framesAnswered=${mf.framesAnswered || 1}; framesWithVideo=${mf.framesWithVideo || 0}; requestableFrames=${mf.requestableFrames || 0}; requestableVideos=${mf.requestableVideos || 0}; wrongFrameSuspected=${mf.wrongFrameSuspected}; videoCount=${mf.videoCount || 0}`,
      reasonMessage: `phase=${phase || ''}; bestIndex=${mf.bestIndex}; bestScore=${mf.bestScore}; bestCanRequest=${mf.bestCanRequest}; bestPipEnabled=${mf.bestPipEnabled}; bestReadyState=${mf.bestReadyState}; targetIndex=${mf.targetIndex}; targetScore=${mf.targetScore}`,
      method: 'silent-multiframe-content-direct-log',
      targetStrategy: 'content-direct-summary',
      domain: mf.domain || location.hostname,
      title: mf.title || document.title,
      videoIndex: typeof mf.bestIndex === 'number' ? mf.bestIndex : -1,
      frameId: Number(mf.frameId || 0),
      readyState: Number(mf.bestReadyState || 0),
      pipEnabled: !!mf.bestPipEnabled,
      canRequest: !!mf.bestCanRequest,
      size: `videos=${mf.videoCount || 0}`
    });

    return mf;
  } catch (e) {
    emitContentSilentDiagnosticDirect('pip-preserve-silent-multiframe-content-summary-failed', {
      attemptId,
      ok: false,
      result: 'failed',
      reasonCode: 'content-summary-failed',
      reason: e?.message || String(e),
      reasonMessage: `phase=${phase || ''}`,
      method: 'silent-multiframe-content-direct-log',
      targetStrategy: 'content-direct'
    });
    return null;
  }
}

async function runSilentReopenPreflight(targetVideoSessionId, targetStableVideoKey, videoIndex, attemptId) {
  emitMultiFrameContentSummaryDirect(targetVideoSessionId, targetStableVideoKey, videoIndex, attemptId, 'preflight-start');

  const embeddedMultiFramePreflight = buildEmbeddedMultiFramePreflightSummary(targetVideoSessionId, targetStableVideoKey, videoIndex);

  const startedAt = Date.now();
  const lookup = findTargetVideo(targetVideoSessionId, targetStableVideoKey, videoIndex);
  const diagnostics = lookup && lookup.video ? getVideoDiagnostics(lookup.video) : { found: false, reasonCode: 'target-not-found' };
  const ineligibleReason = classifySilentIneligibility(diagnostics, lookup);
  const ok = !ineligibleReason;

  emitMultiFrameContentSummaryDirect(targetVideoSessionId, targetStableVideoKey, videoIndex, attemptId, 'preflight-before-return');
  return {
    ok,
    attemptId,
    reasonCode: ineligibleReason,
    reason: ineligibleReason,
    reasonMessage: ineligibleReason,
    method: 'silent-reopen-preflight',
      embeddedMultiFramePreflight,
    match: lookup ? lookup.match || '' : '',
    targetStrategy: lookup ? lookup.match || 'none' : 'none',
    found: !!(lookup && lookup.video),
    requestAttempted: false,
    enterPipSeen: false,
    tabUrl: location.href,
    domain: location.hostname.replace(/^www\./i, ''),
    title: document.title || '',
    videoIndex: Number.isInteger(videoIndex) ? videoIndex : -1,
    videoCount: getVisibleVideos().length,
    pictureInPictureEnabled: !!document.pictureInPictureEnabled,
    alreadyInPip: !!document.pictureInPictureElement,
    hasUserActivation: !!(navigator.userActivation && navigator.userActivation.hasBeenActive),
    isActiveUserActivation: !!(navigator.userActivation && navigator.userActivation.isActive),
    documentPictureInPicture: typeof window.documentPictureInPicture !== 'undefined',
    contentVersion: CONTENT_VERSION,
    diagnostics,
    ts: startedAt
  };
}

async function runSilentMultiFrameProbe(targetVideoSessionId, targetStableVideoKey, videoIndex, attemptId) {
  const videos = Array.from(document.querySelectorAll('video'));
  const states = videos.map((video, index) => {
    const diagnostics = typeof getVideoDiagnostics === 'function'
      ? getVideoDiagnostics(video)
      : {
          readyState: video.readyState || 0,
          paused: !!video.paused,
          ended: !!video.ended,
          muted: !!video.muted,
          pipEnabled: !!document.pictureInPictureEnabled,
          alreadyInPip: document.pictureInPictureElement === video,
          canRequest: !!(document.pictureInPictureEnabled && video.requestPictureInPicture && !video.disablePictureInPicture),
          disablePip: !!video.disablePictureInPicture
        };

    const rect = video.getBoundingClientRect ? video.getBoundingClientRect() : { width: 0, height: 0, left: 0, top: 0 };
    const visible = !!(rect && rect.width >= 80 && rect.height >= 45);
    const sessionId = video.dataset ? (video.dataset.pipManagerVideoSessionId || video.dataset.videoSessionId || '') : '';
    let stableKey = '';
    try { stableKey = typeof buildStableVideoKey === 'function' ? buildStableVideoKey(video, index) : ''; } catch {}

    const matchSession = !!targetVideoSessionId && sessionId === targetVideoSessionId;
    const matchStable = !!targetStableVideoKey && stableKey === targetStableVideoKey;
    const score = (matchSession ? 100 : 0)
      + (matchStable ? 80 : 0)
      + (visible ? 25 : 0)
      + (diagnostics.canRequest ? 60 : 0)
      + (diagnostics.pipEnabled ? 25 : 0)
      + ((diagnostics.readyState || 0) >= 1 ? 10 : 0)
      - (diagnostics.ended ? 80 : 0);

    return {
      index,
      sessionId,
      stableKey,
      matchSession,
      matchStable,
      visible,
      score,
      rect: {
        width: Math.round(rect?.width || 0),
        height: Math.round(rect?.height || 0),
        left: Math.round(rect?.left || 0),
        top: Math.round(rect?.top || 0)
      },
      diagnostics
    };
  }).sort((a, b) => b.score - a.score);

  let target = null;
  try {
    target = typeof findTargetVideo === 'function'
      ? findTargetVideo(targetVideoSessionId, targetStableVideoKey, videoIndex)
      : null;
  } catch {}

  const best = states[0] || null;
  const targetIndex = typeof target?.index === 'number' ? target.index : -1;
  const targetState = states.find(v => v.index === targetIndex) || null;
  const hasAnyRequestable = states.some(v => v.diagnostics && v.diagnostics.canRequest);
  const currentFrameHardBlocked = !!(targetState && targetState.diagnostics && !targetState.diagnostics.canRequest);
  const wrongFrameSuspected = currentFrameHardBlocked && hasAnyRequestable;

  return {
    ok: true,
    method: 'silent-multiframe-probe',
    attemptId,
    tabUrl: location.href,
    domain: location.hostname,
    title: document.title,
    frameTitle: document.title,
    videoCount: videos.length,
    targetFound: !!target?.video,
    targetIndex,
    targetStrategy: target?.strategy || '',
    bestIndex: best ? best.index : -1,
    bestScore: best ? best.score : 0,
    targetScore: targetState ? targetState.score : 0,
    betterCandidate: !!(best && targetState && best.index !== targetState.index && best.score > targetState.score + 30),
    wrongFrameSuspected,
    hasAnyRequestable,
    pictureInPictureEnabled: !!document.pictureInPictureEnabled,
    documentPictureInPicture: typeof documentPictureInPicture !== 'undefined',
    contentVersion: typeof CONTENT_VERSION !== 'undefined' ? CONTENT_VERSION : '',
    videos: states.slice(0, 10),
    ts: Date.now()
  };
}



async function openPictureInPictureSilentStrongForTarget(targetVideoSessionId, targetStableVideoKey, videoIndex, attemptId) {
  const startedAt = Date.now();
  const localAttemptId = attemptId || `silent-${PAGE_INSTANCE_ID}-${startedAt.toString(36)}`;
  const attempts = [];

  const preflightVideos = getVisibleVideos();
  const preflight = {
    attemptId: localAttemptId,
    type: 'silent-preflight-start',
    ts: startedAt,
    tabUrl: location.href,
    domain: location.hostname,
    documentTitle: document.title || '',
    targetVideoSessionId,
    targetStableVideoKey,
    videoIndex,
    videoCount: preflightVideos.length,
    pictureInPictureEnabled: !!document.pictureInPictureEnabled,
    alreadyInPip: !!document.pictureInPictureElement
  };

  for (let attempt = 1; attempt <= 3; attempt += 1) {
    let lookup = findTargetVideo(targetVideoSessionId, targetStableVideoKey, videoIndex);
    let targetStrategy = lookup.match || 'none';

    if (!lookup.video && attempt === 3) {
      lookup = findTargetVideo('', '', Number.isInteger(videoIndex) ? videoIndex : -1);
      if (lookup.video) {
        targetStrategy = `best-visible-video:${lookup.match}`;
        lookup.match = targetStrategy;
      }
    }

    if (!lookup.video) {
      attempts.push({
        attempt,
        attemptId: localAttemptId,
        type: `silent-attempt-${attempt}`,
        strategy: targetStrategy,
        ok: false,
        result: 'fail',
        found: false,
        videoCount: getVisibleVideos().length,
        reasonCode: 'target-not-found',
        reason: 'target-not-found',
        reasonMessage: 'target-not-found',
        requestAttempted: false,
        enterPipSeen: false,
        ts: Date.now()
      });
      await delay(220);
      continue;
    }

    const diag = getVideoDiagnostics(lookup.video);
    if (diag.reasonCode === 'video-not-ready' && attempt < 3) {
      attempts.push({
        attempt,
        attemptId: localAttemptId,
        type: `silent-attempt-${attempt}`,
        strategy: targetStrategy,
        ok: false,
        result: 'fail',
        found: true,
        reasonCode: 'video-not-ready',
        reason: 'video-not-ready',
        reasonMessage: 'video-not-ready',
        requestAttempted: false,
        enterPipSeen: false,
        diagnostics: diag,
        ts: Date.now()
      });
      await delay(320);
      continue;
    }

    const result = await tryRequestPictureInPictureSilent(
      lookup.video,
      lookup,
      `silent-strong-attempt-${attempt}`,
      attempt === 1 ? 900 : 1200,
      localAttemptId
    );

    attempts.push({
      attempt,
      type: `silent-attempt-${attempt}`,
      strategy: targetStrategy,
      result: result.ok ? 'success' : 'fail',
      found: true,
      ...result
    });

    if (result.ok) {
      return {
        ok: true,
        attemptId: localAttemptId,
        reasonCode: result.reasonCode || '',
        reason: result.reason || '',
        reasonMessage: result.reasonMessage || result.reason || '',
        method: result.method,
        match: result.match,
        targetStrategy,
        enterPipSeen: !!result.enterPipSeen,
        requestAttempted: !!result.requestAttempted,
        preflight,
        attempts,
        final: {
          type: 'silent-final-result',
          attemptId: localAttemptId,
          result: 'confirmed-by-content',
          reasonCode: result.reasonCode || '',
          enterPipSeen: !!result.enterPipSeen,
          hwndCaptured: false
        }
      };
    }

    if (result.reasonCode === 'gesture-required' || result.reasonCode === 'pip-not-allowed') {
      return {
        ok: false,
        attemptId: localAttemptId,
        reasonCode: result.reasonCode,
        reason: result.reason || result.reasonCode,
        reasonMessage: result.reasonMessage || result.reason || result.reasonCode,
        method: result.method,
        match: result.match,
        targetStrategy,
        enterPipSeen: !!result.enterPipSeen,
        requestAttempted: !!result.requestAttempted,
        preflight,
        attempts,
        final: {
          type: 'silent-final-result',
          attemptId: localAttemptId,
          result: 'failed-in-content',
          reasonCode: result.reasonCode,
          enterPipSeen: !!result.enterPipSeen,
          hwndCaptured: false
        }
      };
    }

    await delay(260);
  }

  const last = attempts[attempts.length - 1] || {};
  return {
    ok: false,
    attemptId: localAttemptId,
    reasonCode: last.reasonCode || 'unknown-error',
    reason: last.reason || last.reasonCode || 'unknown-error',
    reasonMessage: last.reasonMessage || last.reason || last.reasonCode || 'unknown-error',
    method: last.method || 'silent-strong-exhausted',
    match: last.match || 'none',
    targetStrategy: last.strategy || last.targetStrategy || 'none',
    enterPipSeen: !!last.enterPipSeen,
    requestAttempted: attempts.some(item => !!item.requestAttempted),
    preflight,
    attempts,
    final: {
      type: 'silent-final-result',
      attemptId: localAttemptId,
      result: 'failed-in-content',
      reasonCode: last.reasonCode || 'unknown-error',
      enterPipSeen: !!last.enterPipSeen,
      hwndCaptured: false
    }
  };
}


function runVideoCommand(command, targetVideoSessionId, targetStableVideoKey, videoIndex, allowNoVideoTarget = false) {
  const lookup = findTargetVideo(targetVideoSessionId, targetStableVideoKey, videoIndex);

  // Se o app mandou alvo explícito, não faz fallback para outro player, exceto no
  // gatilho terminal seguro: a aba é exata, mas o elemento pode já ter sido removido.
  if ((targetVideoSessionId || targetStableVideoKey) && !lookup.video && !allowNoVideoTarget) {
    return {
      ok: false,
      reason: 'target-player-not-found',
      targetVideoSessionId,
      targetStableVideoKey
    };
  }

  const target = lookup.video;
  if (!target && command === 'next' && allowNoVideoTarget)
    return runNextVideo(null, { match: 'terminal-same-tab-no-video-target' });
  if (!target) return { ok: false, reason: 'no-video-found' };

  if (command === 'next') return runNextVideo(target, lookup);
  if (command === 'previous') return runPreviousVideo(target, lookup);

  return { ok: false, reason: 'unknown-command' };
}

function runNextVideo(targetVideo, lookup) {
  const profile = getPipManagerSiteProfile();

  if (profile.preferDomNext) {
    const preferredDomClick = clickFirstVisible(profile.nextSelectors || [], targetVideo);
    if (preferredDomClick) {
      reportVideoState();
      return { ok: true, method: `profile-dom-next:${profile.id}`, siteProfileId: profile.id, match: lookup.match };
    }

    const preferredSemanticClick = clickSemanticNavigationControl('next', targetVideo);
    if (preferredSemanticClick) {
      reportVideoState();
      return { ok: true, method: `profile-semantic-next:${profile.id}`, siteProfileId: profile.id, match: lookup.match };
    }
  }

  // Navegação por URL é determinística (não depende de o navegador aceitar
  // um evento de teclado sintético como "confiável", o que ele nunca faz).
  // Preferida quando o site não expõe nenhum botão real de "próximo".
  if (profile.preferUrlIndexAdvance && profile.allowUrlIndexAdvance && tryAdvanceUrlIndex(1)) {
    return { ok: true, method: `profile-url-index:${profile.id}`, siteProfileId: profile.id, match: lookup.match };
  }

  if (profile.nextShortcut) {
    const shortcutOk = dispatchKeyboardChordStrong(profile.nextShortcut, targetVideo);
    if (shortcutOk) {
      reportVideoState();
      return { ok: true, method: `profile-shortcut:${profile.id}`, siteProfileId: profile.id, match: lookup.match };
    }
  }

  const clicked = profile.preferDomNext ? false : clickFirstVisible(profile.nextSelectors || [], targetVideo);

  if (clicked) {
    reportVideoState();
    return { ok: true, method: `profile-dom-next:${profile.id}`, siteProfileId: profile.id, match: lookup.match };
  }


  const semanticClicked = clickSemanticNavigationControl('next', targetVideo);
  if (semanticClicked) {
    reportVideoState();
    return { ok: true, method: `profile-semantic-next:${profile.id}`, siteProfileId: profile.id, match: lookup.match };
  }

  if (profile.allowUrlIndexAdvance && tryAdvanceUrlIndex(1)) {
    return { ok: true, method: `profile-url-index:${profile.id}`, siteProfileId: profile.id, match: lookup.match };
  }

  return { ok: false, reason: 'site-profile-next-not-found', siteProfileId: profile.id, match: lookup.match };
}

let pipManagerReopenTimer = null;

function scheduleReopenPictureInPictureAfterNext(reason) {
  // 9.31.1: limpeza real.
  // Não agenda Ctrl+Shift+], não chama requestPictureInPicture e não emite pipAutoReopenAttempt.
  if (pipManagerReopenTimer) {
    clearTimeout(pipManagerReopenTimer);
    pipManagerReopenTimer = null;
  }
  setTimeout(reportVideoState, 120);
}

function reportPostNextVideoDiagnostic(reason, delayMs) {
  // 9.31.1: removido pipAutoReopenAttempt para a extensão não parecer que está reabrindo PiP.
  setTimeout(reportVideoState, 120);
}

function reopenPictureInPictureIfClosed(reason, delayMs) {
  // 9.31.1: desativado de verdade.
  // O usuário pode abrir PiP manualmente pelo navegador; a extensão não força reabertura.
  setTimeout(reportVideoState, 120);
}


function isVideoReadyForPip(video) {
  if (!video) return false;
  const rect = video.getBoundingClientRect();
  const hasArea = rect.width > 80 && rect.height > 45;
  const ready = Number(video.readyState || 0);
  const hasMetadata = Number(video.videoWidth || 0) > 0 || Number(video.videoHeight || 0) > 0 || Number.isFinite(Number(video.duration || 0));
  return hasArea && ready >= 1 && hasMetadata;
}

function checkPendingReopenAfterNavigation() {
  try { sessionStorage.removeItem('pipManagerReopenAfterNavigation'); } catch (_) {}
  setTimeout(reportVideoState, 120);
}


function runPreviousVideo(targetVideo, lookup) {
  const profile = getPipManagerSiteProfile();
  if (profile.forceBrowserHistoryPrevious)
    return { ok: false, reason: 'needs-browser-go-back', method: `profile-browser-history-previous:${profile.id}`, match: lookup.match };
  const clicked = clickFirstVisible(profile.previousSelectors || [], targetVideo);
  if (clicked) {
    reportVideoState();
    return { ok: true, method: `profile-dom-previous:${profile.id}`, siteProfileId: profile.id, match: lookup.match };
  }
  if (clickSemanticNavigationControl('previous', targetVideo)) {
    reportVideoState();
    return { ok: true, method: `profile-semantic-previous:${profile.id}`, siteProfileId: profile.id, match: lookup.match };
  }
  if (profile.preferUrlIndexAdvance && profile.allowUrlIndexAdvance && tryAdvanceUrlIndex(-1)) {
    return { ok: true, method: `profile-url-index-previous:${profile.id}`, siteProfileId: profile.id, match: lookup.match };
  }
  if (profile.previousShortcut && dispatchKeyboardChordStrong(profile.previousShortcut, targetVideo)) {
    reportVideoState();
    return { ok: true, method: `profile-shortcut-previous:${profile.id}`, siteProfileId: profile.id, match: lookup.match };
  }
  if (profile.allowUrlIndexAdvance && tryAdvanceUrlIndex(-1)) {
    return { ok: true, method: `profile-url-index-previous:${profile.id}`, siteProfileId: profile.id, match: lookup.match };
  }
  return { ok: false, reason: 'needs-browser-go-back', method: 'request-browser-go-back-primary', match: lookup.match };
}

function findTargetVideo(targetVideoSessionId, targetStableVideoKey, videoIndex) {
  const videos = getVisibleVideos();
  if (!videos.length) return { video: null, match: 'none' };

  if (targetVideoSessionId) {
    const found = videos.find(item => getVideoSessionId(item.video) === targetVideoSessionId);
    if (found) return { video: found.video, item: found, match: 'videoSessionId' };
  }

  if (targetStableVideoKey) {
    const matches = videos.filter(item => getStableVideoKey(item.video) === targetStableVideoKey);
    if (matches.length === 1) return { video: matches[0].video, item: matches[0], match: 'stableVideoKey' };
    if (matches.length > 1) return { video: null, match: 'stableVideoKey-ambiguous' };
  }

  if ((targetVideoSessionId || targetStableVideoKey)) {
    return { video: null, match: 'target-missing' };
  }

  if (Number.isInteger(videoIndex) && videoIndex >= 0) {
    const found = videos.find(item => item.visualRank === videoIndex || item.domIndex === videoIndex);
    if (found) return { video: found.video, item: found, match: 'videoIndex' };
  }

  const playing = videos.find(item => !item.video.paused && !item.video.ended);
  const picked = playing || videos[0];
  return { video: picked.video, item: picked, match: playing ? 'playing-fallback' : 'first-fallback' };
}


function getAdvertisementClassification(video, rect) {
  const title = String(document.title || '').trim();
  const host = String(location.hostname || '').replace(/^www\./i, '').toLowerCase();
  const pageUrl = String(location.href || '').toLowerCase();
  const source = String(getVideoSource(video) || '').toLowerCase();
  const referrer = String(document.referrer || '').toLowerCase();
  const duration = Number(video && video.duration || 0);

  const titleSignal = /\b(outstream\s+ad|ad\s+content|video\s+advertisement|video\s+ad|sponsored\s+video|instream\s+ad|pre[-\s]?roll\s+ad|mobile\s+slider)\b/i.test(title);
  const knownAdHostSuffixes = [
    'aphroxa.com',
    'trendbuzz.to',
    'quality-traffic.com',
    'contentsserved.com',
    'creative.cambaddies.com',
    'creative.prncams.com',
    'doubleclick.net',
    'googlesyndication.com',
    'adnxs.com',
    'adsrvr.org',
    'criteo.com',
    'taboola.com',
    'outbrain.com'
  ];
  const knownAdHost = knownAdHostSuffixes.some(suffix => host === suffix || host.endsWith(`.${suffix}`));
  const genericAdHost = /(^|\.)(ads?|adservice|adserver|syndicate|creative|promo|banner)\./i.test(host);
  const routeSignal = /(?:[?&](?:campaignid|creativeid|smartpopid|traffictype|adunit|placementid)=|banneriframe|outstream|\/vast(?:\/|\?|$)|\/prebid(?:\/|\?|$)|\/ads?(?:\/|\?|$))/i.test(`${pageUrl} ${source} ${referrer}`);

  let containerSignal = false;
  let inPlayerAdSignal = false;
  try {
    let node = video;
    for (let depth = 0; node && depth < 6; depth += 1, node = node.parentElement) {
      const marker = `${node.id || ''} ${node.className || ''} ${node.getAttribute?.('data-ad') || ''} ${node.getAttribute?.('data-testid') || ''}`;
      if (/(^|[\s_-])(advert|advertisement|sponsored|outstream|preroll|pre-roll|vast|ad-slot|ad-container|video-ad|banner)([\s_-]|$)/i.test(marker)) {
        containerSignal = true;
        break;
      }
    }
  } catch (_) {}

  // Some sites replace the media inside the main player during an instream ad.
  // The page URL/title remain those of the real video, so inspect only the
  // player subtree for a visible ad overlay or skip/countdown control.
  try {
    const playerRoot = video.closest('[class*="player" i],[id*="player" i]') || video.parentElement;
    if (playerRoot) {
      const adNodes = Array.from(playerRoot.querySelectorAll(
        '[class*="advert" i],[class*="ad-container" i],[class*="adContainer" i],' +
        '[class*="skip-ad" i],[class*="skipAd" i],[id*="ad-container" i],' +
        '[data-ad],[data-ad-state],[data-testid*="ad-" i]'));
      inPlayerAdSignal = adNodes.some(node => {
        if (!isVisible(node)) return false;
        const marker = normalizeText(`${node.id || ''} ${node.className || ''} ${node.getAttribute?.('data-ad') || ''} ${node.textContent || ''}`);
        return /(?:^|\s)(?:ad|ads|advert|advertisement|skip ad|pular anuncio|anuncio|preroll|vast)(?:\s|$)/i.test(marker)
          || /(?:skip|pular).{0,16}(?:ad|anuncio)/i.test(marker);
      });
    }
  } catch (_) {}

  const shortOrFiniteAd = Number.isFinite(duration) && duration > 0 && duration <= 90;
  const isLikelyAd = titleSignal
    || knownAdHost
    || routeSignal
    || inPlayerAdSignal
    || (genericAdHost && (containerSignal || shortOrFiniteAd));

  const reasons = [];
  if (titleSignal) reasons.push('title');
  if (knownAdHost) reasons.push('known-host');
  if (routeSignal) reasons.push('route');
  if (genericAdHost) reasons.push('generic-host');
  if (containerSignal) reasons.push('container');
  if (inPlayerAdSignal) reasons.push('in-player-overlay');

  return {
    isLikelyAd,
    reason: reasons.join(',') || '',
    titleSignal,
    knownAdHost,
    genericAdHost,
    routeSignal,
    containerSignal,
    inPlayerAdSignal
  };
}

function getVisibleVideos() {
  const discovered = Array.from(document.querySelectorAll('video'))
    .map((video, domIndex) => {
      ensureVideoIdentity(video);
      const rect = video.getBoundingClientRect();
      return { video, domIndex, rect, quality: getVideoCandidateQuality(video, rect) };
    })
    .filter(item => item.quality.visible)
    // vídeos ruins continuam existindo na página, mas não entram como candidato normal.
    // isso evita PiP/vínculo em iframe pequeno de anúncio.
    .filter(item => item.quality.candidate);

  // Prioridade:
  // 1) maior pontuação de vídeo principal
  // 2) maior área
  // 3) ordem DOM original
  return discovered
    .sort((a, b) =>
      b.quality.score - a.quality.score ||
      b.quality.area - a.quality.area ||
      a.domIndex - b.domIndex)
    .map((item, visualRank) => ({ ...item, visualRank, index: visualRank }));
}

function getVideoCandidateQuality(video, rect) {
  const width = Math.round(rect.width || video.videoWidth || 0);
  const height = Math.round(rect.height || video.videoHeight || 0);
  const area = Math.max(0, width * height);
  const duration = Number(video.duration || 0);
  const src = String(getVideoSource(video) || '').toLowerCase();
  const host = location.hostname.replace(/^www\./i, '').toLowerCase();
  const pageUrl = String(location.href || '').toLowerCase();
  const intrinsicWidth = Number(video.videoWidth || 0);
  const intrinsicHeight = Number(video.videoHeight || 0);
  const intrinsicRatio = intrinsicHeight > 0 ? intrinsicWidth / intrinsicHeight : 0;

  const visible = width > 20 && height > 20;
  const advertisement = getAdvertisementClassification(video, rect);

  // Sinais fortes de anúncio/banner/iframe auxiliar.
  const verySmall = width < 360 || height < 180 || area < 90000;
  const shortClip = Number.isFinite(duration) && duration > 0 && duration < 30;
  const bannerShape = width > 0 && height > 0 && (width / height >= 2.8 || height / width >= 2.8);
  const adLikeUrl = /(^|[\W_])(ad|ads|advert|banner|promo|vast|prebid|doubleclick|googlesyndication|adnxs|crme|iframe)([\W_]|$)/i.test(src + ' ' + pageUrl);
  // Um criativo curto e ultralargo pode ocupar temporariamente o player
  // principal. A geometria intrínseca identifica esse caso sem depender do site.
  const transientBannerAd = Number.isFinite(duration) && duration > 0 && duration <= 45
    && intrinsicWidth >= 700 && intrinsicRatio >= 3.0;

  // Live/stream normalmente tem duration 0; não punir só por isso.
  const liveLike = !Number.isFinite(duration) || duration <= 0;

  let score = 0;
  score += Math.min(80, area / 8000);
  if (!video.paused && !video.ended) score += 45;
  if (duration >= 30 || liveLike) score += 25;
  if (width >= 480 && height >= 260) score += 25;
  if (width >= 640 && height >= 360) score += 15;
  if (src.includes(host)) score += 10;

  if (verySmall) score -= 60;
  if (shortClip) score -= 45;
  if (bannerShape) score -= 35;
  if (adLikeUrl) score -= 55;
  if (transientBannerAd) score -= 180;

  // Candidato normal: precisa passar o filtro mínimo.
  // Exemplo bloqueado: 300x100 + 12s + iframe/ad.
  const candidate = visible && !advertisement.isLikelyAd && !transientBannerAd && !(
    (verySmall && shortClip) ||
    (verySmall && bannerShape) ||
    (shortClip && adLikeUrl) ||
    (verySmall && adLikeUrl)
  );

  return {
    visible,
    candidate,
    isLikelyAd: advertisement.isLikelyAd,
    adReason: transientBannerAd ? 'intrinsic-banner-short' : advertisement.reason,
    transientBannerAd,
    score,
    area,
    width,
    height,
    duration,
    verySmall,
    shortClip,
    bannerShape,
    adLikeUrl
  };
}

function clickFirstVisible(selectors, targetVideo) {
  const scopedRoots = getCandidateRoots(targetVideo);

  for (const root of scopedRoots) {
    for (const selector of selectors) {
      const elements = Array.from(root.querySelectorAll ? root.querySelectorAll(selector) : []);
      for (const el of elements) {
        if (!isVisible(el)) continue;
        if (clickLikeUser(el)) return true;
      }
    }
  }

  return false;
}

function clickSemanticNavigationControl(direction, targetVideo) {
  const scoreDescriptor = globalThis.PipManagerSiteProfiles?.scoreNavigationDescriptor;
  if (typeof scoreDescriptor !== 'function') return false;

  const interactiveSelector = 'button,a,[role="button"],[role="link"],[tabindex],[data-action],[data-command]';
  const candidates = [];
  const seen = new Set();

  for (const root of getCandidateRoots(targetVideo)) {
    let elements = [];
    try { elements = Array.from(root.querySelectorAll(interactiveSelector)); } catch (_) {}

    for (const el of elements) {
      if (seen.has(el) || !isVisible(el)) continue;
      seen.add(el);

      let icon = '';
      try {
        const iconNode = el.querySelector('svg,use,[data-icon],[class*="icon" i]');
        icon = [
          iconNode?.getAttribute?.('aria-label'), iconNode?.getAttribute?.('data-icon'),
          iconNode?.getAttribute?.('href'), iconNode?.getAttribute?.('xlink:href'),
          iconNode?.getAttribute?.('id'), iconNode?.getAttribute?.('class')
        ].filter(Boolean).join(' ');
      } catch (_) {}

      const descriptor = {
        ariaLabel: el.getAttribute?.('aria-label'),
        title: el.getAttribute?.('title'),
        testId: el.getAttribute?.('data-testid'),
        action: el.getAttribute?.('data-action'),
        command: el.getAttribute?.('data-command'),
        name: el.getAttribute?.('name'),
        id: el.id,
        className: typeof el.className === 'string' ? el.className : el.getAttribute?.('class'),
        text: String(el.textContent || '').slice(0, 160),
        icon,
        disabled: Boolean(el.disabled || el.getAttribute?.('aria-disabled') === 'true')
      };
      const score = scoreDescriptor(direction, descriptor);
      if (score >= 70) candidates.push({ el, score });
    }
  }

  candidates.sort((a, b) => b.score - a.score);
  return candidates.length > 0 && clickLikeUser(candidates[0].el);
}

function clickElementByText(needles, targetVideo) {
  const scopedRoots = getCandidateRoots(targetVideo);
  const selector = 'button,a,[role="button"],[tabindex]';

  for (const root of scopedRoots) {
    const elements = Array.from(root.querySelectorAll ? root.querySelectorAll(selector) : []);
    for (const el of elements) {
      if (!isVisible(el)) continue;
      const text = normalizeText([
        el.getAttribute('aria-label'),
        el.getAttribute('title'),
        el.textContent
      ].filter(Boolean).join(' '));

      if (!text) continue;
      if (needles.some(n => text.includes(normalizeText(n)))) {
        if (clickLikeUser(el)) return true;
      }
    }
  }

  return false;
}

function clickLikeUser(el) {
  try { el.scrollIntoView({ block: 'center', inline: 'center' }); } catch (_) {}

  const rect = el.getBoundingClientRect ? el.getBoundingClientRect() : null;
  const x = rect ? rect.left + rect.width / 2 : 0;
  const y = rect ? rect.top + rect.height / 2 : 0;

  try {
    // The final el.click() below emits the single click.  Dispatching a synthetic
    // click here as well used to invoke site handlers twice and could skip an item.
    for (const type of ['pointerdown', 'mousedown', 'pointerup', 'mouseup']) {
      const eventOptions = {
        bubbles: true,
        cancelable: true,
        composed: true,
        view: window,
        clientX: x,
        clientY: y,
        button: 0,
        buttons: type.endsWith('down') ? 1 : 0
      };

      if (type.startsWith('pointer') && typeof PointerEvent === 'function') {
        el.dispatchEvent(new PointerEvent(type, { ...eventOptions, pointerId: 1, pointerType: 'mouse', isPrimary: true }));
      } else {
        el.dispatchEvent(new MouseEvent(type, eventOptions));
      }
    }
    try { el.click(); } catch (_) {}
    return true;
  } catch (_) {
    try { el.click(); return true; } catch (_) {}
  }

  return false;
}

function tryAdvanceUrlIndex(delta) {
  try {
    const url = new URL(location.href);

    // Escopo restrito a páginas de playlist. O primeiro item de uma playlist
    // muitas vezes ainda não tem ?index= na URL (index implícito = 0), então
    // não podemos exigir o parâmetro já presente para considerar elegível.
    if (!/\/playlists\//i.test(url.pathname)) return false;

    const current = url.searchParams.has('index') ? Number(url.searchParams.get('index')) : 0;
    if (!Number.isFinite(current)) return false;

    const next = Math.max(0, current + delta);
    if (next === current) return false;

    url.searchParams.set('index', String(next));
    location.href = url.toString();
    return true;
  } catch (_) {
    return false;
  }
}

function normalizeText(value) {
  return String(value || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

// Coleta raízes shadow DOM abertas alcançáveis a partir de `root`, de forma limitada
// (número de nós) para não travar em páginas muito grandes. Shadow roots fechados
// (`mode: 'closed'`) não são acessíveis por design do navegador e ficam de fora.
function collectOpenShadowRoots(root, maxNodes) {
  const found = [];
  if (!root || typeof root.querySelectorAll !== 'function') return found;

  let visited = 0;
  const stack = [root];
  while (stack.length && visited < maxNodes) {
    const current = stack.pop();
    let children;
    try { children = current.querySelectorAll('*'); } catch (_) { continue; }

    for (const el of children) {
      visited++;
      if (visited >= maxNodes) break;
      if (el.shadowRoot) {
        found.push(el.shadowRoot);
        stack.push(el.shadowRoot);
      }
    }
  }
  return found;
}

function getCandidateRoots(targetVideo) {
  const roots = [];
  let node = targetVideo;
  for (let i = 0; i < 5 && node; i++) {
    if (node.querySelectorAll) roots.push(node);
    node = node.parentElement;
  }
  roots.push(document);

  // Amplia a busca para dentro de shadow DOM aberta encontrada a partir de qualquer
  // raiz já coletada. Isso cobre players que expõem os controles (incluindo o botão
  // de Picture-in-Picture) dentro de um shadow root, onde querySelectorAll comum nunca
  // enxerga o elemento.
  const shadowRoots = roots.flatMap(r => collectOpenShadowRoots(r, 1500));
  return Array.from(new Set([...roots, ...shadowRoots]));
}

function isVisible(el) {
  const rect = el.getBoundingClientRect();
  const style = window.getComputedStyle(el);
  return rect.width > 0 && rect.height > 0 && style.visibility !== 'hidden' && style.display !== 'none';
}

function dispatchKeyboardChord(options, preferredTarget) {
  return dispatchKeyboardChordStrong(options, preferredTarget);
}

function dispatchKeyboardChordStrong(options, preferredTarget) {
  const targets = [];

  if (preferredTarget) targets.push(preferredTarget);
  if (document.activeElement) targets.push(document.activeElement);
  if (document.body) targets.push(document.body);
  if (document.documentElement) targets.push(document.documentElement);
  targets.push(document);
  targets.push(window);

  try {
    if (preferredTarget && preferredTarget.scrollIntoView) {
      preferredTarget.scrollIntoView({ block: 'center', inline: 'center' });
    }
  } catch (_) {}

  try { preferredTarget && preferredTarget.focus && preferredTarget.focus(); } catch (_) {}
  try { window.focus && window.focus(); } catch (_) {}

  const base = {
    bubbles: true,
    cancelable: true,
    composed: true,
    key: options.key,
    code: options.code,
    keyCode: options.keyCode,
    which: options.keyCode,
    shiftKey: !!options.shiftKey,
    altKey: !!options.altKey,
    ctrlKey: !!options.ctrlKey,
    metaKey: !!options.metaKey
  };

  let sent = false;
  const uniqueTargets = Array.from(new Set(targets.filter(Boolean)));

  for (const target of uniqueTargets) {
    try {
      target.dispatchEvent(new KeyboardEvent('keydown', base));
      sent = true;
    } catch (_) {}
  }

  for (const target of uniqueTargets) {
    try {
      target.dispatchEvent(new KeyboardEvent('keypress', base));
      sent = true;
    } catch (_) {}
  }

  for (const target of uniqueTargets) {
    try {
      target.dispatchEvent(new KeyboardEvent('keyup', base));
      sent = true;
    } catch (_) {}
  }

  return sent;
}

let pipManagerPlaylistCache = { href: '', expiresAt: 0, value: null };
const pipManagerNextMediaCache = new Map();
const pipManagerNextMediaPending = new Set();
const pipManagerNextFullMediaCache = new Map();
let pipManagerNextPreloadEnabled = false;
let pipManagerNextPreloadElement = null;
let pipManagerNextPreloadAssetId = '';
let pipManagerNextPreloadTimer = 0;
let pipManagerNextPreloadHasSlot = false;
let pipManagerNextPreloadSlotHoldTimer = 0;

// Quanto de vídeo tentamos deixar em buffer antes de pausar o download (em vez de
// parar assim que o "canplay" dispara). Mais buffer = mais chance de a troca real
// não precisar rebaixar nada da rede, ao custo de mais banda gasta antecipadamente.
const NEXT_VIDEO_PRELOAD_TARGET_BUFFER_SECONDS = 20;
// Depois de pronto, mantemos o elemento (e o cache HTTP do navegador) vivo por até
// esse tempo esperando a troca real, em vez de destruir tudo poucos segundos depois
// de ficar pronto — o que hoje jogava fora o trabalho de preload antes de ser útil.
const NEXT_VIDEO_PRELOAD_MAX_LIFETIME_MS = 90000;
const NEXT_VIDEO_PRELOAD_MAX_RETRIES = 2;
const NEXT_VIDEO_PRELOAD_RETRY_DELAY_MS = 1500;
const NEXT_VIDEO_PRELOAD_SLOT_WAIT_RETRY_MS = 1500;
const NEXT_VIDEO_PRELOAD_READY_LOG_MAX_ENTRIES = 5;
// Teto de quanto tempo uma única aba pode segurar o slot compartilhado de preload.
// Sem isso, uma conexão lenta numa aba poderia nunca atingir o buffer-alvo e
// bloquear o preload de todas as outras abas até o timeout de 90s inteiro.
const NEXT_VIDEO_PRELOAD_SLOT_MAX_HOLD_MS = 20000;

// assetId -> { readyAt, mediaUrl, warm }. Usado só para telemetria: quando a troca
// real de vídeo acontece, comparamos com isso pra medir se o preload realmente
// ajudou (e por quanto tempo o cache ficou "quente" antes de ser usado).
const pipManagerPreloadReadyLog = new Map();

function isNetworkEligibleForPreload() {
  try {
    const connection = navigator.connection || navigator.webkitConnection || navigator.mozConnection;
    if (!connection) return true;
    if (connection.saveData) return false;
    if (connection.effectiveType && /^(slow-2g|2g|3g)$/i.test(connection.effectiveType)) return false;
    return true;
  } catch (_) {
    return true;
  }
}

function sendNextPreloadDiagnostic(event, assetId, readyState = 0, extra = null) {
  try {
    api().runtime.sendMessage({
      type: 'pipManagerNextPreloadDiagnostic', event, assetId: assetId || '',
      readyState: Number(readyState || 0), enabled: pipManagerNextPreloadEnabled, ts: Date.now(),
      ...(extra || {})
    });
  } catch (_) {}
}

function releaseNextVideoPreloadSlot() {
  if (pipManagerNextPreloadSlotHoldTimer) clearTimeout(pipManagerNextPreloadSlotHoldTimer);
  pipManagerNextPreloadSlotHoldTimer = 0;
  if (!pipManagerNextPreloadHasSlot) return;
  pipManagerNextPreloadHasSlot = false;
  try { api().runtime.sendMessage({ type: 'pipManagerReleasePreloadSlot' }); } catch (_) {}
}

function rememberPreloadReady(assetId, mediaUrl, warm) {
  if (pipManagerPreloadReadyLog.size >= NEXT_VIDEO_PRELOAD_READY_LOG_MAX_ENTRIES && !pipManagerPreloadReadyLog.has(assetId)) {
    const oldestKey = pipManagerPreloadReadyLog.keys().next().value;
    if (oldestKey !== undefined) pipManagerPreloadReadyLog.delete(oldestKey);
  }
  const existing = pipManagerPreloadReadyLog.get(assetId);
  pipManagerPreloadReadyLog.set(assetId, { readyAt: existing?.readyAt || Date.now(), mediaUrl, warm });
}

// Chamado quando qualquer <video> da página começa a tocar de fato. Se o src bater
// com algo que pré-carregamos, mede quanto tempo se passou entre "ficou pronto" e
// "foi realmente usado" — é a métrica que diz se o preload está valendo a pena.
function checkPreloadSwitchTelemetry(video) {
  try {
    if (!video || pipManagerPreloadReadyLog.size === 0) return;
    const src = String(video.currentSrc || video.src || '');
    if (!src) return;
    for (const [assetId, info] of pipManagerPreloadReadyLog.entries()) {
      if (!info || !info.mediaUrl) continue;
      if (src === info.mediaUrl || (assetId && src.includes(assetId))) {
        const switchLatencyMs = Date.now() - info.readyAt;
        sendNextPreloadDiagnostic('switch-observed', assetId, video.readyState, { switchLatencyMs, wasWarm: !!info.warm });
        pipManagerPreloadReadyLog.delete(assetId);
        break;
      }
    }
  } catch (_) {}
}

function cancelNextVideoPreload(reason = 'cancelled') {
  if (pipManagerNextPreloadTimer) clearTimeout(pipManagerNextPreloadTimer);
  pipManagerNextPreloadTimer = 0;
  const previousAssetId = pipManagerNextPreloadAssetId;
  pipManagerNextPreloadAssetId = '';
  if (pipManagerNextPreloadElement) {
    try {
      pipManagerNextPreloadElement.pause();
      pipManagerNextPreloadElement.removeAttribute('src');
      pipManagerNextPreloadElement.load();
      pipManagerNextPreloadElement.remove();
    } catch (_) {}
  }
  pipManagerNextPreloadElement = null;
  releaseNextVideoPreloadSlot();
  if (previousAssetId) {
    // O cache HTTP pode sobreviver à destruição do elemento, mas depois de expirar
    // o tempo de vida não temos mais garantia disso — marca como "não confiável"
    // em vez de apagar, pra telemetria continuar registrando o que aconteceu.
    if (reason === 'lifetime-expired' && pipManagerPreloadReadyLog.has(previousAssetId)) {
      pipManagerPreloadReadyLog.get(previousAssetId).warm = false;
    }
    sendNextPreloadDiagnostic(`cancelled-${reason}`, previousAssetId);
  }
}

async function startNextVideoPreload(assetId, mediaUrl, retryCount = 0) {
  if (!pipManagerNextPreloadEnabled || !assetId || !isPreviewMediaUrl(mediaUrl)) return;
  if (pipManagerNextPreloadAssetId === assetId && pipManagerNextPreloadElement) return;
  if (!isNetworkEligibleForPreload()) {
    sendNextPreloadDiagnostic('skipped-network-conditions', assetId);
    return;
  }

  cancelNextVideoPreload('replaced');

  // Com vários slots de PiP ativos ao mesmo tempo, só deixamos uma aba por vez
  // baixar o "próximo vídeo" pra não competir por banda com quem já está tocando.
  let grant = { granted: true };
  try {
    grant = (await api().runtime.sendMessage({ type: 'pipManagerRequestPreloadSlot', assetId })) || { granted: true };
  } catch (_) {}
  if (!grant.granted) {
    sendNextPreloadDiagnostic('waiting-slot', assetId);
    setTimeout(() => {
      if (pipManagerNextPreloadEnabled) startNextVideoPreload(assetId, mediaUrl, retryCount);
    }, NEXT_VIDEO_PRELOAD_SLOT_WAIT_RETRY_MS);
    return;
  }
  pipManagerNextPreloadHasSlot = true;
  // Segura o slot por no máximo esse tempo; se o buffer-alvo nunca for atingido
  // (conexão lenta, vídeo grande), libera mesmo assim para não travar as outras
  // abas. O download em si continua rolando na aba, só paramos de reservar turno.
  pipManagerNextPreloadSlotHoldTimer = setTimeout(() => releaseNextVideoPreloadSlot(), NEXT_VIDEO_PRELOAD_SLOT_MAX_HOLD_MS);

  const video = document.createElement('video');
  video.preload = 'auto';
  video.muted = true;
  video.playsInline = true;
  video.style.cssText = 'position:fixed;width:1px;height:1px;left:-10000px;top:-10000px;opacity:0;pointer-events:none';

  video.addEventListener('loadedmetadata', () => sendNextPreloadDiagnostic('metadata', assetId, video.readyState), { once: true });

  const onBufferProgress = () => {
    try {
      if (!video.buffered || video.buffered.length === 0) return;
      const bufferedEnd = video.buffered.end(video.buffered.length - 1);
      const bufferedEnough = bufferedEnd >= NEXT_VIDEO_PRELOAD_TARGET_BUFFER_SECONDS
        || (video.duration && Number.isFinite(video.duration) && bufferedEnd >= video.duration - 0.5);
      if (!bufferedEnough) return;
      // Buffer suficiente: pausa o download, mas mantém o elemento (com o src
      // intacto) vivo em vez de destruí-lo — é isso que preserva o cache quente
      // até a troca de vídeo acontecer de verdade.
      video.removeEventListener('progress', onBufferProgress);
      try { video.pause(); } catch (_) {}
      rememberPreloadReady(assetId, mediaUrl, true);
      sendNextPreloadDiagnostic('buffered-paused', assetId, video.readyState, { bufferedSeconds: Math.round(bufferedEnd) });
      releaseNextVideoPreloadSlot();
    } catch (_) {}
  };
  video.addEventListener('progress', onBufferProgress);

  video.addEventListener('canplay', () => {
    sendNextPreloadDiagnostic('ready', assetId, video.readyState);
    rememberPreloadReady(assetId, mediaUrl, true);
  }, { once: true });

  video.addEventListener('error', () => {
    const code = video.error?.code || 'unknown';
    releaseNextVideoPreloadSlot();
    if (retryCount < NEXT_VIDEO_PRELOAD_MAX_RETRIES) {
      const nextAttempt = retryCount + 1;
      sendNextPreloadDiagnostic(`retry-${nextAttempt}-after-error-${code}`, assetId);
      cancelNextVideoPreload(`failed-${code}`);
      setTimeout(() => startNextVideoPreload(assetId, mediaUrl, nextAttempt), NEXT_VIDEO_PRELOAD_RETRY_DELAY_MS * nextAttempt);
    } else {
      cancelNextVideoPreload(`failed-${code}`);
    }
  }, { once: true });

  video.src = mediaUrl;
  document.documentElement.appendChild(video);
  pipManagerNextPreloadElement = video;
  pipManagerNextPreloadAssetId = assetId;
  sendNextPreloadDiagnostic('start', assetId);
  video.load();
  pipManagerNextPreloadTimer = setTimeout(() => cancelNextVideoPreload('lifetime-expired'), NEXT_VIDEO_PRELOAD_MAX_LIFETIME_MS);
}

function setNextVideoPreloadEnabled(enabled) {
  pipManagerNextPreloadEnabled = !!enabled;
  if (!pipManagerNextPreloadEnabled) cancelNextVideoPreload('disabled');
  else {
    const latest = Array.from(pipManagerNextFullMediaCache.entries()).pop();
    if (latest && latest[1]) startNextVideoPreload(latest[0], latest[1]);
  }
  sendNextPreloadDiagnostic('setting', '', 0);
}

function cleanPlaylistTitle(value) {
  return String(value || '').replace(/\s+/g, ' ').trim().slice(0, 180);
}

function normalizeEmbeddedUrl(value) {
  let text = String(value || '').trim();
  if (!text) return '';
  try {
    text = text.replace(/\\u002[fF]/g, '/').replace(/\\\//g, '/').replace(/&amp;/g, '&');
    const url = new URL(text, location.href);
    return url.protocol === 'https:' ? url.href : '';
  } catch (_) {
    return '';
  }
}

function isPreviewMediaUrl(value) {
  const url = normalizeEmbeddedUrl(value);
  if (!url) return false;
  return /\.(?:mp4|webm|m3u8)(?:$|[?#])/i.test(url)
    || /(?:video|stream|manifest|playlist|media)[^?#]*[?&](?:url|src)=/i.test(url);
}

function findNextPreviewVideoUrl(upNextButton, thumbnailUrl) {
  const candidates = [];
  const add = value => {
    const raw = String(value || '').replace(/\\u002[fF]/g, '/').replace(/\\\//g, '/');
    const values = [raw, ...(raw.match(/https?:\/\/[^\s"'<>\\]+/g) || [])];
    for (const valueCandidate of values) {
      const url = normalizeEmbeddedUrl(valueCandidate);
      if (url && isPreviewMediaUrl(url) && !candidates.includes(url)) candidates.push(url);
    }
  };

  try {
    const scope = upNextButton && (upNextButton.closest('[data-video],[data-src],[class*="next"]') || upNextButton);
    for (const node of scope ? [scope, ...scope.querySelectorAll('*')] : []) {
      for (const attribute of Array.from(node.attributes || [])) add(attribute.value);
      if (node instanceof HTMLVideoElement) add(getVideoSource(node));
      if (node instanceof HTMLSourceElement) add(node.src);
    }

    const assetId = String(thumbnailUrl || '').match(/[a-f0-9]{20,}/i)?.[0] || '';
    if (assetId) {
      for (const entry of performance.getEntriesByType('resource')) {
        if (String(entry.name || '').includes(assetId)) add(entry.name);
      }
      for (const script of Array.from(document.scripts)) {
        const text = String(script.textContent || '');
        if (!text.includes(assetId)) continue;
        const decoded = text.replace(/\\u002[fF]/g, '/').replace(/\\\//g, '/');
        const urls = decoded.match(/https:\/\/[^\s"'<>\\]+/g) || [];
        for (const url of urls.slice(0, 40)) if (url.includes(assetId)) add(url);
      }
    }
  } catch (_) {}

  return candidates[0] || '';
}

function readNuxtVideoUrl(html, assetId) {
  try {
    const match = String(html || '').match(/<script[^>]*id=["']__NUXT_DATA__["'][^>]*>([\s\S]+?)<\/script>/i);
    if (!match) return '';
    const data = JSON.parse(match[1]);
    const mediaUrls = data
      .filter(value => typeof value === 'string')
      .map(normalizeEmbeddedUrl)
      .filter(url => isPreviewMediaUrl(url) && (!assetId || url.includes(assetId)));
    const shortPreview = mediaUrls.find(url => /\/videoPreview\/[^/?#]+\.mp4(?:$|[?#])/i.test(url));
    if (shortPreview) return shortPreview;
    const previewMp4 = mediaUrls.find(url => /(?:\/previews?\/|[_-]preview)\S*\.mp4(?:$|[?#])/i.test(url));
    if (previewMp4) return previewMp4;
    const directMp4 = mediaUrls.find(url => /\.mp4(?:$|[?#])/i.test(url));
    if (directMp4) return directMp4;

    // Compatibilidade com o formato antigo de ponteiros usado pelo Nuxt.
    const app = data?.[data?.[0]?.[1]];
    const payload = data?.[app?.data];
    if (!payload || typeof payload !== 'object') return '';
    const inputKey = Object.keys(payload).find(key => key.includes('videoInput'));
    const input = inputKey ? data?.[payload[inputKey]] : null;
    const videoList = data?.[input?.video];
    const video = Array.isArray(videoList) ? data?.[videoList[0]] : null;
    const direct = video && Number.isInteger(video.url) ? data?.[video.url] : video?.url;
    return isPreviewMediaUrl(direct) ? normalizeEmbeddedUrl(direct) : '';
  } catch (_) {
    return '';
  }
}

function readNuxtFullVideoUrl(html, assetId) {
  try {
    const match = String(html || '').match(/<script[^>]*id=["']__NUXT_DATA__["'][^>]*>([\s\S]+?)<\/script>/i);
    if (!match) return '';
    const data = JSON.parse(match[1]);
    const mediaUrls = data.filter(value => typeof value === 'string').map(normalizeEmbeddedUrl)
      .filter(url => isPreviewMediaUrl(url) && (!assetId || url.includes(assetId)));
    return mediaUrls.find(url => /\.mp4(?:$|[?#])/i.test(url) && !/\/videoPreview\/|\/previews?\/|[_-]preview/i.test(url)) || '';
  } catch (_) {
    return '';
  }
}

function findNextVideoPageUrl(upNextButton, assetId, title) {
  try {
    const nodes = upNextButton ? [upNextButton, ...upNextButton.querySelectorAll('*')] : [];
    for (const node of nodes) {
      for (const attribute of Array.from(node.attributes || [])) {
        const raw = String(attribute.value || '');
        if (!raw.includes('/video/')) continue;
        const url = new URL(raw, location.href);
        if (url.origin === location.origin && (!assetId || url.pathname.includes(assetId))) return url.href;
      }
    }
    if (assetId) {
      const escapedId = assetId.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const pattern = new RegExp('(?:https?:\\/\\/[^"\\s<]+)?\\/video\\/[a-zA-Z0-9%_-]+_' + escapedId, 'i');
      for (const script of Array.from(document.scripts)) {
        const match = String(script.textContent || '').replace(/\\u002[fF]/g, '/').replace(/\\\//g, '/').match(pattern);
        if (match) return new URL(match[0], location.href).href;
      }
      const slug = cleanPlaylistTitle(title).normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/gi, '-').replace(/^-|-$/g, '') || 'video';
      return `${location.origin}/video/${encodeURIComponent(slug)}_${assetId}`;
    }
  } catch (_) {}
  return '';
}

// Baixa a próxima página só até o ponto em que o bloco __NUXT_DATA__ termina, em vez
// de esperar a resposta inteira. Essas páginas costumam trazer bastante HTML/JS além
// do que precisamos (só a URL do vídeo embutida nesse bloco), então isso reduz o
// volume de dados baixado para "descobrir" o próximo vídeo — o que importa bastante
// quando isso roda em paralelo com vários PiPs já em reprodução.
async function fetchNuxtDataHtmlPrefix(pageUrl) {
  const MAX_BYTES = 3 * 1024 * 1024; // salvaguarda: nunca lê mais que ~3MB mesmo se o bloco não aparecer
  const controller = new AbortController();
  let response;
  try {
    response = await fetch(pageUrl, { credentials: 'include', cache: 'no-store', headers: { Accept: 'text/html' }, signal: controller.signal });
  } catch (_) {
    return '';
  }
  if (!response.ok) return '';
  if (!response.body || typeof response.body.getReader !== 'function') return await response.text();

  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';
  let readBytes = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      readBytes += value.byteLength;
      buffer += decoder.decode(value, { stream: true });
      const markerIndex = buffer.indexOf('__NUXT_DATA__');
      if (markerIndex !== -1 && /<\/script>/i.test(buffer.slice(markerIndex))) {
        controller.abort();
        break;
      }
      if (readBytes >= MAX_BYTES) {
        controller.abort();
        break;
      }
    }
  } catch (_) {
    // abort() dispara um erro esperado aqui; qualquer outro erro de rede também cai
    // neste catch e devolvemos o que já foi lido até então.
  } finally {
    try { reader.cancel(); } catch (_) {}
  }
  return buffer;
}

function scheduleNextPreviewVideoResolution(upNextButton, thumbnailUrl, title) {
  const assetId = String(thumbnailUrl || '').match(/[a-f0-9]{20,}/i)?.[0] || '';
  if (!assetId || (pipManagerNextMediaCache.has(assetId) && pipManagerNextFullMediaCache.has(assetId)) || pipManagerNextMediaPending.has(assetId)) return;
  const pageUrl = findNextVideoPageUrl(upNextButton, assetId, title);
  if (!pageUrl) return;

  pipManagerNextMediaPending.add(assetId);
  fetchNuxtDataHtmlPrefix(pageUrl)
    .then(html => {
      const mediaUrl = readNuxtVideoUrl(html, assetId);
      const fullMediaUrl = readNuxtFullVideoUrl(html, assetId);
      pipManagerNextMediaCache.set(assetId, mediaUrl);
      pipManagerNextFullMediaCache.set(assetId, fullMediaUrl);
      pipManagerPlaylistCache.expiresAt = 0;
      if (fullMediaUrl) startNextVideoPreload(assetId, fullMediaUrl);
      if (mediaUrl) setTimeout(() => reportVideoState(true), 0);
    })
    .catch(() => pipManagerNextMediaCache.set(assetId, ''))
    .finally(() => pipManagerNextMediaPending.delete(assetId));
}

function readProfilePlaylistCard(profile) {
  if (!profile || profile.contentKind !== 'playlist-capable') return null;

  try {
    if (profile.structuredPlaylist) {
      const items = Array.from(document.querySelectorAll('[data-playlist-item],[role="option"],[class*="playlist" i] [aria-selected]'));
      if (items.length < 2) return null;
      const currentIndex = items.findIndex(item => item.hasAttribute('selected') || item.getAttribute('aria-selected') === 'true');
      if (currentIndex < 0 || currentIndex + 1 >= items.length) return null;
      const current = items[currentIndex];
      const nextCard = items[currentIndex + 1];
      const link = nextCard.querySelector('a[title],a[href]');
      const image = nextCard.querySelector('img');
      const title = cleanPlaylistTitle(link?.getAttribute('title') || link?.textContent || image?.getAttribute('alt'));
      if (!title) return null;
      return {
        playlistDetected: true,
        playlistTitle: cleanPlaylistTitle(document.querySelector('[data-playlist-title],[class*="playlist" i] [class*="title" i]')?.textContent) || 'Playlist',
        playlistIndex: currentIndex,
        currentItemTitle: cleanPlaylistTitle(current.querySelector('a[title],a[href]')?.textContent || document.title),
        nextTitles: items.slice(currentIndex + 1, currentIndex + 6).map(item => cleanPlaylistTitle(item.querySelector('a[title],a[href]')?.getAttribute('title') || item.querySelector('a[title],a[href]')?.textContent)).filter(Boolean),
        nextPreviewTitle: title,
        nextPreviewThumbnailUrl: String(image?.currentSrc || image?.getAttribute('src') || ''),
        nextPreviewVideoUrl: findNextPreviewVideoUrl(nextCard, ''),
        nextPreviewDuration: cleanPlaylistTitle(nextCard.querySelector('[data-duration],[class*="duration" i],[class*="time" i]')?.textContent),
        nextPreviewIndex: currentIndex + 1
      };
    }

    const page = new URL(location.href);
    const playlistKey = page.searchParams.get('pkey') || page.searchParams.get('list') || '';
    const currentKey = page.searchParams.get('viewkey') || page.searchParams.get('v') || '';
    if (!playlistKey || !currentKey) return null;

    const playlistRoots = profile.restrictPlaylistRoots
      ? Array.from(document.querySelectorAll('[class*="playlist" i],[id*="playlist" i],[data-playlist]'))
      : [];
    const anchorNodes = playlistRoots.length
      ? playlistRoots.flatMap(root => Array.from(root.querySelectorAll('a[href]')))
      : Array.from(document.querySelectorAll('a[href]'));
    const findRichCard = anchor => {
      let node = anchor;
      for (let depth = 0; node && depth < 7; depth++, node = node.parentElement) {
        if (node.querySelector?.('img,picture,video,[style*="background-image" i]')) return node;
      }
      return anchor.closest('li,article,[class*="item" i],[class*="video" i],[class*="card" i]') || anchor;
    };
    const readCardThumbnail = card => {
      const media = card?.querySelector?.('img,picture img,source') || null;
      const values = [
        media?.currentSrc, media?.src,
        media?.getAttribute?.('data-src'), media?.getAttribute?.('data-original'),
        media?.getAttribute?.('data-thumb_url'), media?.getAttribute?.('data-mediumthumb'),
        media?.getAttribute?.('data-thumb'), media?.getAttribute?.('data-image'),
        media?.getAttribute?.('srcset'), media?.getAttribute?.('data-srcset')
      ];
      for (const node of card ? [card, ...card.querySelectorAll('[style*="background-image" i],[data-thumb],[data-image]')] : []) {
        values.push(node.getAttribute?.('data-thumb'), node.getAttribute?.('data-image'), node.style?.backgroundImage);
      }
      for (const raw of values.filter(Boolean)) {
        const text = String(raw).trim();
        const cssValue = text.match(/^url\(["']?([\s\S]+)["']?\)$/i)?.[1] || text;
        const candidate = cssValue.trim().split(/\s+/)[0].replace(/,$/, '');
        const normalized = normalizeEmbeddedUrl(candidate);
        if (normalized && !/^data:/i.test(normalized)) return normalized;
      }
      return '';
    };
    const anchors = anchorNodes.map(anchor => {
      try {
        const url = new URL(anchor.getAttribute('href') || '', location.href);
        const itemPlaylistKey = url.searchParams.get('pkey') || url.searchParams.get('list') || '';
        const itemKey = url.searchParams.get('viewkey') || url.searchParams.get('v') || '';
        if (!itemKey || (itemPlaylistKey && itemPlaylistKey !== playlistKey)) return null;
        const card = findRichCard(anchor);
        const image = card.querySelector('img') || anchor.querySelector('img');
        const title = cleanPlaylistTitle(
          anchor.getAttribute('title') || anchor.getAttribute('aria-label') ||
          card.getAttribute?.('data-title') || image?.getAttribute('alt') ||
          card.querySelector?.('[class*="title" i]')?.textContent || '');
        return { anchor, card, image, thumbnailUrl: readCardThumbnail(card), url: url.href, itemKey, title };
      } catch (_) { return null; }
    }).filter(Boolean);

    const uniqueByKey = new Map();
    for (const item of anchors) {
      const previous = uniqueByKey.get(item.itemKey);
      const score = (item.thumbnailUrl ? 4 : 0) + (item.title ? 2 : 0) + (findNextPreviewVideoUrl(item.card, item.thumbnailUrl) ? 8 : 0);
      const previousScore = previous ? ((previous.thumbnailUrl ? 4 : 0) + (previous.title ? 2 : 0) + (findNextPreviewVideoUrl(previous.card, previous.thumbnailUrl) ? 8 : 0)) : -1;
      if (!previous || score > previousScore) uniqueByKey.set(item.itemKey, item);
    }
    const unique = Array.from(uniqueByKey.values());
    if (unique.length < 1) return null;

    let currentIndex = unique.findIndex(item => item.itemKey === currentKey);
    if (currentIndex < 0) {
      currentIndex = unique.findIndex(item =>
        item.card.matches?.('[aria-current="true"],[aria-selected="true"],[class*="active" i],[class*="current" i]'));
    }
    const next = currentIndex >= 0 ? unique[currentIndex + 1] : unique.find(item => item.itemKey !== currentKey);
    if (!next || !next.title) return null;

    const thumbnailUrl = next.thumbnailUrl || readCardThumbnail(next.card);
    const previewVideoUrl = findNextPreviewVideoUrl(next.card, thumbnailUrl);
    return {
      playlistDetected: true,
      playlistTitle: cleanPlaylistTitle(document.querySelector('[class*="playlist" i] h1,[class*="playlist" i] h2,[class*="playlist" i] h3')?.textContent) || 'Playlist',
      playlistIndex: currentIndex,
      currentItemTitle: cleanPlaylistTitle(document.title),
      nextTitles: [next.title],
      nextPreviewTitle: next.title,
      nextPreviewThumbnailUrl: thumbnailUrl,
      nextPreviewVideoUrl: previewVideoUrl,
      nextPreviewDuration: '',
      nextPreviewIndex: currentIndex >= 0 ? currentIndex + 1 : -1
    };
  } catch (_) {
    return null;
  }
}

function readPlaylistContext() {
  const now = Date.now();
  if (pipManagerPlaylistCache.href === location.href && pipManagerPlaylistCache.expiresAt > now)
    return pipManagerPlaylistCache.value;

  const empty = { playlistDetected: false, playlistTitle: '', playlistIndex: -1, currentItemTitle: '', nextTitles: [], nextPreviewTitle: '', nextPreviewThumbnailUrl: '', nextPreviewVideoUrl: '', nextPreviewDuration: '', nextPreviewIndex: -1 };
  let result = empty;
  const siteProfile = getPipManagerSiteProfile();

  // Live-room sites may expose active lists and carousels that resemble a
  // playlist structurally.  Their profile explicitly prevents those elements
  // from creating a false preview below the PiP slot.
  if (siteProfile.playlistDisabled) {
    pipManagerPlaylistCache = { href: location.href, expiresAt: now + 2000, value: empty };
    return empty;
  }

  try {
    const lists = [];
    for (const node of document.querySelectorAll('script[type="application/ld+json"]')) {
      try {
        const raw = JSON.parse(node.textContent || 'null');
        const queue = Array.isArray(raw) ? [...raw] : [raw];
        while (queue.length) {
          const item = queue.shift();
          if (!item || typeof item !== 'object') continue;
          if (item['@graph'] && Array.isArray(item['@graph'])) queue.push(...item['@graph']);
          if (item['@type'] === 'ItemList' && Array.isArray(item.itemListElement)) lists.push(item);
        }
      } catch (_) {}
    }

    for (const list of lists) {
      const entries = list.itemListElement.map((entry, order) => {
        const value = entry && entry.item ? entry.item : entry;
        return {
          title: cleanPlaylistTitle((value && (value.name || value.headline)) || (entry && entry.name)),
          url: String((value && value.url) || (entry && entry.url) || ''),
          position: Number((entry && entry.position) || order + 1)
        };
      }).filter(entry => entry.title);
      let index = entries.findIndex(entry => entry.url && new URL(entry.url, location.href).href === location.href);
      if (index < 0) index = entries.findIndex(entry => entry.url && location.href.startsWith(new URL(entry.url, location.href).href));
      if (entries.length > 1 && index >= 0) {
        result = {
          playlistDetected: true,
          playlistTitle: cleanPlaylistTitle(list.name),
          playlistIndex: index,
          currentItemTitle: entries[index].title,
          nextTitles: entries.slice(index + 1, index + 6).map(entry => entry.title)
        };
        break;
      }
    }

    if (!result.playlistDetected) {
      const activeSelectors = '[aria-current="true"],[aria-current="page"],[aria-selected="true"],[data-active="true"],.playlist-item.active,.playlist-item.current,.episode.active,.episode.current';
      const active = document.querySelector(activeSelectors);
      if (active) {
        const container = active.closest('[role="list"],ol,ul,[class*="playlist"],[class*="episode-list"]') || active.parentElement;
        const nodes = container ? Array.from(container.querySelectorAll('a[href],[role="listitem"],li,[data-title]')) : [];
        const unique = nodes.filter((node, index) => nodes.indexOf(node) === index);
        const entries = unique.map(node => ({
          node,
          title: cleanPlaylistTitle(node.getAttribute('data-title') || node.getAttribute('aria-label') || node.getAttribute('title') || node.textContent)
        })).filter(entry => entry.title);
        const index = entries.findIndex(entry => entry.node === active || entry.node.contains(active) || active.contains(entry.node));
        if (entries.length > 1 && index >= 0) {
          const heading = container && (container.querySelector('[data-playlist-title],h1,h2,h3') || container.previousElementSibling);
          result = {
            playlistDetected: true,
            playlistTitle: cleanPlaylistTitle(heading && heading.textContent),
            playlistIndex: index,
            currentItemTitle: entries[index].title,
            nextTitles: entries.slice(index + 1, index + 6).map(entry => entry.title)
          };
        }
      }
    }

    if (!result.playlistDetected) {
      const profilePlaylist = readProfilePlaylistCard(siteProfile);
      if (profilePlaylist) result = { ...empty, ...profilePlaylist };
    }

    const profileLabels = siteProfile.upNextLabels || [];
    const upNextLabel = Array.from(document.querySelectorAll('p,[role="heading"],h1,h2,h3,h4,h5,h6')).find(node =>
      profileLabels.includes(cleanPlaylistTitle(node.textContent).toLowerCase()));
    let upNextButton = upNextLabel ? upNextLabel.nextElementSibling : null;
    if (upNextButton && upNextButton.tagName !== 'BUTTON') upNextButton = upNextButton.querySelector && upNextButton.querySelector('button');
    if (upNextButton) {
      const image = upNextButton.querySelector('img');
      const heading = upNextButton.querySelector('h1,h2,h3,h4,h5,h6');
      const textLines = String(upNextButton.innerText || '').split(/\r?\n/).map(cleanPlaylistTitle).filter(Boolean);
      const duration = textLines.find(value => /^\d{1,2}:\d{2}(?::\d{2})?$/.test(value)) || '';
      const title = cleanPlaylistTitle((heading && heading.textContent) || (image && image.getAttribute('alt')) || textLines.find(value => value !== duration));
      const thumbnailUrl = image ? String(image.currentSrc || image.getAttribute('src') || '') : '';
      const assetId = thumbnailUrl.match(/[a-f0-9]{20,}/i)?.[0] || '';
      const discoveredVideoUrl = findNextPreviewVideoUrl(upNextButton, thumbnailUrl);
      if (assetId && discoveredVideoUrl) pipManagerNextMediaCache.set(assetId, discoveredVideoUrl);
      scheduleNextPreviewVideoResolution(upNextButton, thumbnailUrl, title);
      const currentIndex = result.playlistIndex >= 0 ? result.playlistIndex : (() => { try { const value = Number.parseInt(new URL(location.href).searchParams.get('index'), 10); return Number.isFinite(value) ? value : -1; } catch (_) { return -1; } })();
      result = {
        ...result,
        playlistDetected: true,
        nextPreviewTitle: title,
        nextPreviewThumbnailUrl: thumbnailUrl,
        nextPreviewVideoUrl: discoveredVideoUrl || (assetId ? (pipManagerNextMediaCache.get(assetId) || '') : ''),
        nextPreviewDuration: duration,
        nextPreviewIndex: currentIndex >= 0 ? currentIndex + 1 : -1,
        nextTitles: title ? [title] : result.nextTitles
      };
    }

    if (!result.playlistDetected) {
      const params = new URL(location.href).searchParams;
      const rawIndex = params.get('index') || params.get('episode') || params.get('item');
      const parsed = rawIndex !== null ? Number.parseInt(rawIndex, 10) : NaN;
      if (Number.isFinite(parsed)) {
        result = { ...empty, playlistDetected: true, playlistIndex: Math.max(0, parsed), currentItemTitle: cleanPlaylistTitle(document.title) };
      }
    }
  } catch (_) {}

  pipManagerPlaylistCache = { href: location.href, expiresAt: now + 2000, value: result };
  return result;
}

function buildSessionPayload(video, item) {
  ensureVideoIdentity(video);
  const rect = item && item.rect ? item.rect : video.getBoundingClientRect();
  const playlist = readPlaylistContext();
  const siteProfile = getPipManagerSiteProfile();
  return {
    type: 'videoSession',
    videoSessionId: getVideoSessionId(video),
    stableVideoKey: getStableVideoKey(video),
    pageInstanceId: PAGE_INSTANCE_ID,
    elementInstanceId: getElementInstanceId(video),
    frameId: 0,
    videoIndex: item ? item.visualRank : 0,
    visualRank: item ? item.visualRank : 0,
    domIndex: item ? item.domIndex : -1,
    title: document.title || '',
    url: location.href,
    normalizedUrl: normalizeUrl(location.href),
    domain: location.hostname.replace(/^www\./i, ''),
    siteProfileId: siteProfile.id,
    siteContentKind: siteProfile.contentKind || 'unknown',
    siteNextStrategy: siteProfile.nextShortcut ? 'keyboard-confirmed' : 'semantic-dom-scan',
    videoSrcHash: hashString(getVideoSource(video)),
    // videoWidth/videoHeight continuam descrevendo a caixa renderizada para os
    // diagnósticos antigos. A autoridade de aspecto do perfil Jogo usa somente
    // as dimensões intrínsecas do stream, que não mudam quando a janela PiP é
    // movida ou redimensionada pelo aplicativo.
    videoWidth: Math.round(rect.width || video.videoWidth || 0),
    videoHeight: Math.round(rect.height || video.videoHeight || 0),
    intrinsicVideoWidth: Math.round(Number(video.videoWidth || 0)),
    intrinsicVideoHeight: Math.round(Number(video.videoHeight || 0)),
    intrinsicAspectRatio: Number(video.videoWidth || 0) > 0 && Number(video.videoHeight || 0) > 0
      ? Number(video.videoWidth) / Number(video.videoHeight)
      : 0,
    candidateScore: item && item.quality ? Math.round(item.quality.score) : 0,
    candidateArea: item && item.quality ? Math.round(item.quality.area) : 0,
    candidateFlags: item && item.quality ? [
      item.quality.verySmall ? 'small' : '',
      item.quality.shortClip ? 'short' : '',
      item.quality.bannerShape ? 'banner-shape' : '',
      item.quality.adLikeUrl ? 'ad-like-url' : '',
      item.quality.isLikelyAd ? `blocked-ad:${item.quality.adReason || 'signal'}` : ''
    ].filter(Boolean).join(',') : '',
    isLikelyAd: !!(item && item.quality && item.quality.isLikelyAd),
    adReason: item && item.quality ? (item.quality.adReason || '') : '',
    durationBucket: getDurationBucket(video),
    hasVideo: true,
    isPlaying: !!(!video.paused && !video.ended),
    readyState: Number(video.readyState || 0),
    paused: !!video.paused,
    ended: !!video.ended,
    hasSource: !!getVideoSource(video),
    currentTime: Number(video.currentTime || 0),
    duration: Number.isFinite(video.duration) ? Number(video.duration || 0) : 0,
    playlistDetected: !!playlist.playlistDetected,
    playlistTitle: playlist.playlistTitle || '',
    playlistIndex: Number.isInteger(playlist.playlistIndex) ? playlist.playlistIndex : -1,
    currentItemTitle: playlist.currentItemTitle || document.title || '',
    nextTitles: Array.isArray(playlist.nextTitles) ? playlist.nextTitles.slice(0, 5) : [],
    nextPreviewTitle: playlist.nextPreviewTitle || '',
    nextPreviewThumbnailUrl: playlist.nextPreviewThumbnailUrl || '',
    nextPreviewVideoUrl: playlist.nextPreviewVideoUrl || '',
    nextPreviewDuration: playlist.nextPreviewDuration || '',
    nextPreviewIndex: Number.isInteger(playlist.nextPreviewIndex) ? playlist.nextPreviewIndex : -1,
    lastSeenUnixMs: Date.now()
  };
}

function sendPictureInPictureEvent(eventName, video) {
  try {
    const rawRect = video.getBoundingClientRect ? video.getBoundingClientRect() : { width: 0, height: 0 };
    const quality = getVideoCandidateQuality(video, rawRect);
    if (quality.isLikelyAd) return;
    const item = getVisibleVideos().find(entry => entry.video === video) || null;
    const payload = buildSessionPayload(video, item);
    api().runtime.sendMessage({
      type: 'pictureInPictureEvent',
      eventName,
      eventUnixMs: Date.now(),
      ...payload
    });
    setTimeout(reportVideoState, 200);
  } catch (_) {}
}

function installPictureInPictureListeners(video) {
  ensureVideoIdentity(video);
  if (video.dataset.pipManagerPipListeners === '1') return;
  video.dataset.pipManagerPipListeners = '1';

  try {
    video.addEventListener('enterpictureinpicture', () => sendPictureInPictureEvent('enter', video), true);
    video.addEventListener('leavepictureinpicture', () => sendPictureInPictureEvent('leave', video), true);
  } catch (_) {}
}

const pipManagerTerminalTimers = new WeakMap();
const PIP_MANAGER_TERMINAL_COOLDOWN_MS = 12000;

function cancelPlaybackTerminalCheck(video) {
  try {
    const timer = pipManagerTerminalTimers.get(video);
    if (timer) clearTimeout(timer);
    pipManagerTerminalTimers.delete(video);
  } catch (_) {}
}

function schedulePlaybackTerminalCheck(video, reason) {
  if (!(video instanceof HTMLVideoElement)) return;

  cancelPlaybackTerminalCheck(video);
  const delayMs = reason === 'ended' ? 300 : 3500;
  const scheduledUrl = location.href;

  const timer = setTimeout(() => {
    pipManagerTerminalTimers.delete(video);
    try {
      ensureVideoIdentity(video);
      const now = Date.now();
      const lastSignalAt = Number(video.dataset.pipManagerTerminalSignalAt || 0);
      if (now - lastSignalAt < PIP_MANAGER_TERMINAL_COOLDOWN_MS) return;

      if (location.href !== scheduledUrl) return;

      const replacementPlaying = getVisibleVideos().some(entry =>
        entry.video !== video && !entry.video.paused && !entry.video.ended);
      if (replacementPlaying) return;

      const source = getVideoSource(video);
      const endedConfirmed = reason === 'ended' && !!video.ended;
      const networkEmpty = typeof HTMLMediaElement !== 'undefined'
        && Number(video.networkState || 0) === Number(HTMLMediaElement.NETWORK_EMPTY || 0);
      const emptiedConfirmed = reason === 'emptied'
        && Number(video.readyState || 0) === 0
        && (!source || !video.isConnected || networkEmpty)
        && !!video.paused;

      if (!endedConfirmed && !emptiedConfirmed) return;

      const terminalRect = video.getBoundingClientRect ? video.getBoundingClientRect() : { width: 0, height: 0 };
      const terminalQuality = getVideoCandidateQuality(video, terminalRect);
      if (terminalQuality.isLikelyAd) return;

      const item = getVisibleVideos().find(entry => entry.video === video) || null;
      const payload = buildSessionPayload(video, item);
      video.dataset.pipManagerTerminalSignalAt = String(now);

      api().runtime.sendMessage({
        ...payload,
        type: 'pipManagerPlaybackTerminal',
        reason: endedConfirmed ? 'ended' : 'emptied-no-source',
        readyState: Number(video.readyState || 0),
        paused: !!video.paused,
        ended: !!video.ended,
        hasSource: !!source,
        eventUnixMs: now
      });
    } catch (_) {}
  }, delayMs);

  pipManagerTerminalTimers.set(video, timer);
}

function handlePlaybackTerminalEvent(event) {
  const video = event && event.target;
  if (!(video instanceof HTMLVideoElement)) return;
  schedulePlaybackTerminalCheck(video, event.type === 'ended' ? 'ended' : 'emptied');
}

function handlePlaybackResumedEvent(event) {
  const video = event && event.target;
  if (video instanceof HTMLVideoElement) cancelPlaybackTerminalCheck(video);
}

const PIP_MANAGER_TIMEUPDATE_REPORT_MS = 2500;
const PIP_MANAGER_STATE_HEARTBEAT_MS = 5000;
const PIP_MANAGER_FORCED_EVENT_DEDUPE_MS = 180;
let pipManagerLastTimeUpdateReportMs = 0;
let pipManagerLastVideoStateSignature = '';
let pipManagerLastVideoStateSentMs = 0;

function throttleReportVideoState() {
  const now = Date.now();
  if (now - pipManagerLastTimeUpdateReportMs < PIP_MANAGER_TIMEUPDATE_REPORT_MS) return;
  pipManagerLastTimeUpdateReportMs = now;
  reportVideoState(false);
}

function buildVideoStateReportSignature(sessions, isActiveTab) {
  return JSON.stringify({
    active: !!isActiveTab,
    sessions: (sessions || []).map(session => ({
      videoSessionId: session.videoSessionId || '',
      stableVideoKey: session.stableVideoKey || '',
      url: session.url || '',
      isPlaying: !!session.isPlaying,
      readyState: Number(session.readyState || 0),
      paused: !!session.paused,
      ended: !!session.ended,
      hasSource: !!session.hasSource,
      currentTimeBucket: Math.floor(Number(session.currentTime || 0) / 5),
      durationBucket: Math.floor(Number(session.duration || 0) / 5)
    }))
  });
}


function sendContentVersionDiagnostic(reason) {
  try {
    api().runtime.sendMessage({
      type: 'pipManagerContentDiagnostic',
      version: CONTENT_VERSION,
      reason,
      url: location.href,
      title: document.title || '',
      domain: location.hostname.replace(/^www\./i, ''),
      pageInstanceId: PAGE_INSTANCE_ID,
      hasReacquireBestVisible: typeof openPictureInPictureReacquireBestVisible === 'function'
        || typeof openPictureInPictureReacquireBestVisibleGlobal === 'function',
      hasSilentStrong: typeof openPictureInPictureSilentStrongForTarget === 'function',
      ts: Date.now()
    });
  } catch (_) {}
}

function buildVideoStateSnapshot() {
  const videos = getVisibleVideos();
  return {
    sessions: videos.map((item) => buildSessionPayload(item.video, item)),
    rawVideoCount: document.querySelectorAll('video').length,
    isActiveTab: document.visibilityState === 'visible',
    snapshotUnixMs: Date.now()
  };
}

function reportVideoState(forceOrEvent, preparedSnapshot = null) {
  try {
    const now = Date.now();
    const force = forceOrEvent === true
      || (!!forceOrEvent && typeof forceOrEvent.type === 'string' && forceOrEvent.type !== 'timeupdate');
    const snapshot = preparedSnapshot || buildVideoStateSnapshot();
    const sessions = snapshot.sessions;
    const isActiveTab = snapshot.isActiveTab;
    const signature = buildVideoStateReportSignature(sessions, isActiveTab);
    const unchanged = signature === pipManagerLastVideoStateSignature;
    const elapsedMs = now - pipManagerLastVideoStateSentMs;

    // Eventos play/playing/canplay podem chegar em sequência no mesmo frame.
    // Mantemos o primeiro imediatamente e descartamos duplicatas idênticas muito próximas.
    if (unchanged && elapsedMs < PIP_MANAGER_FORCED_EVENT_DEDUPE_MS)
      return;

    // timeupdate vira apenas fallback/heartbeat. Mudanças estruturais e eventos explícitos
    // continuam sendo enviados imediatamente.
    if (!force && unchanged && elapsedMs < PIP_MANAGER_STATE_HEARTBEAT_MS)
      return;

    pipManagerLastVideoStateSignature = signature;
    pipManagerLastVideoStateSentMs = now;

    api().runtime.sendMessage({
      type: 'videoSessionsState',
      videoCount: sessions.length,
      rawVideoCount: snapshot.rawVideoCount,
      isActiveTab,
      contentVersion: CONTENT_VERSION,
      pageInstanceId: PAGE_INSTANCE_ID,
      hasReacquireBestVisible: typeof openPictureInPictureReacquireBestVisible === 'function'
        || typeof openPictureInPictureReacquireBestVisibleGlobal === 'function',
      hasSilentStrong: typeof openPictureInPictureSilentStrongForTarget === 'function',
      snapshotUnixMs: snapshot.snapshotUnixMs,
      sessions
    });
  } catch (_) {}
}

function ensureVideoIdentity(video) {
  if (!video.dataset.pipManagerElementInstanceId) {
    video.dataset.pipManagerElementInstanceId = nextElementInstanceId();
  }
  if (!video.dataset.pipManagerSessionId) {
    video.dataset.pipManagerSessionId = `${ELEMENT_SESSION_PREFIX}-${video.dataset.pipManagerElementInstanceId}`;
  }
  if (video.dataset.pipManagerPipListeners !== '1') {
    setTimeout(() => installPictureInPictureListeners(video), 0);
  }
}

function getElementInstanceId(video) {
  ensureVideoIdentity(video);
  return video.dataset.pipManagerElementInstanceId || '';
}

function getVideoSessionId(video) {
  ensureVideoIdentity(video);
  return video.dataset.pipManagerSessionId || '';
}

function getStableVideoKey(video) {
  const domain = location.hostname.replace(/^www\./i, '').toLowerCase();
  const normalizedUrl = normalizeUrl(location.href);
  const durationBucket = getDurationBucket(video);
  const srcHash = hashString(getVideoSource(video));
  const sizeBucket = getSizeBucket(video);

  // Chave estável não depende mais de ordem visual/índice DOM.
  // Se houver mais de um player com a mesma assinatura, o comando trata como ambíguo
  // e falha com clareza em vez de comandar o player errado.
  return `svk:${domain}:${hashString(normalizedUrl)}:d${durationBucket}:s${sizeBucket}:src${srcHash}`;
}

function normalizeUrl(url) {
  try {
    const u = new URL(url);
    const remove = ['utm_source','utm_medium','utm_campaign','utm_term','utm_content','fbclid','gclid','si','feature','ab_channel'];
    for (const key of remove) u.searchParams.delete(key);
    u.hash = '';
    u.hostname = u.hostname.replace(/^www\./i, '').toLowerCase();
    return u.toString();
  } catch (_) {
    return String(url || '').split('#')[0];
  }
}

function getDurationBucket(video) {
  const duration = Number(video.duration || 0);
  if (!Number.isFinite(duration) || duration <= 0) return 0;
  return Math.round(duration / 5) * 5;
}

function getSizeBucket(video) {
  const w = Number(video.videoWidth || video.getBoundingClientRect().width || 0);
  const h = Number(video.videoHeight || video.getBoundingClientRect().height || 0);
  const wb = Math.round(w / 80) * 80;
  const hb = Math.round(h / 80) * 80;
  return `${wb}x${hb}`;
}

function getVideoSource(video) {
  return video.currentSrc || video.src || Array.from(video.querySelectorAll('source')).map(s => s.src).find(Boolean) || '';
}

function hashString(value) {
  const text = String(value || '');
  let hash = 2166136261;
  for (let i = 0; i < text.length; i++) {
    hash ^= text.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return (hash >>> 0).toString(36);
}

if (!PIP_MANAGER_AUXILIARY_CONTEXT) {
  try {
    const preloadSetting = api().runtime.sendMessage({ type: 'pipManagerGetNextPreloadSetting' });
    if (preloadSetting && typeof preloadSetting.then === 'function')
      preloadSetting.then(result => setNextVideoPreloadEnabled(!!result?.enabled)).catch(() => {});
  } catch (_) {}
  reportVideoState();
  setTimeout(checkPendingReopenAfterNavigation, 500);
  document.addEventListener('play', handlePlaybackResumedEvent, true);
  document.addEventListener('play', reportVideoState, true);
  document.addEventListener('playing', handlePlaybackResumedEvent, true);
  document.addEventListener('playing', reportVideoState, true);
  document.addEventListener('playing', (event) => checkPreloadSwitchTelemetry(event.target), true);
  document.addEventListener('canplay', handlePlaybackResumedEvent, true);
  document.addEventListener('canplay', reportVideoState, true);
  document.addEventListener('timeupdate', throttleReportVideoState, true);
  document.addEventListener('pause', reportVideoState, true);
  document.addEventListener('loadedmetadata', handlePlaybackResumedEvent, true);
  document.addEventListener('loadedmetadata', reportVideoState, true);
  document.addEventListener('emptied', handlePlaybackTerminalEvent, true);
  document.addEventListener('emptied', reportVideoState, true);
  document.addEventListener('ended', handlePlaybackTerminalEvent, true);
  document.addEventListener('ended', reportVideoState, true);
  document.addEventListener('visibilitychange', reportVideoState, true);
}
