# MoveCapturedGroup + Fixed Layout no-op fix

Correções cirúrgicas sobre a base 9.39.01 Final Stable:

1. `MoveCapturedGroup` não lança mais `ArgumentException` quando o grupo fica maior que a tela por arredondamento de 1 px. Os limites de `Math.Clamp` são normalizados antes do uso.
2. `QueueApplyFixedSlotGeometry` não cria mais sequências assíncronas quando o slot já está dentro da tolerância da posição fixa.
3. `ApplyFixedSlotGeometryNow` retorna imediatamente quando não há deslocamento real, evitando refresh e log `changed=False`.

Nenhuma lógica de áudio, playlist, AutoReturn, pareamento, captura ou redimensionamento foi adicionada ou alterada.
