# Parte 4 — estrutura de projetos

## Objetivo

Separar código de produto, testes e benchmarks sem modificar comportamento.
Esta etapa não altera regras de Next, AutoReturn, descoberta, slots, layout ou
protocolo da extensão.

## Estrutura final

```text
PiPManager.sln
src/
  PiPManager.Wpf/
  PiPManager.Core/
  PiPManager.Extension/
  PiPManager.Native/
tests/
  PiPManager.Core.Tests/
  PiPManager.WindowEventMonitor.Tests/
  Extension.Tests/
benchmarks/
  PiPManager.LayoutBenchmarks/
tools/
  checks/
docs/
  consolidation/
  stabilization/
```

Os scripts canônicos de build, CI e validação permanecem na raiz para oferecer
um ponto de entrada estável.

## Ajustes de integração

- `ProjectReference` e arquivos vinculados usam os novos caminhos relativos.
- A DLL validada está em `src/PiPManager.Native/prebuilt/` e continua sendo
  copiada para build e publicação.
- Os testes JavaScript carregam a extensão de `src/PiPManager.Extension/`.
- Build, CI, benchmark, empacotamento e os 67 checks usam a nova árvore.
- Os manifestos de arquitetura e limites de camada registram os novos donos.

## Validação

- Restore dos quatro projetos executáveis/testáveis: aprovado.
- Testes da extensão: aprovados.
- Gate completo: `ALL TESTS AND CHECKS OK`.
- Build WPF Release: zero erros e zero avisos.
- Resultado: `STABILIZATION GATE PASSED: layer=All; full=True`.
