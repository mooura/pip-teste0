namespace PiPManager.Wpf.Models;

internal sealed class NextPreviewCommandBarrier
{
    public int SlotNumber { get; init; }
    public string CurrentAssetId { get; init; } = string.Empty;
    public string CommandTargetAssetId { get; init; } = string.Empty;
    public int CurrentIndex { get; init; } = -1;
    public int NextIndex { get; init; } = -1;
    public int TargetGeneration { get; init; }
    public string TargetOperationId { get; init; } = string.Empty;
    public DateTime StartedUtc { get; init; } = DateTime.UtcNow;
}
