# PIP FIX7 Hotfix 3 — alvo imutável e estado explícito do preview

Versão da extensão: `1.4.39.21-reconnect-ownership-geometry-hotfix6`.

## Correções

- o alvo mostrado antes do clique é congelado como `CommandTarget` e enviado por WPF → background → content script;
- em páginas de playlist, a navegação usa o `nextIndex` congelado na mesma URL de playlist;
- o preview anterior entra em `STALE` e é removido imediatamente ao clicar em Próximo;
- o WPF mantém uma barreira até o vídeo comandado ser alcançado e o próximo alvo da nova posição ficar resolvido;
- estados do preview: `EMPTY`, `RESOLVING_TARGET`, `READY_METADATA`, `RESOLVING_MEDIA`, `READY_ANIMATED`, `STALE`, `UNAVAILABLE`;
- o `reopen-current-player` é bloqueado desde o início da geração de navegação e não apenas depois que o resolver aparece;
- todos os eventos do preload herdam contexto por `operationId`;
- buffer-alvo do vídeo auxiliar reduzido para 10 segundos.

## Limites de segurança

- a barreira do preview permanece ativa até o novo vídeo e o próximo alvo da nova posição serem confirmados;
- se a página não produzir um alvo novo, a barreira expira de forma controlada após 12 segundos;
- o preview não chama `requestPictureInPicture()` e não depende de ativação do usuário;
- o Hotfix 2 de rechecagem de readiness em 250 ms permanece ativo.
