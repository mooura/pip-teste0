namespace PiPManager.Wpf.Services;

public static class ReleaseInfoConstants
{
    public const string ProductVersion = "9.39.01";
    public const string AppVersion = "1.5.12.3901";
    public const string CoreVersion = "net8.0";
    public const string ExtensionVersion = "1.4.39.25";
    public const string CompatibleExtensionVersionPrefix = "1.4.39.";
    public const string CoreExecutionMode = "ReactorCompareDefault-ManagedLayoutDefault";
    public const string BuildLine = "Consolidation Block C: Unified Authority + Measured Native Retirement; Phase 12: AutoAdvance Safety + Fresh Target Recovery; Relative Group Layout + Batched Recovery; Flush Reservation + Ten-Source Stabilization + Aspect-Aware Slots; Adaptive Next Preload + LRU3 + Bounded Backoff; Aux Video Isolation Phase 1; Deterministic Next Target Resolver Phase 2; Generation-safe Target State Machine Phase 3; Next + Preview Recovery Hotfix 1; Authoritative Preview + Silent Readiness Hotfix 2; Immutable Command Target + Explicit Preview State Hotfix 3; Next Priority + Fast Return + Network Cap Hotfix 4; Terminal Auto-Next Identity + Bounded Readiness Hotfix 5; Cross-Browser HWND Ownership + Reconnect Geometry Authority Hotfix 6; Universal Slot Geometry + Command Preload Handoff Hotfix 7; Real Buffer Handoff + Trusted Manual Geometry Hotfix 8; Byte-Capped Range Preload + Temporary Cache Hotfix 9";
}

public interface IReleaseInfoService
{
    string ProductVersion { get; }
    string AppVersion { get; }
    string CoreVersion { get; }
    string ExtensionVersion { get; }
    string CoreExecutionMode { get; }
    string BuildLine { get; }
    string StartupBanner { get; }
}

public sealed class ReleaseInfoService : IReleaseInfoService
{
    public string ProductVersion => ReleaseInfoConstants.ProductVersion;
    public string AppVersion => ReleaseInfoConstants.AppVersion;
    public string CoreVersion => ReleaseInfoConstants.CoreVersion;
    public string ExtensionVersion => ReleaseInfoConstants.ExtensionVersion;
    public string CoreExecutionMode => ReleaseInfoConstants.CoreExecutionMode;
    public string BuildLine => ReleaseInfoConstants.BuildLine;

    public string StartupBanner =>
        $"pipmanager-startup: product={ProductVersion}; app={AppVersion}; extension={ExtensionVersion}; core={CoreVersion}; mode={CoreExecutionMode}; line={BuildLine}";
}
