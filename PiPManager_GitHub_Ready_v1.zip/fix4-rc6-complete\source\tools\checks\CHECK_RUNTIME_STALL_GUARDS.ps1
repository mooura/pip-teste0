$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$mainPath = Join-Path $root 'src\PiPManager.Wpf\MainWindow.xaml.cs'
$bridgePath = Join-Path $root 'src\PiPManager.Wpf\Services\ExtensionBridgeService.cs'
$monitorPath = Join-Path $root 'src\PiPManager.Wpf\Services\WindowsEventMonitorService.cs'
$main = Get-Content -Raw -LiteralPath $mainPath
$bridge = Get-Content -Raw -LiteralPath $bridgePath
$monitor = Get-Content -Raw -LiteralPath $monitorPath

$checks = [ordered]@{
    'snapshot request gate exists' = $bridge.Contains('private readonly SemaphoreSlim _snapshotRequestGate = new(1, 1);')
    'snapshot requests coalesce' = $bridge.Contains('SnapshotRequestCoalesceMs = 250') -and $bridge.Contains('nowUnixMs - previousUnixMs < SnapshotRequestCoalesceMs')
    'content diagnostics throttled' = $bridge.Contains('ContentDiagnosticLogThrottleMs = 15_000') -and $bridge.Contains('var shouldLog = frameId == 0')
    'iframe diagnostics counted instead of logged' = $bridge.Contains('Interlocked.Increment(ref _suppressedContentDiagnosticCount)')
    'content diagnostics do not enter UI status' = $bridge.Contains('Do not post diagnostic chatter to StatusChanged/UI.')
    'defensive UI diagnostic guard exists' = $main.Contains('message.StartsWith("Content script ativo", StringComparison.OrdinalIgnoreCase)')
    'window movement avoids WPF dispatch' = $main.Contains('Do not allocate a WPF') -and $main.Contains('if (ev.Kind == WindowMonitorEventKind.MovedOrResized)')
    'health and automation timers use background priority' = $main.Contains('new DispatcherTimer(DispatcherPriority.Background)')
    'movement event logging throttled' = $monitor.Contains('MovementLogThrottleMs = 1500') -and $monitor.Contains('dedupeWindowMs = kind == WindowMonitorEventKind.MovedOrResized ? 250 : 120')
    'layout self moves bypass event pipeline' = $monitor.Contains('_flowControl.ShouldSuppressMovement') -and $main.Contains('_windowEventFlowControl')
    'auto return preserves browser process' = $main.Contains('ExpectedBrowserProcess') -and $main.Contains('pendingState.ExpectedBrowserProcess')
    'auto return refreshes stale tab identity' = $main.Contains('ResolveFreshAutoReturnTabSnapshot') -and $main.Contains('auto-return-target-refreshed')
}

$failed = @()
foreach ($item in $checks.GetEnumerator()) {
    if ($item.Value) {
        Write-Host ($item.Key + ': OK')
    } else {
        Write-Host ($item.Key + ': FAIL')
        $failed += $item.Key
    }
}

if ($failed.Count -gt 0) {
    throw "Runtime stall guard checks failed: $($failed -join ', ')"
}

Write-Host 'Runtime stall guard checks OK.'
