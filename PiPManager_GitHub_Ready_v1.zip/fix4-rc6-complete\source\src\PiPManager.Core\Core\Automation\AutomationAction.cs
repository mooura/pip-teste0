﻿using System;

namespace PiPManager.Core.Automation;

/// <summary>
/// Ação decidida pelo AutomationEngine.
/// Nesta fundação, as ações ainda são descritivas para futura ligação com serviços reais.
/// </summary>
public abstract record AutomationAction(
    Guid ActionId,
    DateTimeOffset CreatedAt,
    int SlotNumber,
    string AttemptId)
{
    public virtual string Name => GetType().Name;
}

public sealed record OpenNativePipAction(
    int SlotNumber,
    int? TabId,
    string AttemptId)
    : AutomationAction(Guid.NewGuid(), DateTimeOffset.UtcNow, SlotNumber, AttemptId);

public sealed record StartReconnectAction(
    int SlotNumber,
    string AttemptId)
    : AutomationAction(Guid.NewGuid(), DateTimeOffset.UtcNow, SlotNumber, AttemptId);

public sealed record NoAutomationAction(
    int SlotNumber,
    string AttemptId,
    string Reason)
    : AutomationAction(Guid.NewGuid(), DateTimeOffset.UtcNow, SlotNumber, AttemptId);
