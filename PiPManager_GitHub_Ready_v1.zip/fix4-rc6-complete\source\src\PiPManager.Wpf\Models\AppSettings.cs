﻿namespace PiPManager.Wpf.Models;

public sealed class AppSettings
{
    public int InterfaceVersion { get; set; } = 4;
    public int SlotCount { get; set; } = 4;
    public LayoutMode LayoutMode { get; set; } = LayoutMode.GridTwoColumns;
    public double MainLeft { get; set; } = double.NaN;
    public double MainTop { get; set; } = double.NaN;
    public double MainWidth { get; set; } = 500;
    public double MainHeight { get; set; } = 360;
    public List<SlotLayoutItem> SlotLayout { get; set; } = [];
    public List<SlotLayoutItem> CustomSlotLayout { get; set; } = [];
    public string AutoReturnPolicy { get; set; } = "Off";
    public Dictionary<int, bool> AutoReturnDiscreteBySlot { get; set; } = [];
    public bool AutomaticReactorCaptureEnabled { get; set; } = true;
    public bool AutoAdvanceOnVideoEndEnabled { get; set; } = true;
    public bool NextVideoPreviewEnabled { get; set; } = false;
    public bool NextVideoPreloadEnabled { get; set; } = false;
    public Dictionary<int, bool> NextVideoPreloadBySlot { get; set; } = [];
    public string LayoutMonitorDeviceName { get; set; } = string.Empty;
    public string NativeLayoutEngineMode { get; set; } = "Off";

    // Perfil Jogo: após a primeira troca manual entre slots, esta ordem visual
    // preserva quais posições pertencem ao topo e quais pertencem à lateral.
    public bool JogoManualPlacementEnabled { get; set; } = false;
    public List<int> JogoVisualSlotOrder { get; set; } = [];
    public List<int> JogoTopSlots { get; set; } = [];

    // Jogo livre: reduz proporcionalmente todo o L de PiPs, ancorado no canto
    // superior direito. 100% mantém o perfil automático original; valores menores
    // ampliam a área livre sem deformar os vídeos.
    public bool JogoFreeAreaEnabled { get; set; } = false;
    public double JogoLayoutScale { get; set; } = 0.85;

    // Autoridades independentes do Jogo livre. Zero mantém o grupo automático.
    // Valores positivos representam a largura de um PiP do grupo como fração
    // da largura útil do monitor e sobrevivem a reinício e troca de HWND.
    public double JogoTopWidthRatio { get; set; } = 0.0;
    public double JogoSideWidthRatio { get; set; } = 0.0;

    // Atalho global opcional, registrado somente enquanto o perfil Jogo está ativo.
    // Sem o perfil Jogo, a barra de espaço permanece livre para o aplicativo em foco.
    public bool JogoSpaceHideHotkeyEnabled { get; set; } = false;

    // Layout fixo personalizado: os retângulos passam a ser a autoridade de geometria
    // para captura, reconexão e retorno de cada slot.
    public bool FixedCustomLayoutEnabled { get; set; } = false;
    public bool RespectFixedLayoutAreaEnabled { get; set; } = false;
    public List<SlotLayoutItem> FixedSlotLayout { get; set; } = [];
    public RelativeGroupLayout? RelativeFixedLayout { get; set; }

    // Posição manual da barrinha recolhida.
    // Mantém a alça minimalista onde o usuário deixou ao reiniciar o programa.
    public double ToolbarCollapsedLeft { get; set; } = double.NaN;
    public double ToolbarCollapsedTop { get; set; } = double.NaN;
}


public sealed class SlotLayoutItem
{
    public int Left { get; set; }
    public int Top { get; set; }
    public int Right { get; set; }
    public int Bottom { get; set; }

    public NativeRect ToRect() => new(Left, Top, Right, Bottom);
    public static SlotLayoutItem FromRect(NativeRect rect) => new()
    {
        Left = rect.Left,
        Top = rect.Top,
        Right = rect.Right,
        Bottom = rect.Bottom
    };
}
