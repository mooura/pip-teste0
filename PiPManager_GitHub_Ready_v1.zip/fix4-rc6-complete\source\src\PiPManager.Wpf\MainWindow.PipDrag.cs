using PiPManager.Wpf.Models;
using PiPManager.Wpf.Services;
using PiPManager.Core.Automation;

namespace PiPManager.Wpf;

public partial class MainWindow
{
    private IntPtr _manualResizeCandidateHandle = IntPtr.Zero;
    private NativeRect _manualResizeCandidateStartRect;

    private void RefreshPipDragTargets()
    {
        // Atualiza os alvos do hook global.
        // O PiP clicado vira a âncora natural do grupo.
        if (_naturalAnchorDragActive) return;

        if (_allHidden)
        {
            _pipMouseDragService.ClearTargets();
            return;
        }

        // Mantém os PiPs como alvos do hook mesmo quando o grupo está solto.
        // Assim um clique direto na janela PiP real sempre atualiza o PiP selecionado.
        var targets = GetOccupiedSlotsInNumberOrder()
            .Where(slot => slot.Window is not null && PipWindowService.IsUsable(slot.Window.Handle))
            .Select(slot => new DragTargetInfo(slot.Window!.Handle, PipWindowService.GetVisualRect(slot.Window.Handle)))
            .Where(item => item.Rect.IsValid)
            .ToArray();

        _pipMouseDragService.UpdateTargets(targets);
    }

    private void ClearPipDragTargets()
    {
        // Limpa os alvos e o estado do arraste por âncora natural.
        _pipMouseDragService.ClearTargets();
        _naturalAnchorDragActive = false;
        _naturalAnchorDragHandle = IntPtr.Zero;
        _naturalAnchorStartRects.Clear();
        _naturalAnchorRawOffsets.Clear();
        _naturalAnchorVisualOffsets.Clear();
        _naturalAnchorStartBounds = default;
        _manualResizeCandidateHandle = IntPtr.Zero;
        _manualResizeCandidateStartRect = default;
        ResetJogoManualResizeCandidate();
    }

    private void NaturalAnchorDragStarted(IntPtr handle, int screenX, int screenY)
    {
        if (_allHidden) return;

        // O hook pode entregar um último mouse-down/foreground para um HWND no mesmo
        // instante em que o usuário fecha o PiP. Isso não é um arraste. Antes este
        // caminho purgava o slot completo e apagava tabId/session/stableVideoKey já
        // reservados pelo AutoReturn.
        if (!PipWindowService.IsUsable(handle))
        {
            AppLogger.Info(
                $"natural-anchor-drag-ignored-destroyed-hwnd: handle=0x{handle.ToInt64():X}; " +
                "pairMetadataPreserved=True");
            RefreshPipDragTargets();
            return;
        }

        // Remove imediatamente qualquer slot que ainda aponte para uma janela já
        // destruída/inutilizável antes de montar o modelo do arraste. Um slot com
        // handle morto produz um retângulo inválido e antes disso era simplesmente
        // descartado no meio do cálculo, disparando o aviso enganoso de
        // "HWND duplicado" mesmo quando não havia duplicidade real.
        PurgeDestroyedSlotReferences("NaturalAnchorDragStarted");

        var occupied = GetUsableOccupiedSlotsForDrag();
        var anchorSlot = occupied.FirstOrDefault(slot => slot.Window?.Handle == handle);
        if (occupied.Length == 0 || anchorSlot is null) return;

        _manualResizeCandidateHandle = handle;
        _manualResizeCandidateStartRect = PipWindowService.GetVisualRect(handle);

        // Seleção independente do arraste:
        // clicar em qualquer PiP real atualiza imediatamente o selecionado,
        // mesmo quando o grupo está solto.
        SelectSlotFromPipClick(anchorSlot, setStatus: true);

        if (!_groupLocked) return;

        // Arraste por âncora natural: o PiP clicado vira a âncora do grupo.
        // O hook NÃO bloqueia o clique. O Zen/Firefox move a âncora normalmente.
        // O programa apenas move os outros PiPs para âncora + offset salvo.

        var anchorRect = PipWindowService.GetVisualRect(handle);
        if (!anchorRect.IsValid) return;

        _naturalAnchorDragActive = true;
        _naturalAnchorDragHandle = handle;
        LogAnchorRectDropReasons(occupied, "NaturalAnchorDragStarted");
        _naturalAnchorStartRects = occupied
            .Where(slot => slot.Window is not null)
            .Select(slot => new { slot.Window!.Handle, Rect = PipWindowService.GetVisualRect(slot.Window.Handle) })
            .Where(item => item.Rect.IsValid)
            .GroupBy(item => item.Handle)
            .ToDictionary(group => group.Key, group => group.First().Rect);

        _naturalAnchorRawOffsets = BuildRawOffsetsForDrag(occupied);
        _naturalAnchorVisualOffsets = _naturalAnchorStartRects
            .Where(pair => pair.Key != handle)
            .ToDictionary(
                pair => pair.Key,
                pair => (OffsetX: pair.Value.Left - anchorRect.Left, OffsetY: pair.Value.Top - anchorRect.Top));

        _naturalAnchorStartBounds = GetBounds(_naturalAnchorStartRects.Values.ToArray());
        _lastNaturalAnchorDragMoveUtc = DateTime.MinValue;
        _lastNaturalAnchorDragDx = 0;
        _lastNaturalAnchorDragDy = 0;

        if (_naturalAnchorStartBounds.IsValid)
            _lastKnownGroupBounds = _naturalAnchorStartBounds;
        SetStatus("Arrastando grupo pelo PiP âncora");
    }

    private void NaturalAnchorDragDelta(IntPtr handle, int screenX, int screenY)
    {
        // O redimensionamento continua 100% nativo do Firefox/Zen. Quando o
        // tamanho da janela sob o mouse muda, o PiPManager apenas observa o gesto
        // e não move, redimensiona nem recompõe os demais PiPs durante o arraste.
        if (IsJogoManualResizeInProgress(handle))
            return;
        ApplyNaturalAnchorDrag(force: false);
    }

    private void NaturalAnchorDragCompleted(IntPtr handle, int screenX, int screenY)
    {
        var jogoManualResizeRecorded = RecordCompletedManualResize(handle);
        if (jogoManualResizeRecorded)
        {
            ResetNaturalAnchorDragAfterJogoResize();
            return;
        }
        if (!_naturalAnchorDragActive) return;

        ApplyNaturalAnchorDrag(force: true);

        // Mesma limpeza ao finalizar: uma janela pode ter sido destruída durante o
        // próprio arraste (ex.: fechada pelo navegador). Purga antes de recalcular
        // para não confundir isso com HWND duplicado.
        PurgeDestroyedSlotReferences("NaturalAnchorDragCompleted");

        var occupied = GetUsableOccupiedSlotsForDrag();
        LogAnchorRectDropReasons(occupied, "NaturalAnchorDragCompleted");
        var finalRects = occupied
            .Where(slot => slot.Window is not null && PipWindowService.IsUsable(slot.Window.Handle))
            .Select(slot => new { slot.Window!.Handle, Rect = PipWindowService.GetVisualRect(slot.Window.Handle) })
            .Where(item => item.Rect.IsValid)
            .GroupBy(item => item.Handle)
            .ToDictionary(group => group.Key, group => group.First().Rect);

        if (finalRects.Count > 0)
        {
            _lockedGroupModelRects = finalRects;
            _lockedGroupModelBounds = GetBounds(finalRects.Values.ToArray());
            _lastKnownGroupBounds = _lockedGroupModelBounds;

            if (_fixedCustomLayoutEnabled && _naturalAnchorStartBounds.IsValid && _lockedGroupModelBounds.IsValid)
            {
                var fixedDx = _lockedGroupModelBounds.Left - _naturalAnchorStartBounds.Left;
                var fixedDy = _lockedGroupModelBounds.Top - _naturalAnchorStartBounds.Top;
                OffsetFixedSlotAuthority(fixedDx, fixedDy, "natural-anchor-drag-completed");
            }
        }

        _naturalAnchorDragActive = false;
        _naturalAnchorDragHandle = IntPtr.Zero;
        _naturalAnchorVisualOffsets.Clear();
        _naturalAnchorRawOffsets.Clear();
        _naturalAnchorStartRects.Clear();
        _naturalAnchorStartBounds = default;
        _lastNaturalAnchorDragMoveUtc = DateTime.MinValue;
        _lastNaturalAnchorDragDx = 0;
        _lastNaturalAnchorDragDy = 0;

        // Consolida inclusive a âncora em uma única transação Win32 no fim do gesto.
        // Durante o arraste a janela sob o mouse continua sendo movida naturalmente pelo
        // navegador; o lote final elimina qualquer diferença residual entre os HWNDs.
        ApplyLockedGroupModelOnce();
        if (_fixedCustomLayoutEnabled)
            ApplyFixedLayoutToAllActive(
                CurrentLayout == LayoutMode.Jogo
                    ? "natural-anchor-drag-final/jogo-reanchor"
                    : "natural-anchor-drag-final");
        RefreshSlotsFromLockedModel();
        CaptureCurrentRectsIntoSlotLayout();
        PositionToolbar();
        SaveSettings();
        RefreshPipDragTargets();
        SetStatus(_fixedCustomLayoutEnabled && CurrentLayout == LayoutMode.Jogo
            ? "Perfil Jogo fixo restaurado após o ajuste"
            : "Grupo movido pelo PiP âncora");
    }

    private bool RecordCompletedManualResize(IntPtr handle)
    {
        if (handle == IntPtr.Zero || handle != _manualResizeCandidateHandle || !_manualResizeCandidateStartRect.IsValid)
        {
            ResetJogoManualResizeCandidate();
            return false;
        }

        var start = _manualResizeCandidateStartRect;
        var finalRect = PipWindowService.GetVisualRect(handle);
        _manualResizeCandidateHandle = IntPtr.Zero;
        _manualResizeCandidateStartRect = default;
        if (!finalRect.IsValid
            || (Math.Abs(finalRect.Width - start.Width) <= LayoutMoveSizeTolerancePx
                && Math.Abs(finalRect.Height - start.Height) <= LayoutMoveSizeTolerancePx))
        {
            ResetJogoManualResizeCandidate();
            return false;
        }

        var slot = Slots.FirstOrDefault(item => item.Window?.Handle == handle);
        if (slot is null)
        {
            ResetJogoManualResizeCandidate();
            return false;
        }

        ClearFixedLayoutExternalResizeEcho(handle, "manual-resize-committed");
        _lastManuallyResizedSlotNumber = slot.Number;
        AppLogger.Info(
            $"manual-pip-resize-reference-recorded: slot={slot.Number}; hwnd=0x{handle.ToInt64():X}; " +
            $"before={FormatRect(start)}; after={FormatRect(finalRect)}");

        if (CurrentLayout == LayoutMode.Jogo)
        {
            CommitJogoManualResizeReference(slot, finalRect);
            ResetJogoManualResizeCandidate();
            return true;
        }

        CommitManualFixedSlotResize(slot.Number, finalRect);
        ResetJogoManualResizeCandidate();
        return false;
    }

    private bool IsJogoManualResizeInProgress(IntPtr handle)
    {
        if (CurrentLayout != LayoutMode.Jogo
            || handle == IntPtr.Zero
            || handle != _manualResizeCandidateHandle
            || !_manualResizeCandidateStartRect.IsValid)
            return false;

        var actual = PipWindowService.GetVisualRect(handle);
        if (!actual.IsValid)
            return false;

        return Math.Abs(actual.Width - _manualResizeCandidateStartRect.Width) > LayoutMoveSizeTolerancePx
            || Math.Abs(actual.Height - _manualResizeCandidateStartRect.Height) > LayoutMoveSizeTolerancePx;
    }

    private void CommitJogoManualResizeReference(PipSlot slot, NativeRect finalRect)
    {
        if (slot.Window is null || !finalRect.IsValid)
            return;

        slot.RefreshWindow(slot.Window with { VisualRect = finalRect });

        var occupied = GetOccupiedSlotsInNumberOrder()
            .Where(item => item.Window is not null && PipWindowService.IsUsable(item.Window.Handle))
            .ToArray();
        var currentRects = occupied
            .Select(item => PipWindowService.GetVisualRect(item.Window!.Handle))
            .ToArray();
        if (currentRects.Length == occupied.Length && currentRects.All(rect => rect.IsValid))
        {
            SaveLockedGroupModel(occupied, currentRects);
            _lastKnownGroupBounds = GetBounds(currentRects);

            var topSlots = ResolveJogoTopGroupSlotNumbers(occupied, currentRects);
            var group = topSlots.Contains(slot.Number) ? "superior" : "lateral";

            // Fixar layout continua aceitando o tamanho escolhido pelo usuário,
            // mas nenhum outro PiP é alterado até o botão Igualar ser acionado.
            SetFixedSlotAuthorityRect(
                slot.Number,
                finalRect,
                "manual-pip-resize-reference/jogo");

            CaptureCurrentRectsIntoSlotLayout();
            PositionToolbar();
            SaveSettings();
            RefreshPipDragTargets();
            SetStatus($"PiP {slot.Number} ajustado; clique em Igualar para aplicar somente ao grupo {group}");
            AppLogger.Info(
                $"jogo-manual-resize-reference-only: slot={slot.Number}; group={group}; " +
                $"rect={FormatRect(finalRect)}; otherWindowsChanged=False; " +
                "equalizeOnDemand=True; nativeBorderResize=True");
        }
    }

    private void ResetJogoManualResizeCandidate()
    {
        // Mantido como ponto único de limpeza para futuras extensões do gesto.
    }

    private void ResetNaturalAnchorDragAfterJogoResize()
    {
        _naturalAnchorDragActive = false;
        _naturalAnchorDragHandle = IntPtr.Zero;
        _naturalAnchorVisualOffsets.Clear();
        _naturalAnchorRawOffsets.Clear();
        _naturalAnchorStartRects.Clear();
        _naturalAnchorStartBounds = default;
        _lastNaturalAnchorDragMoveUtc = DateTime.MinValue;
        _lastNaturalAnchorDragDx = 0;
        _lastNaturalAnchorDragDy = 0;
        RefreshCapturedRectsOnly();
        CaptureCurrentRectsIntoSlotLayout();
        PositionToolbar();
        SaveSettings();
        RefreshPipDragTargets();
    }

    private void ApplyNaturalAnchorDrag(bool force)
    {
        if (!_naturalAnchorDragActive || _naturalAnchorDragHandle == IntPtr.Zero) return;
        if (_naturalAnchorVisualOffsets.Count == 0) return;

        var now = DateTime.UtcNow;
        if (!force && (now - _lastNaturalAnchorDragMoveUtc).TotalMilliseconds < NaturalAnchorDragFrameMs)
            return;

        var anchorRect = PipWindowService.GetVisualRect(_naturalAnchorDragHandle);
        if (!anchorRect.IsValid) return;

        if (_naturalAnchorStartRects.TryGetValue(_naturalAnchorDragHandle, out var anchorStart) && anchorStart.IsValid)
        {
            var dx = anchorRect.Left - anchorStart.Left;
            var dy = anchorRect.Top - anchorStart.Top;
            if (!force && Math.Abs(dx - _lastNaturalAnchorDragDx) < NaturalAnchorDragPixelThreshold &&
                Math.Abs(dy - _lastNaturalAnchorDragDy) < NaturalAnchorDragPixelThreshold)
                return;
            _lastNaturalAnchorDragDx = dx;
            _lastNaturalAnchorDragDy = dy;
        }

        _lastNaturalAnchorDragMoveUtc = now;
        _ignoreWindowMovesUntilUtc = DateTime.UtcNow.AddMilliseconds(180);

        var rawMoves = new List<(IntPtr Handle, int RawLeft, int RawTop)>();
        foreach (var (hWnd, visualOffset) in _naturalAnchorVisualOffsets)
        {
            if (hWnd == _naturalAnchorDragHandle) continue;
            if (!_naturalAnchorRawOffsets.TryGetValue(hWnd, out var rawOffset)) continue;
            if (!PipWindowService.IsUsable(hWnd)) continue;

            var targetVisualLeft = anchorRect.Left + visualOffset.OffsetX;
            var targetVisualTop = anchorRect.Top + visualOffset.OffsetY;
            rawMoves.Add((hWnd, targetVisualLeft + rawOffset.OffsetX, targetVisualTop + rawOffset.OffsetY));
        }

        if (rawMoves.Count > 0)
            PipWindowService.MoveRawPositionBatch(rawMoves);
    }

    private Dictionary<IntPtr, (int OffsetX, int OffsetY)> BuildRawOffsetsForDrag(IReadOnlyList<PipSlot> occupied)
    {
        var result = new Dictionary<IntPtr, (int OffsetX, int OffsetY)>();
        foreach (var slot in occupied)
        {
            if (slot.Window is null) continue;
            var handle = slot.Window.Handle;
            var raw = PipWindowService.GetRawRect(handle);
            var visual = PipWindowService.GetVisualRect(handle);
            if (!raw.IsValid || !visual.IsValid) continue;
            result[handle] = (raw.Left - visual.Left, raw.Top - visual.Top);
        }
        return result;
    }

    private bool LockedModelMatches(IReadOnlyList<PipSlot> occupied)
    {
        if (_lockedGroupModelRects.Count != occupied.Count) return false;
        return occupied.All(slot => slot.Window is not null && _lockedGroupModelRects.ContainsKey(slot.Window.Handle));
    }

    private void RefreshSlotsFromLockedModel()
    {
        foreach (var slot in Slots.Where(slot => slot.Window is not null))
        {
            if (_lockedGroupModelRects.TryGetValue(slot.Window!.Handle, out var rect))
                slot.RefreshWindow(slot.Window with { VisualRect = rect });
            else
            {
                var actual = PipWindowService.GetVisualRect(slot.Window!.Handle);
                if (actual.IsValid) slot.RefreshWindow(slot.Window with { VisualRect = actual });
            }
        }
    }

    private void RefreshCapturedRectsOnly()
    {
        foreach (var slot in Slots.Where(slot => slot.Window is not null))
        {
            var rect = PipWindowService.GetVisualRect(slot.Window!.Handle);
            if (rect.IsValid)
                slot.RefreshWindow(slot.Window with { VisualRect = rect });
        }
    }

    private void SaveLockedGroupModelFromCurrentRects()
    {
        var occupied = GetOccupiedSlotsInNumberOrder();
        var dict = new Dictionary<IntPtr, NativeRect>();
        foreach (var slot in occupied)
        {
            if (slot.Window is null) continue;
            var rect = PipWindowService.GetVisualRect(slot.Window.Handle);
            if (rect.IsValid)
                dict[slot.Window.Handle] = rect;
        }

        _lockedGroupModelRects = dict;
        _lockedGroupModelBounds = GetBounds(dict.Values.ToArray());
        if (_lockedGroupModelBounds.IsValid)
            _lastKnownGroupBounds = _lockedGroupModelBounds;
    }

    private void ApplyLockedGroupModelOnce(bool showAfterMove = false)
    {
        if (_lockedGroupModelRects.Count == 0) return;
        _ignoreWindowMovesUntilUtc = DateTime.UtcNow.AddMilliseconds(220);

        var moves = new List<(IntPtr Handle, NativeRect Target)>();
        foreach (var slot in GetOccupiedSlotsInNumberOrder())
        {
            if (slot.Window is null) continue;
            if (!_lockedGroupModelRects.TryGetValue(slot.Window.Handle, out var target) || !target.IsValid)
                continue;

            moves.Add((slot.Window.Handle, target));
            slot.RefreshWindow(slot.Window with { VisualRect = target });
        }

        PipWindowService.MoveVisualBatch(moves, pixelThreshold: 1);
        if (showAfterMove)
        {
            foreach (var slot in GetOccupiedSlotsInNumberOrder())
            {
                if (slot.Window is not null)
                    PipWindowService.Show(slot.Window.Handle);
            }
        }
    }

    private void SaveLockedGroupModel(IReadOnlyList<PipSlot> slots, IReadOnlyList<NativeRect> targets)
    {
        var dict = new Dictionary<IntPtr, NativeRect>();
        for (var i = 0; i < Math.Min(slots.Count, targets.Count); i++)
        {
            if (slots[i].Window is null || !targets[i].IsValid) continue;
            dict[slots[i].Window!.Handle] = targets[i];
        }

        _lockedGroupModelRects = dict;
        _lockedGroupModelBounds = GetBounds(dict.Values.ToArray());
        if (_lockedGroupModelBounds.IsValid)
            _lastKnownGroupBounds = _lockedGroupModelBounds;
    }

    /// <summary>
    /// Remove slots sem janela utilizável quando eles não pertencem à recuperação e
    /// preserva a identidade dos slots reservados pelo AutoReturn. Deve rodar antes de
    /// montar o modelo de arraste para que um handle morto nunca seja confundido com um
    /// HWND duplicado nem consultado como geometria física do gesto atual.
    /// </summary>
    private int PurgeDestroyedSlotReferences(string source)
    {
        var purged = 0;
        var preserved = new List<(int Slot, IntPtr Handle, bool LossDebounceReserved)>();
        foreach (var slot in GetOccupiedSlotsInNumberOrder())
        {
            var window = slot.Window;
            if (window is null) continue;
            if (PipWindowService.IsUsable(window.Handle)) continue;

            // Um HWND perdido com vínculo forte pertence ao fluxo de recuperação.
            // O modelo de arraste simplesmente o ignora até a nova janela chegar;
            // nunca deve apagar a identidade necessária ao AutoReturn.
            // A reserva precisa começar no primeiro instante da perda. O debounce do
            // monitor ainda pode estar em curso, portanto exigir Pending/Offline aqui
            // cria uma corrida e apaga a identidade antes do AutoReturn montar a fila.
            var preserveForAutoReturn = AutoReturnBurstPolicy.ShouldPreserveLostSlot(
                IsAutoReturnEnabledForSlot(slot.Number),
                SlotHasPairRecoverySignal(slot.Number));
            if (preserveForAutoReturn)
            {
                var lossDebounceReserved =
                    _windowLossDebounceGenerationByHwnd.ContainsKey(window.Handle);
                preserved.Add((
                    slot.Number,
                    window.Handle,
                    lossDebounceReserved));
                continue;
            }

            purged++;
            AppLogger.Warn(
                $"{source}: referência de janela destruída removida antes do arraste; " +
                $"slot={slot.Number}; handle=0x{window.Handle.ToInt64():X}");
            ClearSlotCompletely(slot, source + "/janela-destruida");
        }

        if (preserved.Count > 0)
        {
            var details = string.Join(",", preserved.Select(item =>
                $"{item.Slot}:0x{item.Handle.ToInt64():X}:debounce={item.LossDebounceReserved}"));
            AppLogger.Info(
                $"{source}: referências perdidas preservadas fora do modelo de arraste; " +
                $"count={preserved.Count}; slots={details}; pairMetadataPreserved=True");
        }

        return purged;
    }

    private PipSlot[] GetUsableOccupiedSlotsForDrag()
    {
        // Slots em recuperação continuam ocupados para o AutoReturn, porém não possuem
        // geometria válida e não devem participar do modelo físico do gesto atual.
        return GetOccupiedSlotsInNumberOrder()
            .Where(slot => slot.Window is not null && PipWindowService.IsUsable(slot.Window.Handle))
            .ToArray();
    }

    /// <summary>
    /// Registra, de forma precisa, por que cada slot ocupado pode não entrar no modelo de
    /// arraste — separando o caso real de HWND duplicado (dois slots com o mesmo handle) do
    /// caso de retângulo inválido (janela sem geometria disponível no instante da leitura).
    /// Isso substitui o antigo aviso genérico "slots duplicados apontando para o mesmo HWND",
    /// que era disparado mesmo quando não havia duplicidade nenhuma.
    /// </summary>
    private void LogAnchorRectDropReasons(IReadOnlyList<PipSlot> occupied, string source)
    {
        var withWindow = occupied.Where(slot => slot.Window is not null).ToArray();

        var byHandle = withWindow
            .GroupBy(slot => slot.Window!.Handle)
            .Where(group => group.Count() > 1)
            .ToArray();

        foreach (var group in byHandle)
        {
            var slotNumbers = string.Join(",", group.Select(slot => slot.Number));
            AppLogger.Warn(
                $"{source}: HWND realmente duplicado entre slots; handle=0x{group.Key.ToInt64():X}; slots={slotNumbers}");
        }

        var handledAsDuplicate = byHandle.SelectMany(group => group).Select(slot => slot.Number).ToHashSet();
        var invalidRect = withWindow
            .Where(slot => !handledAsDuplicate.Contains(slot.Number))
            .Where(slot => PipWindowService.IsUsable(slot.Window!.Handle))
            .Where(slot => !PipWindowService.GetVisualRect(slot.Window!.Handle).IsValid)
            .ToArray();

        foreach (var slot in invalidRect)
        {
            AppLogger.Warn(
                $"{source}: slot ignorado no modelo de arraste por retângulo inválido (janela sem geometria no momento da leitura), " +
                $"não é HWND duplicado; slot={slot.Number}; handle=0x{slot.Window!.Handle.ToInt64():X}");
        }
    }

}
