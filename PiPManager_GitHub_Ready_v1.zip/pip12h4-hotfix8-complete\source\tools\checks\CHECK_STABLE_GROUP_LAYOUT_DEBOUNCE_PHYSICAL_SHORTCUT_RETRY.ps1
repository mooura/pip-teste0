$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$main = Get-Content (Join-Path $root 'src\PiPManager.Wpf\MainWindow.xaml.cs') -Raw
$checks = [ordered]@{
  'single physical shortcut retry' = $main.Contains('initial-open-physical-shortcut-retry-start') -and $main.Contains('manual-open/physical-retry')
  'retry precedes extension fallback' = $main.IndexOf('initial-open-physical-shortcut-retry-start') -lt $main.IndexOf('fallback requestPictureInPicture enviado por ação do usuário')
  'group layout debounce token' = $main.Contains('_stableGroupLayoutDebounceCts')
  '500 ms stable window' = $main.Contains('QueueStableGroupLayout("capture-all", debounceMs: 500)')
  'new capture cancels prior request' = $main.Contains('_stableGroupLayoutDebounceCts?.Cancel()')
  'layout applied only after debounce' = $main.Contains('stable-group-layout-debounce-applied')
  'manual success queues stable layout' = $main.Contains('manual-open/shortcut/slot-')
}
$failed = 0
foreach ($item in $checks.GetEnumerator()) {
  if ($item.Value) { Write-Host ($item.Key + ': OK') } else { Write-Host ($item.Key + ': FAIL'); $failed++ }
}
if ($failed -gt 0) { throw 'Stable group layout debounce and physical shortcut retry checks failed.' }
Write-Host 'Stable group layout debounce and physical shortcut retry checks OK.'
