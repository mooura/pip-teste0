# AutoReturn burst recovery stabilization

## Failure characterized

When several PiP windows were destroyed in quick succession, the window-loss
debounce and the natural group-drag callback could race. The drag cleanup could
call `ClearSlotCompletely` before the debounce admitted that slot to the
AutoReturn queue. The lost slot then no longer had its tab, session, stable video
key or URL, so no recovery attempt could be created.

The runtime evidence showed slots 1, 10 and 4 being cleared by
`NaturalAnchorDragStarted/janela-destruida`, while only slots 3 and 6 reached
`auto-return-pending`. The two admitted slots were successfully recovered.

## Stabilized behavior

- A linked slot with AutoReturn enabled is protected from drag cleanup as soon
  as its HWND becomes unusable, including while the loss debounce is pending.
- Transient Hidden events still use the existing debounce. The reservation
  preserves identity but does not prematurely send the reopen shortcut.
- Confirmed losses are retained in the existing per-slot queue.
- Queue selection is deterministic: oldest pending loss first, slot number as
  the tie-breaker.
- Each admitted slot stores its own maximum queue age. Later slots in a burst
  receive more time and do not lose it as earlier slots complete.
- The fixed-layout recovery timeout grows with the expected slot count, up to a
  bounded limit, while the final group layout is still applied only once.
- The physical PiP shortcut and HWND ownership remain serialized. This avoids
  binding one newly created PiP window to the wrong slot.

## Adaptive retry acceleration

- The readiness probe runs before the single-flight physical gate. Loading
  players from different slots can therefore prepare concurrently.
- A not-ready player is deferred at most twice before the bounded physical
  fallback, preventing both premature shortcuts and indefinite readiness waits.
- The fixed ten-second cooldown was replaced by a per-slot progressive backoff:
  500 ms, 1000 ms and then 2000 ms capped.
- Every cooldown queues its own fast tick. The regular timer remains only as a
  safety net.
- The policy is shared by the slot-keyed AutoReturn state, so the same behavior
  applies to slots 1 through 10.
- Shortcut dispatch and HWND capture remain serialized; only readiness work is
  concurrent.

## Playlist recovery and Open All ownership

- A manual next/previous transition may destroy the PiP before the page updates
  its session or stable-video identity. Playlist recovery now keeps the strict
  real-change check for a bounded 2200 ms grace period, then reopens the current
  page player instead of waiting indefinitely. The existing 150 ms navigation
  stabilization still applies.
- This fallback is limited to detected playlist contexts. Non-playlist video
  changes retain the strict real-change requirement.
- Before `Open All`, unusable slot reservations are cleared only when that
  slot's AutoReturn is disabled. Active, awaiting and AutoReturn-owned slots
  remain protected.
- While a manual or batched prepared-open attempt owns a target slot, smart
  reconnect is not allowed to claim the newly created HWND for an older offline
  reservation. Prepared capture remains the sole owner until confirmation or
  timeout.
- The extension discovery result remains authoritative. An unavailable source
  is reported instead of triggering unsafe content-script reinjection or being
  counted as a successful PiP.

## Regression evidence

- `AutoReturnBurstPolicy` is covered by executable Core tests.
- Core tests verify the complete 500/1000/2000 ms sequence and its cap.
- `CHECK_FIVE_PIP_IDENTITY_STABILITY.ps1` protects early identity reservation,
  oldest-first queueing and per-slot queue lifetime.
- `CHECK_MIXED_ASPECT_LAYOUT_STABILITY.ps1` prevents the drag purge from
  reintroducing the pre-debounce deletion race.
- `CHECK_RELATIVE_GROUP_LAYOUT_RECOVERY.ps1` checks the scalable group timeout.
- `CHECK_AUTORETURN_TRIGGER_ELIGIBILITY.ps1` checks the bounded playlist
  same-player fallback.
- `CHECK_TEN_SLOT_COVERAGE.ps1` checks stale-reservation cleanup and prepared
  HWND ownership during `Open All`.
