'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');
const root = path.resolve(__dirname, '../..');
const content = fs.readFileSync(path.join(root, 'src/PiPManager.Extension/content.js'), 'utf8');
const background = fs.readFileSync(path.join(root, 'src/PiPManager.Extension/background.js'), 'utf8');
const main = fs.readFileSync(path.join(root, 'src/PiPManager.Wpf/MainWindow.xaml.cs'), 'utf8');
const manifest = JSON.parse(fs.readFileSync(path.join(root, 'src/PiPManager.Extension/manifest.json'), 'utf8'));

assert.strictEqual(manifest.version, '1.4.39.25');
assert(content.includes("CONTENT_VERSION = '1.4.39.25-command-target-root-guard-hotfix10'"));
assert(background.includes("BRIDGE_VERSION = '1.4.39.25-command-target-root-guard-hotfix10'"));

const authoritativeStart = main.indexOf('private static bool IsAuthoritativeNextCommandTarget');
const authoritativeEnd = main.indexOf('private VideoTabInfo? ResolveAuthoritativeNextCandidateForSlot', authoritativeStart);
assert(authoritativeStart >= 0 && authoritativeEnd > authoritativeStart, 'authoritative target method must exist');
const authoritativeBody = main.slice(authoritativeStart, authoritativeEnd);
assert(authoritativeBody.includes('tab.NextTargetGeneration <= 0'), 'generation is part of strong identity');
assert(authoritativeBody.includes('string.IsNullOrWhiteSpace(tab.NextTargetOperationId)'), 'operationId is part of strong identity');
assert(authoritativeBody.includes('tab.NextPreviewAssetId'), 'preview asset coherence is checked');
assert(!authoritativeBody.includes('tab.NextPreviewIndex >= 0'), 'indexless playlists must not be rejected');
assert(main.includes('indexlessAccepted='), 're-resolution must expose indexless acceptance');
assert(main.includes('same-tab-authoritative-target'), 'same-tab fallback must remain bounded');
assert(main.includes('video-command-blocked-offline-no-video'), 'offline no-video commands must be blocked');
assert(main.includes('video-command-blocked-playlist-collection-root'), 'playlist collection root commands must be blocked');
assert(main.includes('previous-command-blocked-no-authoritative-player'), 'previous requires a live authoritative player');
assert(main.includes('auto-return-candidate-rejected-playlist-root'), 'playlist root must not become an AutoReturn candidate');

assert(content.includes('function isPlaylistCollectionRootUrl('));
assert(content.includes("reason: 'playlist-collection-root-no-player'"));
assert(content.includes("reason: 'previous-target-not-authoritative'"));
assert(content.includes('hasSafePreviousNavigationContext()'));
assert(background.includes('previous-blocked-no-authoritative-player'));
assert(background.includes('tabs-goBack-blocked-unsafe-playlist-context'));
assert(background.includes('canUseBrowserHistoryForPrevious(tabId)'));

function extractFunction(source, name) {
  const start = source.indexOf(`function ${name}(`);
  if (start < 0) throw new Error(`function ${name} not found`);
  const brace = source.indexOf('{', start);
  let depth = 0, quote = '', escaped = false;
  for (let i = brace; i < source.length; i += 1) {
    const ch = source[i];
    if (quote) {
      if (escaped) escaped = false;
      else if (ch === '\\') escaped = true;
      else if (ch === quote) quote = '';
      continue;
    }
    if (ch === '"' || ch === "'" || ch === '`') { quote = ch; continue; }
    if (ch === '{') depth += 1;
    else if (ch === '}' && --depth === 0) return source.slice(start, i + 1);
  }
  throw new Error(`function ${name} incomplete`);
}

const ctx = vm.createContext({ URL, Number, location: { href: 'https://pmvhaven.com/playlists/abc' } });
vm.runInContext([
  extractFunction(content, 'isPlaylistCollectionRootUrl'),
  extractFunction(content, 'isPlaylistItemUrl'),
  extractFunction(content, 'readExplicitPlaylistIndex'),
  extractFunction(content, 'hasSafePreviousNavigationContext')
].join('\n'), ctx);
assert.strictEqual(ctx.isPlaylistCollectionRootUrl('https://pmvhaven.com/playlists'), true);
assert.strictEqual(ctx.isPlaylistCollectionRootUrl('https://pmvhaven.com/playlists/abc'), false);
assert.strictEqual(ctx.isPlaylistItemUrl('https://pmvhaven.com/playlists/abc'), true);
assert.strictEqual(ctx.hasSafePreviousNavigationContext(), false, 'indexless playlist must not use browser history');
ctx.location.href = 'https://pmvhaven.com/playlists/abc?index=3';
assert.strictEqual(ctx.hasSafePreviousNavigationContext(), true, 'explicit nonzero index can use browser history');
ctx.location.href = 'https://pmvhaven.com/playlists/abc?index=0';
assert.strictEqual(ctx.hasSafePreviousNavigationContext(), false, 'first item must not navigate back to collection history');

console.log('Authoritative indexless CommandTarget + playlist root guard Hotfix 10 tests: OK');
