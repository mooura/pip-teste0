$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$content = Get-Content -Raw (Join-Path $root 'src\PiPManager.Extension\content.js')
$background = Get-Content -Raw (Join-Path $root 'src\PiPManager.Extension\background.js')
$main = Get-Content -Raw (Join-Path $root 'src\PiPManager.Wpf\MainWindow.xaml.cs')
$bridge = Get-Content -Raw (Join-Path $root 'src\PiPManager.Wpf\Services\ExtensionBridgeService.cs')
$autoState = Get-Content -Raw (Join-Path $root 'src\PiPManager.Wpf\Models\AutoReturnSlotState.cs')
$videoTab = Get-Content -Raw (Join-Path $root 'src\PiPManager.Wpf\Models\VideoTabInfo.cs')
$manifest = Get-Content -Raw (Join-Path $root 'src\PiPManager.Extension\manifest.json') | ConvertFrom-Json
$release = Get-Content -Raw (Join-Path $root 'src\PiPManager.Wpf\Services\ReleaseInfoService.cs')
$checks = [ordered]@{
  'manifest is 1.4.39.25' = ([string]$manifest.version -eq '1.4.39.25')
  'release metadata is synchronized' = $release.Contains('ExtensionVersion = "1.4.39.25"')
  'extension identifiers are synchronized' = $content.Contains("CONTENT_VERSION = '1.4.39.25-command-target-root-guard-hotfix10'") -and $background.Contains("BRIDGE_VERSION = '1.4.39.25-command-target-root-guard-hotfix10'")
  'command target is immutable and forwarded' = $content.Contains('function freezeNextCommandTarget(') -and $content.Contains('function tryNavigateFrozenCommandTarget(') -and $background.Contains('commandTarget') -and $bridge.Contains('commandTarget = commandTarget is null ? null')
  'preview lifecycle is explicit' = $content.Contains("previewState: 'STALE'") -and $content.Contains('if (commandTarget) markNextPreviewStaleForCommand(commandTarget);') -and $content.Contains("previewState: 'RESOLVING_TARGET'") -and $content.Contains("'READY_METADATA', 'READY_ANIMATED'") -and $videoTab.Contains('NextPreviewState')
  'WPF clears stale preview by command barrier' = $main.Contains('ArmNextPreviewCommandBarrier(') -and $main.Contains('IsNextPreviewCommandBarrierActive(') -and $main.Contains('next-preview-command-stale-cleared') -and $main.Contains('command-target-unresolved') -and $main.Contains('NextPreviewCommandBarrierMaxAgeSeconds = 12')
  'same-video fallback is blocked from command start' = $main.Contains('auto-return-same-video-fallback-blocked-command-generation') -and $autoState.Contains('BlockSameVideoFallback')
  'preload is bounded to ten seconds' = $content.Contains('const NEXT_VIDEO_PRELOAD_TARGET_BUFFER_SECONDS = 10')
  'diagnostic operation context persists' = $content.Contains('pipManagerNextOperationContextById') -and $content.Contains('rememberNextTargetOperationContext(') -and $background.Contains('previewState: message.previewState')
}
$failed = @()
foreach ($item in $checks.GetEnumerator()) { if ($item.Value) { Write-Host ($item.Key + ': OK') } else { Write-Host ($item.Key + ': FAIL'); $failed += $item.Key } }
if ($failed.Count -gt 0) { throw ('Hotfix 3 checks failed: ' + ($failed -join ', ')) }
Write-Host 'Immutable Command Target + Explicit Preview State Hotfix 3 checks OK.'
