﻿using System;

namespace PiPManager.Core.Slots;

/// <summary>
/// Resultado formal de uma transição da máquina de estados.
/// Applied indica se o evento foi aplicado ao snapshot, mesmo sem alterar o enum de estado.
/// Changed indica alteração do estado principal.
/// </summary>
public sealed record SlotTransition(
    int SlotNumber,
    SlotState From,
    SlotState To,
    string EventName,
    string AttemptId,
    bool Applied,
    bool Changed,
    string? Reason,
    DateTimeOffset CreatedAt)
{
    public static SlotTransition Ignored(
        SlotSnapshot slot,
        string eventName,
        string attemptId,
        string? reason = null)
        => new(
            slot.SlotNumber,
            slot.State,
            slot.State,
            eventName,
            attemptId,
            Applied: false,
            Changed: false,
            Reason: reason,
            CreatedAt: DateTimeOffset.UtcNow);

    public static SlotTransition AppliedWithoutStateChange(
        SlotSnapshot slot,
        string eventName,
        string attemptId,
        string? reason = null)
        => new(
            slot.SlotNumber,
            slot.State,
            slot.State,
            eventName,
            attemptId,
            Applied: true,
            Changed: false,
            Reason: reason,
            CreatedAt: DateTimeOffset.UtcNow);

    public static SlotTransition ChangedTo(
        SlotSnapshot from,
        SlotState to,
        string eventName,
        string attemptId,
        string? reason = null)
        => new(
            from.SlotNumber,
            from.State,
            to,
            eventName,
            attemptId,
            Applied: true,
            Changed: from.State != to,
            Reason: reason,
            CreatedAt: DateTimeOffset.UtcNow);

    // Compatibilidade nominal para chamadas antigas.
    public static SlotTransition NoChange(
        SlotSnapshot slot,
        string eventName,
        string attemptId,
        string? reason = null)
        => Ignored(slot, eventName, attemptId, reason);
}
