using PiPManager.Wpf.Models;

namespace PiPManager.Wpf.Services;

internal static class AutoReturnPolicyCodec
{
    internal static AutoReturnPolicy Parse(string? value)
    {
        // Legacy Silent values intentionally migrate to the supported Discrete path.
        return string.Equals(value, "Discrete", StringComparison.OrdinalIgnoreCase)
               || string.Equals(value, "Discreto", StringComparison.OrdinalIgnoreCase)
               || string.Equals(value, "Silent", StringComparison.OrdinalIgnoreCase)
               || string.Equals(value, "Silencioso", StringComparison.OrdinalIgnoreCase)
            ? AutoReturnPolicy.Discrete
            : AutoReturnPolicy.Off;
    }

    internal static string Format(AutoReturnPolicy policy) => policy switch
    {
        AutoReturnPolicy.Discrete => "Discreto",
        _ => "Off"
    };
}

