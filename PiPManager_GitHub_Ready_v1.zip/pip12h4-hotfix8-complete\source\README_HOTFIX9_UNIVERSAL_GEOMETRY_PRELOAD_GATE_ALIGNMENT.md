# Hotfix 9 — Universal Geometry / Preload Gate Alignment

This package changes validation only. Runtime source under `src/` is unchanged.

`CHECK_UNIVERSAL_GEOMETRY_PRELOAD_HANDOFF_HOTFIX7.ps1` previously required the Hotfix 7 native-video diagnostic `preload-network-window-empty`. Hotfix 9 intentionally replaced that transport with a byte-capped Range cache.

The aligned assertion now proves that:

- zero cached bytes map to `PRELOAD_EMPTY`;
- partial cached bytes map to `PRELOAD_PARTIAL`;
- only useful cached bytes map to `READY`;
- the empty Range-cache reason is `range-preload-byte-cache-empty`.

No geometry, handoff, WPF, Core, Native, content-script, or background runtime behavior was changed.
