'use strict';
const fs = require('fs');
const path = require('path');
const assert = require('assert');
const root = path.resolve(__dirname, '../..');
const main = fs.readFileSync(path.join(root, 'src/PiPManager.Wpf/MainWindow.xaml.cs'), 'utf8');
const content = fs.readFileSync(path.join(root, 'src/PiPManager.Extension/content.js'), 'utf8');
const background = fs.readFileSync(path.join(root, 'src/PiPManager.Extension/background.js'), 'utf8');
const manifest = JSON.parse(fs.readFileSync(path.join(root, 'src/PiPManager.Extension/manifest.json'), 'utf8'));

assert.strictEqual(manifest.version, '1.4.39.25', 'extension runtime version must remain unchanged');
assert(content.includes("CONTENT_VERSION = '1.4.39.25-command-target-root-guard-hotfix10'"));
assert(background.includes("BRIDGE_VERSION = '1.4.39.25-command-target-root-guard-hotfix10'"));

const start = main.indexOf('private void CompleteVideoSwitchPreservationAfterAutoReturn');
const end = main.indexOf('private void FinalizeVideoSwitchPreservedSameHwndIfStable', start);
assert(start >= 0 && end > start, 'AutoReturn preserve completion method must exist');
const body = main.slice(start, end);
assert(body.includes('state.AutoReturnTookOwnership'), 'only AutoReturn-owned preservation may complete');
assert(body.includes('slotHandle != confirmedHandle'), 'confirmed HWND must belong to the slot');
assert(body.includes('state.TabId.Value != tab.TabId'), 'completion must stay on the paired tab');
assert(body.includes('_videoSwitchPreservationBySlot.Remove(slot.Number)'), 'completed state must be removed before expiry');
assert(body.includes('result=auto-return-confirmed'), 'completion result telemetry must be explicit');
assert(body.includes('preservedConfirmed=True'), 'telemetry must report confirmed preservation');
assert(body.includes('completionReason=auto-return-confirmed'), 'completion reason must be stable');
assert(body.includes('expireReason=auto-return-confirmed'), 'completion must replace the false expiry reason');
assert(body.includes('timerCancelled=True'), 'timer cancellation must be observable');

const calls = (main.match(/CompleteVideoSwitchPreservationAfterAutoReturn\(/g) || []).length;
assert(calls >= 3, 'method plus silent and focusless calls must exist');
assert(main.includes('"preserve-silent-reopen-confirmed"'), 'silent AutoReturn success must synchronize preservation');
assert(main.includes('"focusless-auto-return-confirmed"'), 'focusless AutoReturn success must synchronize preservation');

console.log('AutoReturn preserve-state synchronization Hotfix 11 tests: OK');
