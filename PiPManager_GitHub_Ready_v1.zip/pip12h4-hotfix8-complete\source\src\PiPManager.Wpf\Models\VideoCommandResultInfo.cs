namespace PiPManager.Wpf.Models;

public sealed class VideoCommandResultInfo
{
    public string Command { get; init; } = string.Empty;
    public bool Ok { get; init; }
    public string Method { get; init; } = string.Empty;
    public string Reason { get; init; } = string.Empty;
    public string Match { get; init; } = string.Empty;
    public string TargetVideoSessionId { get; init; } = string.Empty;
    public string TargetStableVideoKey { get; init; } = string.Empty;

    // Um "next"/"previous" cai aqui quando o alvo vinculado não existe mais no
    // momento em que a extensão tentou resolver o comando: o site navegou para
    // um item sem player carregado (ex.: sala/modelo bloqueado, offline, ou
    // conteúdo removido). Sinal para o app decidir se vale reenviar o comando.
    public bool IsBlockedTarget =>
        !Ok &&
        (string.Equals(Method, "blocked-no-linked-target", StringComparison.OrdinalIgnoreCase)
         || string.Equals(Reason, "target-player-not-found", StringComparison.OrdinalIgnoreCase)
         || string.Equals(Reason, "target-player-not-found-after-refresh", StringComparison.OrdinalIgnoreCase)
         || string.Equals(Reason, "no-linked-target", StringComparison.OrdinalIgnoreCase));
}
