# AutoReturn Hard Readiness Gate Fix

Base: PiPManager 9.39.01 FINAL STABLE MOVE GROUP FIX.

## Problema confirmado pelo log

O caminho `same-video-reopen` considerava o alvo pronto sem validar `readyState`.
Quando o player estava em `HAVE_NOTHING` (`readyState=0`), o programa enviava dois
atalhos físicos, não encontrava um novo HWND e consumia o backoff. O PiP só era
recuperado depois que o site disponibilizava um vídeo real.

## Correção

- `readyState=0`, ausência de source ou `ended=true` bloqueiam qualquer tentativa física.
- O AutoReturn continua observando o player e tenta novamente a cada 900 ms.
- Espera por readiness não aumenta o backoff de falha física.
- O caminho rápido do mesmo vídeo permanece disponível a partir de metadata (`readyState>=1`).
- O fallback limitado para estados parcialmente carregados foi preservado.
- Layout, arraste, interface, extensão, pareamento e áudio não foram alterados.

## Compatibilidade com o Hotfix 5

No auto-next terminal, a repetição contínua foi substituída por uma política limitada:
uma deferral de readiness e, se o player continuar sem source, observação estrutural
passiva. O bloqueio de tentativa física em `HAVE_NOTHING` permanece; apenas o loop
indefinido foi removido.
