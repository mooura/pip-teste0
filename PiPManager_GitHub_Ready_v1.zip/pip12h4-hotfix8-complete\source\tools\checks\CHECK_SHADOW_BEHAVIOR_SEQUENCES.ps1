$ErrorActionPreference = "Stop"
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$coreTests = Join-Path $root "tests\PiPManager.Core.Tests\Program.cs"
$text = Get-Content $coreTests -Raw
$requiredTests = @(
  "TestShadowPreservedSameHwndReturnsWaitingToActive",
  "TestShadowAutoReturnReconnectCycleUsesSameAttempt",
  "TestShadowReconnectFailedUsesSameAttempt",
  "TestShadowManualOpenAfterFailedReconnectCanCaptureNormally",
  "TestShadowExternalCaptureFromEmptyBecomesActive",
  "TestShadowExternalCaptureLossWithoutLinkResetsToEmpty",
  "TestShadowManualOpenCaptureContinuityUsesSameAttempt"
)
foreach ($name in $requiredTests) { if (!$text.Contains($name)) { throw "Missing behavioral sequence test: $name" } }
$requiredTransitions = @("WaitingForReconnect","ReconnectStarted","ReconnectSucceeded","ReconnectFailed","ExternalPipCaptured","PreservedSameHwndConfirmed","SlotResetRequested","PipWindowCaptured")
foreach ($transition in $requiredTransitions) { if (!$text.Contains($transition)) { throw "Missing behavioral transition coverage: $transition" } }
Write-Host "Shadow behavioral sequence checks OK."
