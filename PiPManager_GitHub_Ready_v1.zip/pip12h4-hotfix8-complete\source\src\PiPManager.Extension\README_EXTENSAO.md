# PiP Manager Bridge - Open PiP Pairing

Esta extensão conversa com o app local em:

ws://127.0.0.1:45151/ws

## Comandos recebidos

- `videoCommand`: executa próximo/anterior no player alvo.
- `openPictureInPicture`: tenta abrir PiP no player alvo usando `requestPictureInPicture()`.

## Fluxo recomendado

1. App escolhe uma sessão de vídeo.
2. App envia `openPictureInPicture`.
3. Extensão tenta abrir PiP naquele `<video>`.
4. App captura a nova janela do Windows.
5. App vincula o novo PiP ao `stableVideoKey` / `videoSessionId` escolhido.



## v1.4.39.24 FIX — Fase 1: isolamento de vídeos auxiliares

Esta fase mantém a versão de manifesto `1.4.39.24` e aplica a primeira correção arquitetural recomendada:

- todo `<video>` criado para preload recebe `data-pip-manager-auxiliary="1"` e `data-pip-manager-preload="1"`;
- vídeos auxiliares são excluídos da descoberta, pareamento, comandos, abertura de PiP e eventos terminais;
- `rawVideoCount` passa a representar apenas vídeos operacionais; `domVideoCount` e `auxiliaryVideoCount` preservam a telemetria completa;
- sessões de documentos antigos no mesmo `tabId/frameId` são removidas quando uma nova `pageInstanceId` aparece;
- o objetivo é eliminar falsos `target-tab-has-multiple-players` causados pelo preload ou por sessões antigas após navegação.

O target resolver, state machine, placeholder seguro e redução do buffer ficam para as próximas fases, após validar este isolamento.

## v1.4.39.24 — Fase 3: state machine e cancelamento forte

- cada identidade atual/próxima recebe `generation` e `operationId`;
- `AbortController` cancela a resolução anterior quando o alvo muda ou a página navega;
- estados explícitos distinguem `RESOLVING_TARGET`, `RESOLVING_MEDIA`, `MEDIA_READY`, `PRELOADING` e `READY`;
- preview e preload usam o mesmo objeto de alvo autoritativo;
- callbacks de preload de uma geração antiga não podem alterar o estado atual;
- thumbnail associada ao `currentAssetId` é descartada;
- o aplicativo recebe lifecycle, geração e operação para impedir o `same-video-fallback` prematuro do AutoReturn.

## v1.4.39.24 — Hotfix 1: recuperação de Next e preview

Navegação pelo alvo autoritativo, descoberta ampliada do cartão Up Next e retries transitórios de 300/600/900 ms. No Hotfix 3, o preview anterior é marcado `STALE` e removido no início do comando.

## v1.4.39.24 — Hotfix 2: preview autoritativo e fallback rápido

- `nextPreviewAssetId` identifica explicitamente o asset visualizado;
- o WPF só mostra thumbnail/vídeo quando essa identidade coincide com `nextAssetId`;
- metadados da página real do próximo vídeo recuperam `og:image` e `og:title`;
- `player-not-ready` recebe uma rechecagem única de 250 ms;
- persistindo `HAVE_NOTHING`, o silent reopen é pulado e o fallback físico começa imediatamente.


## v1.4.39.24 — Hotfix 3: alvo imutável e preview por geração

- `CommandTarget` é congelado antes do comando;
- preview antigo é marcado `STALE` e removido;
- estado explícito do preview;
- fallback para o player antigo bloqueado por geração;
- preload limitado a 10 segundos;
- contexto diagnóstico persistente por `operationId`.

## v1.4.39.25 — Hotfix 10: CommandTarget sem índice e proteção da raiz de playlists

- `nextAssetId`, `generation` e `operationId` formam a identidade autoritativa mesmo quando `currentIndex` e `nextIndex` permanecem `-1`;
- a recuperação é limitada à mesma aba vinculada;
- `/playlists` e `/playlist` sem player são classificadas como raiz de coleção, não como continuação do vídeo;
- `Previous` prioriza controles DOM/semânticos e só permite histórico com índice explícito maior que zero;
- o background bloqueia `tabs.goBack` quando não existe player autoritativo ou contexto seguro.
