$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$content = Get-Content (Join-Path $root 'src\PiPManager.Extension\content.js') -Raw
$background = Get-Content (Join-Path $root 'src\PiPManager.Extension\background.js') -Raw
$model = Get-Content (Join-Path $root 'src\PiPManager.Wpf\Models\VideoTabInfo.cs') -Raw
$bridge = Get-Content (Join-Path $root 'src\PiPManager.Wpf\Services\ExtensionBridgeService.cs') -Raw
$protocolReader = Get-Content (Join-Path $root 'src\PiPManager.Wpf\Services\ExtensionProtocolReader.cs') -Raw
$siteProfiles = Get-Content (Join-Path $root 'src\PiPManager.Extension\site-profiles.js') -Raw
$xaml = Get-Content (Join-Path $root 'src\PiPManager.Wpf\MainWindow.xaml') -Raw
$slot = Get-Content (Join-Path $root 'src\PiPManager.Wpf\Models\PipSlot.cs') -Raw
$main = Get-Content (Join-Path $root 'src\PiPManager.Wpf\MainWindow.xaml.cs') -Raw
$preview = Get-Content (Join-Path $root 'src\PiPManager.Wpf\NextVideoPreviewWindow.xaml.cs') -Raw
$settings = Get-Content (Join-Path $root 'src\PiPManager.Wpf\Models\AppSettings.cs') -Raw
$failed = 0

function Check($name, $ok) {
  if ($ok) { Write-Host "$name`: OK" }
  else { Write-Host "$name`: FAIL"; $script:failed++ }
}

Check 'playlist context reader exists' ($content.Contains('function readPlaylistContext()'))
Check 'JSON-LD ItemList supported' ($content.Contains("item['@type'] === 'ItemList'"))
Check 'active DOM item supported' ($content.Contains('aria-current=') -and $content.Contains('aria-selected='))
Check 'URL index fallback supported' ($content.Contains("params.get('index')"))
Check 'five upcoming titles bounded in content' ($content.Contains('nextTitles.slice(0, 5)'))
Check 'playlist changes participate in snapshot signature' ($background.Contains('playlistIndex: Number(session.playlistIndex ?? -1)'))
Check 'managed playlist model exists' ($model.Contains('PlaylistDetected') -and $model.Contains('NextTitles'))
Check 'bridge reads playlist context' ($bridge.Contains('PlaylistIndex = GetIntOrDefault') -and $bridge.Contains('NextTitles = GetStringList'))
Check 'five upcoming titles bounded in bridge' ($bridge.Contains('ExtensionProtocolReader.GetStringList') -and $protocolReader.Contains('int maximum = 5'))
Check 'playlist is visible in picker' ($xaml.Contains('PickerPlaylistLine'))
Check 'current playlist video title is visible above linked slot' ($xaml.Contains('CurrentVideoTitle') -and $slot.Contains('CurrentVideoTitleDisplay'))
Check 'slot exposes playlist state' ($slot.Contains('public string PlaylistText') -and $slot.Contains('HasPlaylistText'))
Check 'slot playlist follows paired video snapshot' ($main.Contains('slot.PlaylistText = BuildSlotPlaylistText(tab)'))
Check 'application infers playlist from URL' ($main.Contains('ResolvePlaylistIndex') -and $main.Contains('IsPlaylistUrl'))
Check 'slot playlist visibility is logged' ($main.Contains('playlist-context-slot-visible'))
Check 'Up Next card is collected' ($content.Contains("nextPreviewThumbnailUrl") -and $siteProfiles.Contains("up next"))
Check 'Up Next media source is collected' ($content.Contains('findNextPreviewVideoUrl') -and $content.Contains('nextPreviewVideoUrl'))
Check 'embedded application data resolves next media' ($content.Contains('readNuxtVideoUrl') -and $content.Contains('__NUXT_DATA__') -and $content.Contains("fetch(pageUrl"))
Check 'short MP4 preview is preferred' ($content.Contains('videoPreview') -and $content.Contains('shortPreview') -and $content.Contains('previewMp4'))
Check 'preview media URL crosses bridge' ($model.Contains('NextPreviewVideoUrl') -and $bridge.Contains('nextPreviewVideoUrl'))
Check 'animated preview uses inline native muted media with fallback' ($xaml.Contains('SlotPreviewMedia') -and $xaml.Contains('IsMuted="True"') -and $xaml.Contains('SlotPreviewImage'))
Check 'animated preview only plays while slot is hovered' ($main.Contains('SlotItem_MouseEnter') -and $main.Contains('media.Play()') -and $main.Contains('media.Stop()'))
Check 'preview state is isolated per slot' ($slot.Contains('NextPreviewVideoUrl') -and $main.Contains('foreach (var slot in Slots)'))
Check 'preview is optional and persisted' ($settings.Contains('NextVideoPreviewEnabled') -and $main.Contains('next-preview-setting-changed'))
Check 'next preload is optional and persisted per slot' ($settings.Contains('NextVideoPreloadBySlot') -and $main.Contains('next-preload-slot-setting-changed'))
Check 'next preload setting crosses bridge' ($bridge.Contains('SendNextVideoPreloadSettingAsync') -and $background.Contains('nextVideoPreloadSetting'))
Check 'next full MP4 is preloaded in Firefox' ($content.Contains('readNuxtFullVideoUrl') -and $content.Contains("video.preload = 'auto'") -and $content.Contains('startNextVideoPreload'))
Check 'next preload is bounded and cancellable' ($content.Contains('12000') -and $content.Contains('cancelNextVideoPreload'))
Check 'per-slot hover native previews exist' ($xaml.Contains('SlotPreviewMedia') -and $main.Contains('_hoveredPreviewSlotNumber'))
Check 'preview click uses validated next flow' ($main.Contains('next-preview-inline-clicked') -and $main.Contains('SendVideoCommandToCapturedAsync(VideoCommandKind.Next)'))
Check 'checker included in core gate' ((Get-Content (Join-Path $root 'RUN_CORE_TESTS.bat') -Raw).Contains('CHECK_PLAYLIST_CONTEXT_DETECTION.ps1'))

if ($failed -gt 0) { throw 'Playlist context detection checks failed.' }
Write-Host 'Playlist context detection checks OK.'
