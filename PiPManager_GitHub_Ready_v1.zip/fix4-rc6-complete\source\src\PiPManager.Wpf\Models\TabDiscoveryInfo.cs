﻿namespace PiPManager.Wpf.Models;

public sealed class TabDiscoveryInfo
{
    public int TabId { get; init; }
    public string Status { get; init; } = string.Empty;
    public int RawVideoCount { get; init; }
    public int SessionCount { get; init; }

    public bool IsExactNoVideo =>
        TabId > 0
        && string.Equals(Status, "no-video", StringComparison.OrdinalIgnoreCase)
        && RawVideoCount == 0
        && SessionCount == 0;
}
