$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$content = Get-Content -Raw (Join-Path $root 'src\PiPManager.Extension\content.js')
$background = Get-Content -Raw (Join-Path $root 'src\PiPManager.Extension\background.js')
$main = Get-Content -Raw (Join-Path $root 'src\PiPManager.Wpf\MainWindow.xaml.cs')
$model = Get-Content -Raw (Join-Path $root 'src\PiPManager.Wpf\Models\VideoTabInfo.cs')
$bridge = Get-Content -Raw (Join-Path $root 'src\PiPManager.Wpf\Services\ExtensionBridgeService.cs')
$manifest = Get-Content -Raw (Join-Path $root 'src\PiPManager.Extension\manifest.json') | ConvertFrom-Json
$release = Get-Content -Raw (Join-Path $root 'src\PiPManager.Wpf\Services\ReleaseInfoService.cs')
$checks = [ordered]@{
  'manifest is 1.4.39.25' = ([string]$manifest.version -eq '1.4.39.25')
  'release metadata is synchronized' = $release.Contains('ExtensionVersion = "1.4.39.25"')
  'extension identifiers are synchronized' = $content.Contains("CONTENT_VERSION = '1.4.39.25-command-target-root-guard-hotfix10'") -and $background.Contains("BRIDGE_VERSION = '1.4.39.25-command-target-root-guard-hotfix10'")
  'authoritative preview payload exists' = $content.Contains('function buildAuthoritativePreviewPayload(') -and $content.Contains('nextPreviewAssetId:') -and $background.Contains("nextPreviewAssetId: session.nextPreviewAssetId || ''")
  'next-page metadata enriches preview' = $content.Contains('function readNextPagePreviewMetadata(') -and $content.Contains('resolvedThumbnailUrl')
  'WPF carries and validates preview asset' = $model.Contains('NextPreviewAssetId') -and $bridge.Contains('NextPreviewAssetId = GetString(item, "nextPreviewAssetId")') -and $main.Contains('IsAuthoritativeNextPreview(')
  'stale preview is rejected' = $main.Contains('preview-asset-not-authoritative') -and $main.Contains('thumbnail-asset-mismatch')
  'readiness recheck is bounded' = $main.Contains('pip-preserve-silent-readiness-recheck-wait') -and $main.Contains('Task.Delay(250)') -and $main.Contains('Task.Delay(450)')
  'not-ready skips silent reopen' = $main.Contains('pip-preserve-silent-readiness-recheck-blocked') -and $main.Contains('player-not-ready') -and $main.Contains('video-not-ready')
}
$failed = @()
foreach ($item in $checks.GetEnumerator()) { if ($item.Value) { Write-Host ($item.Key + ': OK') } else { Write-Host ($item.Key + ': FAIL'); $failed += $item.Key } }
if ($failed.Count -gt 0) { throw ('Hotfix 2 checks failed: ' + ($failed -join ', ')) }
Write-Host 'Authoritative Preview + Silent Readiness Hotfix 2 checks OK.'
