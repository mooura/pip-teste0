﻿using System.IO;
using System.Text.Json;
using PiPManager.Wpf.Models;

namespace PiPManager.Wpf.Services;

public sealed class SettingsService
{
    private static string SettingsFile => AppLogger.SettingsFile;

    public AppSettings Load()
    {
        try
        {
            if (!File.Exists(SettingsFile)) return new AppSettings();
            var json = File.ReadAllText(SettingsFile);
            return JsonSerializer.Deserialize<AppSettings>(json) ?? new AppSettings();
        }
        catch (Exception ex)
        {
            AppLogger.Error("Falha ao carregar configurações", ex);
            return new AppSettings();
        }
    }

    public void Save(AppSettings settings)
    {
        try
        {
            Directory.CreateDirectory(AppLogger.LogDirectory);
            var tmp = SettingsFile + ".tmp";
            File.WriteAllText(tmp, JsonSerializer.Serialize(settings, new JsonSerializerOptions { WriteIndented = true }));
            File.Copy(tmp, SettingsFile, true);
            File.Delete(tmp);
        }
        catch (Exception ex)
        {
            AppLogger.Error("Falha ao salvar configurações", ex);
        }
    }
}
