$ErrorActionPreference = "Stop"
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$main = Get-Content (Join-Path $root "src\PiPManager.Wpf\MainWindow.xaml.cs") -Raw
$coordinator = Get-Content (Join-Path $root "src\PiPManager.Wpf\Services\AutomationCoordinator.cs") -Raw

foreach ($required in @(
  "LegacyPipCaptured",
  "ObserveLegacyCaptured",
  "AutomationSignalKind.LegacyPipCaptured => AutomationSlotState.Active",
  "AutomationSignalKind.LegacyPipCaptured => ""confirm-active"""
)) {
  if (!$coordinator.Contains($required)) {
    throw "Automation coordinator capture behavior missing: $required"
  }
}

foreach ($required in @(
  "_automationCoordinator.ObserveLegacyCaptured(slot.Number, hwnd, source)",
  "BuildAutomationVideoTabsSignature",
  "ObserveAutomationVideoTabsUpdatedIfChanged",
  "AutomationVideoTabsSnapshotThrottleMs",
  "_lastAutomationVideoTabsSignature",
  "_lastAutomationVideoTabsObservedUtc"
)) {
  if (!$main.Contains($required)) {
    throw "Automation coordinator MainWindow behavior missing: $required"
  }
}

$successMethodStart = $main.IndexOf("private void ShadowMirrorReconnectSucceeded")
if ($successMethodStart -lt 0) {
  throw "ShadowMirrorReconnectSucceeded not found"
}
$successMethodEnd = $main.IndexOf("private void ShadowMirrorReconnectFailed", $successMethodStart)
$successMethod = $main.Substring($successMethodStart, $successMethodEnd - $successMethodStart)

$zeroCheck = $successMethod.IndexOf("if (hwnd == IntPtr.Zero)")
$observe = $successMethod.IndexOf("_automationCoordinator.ObserveLegacyReconnectSucceeded(slot.Number, hwnd, source)")
if ($zeroCheck -lt 0 -or $observe -lt 0 -or $observe -lt $zeroCheck) {
  throw "Reconnect success must be observed only after hwnd zero validation"
}

# 9.35.04: CurrentTime is allowed elsewhere in legacy logs/AutoReturn.
# It is forbidden only inside the Automation structural signature.
$signatureStart = $main.IndexOf("private static string BuildAutomationVideoTabsSignature")
if ($signatureStart -lt 0) {
  throw "BuildAutomationVideoTabsSignature not found"
}

$signatureEnd = $main.IndexOf("private void ObserveAutomationVideoTabsUpdatedIfChanged", $signatureStart)
if ($signatureEnd -lt 0) {
  throw "ObserveAutomationVideoTabsUpdatedIfChanged anchor not found"
}

$signatureMethod = $main.Substring($signatureStart, $signatureEnd - $signatureStart)
if ($signatureMethod.Contains("CurrentTime")) {
  throw "Automation video tab structural signature must not include CurrentTime"
}

foreach ($required in @(
  "automation-video-tabs-observed",
  "structuralSignature=True",
  "heartbeat={!changed}",
  "automation-capture-deferred-to-reconnect-success",
  "!_shadowReconnectAttemptIdBySlot.ContainsKey(slot.Number)"
)) {
  if (!$main.Contains($required)) {
    throw "Automation coordinator 9.35.03 behavior marker missing: $required"
  }
}

Write-Host "Automation Engine behavior checks OK."
