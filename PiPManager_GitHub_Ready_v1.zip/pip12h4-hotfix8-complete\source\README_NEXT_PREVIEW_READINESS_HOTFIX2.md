# PIP FIX7 Hotfix 2 — preview autoritativo e fallback rápido

Versão da extensão: `1.4.39.17-next-preview-readiness-hotfix2`.

## Correções

- o preview agora carrega um `nextPreviewAssetId` explícito e o WPF exige igualdade com `nextAssetId`;
- thumbnail do asset atual ou de outro asset é recusada;
- a página real do próximo vídeo é usada para recuperar `og:image`/`og:title` associados ao `nextAssetId`;
- `player-not-ready` executa uma única rechecagem após 250 ms;
- se continuar em `HAVE_NOTHING`, o silent reopen é pulado e o AutoReturn segue diretamente para o fallback físico;
- `video-not-ready` também interrompe imediatamente uma tentativa silenciosa já iniciada.

## Resultado esperado

O preview deixa de ficar um vídeo atrasado. Quando o player recém-navegado ainda estiver em `readyState=0`, o programa não desperdiça a espera integral de 3,6 segundos antes do atalho físico.
