$ErrorActionPreference = "Stop"
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$content = Get-Content -Raw (Join-Path $root "src\PiPManager.Extension\content.js")
$background = Get-Content -Raw (Join-Path $root "src\PiPManager.Extension\background.js")
$manifest = Get-Content -Raw (Join-Path $root "src\PiPManager.Extension\manifest.json")
$main = Get-Content -Raw (Join-Path $root "src\PiPManager.Wpf\MainWindow.xaml.cs")
$pip = Get-Content -Raw (Join-Path $root "src\PiPManager.Wpf\Services\PipWindowService.cs")
$win32 = Get-Content -Raw (Join-Path $root "src\PiPManager.Wpf\Services\Win32.cs")
$release = Get-Content -Raw (Join-Path $root "src\PiPManager.Wpf\Services\ReleaseInfoService.cs")

$checks = [ordered]@{
  "timeupdate telemetry reduced to 2500 ms" = $content.Contains("PIP_MANAGER_TIMEUPDATE_REPORT_MS = 2500") -and $content.Contains("reportVideoState(false)")
  "content structural heartbeat exists" = $content.Contains("PIP_MANAGER_STATE_HEARTBEAT_MS = 5000") -and $content.Contains("buildVideoStateReportSignature")
  "content event burst dedupe exists" = $content.Contains("PIP_MANAGER_FORCED_EVENT_DEDUPE_MS = 180") -and $content.Contains("unchanged && elapsedMs < PIP_MANAGER_FORCED_EVENT_DEDUPE_MS")
  "explicit content state request remains immediate" = $content.Contains("reportVideoState(true)") -and $content.Contains("message.type === 'requestVideoState'")
  "background snapshot heartbeat exists" = $background.Contains("SESSIONS_SNAPSHOT_HEARTBEAT_MS = 5000") -and $background.Contains("buildSessionsSnapshotSignature")
  "background suppresses identical snapshots" = $background.Contains("signature === lastSessionsSnapshotSignature") -and $background.Contains("return false")
  "explicit app snapshot request is forced" = $background.Contains("sendSessionsSnapshot(true)")
  "health timer is lower pressure" = $main.Contains("HealthTimerIntervalMs = 1800") -and $main.Contains("HealthDragTargetsRefreshMs = 5000")
  "geometry cadence is separated" = $main.Contains("HealthGeometryRefreshMs = 3000") -and $main.Contains("if (!refreshGeometry)")
  "full EnumWindows discovery is recovery-only" = $main.Contains("EnsureDiscoveryForRecovery") -and $main.Contains("List<PipWindowInfo>? discovered = null")
  "topmost style checked before correction" = $main.Contains("!PipWindowService.IsTopMost(handle)") -and $pip.Contains("public static bool IsTopMost")
  "topmost correction is asynchronous" = $pip.Contains("SWP_ASYNCWINDOWPOS") -and $win32.Contains("WS_EX_TOPMOST = 0x00000008L")
  "playback fluency retained in 9.39.01" = $release.Contains('ProductVersion = "9.39.01"') -and $release.Contains('AppVersion = "1.5.12.3901"')
  "extension version is 1.4.39.25" = $manifest.Contains('"version": "1.4.39.25"') -and $release.Contains('ExtensionVersion = "1.4.39.25"')
}

$failed = @()
foreach ($item in $checks.GetEnumerator()) {
  if ($item.Value) { Write-Host ($item.Key + ": OK") }
  else { Write-Host ($item.Key + ": FAIL"); $failed += $item.Key }
}

if ($failed.Count -gt 0) {
  throw "Playback fluency guard checks failed: $($failed -join ', ')"
}

Write-Host "Playback fluency guard checks OK."
