$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$main = Get-Content (Join-Path $Root 'src\PiPManager.Wpf\MainWindow.xaml.cs') -Raw
$video = Get-Content (Join-Path $Root 'src\PiPManager.Wpf\Services\VideoCommandService.cs') -Raw
$run = Get-Content (Join-Path $Root 'RUN_CORE_TESTS.bat') -Raw
$checks = @(
  @{ Name='initial open waits for confirmed HWND'; Ok=($main -match 'WaitForInitialOpenHwndAsync') },
  @{ Name='initial open minimizes browser after confirmation'; Ok=($main -match 'initial-open-browser-minimized-after-confirmation') },
  @{ Name='initial open shortcut path uses immediate minimize'; Ok=($main -match 'manual-open/shortcut.*, timeoutMs: 700') },
  @{ Name='initial open fallback path uses immediate minimize'; Ok=($main -match 'manual-open/fallback.*, timeoutMs: 850') },
  @{ Name='initial wait is event-responsive'; Ok=($main -match 'Task.Delay\(25\)') },
  @{ Name='browser minimize API retained'; Ok=($video -match 'TryMinimizeExpectedBrowserWindow') },
  @{ Name='checker included in core gate'; Ok=($run -match 'CHECK_INITIAL_OPEN_BROWSER_MINIMIZE.ps1') }
)
$failed=0
foreach($c in $checks){ if($c.Ok){Write-Host "$($c.Name): OK"} else {Write-Host "$($c.Name): FAIL"; $failed++}}
if($failed -gt 0){throw 'Initial open browser minimize checks failed.'}
Write-Host 'Initial open browser minimize checks OK.'
