# PiPManager Fix4 RC6 - README

## Branch Overview

This is the **Fix4 RC6** stable release branch of PiPManager, offering a mature and tested Picture-in-Picture management system for Firefox.

**Branch**: `fix4-rc6`  
**Application Version**: 9.39.03  
**Extension Version**: 1.4.39.7  
**Release Date**: 2026-08-05  
**Status**: Stable (Release Candidate)

## What's in This Branch

### Core Features
- ✅ Automatic PiP window restoration
- ✅ Multi-site video platform support
- ✅ Tab occupancy notifications (v2 optimized)
- ✅ Fixed layout mode
- ✅ Real-time tab occupancy tracking
- ✅ Intelligent playlist navigation

### Architecture
```
PiPManager_9.39.03_FIX4_RC3_P0_OPTIMIZATION_RC6_SOURCE/
├── Source Code/
│   ├── Core/                 # PiP management engine
│   ├── UI/                   # WPF interface
│   ├── Services/             # Video detection, platform support
│   └── Configuration/        # Settings management
├── Extension/
│   ├── Content Scripts/      # Page interaction
│   ├── Background Scripts/   # State management
│   └── UI Components/        # Popup and options
├── Tests/                    # Unit and integration tests
└── Documentation/            # Build guides, API docs
```

## Getting Started

### 1. Prerequisites
```powershell
# Check .NET installation
dotnet --version    # Must be 8.0 or higher

# Verify Windows version
[System.Environment]::OSVersion.VersionString
```

### 2. Build
```powershell
# Navigate to project directory
cd "PiPManager_9.39.03_FIX4_RC3_P0_OPTIMIZATION_RC6_SOURCE"

# Build application
.\BUILD_WINDOWS.bat
# OR
dotnet build -c Release
```

### 3. Test
```powershell
# Run test suite
dotnet test

# Manual testing checklist in SETUP_FIX4_RC6.md
```

### 4. Install Extension
1. Open Firefox
2. Go to `about:debugging#/runtime/this-firefox`
3. Click "Load Temporary Add-on"
4. Select `Extension/manifest.json`

## Stability & Quality

### Tested Features
- ✓ Multi-platform video site support (YouTube, Vimeo, Dailymotion, Twitch)
- ✓ Tab occupancy detection and notifications
- ✓ PiP window restoration across sessions
- ✓ Layout switching stability
- ✓ Memory usage optimization
- ✓ Browser extension communication
- ✓ Windows 10 and 11 compatibility
- ✓ Firefox 90+ compatibility

### Known Limitations
- Desktop application Windows-only (no macOS/Linux)
- Firefox extension only (Chrome/Edge not supported in this branch)
- Requires .NET 8 Runtime

### Performance
- Low memory footprint (~30-50MB)
- Minimal browser extension overhead
- Efficient tab occupancy tracking
- Optimized video detection

## Documentation

- **SETUP_FIX4_RC6.md** - Complete build and deployment guide
- **VERSION.txt** - Version information (in build output)
- **BUILD_WINDOWS.bat** - Automated build script
- **README.md** (main branch) - Project overview

## Deployment

### For End Users
```powershell
# Download release package
# Extract to Program Files
# Run installer (if provided)
# Install Firefox extension from package
```

### For Developers
```powershell
# Clone and checkout
git clone https://github.com/pip-teste/PiPManager.git
git checkout fix4-rc6

# Build from source
.\BUILD_WINDOWS.bat

# Install dev extension via about:debugging
```

### System Requirements
- **OS**: Windows 10 (build 1909)+ or Windows 11
- **.NET**: 8.0 Runtime or SDK
- **Browser**: Firefox 90+
- **RAM**: 2GB minimum
- **Disk**: 500MB for build artifacts

## Support

### Issue Reporting
When reporting issues, include:
1. **Version**: 9.39.03 (1.4.39.7 extension)
2. **Branch**: fix4-rc6
3. **OS**: Windows version and build number
4. **Reproduction Steps**: Clear step-by-step
5. **Error Messages**: Full error text
6. **Logs**: Application logs if available

### Common Issues

**PiP window not restoring?**
- Check if browser extension is installed
- Verify Firefox version is 90+
- Restart both application and browser

**Tab occupancy not detecting videos?**
- Ensure browser extension is active
- Try refreshing the page
- Check Firefox console for script errors

**Layout switching crashes?**
- Update .NET Runtime to latest
- Rebuild application from source
- Check for conflicting applications

## Contributing

This is a stable branch. For contributions:
1. Report issues in GitHub Issues
2. Submit bug fixes as pull requests
3. Follow CONTRIBUTING.md guidelines
4. Ensure all tests pass
5. Update documentation

## Roadmap

**fix4-rc6** is feature-complete for:
- ✓ Tab occupancy management
- ✓ Multi-slot layouts
- ✓ Platform support
- ✓ PiP restoration

Future enhancements will be in the **pip12h4-hotfix8** development branch.

## Related Branches

- **main**: Documentation and project overview
- **pip12h4-hotfix8**: Development branch with advanced features and hotfixes

## Technical Specs

### Application
- **Platform**: .NET 8 + WPF
- **Target OS**: Windows 10 1909+, Windows 11
- **Architecture**: x64 (x86 available)

### Extension
- **Type**: WebExtension (Firefox)
- **Manifest**: Version 3
- **Permissions**: Content script, Storage, Communications
- **Supported Browsers**: Firefox 90+

### Database
- Settings: JSON files in AppData
- State: In-memory during session
- Persistence: File-based automatic backup

## Version Comparison

| Feature | This Branch | Development |
|---------|------------|------------|
| Status | Stable | Development |
| AutoReturn Basic | ✓ | ✓ |
| AutoReturn Advanced | ✗ | ✓ |
| Tab Occupancy v2 | ✓ | ✓ |
| Integrated Sync | ✗ | ✓ |
| Geometry Authority | Basic | Universal |
| Production Ready | ✓ | ✗ |

## Performance Benchmarks

- **Startup Time**: <2 seconds
- **Memory Usage**: ~40MB average
- **Video Detection**: <100ms per page
- **Tab Occupancy Check**: <50ms per tab

## License

MIT License - See LICENSE file

## Acknowledgments

- Firefox community for WebExtension support
- .NET/WPF developers
- Video platform API maintainers
- Testers and contributors

---

**Last Updated**: 2026-08-05  
**Maintained By**: PiPManager Team  
**Repository**: https://github.com/pip-teste/PiPManager
