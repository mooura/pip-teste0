﻿$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$content = Get-Content (Join-Path $root 'src\PiPManager.Extension\content.js') -Raw
$main = Get-Content (Join-Path $root 'src\PiPManager.Wpf\MainWindow.xaml.cs') -Raw
$drag = Get-Content (Join-Path $root 'src\PiPManager.Wpf\MainWindow.PipDrag.cs') -Raw
$fixed = Get-Content (Join-Path $root 'src\PiPManager.Wpf\MainWindow.FixedLayout.cs') -Raw
$checks = [ordered]@{
  'five second network warming window' = $content.Contains('NEXT_VIDEO_PRELOAD_NETWORK_WINDOW_MS = 5000')
  'matching command target arms preload handoff' = $content.Contains('PRELOAD_HANDOFF_TO_NAVIGATION') -and $content.Contains('handoff-armed')
  'generation reset preserves matching preload' = $content.Contains('generation-change-preserved-command-handoff') -and $content.Contains('cancel-skipped-command-handoff') -and $content.Contains("reason === 'target-changed'")
  'handoff is consumed only after target becomes current' = $content.Contains('command-target-became-current') -and $content.Contains('handoff-consumed')
  'empty warming is not reported ready' = $content.Contains("const lifecycleState = hasUsefulBytes ? 'READY' : (hasPartialBytes ? 'PRELOAD_PARTIAL' : 'PRELOAD_EMPTY')") -and $content.Contains('range-preload-byte-cache-empty')
  'buffer envelope is eight to twelve seconds' = $content.Contains('NEXT_VIDEO_PRELOAD_MIN_USEFUL_BUFFER_SECONDS = 8') -and $content.Contains('NEXT_VIDEO_PRELOAD_TARGET_BUFFER_SECONDS = 10') -and $content.Contains('NEXT_VIDEO_PRELOAD_MAX_BUFFER_SECONDS = 12')
  'slot-level geometry authority survives hwnd replacement' = $main.Contains('SlotNavigationGeometryAuthorityState') -and $main.Contains('_lastManualUserRectBySlot') -and $main.Contains('slot-navigation-geometry-safe-fallback')
  'next command arms geometry before loss' = $main.Contains('ArmSlotNavigationGeometryAuthority(slot, "video-command-next")')
  'prepared capture binds geometry authority' = $main.Contains('BindSlotNavigationGeometryAuthority(slot, newWindow.Handle, "CapturePreparedPipWindow", preferredAspectRatio)')
  'late browser inflation checks span 4.2 seconds' = $main.Contains('ReconnectGeometryVerifyCheckpointsMs = [0, 150, 400, 900, 1800, 3200, 4200]')
  'confirmed manual resize updates stable reference' = $drag.Contains('_lastManualUserRectBySlot[slot.Number] = finalRect')
  'plain pip click does not cancel geometry protection' = -not $drag.Contains('CancelReconnectGeometryAuthority(handle, "natural-anchor-drag-started")')
  'fixed layout yields to slot authority' = $fixed.Contains('TryGetSlotNavigationGeometryTarget')
}
$failed = 0
foreach ($item in $checks.GetEnumerator()) {
  if ($item.Value) { Write-Host ($item.Key + ': OK') }
  else { Write-Host ($item.Key + ': FAIL'); $failed++ }
}
if ($failed -gt 0) { throw 'Universal geometry + preload handoff Hotfix 7 checks failed.' }
Write-Host 'Universal geometry + preload handoff Hotfix 7 checks OK.'
