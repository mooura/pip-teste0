﻿namespace PiPManager.Wpf.Services;

public enum AutomationSlotState
{
    Empty,
    Preparing,
    Active,
    Lost,
    Reconnecting,
    Paused,
    Failed
}

public enum AutomationOperationProfile
{
    Conservative,
    Balanced,
    Aggressive
}

public enum AutomationSignalKind
{
    WindowCreated,
    WindowShown,
    WindowDestroyed,
    WindowHidden,
    WindowMovedOrResized,
    WindowTitleChanged,
    WindowForegroundChanged,
    ExtensionPipEvent,
    ExtensionVideoTabsUpdated,
    LegacyPipCaptured,
    LegacyPipLost,
    LegacyReconnectStarted,
    LegacyReconnectSucceeded,
    LegacyReconnectFailed,
    ManualAction
}

public sealed record AutomationSignal(
    AutomationSignalKind Kind,
    int SlotNumber,
    IntPtr Hwnd,
    string Source,
    string Summary,
    DateTimeOffset CreatedAtUtc);

public sealed record AutomationDecision(
    DateTimeOffset CreatedAtUtc,
    AutomationSignalKind SignalKind,
    int SlotNumber,
    AutomationSlotState State,
    string RecommendedAction,
    int Confidence,
    string Reason,
    string RecoveryPlan,
    bool ShadowOnly);

public interface IAutomationCoordinator
{
    bool ShadowOnly { get; }
    AutomationOperationProfile Profile { get; }
    IReadOnlyList<AutomationDecision> RecentDecisions { get; }

    AutomationDecision Observe(AutomationSignal signal);
    AutomationDecision ObserveWindowEvent(WindowMonitorEvent ev, int slotNumber);
    AutomationDecision ObserveExtensionPipEvent(string summary, int slotNumber, IntPtr hwnd);
    AutomationDecision ObserveVideoTabsUpdated(int tabCount);
    AutomationDecision ObserveLegacyCaptured(int slotNumber, IntPtr hwnd, string source);
    AutomationDecision ObserveLegacyLoss(int slotNumber, IntPtr hwnd, string source);
    AutomationDecision ObserveLegacyReconnectStarted(int slotNumber, string source);
    AutomationDecision ObserveLegacyReconnectSucceeded(int slotNumber, IntPtr hwnd, string source);
    AutomationDecision ObserveLegacyReconnectFailed(int slotNumber, string reason, string source);
}

public sealed class AutomationCoordinator : IAutomationCoordinator
{
    private readonly object _gate = new();
    private readonly Dictionary<int, AutomationSlotState> _stateBySlot = [];
    private readonly Dictionary<int, DateTimeOffset> _lastFailureUtcBySlot = [];
    private readonly Queue<AutomationDecision> _recent = new();

    public bool ShadowOnly => true;
    public AutomationOperationProfile Profile { get; private set; } = AutomationOperationProfile.Balanced;

    public IReadOnlyList<AutomationDecision> RecentDecisions
    {
        get
        {
            lock (_gate)
                return _recent.ToArray();
        }
    }

    public AutomationDecision ObserveWindowEvent(WindowMonitorEvent ev, int slotNumber)
    {
        var kind = ev.Kind switch
        {
            WindowMonitorEventKind.Created => AutomationSignalKind.WindowCreated,
            WindowMonitorEventKind.Shown => AutomationSignalKind.WindowShown,
            WindowMonitorEventKind.Destroyed => AutomationSignalKind.WindowDestroyed,
            WindowMonitorEventKind.Hidden => AutomationSignalKind.WindowHidden,
            WindowMonitorEventKind.MovedOrResized => AutomationSignalKind.WindowMovedOrResized,
            WindowMonitorEventKind.TitleChanged => AutomationSignalKind.WindowTitleChanged,
            WindowMonitorEventKind.ForegroundChanged => AutomationSignalKind.WindowForegroundChanged,
            _ => AutomationSignalKind.ManualAction
        };

        return Observe(new AutomationSignal(
            kind,
            slotNumber,
            ev.Hwnd,
            "window-event-monitor",
            $"kind={ev.Kind}; relevant={ev.Relevant}; reason={ev.Reason}",
            ev.CreatedAtUtc));
    }

    public AutomationDecision ObserveExtensionPipEvent(string summary, int slotNumber, IntPtr hwnd)
    {
        return Observe(new AutomationSignal(
            AutomationSignalKind.ExtensionPipEvent,
            slotNumber,
            hwnd,
            "extension",
            summary,
            DateTimeOffset.UtcNow));
    }

    public AutomationDecision ObserveVideoTabsUpdated(int tabCount)
    {
        return Observe(new AutomationSignal(
            AutomationSignalKind.ExtensionVideoTabsUpdated,
            0,
            IntPtr.Zero,
            "extension",
            $"tabCount={tabCount}",
            DateTimeOffset.UtcNow));
    }


    public AutomationDecision ObserveLegacyCaptured(int slotNumber, IntPtr hwnd, string source)
    {
        return Observe(new AutomationSignal(
            AutomationSignalKind.LegacyPipCaptured,
            slotNumber,
            hwnd,
            source,
            "legacy-pip-captured",
            DateTimeOffset.UtcNow));
    }

    public AutomationDecision ObserveLegacyLoss(int slotNumber, IntPtr hwnd, string source)
    {
        return Observe(new AutomationSignal(
            AutomationSignalKind.LegacyPipLost,
            slotNumber,
            hwnd,
            source,
            "legacy-loss-detected",
            DateTimeOffset.UtcNow));
    }

    public AutomationDecision ObserveLegacyReconnectStarted(int slotNumber, string source)
    {
        return Observe(new AutomationSignal(
            AutomationSignalKind.LegacyReconnectStarted,
            slotNumber,
            IntPtr.Zero,
            source,
            "legacy-reconnect-started",
            DateTimeOffset.UtcNow));
    }

    public AutomationDecision ObserveLegacyReconnectSucceeded(int slotNumber, IntPtr hwnd, string source)
    {
        return Observe(new AutomationSignal(
            AutomationSignalKind.LegacyReconnectSucceeded,
            slotNumber,
            hwnd,
            source,
            "legacy-reconnect-succeeded",
            DateTimeOffset.UtcNow));
    }

    public AutomationDecision ObserveLegacyReconnectFailed(int slotNumber, string reason, string source)
    {
        return Observe(new AutomationSignal(
            AutomationSignalKind.LegacyReconnectFailed,
            slotNumber,
            IntPtr.Zero,
            source,
            reason,
            DateTimeOffset.UtcNow));
    }

    public AutomationDecision Observe(AutomationSignal signal)
    {
        lock (_gate)
        {
            var previous = GetState(signal.SlotNumber);
            var next = DetermineNextState(signal, previous);
            if (signal.SlotNumber > 0)
                _stateBySlot[signal.SlotNumber] = next;

            if (signal.Kind == AutomationSignalKind.LegacyReconnectFailed && signal.SlotNumber > 0)
                _lastFailureUtcBySlot[signal.SlotNumber] = DateTimeOffset.UtcNow;

            var decision = BuildDecision(signal, previous, next);
            _recent.Enqueue(decision);
            while (_recent.Count > 200)
                _recent.Dequeue();

            var decisionLog =
                $"automation-shadow-decision: signal={decision.SignalKind}; slot={decision.SlotNumber}; state={decision.State}; " +
                $"action={decision.RecommendedAction}; confidence={decision.Confidence}; reason={decision.Reason}; plan={decision.RecoveryPlan}; shadowOnly={decision.ShadowOnly}";

            if (decision.SignalKind == AutomationSignalKind.ExtensionVideoTabsUpdated)
                AppLogger.InfoAggregated("automation-shadow-video-tabs", TimeSpan.FromSeconds(2), decisionLog);
            else
                AppLogger.Info(decisionLog);

            return decision;
        }
    }

    private AutomationSlotState GetState(int slotNumber)
    {
        if (slotNumber <= 0)
            return AutomationSlotState.Empty;

        return _stateBySlot.TryGetValue(slotNumber, out var state)
            ? state
            : AutomationSlotState.Empty;
    }

    private static AutomationSlotState DetermineNextState(AutomationSignal signal, AutomationSlotState previous)
    {
        return signal.Kind switch
        {
            AutomationSignalKind.WindowCreated or AutomationSignalKind.WindowShown => previous is AutomationSlotState.Lost or AutomationSlotState.Reconnecting
                ? AutomationSlotState.Reconnecting
                : AutomationSlotState.Preparing,

            AutomationSignalKind.WindowDestroyed or AutomationSignalKind.WindowHidden or AutomationSignalKind.LegacyPipLost => AutomationSlotState.Lost,

            AutomationSignalKind.LegacyPipCaptured => AutomationSlotState.Active,
            AutomationSignalKind.LegacyReconnectStarted => AutomationSlotState.Reconnecting,
            AutomationSignalKind.LegacyReconnectSucceeded => AutomationSlotState.Active,
            AutomationSignalKind.LegacyReconnectFailed => AutomationSlotState.Failed,

            AutomationSignalKind.ExtensionPipEvent => previous,
            AutomationSignalKind.ExtensionVideoTabsUpdated => previous,
            AutomationSignalKind.WindowMovedOrResized or AutomationSignalKind.WindowTitleChanged or AutomationSignalKind.WindowForegroundChanged => previous,

            _ => previous
        };
    }

    private AutomationDecision BuildDecision(AutomationSignal signal, AutomationSlotState previous, AutomationSlotState next)
    {
        var confidence = EstimateConfidence(signal, previous, next);
        var action = RecommendAction(signal, previous, next, confidence);
        var plan = BuildRecoveryPlan(signal, previous, next, confidence);
        var reason = BuildReason(signal, previous, next, confidence);

        return new AutomationDecision(
            DateTimeOffset.UtcNow,
            signal.Kind,
            signal.SlotNumber,
            next,
            action,
            confidence,
            reason,
            plan,
            ShadowOnly);
    }

    private int EstimateConfidence(AutomationSignal signal, AutomationSlotState previous, AutomationSlotState next)
    {
        var score = 40;

        if (signal.SlotNumber > 0)
            score += 15;

        if (signal.Hwnd != IntPtr.Zero)
            score += 15;

        if (signal.Kind is AutomationSignalKind.LegacyReconnectSucceeded or AutomationSignalKind.LegacyPipLost or AutomationSignalKind.LegacyPipCaptured)
            score += 20;

        if (signal.Kind is AutomationSignalKind.WindowCreated or AutomationSignalKind.WindowShown)
            score += previous is AutomationSlotState.Lost or AutomationSlotState.Reconnecting ? 20 : 10;

        if (signal.Kind is AutomationSignalKind.WindowDestroyed or AutomationSignalKind.WindowHidden)
            score += 10;

        if (signal.Kind == AutomationSignalKind.LegacyReconnectFailed)
            score -= 10;

        if (signal.SlotNumber > 0 &&
            _lastFailureUtcBySlot.TryGetValue(signal.SlotNumber, out var lastFailure) &&
            (DateTimeOffset.UtcNow - lastFailure).TotalSeconds < 20)
        {
            score -= 15;
        }

        return Math.Clamp(score, 0, 100);
    }

    private static string RecommendAction(AutomationSignal signal, AutomationSlotState previous, AutomationSlotState next, int confidence)
    {
        if (confidence < 50)
            return "wait-for-confirmation";

        return signal.Kind switch
        {
            AutomationSignalKind.WindowCreated or AutomationSignalKind.WindowShown => "request-immediate-refresh",
            AutomationSignalKind.WindowDestroyed or AutomationSignalKind.WindowHidden or AutomationSignalKind.LegacyPipLost => "reserve-slot-and-observe-recovery",
            AutomationSignalKind.LegacyReconnectStarted => "observe-reconnect",
            AutomationSignalKind.LegacyPipCaptured => "confirm-active",
            AutomationSignalKind.LegacyReconnectSucceeded => "confirm-active",
            AutomationSignalKind.LegacyReconnectFailed => "cooldown-and-stop-loop",
            AutomationSignalKind.ExtensionVideoTabsUpdated => "update-candidates",
            _ => "compare-only"
        };
    }

    private static string BuildRecoveryPlan(AutomationSignal signal, AutomationSlotState previous, AutomationSlotState next, int confidence)
    {
        if (next == AutomationSlotState.Lost || next == AutomationSlotState.Reconnecting)
            return "1-adopt-existing-pip;2-request-extension-reopen;3-locate-video-again;4-mark-unavailable";

        if (next == AutomationSlotState.Failed)
            return "cooldown-progressive;manual-action-cancels-automation";

        if (next == AutomationSlotState.Active)
            return "keep-slot;monitor-video-change";

        return "observe-only";
    }

    private static string BuildReason(AutomationSignal signal, AutomationSlotState previous, AutomationSlotState next, int confidence)
    {
        return $"source={signal.Source}; previous={previous}; summary={signal.Summary}; confidence={confidence}";
    }
}
