$ErrorActionPreference = "Stop"
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$logger = Get-Content -Raw (Join-Path $root "src\PiPManager.Wpf\Services\AppLogger.cs")
$monitor = Get-Content -Raw (Join-Path $root "src\PiPManager.Wpf\Services\WindowsEventMonitorService.cs")
$coordinator = Get-Content -Raw (Join-Path $root "src\PiPManager.Wpf\Services\AutomationCoordinator.cs")
$bridge = Get-Content -Raw (Join-Path $root "src\PiPManager.Wpf\Services\ExtensionBridgeService.cs")
$main = Get-Content -Raw (Join-Path $root "src\PiPManager.Wpf\MainWindow.xaml.cs")
$release = Get-Content -Raw (Join-Path $root "src\PiPManager.Wpf\Services\ReleaseInfoService.cs")

$checks = [ordered]@{
  "keyed aggregate logger exists" = $logger.Contains("InfoAggregated") -and $logger.Contains("aggregatedSuppressed") -and $logger.Contains("FlushAggregatedLogs")
  "polling heartbeat is 15 seconds" = $monitor.Contains("PollingLogThrottleMs = 15000")
  "video snapshot logs aggregated" = $main.Contains("AutomationVideoTabsChangedLogAggregateMs = 1500") -and $main.Contains('"automation-video-tabs-observed"')
  "shadow snapshot decisions aggregated" = $coordinator.Contains('"automation-shadow-video-tabs"') -and $coordinator.Contains("ExtensionVideoTabsUpdated")
  "raw non-silent diagnostics aggregated" = $bridge.Contains('"silent-diagnostic-raw-nonsilent"') -and $bridge.Contains("!silent")
  "preservation repeat logs aggregated" = $main.Contains('pip-preserve-new-video-detected:{state.SlotNumber}:{state.CommandType}')
  "waiting real change logs aggregated" = $main.Contains('auto-return-waiting-real-change:{state.SlotNumber}')
  "preflight completion is signal driven" = $main.Contains("ArmSilentPreflightResultWait") -and $main.Contains("SignalSilentPreflightResultWait") -and $main.Contains("Task.WhenAny(preflightResultSignal.Task")
  "preflight timeout fallback retained" = $main.Contains("SilentPreflightFallbackWaitMs = 880") -and $main.Contains("timeout-fallback")
  "terminal baseline uses pre-next preservation" = $main.Contains('baselineSource = "preservation-before-next"') -and $main.Contains("preservation.OldUrl")
  "terminal real-change requirement retained" = $main.Contains('EligibilityMode = "terminal-auto-next-real-change"') -and $main.Contains("RequiresRealVideoChange = true")
  "HWND and generation guards retained" = $main.Contains("IsAutoReturnAttemptCurrent") -and $main.Contains("CancellationGeneration = GetAutoReturnCancellationGeneration")
  "release metadata remains explicit" = $release.Contains('ProductVersion = "') -and $release.Contains('AppVersion = "') -and $release.Contains('ExtensionVersion = "1.4.39.')
}

$failed = @()
foreach ($item in $checks.GetEnumerator()) {
  if ($item.Value) { Write-Host ($item.Key + ": OK") }
  else { Write-Host ($item.Key + ": FAIL"); $failed += $item.Key }
}

if ($failed.Count -gt 0) {
  throw "Fluency Core Phase 1.1 checks failed: $($failed -join ', ')"
}

Write-Host "Fluency Core Phase 1.1 checks OK."
