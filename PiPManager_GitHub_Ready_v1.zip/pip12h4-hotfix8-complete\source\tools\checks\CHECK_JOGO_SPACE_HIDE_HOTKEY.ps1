﻿$ErrorActionPreference = 'Stop'

$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$settings = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\Models\AppSettings.cs') -Raw
$xaml = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\MainWindow.xaml') -Raw
$main = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\MainWindow.xaml.cs') -Raw
$hotkey = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\MainWindow.JogoSpaceHotkey.cs') -Raw
$runner = Get-Content -LiteralPath (Join-Path $root 'RUN_CORE_TESTS.bat') -Raw

$checks = [ordered]@{
    'optional setting persists' =
        $settings.Contains('public bool JogoSpaceHideHotkeyEnabled { get; set; } = false;') -and
        $main.Contains('_settings.JogoSpaceHideHotkeyEnabled = _jogoSpaceHideHotkeyEnabled;')
    'Jogo menu exposes opt-in Space shortcut' =
        $xaml.Contains('x:Name="JogoSpaceHideHotkeyMenuItem"') -and
        $xaml.Contains('IsCheckable="True"') -and
        $xaml.Contains('Click="JogoSpaceHideHotkeyMenuItem_Click"')
    'Space is a no-repeat global hotkey' =
        $hotkey.Contains('private const uint ModNoRepeat = 0x4000;') -and
        $hotkey.Contains('private const uint VkSpace = 0x20;') -and
        $hotkey.Contains('RegisterHotKey(') -and
        $hotkey.Contains('ModNoRepeat,') -and
        $hotkey.Contains('VkSpace);')
    'registration is restricted to Jogo profile' =
        $hotkey.Contains('var shouldRegister = _jogoSpaceHideHotkeyEnabled && CurrentLayout == LayoutMode.Jogo;') -and
        $hotkey.Contains('CurrentLayout != LayoutMode.Jogo') -and
        $main.Contains('UpdateJogoSpaceHideHotkeyRegistration("layout-changed");')
    'Space toggles the existing visibility authority' =
        $hotkey.Contains('message != WmHotkey') -and
        $hotkey.Contains('ToggleAllVisibility();') -and
        $hotkey.Contains('jogo-space-hide-hotkey-triggered') -and
        $hotkey.Contains('handled = true;')
    'non-Jogo profile releases Space immediately' =
        $hotkey.Contains('UnregisterJogoSpaceHideHotkey(source);') -and
        $hotkey.Contains('reason={(CurrentLayout == LayoutMode.Jogo ? "disabled" : "profile-not-jogo")}') -and
        $main.Contains('UpdateJogoSpaceHideHotkeyRegistration("enter-custom-mode");')
    'window lifecycle owns registration' =
        $main.Contains('ActivateJogoSpaceHideHotkey();') -and
        $main.Contains('DisposeJogoSpaceHideHotkey();') -and
        $hotkey.Contains('RemoveHook(JogoSpaceHideHotkeyWndProc)')
    'checker included in core gate' =
        $runner.Contains('CHECK_JOGO_SPACE_HIDE_HOTKEY.ps1')
}

$failed = @()
Write-Host 'Checking Jogo Space hide/show hotkey...'
foreach ($item in $checks.GetEnumerator()) {
    if ($item.Value) {
        Write-Host "$($item.Key): OK"
    }
    else {
        Write-Host "$($item.Key): FAIL"
        $failed += $item.Key
    }
}

if ($failed.Count -gt 0) {
    throw "Jogo Space hide/show hotkey checks failed: $($failed -join ', ')"
}

Write-Host 'Jogo Space hide/show hotkey checks OK.' -ForegroundColor Green
