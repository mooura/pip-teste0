# Terminal Auto-Next Identity + Bounded Readiness Hotfix 5

Version: `1.4.39.21-reconnect-ownership-geometry-hotfix6`

- URL/index-only transitions are `NAVIGATION_PENDING`, not `VIDEO_CHANGED`.
- Terminal auto-next has its own generation, separate from manual `CommandTarget`.
- Readiness deferrals are strictly bounded.
- After 4 seconds without source the target is diagnosed as unavailable.
- After 8 seconds active probing becomes a passive structural watch.
- A later real session/source resumes AutoReturn.
- Preload `src` removal is allowed only for the owned auxiliary `next-preload` element.
