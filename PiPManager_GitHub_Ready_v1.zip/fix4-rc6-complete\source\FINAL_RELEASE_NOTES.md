# P0 Optimization RC6 — aplicativo 1.5.12.3909

A RC6 corrige o modo **Fixar layout** a partir do log real de 4 de agosto de 2026.

- a autoridade fixa é exclusiva dos HWNDs PiP vinculados; o EA SPORTS FC 26 e
  qualquer outra janela externa deixam de ser reposicionados;
- o ciclo de recuperação usa deadline absoluta de 45 segundos, sem ampliação por
  quantidade de slots;
- uma troca de slot durante a recuperação remapeia os conjuntos esperado e
  recuperado, evitando aguardar o número antigo;
- cada PiP recuperado é colocado uma única vez, com `resize=False`;
- conclusão e timeout não executam lote global nem movem PiPs não relacionados;
- reflow de aspecto pendente é descartado ao final da recuperação para não
  sobrescrever a autoridade fixa recém-restaurada.

# P0 Optimization RC5 — aplicativo 1.5.12.3908

A RC5 mantém todas as otimizações P0 anteriores e elimina trabalho redundante durante
o Ocultar/Mostrar inteligente. Janelas já vinculadas deixam de entrar no fluxo de captura
e eventos de visibilidade gerados pelo próprio aplicativo não acionam refresh ou AutoReturn.

O atraso observado em um player Stripchat ocorreu antes da criação do HWND pelo Firefox;
após `Shown`, a captura assistida continuou abaixo de 500 ms.
