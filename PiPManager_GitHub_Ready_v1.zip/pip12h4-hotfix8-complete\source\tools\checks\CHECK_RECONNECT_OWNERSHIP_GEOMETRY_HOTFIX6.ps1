$ErrorActionPreference = 'Stop'
$root = Resolve-Path (Join-Path $PSScriptRoot '..\..')
$main = Get-Content (Join-Path $root 'src\PiPManager.Wpf\MainWindow.xaml.cs') -Raw
$fixed = Get-Content (Join-Path $root 'src\PiPManager.Wpf\MainWindow.FixedLayout.cs') -Raw
$drag = Get-Content (Join-Path $root 'src\PiPManager.Wpf\MainWindow.PipDrag.cs') -Raw
$manifest = Get-Content (Join-Path $root 'src\PiPManager.Extension\manifest.json') -Raw | ConvertFrom-Json
$checks = [ordered]@{
  'manifest is 1.4.39.25' = ([string]$manifest.version -eq '1.4.39.25')
  'cross-browser candidate is rejected' = $main.Contains('smart-reconnect-cross-browser-rejected') -and $main.Contains('IsReconnectCandidateProcessCompatible(slot, candidate')
  'reconnect preserves position and size' = $main.Contains('PipWindowService.MoveAndResizeVisual(newHandle, referenceRect)')
  'late browser inflation is corrected' = $main.Contains('ReconnectGeometryVerifyCheckpointsMs = [0, 150, 400, 900, 1800, 3200, 4200]') -and $main.Contains('reconnect-geometry-corrected')
  'monitor enforces reconnect authority' = $main.Contains('TryEnforceReconnectGeometryAuthority(slot, rect, "Monitor de PiP")')
  'fixed layout yields to reconnect authority' = $fixed.Contains('reason=reconnect-geometry-authority-active')
  'confirmed manual resize cancels reconnect authority' = $drag.Contains('CancelReconnectGeometryAuthority(handle, "manual-resize-committed")')
  'manual next re-resolves target' = $main.Contains('next-command-target-reresolved')
  'playlist next blocks empty target' = $main.Contains('next-command-blocked-no-authoritative-target')
  'node regression is wired' = (Get-Content (Join-Path $root 'RUN_CORE_TESTS.bat') -Raw).Contains('reconnect-ownership-geometry-hotfix6.test.js')
}
$failed = @()
foreach ($item in $checks.GetEnumerator()) {
  if ($item.Value) { Write-Host ($item.Key + ': OK') -ForegroundColor Green }
  else { Write-Host ($item.Key + ': FAIL') -ForegroundColor Red; $failed += $item.Key }
}
if ($failed.Count -gt 0) { throw ('Reconnect ownership + geometry Hotfix 6 checks failed: ' + ($failed -join ', ')) }
Write-Host 'Reconnect ownership + geometry Hotfix 6 checks OK.' -ForegroundColor Green
