# PiP Manager 9.39.03 Fix4 RC3 — P0 Optimization RC1

Esta árvore deriva da candidata **Fix4 RC3 Telemetry** e inicia o pacote P0 de
fluidez e otimização sem alterar intencionalmente as regras de layout, vínculo,
navegação, preservação ou AutoReturn.

## Alterações implementadas

### 1. Arraste coalescido antes do Dispatcher

`PipGroupMouseDragService` não envia mais um `BeginInvoke` para cada pixel do
mouse. O hook guarda somente a posição mais recente e mantém no máximo um lote
pendente na thread gráfica.

- movimentos intermediários obsoletos são descartados;
- o último ponto é descarregado antes de finalizar o gesto;
- callbacks são alinhados à prioridade de renderização;
- limpeza e encerramento invalidam lotes antigos.

### 2. Normalização do AutoReturn em cache

`NormalizeSlotAutoReturnSettings` reconstrói o estado somente quando:

- ocorre inicialização ou migração;
- a quantidade de slots muda;
- objetos de slot são recriados.

Consultas comuns e `SaveSettings` reutilizam o dicionário já preparado. Os
modelos visuais novos recebem diretamente a configuração correta.

### 3. Configurações com debounce e I/O assíncrono

`SettingsService.Save` agora:

- serializa um snapshot consistente;
- consolida chamadas por 400 ms;
- mantém apenas o estado mais recente;
- grava o arquivo fora da thread WPF;
- ignora gravações sem alteração;
- executa `Flush` obrigatório no encerramento.

### 4. Controle de rajadas da extensão

A interface mantém no máximo um trabalho pendente para status comuns e para
snapshots de vídeo.

- diagnósticos repetitivos de content script são filtrados antes do Dispatcher;
- status comuns usam estratégia `latest-wins`;
- sessões de clientes diferentes são unidas por chave antes do merge;
- snapshots vazios continuam sendo observados;
- mensagens funcionais críticas nunca são descartadas, incluindo
  `SilentPreflight`, resultados `Silencioso` e autenticação da extensão.

## Preservado

Não houve mudança intencional em:

- cálculo ou geometria dos layouts;
- comportamento de Travar, Igualar, Ocultar/Mostrar e layout Jogo;
- protocolos e versões da extensão;
- navegação Próximo/Anterior e seus `operationId`;
- gates de preservação, preload e AutoReturn;
- ABI do núcleo nativo.

## Identificação

- Produto: `9.39.03 Fix4 RC3 P0 Optimization RC1`
- Aplicativo: `1.5.12.3905`
- Extensão: `1.4.39.7` sem alteração
- Base: `PiPManager_9.39.03_FIX4_RC3_TELEMETRY_SOURCE`

Esta é uma fonte candidata para compilação e teste no Windows. Não substitui a
RC3 anterior até concluir `BUILD_WINDOWS.bat` e a validação manual descrita em
`LOCAL_VALIDATION_P0_RC1.md`.
