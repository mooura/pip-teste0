﻿using PiPManager.Wpf.Models;

namespace PiPManager.Wpf.Services;

public sealed class LayoutService
{
    private const int Gap = 0;

    // Os alvos do layout são calculados sobre os limites visuais do DWM. Por isso a
    // próxima janela começa exatamente no fim da anterior, sem sobreposição artificial.
    public const int VisualSeamCompensationPx = 0;

    public static int StepSize(int value) => StepSize(value, VisualSeamCompensationPx);

    private static int StepSize(int value, int seamCompensationPx)
        => Math.Max(1, value + Gap - Math.Max(0, seamCompensationPx));

    private static bool HasMixedAspectRatios(IReadOnlyList<NativeRect> rects)
    {
        if (rects.Count < 2) return false;

        var ratios = rects
            .Where(rect => rect.IsValid && rect.Height > 0)
            .Select(rect => rect.Width / (double)rect.Height)
            .ToArray();

        if (ratios.Length < 2) return false;

        var hasPortrait = ratios.Any(ratio => ratio < 0.90);
        var hasLandscape = ratios.Any(ratio => ratio > 1.15);
        var spread = ratios.Max() / Math.Max(0.01, ratios.Min());
        return (hasPortrait && hasLandscape) || spread >= 1.45;
    }

    public NativeRect GetGroupBounds(IEnumerable<PipSlot> slots)
    {
        var rects = slots
            .Where(s => s.Window is not null && !s.IsHidden)
            .Select(s => PipWindowService.GetVisualRect(s.Window!.Handle))
            .Where(r => r.IsValid)
            .ToArray();

        if (rects.Length == 0) return default;
        return new NativeRect(rects.Min(r => r.Left), rects.Min(r => r.Top), rects.Max(r => r.Right), rects.Max(r => r.Bottom));
    }

    public IReadOnlyList<NativeRect> BuildLayoutRects(IReadOnlyList<NativeRect> sourceRects, LayoutMode mode, NativeRect anchor)
        => BuildLayoutRects(sourceRects, mode, anchor, PipWindowService.GetVirtualScreenBounds());

    public IReadOnlyList<NativeRect> BuildLayoutRects(IReadOnlyList<NativeRect> sourceRects, LayoutMode mode, NativeRect anchor, NativeRect workArea)
    {
        var valid = sourceRects.Where(r => r.IsValid).ToArray();
        if (valid.Length == 0 || !anchor.IsValid) return [];

        var raw = mode switch
        {
            LayoutMode.Horizontal => BuildHorizontal(valid, anchor.Left, anchor.Top),
            LayoutMode.Vertical => BuildVertical(valid, anchor.Left, anchor.Top),
            LayoutMode.Jogo => BuildJogo(valid, workArea),
            LayoutMode.Custom => BuildGridTwoColumns(valid, anchor.Left, anchor.Top),
            _ => BuildGridTwoColumns(valid, anchor.Left, anchor.Top)
        };

        // O perfil Jogo já retorna coordenadas visuais encaixadas exatamente na
        // área útil. Aplicar o clamp genérico aqui recolocaria a margem histórica
        // de 8 px e criaria a faixa vazia observada nas bordas do monitor.
        return mode == LayoutMode.Jogo ? raw : ClampGroupToWorkArea(raw, workArea);
    }


    private const double JogoPortraitAspectThreshold = 0.90;
    private const double JogoMinimumContentAspect = 0.20;
    private const double JogoMaximumContentAspect = 6.00;

    private sealed record JogoLayoutItem(
        int Index,
        NativeRect Rect,
        double ContentAspect,
        bool IsPortrait);

    private static double SanitizeJogoContentAspect(double requested, NativeRect fallback)
    {
        if (double.IsFinite(requested)
            && requested >= JogoMinimumContentAspect
            && requested <= JogoMaximumContentAspect)
            return requested;

        if (fallback.IsValid && fallback.Height > 0)
        {
            var fallbackAspect = fallback.Width / (double)fallback.Height;
            if (double.IsFinite(fallbackAspect) && fallbackAspect > 0)
                return Math.Clamp(fallbackAspect, JogoMinimumContentAspect, JogoMaximumContentAspect);
        }

        return 16.0 / 9.0;
    }

    private static bool IsJogoPortrait(double contentAspect)
        => contentAspect < JogoPortraitAspectThreshold;

    private static List<NativeRect> BuildJogo(IReadOnlyList<NativeRect> rects, NativeRect workArea)
    {
        var fallbackAspects = rects
            .Select(rect => SanitizeJogoContentAspect(0, rect))
            .ToArray();
        return BuildJogoContentAware(rects, fallbackAspects, workArea);
    }

    // Autoridade de proporção do perfil Jogo. A geometria DWM é usada somente
    // como tamanho inicial/fallback; horizontal, vertical e altura final vêm da
    // proporção intrínseca do stream enviada pela extensão.
    public IReadOnlyList<NativeRect> BuildJogoContentAwareRects(
        IReadOnlyList<NativeRect> sourceRects,
        IReadOnlyList<double> contentAspectRatios,
        NativeRect workArea,
        IReadOnlyList<int>? manualVisualOrder = null,
        int? manualTopCount = null,
        double jogoLayoutScale = 1.0,
        double jogoTopWidthRatio = 0.0,
        double jogoSideWidthRatio = 0.0)
    {
        if (sourceRects.Count == 0) return [];
        if (contentAspectRatios.Count != sourceRects.Count)
            throw new ArgumentException("Uma proporção de conteúdo é necessária para cada PiP.", nameof(contentAspectRatios));

        return BuildJogoContentAware(
            sourceRects,
            contentAspectRatios,
            workArea,
            manualVisualOrder,
            manualTopCount,
            jogoLayoutScale,
            jogoTopWidthRatio,
            jogoSideWidthRatio);
    }

    private static List<NativeRect> BuildJogoContentAware(
        IReadOnlyList<NativeRect> rects,
        IReadOnlyList<double> contentAspectRatios,
        NativeRect workArea,
        IReadOnlyList<int>? manualVisualOrder = null,
        int? manualTopCount = null,
        double jogoLayoutScale = 1.0,
        double jogoTopWidthRatio = 0.0,
        double jogoSideWidthRatio = 0.0)
    {
        if (rects.Count == 0) return [];

        var screen = workArea.IsValid ? workArea : PipWindowService.GetVirtualScreenBounds();
        const int topRowCapacity = 6;

        // A identidade do slot continua intacta. A ordenação existe apenas para
        // a posição visual: conteúdo vertical vai para o trilho direito; uma
        // janela que ficou vertical apenas por resize não altera a classificação.
        var indexed = rects
            .Select((rect, index) =>
            {
                var contentAspect = SanitizeJogoContentAspect(contentAspectRatios[index], rect);
                return new JogoLayoutItem(
                    index,
                    rect,
                    contentAspect,
                    IsJogoPortrait(contentAspect));
            })
            .ToArray();

        var hasValidManualOrder = manualVisualOrder is not null
            && manualVisualOrder.Count == indexed.Length
            && manualVisualOrder.Distinct().Count() == indexed.Length
            && manualVisualOrder.All(index => index >= 0 && index < indexed.Length)
            && manualTopCount is >= 0
            && manualTopCount <= Math.Min(topRowCapacity, indexed.Length);

        JogoLayoutItem[] topRow;
        JogoLayoutItem[] sideRail;
        if (hasValidManualOrder)
        {
            // Depois de uma troca manual no painel, o slot visual passa a ser a
            // autoridade da posição. Isso permite colocar qualquer conteúdo no
            // topo ou na lateral sem perder a proporção intrínseca do vídeo.
            var manual = manualVisualOrder!
                .Select(index => indexed[index])
                .ToArray();
            topRow = manual.Take(manualTopCount!.Value).ToArray();
            sideRail = manual.Skip(manualTopCount.Value).ToArray();
        }
        else
        {
            var landscape = indexed.Where(item => !item.IsPortrait).ToArray();
            var portrait = indexed.Where(item => item.IsPortrait).ToArray();
            topRow = landscape.Take(topRowCapacity).ToArray();

            // A lateral começa pelos horizontais excedentes. Os vídeos realmente
            // verticais ficam nas últimas posições, na parte inferior do trilho.
            sideRail = landscape
                .Skip(topRowCapacity)
                .Concat(portrait)
                .ToArray();
        }

        var output = new NativeRect[rects.Count];
        var manualTopWidth = ResolveJogoManualGroupWidth(screen.Width, jogoTopWidthRatio);
        var manualSideWidth = ResolveJogoManualGroupWidth(screen.Width, jogoSideWidthRatio);

        // Com seis horizontais, a faixa superior ocupa exatamente a largura útil.
        // A altura de cada janela é derivada de sua própria proporção de conteúdo,
        // impedindo letterbox/pillarbox provocado pelo layout.
        var topWidths = new int[topRow.Length];
        if (manualTopWidth > 0 && topRow.Length > 0)
        {
            var maximumPerItem = Math.Max(1, screen.Width / topRow.Length);
            var commonWidth = Math.Clamp(manualTopWidth, 1, maximumPerItem);
            Array.Fill(topWidths, commonWidth);
        }
        else if (topRow.Length == topRowCapacity)
        {
            for (var i = 0; i < topWidths.Length; i++)
            {
                var left = screen.Left + (int)Math.Round(i * screen.Width / (double)topRowCapacity);
                var right = screen.Left + (int)Math.Round((i + 1) * screen.Width / (double)topRowCapacity);
                topWidths[i] = Math.Max(1, right - left);
            }
        }
        else if (topRow.Length > 0)
        {
            var requestedWidth = Math.Max(1, topRow.Sum(item => Math.Max(1, item.Rect.Width)));
            var widthScale = Math.Min(1.0, screen.Width / (double)requestedWidth);
            var cumulative = 0.0;
            var previous = screen.Left;
            for (var i = 0; i < topRow.Length; i++)
            {
                cumulative += Math.Max(1, topRow[i].Rect.Width) * widthScale;
                var right = screen.Left + (int)Math.Round(cumulative);
                right = Math.Min(screen.Right, Math.Max(previous + 1, right));
                topWidths[i] = right - previous;
                previous = right;
            }
        }

        // Em áreas úteis muito baixas, reduz a faixa antes de materializar os
        // retângulos. Em monitores normais seis vídeos horizontais continuam
        // preenchendo 100% da largura; a redução só ocorre para evitar corte.
        if (topRow.Length > 0)
        {
            var maximumAllowedTopHeight = Math.Max(1, screen.Height - sideRail.Length);
            var requestedTopHeight = Enumerable.Range(0, topRow.Length)
                .Max(index => topWidths[index] / topRow[index].ContentAspect);
            if (requestedTopHeight > maximumAllowedTopHeight)
            {
                var topScale = maximumAllowedTopHeight / requestedTopHeight;
                var cumulativeScaledWidth = 0.0;
                var previousScaledRight = screen.Left;
                for (var i = 0; i < topWidths.Length; i++)
                {
                    cumulativeScaledWidth += topWidths[i] * topScale;
                    var scaledRight = screen.Left + (int)Math.Round(cumulativeScaledWidth);
                    scaledRight = Math.Min(screen.Right, Math.Max(previousScaledRight + 1, scaledRight));
                    topWidths[i] = scaledRight - previousScaledRight;
                    previousScaledRight = scaledRight;
                }
            }
        }

        var topRowHeight = 0;
        var topTotalWidth = topWidths.Sum();
        var x = manualTopWidth > 0
            ? Math.Max(screen.Left, screen.Right - topTotalWidth)
            : screen.Left;
        for (var visualIndex = 0; visualIndex < topRow.Length; visualIndex++)
        {
            var item = topRow[visualIndex];
            var width = topWidths[visualIndex];
            var right = visualIndex == topRow.Length - 1
                    && (topRow.Length == topRowCapacity || manualTopWidth > 0)
                ? screen.Right
                : Math.Min(screen.Right, x + width);
            width = Math.Max(1, right - x);
            var height = Math.Max(1, (int)Math.Round(width / item.ContentAspect));
            var bottom = Math.Min(screen.Bottom, screen.Top + height);
            output[item.Index] = new NativeRect(x, screen.Top, right, bottom);
            topRowHeight = Math.Max(topRowHeight, bottom - screen.Top);
            x = right;
        }

        // O trilho usa uma largura comum calculada pela altura disponível. Assim,
        // vários vídeos 9:16 cabem na lateral sem obrigar a faixa superior a
        // encolher e cada janela conserva sua proporção intrínseca.
        if (sideRail.Length > 0)
        {
            var railTop = screen.Top + topRowHeight;
            var availableHeight = Math.Max(sideRail.Length, screen.Bottom - railTop);
            var heightFactor = sideRail.Sum(item => 1.0 / item.ContentAspect);
            var preferredRailWidth = manualSideWidth > 0
                ? Math.Min(screen.Width, manualSideWidth)
                : topRow.Length > 0
                    ? Math.Max(1, topWidths[^1])
                    : Math.Min(screen.Width, Math.Max(1, sideRail.Max(item => item.Rect.Width)));
            var fittingRailWidth = heightFactor > 0
                ? (int)Math.Floor(availableHeight / heightFactor)
                : preferredRailWidth;
            var railWidth = Math.Max(1, Math.Min(preferredRailWidth, fittingRailWidth));
            var railLeft = screen.Right - railWidth;
            var cumulativeHeightFactor = 0.0;

            for (var i = 0; i < sideRail.Length; i++)
            {
                var item = sideRail[i];
                var top = railTop + (int)Math.Round(cumulativeHeightFactor * railWidth);
                cumulativeHeightFactor += 1.0 / item.ContentAspect;
                var bottom = railTop + (int)Math.Round(cumulativeHeightFactor * railWidth);
                if (i == sideRail.Length - 1)
                    bottom = Math.Min(screen.Bottom, bottom);
                bottom = Math.Min(screen.Bottom, Math.Max(top + 1, bottom));
                output[item.Index] = new NativeRect(railLeft, top, screen.Right, bottom);
            }
        }

        return ScaleJogoTargetsToTopRight(output, screen, jogoLayoutScale);
    }

    private static int ResolveJogoManualGroupWidth(int screenWidth, double ratio)
    {
        if (screenWidth <= 0 || !double.IsFinite(ratio) || ratio < 0.04)
            return 0;
        return Math.Clamp((int)Math.Round(screenWidth * Math.Min(1.0, ratio)), 1, screenWidth);
    }

    private static List<NativeRect> ScaleJogoTargetsToTopRight(
        IReadOnlyList<NativeRect> targets,
        NativeRect screen,
        double requestedScale)
    {
        var scale = double.IsFinite(requestedScale)
            ? Math.Clamp(requestedScale, 0.55, 1.0)
            : 1.0;
        if (scale >= 0.9995)
            return targets.ToList();

        // Escala uniforme em torno do canto superior direito. Coordenadas de
        // costura compartilhadas recebem exatamente a mesma transformação, então
        // o L continua conectado e sem brechas, enquanto a proporção de cada PiP
        // permanece intacta.
        int ScaleX(int value) => screen.Right
            - (int)Math.Round((screen.Right - value) * scale);
        int ScaleY(int value) => screen.Top
            + (int)Math.Round((value - screen.Top) * scale);

        var output = new List<NativeRect>(targets.Count);
        foreach (var target in targets)
        {
            if (!target.IsValid)
            {
                output.Add(default);
                continue;
            }

            var left = Math.Clamp(ScaleX(target.Left), screen.Left, screen.Right - 1);
            var right = Math.Clamp(ScaleX(target.Right), left + 1, screen.Right);
            var top = Math.Clamp(ScaleY(target.Top), screen.Top, screen.Bottom - 1);
            var bottom = Math.Clamp(ScaleY(target.Bottom), top + 1, screen.Bottom);
            output.Add(new NativeRect(left, top, right, bottom));
        }

        return output;
    }

    private static List<NativeRect> BuildHorizontal(IReadOnlyList<NativeRect> rects, int left, int top)
    {
        var x = left;
        var output = new List<NativeRect>(rects.Count);
        foreach (var r in rects)
        {
            output.Add(new NativeRect(x, top, x + r.Width, top + r.Height));
            x += StepSize(r.Width);
        }
        return output;
    }

    private static List<NativeRect> BuildVertical(IReadOnlyList<NativeRect> rects, int left, int top)
    {
        var y = top;
        var output = new List<NativeRect>(rects.Count);
        foreach (var r in rects)
        {
            output.Add(new NativeRect(left, y, left + r.Width, y + r.Height));
            y += StepSize(r.Height);
        }
        return output;
    }

    private static List<NativeRect> BuildGridTwoColumns(IReadOnlyList<NativeRect> rects, int left, int top)
    {
        if (rects.Count <= 1) return BuildHorizontal(rects, left, top);

        // Firefox pode alterar automaticamente a proporção de um PiP quando o vídeo muda.
        // Em uma grade tradicional, um PiP vertical aumenta a altura da linha inteira, deixando
        // espaços sob os PiPs horizontais. Se o tamanho solicitado for ajustado pelo navegador,
        // as posições calculadas com o tamanho antigo também podem se sobrepor. Para proporções
        // mistas, cada coluna é empilhada de forma independente usando as dimensões visuais reais.
        if (HasMixedAspectRatios(rects))
            return BuildMixedAspectMasonryTwoColumns(rects, left, top);

        const int columns = 2;
        var rows = (int)Math.Ceiling(rects.Count / 2.0);

        var colWidths = new int[columns];
        var rowHeights = new int[rows];
        for (var i = 0; i < rects.Count; i++)
        {
            var col = i % columns;
            var row = i / columns;
            colWidths[col] = Math.Max(colWidths[col], rects[i].Width);
            rowHeights[row] = Math.Max(rowHeights[row], rects[i].Height);
        }

        var output = new List<NativeRect>(rects.Count);
        for (var i = 0; i < rects.Count; i++)
        {
            var col = i % columns;
            var row = i / columns;
            var x = left + colWidths.Take(col).Select(value => StepSize(value)).Sum();
            var y = top + rowHeights.Take(row).Select(value => StepSize(value)).Sum();
            output.Add(new NativeRect(x, y, x + rects[i].Width, y + rects[i].Height));
        }
        return output;
    }

    private static List<NativeRect> BuildMixedAspectMasonryTwoColumns(IReadOnlyList<NativeRect> rects, int left, int top)
    {
        const int columns = 2;
        var assignedColumns = new int[rects.Count];
        var assignedTops = new int[rects.Count];
        var nextTop = new[] { top, top };
        var colWidths = new int[columns];

        // Mantém a ordem lógica: cada próximo slot é colocado na coluna que termina primeiro.
        // Como a menor altura acumulada nunca retrocede, os slots posteriores não aparecem
        // visualmente acima dos anteriores, mesmo quando um PiP vertical ocupa muito espaço.
        for (var i = 0; i < rects.Count; i++)
        {
            var col = i switch
            {
                0 => 0,
                1 => 1,
                _ => nextTop[0] <= nextTop[1] ? 0 : 1
            };

            assignedColumns[i] = col;
            assignedTops[i] = nextTop[col];
            colWidths[col] = Math.Max(colWidths[col], rects[i].Width);
            nextTop[col] += StepSize(rects[i].Height, seamCompensationPx: 0);
        }

        var centerSeam = left + StepSize(colWidths[0], seamCompensationPx: 0);
        var output = new List<NativeRect>(rects.Count);
        for (var i = 0; i < rects.Count; i++)
        {
            var col = assignedColumns[i];
            var rect = rects[i];
            // A coluna esquerda é alinhada pela borda direita e a coluna direita pela
            // borda esquerda. Assim, larguras diferentes continuam encostando no eixo
            // central, sem criar um corredor vazio entre PiPs estreitos e largos.
            var x = col == 0 ? centerSeam - rect.Width : centerSeam;
            var y = assignedTops[i];
            output.Add(new NativeRect(x, y, x + rect.Width, y + rect.Height));
        }

        return output;
    }

    private static IReadOnlyList<NativeRect> ClampGroupToWorkArea(IReadOnlyList<NativeRect> rects, NativeRect workArea)
    {
        if (rects.Count == 0) return rects;
        var bounds = new NativeRect(rects.Min(r => r.Left), rects.Min(r => r.Top), rects.Max(r => r.Right), rects.Max(r => r.Bottom));
        var screen = workArea.IsValid ? workArea : PipWindowService.GetVirtualScreenBounds();
        var dx = 0;
        var dy = 0;
        if (bounds.Left < screen.Left + 8) dx = screen.Left + 8 - bounds.Left;
        else if (bounds.Right > screen.Right - 8) dx = screen.Right - 8 - bounds.Right;
        if (bounds.Top < screen.Top + 8) dy = screen.Top + 8 - bounds.Top;
        else if (bounds.Bottom > screen.Bottom - 8) dy = screen.Bottom - 8 - bounds.Bottom;
        return rects.Select(r => r.Offset(dx, dy)).ToArray();
    }
}
