# PiP Manager 9.39.01 — Native Layout Engine Phase 1.1

Versão do produto: **9.39.01**  
App WPF: **1.5.12.3901**  
Extensão: **1.4.39.24**  
Núcleo nativo: **PiPManager.Native.dll ABI 100**

## O que mudou

A movimentação e o redimensionamento do grupo de PiPs ganharam um núcleo experimental em C++.
A interface, o AutoReturn e a integração com o navegador continuam em C# e JavaScript.

### Modos do seletor `Nativo`

- **OFF** — usa apenas o motor C# da 9.38.02.
- **Compare** — padrão seguro. O C++ prepara o lote em dry-run e o C# ainda aplica as janelas.
- **Primary** — o C++ movimenta/redimensiona o grupo; se a DLL falhar, o C# assume automaticamente.

## Compilação

Execute `BUILD_WINDOWS.bat`.

A solução completa está em `PiPManager.sln`. O aplicativo WPF e o Core ficam
em `src/`, os testes em `tests/`, o benchmark em `benchmarks/` e os checks em
`tools/checks/`.

O pacote inclui uma DLL nativa x64 pré-compilada e validada. Para recompilar o C++ localmente, instale no Visual Studio 2022 o workload **Desktop development with C++**. O script `BUILD_NATIVE_WINDOWS.bat` detecta o MSBuild automaticamente; sem o workload, utiliza a DLL pré-compilada.

## Teste recomendado

1. Inicie no modo **Compare**.
2. Abra de 4 a 10 PiPs.
3. Alterne entre 2x2, horizontal, vertical e manual.
4. Arraste o grupo e use Igualar.
5. Procure no log por `native-layout-compare` e confirme `parity=True`.
6. Somente depois altere para **Primary**.
7. Em Primary, procure `native-layout-primary` e ausência de `native-layout-primary-fallback`.

## Compatibilidade

A extensão 1.4.39.24 anima a sequência de miniaturas do perfil de controles do player, rejeita anúncios ultrawide curtos e melhora a leitura dos controles por slot.
A base estável anterior permanece disponível como 9.38.02 Playback Fluency.

## Ajuste 9.39.01 — agrupamento em lote

O movimento do grupo pela barra flutuante agora monta um único lote com todos os HWNDs.
No modo Compare, a execução nativa visual é amostrada a cada 250 ms, enquanto o motor C#
continua sendo a autoridade em todos os frames. Isso evita executar comparação C++ uma vez
por PiP a cada evento de movimento.

## Consolidação — molde relativo e recuperação em lote

- O desenho manual é persistido como uma âncora de grupo e offsets relativos por slot.
- `Travar conjunto` preserva a topologia e conclui o arraste com um único lote Win32.
- Os encaixes usam os limites visuais DWM sem sobreposição artificial entre PiPs.
- `Fixar layout` captura o desenho atual sem reposicionar as janelas e mantém uma área
  interna de exclusão para janelas comuns.
- Durante o AutoReturn, cada PiP recuperado ocupa somente o seu slot. O grupo completo
  é reaplicado uma vez, quando todos os slots esperados retornam ou após o timeout.
- Captura, vínculo vídeo-slot, playlist e seleção de alvo do AutoReturn permanecem no
  fluxo existente.

### Ajustes visuais e capacidade dos slots

- A área livre usa a borda visual DWM dos PiPs com margem zero. Janelas comuns ficam
  rentes ao conjunto, sem o afastamento artificial anterior.
- Antes de `Abrir todos`, a aplicação pede snapshots sucessivos até a lista de fontes
  estabilizar ou atingir a capacidade configurada.
- Os dez slots continuam equivalentes. Um PiP exige uma fonte de vídeo válida; fontes
  ausentes não são duplicadas para preencher slots vazios.
- No editor de layout livre, cada cartão mostra formato `Normal` ou `Vertical` de acordo
  com a proporção visual real da janela PiP, sem alterar seus controles por slot.

### Estabilização de proporções e neutralidade de plataforma

- Uma mudança automática para vídeo vertical mantém o slot alterado ancorado e desloca
  somente os vizinhos que realmente passaram a colidir.
- Enquanto a proporção natural estabiliza, o verificador periódico não força novamente
  o tamanho antigo; isso elimina o ciclo que deformava e expandia o conjunto.
- Atualizações automáticas do editor não são registradas como arraste manual.
- A extensão não contém uma lista de domínios ou nomes de plataformas de teste. A
  estratégia é escolhida exclusivamente pelas capacidades observáveis da página.

### Igualar como mosaico único

- `Igualar` usa o último PiP realmente redimensionado pelo usuário; mudanças automáticas
  de proporção não substituem essa referência.
- Horizontal, vertical e grade são reconstruídos com bordas exatas. No layout livre,
  o desenho do usuário é preservado e componentes soltos são unidos pelo menor
  deslocamento possível, formando um único mosaico sem sobreposição.
- O layout fixo cede enquanto o usuário redimensiona um PiP e incorpora o novo tamanho
  ao molde ao final do gesto.
- Durante uma recuperação, slots já estabilizados não recebem novamente a mesma
  geometria, eliminando o piscar causado por reaplicações repetidas.

## PIP FIX5 — extensão integrada e isolamento auxiliar

A extensão oficial do pacote foi atualizada para `1.4.39.13-aux-video-isolation-phase1`. Elementos `<video>` criados pelo preload são marcados como auxiliares e excluídos da descoberta de players, pareamento, comandos, abertura de PiP e eventos terminais. O background também remove sessões pertencentes ao documento anterior do mesmo frame após navegação.


## PIP FIX6 — resolução determinística do próximo alvo

A extensão oficial foi atualizada para `1.4.39.14-next-target-resolver-phase2`. O próximo asset agora é identificado e validado antes de qualquer preview ou preload. Alvos vazios ou iguais ao vídeo atual são rejeitados, e o cache não pode mais escolher arbitrariamente o último asset resolvido. A Phase 1 de isolamento dos vídeos auxiliares permanece ativa.


## PIP FIX7 — state machine e cancelamento forte

A extensão oficial foi atualizada para `1.4.39.24-range-network-cap-hotfix9`. Cada resolução recebe `generation` e `operationId`; operações antigas são abortadas, preview e preload consomem o mesmo alvo e o AutoReturn aguarda a mudança real da playlist por até 8 segundos antes de considerar reabrir o player anterior.

## Hotfix 1 — Next e preview

A extensão `1.4.39.24-range-network-cap-hotfix9` restaura a navegação Próximo por URL autoritativa e por descoberta genérica do cartão Up Next. Falhas transitórias de detecção da playlist usam retries de 300/600/900 ms. No Hotfix 3, a preservação visual do preview anterior foi substituída por limpeza imediata e estado `STALE`, evitando mostrar o vídeo atual como próximo.


## Hotfix 2 — preview autoritativo e readiness
Extensão `1.4.39.24-range-network-cap-hotfix9`: o preview exige identidade explícita igual ao `nextAssetId`; o silent reopen faz uma única rechecagem de 250 ms e segue ao fallback físico quando o player permanece em `HAVE_NOTHING`.


## Hotfix 3 — alvo imutável e preview por geração
Extensão `1.4.39.24-range-network-cap-hotfix9`: congela `CommandTarget` no clique, limpa o preview anterior, bloqueia o fallback para a sessão antiga desde o começo da navegação, publica estado explícito do preview e limita o preload a 10 segundos.

### Hotfix 4 — prioridade do Próximo

A versão `1.4.39.24` dá prioridade à navegação Próximo sobre Abrir todos, reduz a espera de readiness antes do retorno físico e limita temporalmente a atividade de rede do preload.


Hotfix 5: terminal auto-next rejects URL-only identity changes, applies bounded readiness/passive structural watch, and protects operational players from preload src removal.

## Hotfix 7 — preload handoff e geometria universal

A extensão preserva o preload do asset congelado como `CommandTarget` durante a navegação e só o consome quando esse asset vira o vídeo atual. O WPF preserva a última geometria confirmada pelo usuário no nível do slot, inclusive quando o AutoReturn captura o novo HWND por `CapturePreparedPipWindow`.


## Hotfix 8 — Real Buffer Handoff + Trusted Manual Geometry

- Pauses preload demand without removing `src` or calling `load()` after useful buffer is available.
- Persists command handoff metadata across same-tab navigation and defers the next generation until the commanded asset becomes current.
- Separates manual, observed and browser-automatic PiP rectangles.
- Uses a proven manual resize as authority; otherwise uses a bounded safe fallback.
- Clamps layout targets before the native Win32 batch to prevent an oversized visual flash.


## Range Network Cap Hotfix 9 / 1.4.39.24

Extensão `1.4.39.24-range-network-cap-hotfix9`: o preload da mídia completa usa `Range` no background, `AbortController`, teto de 8 MiB/5 s e cache temporário de três entradas por 90 s. Geometria e handoff do Hotfix 8 permanecem inalterados.
