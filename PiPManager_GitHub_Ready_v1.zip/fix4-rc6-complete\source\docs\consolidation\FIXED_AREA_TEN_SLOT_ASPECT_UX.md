# Área fixa rente, capacidade de dez slots e proporção visual

## Evidência da execução

Na execução analisada, `Abrir todos` recebeu oito fontes e registrou
`open-all-start: candidates=8`. Os oito itens terminaram com `open-all-item-pass`; não
houve falha nos slots 9 ou 10. Os dois slots restantes estavam livres por ausência de
uma nona e uma décima fonte detectada.

## Área fixa

A reserva interna agora calcula a área livre sobre os limites visuais DWM sem margem
adicional. O ajuste de uma janela comum compensa a diferença entre o retângulo bruto
Win32 e o retângulo visual, fazendo sua borda terminar exatamente na borda do PiP.

Essa reserva continua sendo administrada pelo PiP Manager. O Windows AppBar só admite
uma faixa retangular encostada numa borda da tela e não representa desenhos livres ou
em L.

## Abrir todos

Antes de montar a fila, a aplicação solicita até cinco snapshots curtos e encerra cedo
quando as fontes estabilizam ou atingem `Slots.Count`. A capacidade deixou de usar um
literal local e passa a acompanhar a coleção real de slots. A aplicação nunca duplica
um vídeo para preencher um slot sem fonte.

## Aparência no layout livre

O editor consulta o retângulo visual vivo de cada HWND. A proporção abaixo de `0.90`
é apresentada como `Vertical`; as demais são apresentadas como `Normal`. Essa dimensão
é apenas a moldura visual do cartão: estado, AutoReturn e demais funções permanecem
iguais em todos os slots.

## Autoridade de tamanho e reflow automático

O navegador é a autoridade exclusiva do tamanho natural de cada PiP. Quando um vídeo
muda de vertical para horizontal, ou no sentido contrário, o Manager confirma a nova
geometria em duas leituras e executa somente movimentos de posição. Colisões são
propagadas a partir do slot alterado e componentes que ficaram separados são novamente
encostados, preservando o desenho livre como um único mosaico.

O modo fixo, a recuperação, a troca de slots, a mudança de monitor e o comando de
travar o grupo também preservam as dimensões atuais do navegador. O único comando que
redimensiona os PiPs é `Igualar`, acionado explicitamente pelo usuário; ele usa o último
PiP ajustado manualmente (ou o slot selecionado) como referência para todos os demais.
