$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$main = Get-Content (Join-Path $Root 'src\PiPManager.Wpf\MainWindow.xaml.cs') -Raw
$video = Get-Content (Join-Path $Root 'src\PiPManager.Wpf\Services\VideoCommandService.cs') -Raw
$run = Get-Content (Join-Path $Root 'RUN_CORE_TESTS.bat') -Raw
$checks = @(
  @{ Name='minimized browser detected before activation'; Ok=($video -match 'browserWasMinimized.*Win32\.IsIconic') },
  @{ Name='adaptive restore readiness helper exists'; Ok=($video -match 'WaitForBrowserReadyAfterActivationAsync') },
  @{ Name='minimized restore timeout is 650 ms'; Ok=($video -match 'browserWasMinimized \? 650 : 240') },
  @{ Name='foreground requires exact expected HWND'; Ok=($video -match 'GetForegroundWindow\(\) == browserHwnd') },
  @{ Name='readiness requires non-iconic browser'; Ok=($video -match '!Win32\.IsIconic\(browserHwnd\)') },
  @{ Name='readiness requires two stable samples'; Ok=($video -match 'stableSamples >= 2') },
  @{ Name='initial generic focus delay reduced'; Ok=(($main -match 'Task\.Delay\(100\)') -and ($main -match 'SendOpenPictureInPictureShortcutToForegroundAsync')) },
  @{ Name='checker included in core gate'; Ok=($run -match 'CHECK_ADAPTIVE_BROWSER_RESTORE_READINESS.ps1') }
)
$failed=0
foreach($c in $checks){if($c.Ok){Write-Host "$($c.Name): OK"}else{Write-Host "$($c.Name): FAIL";$failed++}}
if($failed -gt 0){throw 'Adaptive browser restore readiness checks failed.'}
Write-Host 'Adaptive browser restore readiness checks OK.'
