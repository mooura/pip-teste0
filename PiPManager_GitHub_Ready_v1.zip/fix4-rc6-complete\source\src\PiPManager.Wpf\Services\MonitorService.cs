﻿using PiPManager.Wpf.Models;

namespace PiPManager.Wpf.Services;

public sealed class MonitorService
{
    public IReadOnlyList<DisplayMonitorInfo> GetMonitors() => Win32.GetDisplayMonitors();

    public DisplayMonitorInfo GetPreferredMonitor(string? deviceName)
    {
        var monitors = GetMonitors();
        if (!string.IsNullOrWhiteSpace(deviceName))
        {
            var exact = monitors.FirstOrDefault(m => string.Equals(m.DeviceName, deviceName, StringComparison.OrdinalIgnoreCase));
            if (exact is not null) return exact;
        }
        return monitors.FirstOrDefault(m => m.IsPrimary) ?? monitors.First();
    }

    public DisplayMonitorInfo GetMonitorForWindow(IntPtr hWnd)
    {
        var monitors = GetMonitors();
        var rect = PipWindowService.GetVisualRect(hWnd);
        if (!rect.IsValid) return monitors.FirstOrDefault(m => m.IsPrimary) ?? monitors.First();
        return monitors.OrderByDescending(m => rect.IntersectionArea(m.Bounds)).First();
    }
}
