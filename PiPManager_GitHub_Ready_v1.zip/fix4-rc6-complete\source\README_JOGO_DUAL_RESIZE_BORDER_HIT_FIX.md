﻿# Correção de detecção da borda no redimensionamento duplo do perfil Jogo

## Problema

O hook global reconhecia somente cliques dentro do retângulo visual do PiP. A borda de redimensionamento do Firefox pode ficar fora desse retângulo por causa da moldura não cliente e da sombra DWM. Nesse caso, o navegador redimensionava a janela, mas o PiPManager não iniciava o candidato de redimensionamento do grupo.

## Correção

- `WindowFromPoint` identifica o HWND real sob o cursor, inclusive na moldura nativa.
- `GetAncestor(..., GA_ROOT)` resolve o HWND raiz do PiP.
- Uma margem limitada de 18 pixels cobre sombras transparentes nas quais `WindowFromPoint` retorna a janela abaixo.
- O log `pip-drag-hit` informa qual estratégia reconheceu o clique: `window-from-point`, `visual-rect` ou `border-margin`.

## Como verificar

1. Selecione o perfil `Jogo`.
2. Posicione o cursor na borda de um PiP até aparecer a seta dupla do Firefox.
3. Arraste e solte.
4. O status deve informar que o tamanho do grupo superior ou lateral foi salvo.
5. No log devem aparecer, nesta ordem aproximada:
   - `pip-drag-hit`
   - `manual-pip-resize-reference-recorded`
   - `jogo-dual-group-resize` com `phase=final`
6. Em `Layout > Jogo livre`, o percentual do grupo ajustado deve mudar, enquanto o outro grupo permanece igual.
