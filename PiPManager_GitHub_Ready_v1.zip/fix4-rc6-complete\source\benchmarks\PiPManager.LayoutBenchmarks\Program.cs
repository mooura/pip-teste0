using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text.Json;
using PiPManager.Wpf.Models;
using PiPManager.Wpf.Services;

if (!OperatingSystem.IsWindows())
    throw new PlatformNotSupportedException("Layout benchmark requires Windows.");

var outputPath = args.Length > 0
    ? Path.GetFullPath(args[0])
    : Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "native-layout-benchmark.json"));
var windowCount = args.Length > 1 && int.TryParse(args[1], out var parsedWindows)
    ? Math.Clamp(parsedWindows, 1, 10)
    : 10;
var iterations = args.Length > 2 && int.TryParse(args[2], out var parsedIterations)
    ? Math.Clamp(parsedIterations, 100, 5000)
    : 1000;

var windows = new List<IntPtr>();
try
{
    for (var index = 0; index < windowCount; index++)
    {
        var handle = NativeMethods.CreateWindowExW(
            0, "STATIC", $"PiPManager benchmark {index}", NativeMethods.WS_OVERLAPPED,
            50 + index * 5, 50 + index * 5, 320, 180,
            IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero);
        if (handle == IntPtr.Zero)
            throw new InvalidOperationException($"Unable to create benchmark window {index}; win32={Marshal.GetLastWin32Error()}");
        windows.Add(handle);
    }

    using var native = new NativeLayoutEngine();
    if (!native.IsAvailable)
        throw new InvalidOperationException($"Native layout engine unavailable: {native.LoadFailure}");

    RunManaged(windows, 25, 100);
    RunNative(native, windows, 25, 100);

    var managedSamples = RunManaged(windows, iterations, 200);
    var nativeSamples = RunNative(native, windows, iterations, 200);
    var managed = Summarize(managedSamples);
    var nativeSummary = Summarize(nativeSamples);
    var ratio = managed.AverageMs <= 0 ? 0 : nativeSummary.AverageMs / managed.AverageMs;

    var result = new
    {
        generatedAt = DateTimeOffset.Now,
        machine = new
        {
            environment = Environment.OSVersion.VersionString,
            framework = RuntimeInformation.FrameworkDescription,
            processorCount = Environment.ProcessorCount,
            architecture = RuntimeInformation.ProcessArchitecture.ToString()
        },
        scenario = new
        {
            windows = windowCount,
            iterations,
            operation = "alternate raw move+resize using one batch"
        },
        managed,
        native = new
        {
            version = native.Version,
            nativeSummary.AverageMs,
            nativeSummary.MedianMs,
            nativeSummary.P95Ms,
            nativeSummary.MinimumMs,
            nativeSummary.MaximumMs
        },
        nativeToManagedRatio = ratio,
        decision = managed.P95Ms < 1.0
            ? "managed-path-sufficient-native-retirement-candidate"
            : "retain-native-until-layout-profiled"
    };

    Directory.CreateDirectory(Path.GetDirectoryName(outputPath)!);
    File.WriteAllText(outputPath, JsonSerializer.Serialize(result, new JsonSerializerOptions { WriteIndented = true }));
    Console.WriteLine($"Managed avg={managed.AverageMs:F4} ms p95={managed.P95Ms:F4} ms");
    Console.WriteLine($"Native  avg={nativeSummary.AverageMs:F4} ms p95={nativeSummary.P95Ms:F4} ms ABI={native.Version}");
    Console.WriteLine($"Native/Managed ratio={ratio:F3}");
    Console.WriteLine($"Result={outputPath}");
}
finally
{
    foreach (var handle in windows)
        NativeMethods.DestroyWindow(handle);
}

static double[] RunManaged(IReadOnlyList<IntPtr> windows, int iterations, int baseCoordinate)
{
    var samples = new double[iterations];
    for (var iteration = 0; iteration < iterations; iteration++)
    {
        var offset = iteration % 2 == 0 ? 0 : 2;
        var stopwatch = Stopwatch.StartNew();
        var defer = NativeMethods.BeginDeferWindowPos(windows.Count);
        if (defer == IntPtr.Zero) throw new InvalidOperationException("BeginDeferWindowPos failed");
        for (var index = 0; index < windows.Count; index++)
        {
            defer = NativeMethods.DeferWindowPos(
                defer, windows[index], IntPtr.Zero,
                baseCoordinate + index * 4 + offset,
                baseCoordinate + index * 4 + offset,
                320 + (index % 2), 180 + (index % 2),
                NativeMethods.SWP_NOACTIVATE | NativeMethods.SWP_NOZORDER);
            if (defer == IntPtr.Zero) throw new InvalidOperationException("DeferWindowPos failed");
        }
        if (!NativeMethods.EndDeferWindowPos(defer)) throw new InvalidOperationException("EndDeferWindowPos failed");
        stopwatch.Stop();
        samples[iteration] = stopwatch.Elapsed.TotalMilliseconds;
    }
    return samples;
}

static double[] RunNative(NativeLayoutEngine engine, IReadOnlyList<IntPtr> windows, int iterations, int baseCoordinate)
{
    var samples = new double[iterations];
    for (var iteration = 0; iteration < iterations; iteration++)
    {
        var offset = iteration % 2 == 0 ? 2 : 0;
        var moves = windows.Select((handle, index) => new NativeLayoutMove(
            handle,
            new NativeRect(
                baseCoordinate + index * 4 + offset,
                baseCoordinate + index * 4 + offset,
                baseCoordinate + index * 4 + offset + 320 + (index % 2),
                baseCoordinate + index * 4 + offset + 180 + (index % 2)))).ToArray();
        var stopwatch = Stopwatch.StartNew();
        var result = engine.ProcessRawBatch(moves, pixelThreshold: 0, resizeToTargets: true, dryRun: false);
        stopwatch.Stop();
        if (!result.Available || !result.Success)
            throw new InvalidOperationException($"Native batch failed: {result.FailureReason}");
        samples[iteration] = stopwatch.Elapsed.TotalMilliseconds;
    }
    return samples;
}

static BenchmarkSummary Summarize(double[] values)
{
    var ordered = values.OrderBy(value => value).ToArray();
    return new BenchmarkSummary(
        AverageMs: values.Average(),
        MedianMs: Percentile(ordered, 0.50),
        P95Ms: Percentile(ordered, 0.95),
        MinimumMs: ordered[0],
        MaximumMs: ordered[^1]);
}

static double Percentile(double[] ordered, double percentile)
{
    var index = (int)Math.Ceiling(percentile * ordered.Length) - 1;
    return ordered[Math.Clamp(index, 0, ordered.Length - 1)];
}

internal sealed record BenchmarkSummary(
    double AverageMs,
    double MedianMs,
    double P95Ms,
    double MinimumMs,
    double MaximumMs);

internal static partial class NativeMethods
{
    internal const uint WS_OVERLAPPED = 0x00000000;
    internal const uint SWP_NOZORDER = 0x0004;
    internal const uint SWP_NOACTIVATE = 0x0010;

    [LibraryImport("user32.dll", EntryPoint = "CreateWindowExW", SetLastError = true, StringMarshalling = StringMarshalling.Utf16)]
    internal static partial IntPtr CreateWindowExW(
        uint exStyle, string className, string windowName, uint style,
        int x, int y, int width, int height,
        IntPtr parent, IntPtr menu, IntPtr instance, IntPtr parameter);

    [LibraryImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    internal static partial bool DestroyWindow(IntPtr window);

    [LibraryImport("user32.dll")]
    internal static partial IntPtr BeginDeferWindowPos(int count);

    [LibraryImport("user32.dll")]
    internal static partial IntPtr DeferWindowPos(
        IntPtr defer, IntPtr window, IntPtr insertAfter,
        int x, int y, int width, int height, uint flags);

    [LibraryImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    internal static partial bool EndDeferWindowPos(IntPtr defer);
}

