# AutoReturn Fresh Snapshot No-Video Gate

Correção isolada sobre a base `PIP_FIX` aprovada.

## Alterações

- O diagnóstico fresco da extensão agora é exposto ao WPF por aba.
- Quando a aba exata responde `no-video`, `rawVideoCount=0` e `sessionCount=0`, o candidato antigo do cache é rejeitado.
- Nessa condição o AutoReturn não adquire o gate físico, não envia `Ctrl+Shift+]` e agenda nova verificação em 900 ms.
- HWND inválido mantido no modelo do slot é removido antes da classificação, preservando o vínculo de vídeo.
- Um retry após estado `Failed` passa explicitamente por `WaitingForReconnect` antes de `Reconnecting`.
- Layout, movimentação e interface não foram modificados. O `background.js` da extensão agora ecoa um `requestId` de correlação; por isso a extensão deve ser recarregada nesta versão.

## Logs esperados

```text
auto-return-fresh-snapshot-no-video-deferred
staleCandidateRejected=True
physicalGateAcquired=False
auto-return-stale-hwnd-cleared
shadow-mode-event: ... ReconnectRetryQueued ... stateChanged=True
```

## Correlação final do snapshot

- Cada solicitação do aplicativo recebe um `requestId` exclusivo.
- O WPF só aceita a resposta cujo `requestId` coincide exatamente com a tentativa atual.
- Ausência de resposta correlacionada em 700 ms é tratada com falha segura: espera de 900 ms, sem atalho físico.
- Uma segunda resposta correlacionada é exigida imediatamente antes de cada `Ctrl+Shift+]`.
- `no-video`, aba ausente, resposta não pronta ou timeout cancelam o envio sem aumentar o backoff físico.

Logs adicionais esperados:

```text
auto-return-fresh-snapshot-correlated-response
auto-return-fresh-snapshot-timeout-deferred
auto-return-pre-shortcut-fresh-snapshot-deferred
auto-return-physical-attempt-deferred-by-correlated-snapshot
```
