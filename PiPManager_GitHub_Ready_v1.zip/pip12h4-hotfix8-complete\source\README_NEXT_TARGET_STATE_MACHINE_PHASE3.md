# Next Target State Machine — Phase 3

Versão da extensão: `1.4.39.17-next-preview-readiness-hotfix2`.

## Objetivo

Eliminar a corrida observada entre o avanço da playlist, a resolução do próximo alvo, o preview e o AutoReturn.

## Estados

- `RESOLVING_TARGET`
- `TARGET_RESOLVED` / `TARGET_NOT_FOUND` / `TARGET_SAME_AS_CURRENT`
- `RESOLVING_MEDIA`
- `MEDIA_READY`
- `PRELOADING`
- `PRELOAD_READY`
- `READY`
- `STALE` / `CANCELLED` / `FAILED`

## Garantias

1. Cada mudança de identidade recebe um `generation` e `operationId`.
2. Respostas de gerações anteriores não podem atualizar preview ou preload.
3. A operação anterior é abortada com `AbortController` quando o alvo muda ou a página navega.
4. Preview e preload consomem o mesmo alvo autoritativo.
5. O AutoReturn não executa `same-video-fallback` enquanto o resolver está ativo ou já observou avanço do índice da playlist.
6. Thumbnail associada ao asset atual é descartada, evitando repetição visual do vídeo corrente.

## Logs principais

- `next-preload-target-resolution-start`
- `next-preload-target-resolved`
- `next-preload-target-media-resolution-start`
- `next-preload-target-media-resolved`
- `next-preload-target-media-resolution-cancelled`
- `auto-return-same-video-fallback-deferred-target-resolution`
