$ErrorActionPreference = "Stop"

$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$app = Get-Content (Join-Path $root "src\PiPManager.Wpf\App.xaml.cs") -Raw
$proj = Get-Content (Join-Path $root "src\PiPManager.Wpf\PiPManager.Wpf.csproj") -Raw
$release = Get-Content (Join-Path $root "src\PiPManager.Wpf\Services\ReleaseInfoService.cs") -Raw
$log = Get-Content (Join-Path $root "src\PiPManager.Wpf\Services\LogMaintenanceService.cs") -Raw
$diag = Get-Content (Join-Path $root "src\PiPManager.Wpf\Services\ShadowDiagnosticsService.cs") -Raw
$appHostText = Get-Content (Join-Path $root "src\PiPManager.Wpf\Services\AppHostService.cs") -Raw

$checks = @{
  "Generic Host package" = $proj.Contains("Microsoft.Extensions.Hosting")
  "App has IHost" = $app.Contains("private IHost? _host")
  "App starts host" = $app.Contains("_host.Start()")
  "DI ServiceProvider exposed" = $app.Contains("public static IServiceProvider Services")
  "ReleaseInfo registered" = $appHostText.Contains("AddSingleton<IReleaseInfoService")
  "LogMaintenance registered" = $appHostText.Contains("AddSingleton<ILogMaintenanceService")
  "ShadowDiagnostics registered" = $appHostText.Contains("AddSingleton<IShadowDiagnosticsService")
  "Product version centralized" = $release.Contains('public const string ProductVersion = "')
  "Extension version centralized" = $release.Contains('public const string ExtensionVersion = "')
  "Compatible extension prefix centralized" = $release.Contains('public const string CompatibleExtensionVersionPrefix = "')
  "Log rotation in service" = $log.Contains("RotateOperationalLogIfNeeded")
  "Shadow redaction service" = $diag.Contains("[url-redacted]")
}

foreach ($key in $checks.Keys) {
  if (!$checks[$key]) {
    throw "Architecture Phase 1 check failed: $key"
  }
}

Write-Host "Architecture Phase 1 checks OK."
