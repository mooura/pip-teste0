﻿namespace PiPManager.Wpf.Models;

public sealed class VideoPlaybackTerminalInfo
{
    public string Reason { get; init; } = string.Empty;
    public string VideoSessionId { get; init; } = string.Empty;
    public string StableVideoKey { get; init; } = string.Empty;
    public int TabId { get; init; }
    public int FrameId { get; init; }
    public int VideoIndex { get; init; }
    public string PageInstanceId { get; init; } = string.Empty;
    public string ElementInstanceId { get; init; } = string.Empty;
    public string Title { get; init; } = string.Empty;
    public string Url { get; init; } = string.Empty;
    public string Domain { get; init; } = string.Empty;
    public double CurrentTime { get; init; }
    public double Duration { get; init; }
    public int ReadyState { get; init; }
    public bool IsPaused { get; init; }
    public bool IsEnded { get; init; }
    public bool HasSource { get; init; }
    public long EventUnixMs { get; init; }

    public string PairKey => !string.IsNullOrWhiteSpace(VideoSessionId)
        ? VideoSessionId
        : StableVideoKey;
}
