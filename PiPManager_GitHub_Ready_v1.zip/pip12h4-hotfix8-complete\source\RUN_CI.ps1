$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location -LiteralPath $root

function Invoke-Checked([string]$label, [scriptblock]$action) {
    Write-Host "== $label ==" -ForegroundColor Cyan
    & $action
    if ($LASTEXITCODE -ne 0) {
        throw "$label failed with exit code $LASTEXITCODE"
    }
}

Invoke-Checked 'Restore WPF application' { dotnet restore '.\src\PiPManager.Wpf\PiPManager.Wpf.csproj' }
Invoke-Checked 'Restore Core tests' { dotnet restore '.\tests\PiPManager.Core.Tests\PiPManager.Core.Tests.csproj' }
Invoke-Checked 'Restore Window Event tests' { dotnet restore '.\tests\PiPManager.WindowEventMonitor.Tests\PiPManager.WindowEventMonitor.Tests.csproj' }
Invoke-Checked 'Run complete regression gate' { cmd.exe /d /c 'RUN_CORE_TESTS.bat --ci' }
Invoke-Checked 'Build WPF Release' { dotnet build '.\src\PiPManager.Wpf\PiPManager.Wpf.csproj' -c Release --no-restore }

Write-Host 'CI gate completed successfully.' -ForegroundColor Green
