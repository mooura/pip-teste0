param(
    [Parameter(Mandatory = $true)]
    [string]$LogPath
)

$ErrorActionPreference = "Stop"
if (-not (Test-Path $LogPath)) { throw "Log file not found: $LogPath" }

$allLines = @(Get-Content $LogPath)
if ($allLines.Count -eq 0) { throw "Log file is empty: $LogPath" }

# Analyze only the most recent application session. Historical sessions can contain
# legitimate assisted captures and AutoReturn reconnections that must not be mixed.
$sessionStart = 0
$sessionMarkerFound = $false
for ($i = $allLines.Count - 1; $i -ge 0; $i--) {
    if ($allLines[$i] -match "pipmanager-startup:") {
        $sessionStart = $i
        $sessionMarkerFound = $true
        break
    }
}
$sessionLines = @($allLines[$sessionStart..($allLines.Count - 1)])

# Select the latest accepted assisted capture that was actually correlated pre-arm.
# The correlation marker is emitted before the accepted line and contains the same HWND.
$targetAcceptedIndex = -1
$targetHwnd = $null
for ($i = $sessionLines.Count - 1; $i -ge 0; $i--) {
    $line = $sessionLines[$i]
    if ($line -notmatch "window-event-reactor-assisted-capture-accepted") { continue }
    if ($line -notmatch "hwnd=(0x[0-9A-Fa-f]+)") { continue }

    $candidateHwnd = $Matches[1].ToUpperInvariant()
    $hasCorrelation = $false
    for ($j = $i - 1; $j -ge 0; $j--) {
        $prior = $sessionLines[$j]
        if ($prior -match "window-event-reactor-assisted-capture-accepted") { break }
        if ($prior -match "window-event-reactor-assisted-pre-arm-correlated" -and
            $prior -match [regex]::Escape($candidateHwnd)) {
            $hasCorrelation = $true
            break
        }
    }

    if ($hasCorrelation) {
        $targetAcceptedIndex = $i
        $targetHwnd = $candidateHwnd
        break
    }
}

$raceObserved = $false
$correlationMarker = $false
$accepted = $targetAcceptedIndex -ge 0
$completed = $false
$duplicate = $false

if ($accepted) {
    # Scope the attempt from its preceding correlation marker through the next
    # assisted acceptance (or session end). Count only completions for this HWND.
    $intervalEnd = $sessionLines.Count - 1
    for ($i = $targetAcceptedIndex + 1; $i -lt $sessionLines.Count; $i++) {
        if ($sessionLines[$i] -match "window-event-reactor-assisted-capture-accepted") {
            $intervalEnd = $i - 1
            break
        }
    }

    $before = if ($targetAcceptedIndex -gt 0) { @($sessionLines[0..($targetAcceptedIndex - 1)]) } else { @() }
    $correlationLines = @($before | Where-Object {
        $_ -match "window-event-reactor-assisted-pre-arm-correlated" -and
        $_ -match [regex]::Escape($targetHwnd)
    })
    $correlationMarker = $correlationLines.Count -gt 0

    $raceLines = @($sessionLines | Where-Object {
        ($_ -match "preArmCorrelated=True" -or $_ -match "preArmCorrelated=true") -and
        $_ -match [regex]::Escape($targetHwnd)
    })
    $raceObserved = $raceLines.Count -gt 0

    $attemptLines = @($sessionLines[$targetAcceptedIndex..$intervalEnd])
    $completionLines = @($attemptLines | Where-Object {
        $_ -match "PiP preparado capturado e vinculado" -and
        $_ -match ("handle=" + [regex]::Escape($targetHwnd))
    })
    $completed = $completionLines.Count -ge 1
    $duplicate = $completionLines.Count -gt 1
}

$checks = [ordered]@{
    "Most recent session isolated" = $sessionMarkerFound
    "Pre-arm race observed" = $raceObserved
    "Pre-arm correlation marker" = $correlationMarker
    "Assisted capture accepted" = $accepted
    "Prepared capture completed for accepted HWND" = $completed
    "No duplicate completion for accepted HWND in attempt interval" = -not $duplicate
}

Write-Host ("SessionStartLine: " + ($sessionStart + 1))
if ($targetHwnd) { Write-Host ("ValidatedHwnd: " + $targetHwnd) }

$failed = 0
foreach ($item in $checks.GetEnumerator()) {
    $status = if ($item.Value) { "OK" } else { "FAIL"; $failed++ }
    Write-Host ($item.Key + ": " + $status)
}

if ($failed -gt 0) { throw "Dedicated assisted-capture race log validation failed." }
Write-Host "Dedicated assisted-capture race log validation OK."
