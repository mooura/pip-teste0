'use strict';

const fs = require('fs');
const path = require('path');
const vm = require('vm');

function assert(condition, message) {
  if (!condition) throw new Error(`TEST FAILED: ${message}`);
}

const extensionRoot = path.join(__dirname, '..', '..', 'src', 'PiPManager.Extension');
const content = fs.readFileSync(path.join(extensionRoot, 'content.js'), 'utf8');
const background = fs.readFileSync(path.join(extensionRoot, 'background.js'), 'utf8');

assert(content.includes("CONTENT_VERSION = '1.4.39.25-command-target-root-guard-hotfix10'"), 'content phase identifier must be present');
assert(background.includes("BRIDGE_VERSION = '1.4.39.25-command-target-root-guard-hotfix10'"), 'background phase identifier must be present');
assert(content.includes("video.dataset.pipManagerAuxiliary = '1'"), 'auxiliary marker must be applied');
assert(content.includes("video.dataset.pipManagerPreload = '1'") || content.includes("type: 'pipManagerStartRangePreload'"), 'legacy native preload must be marked or replaced by isolated range transport');
assert(content.includes('video.disablePictureInPicture = true'), 'auxiliary videos must disable PiP');
assert(content.includes(".filter(video => !isPipManagerAuxiliaryVideo(video))"), 'operational discovery must exclude auxiliaries');
assert(content.includes('auxiliaryVideoCount'), 'auxiliary count telemetry must exist');
assert(content.includes('domVideoCount'), 'DOM video count telemetry must exist');
assert(background.includes('differentDocument'), 'background must identify stale document sessions');
assert(background.includes('sameTab && sameFrame && differentDocument'), 'stale-session purge must be scoped to tab and frame');

// Execute the production marker/filter helpers with a tiny DOM-compatible fake.
const start = content.indexOf("const PIP_MANAGER_AUXILIARY_VIDEO_ATTRIBUTE");
const end = content.indexOf('const PAGE_INSTANCE_ID', start);
assert(start >= 0 && end > start, 'auxiliary helper source region must be found');

class FakeVideo {
  constructor() {
    this.dataset = {};
    this.attrs = new Map();
    this.disablePictureInPicture = false;
  }
  setAttribute(name, value) { this.attrs.set(name, String(value)); }
  getAttribute(name) { return this.attrs.has(name) ? this.attrs.get(name) : null; }
}

const realVideo = new FakeVideo();
const preloadVideo = new FakeVideo();
const document = {
  querySelectorAll(selector) {
    assert(selector === 'video', 'production helper should query video elements');
    return [realVideo, preloadVideo];
  }
};
const context = vm.createContext({ HTMLVideoElement: FakeVideo, document, Array, String });
vm.runInContext(`${content.slice(start, end)}\nthis.helpers = { markPipManagerAuxiliaryVideo, isPipManagerAuxiliaryVideo, getOperationalVideoElements };`, context);
context.helpers.markPipManagerAuxiliaryVideo(preloadVideo, 'preload');
preloadVideo.dataset.pipManagerPreload = '1';

assert(context.helpers.isPipManagerAuxiliaryVideo(preloadVideo), 'marked preload must be auxiliary');
assert(!context.helpers.isPipManagerAuxiliaryVideo(realVideo), 'unmarked player must remain operational');
const operational = context.helpers.getOperationalVideoElements();
assert(operational.length === 1 && operational[0] === realVideo, 'operational discovery must retain only the real player');
assert(preloadVideo.disablePictureInPicture === true, 'marked preload must have PiP disabled');

console.log('Auxiliary video isolation tests: OK');
