﻿param()

$ErrorActionPreference = 'Stop'
$root = Resolve-Path (Join-Path $PSScriptRoot '..\..')
$main = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\MainWindow.xaml.cs') -Raw
$drag = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\MainWindow.PipDrag.cs') -Raw
$monitor = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\Services\WindowsEventMonitorService.cs') -Raw
$release = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\Services\ReleaseInfoService.cs') -Raw

$checks = [ordered]@{
  'drag model filters unusable HWNDs' = $drag.Contains('GetUsableOccupiedSlotsForDrag()') -and $drag.Contains('PipWindowService.IsUsable(slot.Window.Handle)')
  'lost AutoReturn slots are aggregated' = $drag.Contains('referências perdidas preservadas fora do modelo de arraste') -and $drag.Contains('pairMetadataPreserved=True')
  'drag purge exposes debounce reservation before preserving identity' = $drag.Contains('var lossDebounceReserved =') -and $drag.Contains('AutoReturnBurstPolicy.ShouldPreserveLostSlot')
  'health totals use 250ms coalescing' = $monitor.Contains('HealthTotalsPublishThrottleMs = 250') -and $monitor.Contains('PublishHealthTotals()')
  'intentional visibility transition is armed by HWND' = $main.Contains('_intentionalVisibilityTransitionUntilByHwnd') -and $main.Contains('IntentionalVisibilityTransitionSuppressMs = 1500') -and $main.Contains('ArmIntentionalVisibilityTransition(')
  'shown and hidden events skip automation during app transition' = $main.Contains('WindowMonitorEventKind.Shown or WindowMonitorEventKind.Hidden') -and $main.Contains('window-event-assisted-intentional-visibility-suppressed') -and $main.Contains('skip-refresh-and-autoreturn')
  'destroyed events remain unsuppressed' = -not $main.Contains('WindowMonitorEventKind.Destroyed or WindowMonitorEventKind.Shown or WindowMonitorEventKind.Hidden')
  'already-owned HWND is rejected before pre-arm wait' = $main.IndexOf('reason=already-owned-slot') -ge 0 -and $main.IndexOf('reason=already-owned-slot') -lt $main.IndexOf('window-event-reactor-assisted-pre-arm-wait')
  'hide and show both arm suppression' = $main.Contains('"hide"') -and $main.Contains('"show"') -and $main.Contains('slotsToRestore.Select(slot => slot.Window!.Handle)')
  'release retains RC5 in current app version' = $release.Contains('AppVersion = "1.5.12.3909"') -and $release.Contains('P0 Optimization RC5') -and $release.Contains('P0 Optimization RC6')
}

$failed = 0
foreach ($item in $checks.GetEnumerator()) {
  if ($item.Value) { Write-Host ($item.Key + ': OK') }
  else { Write-Host ($item.Key + ': FAIL'); $failed++ }
}

if ($failed -gt 0) { throw 'P0 Optimization RC5 checks failed.' }
Write-Host 'P0 Optimization RC5 checks OK.'
