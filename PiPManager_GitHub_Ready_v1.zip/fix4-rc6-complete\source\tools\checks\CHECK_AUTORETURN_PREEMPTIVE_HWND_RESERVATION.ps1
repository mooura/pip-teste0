$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$main = Get-Content (Join-Path $Root 'src\PiPManager.Wpf\MainWindow.xaml.cs') -Raw
$run = Get-Content (Join-Path $Root 'RUN_CORE_TESTS.bat') -Raw
$checks = @(
  @{ Name='expected browser process validation'; Ok=($main -match 'expectedProcess' -and $main -match 'Path.GetFileNameWithoutExtension') },
  @{ Name='Created or Shown preclaims HWND'; Ok=($main -match 'auto-return-hwnd-preclaimed') },
  @{ Name='generic reconnect blocked for non-active slot'; Ok=($main -match 'smart-reconnect-candidate-blocked-by-active-attempt') },
  @{ Name='candidate claims are attempt-aware'; Ok=($main -match '_autoReturnCandidateAttemptByHwnd.TryGetValue') },
  @{ Name='fast foreground lease'; Ok=($main -match 'const int foregroundLeaseMs = 350') },
  @{ Name='fast post-focus wait'; Ok=($main -match 'var\s+postRestoreWaitMs\s*=\s*navigationFastLease\s*\?\s*450\s*:\s*600') },
  @{ Name='checker included in core gate'; Ok=($run -match 'CHECK_AUTORETURN_PREEMPTIVE_HWND_RESERVATION.ps1') }
)
$failed=0
foreach($c in $checks){ if($c.Ok){Write-Host "$($c.Name): OK"} else {Write-Host "$($c.Name): FAIL"; $failed++}}
if($failed -gt 0){throw 'AutoReturn preemptive HWND reservation checks failed.'}
Write-Host 'AutoReturn preemptive HWND reservation checks OK.'
