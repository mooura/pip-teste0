namespace PiPManager.Wpf.Models;

internal sealed class AutoReturnSlotState
{
    public int SlotNumber { get; init; }
    public int TabId { get; init; }
    public string OldSession { get; init; } = string.Empty;
    public string OldStable { get; init; } = string.Empty;
    public string OldUrl { get; init; } = string.Empty;
    public string ExpectedBrowserProcess { get; init; } = string.Empty;
    public DateTime PendingSinceUtc { get; init; } = DateTime.UtcNow;
    public int MaxPendingAgeSeconds { get; init; }
    public DateTime CooldownUntilUtc { get; set; } = DateTime.MinValue;
    public bool InProgress { get; set; }
    public int SilentAttempts { get; set; }
    public int FocuslessAttempts { get; set; }
    public int RetryBackoffAttempt { get; set; }
    public int ReadinessDeferrals { get; set; }
    public bool PhysicalAttemptDeferredForFreshSnapshot { get; set; }
    public string Reason { get; set; } = string.Empty;
    public bool RequiresRealVideoChange { get; init; }
    public string EligibilityMode { get; init; } = "same-video-reopen";
    public string CandidateKey { get; set; } = string.Empty;
    public DateTime CandidateFirstSeenUtc { get; set; } = DateTime.MinValue;
    public int CancellationGeneration { get; init; }
    public bool BlockSameVideoFallback { get; init; }
    public string CommandTargetAssetId { get; init; } = string.Empty;
    public string CommandTargetOperationId { get; init; } = string.Empty;
    public int CommandTargetGeneration { get; init; }
    public int CommandTargetNextIndex { get; init; } = -1;
    public string NavigationReason { get; init; } = string.Empty;
    public int TerminalNavigationGeneration { get; init; }
    public DateTime TerminalNavigationPendingSinceUtc { get; set; } = DateTime.MinValue;
    public string TerminalNavigationPendingSignature { get; set; } = string.Empty;
    public bool TerminalTargetUnavailableLogged { get; set; }
    public bool TerminalPassiveWatch { get; set; }
}
