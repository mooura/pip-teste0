# Hotfix 6 — Reconnect Geometry Gate Alignment

The former gate required position-only restore with `resize=False`. Hotfix 6 intentionally changes reconnect behavior to restore the complete pre-loss rectangle and maintain a temporary geometry authority, because Firefox can expand a replacement PiP several seconds after creation.
