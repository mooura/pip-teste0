﻿$ErrorActionPreference = 'Stop'

$root = Resolve-Path (Join-Path $PSScriptRoot '..\..')
$layoutModePath = Join-Path $root 'src\PiPManager.Wpf\Models\LayoutMode.cs'
$videoModelPath = Join-Path $root 'src\PiPManager.Wpf\Models\VideoTabInfo.cs'
$layoutServicePath = Join-Path $root 'src\PiPManager.Wpf\Services\LayoutService.cs'
$bridgePath = Join-Path $root 'src\PiPManager.Wpf\Services\ExtensionBridgeService.cs'
$layoutPartialPath = Join-Path $root 'src\PiPManager.Wpf\MainWindow.Layout.cs'
$mainPath = Join-Path $root 'src\PiPManager.Wpf\MainWindow.xaml.cs'
$contentPath = Join-Path $root 'src\PiPManager.Extension\content.js'
$backgroundPath = Join-Path $root 'src\PiPManager.Extension\background.js'
$xamlPath = Join-Path $root 'src\PiPManager.Wpf\MainWindow.xaml'

$layoutMode = Get-Content -LiteralPath $layoutModePath -Raw
$videoModel = Get-Content -LiteralPath $videoModelPath -Raw
$layoutService = Get-Content -LiteralPath $layoutServicePath -Raw
$bridge = Get-Content -LiteralPath $bridgePath -Raw
$layoutPartial = Get-Content -LiteralPath $layoutPartialPath -Raw
$main = Get-Content -LiteralPath $mainPath -Raw
$content = Get-Content -LiteralPath $contentPath -Raw
$background = Get-Content -LiteralPath $backgroundPath -Raw
$xaml = Get-Content -LiteralPath $xamlPath -Raw

$required = @(
    @{ Name = 'enum compatibility'; Text = $layoutMode; Pattern = 'Custom = 3' },
    @{ Name = 'Jogo enum'; Text = $layoutMode; Pattern = 'Jogo = 4' },
    @{ Name = 'Jogo menu'; Text = $xaml; Pattern = 'Header="Jogo" Tag="Jogo"' },
    @{ Name = 'ten-slot selection'; Text = $main; Pattern = 'mode == LayoutMode.Jogo && Slots.Count != 10' },
    @{ Name = 'intrinsic width emitted'; Text = $content; Pattern = 'intrinsicVideoWidth: Math.round(Number(video.videoWidth || 0))' },
    @{ Name = 'intrinsic height emitted'; Text = $content; Pattern = 'intrinsicVideoHeight: Math.round(Number(video.videoHeight || 0))' },
    @{ Name = 'rendered dimensions remain diagnostic'; Text = $content; Pattern = 'videoWidth: Math.round(rect.width || video.videoWidth || 0)' },
    @{ Name = 'intrinsic dimensions enter snapshot signature'; Text = $background; Pattern = 'intrinsicVideoWidth: Number(session.intrinsicVideoWidth || 0)' },
    @{ Name = 'managed intrinsic width'; Text = $videoModel; Pattern = 'IntrinsicVideoWidth' },
    @{ Name = 'managed intrinsic height'; Text = $videoModel; Pattern = 'IntrinsicVideoHeight' },
    @{ Name = 'managed intrinsic ratio'; Text = $videoModel; Pattern = 'IntrinsicAspectRatio' },
    @{ Name = 'bridge reads intrinsic width'; Text = $bridge; Pattern = 'IntrinsicVideoWidth = GetInt(item, "intrinsicVideoWidth")' },
    @{ Name = 'bridge reads intrinsic height'; Text = $bridge; Pattern = 'IntrinsicVideoHeight = GetInt(item, "intrinsicVideoHeight")' },
    @{ Name = 'content-aware public layout'; Text = $layoutService; Pattern = 'BuildJogoContentAwareRects' },
    @{ Name = 'content aspect stored in layout item'; Text = $layoutService; Pattern = 'contentAspect,' },
    @{ Name = 'portrait uses content aspect'; Text = $layoutService; Pattern = 'IsJogoPortrait(contentAspect));' },
    @{ Name = 'height derives from content aspect'; Text = $layoutService; Pattern = 'width / item.ContentAspect' },
    @{ Name = 'rail fit derives from content aspect'; Text = $layoutService; Pattern = '1.0 / item.ContentAspect' },
    @{ Name = 'right-edge rail'; Text = $layoutService; Pattern = 'var railLeft = screen.Right - railWidth' },
    @{ Name = 'portrait is last in automatic side rail'; Text = $layoutService; Pattern = '.Concat(portrait)' },
    @{ Name = 'manual visual order supported'; Text = $layoutService; Pattern = 'manualVisualOrder' },
    @{ Name = 'manual top split supported'; Text = $layoutService; Pattern = 'manualTopCount' },
    @{ Name = 'slot identity retained'; Text = $layoutService; Pattern = 'output[item.Index]' },
    @{ Name = 'slot aspect cache'; Text = $layoutPartial; Pattern = '_slotIntrinsicContentAspectRatios' },
    @{ Name = 'slot resolves paired video'; Text = $layoutPartial; Pattern = 'ResolvePairedVideoTabForAspect' },
    @{ Name = 'Jogo uses intrinsic content layout'; Text = $layoutPartial; Pattern = 'BuildJogoContentAwareRects' },
    @{ Name = 'snapshot aspect change queues reflow'; Text = $main; Pattern = 'QueueJogoIntrinsicAspectReflowIfNeeded("extension/intrinsic-video-aspect-update")' },
    @{ Name = 'aspect cache follows slot swap'; Text = $main; Pattern = 'SwapDictionaryValues(_slotIntrinsicContentAspectRatios' },
    @{ Name = 'Jogo slot drag enables manual placement'; Text = $main; Pattern = 'EnableJogoManualPlacementFromCurrentTopology' },
    @{ Name = 'Jogo slot drag reapplies profile'; Text = $main; Pattern = 'slot-drag-swap/jogo-manual-placement' },
    @{ Name = 'aspect cache clears with slot'; Text = $main; Pattern = '_slotIntrinsicContentAspectRatios.Remove(slotNumber)' },
    @{ Name = 'intrinsic diagnostic'; Text = $layoutPartial; Pattern = 'aspectAuthority=intrinsic-video' }
)

$failures = @()
foreach ($item in $required) {
    if (-not $item.Text.Contains($item.Pattern)) {
        $failures += $item.Name
    }
}

if ($layoutService.Contains('IsJogoPortrait(rect)')) {
    $failures += 'window rectangle still classifies Jogo portrait content'
}

function New-Rect([double]$Left, [double]$Top, [double]$Width, [double]$Height) {
    [pscustomobject]@{
        Left = $Left
        Top = $Top
        Right = $Left + $Width
        Bottom = $Top + $Height
        Width = $Width
        Height = $Height
    }
}

function Build-JogoIntrinsic(
    [object[]]$Items,
    [double]$WorkWidth = 1920,
    [double]$WorkHeight = 1032,
    [int[]]$ManualVisualOrder = $null,
    [int]$ManualTopCount = -1) {
    $indexed = @()
    for ($i = 0; $i -lt $Items.Count; $i++) {
        $aspect = [double]$Items[$i].ContentAspect
        if ($aspect -lt 0.20 -or $aspect -gt 6.00) {
            $aspect = [double]$Items[$i].WindowWidth / [Math]::Max(1.0, [double]$Items[$i].WindowHeight)
        }
        $indexed += [pscustomobject]@{
            Index = $i
            WindowWidth = [double]$Items[$i].WindowWidth
            WindowHeight = [double]$Items[$i].WindowHeight
            ContentAspect = $aspect
            IsPortrait = $aspect -lt 0.90
        }
    }

    $manualValid = $null -ne $ManualVisualOrder -and
        $ManualVisualOrder.Count -eq $indexed.Count -and
        @($ManualVisualOrder | Sort-Object -Unique).Count -eq $indexed.Count -and
        $ManualTopCount -ge 0 -and
        $ManualTopCount -le [Math]::Min(6, $indexed.Count)

    if ($manualValid) {
        $manual = @($ManualVisualOrder | ForEach-Object { $indexed[$_] })
        $topRow = @($manual | Select-Object -First $ManualTopCount)
        $sideRail = @($manual | Select-Object -Skip $ManualTopCount)
    } else {
        $landscape = @($indexed | Where-Object { -not $_.IsPortrait })
        $portrait = @($indexed | Where-Object { $_.IsPortrait })
        $topRow = @($landscape | Select-Object -First 6)
        $overflow = @($landscape | Select-Object -Skip 6)
        $sideRail = @($overflow) + @($portrait)
    }
    $output = @($null) * $Items.Count

    $topWidths = @()
    if ($topRow.Count -eq 6) {
        for ($i = 0; $i -lt 6; $i++) {
            $left = [Math]::Round($i * $WorkWidth / 6.0)
            $right = [Math]::Round(($i + 1) * $WorkWidth / 6.0)
            $topWidths += ($right - $left)
        }
    } elseif ($topRow.Count -gt 0) {
        $requestedWidth = 0.0
        foreach ($item in $topRow) { $requestedWidth += [Math]::Max(1.0, $item.WindowWidth) }
        $widthScale = [Math]::Min(1.0, $WorkWidth / [Math]::Max(1.0, $requestedWidth))
        $cumulative = 0.0
        $previous = 0.0
        foreach ($item in $topRow) {
            $cumulative += [Math]::Max(1.0, $item.WindowWidth) * $widthScale
            $right = [Math]::Round($cumulative)
            $topWidths += [Math]::Max(1.0, $right - $previous)
            $previous = $right
        }
    }

    $topRowHeight = 0.0
    $x = 0.0
    for ($i = 0; $i -lt $topRow.Count; $i++) {
        $item = $topRow[$i]
        $width = [double]$topWidths[$i]
        $right = $x + $width
        if ($i -eq ($topRow.Count - 1) -and $topRow.Count -eq 6) { $right = $WorkWidth }
        $width = $right - $x
        $height = [Math]::Max(1.0, [Math]::Round($width / $item.ContentAspect))
        $output[$item.Index] = New-Rect $x 0 $width $height
        $topRowHeight = [Math]::Max($topRowHeight, $height)
        $x = $right
    }

    if ($sideRail.Count -gt 0) {
        $railTop = $topRowHeight
        $availableHeight = [Math]::Max($sideRail.Count, $WorkHeight - $railTop)
        $heightFactor = 0.0
        foreach ($item in $sideRail) { $heightFactor += 1.0 / $item.ContentAspect }
        if ($topRow.Count -gt 0) {
            $preferredRailWidth = [Math]::Max(1.0, [double]$topWidths[$topWidths.Count - 1])
        } else {
            $preferredRailWidth = 1.0
            foreach ($item in $sideRail) { $preferredRailWidth = [Math]::Max($preferredRailWidth, $item.WindowWidth) }
            $preferredRailWidth = [Math]::Min($WorkWidth, $preferredRailWidth)
        }
        $fittingRailWidth = [Math]::Floor($availableHeight / [Math]::Max(0.0001, $heightFactor))
        $railWidth = [Math]::Max(1.0, [Math]::Min($preferredRailWidth, $fittingRailWidth))
        $railLeft = $WorkWidth - $railWidth
        $cumulativeFactor = 0.0
        for ($i = 0; $i -lt $sideRail.Count; $i++) {
            $item = $sideRail[$i]
            $top = $railTop + [Math]::Round($cumulativeFactor * $railWidth)
            $cumulativeFactor += 1.0 / $item.ContentAspect
            $bottom = $railTop + [Math]::Round($cumulativeFactor * $railWidth)
            $bottom = [Math]::Min($WorkHeight, [Math]::Max($top + 1.0, $bottom))
            $output[$item.Index] = New-Rect $railLeft $top $railWidth ($bottom - $top)
        }
    }

    return $output
}

function Check-NoOverlap([object[]]$Rects, [string]$Scenario) {
    for ($i = 0; $i -lt $Rects.Count; $i++) {
        for ($j = $i + 1; $j -lt $Rects.Count; $j++) {
            $a = $Rects[$i]
            $b = $Rects[$j]
            $overlap = $a.Left -lt $b.Right -and $a.Right -gt $b.Left -and $a.Top -lt $b.Bottom -and $a.Bottom -gt $b.Top
            if ($overlap) { $script:failures += "$Scenario overlap slots $($i + 1)/$($j + 1)" }
        }
    }
}

function Check-Aspect([object]$Rect, [double]$Expected, [string]$Scenario, [double]$Tolerance = 0.025) {
    $actual = $Rect.Width / [Math]::Max(1.0, $Rect.Height)
    if ([Math]::Abs($actual - $Expected) -gt $Tolerance) {
        $script:failures += "$Scenario aspect expected=$Expected actual=$actual"
    }
}

# Regression principal: as janelas chegam deformadas em 320x115, mas o conteúdo
# continua 16:9. O alvo deve voltar a 320x180, não conservar 2.783:1.
$distorted = 1..10 | ForEach-Object {
    [pscustomobject]@{ WindowWidth = 320; WindowHeight = 115; ContentAspect = (16.0 / 9.0) }
}
$fixed = @(Build-JogoIntrinsic $distorted)
if ($fixed.Count -ne 10 -or $fixed[0].Left -ne 0 -or $fixed[5].Right -ne 1920 -or $fixed[0].Height -ne 180) {
    $failures += 'black-border regression geometry'
}
for ($i = 0; $i -lt $fixed.Count; $i++) { Check-Aspect $fixed[$i] (16.0 / 9.0) "distorted-slot-$($i + 1)" }
Check-NoOverlap $fixed 'distorted-window'

# Uma janela fisicamente vertical não deve migrar se o stream real é horizontal.
$windowPortraitContentLandscape = 1..9 | ForEach-Object {
    [pscustomobject]@{ WindowWidth = 300; WindowHeight = 170; ContentAspect = (16.0 / 9.0) }
}
$windowPortraitContentLandscape[2] = [pscustomobject]@{ WindowWidth = 140; WindowHeight = 330; ContentAspect = (16.0 / 9.0) }
$stillLandscape = @(Build-JogoIntrinsic $windowPortraitContentLandscape)
if ($stillLandscape[2].Top -ne 0 -or $stillLandscape[6].Top -le 0) {
    $failures += 'window geometry incorrectly overrides horizontal content'
}
Check-Aspect $stillLandscape[2] (16.0 / 9.0) 'window-portrait-content-landscape'
Check-NoOverlap $stillLandscape 'window-portrait-content-landscape'

# Um stream 9:16 deve ir para a lateral mesmo se a janela anterior ainda era horizontal.
$contentPortraitWindowLandscape = 1..9 | ForEach-Object {
    [pscustomobject]@{ WindowWidth = 300; WindowHeight = 170; ContentAspect = (16.0 / 9.0) }
}
$contentPortraitWindowLandscape[2] = [pscustomobject]@{ WindowWidth = 300; WindowHeight = 170; ContentAspect = (9.0 / 16.0) }
$portrait = @(Build-JogoIntrinsic $contentPortraitWindowLandscape)
if ($portrait[2].Right -ne 1920 -or $portrait[2].Top -le 0 -or $portrait[6].Top -ne 0) {
    $failures += 'intrinsic portrait automatic side swap'
}
Check-Aspect $portrait[2] (9.0 / 16.0) 'intrinsic-portrait'
Check-NoOverlap $portrait 'intrinsic-portrait'

# Na ordem automática, horizontais excedentes ocupam a parte superior da lateral
# e os vídeos verticais ficam nas posições inferiores.
$portraitBottomItems = 1..8 | ForEach-Object {
    [pscustomobject]@{ WindowWidth = 320; WindowHeight = 180; ContentAspect = (16.0 / 9.0) }
}
$portraitBottomItems[1].ContentAspect = 9.0 / 16.0
$portraitBottomResult = @(Build-JogoIntrinsic $portraitBottomItems)
if ($portraitBottomResult[7].Top -ge $portraitBottomResult[1].Top) {
    $failures += 'portrait is not below landscape overflow in side rail'
}

# Uma ordem manual pode colocar conteúdo vertical no topo e conteúdo horizontal
# na lateral. A classificação intrínseca continua controlando apenas o tamanho.
$manualItems = 1..10 | ForEach-Object {
    [pscustomobject]@{ WindowWidth = 320; WindowHeight = 180; ContentAspect = (16.0 / 9.0) }
}
$manualItems[0].ContentAspect = 9.0 / 16.0
$manualOrder = 0..9
$manualResult = @(Build-JogoIntrinsic $manualItems 1920 1032 $manualOrder 6)
if ($manualResult[0].Top -ne 0 -or $manualResult[6].Top -le 0) {
    $failures += 'manual Jogo top-side placement override'
}
Check-Aspect $manualResult[0] (9.0 / 16.0) 'manual-portrait-on-top' 0.035
Check-Aspect $manualResult[6] (16.0 / 9.0) 'manual-landscape-on-side' 0.035
Check-NoOverlap $manualResult 'manual-jogo-placement'

# Quatro verticais devem caber na altura útil, todos na borda direita e sem barras.
$multi = 1..10 | ForEach-Object {
    [pscustomobject]@{ WindowWidth = 320; WindowHeight = 180; ContentAspect = (16.0 / 9.0) }
}
$multi[0].ContentAspect = 9.0 / 16.0
$multi[2].ContentAspect = 9.0 / 16.0
$multi[4].ContentAspect = 3.0 / 4.0
$multi[6].ContentAspect = 9.0 / 16.0
$multiResult = @(Build-JogoIntrinsic $multi)
$bottom = ($multiResult | Measure-Object -Property Bottom -Maximum).Maximum
if ($bottom -gt 1032) { $failures += 'portrait rail exceeds work area' }
foreach ($index in @(0, 2, 4, 6)) {
    if ($multiResult[$index].Right -ne 1920 -or $multiResult[$index].Top -lt 0) {
        $failures += "portrait rail alignment slot $($index + 1)"
    }
    Check-Aspect $multiResult[$index] ([double]$multi[$index].ContentAspect) "multi-portrait-$($index + 1)" 0.035
}
Check-NoOverlap $multiResult 'multi-portrait'

if ($failures.Count -gt 0) {
    Write-Host 'JOGO PROFILE LAYOUT CHECK FAILED:' -ForegroundColor Red
    $failures | Sort-Object -Unique | ForEach-Object { Write-Host "- $_" -ForegroundColor Red }
    exit 1
}

Write-Host 'JOGO PROFILE LAYOUT CHECK OK.' -ForegroundColor Green
exit 0
