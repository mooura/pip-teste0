# P0 Optimization RC2 — correção do gate de versão

## Motivo da RC2

O build no Windows compilou o núcleo nativo e aprovou todos os testes anteriores,
mas foi interrompido no `CHECK_CONSOLIDATION_PHASE1_BASELINE.ps1` porque os
metadados da versão corrente estavam divergentes:

- `PiPManager.Wpf.csproj`: `1.5.12.3905`;
- `VERSION_STABLE.txt`: `1.5.12.3905`;
- `ReleaseInfoService.cs`: `1.5.12.3904`.

## Correções

- `ReleaseInfoConstants.AppVersion` alinhado para `1.5.12.3905`;
- checks de Native Layout e Playback Fluency alinhados com a versão corrente;
- banner legado de inicialização passou a usar `ReleaseInfoConstants`, removendo
  números históricos codificados diretamente;
- README, relatório local e notas de release atualizados;
- manifesto SHA-256 da fonte regenerado.

## Escopo funcional

Nenhuma lógica do P0 foi alterada nesta RC2. Permanecem exatamente os quatro
blocos do RC1:

1. coalescimento do arraste antes do Dispatcher;
2. cache da normalização do AutoReturn;
3. persistência assíncrona das configurações com debounce;
4. controle de rajadas de status e snapshots da extensão.

## Validação necessária no Windows

Execute `BUILD_WINDOWS.bat`. O gate que falhava deve agora exibir:

```text
current app version matches release: OK
Consolidation phase 1 baseline checks OK.
```
