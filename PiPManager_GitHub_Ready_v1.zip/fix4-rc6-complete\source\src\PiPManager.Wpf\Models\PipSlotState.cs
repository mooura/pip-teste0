﻿namespace PiPManager.Wpf.Models;

public enum PipSlotState
{
    Free,
    Active,
    Hidden,
    Offline,
    AwaitingPip
}
