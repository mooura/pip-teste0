'use strict';

const fs = require('fs');
const path = require('path');

function assert(condition, message) {
  if (!condition) throw new Error(`TEST FAILED: ${message}`);
}

const root = path.join(__dirname, '..', '..');
const background = fs.readFileSync(
  path.join(root, 'src', 'PiPManager.Extension', 'background.js'),
  'utf8');
const content = fs.readFileSync(
  path.join(root, 'src', 'PiPManager.Extension', 'content.js'),
  'utf8');
const bridge = fs.readFileSync(
  path.join(root, 'src', 'PiPManager.Wpf', 'Services', 'ExtensionBridgeService.cs'),
  'utf8');
const mainWindow = fs.readFileSync(
  path.join(root, 'src', 'PiPManager.Wpf', 'MainWindow.xaml.cs'),
  'utf8');
const autoReturnPolicy = fs.readFileSync(
  path.join(root, 'src', 'PiPManager.Core', 'Core', 'Automation', 'AutoReturnBurstPolicy.cs'),
  'utf8');
const releaseInfo = fs.readFileSync(
  path.join(root, 'src', 'PiPManager.Wpf', 'Services', 'ReleaseInfoService.cs'),
  'utf8');
const manifest = JSON.parse(fs.readFileSync(
  path.join(root, 'src', 'PiPManager.Extension', 'manifest.json'),
  'utf8').replace(/^\uFEFF/, ''));

const commandStart = background.indexOf('async function sendVideoCommand(');
const authoritativePrevious = background.indexOf(
  "command === 'previous' && explicitTargetTabId > 0",
  commandStart);
const sessionResolution = background.indexOf(
  'let resolved = resolveTargetSession(',
  commandStart);

assert(commandStart >= 0, 'background command router must exist');
assert(authoritativePrevious > commandStart, 'Previous must have a linked-tab authoritative branch');
assert(authoritativePrevious < sessionResolution,
  'Previous must execute before stale player/session resolution can block browser history');
assert(background.includes("method = ok ? 'tabs-goBack-linked-tab-authoritative'"),
  'Previous result must expose the authoritative linked-tab method');
assert(background.includes("message.operationId || ''"),
  'the WebSocket router must preserve operationId');

const commandResultBlocks = [...background.matchAll(
  /sendToApp\(\{\s*type:\s*'commandResult',([\s\S]*?)\}\);/g)];
assert(commandResultBlocks.length >= 8, 'all command result paths must remain represented');
assert(commandResultBlocks.every(match => /\boperationId\b/.test(match[1])),
  'every command result path must echo operationId');

assert(bridge.includes('string operationId'), 'WPF bridge command API must require operationId');
assert(bridge.includes('OperationId = operationId'), 'WPF bridge result must retain operationId');
assert(mainWindow.includes('if (!state.CommandConfirmed || state.CommandConfirmedUtc == DateTime.MinValue)'),
  'preservation must wait for authoritative command confirmation');
assert(mainWindow.includes('tab.LastSeenUnixMs >= commandConfirmedUnixMs'),
  'preservation must ignore snapshots older than command confirmation');
assert(mainWindow.includes('pip-preserve-command-rejected:'),
  'rejected commands must explicitly cancel preservation');
assert(mainWindow.includes('state.NavigationCommandResultReceived'),
  'AutoReturn fallback must use the authoritative navigation result');
assert(mainWindow.includes('string expectedProcess, string operationId'),
  'terminal AutoReturn must correlate the exact navigation operation');
assert(mainWindow.includes('NavigationCommandConfirmed = navigationCommandConfirmed'),
  'terminal AutoReturn must inherit an early command result without a race');
assert(mainWindow.includes('NavigationOperationId = navigationOperationId') &&
  mainWindow.includes('autoReturnState.NavigationOperationId, preservation.OperationId'),
  'AutoReturn command results must update only the exact navigation operation');
assert(mainWindow.includes('ShouldRequireRealVideoChangeForNavigation('),
  'loss classification must use the authoritative navigation lifetime policy');
assert(mainWindow.includes('video-navigation-confirmed-operation'),
  'confirmed navigation must retain an explicit AutoReturn eligibility mode');
assert(autoReturnPolicy.includes('if (commandResultReceived)') &&
  autoReturnPolicy.includes('return commandConfirmed;'),
  'a received command result must remain authoritative beyond the short correlation window');
assert(mainWindow.includes('auto-return-target-ready-passive-playing-confirmed:'),
  'AutoReturn must expose the bounded passive-playing readiness proof');
assert(autoReturnPolicy.includes('consecutiveFreshSamples >= Math.Max(2, requiredFreshSamples)'),
  'passive playing readiness must require at least two fresh samples');

assert(background.includes("EXPECTED_CONTENT_VERSION_PREFIX = '1.4.39.7-'"),
  'background must reject stale 1.4.39.6 content scripts');
assert(content.includes("CONTENT_VERSION = '1.4.39.7-autoreturn-confirmed-lifetime'"),
  'content script must expose the navigation transaction marker');
assert(releaseInfo.includes('CompatibleExtensionVersionPrefix = "1.4.39.7-"'),
  'WPF and background must share the exact content/bridge compatibility prefix');
assert(manifest.version === '1.4.39.7',
  'extension manifest must expose the final navigation transaction version');

console.log('Navigation transaction regression tests: OK');
