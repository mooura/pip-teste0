﻿using System.Collections.Concurrent;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Text;
using System.Threading.Channels;

namespace PiPManager.Wpf.Services;

public static class AppLogger
{
    private sealed record LogEntry(DateTime Timestamp, string Level, string Message);

    private sealed class AggregatedLogState
    {
        public object Sync { get; } = new();
        public DateTime LastEmittedUtc { get; set; } = DateTime.MinValue;
        public long Suppressed { get; set; }
        public string LastMessage { get; set; } = string.Empty;
        public string Level { get; set; } = "INFO";
    }

    public static string LogDirectory { get; } = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "PiPManagerWpf");

    public static string LogFile { get; } = Path.Combine(LogDirectory, "pip_manager.log");
    public static string OldLogFile { get; } = Path.Combine(LogDirectory, "pip_manager.old.log");
    public static string DiagnosticFile { get; } = Path.Combine(LogDirectory, "pip_manager_diagnostico.txt");
    public static string SettingsFile { get; } = Path.Combine(LogDirectory, "settings.json");

    private const long MaxLogBytes = 1_000_000;
    private const int QueueCapacity = 8192;
    private const int BatchSize = 128;
    private const int BatchWindowMs = 120;
    private static readonly object FileSync = new();
    private static readonly CancellationTokenSource WriterCancellation = new();
    private static readonly Channel<LogEntry> Queue = Channel.CreateBounded<LogEntry>(
        new BoundedChannelOptions(QueueCapacity)
        {
            SingleReader = true,
            SingleWriter = false,
            FullMode = BoundedChannelFullMode.DropOldest,
            AllowSynchronousContinuations = false
        },
        _ =>
        {
            Interlocked.Increment(ref _droppedEntries);
            Interlocked.Increment(ref _writtenEntries);
        });
    private static readonly Task WriterTask = Task.Run(() => WriterLoopAsync(WriterCancellation.Token));
    private static long _enqueuedEntries;
    private static long _writtenEntries;
    private static long _droppedEntries;
    private static int _stopping;
    private static readonly ConcurrentDictionary<string, AggregatedLogState> AggregatedLogs =
        new(StringComparer.OrdinalIgnoreCase);

    public static void Info(string message) => Write("INFO", message);
    public static void Warn(string message) => Write("WARN", message);
    public static void InfoAggregated(string key, TimeSpan interval, string message) =>
        WriteAggregated("INFO", key, interval, message);
    public static void WarnAggregated(string key, TimeSpan interval, string message) =>
        WriteAggregated("WARN", key, interval, message);
    public static void Error(string message, Exception? ex = null) =>
        Write("ERROR", ex is null ? message : $"{message}: {ex}");

    public static void WriteDiagnostic(string text)
    {
        try
        {
            Flush(TimeSpan.FromSeconds(2));
            lock (FileSync)
            {
                Directory.CreateDirectory(LogDirectory);
                File.WriteAllText(DiagnosticFile, text);
            }
            Info("Diagnóstico salvo em arquivo");
        }
        catch (Exception ex)
        {
            Error("Falha ao salvar diagnóstico", ex);
        }
    }

    public static void OpenLogFile()
    {
        try
        {
            Flush(TimeSpan.FromSeconds(2));
            lock (FileSync)
            {
                Directory.CreateDirectory(LogDirectory);
                if (!File.Exists(LogFile)) File.WriteAllText(LogFile, string.Empty);
            }
            Process.Start(new ProcessStartInfo(LogFile) { UseShellExecute = true });
        }
        catch (Exception ex)
        {
            Error("Falha ao abrir arquivo de log", ex);
        }
    }

    public static void OpenDataFolder()
    {
        try
        {
            Directory.CreateDirectory(LogDirectory);
            Process.Start(new ProcessStartInfo("explorer.exe", LogDirectory) { UseShellExecute = true });
        }
        catch (Exception ex)
        {
            Error("Falha ao abrir pasta de dados/logs", ex);
        }
    }

    public static bool ClearLogs()
    {
        try
        {
            Flush(TimeSpan.FromSeconds(2));
            lock (FileSync)
            {
                Directory.CreateDirectory(LogDirectory);
                DeleteIfExists(LogFile);
                DeleteIfExists(OldLogFile);
                DeleteIfExists(DiagnosticFile);
            }
            Info("Logs limpos");
            return true;
        }
        catch (Exception ex)
        {
            Error("Falha ao limpar logs", ex);
            return false;
        }
    }

    public static bool Flush(TimeSpan timeout)
    {
        var target = Interlocked.Read(ref _enqueuedEntries);
        var deadline = DateTime.UtcNow.Add(timeout <= TimeSpan.Zero ? TimeSpan.FromMilliseconds(1) : timeout);
        while (Interlocked.Read(ref _writtenEntries) < target && DateTime.UtcNow < deadline)
            Thread.Sleep(10);
        return Interlocked.Read(ref _writtenEntries) >= target;
    }

    public static void FlushAndStop(TimeSpan timeout)
    {
        if (Volatile.Read(ref _stopping) != 0)
            return;

        FlushAggregatedLogs();
        if (Interlocked.Exchange(ref _stopping, 1) != 0)
            return;

        Queue.Writer.TryComplete();
        try
        {
            if (!WriterTask.Wait(timeout))
                WriterCancellation.Cancel();
        }
        catch
        {
            WriterCancellation.Cancel();
        }
    }

    public static string BuildEnvironmentDiagnosticHeader()
    {
        var asm = Assembly.GetExecutingAssembly().GetName();
        return string.Join(Environment.NewLine, new[]
        {
            "PiP Manager WPF - Diagnóstico",
            $"Gerado em: {DateTime.Now:yyyy-MM-dd HH:mm:ss}",
            $"Versão Assembly: {asm.Version}",
            $"Sistema: {Environment.OSVersion}",
            $".NET: {Environment.Version}",
            $"64 bits processo: {Environment.Is64BitProcess}",
            $"64 bits sistema: {Environment.Is64BitOperatingSystem}",
            $"Diretório base: {AppContext.BaseDirectory}",
            $"Diretório de dados: {LogDirectory}",
            $"Arquivo de log: {LogFile}",
            $"Arquivo de config: {SettingsFile}",
            ""
        });
    }

    private static void WriteAggregated(string level, string key, TimeSpan interval, string message)
    {
        if (string.IsNullOrWhiteSpace(key) || interval <= TimeSpan.Zero)
        {
            Write(level, message);
            return;
        }

        var state = AggregatedLogs.GetOrAdd(key, _ => new AggregatedLogState());
        string? line = null;
        lock (state.Sync)
        {
            var now = DateTime.UtcNow;
            state.Level = level;
            state.LastMessage = message;
            if (state.LastEmittedUtc == DateTime.MinValue || now - state.LastEmittedUtc >= interval)
            {
                line = state.Suppressed > 0
                    ? $"{message}; aggregatedSuppressed={state.Suppressed}"
                    : message;
                state.Suppressed = 0;
                state.LastEmittedUtc = now;
            }
            else
            {
                state.Suppressed++;
            }
        }

        if (line is not null)
            Write(level, line);
    }

    private static void FlushAggregatedLogs()
    {
        foreach (var state in AggregatedLogs.Values)
        {
            string? line = null;
            string level;
            lock (state.Sync)
            {
                level = state.Level;
                if (state.Suppressed > 0 && !string.IsNullOrWhiteSpace(state.LastMessage))
                {
                    line = $"{state.LastMessage}; aggregatedSuppressed={state.Suppressed}; aggregateFlush=shutdown";
                    state.Suppressed = 0;
                    state.LastEmittedUtc = DateTime.UtcNow;
                }
            }

            if (line is not null)
                Write(level, line);
        }
    }

    private static void Write(string level, string message)
    {
        try
        {
            if (Volatile.Read(ref _stopping) != 0)
                return;

            var entry = new LogEntry(DateTime.Now, level, message);
            if (Queue.Writer.TryWrite(entry))
                Interlocked.Increment(ref _enqueuedEntries);
        }
        catch
        {
            // Logging must never crash or block the UI.
        }
    }

    private static async Task WriterLoopAsync(CancellationToken cancellationToken)
    {
        var batch = new List<LogEntry>(BatchSize);
        try
        {
            Directory.CreateDirectory(LogDirectory);
            while (await Queue.Reader.WaitToReadAsync(cancellationToken).ConfigureAwait(false))
            {
                batch.Clear();
                if (Queue.Reader.TryRead(out var first))
                    batch.Add(first);

                var deadline = DateTime.UtcNow.AddMilliseconds(BatchWindowMs);
                while (batch.Count < BatchSize && DateTime.UtcNow < deadline)
                {
                    while (batch.Count < BatchSize && Queue.Reader.TryRead(out var next))
                        batch.Add(next);

                    if (batch.Count >= BatchSize || Queue.Reader.Completion.IsCompleted)
                        break;

                    var remaining = deadline - DateTime.UtcNow;
                    if (remaining <= TimeSpan.Zero)
                        break;
                    await Task.Delay(remaining < TimeSpan.FromMilliseconds(15) ? remaining : TimeSpan.FromMilliseconds(15), cancellationToken)
                        .ConfigureAwait(false);
                }

                while (batch.Count < BatchSize && Queue.Reader.TryRead(out var trailing))
                    batch.Add(trailing);

                if (batch.Count > 0)
                    WriteBatch(batch);
            }

            batch.Clear();
            while (Queue.Reader.TryRead(out var remainingEntry))
            {
                batch.Add(remainingEntry);
                if (batch.Count >= BatchSize)
                {
                    WriteBatch(batch);
                    batch.Clear();
                }
            }
            if (batch.Count > 0)
                WriteBatch(batch);
        }
        catch (OperationCanceledException)
        {
            // Best-effort shutdown.
        }
        catch
        {
            // Logging must never crash the process.
        }
    }

    private static void WriteBatch(IReadOnlyList<LogEntry> batch)
    {
        try
        {
            var builder = new StringBuilder(batch.Count * 160);
            foreach (var entry in batch)
                builder.Append(entry.Timestamp.ToString("yyyy-MM-dd HH:mm:ss.fff"))
                    .Append(" [").Append(entry.Level).Append("] ")
                    .Append(entry.Message).AppendLine();

            var dropped = Interlocked.Exchange(ref _droppedEntries, 0);
            if (dropped > 0)
                builder.Append(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff"))
                    .Append(" [WARN] async-log-queue-dropped: count=").Append(dropped).AppendLine();

            lock (FileSync)
            {
                Directory.CreateDirectory(LogDirectory);
                RotateIfNeeded(builder.Length * sizeof(char));
                File.AppendAllText(LogFile, builder.ToString());
            }
            Interlocked.Add(ref _writtenEntries, batch.Count);
        }
        catch
        {
            Interlocked.Add(ref _writtenEntries, batch.Count);
        }
    }

    private static void RotateIfNeeded(long incomingBytes)
    {
        try
        {
            var info = new FileInfo(LogFile);
            if (!info.Exists || info.Length + incomingBytes <= MaxLogBytes) return;
            DeleteIfExists(OldLogFile);
            File.Move(LogFile, OldLogFile);
        }
        catch
        {
            // Rotation failure cannot crash app.
        }
    }

    private static void DeleteIfExists(string path)
    {
        if (File.Exists(path)) File.Delete(path);
    }
}
