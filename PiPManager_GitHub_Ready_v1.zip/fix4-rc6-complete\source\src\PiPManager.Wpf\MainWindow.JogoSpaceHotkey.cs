﻿using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Interop;
using PiPManager.Wpf.Models;
using PiPManager.Wpf.Services;

namespace PiPManager.Wpf;

public partial class MainWindow
{
    private const int JogoSpaceHideHotkeyId = 0x4A47;
    private const int WmHotkey = 0x0312;
    private const uint ModNoRepeat = 0x4000;
    private const uint VkSpace = 0x20;

    private bool _jogoSpaceHideHotkeyEnabled;
    private bool _jogoSpaceHideHotkeyRegistered;
    private bool _jogoSpaceHideHotkeyRegistrationFailed;
    private HwndSource? _jogoSpaceHideHotkeySource;
    private IntPtr _jogoSpaceHideHotkeyWindowHandle = IntPtr.Zero;

    private void InitializeJogoSpaceHideHotkey()
    {
        _jogoSpaceHideHotkeyEnabled = _settings.JogoSpaceHideHotkeyEnabled;
        UpdateJogoSpaceHideHotkeyUi();
    }

    private void ActivateJogoSpaceHideHotkey()
    {
        EnsureJogoSpaceHideHotkeyWindowHook();
        UpdateJogoSpaceHideHotkeyRegistration("window-loaded");
    }

    private void JogoSpaceHideHotkeyMenuItem_Click(object sender, RoutedEventArgs e)
    {
        _jogoSpaceHideHotkeyEnabled = JogoSpaceHideHotkeyMenuItem.IsChecked;
        _jogoSpaceHideHotkeyRegistrationFailed = false;
        UpdateJogoSpaceHideHotkeyRegistration("menu-toggle");
        SaveSettings();

        if (!_jogoSpaceHideHotkeyEnabled)
        {
            SetStatus("Atalho Espaço do perfil Jogo desativado");
            return;
        }

        if (_jogoSpaceHideHotkeyRegistrationFailed)
        {
            SetStatus("Não foi possível reservar a tecla Espaço; desative outro atalho global que esteja usando essa tecla");
            return;
        }

        SetStatus(_jogoSpaceHideHotkeyRegistered
            ? "Atalho Espaço ativado: ocultar/mostrar PiPs no perfil Jogo"
            : "Atalho Espaço configurado; será ativado somente no perfil Jogo");
    }

    private void UpdateJogoSpaceHideHotkeyRegistration(string source)
    {
        var shouldRegister = _jogoSpaceHideHotkeyEnabled && CurrentLayout == LayoutMode.Jogo;
        if (!shouldRegister)
        {
            UnregisterJogoSpaceHideHotkey(source);
            _jogoSpaceHideHotkeyRegistrationFailed = false;
            UpdateJogoSpaceHideHotkeyUi();
            AppLogger.Info(
                $"jogo-space-hide-hotkey-state: source={source}; enabled={_jogoSpaceHideHotkeyEnabled}; " +
                $"profile={CurrentLayout}; registered=False; reason={(CurrentLayout == LayoutMode.Jogo ? "disabled" : "profile-not-jogo")}");
            return;
        }

        if (_jogoSpaceHideHotkeyRegistered)
        {
            UpdateJogoSpaceHideHotkeyUi();
            return;
        }

        if (!EnsureJogoSpaceHideHotkeyWindowHook())
        {
            _jogoSpaceHideHotkeyRegistrationFailed = true;
            UpdateJogoSpaceHideHotkeyUi();
            AppLogger.Warn($"jogo-space-hide-hotkey-registration-failed: source={source}; reason=no-window-hook");
            return;
        }

        _jogoSpaceHideHotkeyRegistered = RegisterHotKey(
            _jogoSpaceHideHotkeyWindowHandle,
            JogoSpaceHideHotkeyId,
            ModNoRepeat,
            VkSpace);
        _jogoSpaceHideHotkeyRegistrationFailed = !_jogoSpaceHideHotkeyRegistered;

        if (_jogoSpaceHideHotkeyRegistered)
        {
            AppLogger.Info(
                $"jogo-space-hide-hotkey-registered: source={source}; key=Space; modifiers=None; " +
                "noRepeat=True; profile=Jogo; action=toggle-pip-visibility");
        }
        else
        {
            var error = Marshal.GetLastWin32Error();
            AppLogger.Warn(
                $"jogo-space-hide-hotkey-registration-failed: source={source}; key=Space; " +
                $"win32Error={error}; profile=Jogo");
            SetStatus("Não foi possível reservar a tecla Espaço; desative outro atalho global que esteja usando essa tecla");
        }

        UpdateJogoSpaceHideHotkeyUi();
    }

    private bool EnsureJogoSpaceHideHotkeyWindowHook()
    {
        if (_jogoSpaceHideHotkeySource is not null && _jogoSpaceHideHotkeyWindowHandle != IntPtr.Zero)
            return true;

        var handle = new WindowInteropHelper(this).Handle;
        if (handle == IntPtr.Zero)
            return false;

        var source = HwndSource.FromHwnd(handle);
        if (source is null)
            return false;

        source.AddHook(JogoSpaceHideHotkeyWndProc);
        _jogoSpaceHideHotkeySource = source;
        _jogoSpaceHideHotkeyWindowHandle = handle;
        return true;
    }

    private IntPtr JogoSpaceHideHotkeyWndProc(
        IntPtr hwnd,
        int message,
        IntPtr wParam,
        IntPtr lParam,
        ref bool handled)
    {
        if (message != WmHotkey || wParam.ToInt32() != JogoSpaceHideHotkeyId)
            return IntPtr.Zero;

        handled = true;
        if (!_jogoSpaceHideHotkeyEnabled || CurrentLayout != LayoutMode.Jogo)
        {
            AppLogger.Info(
                $"jogo-space-hide-hotkey-ignored: enabled={_jogoSpaceHideHotkeyEnabled}; profile={CurrentLayout}");
            return IntPtr.Zero;
        }

        ToggleAllVisibility();
        AppLogger.Info(
            $"jogo-space-hide-hotkey-triggered: key=Space; profile=Jogo; hidden={_allHidden}; action=toggle-pip-visibility");
        return IntPtr.Zero;
    }

    private void UnregisterJogoSpaceHideHotkey(string source)
    {
        if (!_jogoSpaceHideHotkeyRegistered)
            return;

        var unregistered = _jogoSpaceHideHotkeyWindowHandle != IntPtr.Zero
            && UnregisterHotKey(_jogoSpaceHideHotkeyWindowHandle, JogoSpaceHideHotkeyId);
        _jogoSpaceHideHotkeyRegistered = false;
        AppLogger.Info($"jogo-space-hide-hotkey-unregistered: source={source}; ok={unregistered}");
    }

    private void UpdateJogoSpaceHideHotkeyUi()
    {
        if (JogoSpaceHideHotkeyMenuItem is null)
            return;

        var isJogo = CurrentLayout == LayoutMode.Jogo;
        JogoSpaceHideHotkeyMenuItem.IsEnabled = isJogo;
        JogoSpaceHideHotkeyMenuItem.IsChecked = _jogoSpaceHideHotkeyEnabled;
        JogoSpaceHideHotkeyMenuItem.Header = _jogoSpaceHideHotkeyRegistrationFailed
            ? "Atalho Espaço: indisponível"
            : _jogoSpaceHideHotkeyRegistered
                ? "Atalho Espaço: ocultar/mostrar PiPs — ON"
                : "Atalho Espaço: ocultar/mostrar PiPs";
        JogoSpaceHideHotkeyMenuItem.ToolTip = isJogo
            ? "Quando ativado, a tecla Espaço global alterna entre ocultar e mostrar os PiPs."
            : "Disponível somente enquanto o perfil Jogo estiver selecionado.";
    }

    private void DisposeJogoSpaceHideHotkey()
    {
        UnregisterJogoSpaceHideHotkey("window-closing");
        if (_jogoSpaceHideHotkeySource is not null)
            _jogoSpaceHideHotkeySource.RemoveHook(JogoSpaceHideHotkeyWndProc);
        _jogoSpaceHideHotkeySource = null;
        _jogoSpaceHideHotkeyWindowHandle = IntPtr.Zero;
    }

    [DllImport("user32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool RegisterHotKey(IntPtr hWnd, int id, uint fsModifiers, uint vk);

    [DllImport("user32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool UnregisterHotKey(IntPtr hWnd, int id);
}
