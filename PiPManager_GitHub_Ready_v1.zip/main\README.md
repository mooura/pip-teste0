# PiPManager

Advanced Picture-in-Picture (PiP) manager for Firefox with intelligent video discovery, automated restoration, and multi-slot layout support.

## Overview

PiPManager is a comprehensive Picture-in-Picture management suite that provides intelligent video handling across multiple browser windows and tabs. The project includes both a desktop application (.NET 8 + WPF) and a Firefox browser extension.

## Branches

### main
Documentation and project overview. Contains build instructions and release notes.

### fix4-rc6
**Stable Release Branch**
- Application Version: 9.39.03
- Extension Version: 1.4.39.7
- Focus: Tab occupancy notifications and fixed layout mode
- Status: Stable/RC (Release Candidate)
- Features:
  - Tab-occupied-slots v2 optimization
  - Improved multi-site video platform support
  - Enhanced layout management
  - Robust error handling

### pip12h4-hotfix8
**Development Branch**
- Application Version: 9.39.03
- Extension Version: 1.4.39.25
- Focus: Advanced AutoReturn and preload handling with 8 hotfixes
- Status: Development/Testing
- Features:
  - Universal geometry authority system
  - Advanced AutoReturn mechanisms
  - Preserved state synchronization
  - Integrated sync handling
  - Real-time tab occupancy tracking
  - Automated playlist navigation

## Quick Start

### For Fix4 RC6 (Stable)
```bash
git clone https://github.com/pip-teste/PiPManager.git
git checkout fix4-rc6
cd PiPManager_9.39.03_FIX4_RC3_P0_OPTIMIZATION_RC6_SOURCE
# See SETUP_FIX4_RC6.md for build instructions
```

### For PIP12H4 + Hotfix 8 (Development)
```bash
git clone https://github.com/pip-teste/PiPManager.git
git checkout pip12h4-hotfix8
cd [project-directory]
# See SETUP_PIP12H4.md for build instructions
```

## Features

- **Automatic PiP Window Restoration**: Preserves and restores PiP windows across sessions
- **Multi-Site Video Platform Support**: YouTube, Vimeo, Dailymotion, Twitch, and more
- **Intelligent Playlist Navigation**: Automated playlist handling with state preservation
- **Adaptive Layout Management**: Dynamic window positioning and sizing
- **Real-Time Tab Occupancy Tracking**: Monitors tab availability for PiP operations
- **Advanced AutoReturn**: Intelligent video return handling with universal geometry

## Platform Support

- **Desktop Application**: Windows (.NET 8 + WPF)
- **Browser Extension**: Mozilla Firefox
- **Minimum Requirements**:
  - Windows 10 or later
  - .NET 8 Runtime
  - Firefox 90+

## Development

### Architecture

```
PiPManager/
├── Application (WPF Desktop)
│   ├── Core (PiP management logic)
│   ├── UI (Windows and controls)
│   ├── Services (Video detection, layout management)
│   └── Configuration
├── Extension (Firefox)
│   ├── Content Scripts
│   ├── Background Scripts
│   ├── UI Components
│   └── Manifest
└── Documentation
    ├── Build guides
    ├── Setup instructions
    └── API reference
```

### Build System

Both branches include PowerShell build scripts:
- `BUILD_WINDOWS.bat` - Main build script
- `BUILD_RELEASE.bat` - Release build
- `TEST_DEBUG.bat` - Debug testing

### Testing

- Unit tests included in each branch
- Integration tests for core features
- Manual testing procedures in setup guides

## Requirements

### Development
- Visual Studio 2022 or later
- .NET 8 SDK
- PowerShell 5.0+
- Firefox Developer Edition (for extension testing)

### Build Dependencies
- See branch-specific `packages.config` or project files
- Run build scripts to auto-restore dependencies

## Documentation

- **SETUP_FIX4_RC6.md** - Build and deployment for stable branch
- **SETUP_PIP12H4.md** - Build and deployment for development branch
- **VERSIONS.md** - Complete version history and features
- **CONTRIBUTING.md** - Contribution guidelines
- **LICENSE** - License information

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md) for contribution guidelines, pull request process, and development standards.

## License

This project is licensed under the MIT License - see [LICENSE](LICENSE) file for details.

## Acknowledgments

- Firefox browser extension community
- .NET/WPF development community
- Video platform API documentation maintainers

## Support

For issues, bug reports, and feature requests:
1. Check existing issues and documentation
2. Provide detailed reproduction steps
3. Include system information and version numbers
4. Follow the contribution guidelines

## Release Timeline

- **fix4-rc6**: Stable release candidate for production use
- **pip12h4-hotfix8**: Development branch with latest features and improvements

---

**Repository**: https://github.com/pip-teste/PiPManager  
**Last Updated**: 2026-08-05
