# Bloco 3 — organização estrutural

## Escopo

Esta etapa altera somente a organização dos arquivos de desenvolvimento. Não
move nem modifica o runtime WPF, o Core, a extensão, o protocolo, o AutoReturn,
o Next, a descoberta de abas ou o motor de layout.

## Estrutura aplicada

- 67 verificadores `CHECK_*.ps1` movidos da raiz para `tools/checks/`.
- Documentação de consolidação movida para `docs/consolidation/`.
- Documentação de estabilização movida para `docs/stabilization/`.
- Pontos de entrada canônicos (`RUN_CORE_TESTS.bat`, `RUN_CI.ps1` e
  `RUN_STABILIZATION_GATE.ps1`) mantidos na raiz.
- Todos os verificadores resolvem a raiz do projeto a partir da própria
  localização, sem depender do diretório corrente.

## Validação

- Os 67 scripts passaram na análise sintática do PowerShell.
- O inventário de testes confirmou 66 checks contínuos e 1 condicional.
- Blocos A, B e C passaram com os novos caminhos.
- O gate completo terminou com `ALL TESTS AND CHECKS OK`.
- O build WPF Release terminou com zero erros e zero avisos.
- O gate terminou com `STABILIZATION GATE PASSED: layer=All; full=True`.
