# Correção de compilação do atalho Espaço

Foi corrigido o erro CS0136 em `MainWindow.xaml.cs`.

A referência usada pelo fluxo `Igualar` do perfil Jogo agora se chama `jogoReference`, evitando conflito com a variável `reference` usada posteriormente no mesmo método para os demais layouts.

Nenhuma lógica do atalho Espaço, do perfil Jogo ou do redimensionamento/Igualar por grupo foi alterada.
