$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path

function Check([string]$label, [bool]$condition) {
    if (-not $condition) { throw "FAIL: $label" }
    Write-Host "$label`: OK"
}

$settings = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\Models\AppSettings.cs') -Raw
$model = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\Models\RelativeGroupLayout.cs') -Raw
$engine = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\Services\GroupTransformEngine.cs') -Raw
$fixed = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\MainWindow.FixedLayout.cs') -Raw
$main = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\MainWindow.xaml.cs') -Raw
$drag = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\MainWindow.PipDrag.cs') -Raw
$layout = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\Services\LayoutService.cs') -Raw
$tests = Get-Content -LiteralPath (Join-Path $root 'tests\PiPManager.WindowEventMonitor.Tests\Program.cs') -Raw
$burstPolicy = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Core\Core\Automation\AutoReturnBurstPolicy.cs') -Raw

Check 'relative template persists anchor and slot offsets' ($settings.Contains('RelativeFixedLayout') -and $model.Contains('AnchorX') -and $model.Contains('OffsetX'))
Check 'group engine captures and materializes one template' ($engine.Contains('RelativeGroupLayout Capture(') -and $engine.Contains('Materialize(') -and $engine.Contains('Translate('))
Check 'legacy absolute layout migrates to relative authority' ($fixed.Contains('initialize-migrate-absolute') -and $fixed.Contains('CaptureRelativeFixedAuthority'))
Check 'fixing captures without moving current PiPs' ($fixed.Contains('TryCaptureCurrentFixedLayoutWithoutMoving("menu-enable")') -and -not $fixed.Contains('ApplyFixedLayoutToAllActive("menu-enable")'))
Check 'group drag has one final all-window batch' ($drag.Contains('ApplyLockedGroupModelOnce();') -and $drag.Contains('natural-anchor-drag-final'))
Check 'visual seams use exact DWM edges' ($layout.Contains('VisualSeamCompensationPx = 0'))
Check 'AutoReturn opens one recovery layout cycle' ($main.Contains('BeginFixedLayoutRecoveryCycle(slot.Number, reason)'))
Check 'per-slot recovery avoids repeated verification sequence' ($fixed.Contains('ApplyFixedSlotGeometryOnceDuringRecovery') -and $fixed.Contains('fixed-layout-recovery-slot-placed-once'))
Check 'global recovery batch waits for expected slots or timeout' ($fixed.Contains('allRecovered') -and $fixed.Contains('FixedLayoutRecoveryTimeoutMs') -and $fixed.Contains('recovery-cycle-final-complete'))
Check 'global recovery timeout scales with expected slots' ($fixed.Contains('GetLayoutRecoveryTimeoutMilliseconds') -and $fixed.Contains('timeoutMs={recoveryTimeoutMs}') -and $burstPolicy.Contains('MaxLayoutRecoveryTimeoutMilliseconds'))
Check 'ordinary group debounce is suppressed during recovery' ($main.Contains('reason=fixed-layout-recovery-cycle'))
Check 'relative topology has executable tests' ($tests.Contains('Relative group transform sequence OK.') -and $tests.Contains('must preserve the L topology'))

Write-Host 'Relative group layout and recovery checks OK.' -ForegroundColor Green
