$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$main = Get-Content (Join-Path $Root 'src\PiPManager.Wpf\MainWindow.xaml.cs') -Raw
$drag = Get-Content (Join-Path $Root 'src\PiPManager.Wpf\MainWindow.PipDrag.cs') -Raw
$policy = Get-Content (Join-Path $Root 'src\PiPManager.Core\Core\Automation\AutoReturnBurstPolicy.cs') -Raw
$state = Get-Content (Join-Path $Root 'src\PiPManager.Wpf\Models\AutoReturnSlotState.cs') -Raw
$tests = Get-Content (Join-Path $Root 'tests\PiPManager.Core.Tests\Program.cs') -Raw
$failed = 0
function Check($name, $ok) {
  if ($ok) { Write-Host "$name`: OK" } else { Write-Host "$name`: FAIL"; $script:failed++ }
}
Write-Host 'Checking five-PiP identity stability...'
Check 'stable key is not strong change with active session' ($main -match 'var stableChangedWithoutStrongIdentity = string\.IsNullOrWhiteSpace\(tab\.PairKey\)[\s\S]{0,240}string\.IsNullOrWhiteSpace\(state\.OldSession\)[\s\S]{0,120}&& stableChanged;' -and $main -match 'return sessionChanged \|\| urlChanged \|\| stableChangedWithoutStrongIdentity;')
Check 'candidate stabilization ignores stable key churn' ($main -match 'BuildAutoReturnCandidateKey\(VideoTabInfo tab\)' -and $main -notmatch '\$"\{tab.TabId\}\|\{tab.PairKey\}\|\{tab.StableVideoKey\}')
Check 'Hidden and Destroyed are debounced' ($main -match 'window-event-assisted-loss-deferred' -and $main -match 'WindowLossDebounceMs = 1200')
Check 'Shown cancels transient loss' ($main -match 'CancelWindowLossDebounce\(ev.Hwnd')
Check 'usable PiP suppresses transient loss' ($main -match 'window-event-loss-debounce-suppressed' -and $main -match 'window-usable-after-transient-event')
Check 'loss identity is reserved before debounce admission' ($main -match 'window-event-loss-identity-reserved' -and $main -match 'pendingAdmission=after-debounce')
Check 'drag cleanup preserves every linked AutoReturn slot' ($drag -match 'AutoReturnBurstPolicy.ShouldPreserveLostSlot' -and $drag -notmatch 'preserveForAutoReturn[\s\S]{0,300}_autoReturnStatesBySlot.ContainsKey')
Check 'serialized queue resumes pending slots' ($main -match 'auto-return-serialization-resume-pending' -and $main -match 'await AutoReturnTickAsync\(\)')
Check 'burst queue is oldest-first and gains lifetime' ($main -match 'OrderBy\(item => item.PendingSinceUtc\)' -and $main -match 'GetPendingMaxAgeSeconds')
Check 'each queued slot retains its admitted lifetime' ($state -match 'MaxPendingAgeSeconds' -and $main -match 'state.MaxPendingAgeSeconds')
Check 'burst policy has executable regression tests' ($policy -match 'GetPendingMaxAgeSeconds' -and $tests -match 'TestAutoReturnBurstPolicy\(\)')
$runner = Get-Content (Join-Path $Root 'RUN_CORE_TESTS.bat') -Raw
Check 'checker included in core gate' ($runner -match 'CHECK_FIVE_PIP_IDENTITY_STABILITY.ps1')
if ($failed -gt 0) { throw 'Five-PiP identity stability checks failed.' }
Write-Host 'Five-PiP identity stability checks OK.'
