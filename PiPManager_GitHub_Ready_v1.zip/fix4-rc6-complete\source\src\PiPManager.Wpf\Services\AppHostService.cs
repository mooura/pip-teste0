﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace PiPManager.Wpf.Services;

public static class AppHostService
{
    public static IHost Build()
    {
        return Host.CreateDefaultBuilder()
            .ConfigureServices(services =>
            {
                services.AddSingleton<IReleaseInfoService, ReleaseInfoService>();
                services.AddSingleton<ILogMaintenanceService, LogMaintenanceService>();
                services.AddSingleton<IShadowDiagnosticsService, ShadowDiagnosticsService>();

                services.AddSingleton<SettingsService>();
                services.AddSingleton<WindowDiscoveryService>();
                services.AddSingleton<PipWindowService>();
                services.AddSingleton<LayoutService>();
                services.AddSingleton<MonitorService>();
                services.AddSingleton<ExtensionBridgeService>();
                services.AddSingleton<VideoCommandService>();
                services.AddSingleton<WindowEventFlowControlService>();
                services.AddSingleton<IWindowEventFlowControlService>(sp => sp.GetRequiredService<WindowEventFlowControlService>());
                services.AddSingleton<WindowsEventMonitorService>();
                services.AddSingleton<IWindowEventMonitorService>(sp => sp.GetRequiredService<WindowsEventMonitorService>());
                services.AddSingleton<FakeWindowEventMonitorSource>();
                services.AddSingleton<WindowEventReactorService>();
                services.AddSingleton<IWindowEventReactorService>(sp => sp.GetRequiredService<WindowEventReactorService>());
                services.AddSingleton<AutomationCoordinator>();
                services.AddSingleton<IAutomationCoordinator>(sp => sp.GetRequiredService<AutomationCoordinator>());

                services.AddSingleton<ApplicationHealthService>();
                services.AddSingleton<IApplicationHealthService>(sp => sp.GetRequiredService<ApplicationHealthService>());

                services.AddHostedService<ExtensionBridgeHostedService>();
                services.AddHostedService(sp => sp.GetRequiredService<WindowsEventMonitorService>());
                services.AddHostedService(sp => sp.GetRequiredService<WindowEventReactorService>());
            })
            .Build();
    }
}
