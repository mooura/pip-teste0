﻿using PiPManager.Wpf.Models;

namespace PiPManager.Wpf.Services;

public sealed class WindowDiscoveryService
{
    private static readonly string[] BrowserProcesses =
    [
        "zen.exe", "firefox.exe", "chrome.exe", "msedge.exe", "brave.exe",
        "opera.exe", "opera_gx.exe", "vivaldi.exe", "arc.exe", "chromium.exe"
    ];

    private static readonly string[] BlockedProcesses =
    [
        "explorer.exe", "shellexperiencehost.exe", "searchhost.exe",
        "startmenuexperiencehost.exe", "applicationframehost.exe", "systemsettings.exe",
        "cmd.exe", "powershell.exe", "windowsterminal.exe", "python.exe", "pythonw.exe",
        "pipmanager.wpf.exe"
    ];

    public List<PipWindowInfo> FindPipWindows()
    {
        var result = new List<PipWindowInfo>();

        Win32.EnumWindows((hWnd, enumState) =>
        {
            if (TryGetPipWindow(hWnd, out var window, out _) && window is not null)
                result.Add(window);

            return true;
        }, IntPtr.Zero);

        return result
            .OrderBy(w => w.VisualRect.Top)
            .ThenBy(w => w.VisualRect.Left)
            .ThenByDescending(w => w.Score)
            .ThenBy(w => w.Handle.ToInt64())
            .ToList();
    }

    // Direct HWND validation used by the event reactor. This intentionally does not call EnumWindows.
    public bool TryGetPipWindow(IntPtr hWnd, out PipWindowInfo? window, out string rejectionReason)
    {
        window = null;
        rejectionReason = "unknown";

        try
        {
            if (hWnd == IntPtr.Zero)
            {
                rejectionReason = "zero-hwnd";
                return false;
            }

            if (!Win32.IsWindow(hWnd))
            {
                rejectionReason = "not-a-window";
                return false;
            }

            if (!Win32.IsWindowVisible(hWnd))
            {
                rejectionReason = "not-visible";
                return false;
            }

            if (Win32.IsIconic(hWnd))
            {
                rejectionReason = "iconic";
                return false;
            }

            if (Win32.IsCloaked(hWnd))
            {
                rejectionReason = "cloaked";
                return false;
            }

            var pid = Win32.GetProcessId(hWnd);
            if (pid <= 0)
            {
                rejectionReason = "missing-process-id";
                return false;
            }

            if (pid == Environment.ProcessId)
            {
                rejectionReason = "own-process";
                return false;
            }

            var title = Win32.GetWindowTitle(hWnd).Trim();
            if (string.IsNullOrWhiteSpace(title))
            {
                rejectionReason = "empty-title";
                return false;
            }

            var className = Win32.GetClass(hWnd).Trim();
            if (string.IsNullOrWhiteSpace(className))
            {
                rejectionReason = "empty-class";
                return false;
            }

            var process = Win32.GetProcessName(hWnd).Trim().ToLowerInvariant();
            if (string.IsNullOrWhiteSpace(process))
            {
                rejectionReason = "empty-process";
                return false;
            }

            if (BlockedProcesses.Contains(process))
            {
                rejectionReason = $"blocked-process:{process}";
                return false;
            }

            var rect = PipWindowService.GetVisualRect(hWnd);
            if (!rect.IsValid)
            {
                rejectionReason = "invalid-visual-rect";
                return false;
            }

            if (rect.Width < 80 || rect.Height < 45)
            {
                rejectionReason = $"rect-too-small:{rect.Width}x{rect.Height}";
                return false;
            }

            if (rect.Width > 1600 || rect.Height > 1200)
            {
                rejectionReason = $"rect-too-large:{rect.Width}x{rect.Height}";
                return false;
            }

            var score = ScorePipWindow(title, className, process, rect);
            if (score < 70)
            {
                rejectionReason = $"score-below-threshold:{score}";
                return false;
            }

            window = new PipWindowInfo(hWnd, pid, process, title, className, rect, score);
            rejectionReason = "accepted";
            return true;
        }
        catch (Exception ex)
        {
            rejectionReason = $"exception:{ex.GetType().Name}";
            return false;
        }
    }

    private static int ScorePipWindow(string title, string className, string processName, NativeRect rect)
    {
        var t = Normalize(title);
        var c = className.ToLowerInvariant();
        var p = processName.ToLowerInvariant();

        var isPipTitle = t.Contains("picture-in-picture") ||
                         t.Contains("picture in picture") ||
                         t.Contains("imagem em imagem") ||
                         t.Contains("imagen en imagen") ||
                         t.Contains("bild-in-bild");
        if (!isPipTitle) return 0;

        var score = 100;
        if (c.Contains("mozilladialogclass")) score += 35;
        if (c.Contains("chrome_widgetwin")) score += 18;
        if (c.Contains("dialog")) score += 10;
        if (BrowserProcesses.Contains(p)) score += 20;

        var ratio = rect.Width / Math.Max(1.0, (double)rect.Height);
        if (ratio is >= 1.15 and <= 2.5) score += 8;
        if (ratio is >= 0.35 and < 1.05) score += 8;
        if (rect.Width <= 950 && rect.Height <= 950) score += 10;
        return score;
    }

    private static string Normalize(string value) => value
        .ToLowerInvariant()
        .Replace('–', '-')
        .Replace('—', '-')
        .Replace('‑', '-')
        .Replace('‐', '-')
        .Trim();
}
