$ErrorActionPreference = "Stop"
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$servicePath = Join-Path $root "src\PiPManager.Wpf\Services\WindowEventReactorService.cs"
$hostPath = Join-Path $root "src\PiPManager.Wpf\Services\AppHostService.cs"
$gatePath = Join-Path $root "RUN_CORE_TESTS.bat"

$service = Get-Content $servicePath -Raw
$hostFile = Get-Content $hostPath -Raw
$gate = Get-Content $gatePath -Raw

# Do not reject comments or diagnostics that merely mention "Dispatcher".
# Reject only concrete WPF dispatcher APIs/dependencies in the reactor source.
$hasWpfDispatcherDependency =
  $service.Contains("using System.Windows.Threading") -or
  $service.Contains("System.Windows.Threading.Dispatcher") -or
  $service.Contains("Dispatcher.CurrentDispatcher") -or
  $service.Contains("DispatcherTimer") -or
  $service.Contains(".Dispatcher.Invoke(") -or
  $service.Contains(".Dispatcher.BeginInvoke(") -or
  $service.Contains(".Dispatcher.InvokeAsync(")

$checks = [ordered]@{
  "bounded channel" = $service.Contains("Channel.CreateBounded<WindowMonitorEvent>")
  "drop oldest overload policy" = $service.Contains("BoundedChannelFullMode.DropOldest")
  "single dedicated reader" = $service.Contains("SingleReader = true")
  "75 ms coalescing" = $service.Contains("TimeSpan.FromMilliseconds(75)")
  "coalesce by HWND and category" = $service.Contains("BuildCoalesceKey")
  "legacy fallback authority retained" = $service.Contains("fallback=armed-pair-timer")
  "configurable authority advertised" = $service.Contains("authority=configurable(compare-default)")
  "shadow processing remains non-UI" = $service.Contains("mode=shadow-assisted-candidate")
  "no WPF Dispatcher API dependency" = -not $hasWpfDispatcherDependency
  "registered singleton" = $hostFile.Contains("AddSingleton<WindowEventReactorService>")
  "registered hosted service" = $hostFile.Contains("GetRequiredService<WindowEventReactorService>()")
  "checker included in core gate" = $gate.Contains("CHECK_WINDOW_EVENT_REACTOR_SHADOW.ps1")
}

$failed = 0
foreach ($item in $checks.GetEnumerator()) {
  $status = if ($item.Value) { "OK" } else { "FAIL"; $failed++ }
  Write-Host ($item.Key + ": " + $status)
}

if ($failed -gt 0) { throw "Window Event Reactor Shadow checks failed." }
Write-Host "Window Event Reactor Shadow checks OK."
