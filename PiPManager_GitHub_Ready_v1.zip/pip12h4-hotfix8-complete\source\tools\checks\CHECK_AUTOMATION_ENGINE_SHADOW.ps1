$ErrorActionPreference = "Stop"
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$coordinator = Get-Content (Join-Path $root "src\PiPManager.Wpf\Services\AutomationCoordinator.cs") -Raw
$hostText = Get-Content (Join-Path $root "src\PiPManager.Wpf\Services\AppHostService.cs") -Raw
$main = Get-Content (Join-Path $root "src\PiPManager.Wpf\MainWindow.xaml.cs") -Raw

foreach ($required in @(
  "AutomationCoordinator",
  "IAutomationCoordinator",
  "AutomationSlotState",
  "AutomationSignalKind",
  "AutomationOperationProfile",
  "AutomationDecision",
  "ShadowOnly => true",
  "automation-shadow-decision",
  "1-adopt-existing-pip;2-request-extension-reopen;3-locate-video-again;4-mark-unavailable",
  "wait-for-confirmation",
  "cooldown-and-stop-loop"
)) {
  if (!$coordinator.Contains($required)) {
    throw "Automation coordinator marker missing: $required"
  }
}

foreach ($required in @(
  "AddSingleton<AutomationCoordinator>",
  "AddSingleton<IAutomationCoordinator>"
)) {
  if (!$hostText.Contains($required)) {
    throw "Automation coordinator Host registration missing: $required"
  }
}

foreach ($required in @(
  "IAutomationCoordinator automationCoordinator",
  "_automationCoordinator.ObserveWindowEvent",
  "_automationCoordinator.ObserveExtensionPipEvent",
  "_automationCoordinator.ObserveVideoTabsUpdated",
  "_automationCoordinator.ObserveLegacyCaptured",
  "_automationCoordinator.ObserveLegacyLoss",
  "_automationCoordinator.ObserveLegacyReconnectStarted",
  "_automationCoordinator.ObserveLegacyReconnectSucceeded(slot.Number, hwnd, source)",
  "_automationCoordinator.ObserveLegacyReconnectFailed(slot.Number, reason, source)"
)) {
  if (!$main.Contains($required)) {
    throw "Automation coordinator MainWindow hook missing: $required"
  }
}

Write-Host "Automation Engine Shadow checks OK."
