# Hotfix 11 — AutoReturn preserve-state synchronization

This patch closes the telemetry/state divergence where AutoReturn had already captured and confirmed a new PiP HWND, but the navigation `pip-preserve` state remained alive until its TTL and emitted `preserve-expired-fallback-owned-by-auto-return-new-hwnd-unclassified`.

## Runtime change

- On confirmed focusless AutoReturn and confirmed silent reopen, the application validates that the captured HWND belongs to the expected slot and tab.
- The AutoReturn-owned preservation state is removed immediately.
- Completion is logged as `pip-preserve-result: result=auto-return-confirmed`.
- The terminal state records `completionReason=auto-return-confirmed`, `expireReason=auto-return-confirmed`, and `timerCancelled=True`.

## Preserved scope

The extension remains `1.4.39.25-command-target-root-guard-hotfix10`. Range preload, CommandTarget, playlist root guards, Focus Fix behavior, geometry authority, layout, Core and Native are unchanged.
