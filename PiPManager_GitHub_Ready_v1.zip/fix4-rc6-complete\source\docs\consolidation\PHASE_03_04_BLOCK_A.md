# Consolidação — Bloco A: fases 3 e 4

O Bloco A torna o gate reproduzível em CI e registra as fronteiras arquiteturais antes das extrações. Não altera comportamento do aplicativo, extensão ou DLL nativa.

## Fase 3 — automação e estratégia de testes

- `RUN_CI.ps1` é a entrada única e não interativa para restore, gate e build Release.
- `.github/workflows/ci.yml` executa a mesma entrada em `windows-latest`.
- `RUN_CORE_TESTS.bat --ci` continua sendo a autoridade da regressão local.
- `test-migration.json` diferencia testes comportamentais, checks estruturais e validações manuais.
- Todo novo `CHECK_*.ps1` precisa estar conectado ao gate.

## Fase 4 — mapa de responsabilidades

O arquivo `architecture-map.json` registra os donos atuais e os destinos planejados:

- WPF: composição e apresentação.
- Core: regras determinísticas, estados e decisões sem dependência de WPF/Win32.
- Windows Infrastructure: HWND, monitores, eventos e layout nativo.
- Extension Bridge: protocolo e transporte entre aplicativo e extensão.
- WebExtension: descoberta de mídia e adaptadores por site.
- Native Layout: implementação C ABI opcional e mensurável.

## Regras para o Bloco B

- `MainWindow` pode coordenar a UI, mas regras extraídas não retornam para o code-behind.
- Core não pode referenciar WPF, Win32, WebView2 ou tipos da extensão.
- Adaptadores de site não entram no Core genérico.
- Transporte não decide política de AutoRetorno.
- DLL nativa permanece opcional, com fallback gerenciado.
- Cada extração deve passar pelo mesmo `RUN_CI.ps1`.

## Dívida funcional preservada

O AutoRetorno do perfil de controles do player ainda pode falhar quando `requestPictureInPicture()` não está disponível e nenhum botão PiP é localizado. A correção continua reservada à fase funcional.

