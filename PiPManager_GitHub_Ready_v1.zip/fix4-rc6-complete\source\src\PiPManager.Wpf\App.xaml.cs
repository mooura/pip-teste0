﻿using System.Threading;
using System.Windows;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using PiPManager.Wpf.Services;

namespace PiPManager.Wpf;

public partial class App : Application
{
    private Mutex? _singleInstanceMutex;
    private bool _ownsSingleInstanceMutex;
    private IHost? _host;

    public static IServiceProvider Services
    {
        get
        {
            if (Current is not App app || app._host is null)
                throw new InvalidOperationException("Application host is not initialized.");

            return app._host.Services;
        }
    }

    protected override void OnStartup(StartupEventArgs e)
    {
        _singleInstanceMutex = new Mutex(true, "Local\\PiPManager.Wpf.SingleInstance", out var createdNew);
        _ownsSingleInstanceMutex = createdNew;
        if (!createdNew)
        {
            MessageBox.Show("O PiP Manager já está aberto.", "PiP Manager",
                MessageBoxButton.OK, MessageBoxImage.Information);
            Shutdown();
            return;
        }

        _host = AppHostService.Build();

        var logMaintenance = _host.Services.GetRequiredService<ILogMaintenanceService>();
        logMaintenance.RotateOperationalLogIfNeeded();
        logMaintenance.LogStartupBanner();

        AppLogger.Info("Aplicativo iniciado");
        DispatcherUnhandledException += (_, args) =>
        {
            AppLogger.Error("Erro não tratado na interface", args.Exception);
            try
            {
                _host?.Services.GetService<IApplicationHealthService>()?.ReportOperationalError(args.Exception.Message);
            }
            catch
            {
                // Health reporting must not mask the original UI exception.
            }

            MessageBox.Show("Ocorreu um erro. Consulte o arquivo de log.", "PiP Manager",
                MessageBoxButton.OK, MessageBoxImage.Error);
            args.Handled = true;
        };

        base.OnStartup(e);

        var mainWindow = ActivatorUtilities.CreateInstance<MainWindow>(_host.Services);
        MainWindow = mainWindow;
        mainWindow.Show();

        _host.Start();
    }

    protected override void OnExit(ExitEventArgs e)
    {
        AppLogger.Info("Aplicativo encerrado");

        if (_host is not null)
        {
            try
            {
                _host.StopAsync(TimeSpan.FromSeconds(2)).GetAwaiter().GetResult();
            }
            catch
            {
                // Shutdown must remain best-effort.
            }

            _host.Dispose();
        }

        AppLogger.FlushAndStop(TimeSpan.FromSeconds(3));

        if (_ownsSingleInstanceMutex)
            _singleInstanceMutex?.ReleaseMutex();
        _singleInstanceMutex?.Dispose();
        base.OnExit(e);
    }
}
