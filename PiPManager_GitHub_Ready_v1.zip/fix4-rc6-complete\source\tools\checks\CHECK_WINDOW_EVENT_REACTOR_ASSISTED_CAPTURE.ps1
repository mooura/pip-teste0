$ErrorActionPreference = "Stop"
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$discovery = Get-Content (Join-Path $root "src\PiPManager.Wpf\Services\WindowDiscoveryService.cs") -Raw
$reactor = Get-Content (Join-Path $root "src\PiPManager.Wpf\Services\WindowEventReactorService.cs") -Raw
$main = Get-Content (Join-Path $root "src\PiPManager.Wpf\MainWindow.xaml.cs") -Raw
$gate = Get-Content (Join-Path $root "RUN_CORE_TESTS.bat") -Raw

$checks = [ordered]@{
  "direct HWND validator" = $discovery.Contains("TryGetPipWindow(IntPtr hWnd")
  "EnumWindows callback does not shadow discard" = $discovery.Contains("Win32.EnumWindows((hWnd, enumState) =>") -and (-not $discovery.Contains("Win32.EnumWindows((hWnd, _) =>"))
  "direct validator has rejection reasons" = $discovery.Contains('rejectionReason = "cloaked"') -and $discovery.Contains('score-below-threshold')
  "reactor candidate contract" = $reactor.Contains("WindowEventReactorPipCandidate") -and $reactor.Contains("AssistedPipCandidateReady")
  "Created and Shown only" = $reactor.Contains("WindowMonitorEventKind.Created or WindowMonitorEventKind.Shown")
  "direct HWND retries" = $reactor.Contains("CandidateValidationMaxAttempts = 8") -and $reactor.Contains("CandidateValidationRetryMs = 80")
  "resolution deduplication" = $reactor.Contains("_candidateResolutionInFlight") -and $reactor.Contains("resolution-already-in-flight")
  "reactor uses direct validator" = $reactor.Contains("_discovery.TryGetPipWindow(ev.Hwnd")
  "main subscribes and unsubscribes" = $main.Contains("AssistedPipCandidateReady += OnWindowEventReactorAssistedPipCandidateReady") -and $main.Contains("AssistedPipCandidateReady -= OnWindowEventReactorAssistedPipCandidateReady")
  "prepared AwaitingPip guard" = $main.Contains("targetSlot.State != PipSlotState.AwaitingPip")
  "existing handle protection" = $main.Contains("_armedPipExistingHandles.Contains(candidate.Window.Handle)")
  "slot ownership is attempt-aware" = $main.Contains("already-owned-unclaimed") -and $main.Contains("auto-return-hwnd-owner-mismatch") -and $main.Contains("claimedByCurrentAttempt")
  "final direct validation" = $main.Contains("final-direct-validation-failed") -and $main.Contains("_discovery.TryGetPipWindow(candidate.Window.Handle")
  "prepared capture delivery" = $main.Contains("CapturePreparedPipWindow(currentWindow, tab, confirmedEvent, targetSlotNumber)")
  "legacy timer fallback retained" = [regex]::IsMatch($main, '_armedPipPairTimer\s*=\s*new\s+DispatcherTimer(?:\s*\([^)]*\))?\s*\{\s*Interval\s*=\s*TimeSpan\.FromMilliseconds\(250\)\s*\}') -and $main.Contains("_armedPipPairTimer.Tick += async (_, _) => await ArmedPipPairTickAsync()") -and $main.Contains("_armedPipPairTimer.Start()") -and $main.Contains("fallback=armed-pair-timer")
  "generation cancellation" = $main.Contains("_reactorAssistedCandidateGeneration") -and $main.Contains("unchecked { _reactorAssistedCandidateGeneration++; }")
  "pre-arm race grace" = $main.Contains("ReactorAssistedPreArmGraceMs = 900") -and $main.Contains("window-event-reactor-assisted-pre-arm-wait")
  "pre-arm wait deduplication" = $main.Contains("_reactorAssistedPreArmWaitHandles") -and $main.Contains("pre-arm-wait-already-running")
  "attempt start correlation" = $main.Contains("_openPipAttemptStartedUtc = now") -and $main.Contains("attemptCorrelated")
  "pre-arm snapshot bypass is correlated" = $main.Contains("_armedPipExistingHandles.Contains(candidate.Window.Handle) && !preArmCorrelated") -and $main.Contains("assisted-pre-arm-snapshot-bypass")
  "adaptive confirmation windows" = $main.Contains("ReactorAssistedConfirmationWaitMs = 350") -and $main.Contains("ReactorPrimaryShortConfirmationWaitMs = 125") -and $main.Contains('mode=immediate; reason=exact-attempt-direct-hwnd-match; waitMs=0') -and $main.Contains('TryCapturePreparedPipWindowFromReactor(candidate, tab, null, targetSlotNumber, "adaptive-immediate-exact-attempt-match")') -and $main.Contains("ReactorAssistedConfirmationPollMs = 25") -and $main.Contains("Task.Delay(ReactorAssistedConfirmationPollMs)")
  "legacy 1500 ms fallback unchanged" = $main.Contains("TotalMilliseconds < 1500")
  "stale legacy callback authority guard" = $main.Contains("prepared-state-no-longer-current") -and $main.Contains("_armedPipPairTab is null")
  "confirmed slot cancels legacy fallback" = $main.Contains("target-slot-already-confirmed") -and $main.Contains("CancelLegacyArmedPipFallbackAfterConfirmedCapture")
  "owned HWND cancels legacy fallback" = $main.Contains("reason=hwnd-already-owned")
  "checker included in core gate" = $gate.Contains("CHECK_WINDOW_EVENT_REACTOR_ASSISTED_CAPTURE.ps1")
}

$failed = 0
foreach ($item in $checks.GetEnumerator()) {
  $status = if ($item.Value) { "OK" } else { "FAIL"; $failed++ }
  Write-Host ($item.Key + ": " + $status)
}

if ($failed -gt 0) { throw "Window Event Reactor assisted capture checks failed." }
Write-Host "Window Event Reactor assisted capture checks OK."
