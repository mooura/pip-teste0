using System.Windows;
using System.Windows.Input;
using System.Windows.Media.Imaging;

namespace PiPManager.Wpf;

public partial class NextVideoPreviewWindow : Window
{
    private string _lastPreviewKey = string.Empty;
    private Uri? _currentMediaUri;

    public event Action? NextRequested;
    public event Action<string>? MediaStateChanged;

    public NextVideoPreviewWindow()
    {
        InitializeComponent();
        IsVisibleChanged += (_, _) =>
        {
            try
            {
                if (IsVisible && _currentMediaUri is not null) PreviewMedia.Play();
                else PreviewMedia.Pause();
            }
            catch { }
        };
        Closed += (_, _) =>
        {
            try { PreviewMedia.Stop(); }
            catch { }
        };
    }

    public void UpdatePreview(string title, string thumbnailUrl, string videoUrl, string duration, int nextIndex)
    {
        var previewKey = $"{nextIndex}|{videoUrl}|{thumbnailUrl}|{title}|{duration}";
        if (string.Equals(_lastPreviewKey, previewKey, StringComparison.Ordinal)) return;
        _lastPreviewKey = previewKey;

        PreviewPositionText.Text = nextIndex >= 0 ? $"#{nextIndex + 1} • A SEGUIR" : "A SEGUIR";
        PreviewTitleText.Text = string.IsNullOrWhiteSpace(title) ? "Próximo vídeo" : title.Trim();
        PreviewDurationText.Text = duration ?? string.Empty;
        SetThumbnail(thumbnailUrl);

        try { PreviewMedia.Stop(); }
        catch { }
        PreviewMedia.Visibility = Visibility.Collapsed;
        _currentMediaUri = TryHttpsUri(videoUrl);

        if (_currentMediaUri is null)
        {
            PreviewMedia.Source = null;
            MediaStateChanged?.Invoke("media-no-source-native");
            return;
        }

        PreviewMedia.Source = _currentMediaUri;
        PreviewMedia.Position = TimeSpan.Zero;
        PreviewMedia.Volume = 0;
        PreviewMedia.IsMuted = true;
        PreviewMedia.Play();
        MediaStateChanged?.Invoke("media-loading-native");
    }

    private void SetThumbnail(string thumbnailUrl)
    {
        var uri = TryHttpsUri(thumbnailUrl);
        if (uri is null)
        {
            PreviewImage.Source = null;
            return;
        }

        try
        {
            var bitmap = new BitmapImage();
            bitmap.BeginInit();
            bitmap.CacheOption = BitmapCacheOption.OnLoad;
            bitmap.UriSource = uri;
            bitmap.EndInit();
            bitmap.Freeze();
            PreviewImage.Source = bitmap;
        }
        catch
        {
            PreviewImage.Source = null;
        }
    }

    private static Uri? TryHttpsUri(string value) =>
        Uri.TryCreate(value, UriKind.Absolute, out var uri) && uri.Scheme == Uri.UriSchemeHttps ? uri : null;

    private void PreviewMedia_MediaOpened(object sender, RoutedEventArgs e)
    {
        PreviewMedia.Visibility = Visibility.Visible;
        PreviewMedia.IsMuted = true;
        PreviewMedia.Play();
        MediaStateChanged?.Invoke("media-playing-native");
    }

    private void PreviewMedia_MediaEnded(object sender, RoutedEventArgs e)
    {
        PreviewMedia.Position = TimeSpan.Zero;
        PreviewMedia.Play();
        MediaStateChanged?.Invoke("media-loop-native");
    }

    private void PreviewMedia_MediaFailed(object sender, ExceptionRoutedEventArgs e)
    {
        PreviewMedia.Visibility = Visibility.Collapsed;
        var reason = (e.ErrorException?.GetType().Name ?? "unknown").Replace(';', '_');
        MediaStateChanged?.Invoke($"media-error-native-{reason}");
    }

    private void PreviewSurface_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
    {
        NextRequested?.Invoke();
    }
}
