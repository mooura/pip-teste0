$ErrorActionPreference = "Stop"
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$servicePath = Join-Path $root "src\PiPManager.Wpf\Services\ShadowParityReportService.cs"
$service = Get-Content $servicePath -Raw

foreach ($required in @(
  "ensure-started-before",
  "ReconnectStarted",
  "fora de",
  "return false;",
  "IsPotentialDivergenceForTest"
)) {
  if (!$service.Contains($required)) {
    throw "Parity classification missing required marker: $required"
  }
}

Write-Host "Shadow parity classification checks OK."
