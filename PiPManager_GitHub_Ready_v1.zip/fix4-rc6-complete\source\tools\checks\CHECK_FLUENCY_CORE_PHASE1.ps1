$ErrorActionPreference = "Stop"
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$logger = Get-Content -Raw (Join-Path $root "src\PiPManager.Wpf\Services\AppLogger.cs")
$flow = Get-Content -Raw (Join-Path $root "src\PiPManager.Wpf\Services\WindowEventFlowControlService.cs")
$monitor = Get-Content -Raw (Join-Path $root "src\PiPManager.Wpf\Services\WindowsEventMonitorService.cs")
$reactor = Get-Content -Raw (Join-Path $root "src\PiPManager.Wpf\Services\WindowEventReactorService.cs")
$main = Get-Content -Raw (Join-Path $root "src\PiPManager.Wpf\MainWindow.xaml.cs")
$layout = Get-Content -Raw (Join-Path $root "src\PiPManager.Wpf\MainWindow.Layout.cs")
$video = Get-Content -Raw (Join-Path $root "src\PiPManager.Wpf\Services\VideoCommandService.cs")
$content = Get-Content -Raw (Join-Path $root "src\PiPManager.Extension\content.js")
$app = Get-Content -Raw (Join-Path $root "src\PiPManager.Wpf\App.xaml.cs")
$appHost = Get-Content -Raw (Join-Path $root "src\PiPManager.Wpf\Services\AppHostService.cs")

$checks = [ordered]@{
  "async bounded logger queue" = $logger.Contains("Channel<LogEntry>") -and $logger.Contains("WriterLoopAsync") -and $logger.Contains("BatchSize = 128")
  "UI logger no direct append" = $logger.Contains("Queue.Writer.TryWrite(entry)") -and $logger.Contains("private static void WriteBatch")
  "logger flushes on shutdown" = $app.Contains("AppLogger.FlushAndStop")
  "shared movement flow control registered" = $appHost.Contains("IWindowEventFlowControlService") -and $flow.Contains("ArmInternalMovementSuppression")
  "internal movement dropped before reactor" = $monitor.Contains("_flowControl.ShouldSuppressMovement") -and $monitor.Contains("kind == WindowMonitorEventKind.MovedOrResized")
  "layout arms late Firefox suppression" = $layout.Contains("movementSuppressionMs = resizeToTargets ? 3200 : 1800") -and $layout.Contains("layout-movement-suppression-summary")
  "external movement bypasses shadow" = $main.Contains("Movement is geometry telemetry") -and $main.Contains("if (ev.Kind == WindowMonitorEventKind.MovedOrResized)")
  "health auxiliary work throttled" = $main.Contains("HealthDragTargetsRefreshMs = 5000") -and $main.Contains("EnsureVisiblePipsTopMost();")
  "shadow heartbeat reduced" = $main.Contains("AutomationVideoTabsSnapshotThrottleMs = 15000")
  "polling diagnostics throttled" = $monitor.Contains("PollingLogThrottleMs = 15000") -and $monitor.Contains("suppressedSinceLast")
  "reactor movement batches aggregated" = $reactor.Contains("movementBatchesAggregated") -and $reactor.Contains("MovementBatchLogThrottleMs = 3000")
  "terminal handoff is signal driven" = $main.Contains("WaitForPipOperationAvailabilityAsync") -and $main.Contains("pip-operation-availability-signaled")
  "confirmed AutoReturn outranks stale state" = $main.Contains("capturedHandle != IntPtr.Zero ||") -and $main.Contains("capturedHandle == IntPtr.Zero &&")
  "SendInput incompatibility cached" = $video.Contains("_pipShortcutSendInputUnsupported") -and $video.Contains("Volatile.Read(ref _pipShortcutSendInputUnsupported)") -and $video.Contains("Volatile.Write(ref _pipShortcutSendInputUnsupported, 1)") -and $video.Contains("fallback físico rápido enviado por cache de compatibilidade")
  "auxiliary iframe initialization blocked" = $content.Contains("PIP_MANAGER_AUXILIARY_CONTEXT") -and $content.Contains("if (!PIP_MANAGER_AUXILIARY_CONTEXT)")
}

$failed = @()
foreach ($item in $checks.GetEnumerator()) {
  if ($item.Value) { Write-Host ($item.Key + ": OK") }
  else { Write-Host ($item.Key + ": FAIL"); $failed += $item.Key }
}

if ($failed.Count -gt 0) {
  throw "Fluency Core Phase 1 checks failed: $($failed -join ', ')"
}

Write-Host "Fluency Core Phase 1 checks OK."
