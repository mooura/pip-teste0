﻿using System;

namespace PiPManager.Core.Slots;

/// <summary>
/// Valida invariantes de SlotSnapshot antes de importar estado legado/sombra.
/// A máquina de estados protege transições; este validador protege entradas externas.
/// </summary>
public static class SlotSnapshotValidator
{
    public static bool IsValidHwnd(IntPtr? hwnd)
        => hwnd.HasValue && hwnd.Value != IntPtr.Zero;

    public static void ValidateForImport(SlotSnapshot snapshot)
    {
        if (snapshot.SlotNumber <= 0)
            throw new InvalidOperationException("Snapshot inválido: SlotNumber deve ser maior que zero.");

        switch (snapshot.State)
        {
            case SlotState.Empty:
                if (IsValidHwnd(snapshot.PipHwnd))
                    throw new InvalidOperationException("Snapshot inválido: Empty não pode possuir PipHwnd.");
                break;

            case SlotState.Prepared:
                break;

            case SlotState.Opening:
                RequireAttempt(snapshot, "Opening");
                break;

            case SlotState.Active:
                if (!IsValidHwnd(snapshot.PipHwnd))
                    throw new InvalidOperationException("Snapshot inválido: Active exige PipHwnd válido.");
                break;

            case SlotState.WaitingForReconnect:
                RequireAttempt(snapshot, "WaitingForReconnect");
                break;

            case SlotState.Reconnecting:
                RequireAttempt(snapshot, "Reconnecting");
                break;

            case SlotState.Failed:
                break;

            default:
                throw new InvalidOperationException($"Snapshot inválido: estado desconhecido {snapshot.State}.");
        }

        if (snapshot.IsHidden && snapshot.State != SlotState.Active)
            throw new InvalidOperationException("Snapshot inválido: IsHidden só é permitido com estado Active.");
    }

    private static void RequireAttempt(SlotSnapshot snapshot, string stateName)
    {
        if (string.IsNullOrWhiteSpace(snapshot.AttemptId))
            throw new InvalidOperationException($"Snapshot inválido: {stateName} exige AttemptId.");
    }
}
