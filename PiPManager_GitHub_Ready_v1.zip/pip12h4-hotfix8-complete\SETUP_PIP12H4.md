# PiPManager PIP12H4 + Hotfix 8 - Setup & Build Guide

## Overview

This guide covers building, testing, and deploying the **PIP12H4 + Hotfix 8** development version of PiPManager.

**Branch**: `pip12h4-hotfix8`  
**Application Version**: 9.39.03  
**Extension Version**: 1.4.39.25  
**Status**: Development/Testing (with 8 hotfixes)

## System Requirements

### Minimum
- **OS**: Windows 10 (build 1909) or Windows 11
- **.NET Runtime**: 8.0 or later (Desktop Runtime required)
- **RAM**: 2GB minimum
- **Disk Space**: 500MB for build artifacts

### Development
- **Visual Studio**: 2022 (Community, Professional, or Enterprise)
- **.NET SDK**: 8.0 or later
- **PowerShell**: 5.0 or later
- **Git**: Latest version
- **Firefox**: 90+ (for extension testing)

## Installation

### 1. Clone the Repository

```bash
git clone https://github.com/pip-teste/PiPManager.git
cd PiPManager
git checkout pip12h4-hotfix8
```

### 2. Verify .NET Installation

```powershell
dotnet --version
# Should output 8.x.x or higher
```

### 3. Install Dependencies

The build script will automatically restore NuGet packages. For manual installation:

```powershell
dotnet restore
```

## Building the Application

### Quick Build (Release)

```powershell
cd "PIP_FIX7_HOTFIX11_v1.4.39.25_AUTORETURN_PRESERVE_STATE_SYNC_INTEGRATED"

# Method 1: Using BUILD script
.\BUILD_WINDOWS.bat

# Method 2: Using PowerShell
dotnet build -c Release
```

### Build Output

- **Release Build**: `bin\Release\`
- **Debug Build**: `bin\Debug\`
- **Artifacts**: Executable and supporting DLLs

### Build Options

```powershell
# Debug build with diagnostics
dotnet build -c Debug -v diagnostic

# Release build with specific runtime
dotnet build -c Release -r win-x64

# Clean and rebuild
dotnet clean
dotnet build -c Release
```

## Testing

### Unit Tests

```powershell
# Run all tests
dotnet test

# Run specific test project
dotnet test YourTestProject.csproj

# Run with detailed output
dotnet test -v normal

# Run specific test category
dotnet test --filter "Category=AutoReturn"
```

### Manual Testing Checklist

1. **Application Launch**
   - [ ] Application starts without errors
   - [ ] UI loads correctly
   - [ ] Settings are accessible
   - [ ] Logging is functional

2. **AutoReturn Features**
   - [ ] AutoReturn activates correctly
   - [ ] Geometry authority works
   - [ ] State preservation functions
   - [ ] Sync handling is stable

3. **Advanced PiP Restoration**
   - [ ] Launch PiP window
   - [ ] Close and restart application
   - [ ] Verify PiP window is restored
   - [ ] Check geometry preservation

4. **Multi-Slot Layout**
   - [ ] Switch between layout modes
   - [ ] Verify no crashes
   - [ ] Check window positioning
   - [ ] Test slot occupancy tracking

5. **Playlist Navigation**
   - [ ] Navigate playlists
   - [ ] Verify video detection
   - [ ] Check state synchronization
   - [ ] Test AutoReturn on playlist switch

6. **Tab Occupancy Tracking**
   - [ ] Open multiple tabs with videos
   - [ ] Verify real-time tracking
   - [ ] Test occupancy notifications
   - [ ] Check accuracy

7. **Video Platform Support**
   - [ ] Test YouTube videos
   - [ ] Test Vimeo videos
   - [ ] Test Dailymotion videos
   - [ ] Test Twitch streams
   - [ ] Test custom players

8. **Firefox Extension**
   - [ ] Install extension (see below)
   - [ ] Verify communication with app
   - [ ] Test content script injection
   - [ ] Verify PiP launches from browser
   - [ ] Test extension reliability

### Advanced Testing

#### Hotfix Testing

```powershell
# Test each hotfix scenario
# Hotfix 1: AutoReturn edge cases
# Hotfix 2: Tab switch preservation
# Hotfix 3: Geometry conflicts
# Hotfix 4: Memory management
# Hotfix 5: Race conditions
# Hotfix 6: Playlist timeouts
# Hotfix 7: Positioning precision
# Hotfix 8: Extension stability

dotnet test --filter "Category=Hotfix"
```

#### Performance Testing

```powershell
# Profile AutoReturn performance
dotnet build -c Release -r win-x64

# Monitor resource usage
Get-Process PiPManager | Format-Table Name, @{Name="Memory"; Expression={"{0:N0} MB" -f ($_.WorkingSet/1MB)}}

# Measure response times
Measure-Command { .\bin\Release\PiPManager.exe }
```

#### Stress Testing

```powershell
# Test with multiple tabs/windows
# Monitor for memory leaks
# Check for state corruption
# Verify sync stability
```

### Debug Testing

```powershell
# Run with DEBUG build
dotnet build -c Debug

# Debug with Visual Studio
# Set breakpoints in AutoReturn logic
# Monitor state changes
# Check geometry calculations
```

## Firefox Extension

### Installation (Development)

1. **Open Firefox**
   ```
   Type in address bar: about:debugging#/runtime/this-firefox
   ```

2. **Load Extension**
   - Click "Load Temporary Add-on"
   - Navigate to `Extension/manifest.json`
   - Select the file

3. **Verify Installation**
   - Extension appears in Firefox menu
   - Communication with app works
   - Content scripts inject correctly
   - Advanced features active

### Installation (Testing)

For testing with specific Firefox profiles:

```powershell
# Create test profile
$firefoxPath = "C:\Program Files\Mozilla Firefox\firefox.exe"
& $firefoxPath -CreateProfile "pipmgr-test"

# Load extension in test profile
& $firefoxPath -P "pipmgr-test"
```

### Testing Extension Features

```powershell
# Test extension with various video sites
# Check console for messages
# Verify content script functionality
# Monitor extension performance
```

## Packaging for Distribution

### Create Release Build

```powershell
.\BUILD_RELEASE.bat
```

Output includes:
- Application executable
- Runtime dependencies
- Extension package (.xpi)
- Documentation files
- Release notes

### Distribution Package Contents

```
PiPManager_PIP12H4_Hotfix8_Release/
├── PiPManager.exe
├── Dependencies/
│   └── [Required DLLs]
├── Extension/
│   └── PiPManager_1.4.39.25.xpi
├── Documentation/
│   ├── README.md
│   ├── SETUP.md
│   ├── CHANGELOG_HOTFIXES.md
│   └── ADVANCED_FEATURES.md
├── LICENSE
└── VERSION.txt
```

## Configuration

### Application Settings

Settings are stored in:
- **Windows**: `%APPDATA%\PiPManager\settings.json`

### Advanced Configuration

```json
{
  "version": "1.4.39.25",
  "autoRestore": true,
  "autoReturnAdvanced": true,
  "multiSlot": true,
  "tabOccupancy": true,
  "geometryAuthority": "universal",
  "stateSyncIntegrated": true,
  "playlistNavigation": "advanced",
  "debug": false,
  "logging": {
    "enabled": true,
    "level": "info",
    "file": "pipmgr.log"
  }
}
```

### Feature Flags

Enable/disable experimental features:

```json
{
  "features": {
    "advancedAutoReturn": true,
    "universalGeometry": true,
    "integratedSync": true,
    "advancedPlaylist": true,
    "hotfix8": true
  }
}
```

## Troubleshooting

### Build Issues

```powershell
# Check for dependency issues
dotnet restore --no-cache

# Verify project structure
Get-ChildItem -Recurse -Include "*.csproj"

# Clean and rebuild
dotnet clean
dotnet build -c Release -v diagnostic
```

### AutoReturn Not Working

1. Check if geometry authority is set to "universal"
2. Verify state sync is integrated
3. Test with single video first
4. Check application logs
5. Review hotfix 1 and 3 implementations

### State Preservation Issues

1. Check sync handler status
2. Verify integrated sync is enabled
3. Test state export/import
4. Review hotfix 2 implementation
5. Monitor for race conditions

### Performance Issues

1. Monitor memory usage (hotfix 4)
2. Check for race conditions (hotfix 5)
3. Review playlist navigation (hotfix 6)
4. Profile with Visual Studio
5. Check extension communication (hotfix 8)

### Extension Communication

1. Verify extension is loaded
2. Check browser console for errors
3. Monitor app logs for messages
4. Review content script injection
5. Test with debug builds

## Deployment

### Local Deployment

```powershell
# Copy release build to program folder
$source = ".\bin\Release\*"
$dest = "C:\Program Files\PiPManager\"
Copy-Item $source $dest -Recurse -Force

# Initialize settings with advanced config
Copy-Item "settings.json" "$env:APPDATA\PiPManager\" -Force
```

### Environment Variables

```powershell
# Set debug logging
$env:PIPMGR_DEBUG = "true"

# Set log level
$env:PIPMGR_LOG_LEVEL = "debug"

# Run application
.\PiPManager.exe
```

### Uninstallation

```powershell
# Remove program folder
Remove-Item "C:\Program Files\PiPManager\" -Recurse

# Remove settings (optional)
Remove-Item "$env:APPDATA\PiPManager\" -Recurse

# Disable extension in Firefox
# Manual: about:debugging → Disable PiPManager
```

## Advanced Topics

### Building for Multiple Runtimes

```powershell
# 64-bit Windows (recommended)
dotnet publish -c Release -r win-x64

# 32-bit Windows
dotnet publish -c Release -r win-x86

# Portable build
dotnet publish -c Release --self-contained -r win-x64
```

### Custom Build Configuration

Edit `.csproj` files to modify:
- Feature flags
- AutoReturn behavior
- Geometry authority settings
- Logging configuration

### Performance Profiling

```powershell
# Run with performance monitoring
dotnet build -c Release
# Use Visual Studio Profiler on built executable
```

### Debugging Advanced Features

1. Open solution in Visual Studio 2022
2. Set breakpoints in:
   - AutoReturn logic
   - Geometry calculations
   - State sync handlers
   - Extension communication
3. Monitor state changes in Watch windows
4. Use Immediate window for runtime queries

## Hotfix Documentation

### Hotfix Summary
- **Hotfix 1**: AutoReturn edge case handling
- **Hotfix 2**: State preservation on tab switch
- **Hotfix 3**: Geometry authority conflict resolution
- **Hotfix 4**: Memory leak in sync handler
- **Hotfix 5**: Tab occupancy race conditions
- **Hotfix 6**: Playlist navigation timeout
- **Hotfix 7**: Window positioning precision
- **Hotfix 8**: Extension communication stability

### Testing Hotfixes

Each hotfix has specific test scenarios - refer to test documentation.

## Version Information

- **Application**: 9.39.03
- **Extension**: 1.4.39.25
- **Hotfixes**: 8
- **Build Date**: 2026-08-05
- **Stability**: Development/Testing

## Support & Issues

### Reporting Issues

Include:
1. Branch: pip12h4-hotfix8
2. Complete error message
3. Steps to reproduce
4. System information
5. Application version
6. Extension version
7. Affected hotfix (if known)

### Getting Help

1. Check GitHub issues
2. Review documentation
3. Check hotfix implementations
4. Create detailed issue report
5. Include debug logs

## Related Documentation

- **README.md** - Project overview
- **VERSIONS.md** - Version history and features
- **CONTRIBUTING.md** - Contribution guidelines
- **LICENSE** - License information

---

**Last Updated**: 2026-08-05  
**Branch**: pip12h4-hotfix8  
**Maintainers**: PiPManager Team  
**Status**: Development/Testing
