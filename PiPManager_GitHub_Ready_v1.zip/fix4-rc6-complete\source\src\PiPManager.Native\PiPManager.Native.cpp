#include "PiPManager.Native.h"

#ifdef _WIN32

#pragma comment(lib, "user32.lib")
#pragma comment(lib, "dwmapi.lib")

using BOOL = int;
using UINT = unsigned int;
using DWORD = unsigned long;
using LONG = long;
using HRESULT = long;
using HWND = void*;
using HDWP = void*;

struct RECT
{
    LONG left;
    LONG top;
    LONG right;
    LONG bottom;
};

extern "C" __declspec(dllimport) BOOL __stdcall IsWindow(HWND hWnd);
extern "C" __declspec(dllimport) BOOL __stdcall IsIconic(HWND hWnd);
extern "C" __declspec(dllimport) BOOL __stdcall GetWindowRect(HWND hWnd, RECT* rect);
extern "C" __declspec(dllimport) BOOL __stdcall SetWindowPos(HWND hWnd, HWND insertAfter, int x, int y, int cx, int cy, UINT flags);
extern "C" __declspec(dllimport) HDWP __stdcall BeginDeferWindowPos(int count);
extern "C" __declspec(dllimport) HDWP __stdcall DeferWindowPos(HDWP info, HWND hWnd, HWND insertAfter, int x, int y, int cx, int cy, UINT flags);
extern "C" __declspec(dllimport) BOOL __stdcall EndDeferWindowPos(HDWP info);
extern "C" __declspec(dllimport) HRESULT __stdcall DwmGetWindowAttribute(HWND hWnd, DWORD attribute, void* value, DWORD size);

static_assert(sizeof(PipNativeMove) == 24, "PipNativeMove ABI mismatch");
static_assert(sizeof(PipNativePreparedMove) == 32, "PipNativePreparedMove ABI mismatch");
static_assert(sizeof(PipNativeBatchResult) == 28, "PipNativeBatchResult ABI mismatch");

static constexpr int32_t NativeVersion = 100;
static constexpr DWORD DwmwaExtendedFrameBounds = 9;
static constexpr UINT SwpNoSize = 0x0001;
static constexpr UINT SwpNoZOrder = 0x0004;
static constexpr UINT SwpNoActivate = 0x0010;
static constexpr UINT SwpAsyncWindowPos = 0x4000;
static HWND hwnd_top_most()
{
    return reinterpret_cast<HWND>(static_cast<intptr_t>(-1));
}

static int32_t absolute_value(int32_t value)
{
    return value < 0 ? -value : value;
}

static int32_t rect_width(const RECT& rect)
{
    return static_cast<int32_t>(rect.right - rect.left);
}

static int32_t rect_height(const RECT& rect)
{
    return static_cast<int32_t>(rect.bottom - rect.top);
}

static bool valid_target(const PipNativeMove& move, bool resize)
{
    if (!resize)
        return true;

    return move.right > move.left && move.bottom > move.top;
}

static bool get_visual_rect(HWND hwnd, RECT& visual)
{
    RECT raw{};
    if (!GetWindowRect(hwnd, &raw))
        return false;

    visual = raw;
    RECT dwm{};
    if (DwmGetWindowAttribute(hwnd, DwmwaExtendedFrameBounds, &dwm, sizeof(dwm)) >= 0 &&
        dwm.right > dwm.left && dwm.bottom > dwm.top)
    {
        visual = dwm;
    }

    return true;
}

PIP_API int32_t PIP_CALL pip_native_version()
{
    return NativeVersion;
}

PIP_API int32_t PIP_CALL pip_process_window_batch(
    const PipNativeMove* moves,
    int32_t count,
    int32_t pixelThreshold,
    int32_t resizeToTarget,
    int32_t coordinateMode,
    int32_t dryRun,
    PipNativePreparedMove* preparedMoves,
    int32_t preparedCapacity,
    PipNativeBatchResult* result)
{
    if (result == nullptr)
        return 0;

    *result = {};
    result->nativeVersion = NativeVersion;

    if (moves == nullptr || preparedMoves == nullptr || count <= 0 || count > 64 || preparedCapacity < count)
    {
        result->failed = count > 0 ? count : 1;
        return 0;
    }

    const bool resize = resizeToTarget != 0;
    const bool rawCoordinates = coordinateMode == PipNativeRawCoordinates;
    const int32_t threshold = pixelThreshold < 0 ? 0 : pixelThreshold;
    result->attempted = count;

    int32_t preparedCount = 0;
    for (int32_t index = 0; index < count; ++index)
    {
        const PipNativeMove& move = moves[index];
        HWND hwnd = reinterpret_cast<HWND>(static_cast<intptr_t>(move.hwnd));

        if (hwnd == nullptr || !IsWindow(hwnd) || IsIconic(hwnd) || !valid_target(move, resize))
        {
            ++result->skipped;
            continue;
        }

        PipNativePreparedMove prepared{};
        prepared.hwnd = move.hwnd;
        prepared.status = 1;

        if (rawCoordinates)
        {
            RECT current{};
            if (!GetWindowRect(hwnd, &current))
            {
                ++result->failed;
                continue;
            }

            prepared.rawLeft = move.left;
            prepared.rawTop = move.top;
            prepared.rawWidth = resize ? (move.right - move.left) : 0;
            prepared.rawHeight = resize ? (move.bottom - move.top) : 0;
        }
        else
        {
            RECT raw{};
            RECT visual{};
            if (!GetWindowRect(hwnd, &raw) || !get_visual_rect(hwnd, visual))
            {
                ++result->failed;
                continue;
            }

            const int32_t targetWidth = move.right - move.left;
            const int32_t targetHeight = move.bottom - move.top;
            const bool positionMatches =
                absolute_value(static_cast<int32_t>(visual.left) - move.left) <= threshold &&
                absolute_value(static_cast<int32_t>(visual.top) - move.top) <= threshold;
            const bool sizeMatches = !resize ||
                (absolute_value(rect_width(visual) - targetWidth) <= threshold &&
                 absolute_value(rect_height(visual) - targetHeight) <= threshold);

            if (positionMatches && sizeMatches)
            {
                ++result->skipped;
                continue;
            }

            const int32_t offsetX = static_cast<int32_t>(raw.left - visual.left);
            const int32_t offsetY = static_cast<int32_t>(raw.top - visual.top);
            const int32_t extraWidth = rect_width(raw) > rect_width(visual) ? rect_width(raw) - rect_width(visual) : 0;
            const int32_t extraHeight = rect_height(raw) > rect_height(visual) ? rect_height(raw) - rect_height(visual) : 0;

            prepared.rawLeft = move.left + offsetX;
            prepared.rawTop = move.top + offsetY;
            prepared.rawWidth = resize ? ((targetWidth + extraWidth) < 80 ? 80 : targetWidth + extraWidth) : 0;
            prepared.rawHeight = resize ? ((targetHeight + extraHeight) < 45 ? 45 : targetHeight + extraHeight) : 0;
        }

        preparedMoves[preparedCount++] = prepared;
    }

    result->prepared = preparedCount;
    if (dryRun != 0 || preparedCount == 0)
        return result->failed == 0 ? 1 : 0;

    UINT flags = SwpNoActivate;
    HWND insertAfter = hwnd_top_most();
    if (!resize)
        flags |= SwpNoSize;

    if (rawCoordinates)
    {
        flags |= SwpNoZOrder | SwpAsyncWindowPos;
        insertAfter = nullptr;
    }

    HDWP defer = BeginDeferWindowPos(preparedCount);
    bool useFallback = defer == nullptr;

    if (!useFallback)
    {
        for (int32_t index = 0; index < preparedCount; ++index)
        {
            const PipNativePreparedMove& item = preparedMoves[index];
            HWND hwnd = reinterpret_cast<HWND>(static_cast<intptr_t>(item.hwnd));
            HDWP next = DeferWindowPos(
                defer,
                hwnd,
                insertAfter,
                item.rawLeft,
                item.rawTop,
                item.rawWidth,
                item.rawHeight,
                flags);

            if (next == nullptr)
            {
                EndDeferWindowPos(defer);
                useFallback = true;
                break;
            }

            defer = next;
        }
    }

    if (!useFallback)
    {
        if (EndDeferWindowPos(defer))
        {
            result->applied = preparedCount;
            return result->failed == 0 ? 1 : 0;
        }
        useFallback = true;
    }

    result->fallbackUsed = 1;
    result->applied = 0;
    for (int32_t index = 0; index < preparedCount; ++index)
    {
        const PipNativePreparedMove& item = preparedMoves[index];
        HWND hwnd = reinterpret_cast<HWND>(static_cast<intptr_t>(item.hwnd));
        if (SetWindowPos(hwnd, insertAfter, item.rawLeft, item.rawTop, item.rawWidth, item.rawHeight, flags))
            ++result->applied;
        else
            ++result->failed;
    }

    return result->failed == 0 ? 1 : 0;
}

#else
PIP_API int32_t PIP_CALL pip_native_version() { return 0; }
PIP_API int32_t PIP_CALL pip_process_window_batch(const PipNativeMove*, int32_t, int32_t, int32_t, int32_t, int32_t, PipNativePreparedMove*, int32_t, PipNativeBatchResult*) { return 0; }
#endif
