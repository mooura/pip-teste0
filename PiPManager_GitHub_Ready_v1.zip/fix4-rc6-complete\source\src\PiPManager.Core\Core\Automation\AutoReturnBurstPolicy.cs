namespace PiPManager.Core.Automation;

/// <summary>
/// Regras determinísticas para preservar e drenar perdas simultâneas de PiP.
/// Mantém o conhecimento da rajada fora da UI e permite regressão automatizada.
/// </summary>
public static class AutoReturnBurstPolicy
{
    private const int PendingSlotAllowanceSeconds = 10;
    private const int MaxPendingAgeSeconds = 150;
    private const int MaxLayoutRecoveryTimeoutMilliseconds = 45_000;
    private const int MaxRetryDelayMilliseconds = 2_000;

    public static bool ShouldPreserveLostSlot(
        bool autoReturnEnabled,
        bool hasPairRecoverySignal) =>
        autoReturnEnabled && hasPairRecoverySignal;

    public static int GetPendingMaxAgeSeconds(int pendingSlotCount, int baseSeconds)
    {
        var normalizedBase = Math.Max(1, baseSeconds);
        var additionalSlots = Math.Max(0, pendingSlotCount - 1);
        return Math.Min(
            MaxPendingAgeSeconds,
            normalizedBase + (additionalSlots * PendingSlotAllowanceSeconds));
    }

    public static int GetLayoutRecoveryTimeoutMilliseconds(int expectedSlotCount, int baseMilliseconds)
    {
        _ = expectedSlotCount;
        var normalizedBase = Math.Max(1_000, baseMilliseconds);
        return Math.Min(MaxLayoutRecoveryTimeoutMilliseconds, normalizedBase);
    }

    public static void RemapSlotMembershipAfterSwap(
        ISet<int> expectedSlots,
        ISet<int> recoveredSlots,
        int firstSlotNumber,
        int secondSlotNumber)
    {
        ArgumentNullException.ThrowIfNull(expectedSlots);
        ArgumentNullException.ThrowIfNull(recoveredSlots);
        if (firstSlotNumber == secondSlotNumber)
            return;

        static void SwapMembership(ISet<int> slots, int first, int second)
        {
            var hadFirst = slots.Remove(first);
            var hadSecond = slots.Remove(second);
            if (hadFirst)
                slots.Add(second);
            if (hadSecond)
                slots.Add(first);
        }

        SwapMembership(expectedSlots, firstSlotNumber, secondSlotNumber);
        SwapMembership(recoveredSlots, firstSlotNumber, secondSlotNumber);
    }

    public static int GetRetryDelayMilliseconds(int retryNumber)
    {
        var normalizedRetry = Math.Max(1, retryNumber);
        var delay = 500 * (1 << Math.Min(2, normalizedRetry - 1));
        return Math.Min(MaxRetryDelayMilliseconds, delay);
    }

    /// <summary>
    /// Identifica o intervalo em que o elemento de vídeo ainda não pode aceitar uma
    /// abertura física de PiP. HAVE_NOTHING (readyState 0), ausência de source ou
    /// estado ended aguardam estabilização; a exceção adaptativa de reprodução
    /// comprovada é avaliada separadamente por HasConfirmedActivePlayback.
    /// </summary>
    public static bool IsPlaybackHardNotReady(
        bool hasSource,
        int readyState,
        bool isEnded) =>
        !hasSource || readyState <= 0 || isEnded;

    /// <summary>
    /// Um alvo totalmente indisponível nunca deve consumir uma tentativa física.
    /// Alvos parcialmente carregados ainda usam as deferrals limitadas existentes.
    /// </summary>
    public static bool ShouldDeferPhysicalAttemptForReadiness(
        bool ready,
        bool hardNotReady,
        int readinessDeferrals,
        int maxReadinessDeferrals) =>
        !ready && (hardNotReady || readinessDeferrals < Math.Max(0, maxReadinessDeferrals));

    public static int GetReadinessRetryDelayMilliseconds(bool hardNotReady) =>
        hardNotReady ? 900 : 500;

    /// <summary>
    /// Mantém uma navegação confirmada como autoridade durante toda a vida do
    /// estado de preservação. A janela curta serve apenas para cobrir a corrida
    /// anterior à resposta da extensão; ela nunca invalida uma confirmação.
    /// </summary>
    public static bool ShouldRequireRealVideoChangeForNavigation(
        bool commandResultReceived,
        bool commandConfirmed,
        bool newVideoDetected,
        double commandAgeMilliseconds,
        int correlationMilliseconds)
    {
        if (newVideoDetected)
            return true;

        if (commandResultReceived)
            return commandConfirmed;

        return commandAgeMilliseconds >= 0
            && commandAgeMilliseconds <= Math.Max(0, correlationMilliseconds);
    }

    /// <summary>
    /// Alguns players mantêm readyState=0 mesmo durante reprodução válida.
    /// Duas amostras novas e consecutivas com source + playing constituem uma
    /// prova adaptativa limitada, sem liberar fonte ausente ou vídeo encerrado.
    /// </summary>
    public static bool HasConfirmedActivePlayback(
        bool hasSource,
        bool isPlaying,
        bool isEnded,
        int consecutiveFreshSamples,
        int requiredFreshSamples) =>
        hasSource
        && isPlaying
        && !isEnded
        && consecutiveFreshSamples >= Math.Max(2, requiredFreshSamples);

    public static bool ShouldAllowPlaylistSameVideoFallback(
        bool requiresRealVideoChange,
        bool playlistDetected,
        double pendingElapsedMilliseconds,
        int graceMilliseconds,
        bool navigationCommandResultReceived,
        bool navigationCommandConfirmed) =>
        requiresRealVideoChange
        && playlistDetected
        && navigationCommandResultReceived
        && !navigationCommandConfirmed
        && pendingElapsedMilliseconds >= Math.Max(250, graceMilliseconds);
}
