$ErrorActionPreference = 'Stop'
$root = Resolve-Path (Join-Path $PSScriptRoot '..\..')
$main = Get-Content (Join-Path $root 'src\PiPManager.Wpf\MainWindow.xaml.cs') -Raw
$content = Get-Content (Join-Path $root 'src\PiPManager.Extension\content.js') -Raw
$manifest = Get-Content (Join-Path $root 'src\PiPManager.Extension\manifest.json') -Raw
$release = Get-Content (Join-Path $root 'src\PiPManager.Wpf\Services\ReleaseInfoService.cs') -Raw
$checks = [ordered]@{
  'manifest is 1.4.39.25' = $manifest.Contains('"version": "1.4.39.25"')
  'release metadata is 1.4.39.25' = $release.Contains('ExtensionVersion = "1.4.39.25"')
  'next cancels open all' = $main.Contains('open-all-cancel-requested-by-next') -and $main.Contains('open-all-yielded-to-next-navigation')
  'open all defers to active next' = $main.Contains('open-all-deferred-by-next-navigation')
  'minimal ready fast return exists' = $main.Contains('auto-return-command-target-minimal-ready') -and $main.Contains('AutoReturnCommandNavigationMinimalReadyGraceMs = 220')
  'preload network window is hard bounded' = $content.Contains('NEXT_VIDEO_PRELOAD_NETWORK_WINDOW_MS = 5000') -and $content.Contains("video.preload = 'none'") -and $content.Contains('network-paused-buffer-preserved')
}
$failed=@()
foreach($item in $checks.GetEnumerator()) { if($item.Value){Write-Host "$($item.Key): OK"} else {Write-Host "$($item.Key): FAIL"; $failed += $item.Key} }
if($failed.Count -gt 0){ throw ('Next Priority + Fast Return Hotfix 4 checks failed: ' + ($failed -join ', ')) }
Write-Host 'Next Priority + Fast Return Hotfix 4 checks OK.'
