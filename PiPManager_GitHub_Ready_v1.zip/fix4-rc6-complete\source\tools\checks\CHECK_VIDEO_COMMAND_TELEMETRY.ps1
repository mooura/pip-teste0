$ErrorActionPreference = "Stop"

$root = Resolve-Path (Join-Path $PSScriptRoot "..\..")
$main = Join-Path $root "src\PiPManager.Wpf\MainWindow.xaml.cs"
$bridge = Join-Path $root "src\PiPManager.Wpf\Services\ExtensionBridgeService.cs"
$background = Join-Path $root "src\PiPManager.Extension\background.js"

$mainText = Get-Content -Raw $main
$bridgeText = Get-Content -Raw $bridge
$backgroundText = Get-Content -Raw $background

$requiredMainMarkers = @(
    "video-command-requested:",
    "video-command-dispatched:",
    "video-command-confirmed:",
    "video-command-final-result:"
)

foreach ($marker in $requiredMainMarkers) {
    if (-not $mainText.Contains($marker)) {
        throw "Marcador obrigatório ausente em MainWindow.xaml.cs: $marker"
    }
}

if (-not $bridgeText.Contains("video-command-result-received:")) {
    throw "Marcador de recepção do resultado ausente no bridge"
}

if (-not $backgroundText.Contains("tabs-goBack-linked-tab-authoritative")) {
    throw "Método autoritativo de Anterior ausente no background"
}

if (-not $mainText.Contains("_videoCommandTelemetryByOperationId")) {
    throw "Contexto independente de telemetria por operationId ausente"
}

Write-Host "PASS: telemetria Próximo/Anterior contém ciclo completo e correlação por operationId."
