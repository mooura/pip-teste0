﻿$ErrorActionPreference = "Stop"
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$main = Get-Content -Raw (Join-Path $root "src\PiPManager.Wpf\MainWindow.xaml.cs")
$video = Get-Content -Raw (Join-Path $root "src\PiPManager.Wpf\Services\VideoCommandService.cs")
$run = Get-Content -Raw (Join-Path $root "RUN_CORE_TESTS.bat")
$autoReturnMethodStart = $main.IndexOf("private async Task TryAutoReturnSlotAsync(")
$autoReturnMethodEnd = if ($autoReturnMethodStart -ge 0) {
  $main.IndexOf("private int SetAutoReturnCooldown(", $autoReturnMethodStart)
} else {
  -1
}
$autoReturnMethod = if ($autoReturnMethodStart -ge 0 -and $autoReturnMethodEnd -gt $autoReturnMethodStart) {
  $main.Substring($autoReturnMethodStart, $autoReturnMethodEnd - $autoReturnMethodStart)
} else {
  ""
}
$readinessIndex = $autoReturnMethod.IndexOf("WaitForAutoReturnTargetPlaybackReadyAsync(slot, tab, state, attemptId)")
$physicalGateIndex = $autoReturnMethod.IndexOf("_autoReturnExecutionGate.WaitAsync()")
$readinessBeforePhysicalGate = $readinessIndex -ge 0 -and $physicalGateIndex -ge 0 -and $readinessIndex -lt $physicalGateIndex

$checks = [ordered]@{
  "target playback readiness gate" = $main.Contains("WaitForAutoReturnTargetPlaybackReadyAsync") -and $main.Contains("auto-return-target-ready-wait-start")
  "readiness runs before physical serialization" = $readinessBeforePhysicalGate
  "readiness uses bounded adaptive deferrals" = $main.Contains("AutoReturnMaxReadinessDeferrals = 1") -and $main.Contains("auto-return-target-ready-deferred")
  "same-video missing source cannot bypass readiness" = $main.Contains("IsAutoReturnTargetHardNotReady") -and $main.Contains("(!realChange && !hardNotReady)")
  "hard-not-ready never consumes physical attempts" = $main.Contains("ShouldDeferPhysicalAttemptForReadiness") -and $main.Contains("auto-return-readiness-cooldown-set")
  "readiness cooldown preserves physical backoff" = $main.Contains("physicalRetryBackoffPreserved") -and $main.Contains("GetReadinessRetryDelayMilliseconds")
  "retry backoff is progressive and capped" = $main.Contains("GetRetryDelayMilliseconds") -and $main.Contains("policy=500-1000-2000")
  "adaptive retry queues a fast tick" = $main.Contains("QueueAutoReturnRetryAfterCooldown") -and $main.Contains("auto-return-adaptive-retry-ready")
  "playlist URL change bypasses slow terminal probe" = $main.Contains("playlistUrlChanged") -and $main.Contains("candidateIsPlaylist") -and $main.Contains("/playlists/") -and $main.Contains("!navigationRealChange")
  "natural playlist loss uses fast debounce" = $main.Contains("window-loss-fast-playlist-advance") -and $main.Contains("_videoTabCache.Values")
  "HWND wait checks immediately" = $main.Contains("RefreshCapturedWindows();") -and $main.Contains("iteration <= 8 ? 45")
  "adaptive foreground verification" = $main.Contains("verifyWindowMs = attempt == 1 ? 260 : 420") -and $main.Contains("phase=after-extension-focus; adaptive=True")
  "verified browser foreground reused" = $video.Contains("foregroundAlreadyVerified") -and $video.Contains("canReuseVerifiedForeground")
  "fast PiP physical chord" = $video.Contains("SendPipChordWithKeybdEventFast") -and $video.Contains("fastTiming=16/32ms")
  "fast retry delay" = $main.Contains("delayMs=150")
  "checker included in core gate" = $run.Contains("CHECK_AUTORETURN_READY_FIRST_NO_RETRY.ps1")
}
$failed = @()
foreach ($item in $checks.GetEnumerator()) {
  if ($item.Value) { Write-Host ($item.Key + ": OK") }
  else { Write-Host ($item.Key + ": FAIL"); $failed += $item.Key }
}
if ($failed.Count -gt 0) { throw "AutoReturn ready-first checks failed: $($failed -join ', ')" }
Write-Host "AutoReturn ready-first no-retry checks OK."
