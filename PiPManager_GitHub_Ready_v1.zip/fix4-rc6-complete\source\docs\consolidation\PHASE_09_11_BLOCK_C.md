# Consolidação — Bloco C: fases 9 a 11

## Fase 9 — autoridade Legacy, Shadow e Reactor

- `RuntimeAuthorityPolicy` é o único parser da autoridade de captura.
- `Compare` continua sendo o modo seguro do Reactor.
- `Legacy` permanece como fallback operacional.
- `Primary` continua opt-in.
- Shadow permanece somente observador e não executa ações.

O caminho Legacy não foi removido porque a log real anterior registrou dez recuperações confirmadas usando o fallback. Removê-lo sem uma fase funcional de paridade seria regressão, não consolidação.

## Fase 10 — decisão sobre a DLL C++

O benchmark `PiPManager.LayoutBenchmarks` compara o mesmo lote de movimento e redimensionamento em dez janelas Win32 ocultas.

Resultado desta máquina, 1.000 iterações:

- C# com `BeginDeferWindowPos`: média `0,3158 ms`, p95 `0,5150 ms`.
- DLL ABI 100: média `1,5781 ms`, p95 `2,0982 ms`.
- Razão Native/C#: `4,997`.

Decisão:

- C# passa a ser o padrão para instalações novas e configurações inválidas.
- Configurações existentes continuam respeitadas.
- DLL permanece disponível temporariamente em `Compare` e `Primary` para rollback e comparação.
- A remoção física da DLL fica autorizada após uma release funcional homologada com o modo gerenciado.

## Fase 11 — limpeza

- 71 notas, release notes e validações soltas foram movidas para `HISTORY/RELEASE_ARCHIVE`.
- `_backup/MainWindow.xaml.score_patch_test.txt` foi enviado para a Lixeira.
- `CREATE_DIST_RELEASE.ps1` agora copia o arquivo histórico consolidado.
- `.gitignore` exclui `bin`, `obj`, `_backup` e logs transitórios de validação.
- Código, checks e histórico recuperável foram preservados.

## Dívidas funcionais preservadas

- Corrida perfil de playlist indexada: Voltar manual pode ser desfeito por Próximo automático após perda transitória do PiP.
- Fallback de abertura do perfil de controles do player ainda precisa de homologação ampliada.
- Essas correções continuam reservadas à fase 12.

