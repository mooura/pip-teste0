# Hotfix 7 — Universal Slot Geometry + Command Preload Handoff

Version: `1.4.39.24-range-network-cap-hotfix9`

## Preload handoff

A matching auxiliary preload is no longer cancelled when its `NextTarget` is frozen as the manual `CommandTarget`. The visual preview becomes stale, but the warmed media/cache ownership survives the generation transition until the commanded asset becomes current. Empty network-window results are published as `PRELOAD_EMPTY`, not `READY`.

## Universal geometry authority

The last confirmed user rectangle belongs to the slot rather than the old HWND. The authority is armed before Next, bound in `CapturePreparedPipWindow`, and enforced immediately plus at 150, 400, 900, 1800, 3200 and 4200 ms. A confirmed manual resize replaces the stable rectangle; an ordinary click does not disable protection.
