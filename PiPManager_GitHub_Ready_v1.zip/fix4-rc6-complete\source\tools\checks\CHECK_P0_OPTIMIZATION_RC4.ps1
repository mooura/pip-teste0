param()

$ErrorActionPreference = 'Stop'
$root = Resolve-Path (Join-Path $PSScriptRoot '..\..')
$drag = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\MainWindow.PipDrag.cs') -Raw
$monitor = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\Services\WindowsEventMonitorService.cs') -Raw
$release = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\Services\ReleaseInfoService.cs') -Raw

$checks = [ordered]@{
  'drag model filters unusable HWNDs' = $drag.Contains('GetUsableOccupiedSlotsForDrag()') -and $drag.Contains('PipWindowService.IsUsable(slot.Window.Handle)')
  'lost AutoReturn slots are aggregated' = $drag.Contains('referências perdidas preservadas fora do modelo de arraste') -and $drag.Contains('pairMetadataPreserved=True')
  'drag purge exposes debounce reservation before preserving identity' = $drag.Contains('var lossDebounceReserved =') -and $drag.Contains('AutoReturnBurstPolicy.ShouldPreserveLostSlot')
  'invalid geometry only checks usable HWNDs' = $drag.Contains('.Where(slot => PipWindowService.IsUsable(slot.Window!.Handle))')
  'health totals use 250ms coalescing' = $monitor.Contains('HealthTotalsPublishThrottleMs = 250') -and $monitor.Contains('PublishHealthTotals()')
  'test snapshot forces exact totals' = $monitor.Contains('PublishHealthTotals(force: true);')
  'release retains P0 optimizations in current app version' = $release.Contains('AppVersion = "1.5.12.3909"') -and $release.Contains('P0 Optimization RC5') -and $release.Contains('P0 Optimization RC6')
}

$failed = 0
foreach ($item in $checks.GetEnumerator()) {
  if ($item.Value) {
    Write-Host ($item.Key + ': OK')
  } else {
    Write-Host ($item.Key + ': FAIL')
    $failed++
  }
}

if ($failed -gt 0) { throw 'P0 Optimization RC4 checks failed.' }
Write-Host 'P0 Optimization RC4 checks OK.'
