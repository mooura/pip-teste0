# PiP Manager 9.39.01 — Final Stable Source

## Estado da release

Esta pasta congela a versão final aceita do projeto PiP Manager 9.39.01.
Nenhuma regra funcional foi alterada durante a finalização. A base é a mesma versão compilável que contém a correção CS0136 do atalho Espaço.

## Versões congeladas

- Produto: 9.39.01
- Aplicativo: 1.5.12.3901
- Extensão: 1.4.39.24
- .NET: 8.0 / WPF / Windows x64
- Núcleo nativo: ABI 100

## Funcionalidades consolidadas

- Captura e gerenciamento de múltiplas janelas PiP.
- Perfil Jogo com seis posições superiores e quatro posições laterais.
- Classificação por proporção real do vídeo e reflow do perfil Jogo.
- Troca manual de slots.
- Fixar conjunto e autoridade de layout persistente.
- Ajuste normal pela borda nativa do PiP.
- O último PiP redimensionado é usado como referência pelo comando Igualar.
- No perfil Jogo, Igualar afeta somente o grupo superior ou somente o grupo lateral.
- Limitação automática ao maior tamanho que cabe na área útil, sem sobreposição.
- Atalho global opcional Espaço para ocultar/mostrar, somente no perfil Jogo.
- Abrir todos com propriedade exclusiva da operação e prepared-lock.
- AutoReturn discreto, proteção contra captura indevida de HWND e recuperação de playlist.
- Pré-carregamento e AutoAdvance consolidados até a Fase 12.

## Comportamentos aceitos

- Com seis PiPs superiores em uma tela útil de 1920 px, a largura máxima por PiP é aproximadamente 320 px. Se a referência de Igualar for maior, o perfil reduz o grupo ao maior tamanho possível sem sobreposição ou saída da tela.
- O reflow pode reposicionar ou redimensionar o conjunto quando a proporção real de um vídeo muda ou quando um PiP é recriado pelo AutoReturn.
- O atalho Espaço vem desativado por padrão e deve ser ativado no menu do perfil Jogo.

## Compilação final no Windows

1. Extraia a pasta em um caminho novo.
2. Execute `BUILD_WINDOWS.bat`.
3. Confirme `ALL TESTS AND CHECKS OK`.
4. Confirme a compilação de `PiPManager.Wpf` sem erros.
5. Use `CREATE_DIST_RELEASE.ps1` somente após o build final aprovado.

## Regra de manutenção

Qualquer alteração futura deve partir desta release em uma nova pasta e receber uma nova identificação. Não substituir silenciosamente esta base final.


AUTORETURN CORRELATED SNAPSHOT / PRE-SHORTCUT GATE
- snapshot do AutoReturn agora usa requestId ponta a ponta entre WPF e background.js;
- resposta sem correlação exata expira em modo fail-safe;
- cada tentativa de Ctrl+Shift+] exige novo snapshot correlacionado imediatamente antes do envio;
- no-video/timeout não consome backoff físico;
- extensão 1.4.39.24 precisa ser recarregada porque background.js foi atualizado.

## Fixed-layout external resize echo dedup

- Preserva o primeiro ajuste natural novo do navegador e agenda um único reflow.
- Ignora repetições do mesmo HWND, slot e retângulo visual dentro de 2 px.
- Não interfere em gesto manual de redimensionamento pela borda nativa.
- Limpa a identidade de eco na remoção do HWND e na alternância do layout fixo.
- AutoReturn correlacionado, extensão 1.4.39.24, UI e pareamento permanecem inalterados.

## PIP FIX5 — isolamento de vídeos auxiliares

- extensão integrada atualizada para `1.4.39.13-aux-video-isolation-phase1`;
- preload/preview auxiliares não participam mais da descoberta de players;
- sessões obsoletas do mesmo frame são limpas após navegação;
- objetivo: eliminar falsos `target-tab-has-multiple-players` causados pelo preload.


## PIP FIX6 — Next Target Resolver Phase 2

- extensão atualizada para `1.4.39.14-next-target-resolver-phase2`;
- resolução de `currentAssetId` e `nextAssetId` separada do preload;
- preload bloqueado para alvo vazio, obsoleto ou igual ao vídeo atual;
- fallback que escolhia o último item do cache removido;
- status e motivo do próximo alvo enviados ao aplicativo;
- Phase 1 de isolamento auxiliar preservada.


## PIP FIX7 / 1.4.39.24 — Generation-safe Target State Machine Phase 3
- Generation token and operation identity for next-target work.
- AbortController cancellation on target replacement/navigation.
- Preview and preload share one authoritative target.
- AutoReturn defers same-video fallback while resolution is active or playlist index has advanced.

## PIP FIX7 Hotfix 1 / 1.4.39.24 — Next + Preview Recovery

- corrige `site-profile-next-not-found` com navegação pelo alvo autoritativo e fallback genérico de Up Next;
- converte `playlist-not-detected` em condição transitória com retries limitados;
- a compatibilidade de retries do Hotfix 1 permanece, mas o Hotfix 3 substitui a preservação visual por limpeza imediata do preview `STALE`;
- mantém generation token, cancelamento forte e guard do AutoReturn da Fase 3.


## Hotfix 2 — preview autoritativo e readiness
Extensão `1.4.39.24-range-network-cap-hotfix9`: o preview exige identidade explícita igual ao `nextAssetId`; o silent reopen faz uma única rechecagem de 250 ms e segue ao fallback físico quando o player permanece em `HAVE_NOTHING`.


## Hotfix 3 — alvo imutável e preview por geração
Extensão `1.4.39.24-range-network-cap-hotfix9`: congela `CommandTarget` no clique, limpa o preview anterior, bloqueia o fallback para a sessão antiga desde o começo da navegação, publica estado explícito do preview e limita o preload a 10 segundos.

## Hotfix 4 — Next Priority + Fast Return + Network Cap

- `Próximo` cancela `Abrir todos` e impede que o lote assuma a autoridade física durante uma navegação ativa.
- O AutoReturn aceita o alvo comandado após 220 ms quando a identidade já mudou e existe `src` ou metadata, sem aguardar carregamento completo.
- O preload oculto aborta a atividade de rede ao atingir o buffer-alvo ou após 1,8 segundo, usando remoção do `src` + `load()`.
- Preview autoritativo e `CommandTarget` imutável do Hotfix 3 foram preservados.


Hotfix 5: terminal auto-next rejects URL-only identity changes, applies bounded readiness/passive structural watch, and protects operational players from preload src removal.

Hotfix 6: strict browser-process HWND ownership, reconnect size authority, late size-inflation correction, and bounded CommandTarget re-resolution.

## PIP FIX7 Hotfix 7 / 1.4.39.24 — Universal Slot Geometry + Command Preload Handoff

O preload correspondente ao CommandTarget não é mais destruído pela mudança de geração. A janela de rede passou para 5 segundos e resultados com zero buffer são classificados como `PRELOAD_EMPTY`. A geometria autoritativa agora pertence ao slot, é vinculada também em `CapturePreparedPipWindow` e bloqueia ampliações automáticas do navegador por 4,2 segundos após a captura.


## Hotfix 8 — Real Buffer Handoff + Trusted Manual Geometry

- Pauses preload demand without removing `src` or calling `load()` after useful buffer is available.
- Persists command handoff metadata across same-tab navigation and defers the next generation until the commanded asset becomes current.
- Separates manual, observed and browser-automatic PiP rectangles.
- Uses a proven manual resize as authority; otherwise uses a bounded safe fallback.
- Clamps layout targets before the native Win32 batch to prevent an oversized visual flash.


## Range Network Cap Hotfix 9 / 1.4.39.24

Extensão `1.4.39.24-range-network-cap-hotfix9`: o preload da mídia completa usa `Range` no background, `AbortController`, teto de 8 MiB/5 s e cache temporário de três entradas por 90 s. Geometria e handoff do Hotfix 8 permanecem inalterados.


AUTORETURN PRESERVE SYNC HOTFIX 11
- AutoReturn confirmado finaliza imediatamente o estado pip-preserve da navegação.
- O novo HWND é validado contra slot e tab antes da remoção do estado.
- Elimina o falso preserve-expired-fallback-owned-by-auto-return-new-hwnd-unclassified.
- Extensão permanece 1.4.39.25; Range Cache, CommandTarget, foco e geometria não mudaram.
