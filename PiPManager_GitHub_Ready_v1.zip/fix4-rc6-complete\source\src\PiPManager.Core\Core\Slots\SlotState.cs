﻿namespace PiPManager.Core.Slots;

/// <summary>
/// Estado principal e exclusivo de um slot.
/// Propriedades como oculto, travado e AutoRetorno habilitado não são estados;
/// elas ficam separadas em SlotSnapshot.
/// </summary>
public enum SlotState
{
    Empty = 0,
    Prepared = 1,
    Opening = 2,
    Active = 3,
    WaitingForReconnect = 4,
    Reconnecting = 5,
    Failed = 6
}
