const fs = require('fs');
const path = require('path');
const assert = require('assert');
const vm = require('vm');
const root = path.resolve(__dirname, '../..');
const content = fs.readFileSync(path.join(root, 'src/PiPManager.Extension/content.js'), 'utf8');
const background = fs.readFileSync(path.join(root, 'src/PiPManager.Extension/background.js'), 'utf8');
const manifest = JSON.parse(fs.readFileSync(path.join(root, 'src/PiPManager.Extension/manifest.json'), 'utf8'));
const main = fs.readFileSync(path.join(root, 'src/PiPManager.Wpf/MainWindow.xaml.cs'), 'utf8');
const layout = fs.readFileSync(path.join(root, 'src/PiPManager.Wpf/MainWindow.Layout.cs'), 'utf8');
const drag = fs.readFileSync(path.join(root, 'src/PiPManager.Wpf/MainWindow.PipDrag.cs'), 'utf8');

assert.strictEqual(manifest.version, '1.4.39.25');
assert(content.includes("CONTENT_VERSION = '1.4.39.25-command-target-root-guard-hotfix10'"));
assert(background.includes("BRIDGE_VERSION = '1.4.39.25-command-target-root-guard-hotfix10'"));
assert(background.includes("Range: `bytes=0-${maxBytes - 1}`"), 'background must request an explicit byte range');
assert(background.includes('const controller = new AbortController()'), 'range request must be abortable');
assert(background.includes("active.abortReason = 'time-cap'"), 'time cap must abort the request');
assert(background.includes("active.abortReason = 'byte-cap'"), 'byte cap must abort the request');
assert(background.includes('cachedBytes >= maxBytes'), 'stream must stop at the hard byte cap');
assert(background.includes('rangePreloadCache = new Map()'), 'temporary cache must exist');
assert(background.includes('RANGE_PRELOAD_CACHE_MAX_ENTRIES = 3'), 'temporary cache must be bounded');
assert(background.includes('RANGE_PRELOAD_CACHE_TTL_MS = 90000'), 'temporary cache must expire');
assert(background.includes("new Blob(chunks, { type: contentType })"), 'downloaded range must be retained as temporary bytes');
assert(background.includes("cache: 'default'"), 'controlled fetch must remain eligible for browser HTTP cache reuse');
assert(!background.includes('await response.arrayBuffer()'), 'strict cap must not fall back to an unbounded full-body read');

const preloadStart = content.indexOf('async function startNextVideoPreload');
const preloadEnd = content.indexOf('function startPreloadForResolvedNextTarget', preloadStart);
const preloadBody = content.slice(preloadStart, preloadEnd);
assert(preloadBody.includes("type: 'pipManagerStartRangePreload'"), 'content must delegate full-media warming to the range controller');
assert(!preloadBody.includes("document.createElement('video')"), 'full-media network preload must not use a native hidden video');
assert(!preloadBody.includes('video.src = mediaUrl'), 'full-media URL must not be assigned to a native preload video');
assert(content.includes('cachedBytes > 0 || bufferedSeconds > 0'), 'command handoff must accept the temporary range cache');
assert(content.includes("type: 'pipManagerConsumeRangePreload'"), 'cache must be consumed after the commanded asset becomes current');
assert(content.includes('rangeCachePreserved: cachedBytes > 0'), 'handoff telemetry must expose cached-byte preservation');

// Hotfix 9 is network-only: existing geometry authorities remain present.
assert(main.includes('_lastManualUserRectBySlot'));
assert(main.includes('slot-navigation-geometry-safe-fallback'));
assert(layout.includes('ClampLayoutTargetToGeometryAuthority'));
assert(drag.includes('_lastManualUserRectBySlot[slot.Number] = finalRect'));
console.log('Range network cap Hotfix 9 checks OK.');


(async () => {
  const helperStart = background.indexOf('function rangePreloadKey');
  const helperEnd = background.indexOf('function sendMessageToTab', helperStart);
  assert(helperStart >= 0 && helperEnd > helperStart, 'range helper source region must exist');
  const helperSource = background.slice(helperStart, helperEnd);
  const MiB = 1024 * 1024;
  let abortObserved = false;
  const context = vm.createContext({
    Map, Array, Number, String, Math, Date, Blob, Uint8Array,
    AbortController: class extends AbortController {
      abort(reason) { abortObserved = true; super.abort(reason); }
    },
    setTimeout, clearTimeout,
    sendMessageToTab: async () => ({ ok: true }),
    fetch: async (_url, options) => {
      assert.strictEqual(options.headers.Range, `bytes=0-${8 * MiB - 1}`);
      const chunks = [new Uint8Array(3 * MiB), new Uint8Array(3 * MiB), new Uint8Array(3 * MiB)];
      let index = 0;
      return {
        status: 206,
        headers: { get(name) {
          const key = String(name).toLowerCase();
          if (key === 'content-type') return 'video/mp4';
          if (key === 'content-range') return `bytes 0-${8 * MiB - 1}/${40 * MiB}`;
          return '';
        } },
        body: { getReader() { return {
          async read() { return index < chunks.length ? { done: false, value: chunks[index++] } : { done: true }; },
          async cancel() {}
        }; } }
      };
    }
  });
  vm.runInContext(`
    const RANGE_PRELOAD_HARD_MAX_BYTES = ${8 * MiB};
    const RANGE_PRELOAD_DEFAULT_TIMEOUT_MS = 5000;
    const RANGE_PRELOAD_CACHE_TTL_MS = 90000;
    const RANGE_PRELOAD_CACHE_MAX_ENTRIES = 3;
    const RANGE_PRELOAD_PROGRESS_STEP_BYTES = ${512 * 1024};
    const activeRangePreloads = new Map();
    const rangePreloadCache = new Map();
    ${helperSource}
    this.hotfix9 = { startControlledRangePreload, rangePreloadCache };
  `, context);
  const result = await context.hotfix9.startControlledRangePreload(3, {
    assetId: 'asset-hotfix9', mediaUrl: 'https://media.example/video.mp4',
    operationId: 'op-1', generation: 1, maxBytes: 20 * MiB, timeoutMs: 5000
  });
  assert.strictEqual(result.ok, true, 'controlled range fetch must retain bytes');
  assert.strictEqual(result.cachedBytes, 8 * MiB, 'hard byte cap must be exact');
  assert.strictEqual(result.requestedBytes, 8 * MiB, 'requested Range must be clamped to hard cap');
  assert.strictEqual(result.stopReason, 'byte-cap', 'stream must stop because of byte cap');
  assert.strictEqual(result.rangeSupported, true, 'HTTP 206 must be recognized as Range support');
  assert.strictEqual(context.hotfix9.rangePreloadCache.size, 1, 'temporary cache must retain one bounded entry');
  assert.strictEqual(abortObserved, true, 'AbortController must stop the network after the cap');
  console.log('Range network cap Hotfix 9 runtime stream test OK.');
})().catch(error => { console.error(error); process.exitCode = 1; });
