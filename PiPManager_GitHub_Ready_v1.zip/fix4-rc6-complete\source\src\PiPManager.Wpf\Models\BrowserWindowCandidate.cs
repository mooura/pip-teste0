namespace PiPManager.Wpf.Models;

internal sealed record BrowserWindowCandidate(
    IntPtr Handle,
    string ProcessName,
    string Title,
    int Score,
    string Reasons);

