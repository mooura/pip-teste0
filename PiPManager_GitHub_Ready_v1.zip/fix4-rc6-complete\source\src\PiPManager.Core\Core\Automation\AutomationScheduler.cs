﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace PiPManager.Core.Automation;

/// <summary>
/// Agenda atrasos/cooldowns com cancelamento por chave.
/// Schedule e Cancel são serializados por lock para impedir duas substituições simultâneas.
/// O finally usa compare-and-remove para impedir tarefa antiga de remover agendamento novo.
/// </summary>
public sealed class AutomationScheduler : IDisposable
{
    private readonly object _gate = new();
    private readonly ConcurrentDictionary<string, CancellationTokenSource> _scheduled = new();

    public event Action<string, Exception>? CallbackFailed;

    public void Schedule(
        string key,
        TimeSpan delay,
        Func<CancellationToken, Task> callback)
    {
        CancellationTokenSource cts;

        lock (_gate)
        {
            if (_scheduled.TryRemove(key, out var previous))
            {
                previous.Cancel();
                // A tarefa dona do CTS anterior fará Dispose no finally.
            }

            cts = new CancellationTokenSource();
            _scheduled[key] = cts;
        }

        _ = Task.Run(async () =>
        {
            try
            {
                await Task.Delay(delay, cts.Token).ConfigureAwait(false);
                if (!cts.IsCancellationRequested)
                    await callback(cts.Token).ConfigureAwait(false);
            }
            catch (OperationCanceledException)
            {
                // cancelamento esperado
            }
            catch (Exception ex)
            {
                CallbackFailed?.Invoke(key, ex);
            }
            finally
            {
                lock (_gate)
                {
                    ((ICollection<KeyValuePair<string, CancellationTokenSource>>)_scheduled)
                        .Remove(new KeyValuePair<string, CancellationTokenSource>(key, cts));
                }

                cts.Dispose();
            }
        });
    }

    public bool IsScheduled(string key)
    {
        lock (_gate)
            return _scheduled.ContainsKey(key);
    }

    public void Cancel(string key)
    {
        CancellationTokenSource? existing = null;

        lock (_gate)
        {
            if (_scheduled.TryRemove(key, out var removed))
                existing = removed;
        }

        existing?.Cancel();
        // Não dispose aqui: a tarefa dona do CTS finaliza e descarta.
    }

    public void Dispose()
    {
        string[] keys;

        lock (_gate)
            keys = _scheduled.Keys.ToArray();

        foreach (var key in keys)
            Cancel(key);
    }
}
