﻿using System.Windows.Threading;
using PiPManager.Wpf.Models;

namespace PiPManager.Wpf;

public partial class MainWindow
{
    // Cache de normalização do AutoReturn. O dicionário só precisa ser reconstruído
    // na inicialização/migração ou quando a quantidade de slots efetivamente muda.
    private bool _slotAutoReturnSettingsInitialized;
    private int _slotAutoReturnSettingsSlotCount = -1;

    // Eventos de status e snapshots podem chegar em rajadas vindas de threads da
    // extensão. Mantemos no máximo um trabalho pendente por tipo no Dispatcher.
    private readonly object _extensionUiQueueSync = new();
    private string? _pendingExtensionStatus;
    private bool _extensionStatusDispatchPending;
    private readonly Dictionary<string, VideoTabInfo> _pendingVideoTabsByKey = new(StringComparer.OrdinalIgnoreCase);
    private bool _pendingVideoTabsSnapshotReceived;
    private bool _videoTabsDispatchPending;

    private void QueueExtensionStatusUpdate(string message)
    {
        // Estas mensagens alimentam estado funcional e sinais aguardados por
        // operações assíncronas; nunca podem ser descartadas por latest-wins.
        if (IsCriticalExtensionStatus(message))
        {
            if (!Dispatcher.HasShutdownStarted)
                Dispatcher.BeginInvoke(DispatcherPriority.Normal, new Action(() => OnExtensionBridgeStatusChanged(message)));
            return;
        }

        // Diagnóstico de content script não altera estado e já era descartado pelo
        // handler. Filtrar antes do Dispatcher elimina a rajada na origem.
        if (!string.IsNullOrWhiteSpace(message)
            && message.StartsWith("Content script ativo", StringComparison.OrdinalIgnoreCase))
        {
            return;
        }

        var shouldSchedule = false;
        lock (_extensionUiQueueSync)
        {
            _pendingExtensionStatus = message;
            if (!_extensionStatusDispatchPending)
            {
                _extensionStatusDispatchPending = true;
                shouldSchedule = true;
            }
        }

        if (shouldSchedule && !Dispatcher.HasShutdownStarted)
            Dispatcher.BeginInvoke(DispatcherPriority.Background, new Action(DrainExtensionStatusUpdate));
    }

    private static bool IsCriticalExtensionStatus(string message)
    {
        if (string.IsNullOrWhiteSpace(message))
            return false;

        return message.StartsWith("SilentPreflight ", StringComparison.OrdinalIgnoreCase)
            || message.StartsWith("Silencioso ", StringComparison.OrdinalIgnoreCase)
            || message.StartsWith("Extensão conectada e autenticada", StringComparison.OrdinalIgnoreCase);
    }

    private void DrainExtensionStatusUpdate()
    {
        string? message;
        lock (_extensionUiQueueSync)
        {
            message = _pendingExtensionStatus;
            _pendingExtensionStatus = null;
        }

        try
        {
            if (!string.IsNullOrWhiteSpace(message))
                OnExtensionBridgeStatusChanged(message);
        }
        finally
        {
            var scheduleAgain = false;
            lock (_extensionUiQueueSync)
            {
                if (_pendingExtensionStatus is not null)
                {
                    scheduleAgain = true;
                }
                else
                {
                    _extensionStatusDispatchPending = false;
                }
            }

            if (scheduleAgain && !Dispatcher.HasShutdownStarted)
                Dispatcher.BeginInvoke(DispatcherPriority.Background, new Action(DrainExtensionStatusUpdate));
        }
    }

    private void QueueVideoTabsSnapshotUpdate(IReadOnlyList<VideoTabInfo> tabs)
    {
        var shouldSchedule = false;
        lock (_extensionUiQueueSync)
        {
            _pendingVideoTabsSnapshotReceived = true;
            foreach (var tab in tabs)
            {
                var key = GetVideoCacheKey(tab);
                if (string.IsNullOrWhiteSpace(key))
                    key = $"tab:{tab.TabId}:frame:{tab.FrameId}:video:{tab.VideoIndex}";

                // Snapshots de clientes diferentes são unidos. Para a mesma sessão,
                // a versão mais nova vence antes de chegar à thread gráfica.
                _pendingVideoTabsByKey[key] = tab;
            }

            if (!_videoTabsDispatchPending)
            {
                _videoTabsDispatchPending = true;
                shouldSchedule = true;
            }
        }

        if (shouldSchedule && !Dispatcher.HasShutdownStarted)
            Dispatcher.BeginInvoke(DispatcherPriority.Normal, new Action(DrainVideoTabsSnapshotUpdate));
    }

    private void DrainVideoTabsSnapshotUpdate()
    {
        IReadOnlyList<VideoTabInfo> tabs;
        bool snapshotReceived;
        lock (_extensionUiQueueSync)
        {
            tabs = _pendingVideoTabsByKey.Values.ToList();
            _pendingVideoTabsByKey.Clear();
            snapshotReceived = _pendingVideoTabsSnapshotReceived;
            _pendingVideoTabsSnapshotReceived = false;
        }

        try
        {
            if (snapshotReceived)
                MergeVideoTabsSnapshot(tabs);
        }
        finally
        {
            var scheduleAgain = false;
            lock (_extensionUiQueueSync)
            {
                if (_pendingVideoTabsSnapshotReceived || _pendingVideoTabsByKey.Count > 0)
                {
                    scheduleAgain = true;
                }
                else
                {
                    _videoTabsDispatchPending = false;
                }
            }

            if (scheduleAgain && !Dispatcher.HasShutdownStarted)
                Dispatcher.BeginInvoke(DispatcherPriority.Normal, new Action(DrainVideoTabsSnapshotUpdate));
        }
    }

    private void SyncAutoReturnFlagsToSlotModels()
    {
        foreach (var slot in Slots)
            slot.IsAutoReturnEnabled = _slotAutoReturnDiscreteBySlot.TryGetValue(slot.Number, out var slotEnabled) && slotEnabled;

        foreach (var editable in EditableSlots)
            editable.IsAutoReturnEnabled = _slotAutoReturnDiscreteBySlot.TryGetValue(editable.Number, out var editableEnabled) && editableEnabled;
    }

    private void ClearPendingExtensionUiUpdates()
    {
        lock (_extensionUiQueueSync)
        {
            _pendingExtensionStatus = null;
            _pendingVideoTabsByKey.Clear();
            _pendingVideoTabsSnapshotReceived = false;
            _extensionStatusDispatchPending = false;
            _videoTabsDispatchPending = false;
        }
    }
}
