$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path

function Check([string]$label, [bool]$condition) {
    if (-not $condition) { throw "FAIL: $label" }
    Write-Host "$label`: OK"
}

$fixed = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\MainWindow.FixedLayout.cs') -Raw
$main = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\MainWindow.xaml.cs') -Raw
$layout = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\MainWindow.Layout.cs') -Raw
$editable = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\Models\EditableSlotRect.cs') -Raw
$xaml = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\MainWindow.xaml') -Raw
$tests = Get-Content -LiteralPath (Join-Path $root 'tests\PiPManager.WindowEventMonitor.Tests\Program.cs') -Raw
$runner = Get-Content -LiteralPath (Join-Path $root 'RUN_CORE_TESTS.bat') -Raw

Check 'fixed area uses exact visual edge' ($fixed.Contains('FixedLayoutReservedMarginPx = 0'))
Check 'normal windows are moved by visual bounds' ($fixed.Contains('target.Left + offsetX') -and $fixed.Contains('target.Width + extraWidth'))
Check 'fixed-area reaction is prompt' ($fixed.Contains('FixedLayoutWindowRespectPollMs = 250') -and $fixed.Contains('FixedLayoutWindowActivationSettleMs = 120'))
Check 'open all stabilizes extension snapshots' ($main.Contains('StabilizeVideoSourcesForOpenAllAsync') -and $main.Contains('open-all-source-stabilization'))
Check 'open all capacity follows actual slots' ($main.Contains('var slotCapacity = Slots.Count') -and -not $main.Contains('Math.Max(0, 10 - activeWindowCount)'))
Check 'source deficit is explicit instead of duplicating videos' ($main.Contains('sourceDeficit=') -and $main.Contains('slot(s) livre(s) porque foram detectadas'))
Check 'slot appearance reads live HWND geometry' ($layout.Contains('PipWindowService.GetVisualRect(slot.Window.Handle)'))
Check 'portrait classification is generic' ($editable.Contains('aspectRatio < 0.90') -and $editable.Contains('IsPortraitAppearance'))
Check 'manual slot binds aspect-aware preview dimensions' ($xaml.Contains('Width="{Binding PreviewWidth}"') -and $xaml.Contains('Height="{Binding PreviewHeight}"'))
Check 'portrait and normal appearances have executable tests' ($tests.Contains('640.0 / 1120.0') -and $tests.Contains('1280.0 / 720.0'))
Check 'checker is wired into full gate' ($runner.Contains('CHECK_FIXED_AREA_TEN_SLOT_ASPECT_UX.ps1'))

Write-Host 'Fixed area, ten-slot capacity and aspect UX checks OK.' -ForegroundColor Green
