$ErrorActionPreference = "Stop"
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$main = Get-Content -Raw (Join-Path $root "src\PiPManager.Wpf\MainWindow.xaml.cs")
$content = Get-Content -Raw (Join-Path $root "src\PiPManager.Extension\content.js")
$background = Get-Content -Raw (Join-Path $root "src\PiPManager.Extension\background.js")
$manifest = Get-Content -Raw (Join-Path $root "src\PiPManager.Extension\manifest.json")

$checks = [ordered]@{
  "content advertisement classifier exists" = $content.Contains("function getAdvertisementClassification(video, rect)")
  "known ad hosts blocked in content" = $content.Contains("'creative.cambaddies.com'") -and $content.Contains("'trendbuzz.to'")
  "ad titles blocked in content" = $content.Contains("outstream\s+ad") -and $content.Contains("mobile\s+slider")
  "ad candidates excluded before snapshot" = $content.Contains("const candidate = visible && !advertisement.isLikelyAd")
  "ad terminal events ignored" = $content.Contains("if (terminalQuality.isLikelyAd) return")
  "ad PiP events ignored" = $content.Contains("if (quality.isLikelyAd) return")
  "background advertisement classifier exists" = $background.Contains("function isLikelyAdvertisementSession(session)")
  "background purges ad sessions" = $background.Contains("purgeLikelyAdvertisementSessions()")
  "background ignores ad terminal messages" = $background.Contains("if (isLikelyAdvertisementSession(value))")
  "app advertisement classifier exists" = $main.Contains("IsLikelyAdvertisementVideo(VideoTabInfo tab, out string reason)")
  "app filters snapshots before cache" = $main.Contains("var acceptedTabs = new List<VideoTabInfo>(tabs.Count)")
  "app removes stale ad cache entries" = $main.Contains("IsLikelyAdvertisementVideo(item.Value.Tab, out _)")
  "open all excludes ads" = $main.Contains("&& !IsLikelyAdvertisementVideo(tab, out _)")
  "all PiP opening paths have central guard" = $main.Contains("openpip-ad-isolation-blocked")
  "extension version updated" = $manifest.Contains('"version": "1.4.39.25"')
}

$failed = @()
foreach ($item in $checks.GetEnumerator()) {
  if ($item.Value) { Write-Host ($item.Key + ": OK") }
  else { Write-Host ($item.Key + ": FAIL"); $failed += $item.Key }
}
if ($failed.Count -gt 0) { throw "Advertisement isolation checks failed: $($failed -join ', ')" }
Write-Host "Advertisement video isolation checks OK."
