using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Net.Http;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Markup;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using System.Windows.Interop;
using Microsoft.Extensions.DependencyInjection;
using PiPManager.Wpf.Models;
using PiPManager.Core.Slots;
using PiPManager.Core.Shadow;
using PiPManager.Core.Mapping;
using PiPManager.Core.Automation;
using PiPManager.Wpf.Services;

namespace PiPManager.Wpf;

public partial class MainWindow : Window
{
    private readonly ShadowModeRuntimeService _shadowModeRuntime = new();
    private readonly ShadowParityReportService _shadowParityReport = new();
    private readonly Dictionary<int, string> _shadowOpenAttemptIdBySlot = new();
    private readonly Dictionary<int, string> _shadowReconnectAttemptIdBySlot = new();
    private readonly HashSet<int> _shadowExternalCaptureSlots = new();


        // 9.31.54 — Hidden Browser Workspace
        private bool _hiddenBrowserWorkspaceEnabled = false;
        private IntPtr _hiddenBrowserWorkspaceBrowserHwnd = IntPtr.Zero;
        private HiddenBrowserPlacement? _hiddenBrowserWorkspaceSavedPlacement;

        private struct HiddenBrowserPlacement
        {
            public int X;
            public int Y;
            public int Width;
            public int Height;
        }

        private static class HiddenBrowserWorkspaceNative
        {
            [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential)]
            public struct RECT
            {
                public int Left;
                public int Top;
                public int Right;
                public int Bottom;
            }

            [System.Runtime.InteropServices.DllImport("user32.dll")]
            public static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);

            [System.Runtime.InteropServices.DllImport("user32.dll")]
            public static extern bool MoveWindow(IntPtr hWnd, int X, int Y, int nWidth, int nHeight, bool bRepaint);

            [System.Runtime.InteropServices.DllImport("user32.dll")]
            public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

            [System.Runtime.InteropServices.DllImport("user32.dll")]
            public static extern bool IsWindow(IntPtr hWnd);
        }

        private void EnsureHiddenBrowserWorkspaceForShortcut(IntPtr browserHwnd, string attemptId, int slot, string reason)
        {
            try
            {
                if (!_hiddenBrowserWorkspaceEnabled)
                {
                    AppLogger.Info($"hidden-browser-workspace-skipped: attemptId={attemptId}; slot={slot}; reason=disabled; browserHwnd=0x{browserHwnd.ToInt64():X}");
                    return;
                }

                if (browserHwnd == IntPtr.Zero || !HiddenBrowserWorkspaceNative.IsWindow(browserHwnd))
                {
                    AppLogger.Warn($"hidden-browser-workspace-skipped: attemptId={attemptId}; slot={slot}; reason=invalid-browser-hwnd; browserHwnd=0x{browserHwnd.ToInt64():X}");
                    return;
                }

                if (_hiddenBrowserWorkspaceBrowserHwnd == IntPtr.Zero || _hiddenBrowserWorkspaceBrowserHwnd != browserHwnd || _hiddenBrowserWorkspaceSavedPlacement == null)
                {
                    if (HiddenBrowserWorkspaceNative.GetWindowRect(browserHwnd, out var rc))
                    {
                        _hiddenBrowserWorkspaceSavedPlacement = new HiddenBrowserPlacement
                        {
                            X = rc.Left,
                            Y = rc.Top,
                            Width = Math.Max(300, rc.Right - rc.Left),
                            Height = Math.Max(300, rc.Bottom - rc.Top)
                        };
                        _hiddenBrowserWorkspaceBrowserHwnd = browserHwnd;
                        AppLogger.Info($"hidden-browser-workspace-saved: attemptId={attemptId}; slot={slot}; browserHwnd=0x{browserHwnd.ToInt64():X}; x={rc.Left}; y={rc.Top}; w={rc.Right - rc.Left}; h={rc.Bottom - rc.Top}; reason={reason}");
                    }
                }

                var p = _hiddenBrowserWorkspaceSavedPlacement;
                var width = p?.Width ?? 1280;
                var height = p?.Height ?? 720;
                const int hiddenX = -32000;
                const int hiddenY = -32000;

                HiddenBrowserWorkspaceNative.ShowWindow(browserHwnd, 1);
                var moved = HiddenBrowserWorkspaceNative.MoveWindow(browserHwnd, hiddenX, hiddenY, width, height, true);
                AppLogger.Warn($"hidden-browser-workspace-moved-offscreen: attemptId={attemptId}; slot={slot}; browserHwnd=0x{browserHwnd.ToInt64():X}; moved={moved}; x={hiddenX}; y={hiddenY}; w={width}; h={height}; reason={reason}");
            }
            catch (Exception ex)
            {
                AppLogger.Warn($"hidden-browser-workspace-error: attemptId={attemptId}; slot={slot}; error={ex.Message}; reason={reason}");
            }
        }

        private void RestoreHiddenBrowserWorkspace(string source)
        {
            try
            {
                var hwnd = _hiddenBrowserWorkspaceBrowserHwnd;
                var p = _hiddenBrowserWorkspaceSavedPlacement;
                if (hwnd == IntPtr.Zero || p == null)
                {
                    AppLogger.Info($"hidden-browser-workspace-restore-skipped: source={source}; reason=no-saved-browser");
                    return;
                }

                if (!HiddenBrowserWorkspaceNative.IsWindow(hwnd))
                {
                    AppLogger.Warn($"hidden-browser-workspace-restore-skipped: source={source}; reason=browser-hwnd-invalid; browserHwnd=0x{hwnd.ToInt64():X}");
                    _hiddenBrowserWorkspaceBrowserHwnd = IntPtr.Zero;
                    _hiddenBrowserWorkspaceSavedPlacement = null;
                    return;
                }

                HiddenBrowserWorkspaceNative.ShowWindow(hwnd, 1);
                var moved = HiddenBrowserWorkspaceNative.MoveWindow(hwnd, p.Value.X, p.Value.Y, p.Value.Width, p.Value.Height, true);
                AppLogger.Warn($"hidden-browser-workspace-restored: source={source}; browserHwnd=0x{hwnd.ToInt64():X}; moved={moved}; x={p.Value.X}; y={p.Value.Y}; w={p.Value.Width}; h={p.Value.Height}");
                _hiddenBrowserWorkspaceBrowserHwnd = IntPtr.Zero;
                _hiddenBrowserWorkspaceSavedPlacement = null;
            }
            catch (Exception ex)
            {
                AppLogger.Warn($"hidden-browser-workspace-restore-error: source={source}; error={ex.Message}");
            }
        }

        private void HiddenBrowserWorkspaceToggle_Click(object sender, RoutedEventArgs e)
        {
            _hiddenBrowserWorkspaceEnabled = !_hiddenBrowserWorkspaceEnabled;
            AppLogger.Warn($"hidden-browser-workspace-toggle: enabled={_hiddenBrowserWorkspaceEnabled}");
            TryUpdateHiddenBrowserWorkspaceButtonText();
        }

        private void HiddenBrowserWorkspaceRestore_Click(object sender, RoutedEventArgs e)
        {
            RestoreHiddenBrowserWorkspace("button-restore-browser");
        }

        private void TryUpdateHiddenBrowserWorkspaceButtonText()
        {
            try
            {
                if (this.FindName("HiddenBrowserWorkspaceToggleButton") is System.Windows.Controls.Button btn)
                    btn.Content = _hiddenBrowserWorkspaceEnabled ? "Navegador oculto: ON" : "Navegador oculto: OFF";
            }
            catch { }
        }


    private sealed record TemplateLayoutItem(Rect Rect, int Width, int Height, int Index);

    [DllImport("user32.dll")]
    private static extern IntPtr GetForegroundWindow();

    [DllImport("user32.dll")]
    private static extern bool SetForegroundWindow(IntPtr hWnd);

    [DllImport("user32.dll")]
    private static extern bool IsWindow(IntPtr hWnd);

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern int GetWindowText(IntPtr hWnd, StringBuilder text, int count);

    [DllImport("user32.dll")]
    private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);

    private delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);

    [DllImport("user32.dll")]
    private static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);

    [DllImport("user32.dll")]
    private static extern bool IsWindowVisible(IntPtr hWnd);

    [DllImport("user32.dll")]
    private static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

    [DllImport("user32.dll")]
    private static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int x, int y, int cx, int cy, uint flags);

    [DllImport("user32.dll")]
    private static extern uint GetCurrentThreadId();

    [DllImport("user32.dll")]
    private static extern bool AttachThreadInput(uint idAttach, uint idAttachTo, bool fAttach);

    private static readonly IntPtr HwndTop = new(0);
    private const int SwRestore = 9;
    private const int SwShow = 5;
    private const uint SwpNoSize = 0x0001;
    private const uint SwpNoMove = 0x0002;
    private const uint SwpShowWindow = 0x0040;

    private readonly WindowDiscoveryService _discovery;
    private readonly LayoutService _layoutService;
    private readonly MonitorService _monitorService;
    private IReadOnlyList<DisplayMonitorInfo> _availableMonitors = [];
    private bool _suppressMonitorSelectionEvents;
    private readonly SettingsService _settingsService;
    private readonly ExtensionBridgeService _extensionBridge;
    private readonly PipWindowService _pipWindowService;
    private readonly VideoCommandService _videoCommandService;
    private readonly IApplicationHealthService _applicationHealth;
    private readonly IWindowEventMonitorService _windowEventMonitor;
    private readonly IWindowEventReactorService _windowEventReactor;
    private readonly IWindowEventFlowControlService _windowEventFlowControl;
    private readonly IAutomationCoordinator _automationCoordinator;
    private string _lastAutomationVideoTabsSignature = string.Empty;
    private DateTime _lastAutomationVideoTabsObservedUtc = DateTime.MinValue;
    private const int AutomationVideoTabsSnapshotThrottleMs = 15000;
    private const int AutomationVideoTabsChangedLogAggregateMs = 1500;
    private readonly Dictionary<string, DateTime> _windowEventAssistedCooldownUtc = new(StringComparer.OrdinalIgnoreCase);
    private DateTime _lastWindowEventAssistedCooldownCleanupUtc = DateTime.MinValue;
    private const int WindowEventAssistedCooldownCleanupSeconds = 30;
    private readonly Dictionary<IntPtr, DateTime> _reactorAssistedCandidateCooldownUtc = [];
    private readonly HashSet<IntPtr> _reactorAssistedPreArmWaitHandles = [];
    private const int ReactorAssistedCandidateCooldownMs = 2500;
    private const int ReactorAssistedPreArmGraceMs = 900;
    private const int ReactorAssistedConfirmationWaitMs = 350;
    private const int ReactorAutoReturnConfirmationWaitMs = 100;
    private const int ReactorPrimaryShortConfirmationWaitMs = 125;
    private const int ReactorAssistedConfirmationPollMs = 25;
    private const string ReactorCaptureModeEnvironmentVariable = RuntimeAuthorityPolicy.EnvironmentVariable;
    private const string ReactorPreArmDiagnosticDelayEnvironmentVariable = "PIPMANAGER_DIAGNOSTIC_PREARM_DELAY_MS";
    private const int ReactorPreArmDiagnosticDelayMaxMs = 700;
    private int _reactorAssistedCandidateGeneration;
    private readonly DispatcherTimer _healthTimer;
    private DateTime _lastHealthDragTargetsRefreshUtc = DateTime.MinValue;
    private DateTime _lastHealthGeometryRefreshUtc = DateTime.MinValue;
    private const int HealthTimerIntervalMs = 1800;
    private const int HealthDragTargetsRefreshMs = 5000;
    private const int HealthGeometryRefreshMs = 3000;
    private readonly DispatcherTimer _liveCaptureTimer;
    private readonly AppSettings _settings;
    private FloatingToolbarWindow? _toolbar;
    private bool _allHidden;
    private bool _liveCaptureActive;
    private bool _videoCommandBusy;
    // Reenvio automático de "next" quando a extensão não encontra vídeo no alvo
    // (sala/modelo bloqueado ou offline, item removido, etc.). Guarda simples
    // por tempo para nunca ficar reenviando indefinidamente no mesmo vídeo preso.
    private DateTime _lastAutoRetryNextUtc = DateTime.MinValue;
    private int _autoRetryNextStreak;
    private const int AutoRetryNextMaxStreak = 2;
    private static readonly TimeSpan AutoRetryNextCooldown = TimeSpan.FromSeconds(3);
    private readonly Dictionary<int, string> _slotVideoPairs = [];
    private readonly Dictionary<int, string> _slotStableVideoPairs = [];
    private readonly Dictionary<int, int> _slotPairedTabIds = [];
    private readonly Dictionary<int, string> _slotPairDomains = [];
    private readonly Dictionary<int, string> _slotPairUrls = [];
    private readonly Dictionary<int, string> _slotPlaylistLogSignatures = [];
    private Point _slotDragStartPoint;
    private PipSlot? _slotDragSource;

    private readonly HashSet<int> _missingPairLoggedSlots = [];
    private readonly List<VideoPipEventInfo> _recentPipEvents = [];
    private readonly DispatcherTimer _armedPipPairTimer;
    private VideoTabInfo? _armedPipPairTab;
    private HashSet<IntPtr> _armedPipExistingHandles = [];
    private DateTime _armedPipPairUntilUtc = DateTime.MinValue;
    private DateTime _armedPipPairStartedUtc = DateTime.MinValue;
    private PipWindowInfo? _armedPipCandidateWindow;
    private DateTime _armedPipCandidateDetectedUtc = DateTime.MinValue;
    private int _armedPipTargetSlotNumber;

    private enum OpenPipAttemptOwner
    {
        User,
        AutoReturn
    }

    private bool _openPipAttemptInProgress;
    private int _openPipAttemptSlotNumber;
    private string _openPipAttemptKey = string.Empty;
    private VideoTabInfo? _openPipAttemptTab;
    private OpenPipAttemptOwner _openPipAttemptOwner = OpenPipAttemptOwner.User;
    private DateTime _openPipAttemptStartedUtc = DateTime.MinValue;
    private DateTime _openPipAttemptUntilUtc = DateTime.MinValue;
    private bool _openAllPipsInProgress;
    private System.Threading.CancellationTokenSource? _openAllCancellationCts;
    private bool _autoAdvanceOnVideoEndEnabled = true;
    private bool _nextVideoPreviewEnabled;
    private bool _nextVideoPreloadEnabled;
    private readonly Dictionary<int, bool> _slotNextVideoPreloadBySlot = [];
    private static readonly HttpClient SlotPreviewHttpClient = CreateSlotPreviewHttpClient();
    private readonly Dictionary<string, BitmapImage> _slotPreviewImageCache = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<int, int> _slotPreviewAnimationGeneration = [];
    private readonly Dictionary<int, bool> _lastPreloadSentByTab = [];
    private readonly Dictionary<int, NextVideoPreviewWindow> _nextVideoPreviewWindowsBySlot = [];
    private readonly Dictionary<int, NextPreviewCommandBarrier> _nextPreviewCommandBarriersBySlot = [];
    private int? _hoveredPreviewSlotNumber;
    private readonly SemaphoreSlim _autoAdvanceTerminalGate = new(1, 1);
    private readonly Dictionary<int, DateTime> _autoAdvanceTerminalCooldownUntilBySlot = [];
    private readonly Dictionary<int, int> _autoAdvanceLostPipWatchGenerationBySlot = [];
    private readonly Dictionary<int, DateTime> _autoAdvanceLostPipWatchStartedUtcBySlot = [];
    private readonly Dictionary<int, int> _terminalAutoNextGenerationBySlot = [];
    private bool _autoReturnFastTickQueued;
    private const int AutoAdvanceTerminalCooldownSeconds = 12;
    private const int AutoAdvanceLostPipPollMs = 350;
    private const int AutoAdvanceLostPipMaxAttempts = 40;
    private const int AutoAdvanceLostPipStaleSignalMs = 4500;
    private const int AutoAdvanceLostPipRequiredConfirmations = 2;
    private const int AutoAdvanceLostPipDirectTerminalMinimumAttempt = 2;
    private const int AutoAdvanceLostPipMissingMinimumAttempt = 3;
    private const int AutoAdvanceTerminalProbeGraceMs = 1800;
    private const int AutoAdvanceTerminalBusyWaitMaxMs = 4500;
    private const int AutoAdvanceTerminalSignalFallbackMs = 650;
    private readonly object _pipOperationAvailabilitySync = new();
    private TaskCompletionSource<bool> _pipOperationAvailabilitySignal = CreatePipOperationAvailabilitySignal();
    private int _pipOperationAvailabilityWaiters;
    private const int AutoReturnTerminalAdvanceStabilizeMs = 250;


    // Diagnóstico temporário e reversível: prova que a abertura controlada consegue
    // correlacionar a identidade escolhida com exatamente um HWND novo.
    private string _autoPairProofAttemptId = string.Empty;
    private int _autoPairProofSlotNumber;
    private int _autoPairProofTabId;
    private string _autoPairProofPairKey = string.Empty;
    private DateTime _autoPairProofStartedUtc = DateTime.MinValue;
    private HashSet<IntPtr> _autoPairProofExistingHandles = [];

    private string _lastSilentAttemptId = string.Empty;
    private string _lastSilentExtensionReasonCode = string.Empty;
    private string _lastSilentExtensionReasonMessage = string.Empty;
    private bool _lastSilentExtensionEnterPipSeen;
    private string _lastSilentPreflightAttemptId = string.Empty;
    private string _lastSilentPreflightReasonCode = string.Empty;
    private string _lastSilentPreflightReasonMessage = string.Empty;
    private string _lastSilentPreflightResult = string.Empty;
    private string _lastSilentPreflightDomain = string.Empty;
    private int _lastSilentPreflightTabId;
    private int _lastSilentPreflightFrameId;
    private bool _lastSilentPreflightOk;
    private readonly object _silentPreflightWaitSync = new();
    private string _silentPreflightWaitAttemptId = string.Empty;
    private TaskCompletionSource<bool>? _silentPreflightWaitSignal;
    private const int SilentPreflightFallbackWaitMs = 880;
    private AutoReturnPolicy _autoReturnPolicy = AutoReturnPolicy.Off;
    private readonly Dictionary<int, bool> _slotAutoReturnDiscreteBySlot = [];
    private readonly DispatcherTimer _autoReturnTimer;
    private readonly Dictionary<int, AutoReturnSlotState> _autoReturnStatesBySlot = [];
    private readonly Dictionary<int, DateTime> _autoReturnCooldownUntilBySlot = [];
    private readonly Dictionary<int, int> _autoReturnCancellationGenerationBySlot = [];
    private readonly SemaphoreSlim _autoReturnExecutionGate = new(1, 1);
    private string _activeAutoReturnAttemptId = string.Empty;
    private int _activeAutoReturnSlotNumber;
    private DateTime _activeAutoReturnAttemptStartedUtc = DateTime.MinValue;
    private readonly Dictionary<IntPtr, string> _autoReturnCandidateAttemptByHwnd = [];
    private readonly Dictionary<IntPtr, int> _windowLossDebounceGenerationByHwnd = [];
    private const int WindowLossDebounceMs = 1200;
    private const int WindowLossNavigationDebounceMs = 180;
    private readonly Dictionary<string, DateTime> _silentReopenPreciseCooldownUntilUtc = [];
    private readonly Dictionary<string, string> _silentReopenPreciseCooldownReason = [];
    private readonly Dictionary<string, DateTime> _silentReopenRecentHardBlockByDomainReason = [];
    private readonly Dictionary<string, string> _silentReopenRecentHardBlockFrameByDomainReason = [];
    private readonly Dictionary<int, VideoSwitchPreservationState> _videoSwitchPreservationBySlot = [];
    private readonly DispatcherTimer _videoSwitchPreservationTimer;
    private const int VideoSwitchPreservationTtlSeconds = 8;
    private const int NextPreviewCommandBarrierMaxAgeSeconds = 12;
    private const int VideoNavigationLossCorrelationMs = 2200;
    private const int VideoSwitchPreservedSameHwndConfirmMs = 2500;
    private const int AutoReturnMaxAgeSeconds = 45;
    private const int AutoReturnStabilizeMs = 1200;
    private const int AutoReturnNavigationStabilizeMs = 150;
    private const int AutoReturnTargetReadyMaxWaitMs = 450;
    private const int AutoReturnTargetReadyPollMs = 60;
    private const int AutoReturnMaxReadinessDeferrals = 1;
    private const int AutoReturnCommandNavigationMinimalReadyGraceMs = 220;
    private const int AutoReturnTerminalTargetUnavailableMs = 4000;
    private const int AutoReturnTerminalPassiveWatchMs = 8000;
    private const int AutoReturnTerminalPassiveCooldownMs = 500;
    private const int AutoReturnPlaylistSameVideoFallbackMs = 2200;
    private const int AutoReturnTargetResolverGraceMaxMs = 8000;
    private const int SilentReopenDomainCooldownSeconds = 75;
    private DateTime _liveCaptureStopAtUtc = DateTime.MinValue;
    private sealed record PendingLostPip(PipWindowInfo Window, DateTime FirstLostUtc, bool HadVideoPair);
    private sealed record SlotReconnectCandidate(PipSlot Slot, PipWindowInfo Window, int Score, string Reasons);
    private sealed record ReconnectGeometryAuthorityState(
        int SlotNumber,
        IntPtr Handle,
        NativeRect TargetRect,
        int Generation,
        DateTime ArmedUtc,
        DateTime ExpiresUtc,
        string Source);
    private sealed record SlotNavigationGeometryAuthorityState(
        int SlotNumber,
        NativeRect TargetRect,
        int Generation,
        DateTime ArmedUtc,
        DateTime ExpiresUtc,
        string Source,
        IntPtr SourceHandle,
        bool UsesManualUserRect);
    private readonly Dictionary<int, PendingLostPip> _pendingLostPipsBySlot = [];
    private readonly Dictionary<IntPtr, ReconnectGeometryAuthorityState> _reconnectGeometryAuthorityByHwnd = [];
    private readonly Dictionary<int, SlotNavigationGeometryAuthorityState> _slotNavigationGeometryAuthorityBySlot = [];
    private readonly Dictionary<int, NativeRect> _lastManualUserRectBySlot = [];
    private readonly Dictionary<int, NativeRect> _lastObservedRectBySlot = [];
    private readonly Dictionary<int, NativeRect> _lastBrowserAutomaticRectBySlot = [];
    private readonly Dictionary<int, int> _reconnectGeometryGenerationBySlot = [];
    private const int ReconnectGeometryAuthorityDurationMs = 4700;
    private const int SlotNavigationGeometryAuthorityDurationMs = 15000;
    private const int NavigationGeometrySafeMaxWidthPx = 720;
    private const int NavigationGeometrySafeMaxHeightPx = 640;
    private const double NavigationGeometrySafeMaxWorkAreaFraction = 0.25;
    private static readonly int[] ReconnectGeometryVerifyCheckpointsMs = [0, 150, 400, 900, 1800, 3200, 4200];
    private const int PipLostGraceSeconds = 8;
    private const int PairedPipLostGraceSeconds = 30;
    private bool _groupLocked = true;
    private bool _customLayoutActive;
    private NativeRect _lastKnownGroupBounds;
    private List<NativeRect> _slotLayoutRects = [];
    private DateTime _ignoreWindowMovesUntilUtc = DateTime.MinValue;
    private int _layoutTransactionDepth;
    private int _layoutTransactionGeneration;
    private DateTime _layoutTransactionUntilUtc = DateTime.MinValue;
    private System.Threading.CancellationTokenSource? _stableGroupLayoutDebounceCts;
    private int _stableGroupLayoutDebounceGeneration;
    private System.Threading.CancellationTokenSource? _mixedAspectReflowDebounceCts;
    private int _mixedAspectReflowDebounceGeneration;
    private const int MixedAspectReflowDebounceMs = 550;
    private const int NaturalAspectStableSampleMs = 280;
    private readonly System.Collections.Concurrent.ConcurrentDictionary<IntPtr, long> _lastWindowMoveUiDispatchUnixMsByHwnd = new();
    private readonly System.Collections.Concurrent.ConcurrentDictionary<IntPtr, int> _lastLayoutSelfMoveGenerationByHwnd = new();
    private int _layoutSuppressionSummaryGeneration;
    private const int WindowMoveUiDispatchThrottleMs = 250;
    private const int LayoutMovePositionTolerancePx = 4;
    private const int LayoutMoveSizeTolerancePx = 3;
    private int? _lastResizedSlotNumber;
    private int? _lastManuallyResizedSlotNumber;
    private Dictionary<IntPtr, NativeRect> _lockedGroupModelRects = [];
    private NativeRect _lockedGroupModelBounds;
    private Dictionary<IntPtr, NativeRect> _hiddenPipRects = [];
    private bool _naturalAnchorDragActive;
    private IntPtr _naturalAnchorDragHandle = IntPtr.Zero;
    private Dictionary<IntPtr, NativeRect> _naturalAnchorStartRects = [];
    private Dictionary<IntPtr, (int OffsetX, int OffsetY)> _naturalAnchorRawOffsets = [];
    private Dictionary<IntPtr, (int OffsetX, int OffsetY)> _naturalAnchorVisualOffsets = [];
    private NativeRect _naturalAnchorStartBounds;
    private DateTime _lastNaturalAnchorDragMoveUtc = DateTime.MinValue;
    private int _lastNaturalAnchorDragDx;
    private int _lastNaturalAnchorDragDy;
    private const int NaturalAnchorDragFrameMs = 16;
    private const int NaturalAnchorDragPixelThreshold = 1;
    private readonly PipGroupMouseDragService _pipMouseDragService;
    private const int PanelSlotWidth = 72;
    private const int PanelSlotHeight = 66;
    private const int PanelSlotGap = 6;
    private const int PanelSlotPadding = 8;
    private const double SlotSnapDistance = 14.0;
    private const int TopMostRefreshMs = 10000;
    private DateTime _lastTopMostRefreshUtc = DateTime.MinValue;

    public ObservableCollection<PipSlot> Slots { get; } = [];
    public ObservableCollection<EditableSlotRect> EditableSlots { get; } = [];
    public ObservableCollection<VideoTabInfo> VideoTabs { get; } = [];
    private readonly DispatcherTimer _videoTabsUiTimer;
    private readonly Dictionary<string, (VideoTabInfo Tab, DateTime LastSeenUtc)> _videoTabCache = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<int, (TabDiscoveryInfo Info, DateTime ObservedUtc)> _extensionTabDiscoveryByTabId = [];
    private DateTime _extensionTabDiscoverySnapshotUtc = DateTime.MinValue;
    private long _extensionTabDiscoverySnapshotGeneration;
    private string _extensionTabDiscoveryCorrelationId = string.Empty;
    private DateTime _lastAdvertisementFilterLogUtc = DateTime.MinValue;
    private bool _videoTabsDirty;
    private bool _autoRecoverPairInProgress;
    private DateTime _lastAutoRecoverPairUtc = DateTime.MinValue;
    // Abas em segundo plano podem ter timers/eventos de mídia retardados pelo navegador.
    // Mantemos o último estado bom tempo suficiente para uma varredura paralela completa,
    // sem confundir um atraso temporário com uma aba fechada.
    private const int VideoTabsCacheTtlSeconds = 30;
    private const int AutoRecoverPairCooldownMs = 1800;
    public PipSlot? SelectedSlot { get; set; }
    private bool _automaticReactorCaptureEnabled = true;
    private bool _initializationComplete;
    private bool _suppressAutomaticCaptureToggleEvents;
    private bool _suppressNativeLayoutModeEvents;
    private NativeLayoutEngineMode _nativeLayoutEngineMode = NativeLayoutEngineMode.Off;

    public MainWindow()
        : this(
            App.Services.GetRequiredService<SettingsService>(),
            App.Services.GetRequiredService<WindowDiscoveryService>(),
            App.Services.GetRequiredService<LayoutService>(),
            App.Services.GetRequiredService<MonitorService>(),
            App.Services.GetRequiredService<ExtensionBridgeService>(),
            App.Services.GetRequiredService<PipWindowService>(),
            App.Services.GetRequiredService<VideoCommandService>(),
            App.Services.GetRequiredService<IApplicationHealthService>(),
            App.Services.GetRequiredService<IWindowEventMonitorService>(),
            App.Services.GetRequiredService<IWindowEventReactorService>(),
            App.Services.GetRequiredService<IWindowEventFlowControlService>(),
            App.Services.GetRequiredService<IAutomationCoordinator>())
    {
    }

    public MainWindow(
        SettingsService settingsService,
        WindowDiscoveryService discovery,
        LayoutService layoutService,
        MonitorService monitorService,
        ExtensionBridgeService extensionBridge,
        PipWindowService pipWindowService,
        VideoCommandService videoCommandService,
        IApplicationHealthService applicationHealth,
        IWindowEventMonitorService windowEventMonitor,
        IWindowEventReactorService windowEventReactor,
        IWindowEventFlowControlService windowEventFlowControl,
        IAutomationCoordinator automationCoordinator)
    {
        _settingsService = settingsService;
        _discovery = discovery;
        _layoutService = layoutService;
        _monitorService = monitorService;
        _extensionBridge = extensionBridge;
        _pipWindowService = pipWindowService;
        _videoCommandService = videoCommandService;
        _applicationHealth = applicationHealth;
        _windowEventMonitor = windowEventMonitor;
        _windowEventReactor = windowEventReactor;
        _windowEventFlowControl = windowEventFlowControl;
        _automationCoordinator = automationCoordinator;

_pipMouseDragService = new PipGroupMouseDragService(NaturalAnchorDragStarted, NaturalAnchorDragDelta, NaturalAnchorDragCompleted);
        InitializeComponent();
        DataContext = this;
        _settings = _settingsService.Load();
        _nativeLayoutEngineMode = ParseNativeLayoutEngineMode(_settings.NativeLayoutEngineMode);
        PipWindowService.ConfigureNativeLayoutEngine(_nativeLayoutEngineMode);
        InitializeNativeLayoutEngineSelector();
        _automaticReactorCaptureEnabled = _settings.AutomaticReactorCaptureEnabled;
        _autoAdvanceOnVideoEndEnabled = _settings.AutoAdvanceOnVideoEndEnabled;
        _nextVideoPreviewEnabled = _settings.NextVideoPreviewEnabled;
        _nextVideoPreloadEnabled = _settings.NextVideoPreloadEnabled;
        _autoReturnPolicy = ParseAutoReturnPolicy(_settings.AutoReturnPolicy);
        _slotLayoutRects = _settings.SlotLayout.Select(item => item.ToRect()).Where(rect => rect.IsValid).ToList();
        _customLayoutActive = _settings.LayoutMode == LayoutMode.Custom;

        SetSlotCount(Math.Clamp(_settings.SlotCount, 1, 10));
        InitializeJogoManualPlacement();
        InitializeJogoFreeAreaAdjustment();
        InitializeJogoSpaceHideHotkey();
        _applicationHealth.SetSlotCount(Slots.Count);
        NormalizeSlotAutoReturnSettings(migrateFromGlobal: true);
        NormalizeSlotPreloadSettings();
        EnsureSlotLayoutRects();
        LoadCustomSlotRects();
        UpdatePipCountButton();
        InitializeMonitorSelector();
        InitializeFixedLayoutFeature();
        RefreshLayoutText();
        UpdatePanelSlotVisuals();
        RefreshAllSlotPairVisuals();

        RestoreWindowPlacement();
        Loaded += MainWindow_Loaded;
        Closing += MainWindow_Closing;

        _healthTimer = new DispatcherTimer(DispatcherPriority.Background) { Interval = TimeSpan.FromMilliseconds(HealthTimerIntervalMs) };
        _healthTimer.Tick += (_, _) =>
        {
            if (!_allHidden)
            {
                RefreshCapturedWindows();
                _windowEventMonitor.MarkPollingObserved("health-timer-after-refresh-captured-windows");
                var healthNow = DateTime.UtcNow;
                if (!IsPipOperationBusy()
                    && !_naturalAnchorDragActive
                    && !IsLayoutTransactionActive()
                    && (healthNow - _lastHealthDragTargetsRefreshUtc).TotalMilliseconds >= HealthDragTargetsRefreshMs)
                {
                    _lastHealthDragTargetsRefreshUtc = healthNow;
                    EnsureToolbarOutsidePips();
                    EnsureVisiblePipsTopMost();
                    RefreshPipDragTargets();
                }
            }
        };
        _healthTimer.Start();

        _liveCaptureTimer = new DispatcherTimer(DispatcherPriority.Background) { Interval = TimeSpan.FromMilliseconds(450) };
        _liveCaptureTimer.Tick += (_, _) => LiveCaptureTick();

        _armedPipPairTimer = new DispatcherTimer(DispatcherPriority.Background) { Interval = TimeSpan.FromMilliseconds(250) };
        _armedPipPairTimer.Tick += async (_, _) => await ArmedPipPairTickAsync();

        _videoTabsUiTimer = new DispatcherTimer(DispatcherPriority.Background) { Interval = TimeSpan.FromMilliseconds(800) };
        _videoTabsUiTimer.Tick += (_, _) => ApplyVideoTabsFromCache();
        _videoTabsUiTimer.Start();

        _autoReturnTimer = new DispatcherTimer(DispatcherPriority.Background) { Interval = TimeSpan.FromMilliseconds(950) };
        _autoReturnTimer.Tick += async (_, _) => await AutoReturnTickAsync();
        _autoReturnTimer.Start();

        _videoSwitchPreservationTimer = new DispatcherTimer(DispatcherPriority.Background) { Interval = TimeSpan.FromMilliseconds(650) };
        _videoSwitchPreservationTimer.Tick += (_, _) =>
        {
            ObserveVideoSwitchPreservationStates("timer");
            ExpireVideoSwitchPreservationStates();
        };
        _videoSwitchPreservationTimer.Start();

        UpdateAutoReturnPolicyVisual();
        _initializationComplete = true;
        UpdateConnectionAndAutomationUx();
        UpdateOpenPipButtonsState();
    }


    private static TaskCompletionSource<bool> CreatePipOperationAvailabilitySignal() =>
        new(TaskCreationOptions.RunContinuationsAsynchronously);

    private bool IsPipOperationBusy() =>
        _videoCommandBusy || _openPipAttemptInProgress || _openAllPipsInProgress;

    private void SignalPipOperationAvailability(string source)
    {
        TaskCompletionSource<bool> signal;
        lock (_pipOperationAvailabilitySync)
        {
            signal = _pipOperationAvailabilitySignal;
            _pipOperationAvailabilitySignal = CreatePipOperationAvailabilitySignal();
        }

        signal.TrySetResult(true);
        if (Volatile.Read(ref _pipOperationAvailabilityWaiters) > 0)
            AppLogger.Info($"pip-operation-availability-signaled: source={source}; waiters={Volatile.Read(ref _pipOperationAvailabilityWaiters)}; openAttempt={_openPipAttemptInProgress}; openAttemptSlot={_openPipAttemptSlotNumber}; videoCommandBusy={_videoCommandBusy}; openAll={_openAllPipsInProgress}");
    }

    private async Task WaitForPipOperationAvailabilityAsync(int timeoutMs)
    {
        Task signalTask;
        lock (_pipOperationAvailabilitySync)
        {
            if (!IsPipOperationBusy())
                return;
            signalTask = _pipOperationAvailabilitySignal.Task;
        }

        Interlocked.Increment(ref _pipOperationAvailabilityWaiters);
        try
        {
            await Task.WhenAny(signalTask, Task.Delay(Math.Max(25, timeoutMs)));
        }
        finally
        {
            Interlocked.Decrement(ref _pipOperationAvailabilityWaiters);
        }
    }

    private void OnWindowMonitorRelevantEventReceived(WindowMonitorEvent ev)
    {
        // Geometry is reconciled by the low-priority health refresh. Do not allocate a WPF
        // Dispatcher operation for every LOCATIONCHANGE emitted by Firefox.
        if (ev.Kind == WindowMonitorEventKind.MovedOrResized)
            return;

        Dispatcher.BeginInvoke(new Action(() => _ = HandleWindowMonitorRelevantEventAsync(ev)));
    }

    private void OnWindowEventReactorAssistedPipCandidateReady(WindowEventReactorPipCandidate candidate)
    {
        Dispatcher.BeginInvoke(() =>
        {
            _ = HandleWindowEventReactorAssistedPipCandidateAsync(candidate);
        });
    }

    // First functional reactor step: a Created/Shown event supplies an exact, validated HWND
    // to the prepared PiP flow. Legacy 250 ms discovery remains active as a fallback.
    private async Task HandleWindowEventReactorAssistedPipCandidateAsync(WindowEventReactorPipCandidate candidate)
    {
        if (!_automaticReactorCaptureEnabled)
        {
            AppLogger.Info($"window-event-reactor-assisted-capture-skipped: hwnd=0x{candidate.Window.Handle.ToInt64():X}; reason=automatic-capture-disabled");
            return;
        }

        if (_allHidden)
            return;

        var now = DateTime.UtcNow;
        foreach (var expired in _reactorAssistedCandidateCooldownUtc
                     .Where(item => item.Value <= now)
                     .Select(item => item.Key)
                     .ToList())
        {
            _reactorAssistedCandidateCooldownUtc.Remove(expired);
        }

        if (_reactorAssistedCandidateCooldownUtc.TryGetValue(candidate.Window.Handle, out var cooldownUntil) && now < cooldownUntil)
        {
            AppLogger.Info(
                $"window-event-reactor-assisted-capture-deduped: hwnd=0x{candidate.Window.Handle.ToInt64():X}; " +
                $"kind={candidate.SourceEvent.Kind}; reason=recent-candidate-cooldown");
            return;
        }

        TryRestorePreparedPipStateFromOpenAttempt("reactor-candidate-entry");

        var waitedForPreparedState = false;
        var tab = _armedPipPairTab;
        if (tab is null)
        {
            if (!_reactorAssistedPreArmWaitHandles.Add(candidate.Window.Handle))
            {
                AppLogger.Info(
                    $"window-event-reactor-assisted-capture-deduped: hwnd=0x{candidate.Window.Handle.ToInt64():X}; " +
                    $"kind={candidate.SourceEvent.Kind}; reason=pre-arm-wait-already-running");
                return;
            }

            try
            {
                waitedForPreparedState = true;
                var preArmDeadline = DateTime.UtcNow.AddMilliseconds(ReactorAssistedPreArmGraceMs);
                AppLogger.Info(
                    $"window-event-reactor-assisted-pre-arm-wait: hwnd=0x{candidate.Window.Handle.ToInt64():X}; " +
                    $"kind={candidate.SourceEvent.Kind}; graceMs={ReactorAssistedPreArmGraceMs}; " +
                    $"openAttempt={_openPipAttemptInProgress}; attemptSlot={_openPipAttemptSlotNumber}");

                while (DateTime.UtcNow < preArmDeadline && _armedPipPairTab is null)
                {
                    if (TryRestorePreparedPipStateFromOpenAttempt("reactor-pre-arm-wait"))
                        break;

                    if (Slots.Any(slot => slot.Window is not null && slot.Window.Handle == candidate.Window.Handle))
                    {
                        AppLogger.Info(
                            $"window-event-reactor-assisted-capture-deduped: hwnd=0x{candidate.Window.Handle.ToInt64():X}; " +
                            $"kind={candidate.SourceEvent.Kind}; reason=legacy-captured-during-pre-arm-wait");
                        return;
                    }

                    await Task.Delay(40);
                }

                tab = _armedPipPairTab;
            }
            finally
            {
                _reactorAssistedPreArmWaitHandles.Remove(candidate.Window.Handle);
            }

            if (tab is null)
            {
                AppLogger.Info(
                    $"window-event-reactor-assisted-candidate-observed: hwnd=0x{candidate.Window.Handle.ToInt64():X}; " +
                    $"kind={candidate.SourceEvent.Kind}; action=observe-only; reason=no-armed-prepared-pip-after-grace; " +
                    $"graceMs={ReactorAssistedPreArmGraceMs}");
                return;
            }
        }

        if (DateTime.UtcNow > _armedPipPairUntilUtc)
        {
            AppLogger.Info(
                $"window-event-reactor-assisted-candidate-ignored: hwnd=0x{candidate.Window.Handle.ToInt64():X}; " +
                $"kind={candidate.SourceEvent.Kind}; reason=prepared-window-expired");
            return;
        }

        var targetSlotNumber = _armedPipTargetSlotNumber;
        var targetSlot = Slots.FirstOrDefault(slot => slot.Number == targetSlotNumber);
        var activeAttemptOwnsTarget = !string.IsNullOrWhiteSpace(_activeAutoReturnAttemptId)
            && _activeAutoReturnSlotNumber == targetSlotNumber;
        var targetHasMismatchedWindow = targetSlot?.Window is not null
            && targetSlot.Window.Handle != candidate.Window.Handle
            && activeAttemptOwnsTarget;
        if (targetSlotNumber <= 0 || targetSlot is null ||
            (!targetHasMismatchedWindow && (targetSlot.Window is not null || targetSlot.State != PipSlotState.AwaitingPip)))
        {
            AppLogger.Info(
                $"window-event-reactor-assisted-candidate-ignored: hwnd=0x{candidate.Window.Handle.ToInt64():X}; " +
                $"kind={candidate.SourceEvent.Kind}; targetSlot={targetSlotNumber}; " +
                $"targetState={targetSlot?.State.ToString() ?? "missing"}; reason=target-slot-not-awaiting");
            return;
        }

        var eventUtc = candidate.SourceEvent.CreatedAtUtc.UtcDateTime;
        if (activeAttemptOwnsTarget
            && _activeAutoReturnAttemptStartedUtc != DateTime.MinValue
            && eventUtc >= _activeAutoReturnAttemptStartedUtc.AddMilliseconds(-250))
        {
            _autoReturnCandidateAttemptByHwnd[candidate.Window.Handle] = _activeAutoReturnAttemptId;
            AppLogger.Info($"auto-return-hwnd-claimed: attemptId={_activeAutoReturnAttemptId}; slot={targetSlotNumber}; hwnd=0x{candidate.Window.Handle.ToInt64():X}; eventUtc={eventUtc:O}; attemptStartedUtc={_activeAutoReturnAttemptStartedUtc:O}");
        }
        var candidatePrecedesArm = _armedPipPairStartedUtc != DateTime.MinValue && eventUtc < _armedPipPairStartedUtc;
        var preArmGapMs = candidatePrecedesArm
            ? Math.Max(0, (_armedPipPairStartedUtc - eventUtc).TotalMilliseconds)
            : 0;

        var matchingAttemptKey = BuildOpenPipAttemptKey(targetSlot, tab);
        var attemptCorrelated = _openPipAttemptInProgress
            && DateTime.UtcNow <= _openPipAttemptUntilUtc
            && _openPipAttemptSlotNumber == targetSlotNumber
            && string.Equals(_openPipAttemptKey, matchingAttemptKey, StringComparison.OrdinalIgnoreCase)
            && _openPipAttemptStartedUtc != DateTime.MinValue
            && eventUtc >= _openPipAttemptStartedUtc.AddMilliseconds(-ReactorAssistedPreArmGraceMs)
            && eventUtc <= _openPipAttemptUntilUtc;

        var preArmConfirmationSinceUtc = eventUtc.AddMilliseconds(-500);
        var matchingPreArmEnterEvent = candidatePrecedesArm
            ? FindRecentEnterPipEventFor(tab, preArmConfirmationSinceUtc)
            : null;
        var preArmCorrelated = candidatePrecedesArm
            && preArmGapMs <= ReactorAssistedPreArmGraceMs
            && (attemptCorrelated || matchingPreArmEnterEvent is not null);

        if (_armedPipPairStartedUtc != DateTime.MinValue
            && eventUtc < _armedPipPairStartedUtc.AddMilliseconds(-250)
            && !preArmCorrelated)
        {
            AppLogger.Info(
                $"window-event-reactor-assisted-candidate-ignored: hwnd=0x{candidate.Window.Handle.ToInt64():X}; " +
                $"kind={candidate.SourceEvent.Kind}; reason=event-before-prepared-window; preArmGapMs={preArmGapMs:0.0}; " +
                $"attemptCorrelated={attemptCorrelated}; enterEventCorrelated={matchingPreArmEnterEvent is not null}");
            return;
        }

        if (preArmCorrelated)
        {
            AppLogger.Info(
                $"window-event-reactor-assisted-pre-arm-correlated: hwnd=0x{candidate.Window.Handle.ToInt64():X}; " +
                $"kind={candidate.SourceEvent.Kind}; slot={targetSlotNumber}; pairKey={tab.PairKey}; " +
                $"preArmGapMs={preArmGapMs:0.0}; attemptCorrelated={attemptCorrelated}; " +
                $"enterEventCorrelated={matchingPreArmEnterEvent is not null}; waitedForPreparedState={waitedForPreparedState}");
        }

        if (_armedPipExistingHandles.Contains(candidate.Window.Handle) && !preArmCorrelated)
        {
            AppLogger.Info(
                $"window-event-reactor-assisted-candidate-ignored: hwnd=0x{candidate.Window.Handle.ToInt64():X}; " +
                $"kind={candidate.SourceEvent.Kind}; reason=handle-existed-before-arm");
            return;
        }

        if (_armedPipExistingHandles.Contains(candidate.Window.Handle) && preArmCorrelated)
        {
            AppLogger.Info(
                $"window-event-reactor-assisted-pre-arm-snapshot-bypass: hwnd=0x{candidate.Window.Handle.ToInt64():X}; " +
                $"kind={candidate.SourceEvent.Kind}; slot={targetSlotNumber}; reason=correlated-candidate-created-before-arm-snapshot");
        }

        if (Slots.Any(slot => slot.Window is not null && slot.Window.Handle == candidate.Window.Handle))
        {
            AppLogger.Info(
                $"window-event-reactor-assisted-capture-deduped: hwnd=0x{candidate.Window.Handle.ToInt64():X}; " +
                $"kind={candidate.SourceEvent.Kind}; reason=already-owned-by-slot");
            return;
        }

        _reactorAssistedCandidateCooldownUtc[candidate.Window.Handle] = DateTime.UtcNow.AddMilliseconds(ReactorAssistedCandidateCooldownMs);
        _armedPipCandidateWindow = candidate.Window;
        _armedPipCandidateDetectedUtc = DateTime.UtcNow;

        var confirmationSinceUtc = preArmCorrelated
            ? preArmConfirmationSinceUtc
            : _armedPipPairStartedUtc;
        var confirmedEvent = matchingPreArmEnterEvent ?? FindRecentEnterPipEventFor(tab, confirmationSinceUtc);
        if (confirmedEvent is not null)
        {
            TryCapturePreparedPipWindowFromReactor(candidate, tab, confirmedEvent, targetSlotNumber, "extension-event-already-confirmed");
            return;
        }

        var reactorMode = GetReactorCaptureMode();
        if (reactorMode == "legacy")
        {
            AppLogger.Info(
                $"window-event-reactor-candidate-observed: hwnd=0x{candidate.Window.Handle.ToInt64():X}; " +
                $"kind={candidate.SourceEvent.Kind}; action=observe-only; reason=reactor-mode-legacy");
            return;
        }

        var highTrustDirectMatch = attemptCorrelated
            && candidate.ValidationAttempt == 1
            && candidate.SourceEvent.Kind is WindowMonitorEventKind.Created or WindowMonitorEventKind.Shown;

        if (reactorMode == "primary" && highTrustDirectMatch)
        {
            AppLogger.Info(
                $"window-event-reactor-adaptive-confirmation: hwnd=0x{candidate.Window.Handle.ToInt64():X}; " +
                $"slot={targetSlotNumber}; mode=immediate; reason=exact-attempt-direct-hwnd-match; waitMs=0");
            TryCapturePreparedPipWindowFromReactor(candidate, tab, null, targetSlotNumber, "adaptive-immediate-exact-attempt-match");
            return;
        }

        var activeAutoReturnCandidate = attemptCorrelated
            && !string.IsNullOrWhiteSpace(_activeAutoReturnAttemptId)
            && _activeAutoReturnSlotNumber == targetSlotNumber;
        var confirmationWaitMs = activeAutoReturnCandidate
            ? ReactorAutoReturnConfirmationWaitMs
            : reactorMode == "primary"
                ? ReactorPrimaryShortConfirmationWaitMs
                : ReactorAssistedConfirmationWaitMs;
        var generation = unchecked(++_reactorAssistedCandidateGeneration);
        SetStatus($"Janela PiP detectada pelo Reactor. Aguardando confirmação adaptativa para {tab.ShortDescription}...");
        AppLogger.Info(
            $"window-event-reactor-assisted-capture-pending: hwnd=0x{candidate.Window.Handle.ToInt64():X}; " +
            $"kind={candidate.SourceEvent.Kind}; slot={targetSlotNumber}; pairKey={tab.PairKey}; " +
            $"validationAttempt={candidate.ValidationAttempt}; validationLatencyMs={candidate.ValidationLatencyMs:0.0}; " +
            $"confirmationWaitMs={confirmationWaitMs}; confirmationPollMs={ReactorAssistedConfirmationPollMs}; " +
            $"reactorMode={reactorMode}; preArmCorrelated={preArmCorrelated}; fallback=armed-pair-timer");

        await CompleteWindowEventReactorAssistedCaptureAsync(
            candidate,
            tab,
            targetSlotNumber,
            generation,
            confirmationSinceUtc,
            confirmationWaitMs,
            reactorMode);
    }

    private async Task CompleteWindowEventReactorAssistedCaptureAsync(
        WindowEventReactorPipCandidate candidate,
        VideoTabInfo tab,
        int targetSlotNumber,
        int generation,
        DateTime confirmationSinceUtc,
        int confirmationWaitMs,
        string reactorMode)
    {
        var deadline = DateTime.UtcNow.AddMilliseconds(confirmationWaitMs);

        while (DateTime.UtcNow < deadline)
        {
            await Task.Delay(ReactorAssistedConfirmationPollMs);

            if (!IsWindowEventReactorAssistedCandidateCurrent(candidate.Window.Handle, tab, targetSlotNumber, generation))
                return;

            var confirmedEvent = FindRecentEnterPipEventFor(tab, confirmationSinceUtc);
            if (confirmedEvent is not null)
            {
                TryCapturePreparedPipWindowFromReactor(candidate, tab, confirmedEvent, targetSlotNumber, "extension-event-confirmed-during-fast-wait");
                return;
            }
        }

        if (!IsWindowEventReactorAssistedCandidateCurrent(candidate.Window.Handle, tab, targetSlotNumber, generation))
            return;

        TryCapturePreparedPipWindowFromReactor(
            candidate,
            tab,
            null,
            targetSlotNumber,
            reactorMode == "primary"
                ? "adaptive-short-timeout-direct-hwnd-validated"
                : "compare-window-timeout-direct-hwnd-validated");
    }

    private static string GetReactorCaptureMode()
        => RuntimeAuthorityPolicy.ResolveWireValue();

    private bool IsWindowEventReactorAssistedCandidateCurrent(
        IntPtr hwnd,
        VideoTabInfo tab,
        int targetSlotNumber,
        int generation)
    {
        if (generation != _reactorAssistedCandidateGeneration)
            return false;

        TryRestorePreparedPipStateFromOpenAttempt("reactor-current-check");

        if (_armedPipPairTab is null ||
            !string.Equals(_armedPipPairTab.PairKey, tab.PairKey, StringComparison.OrdinalIgnoreCase))
            return false;

        if (_armedPipTargetSlotNumber != targetSlotNumber || DateTime.UtcNow > _armedPipPairUntilUtc)
            return false;

        if (_armedPipCandidateWindow is null && _discovery.TryGetPipWindow(hwnd, out var restoredCandidate, out _) && restoredCandidate is not null)
            _armedPipCandidateWindow = restoredCandidate;

        if (_armedPipCandidateWindow is null || _armedPipCandidateWindow.Handle != hwnd)
            return false;

        if (Slots.Any(slot => slot.Window is not null && slot.Window.Handle == hwnd))
            return false;

        var targetSlot = Slots.FirstOrDefault(slot => slot.Number == targetSlotNumber);
        return targetSlot is not null && targetSlot.Window is null && targetSlot.State == PipSlotState.AwaitingPip;
    }

    private bool TryCapturePreparedPipWindowFromReactor(
        WindowEventReactorPipCandidate candidate,
        VideoTabInfo tab,
        VideoPipEventInfo? confirmedEvent,
        int targetSlotNumber,
        string confirmationMode)
    {
        TryRestorePreparedPipStateFromOpenAttempt("reactor-final-capture");

        if (_armedPipPairTab is null ||
            !string.Equals(_armedPipPairTab.PairKey, tab.PairKey, StringComparison.OrdinalIgnoreCase) ||
            _armedPipTargetSlotNumber != targetSlotNumber)
            return false;

        var candidateOwner = Slots.FirstOrDefault(slot => slot.Window is not null && slot.Window.Handle == candidate.Window.Handle);
        var claimedByCurrentAttempt = !string.IsNullOrWhiteSpace(_activeAutoReturnAttemptId)
            && _autoReturnCandidateAttemptByHwnd.TryGetValue(candidate.Window.Handle, out var candidateClaim)
            && string.Equals(candidateClaim, _activeAutoReturnAttemptId, StringComparison.Ordinal);
        if (candidateOwner is not null && candidateOwner.Number != targetSlotNumber && !claimedByCurrentAttempt)
        {
            AppLogger.Info(
                $"window-event-reactor-assisted-capture-deduped: hwnd=0x{candidate.Window.Handle.ToInt64():X}; " +
                $"kind={candidate.SourceEvent.Kind}; ownerSlot={candidateOwner.Number}; reason=already-owned-unclaimed");
            return false;
        }
        if (candidateOwner is not null && candidateOwner.Number != targetSlotNumber && claimedByCurrentAttempt)
        {
            AppLogger.Warn($"auto-return-hwnd-owner-mismatch: attemptId={_activeAutoReturnAttemptId}; expectedSlot={targetSlotNumber}; ownerSlot={candidateOwner.Number}; hwnd=0x{candidate.Window.Handle.ToInt64():X}; action=reject-owned-by-other-slot-reactor");
            return false;
        }

        if (!_discovery.TryGetPipWindow(candidate.Window.Handle, out var currentWindow, out var rejectionReason) || currentWindow is null)
        {
            AppLogger.Info(
                $"window-event-reactor-assisted-capture-deferred: hwnd=0x{candidate.Window.Handle.ToInt64():X}; " +
                $"kind={candidate.SourceEvent.Kind}; reason=final-direct-validation-failed:{rejectionReason}; fallback=armed-pair-timer");
            return false;
        }

        var targetSlot = Slots.FirstOrDefault(slot => slot.Number == targetSlotNumber);
        var targetMismatch = targetSlot?.Window is not null && targetSlot.Window.Handle != candidate.Window.Handle && claimedByCurrentAttempt;
        if (targetSlot is null || (!targetMismatch && (targetSlot.Window is not null || targetSlot.State != PipSlotState.AwaitingPip)))
        {
            AppLogger.Info(
                $"window-event-reactor-assisted-capture-deferred: hwnd=0x{candidate.Window.Handle.ToInt64():X}; " +
                $"kind={candidate.SourceEvent.Kind}; targetSlot={targetSlotNumber}; " +
                $"targetState={targetSlot?.State.ToString() ?? "missing"}; reason=target-slot-no-longer-awaiting");
            return false;
        }

        if (targetMismatch)
        {
            AppLogger.Warn($"auto-return-target-slot-hwnd-mismatch: attemptId={_activeAutoReturnAttemptId}; slot={targetSlotNumber}; capturedHwnd=0x{targetSlot!.Window!.Handle.ToInt64():X}; newHwnd=0x{currentWindow.Handle.ToInt64():X}; action=reassociate-reactor-candidate");
        }

        var acceptedUtc = DateTimeOffset.UtcNow;
        var windowToCaptureMs = Math.Max(0, (acceptedUtc - candidate.SourceEvent.CreatedAtUtc).TotalMilliseconds);
        var commandToCaptureMs = _openPipAttemptStartedUtc == DateTime.MinValue
            ? -1
            : Math.Max(0, (acceptedUtc.UtcDateTime - _openPipAttemptStartedUtc).TotalMilliseconds);
        AppLogger.Info(
            $"window-event-reactor-assisted-capture-accepted: hwnd=0x{currentWindow.Handle.ToInt64():X}; " +
            $"kind={candidate.SourceEvent.Kind}; slot={targetSlotNumber}; pairKey={tab.PairKey}; " +
            $"confirmation={confirmationMode}; reactorMode={GetReactorCaptureMode()}; validationAttempt={candidate.ValidationAttempt}; " +
            $"validationLatencyMs={candidate.ValidationLatencyMs:0.0}; windowToCaptureMs={windowToCaptureMs:0.0}; " +
            $"commandToCaptureMs={commandToCaptureMs:0.0}; fallbackUsed=False; action=CapturePreparedPipWindow");

        ClearArmedPipPairState(stopTimer: true);
        CapturePreparedPipWindow(currentWindow, tab, confirmedEvent, targetSlotNumber);
        return true;
    }

    private static string BuildWindowEventAssistedCooldownKey(WindowMonitorEvent ev)
    {
        var hwnd = ev.Hwnd.ToInt64().ToString("X");

        return ev.Kind switch
        {
            WindowMonitorEventKind.Destroyed or WindowMonitorEventKind.Hidden => $"loss:{hwnd}",
            WindowMonitorEventKind.Created or WindowMonitorEventKind.Shown => $"appearance:{hwnd}:{ev.Kind}",
            _ => $"{ev.Kind}:{hwnd}"
        };
    }

    private void CleanupWindowEventAssistedCooldowns()
    {
        var now = DateTime.UtcNow;
        if ((now - _lastWindowEventAssistedCooldownCleanupUtc).TotalSeconds < WindowEventAssistedCooldownCleanupSeconds)
            return;

        _lastWindowEventAssistedCooldownCleanupUtc = now;

        var expired = _windowEventAssistedCooldownUtc
            .Where(item => item.Value < now)
            .Select(item => item.Key)
            .ToList();

        foreach (var key in expired)
            _windowEventAssistedCooldownUtc.Remove(key);

        if (expired.Count > 0)
            AppLogger.Info($"window-event-assisted-cooldown-cleanup: removed={expired.Count}; remaining={_windowEventAssistedCooldownUtc.Count}");
    }

    // CHECK_MARKER: event-assisted-Created / event-assisted-Shown / event-assisted-Destroyed / event-assisted-Hidden
    // Eventos aceleram o fluxo existente, mas não tomam decisão final sozinhos.
    private async Task HandleWindowMonitorRelevantEventAsync(WindowMonitorEvent ev)
    {
        if (_allHidden)
            return;

        CleanupWindowEventAssistedCooldowns();

        var key = BuildWindowEventAssistedCooldownKey(ev);
        var now = DateTime.UtcNow;
        if (_windowEventAssistedCooldownUtc.TryGetValue(key, out var until) && now < until)
        {
            AppLogger.Info($"window-event-assisted-deduped: kind={ev.Kind}; hwnd=0x{ev.Hwnd.ToInt64():X}; key={key}");
            return;
        }

        _windowEventAssistedCooldownUtc[key] = now.AddMilliseconds(180);

        try
        {
            // Movimentos produzidos pelo próprio layout não precisam atravessar o Shadow/Automation
            // nem gerar uma decisão por HWND. Isso evita tempestades de trabalho durante operações
            // atômicas com muitos PiPs, sem esconder redimensionamentos realmente externos.
            if (ev.Kind == WindowMonitorEventKind.MovedOrResized && IsLayoutTransactionActive())
            {
                var alreadyLoggedThisGeneration = _lastLayoutSelfMoveGenerationByHwnd.TryGetValue(ev.Hwnd, out var loggedGeneration)
                    && loggedGeneration == _layoutTransactionGeneration;
                _lastLayoutSelfMoveGenerationByHwnd[ev.Hwnd] = _layoutTransactionGeneration;
                if (!alreadyLoggedThisGeneration)
                    AppLogger.Info($"window-event-layout-self-move-suppressed: hwnd=0x{ev.Hwnd.ToInt64():X}; generation={_layoutTransactionGeneration}");
                _windowEventMonitor.MarkPollingObserved("event-assisted-layout-self-move");
                return;
            }

            // Movement is geometry telemetry, not an automation state transition. Internal movement is
            // discarded upstream by WindowEventFlowControlService; remaining external movement is
            // reconciled by the low-priority health refresh without entering Shadow or polling compare.
            if (ev.Kind == WindowMonitorEventKind.MovedOrResized)
                return;

            var automationSlot = Slots.FirstOrDefault(item => item.Window is not null && item.Window.Handle == ev.Hwnd)?.Number ?? 0;
            _automationCoordinator.ObserveWindowEvent(ev, automationSlot);

            switch (ev.Kind)
            {
                case WindowMonitorEventKind.Created:
                case WindowMonitorEventKind.Shown:
                    CancelWindowLossDebounce(ev.Hwnd, $"event-assisted-{ev.Kind}");
                    if (!string.IsNullOrWhiteSpace(_activeAutoReturnAttemptId)
                        && _activeAutoReturnSlotNumber > 0
                        && _activeAutoReturnAttemptStartedUtc != DateTime.MinValue
                        && ev.CreatedAtUtc.UtcDateTime >= _activeAutoReturnAttemptStartedUtc.AddMilliseconds(-250))
                    {
                        _autoReturnCandidateAttemptByHwnd[ev.Hwnd] = _activeAutoReturnAttemptId;
                        AppLogger.Info($"auto-return-hwnd-preclaimed: attemptId={_activeAutoReturnAttemptId}; slot={_activeAutoReturnSlotNumber}; hwnd=0x{ev.Hwnd.ToInt64():X}; kind={ev.Kind}; eventUtc={ev.CreatedAtUtc.UtcDateTime:O}");
                    }
                    AppLogger.Info($"window-event-assisted-search: kind={ev.Kind}; hwnd=0x{ev.Hwnd.ToInt64():X}; mode=assisted; action=refresh-and-autoreturn-tick");
                    RefreshCapturedWindows();
                    _windowEventMonitor.MarkPollingObserved($"event-assisted-{ev.Kind}");
                    if (_liveCaptureActive)
                        LiveCaptureTick();
                    await AutoReturnTickAsync();
                    break;

                case WindowMonitorEventKind.Destroyed:
                case WindowMonitorEventKind.Hidden:
                    var slot = Slots.FirstOrDefault(item => item.Window is not null && item.Window.Handle == ev.Hwnd);
                    var lossDebounceMs = GetWindowLossDebounceMs(slot?.Number ?? 0);
                    AppLogger.Info($"window-event-assisted-loss-deferred: kind={ev.Kind}; hwnd=0x{ev.Hwnd.ToInt64():X}; slot={slot?.Number.ToString() ?? "-"}; debounceMs={lossDebounceMs}; mode=assisted; fastNavigation={lossDebounceMs == WindowLossNavigationDebounceMs}");
                    ScheduleWindowLossDebounce(ev, slot?.Number ?? 0, lossDebounceMs);
                    break;

                case WindowMonitorEventKind.MovedOrResized:
                    AppLogger.Info($"window-event-assisted-observed: kind={ev.Kind}; hwnd=0x{ev.Hwnd.ToInt64():X}; mode=assisted; action=compare-only");
                    _windowEventMonitor.MarkPollingObserved($"event-assisted-{ev.Kind}");
                    break;

                case WindowMonitorEventKind.TitleChanged:
                case WindowMonitorEventKind.ForegroundChanged:
                    AppLogger.Info($"window-event-assisted-observed: kind={ev.Kind}; hwnd=0x{ev.Hwnd.ToInt64():X}; mode=assisted; action=compare-only");
                    _windowEventMonitor.MarkPollingObserved($"event-assisted-{ev.Kind}");
                    break;
            }
        }
        catch (Exception ex)
        {
            AppLogger.Warn($"window-event-assisted-failed: kind={ev.Kind}; hwnd=0x{ev.Hwnd.ToInt64():X}; error={ex.Message}");
            _applicationHealth.ReportOperationalError(ex.Message);
        }
    }

    private void CancelWindowLossDebounce(IntPtr hwnd, string source)
    {
        if (hwnd == IntPtr.Zero) return;
        var generation = _windowLossDebounceGenerationByHwnd.TryGetValue(hwnd, out var current) ? current + 1 : 1;
        _windowLossDebounceGenerationByHwnd[hwnd] = generation;
        AppLogger.Info($"window-event-loss-debounce-cancelled: hwnd=0x{hwnd.ToInt64():X}; generation={generation}; source={source}");
    }

    private int GetWindowLossDebounceMs(int slotNumber)
    {
        if (slotNumber > 0
            && _videoSwitchPreservationBySlot.TryGetValue(slotNumber, out var state)
            && IsVideoSwitchPreservationStateAlive(state)
            && (string.Equals(state.CommandType, "next", StringComparison.OrdinalIgnoreCase)
                || string.Equals(state.CommandType, "previous", StringComparison.OrdinalIgnoreCase)))
        {
            return WindowLossNavigationDebounceMs;
        }

        // An indexed playlist can advance naturally without a Next command. The fresh
        // extension snapshot often exposes the new ?index= URL before Firefox destroys
        // the old PiP HWND, so treat that exact evidence as navigation instead of waiting
        // the generic 1.2 s transient-loss debounce.
        if (slotNumber > 0
            && _slotPairedTabIds.TryGetValue(slotNumber, out var pairedTabId)
            && pairedTabId > 0
            && _slotPairUrls.TryGetValue(slotNumber, out var oldUrl)
            && !string.IsNullOrWhiteSpace(oldUrl)
            && oldUrl.Contains("/playlists/", StringComparison.OrdinalIgnoreCase))
        {
            var normalizedOldUrl = NormalizeAutoReturnIdentityUrl(oldUrl);
            var playlistAdvanced = _videoTabCache.Values
                .Select(item => item.Tab)
                .Any(tab => tab.TabId == pairedTabId
                    && !string.IsNullOrWhiteSpace(tab.Url)
                    && tab.Url.Contains("/playlists/", StringComparison.OrdinalIgnoreCase)
                    && !string.Equals(
                        NormalizeAutoReturnIdentityUrl(tab.Url),
                        normalizedOldUrl,
                        StringComparison.OrdinalIgnoreCase));

            if (playlistAdvanced)
            {
                AppLogger.Info($"window-loss-fast-playlist-advance: slot={slotNumber}; tabId={pairedTabId}; oldUrl={oldUrl}; debounceMs={WindowLossNavigationDebounceMs}");
                return WindowLossNavigationDebounceMs;
            }
        }

        return WindowLossDebounceMs;
    }

    private void ScheduleWindowLossDebounce(WindowMonitorEvent ev, int slotNumber, int debounceMs)
    {
        var hwnd = ev.Hwnd;
        var generation = _windowLossDebounceGenerationByHwnd.TryGetValue(hwnd, out var current) ? current + 1 : 1;
        _windowLossDebounceGenerationByHwnd[hwnd] = generation;

        var reservedSlot = Slots.FirstOrDefault(item => item.Number == slotNumber);
        var identityReserved = reservedSlot is not null
            && AutoReturnBurstPolicy.ShouldPreserveLostSlot(
                IsAutoReturnEnabledForSlot(slotNumber),
                SlotHasPairRecoverySignal(slotNumber));
        if (identityReserved)
        {
            AppLogger.Info(
                $"window-event-loss-identity-reserved: kind={ev.Kind}; hwnd=0x{hwnd.ToInt64():X}; " +
                $"slot={slotNumber}; generation={generation}; debounceMs={debounceMs}; " +
                "pairMetadataPreserved=True; pendingAdmission=after-debounce");
        }

        _ = Dispatcher.InvokeAsync(async () =>
        {
            await Task.Delay(debounceMs);
            if (!_windowLossDebounceGenerationByHwnd.TryGetValue(hwnd, out var activeGeneration) || activeGeneration != generation)
                return;

            _windowLossDebounceGenerationByHwnd.Remove(hwnd);
            var stillOwned = Slots.Any(item => item.Window is not null && item.Window.Handle == hwnd);
            var stillUsable = stillOwned && PipWindowService.IsUsable(hwnd);
            if (stillUsable)
            {
                AppLogger.Info($"window-event-loss-debounce-suppressed: kind={ev.Kind}; hwnd=0x{hwnd.ToInt64():X}; slot={slotNumber}; reason=window-usable-after-transient-event");
                return;
            }

            AppLogger.Warn($"window-event-loss-debounce-confirmed: kind={ev.Kind}; hwnd=0x{hwnd.ToInt64():X}; slot={slotNumber}; debounceMs={debounceMs}; action=refresh-and-autoreturn-tick");
            RefreshCapturedWindows();
            _windowEventMonitor.MarkPollingObserved($"event-assisted-{ev.Kind}-debounced");
            await AutoReturnTickAsync();
        });
    }

    private void TitleDragRegion_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (e.ClickCount == 2)
        {
            MaximizeButton_Click(sender, e);
            return;
        }

        if (e.LeftButton != MouseButtonState.Pressed) return;

        try
        {
            DragMove();
        }
        catch
        {
            // Ignora quando o Windows cancela o arraste por perda de foco.
        }
    }

    private void MainWindow_Loaded(object sender, RoutedEventArgs e)
    {
        _toolbar = new FloatingToolbarWindow
        {
            ArrangeRequested = ToggleLockMode,
            EqualizeRequested = EqualizeCaptured,
            VisibilityRequested = ToggleAllVisibility,
            ExpandRequested = ShowPanel,
            GroupMoveRequested = MoveCapturedGroup,
            AutoPositionRequested = PositionToolbar,
            ToolbarStateChanged = SaveSettings
        };
        _toolbar.Show();
        _toolbar.SetLockState(_groupLocked);
        UpdateMainQuickActionLabels();
        AutomaticCaptureToggle.IsChecked = _automaticReactorCaptureEnabled;
        UpdateAutoAdvanceOnEndVisual();
        UpdateNextPreviewVisual();
        UpdateNextPreloadVisual();
        UpdateConnectionAndAutomationUx();
        _extensionBridge.StatusChanged += message => Dispatcher.BeginInvoke(() => OnExtensionBridgeStatusChanged(message));
        _extensionBridge.VideoTabsUpdated += tabs => Dispatcher.BeginInvoke(() => MergeVideoTabsSnapshot(tabs));
        _extensionBridge.TabDiscoveryUpdated += (correlationId, tabs) => Dispatcher.BeginInvoke(() => MergeTabDiscoverySnapshot(correlationId, tabs));
        _extensionBridge.PictureInPictureEventReceived += info => Dispatcher.BeginInvoke(() => OnPictureInPictureEvent(info));
        _extensionBridge.PlaybackTerminalReceived += info => Dispatcher.BeginInvoke(() => _ = HandlePlaybackTerminalAsync(info));
        _extensionBridge.CommandResultReceived += info => Dispatcher.BeginInvoke(() => _ = HandleVideoCommandResultAsync(info));
        _windowEventMonitor.RelevantEventReceived += OnWindowMonitorRelevantEventReceived;
        _windowEventReactor.AssistedPipCandidateReady += OnWindowEventReactorAssistedPipCandidateReady;
        // ExtensionBridgeService lifecycle is owned by Generic Host.
        _toolbar.RestoreManualCollapsedPosition(_settings.ToolbarCollapsedLeft, _settings.ToolbarCollapsedTop);
        _pipMouseDragService.Start();
        ActivateJogoSpaceHideHotkey();
        _applicationHealth.SetPipDragHookActive(true);
        _applicationHealth.SetSlotCount(Slots.Count);
        PositionToolbar();
        RefreshPipDragTargets();
        LocationChanged += (_, _) => ScheduleNextPreviewUpdate();
        SizeChanged += (_, _) => ScheduleNextPreviewUpdate();
        ActivateLoadedFixedLayout();
    }


    private static string ExtractKeyValue(string text, string key)
    {
        var token = key + "=";
        var index = text.IndexOf(token, StringComparison.OrdinalIgnoreCase);
        if (index < 0) return string.Empty;

        var start = index + token.Length;
        var end = text.IndexOf(';', start);
        if (end < 0) end = text.Length;

        return text[start..end].Trim();
    }

    private TaskCompletionSource<bool> ArmSilentPreflightResultWait(string attemptId)
    {
        var signal = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
        lock (_silentPreflightWaitSync)
        {
            _silentPreflightWaitAttemptId = attemptId;
            _silentPreflightWaitSignal = signal;
        }
        return signal;
    }

    private void SignalSilentPreflightResultWait(string attemptId)
    {
        TaskCompletionSource<bool>? signal = null;
        lock (_silentPreflightWaitSync)
        {
            if (string.Equals(_silentPreflightWaitAttemptId, attemptId, StringComparison.OrdinalIgnoreCase))
                signal = _silentPreflightWaitSignal;
        }
        signal?.TrySetResult(true);
    }

    private void ClearSilentPreflightResultWait(string attemptId)
    {
        lock (_silentPreflightWaitSync)
        {
            if (!string.Equals(_silentPreflightWaitAttemptId, attemptId, StringComparison.OrdinalIgnoreCase))
                return;
            _silentPreflightWaitAttemptId = string.Empty;
            _silentPreflightWaitSignal = null;
        }
    }

    private static bool IsSilentPreflightHardBlockReason(string reasonCode)
    {
        return string.Equals(reasonCode, "pip-api-disabled", StringComparison.OrdinalIgnoreCase)
            || string.Equals(reasonCode, "pip-method-unavailable", StringComparison.OrdinalIgnoreCase)
            || string.Equals(reasonCode, "pip-disabled-by-video", StringComparison.OrdinalIgnoreCase)
            || string.Equals(reasonCode, "video-ended", StringComparison.OrdinalIgnoreCase)
            || string.Equals(reasonCode, "content-version-mismatch", StringComparison.OrdinalIgnoreCase);
    }

    private static bool IsSilentPreflightReadinessReason(string? reasonCode)
    {
        return string.Equals(reasonCode, "player-not-ready", StringComparison.OrdinalIgnoreCase)
            || string.Equals(reasonCode, "video-not-ready", StringComparison.OrdinalIgnoreCase);
    }

    private static bool IsSilentReopenImmediateFallbackReason(string? reasonCode)
    {
        return string.Equals(reasonCode, "gesture-required", StringComparison.OrdinalIgnoreCase)
            || IsSilentPreflightReadinessReason(reasonCode);
    }

    private void OnExtensionBridgeStatusChanged(string message)
    {
        // Defensive guard: content-script diagnostics are support telemetry, not UI status.
        // Posting hundreds of iframe diagnostics to the Dispatcher can visibly stall WPF.
        if (!string.IsNullOrWhiteSpace(message)
            && message.StartsWith("Content script ativo", StringComparison.OrdinalIgnoreCase))
            return;

        if (!string.IsNullOrWhiteSpace(message)
            && message.StartsWith("Extensão conectada e autenticada", StringComparison.OrdinalIgnoreCase))
        {
            _lastPreloadSentByTab.Clear();
            foreach (var slot in Slots) _ = ApplySlotPreloadSettingAsync(slot.Number, ResolvePairedVideoTab(slot.Number));
        }

        try
        {
            LogMultiFrameAppPlayerStateSummary(message, "OnExtensionBridgeStatusChanged");
        }
        catch { }

        if (!string.IsNullOrWhiteSpace(message) && message.StartsWith("SilentPreflight ", StringComparison.OrdinalIgnoreCase))
        {
            _lastSilentPreflightAttemptId = ExtractKeyValue(message, "attemptId");
            _lastSilentPreflightReasonCode = ExtractKeyValue(message, "reasonCode");
            _lastSilentPreflightReasonMessage = ExtractKeyValue(message, "reasonMessage");
            _lastSilentPreflightResult = ExtractKeyValue(message, "result");
            _lastSilentPreflightDomain = ExtractKeyValue(message, "domain");
            _ = int.TryParse(ExtractKeyValue(message, "tabId"), out _lastSilentPreflightTabId);
            _ = int.TryParse(ExtractKeyValue(message, "frameId"), out _lastSilentPreflightFrameId);
            _lastSilentPreflightOk = string.Equals(ExtractKeyValue(message, "ok"), "True", StringComparison.OrdinalIgnoreCase)
                || string.Equals(ExtractKeyValue(message, "ok"), "true", StringComparison.OrdinalIgnoreCase);
            SignalSilentPreflightResultWait(_lastSilentPreflightAttemptId);
            AppLogger.Info($"silent-preflight-result-cached: attemptId={_lastSilentPreflightAttemptId}; ok={_lastSilentPreflightOk}; result={_lastSilentPreflightResult}; reasonCode={_lastSilentPreflightReasonCode}; reasonMessage={_lastSilentPreflightReasonMessage}; domain={_lastSilentPreflightDomain}; tabId={_lastSilentPreflightTabId}; frameId={_lastSilentPreflightFrameId}; preciseKey={BuildSilentReopenPreciseCooldownKey(_lastSilentPreflightDomain, _lastSilentPreflightFrameId, _lastSilentPreflightReasonCode)}");
            return;
        }

        if (!string.IsNullOrWhiteSpace(message) && message.StartsWith("Silencioso ", StringComparison.OrdinalIgnoreCase))
        {
            var reasonCode = ExtractBracketValue(message);
            if (!string.IsNullOrWhiteSpace(reasonCode))
            {
                _lastSilentExtensionReasonCode = reasonCode;
                _lastSilentExtensionReasonMessage = message;
                _lastSilentExtensionEnterPipSeen = message.Contains("enterpip", StringComparison.OrdinalIgnoreCase)
                    || message.Contains("already-in-pip", StringComparison.OrdinalIgnoreCase);
                AppLogger.Info($"silent-extension-result-cached: attemptId={_lastSilentAttemptId}; reasonCode={_lastSilentExtensionReasonCode}; message={message}");
            }
        }

        UpdateConnectionAndAutomationUx();
        SetStatus(message);
    }

    private static string ExtractBracketValue(string text)
    {
        var start = text.IndexOf('[');
        var end = text.IndexOf(']', start + 1);
        if (start >= 0 && end > start)
            return text.Substring(start + 1, end - start - 1).Trim();

        return string.Empty;
    }

    private static AutoReturnPolicy ParseAutoReturnPolicy(string? value)
        => AutoReturnPolicyCodec.Parse(value);

    private static string FormatAutoReturnPolicy(AutoReturnPolicy policy) =>
        AutoReturnPolicyCodec.Format(policy);

    private bool IsAnySlotAutoReturnEnabled()
    {
        NormalizeSlotAutoReturnSettings(migrateFromGlobal: false);
        return _slotAutoReturnDiscreteBySlot.Values.Any(value => value);
    }

    private bool IsAutoReturnEnabledForSlot(int slotNumber)
    {
        NormalizeSlotAutoReturnSettings(migrateFromGlobal: false);
        return _slotAutoReturnDiscreteBySlot.TryGetValue(slotNumber, out var enabled) && enabled;
    }

    private void NormalizeSlotAutoReturnSettings(bool migrateFromGlobal)
    {
        var slotNumbers = Slots.Count > 0
            ? Slots.Select(slot => slot.Number).Distinct().OrderBy(number => number).ToList()
            : Enumerable.Range(1, Math.Clamp(_settings.SlotCount, 1, 10)).ToList();

        var hasPersistedSlotSettings = _settings.AutoReturnDiscreteBySlot is { Count: > 0 };
        var globalEnabled = _autoReturnPolicy == AutoReturnPolicy.Discrete;

        _slotAutoReturnDiscreteBySlot.Clear();

        foreach (var slotNumber in slotNumbers)
        {
            var enabled = hasPersistedSlotSettings && _settings.AutoReturnDiscreteBySlot.TryGetValue(slotNumber, out var saved)
                ? saved
                : globalEnabled;

            _slotAutoReturnDiscreteBySlot[slotNumber] = enabled;
        }

        foreach (var item in _settings.AutoReturnDiscreteBySlot
                     .Where(item => item.Key >= 1 && item.Key <= 10 && !slotNumbers.Contains(item.Key)))
        {
            _slotAutoReturnDiscreteBySlot[item.Key] = item.Value;
        }

        _settings.AutoReturnDiscreteBySlot = _slotAutoReturnDiscreteBySlot
            .Where(item => item.Key >= 1 && item.Key <= 10)
            .OrderBy(item => item.Key)
            .ToDictionary(item => item.Key, item => item.Value);

        _autoReturnPolicy = _slotAutoReturnDiscreteBySlot.Values.Any(value => value)
            ? AutoReturnPolicy.Discrete
            : AutoReturnPolicy.Off;

        _settings.AutoReturnPolicy = _autoReturnPolicy.ToString();
        _settings.AutomaticReactorCaptureEnabled = _automaticReactorCaptureEnabled;
        _settings.NextVideoPreviewEnabled = _nextVideoPreviewEnabled;
        _settings.NextVideoPreloadEnabled = _nextVideoPreloadEnabled;
        _settings.AutoAdvanceOnVideoEndEnabled = _autoAdvanceOnVideoEndEnabled;
        _settings.LayoutMonitorDeviceName = GetSelectedLayoutMonitor()?.DeviceName ?? string.Empty;
        _settings.NativeLayoutEngineMode = _nativeLayoutEngineMode.ToString();

        foreach (var slot in Slots)
            slot.IsAutoReturnEnabled = _slotAutoReturnDiscreteBySlot.TryGetValue(slot.Number, out var slotEnabled) && slotEnabled;

        foreach (var editable in EditableSlots)
            editable.IsAutoReturnEnabled = _slotAutoReturnDiscreteBySlot.TryGetValue(editable.Number, out var editableEnabled) && editableEnabled;

        if (migrateFromGlobal && !hasPersistedSlotSettings)
        {
            AppLogger.Info($"auto-return-slot-settings-migrated: fromGlobal={globalEnabled}; slots={string.Join(",", _settings.AutoReturnDiscreteBySlot.Select(item => $"{item.Key}:{item.Value}"))}");
        }
    }

    private bool ShouldAutoReturnSlot(PipSlot slot, string context, bool logSkip = true)
    {
        if (slot is null)
            return false;

        NormalizeSlotAutoReturnSettings(migrateFromGlobal: false);

        if (!IsAnySlotAutoReturnEnabled())
        {
            if (logSkip)
                AppLogger.Info($"auto-return-skipped-global-disabled: context={context}; slot={slot.Number}");
            return false;
        }

        if (!IsAutoReturnEnabledForSlot(slot.Number))
        {
            if (logSkip)
            {
                var hasPairSignal = SlotHasPairRecoverySignal(slot.Number);
                var hasVideoPair = SlotHasVideoPair(slot);
                var hasWindow = slot.Window is not null;
                var usableWindow = slot.Window is not null && PipWindowService.IsUsable(slot.Window.Handle);
                var settingsValue = _settings.AutoReturnDiscreteBySlot.TryGetValue(slot.Number, out var savedEnabled) ? savedEnabled.ToString() : "missing";
                AppLogger.Info($"auto-return-skipped-slot-disabled: context={context}; slot={slot.Number}; shouldAutoReturn=False; disabledReason=slot-auto-return-off; slotEnabled=False; autoReturnPolicy={_autoReturnPolicy}; settingsValue={settingsValue}; state={slot.State}; isHidden={slot.IsHidden}; hasWindow={hasWindow}; usableWindow={usableWindow}; hasVideoPair={hasVideoPair}; hasPairSignal={hasPairSignal}");
            }
            return false;
        }

        if (!SlotHasPairRecoverySignal(slot.Number))
        {
            if (logSkip)
                AppLogger.Info($"auto-return-skipped-no-pair-signal: context={context}; slot={slot.Number}");
            return false;
        }

        return true;
    }

    private void UpdateAutoReturnPolicyVisual()
    {
        NormalizeSlotAutoReturnSettings(migrateFromGlobal: false);

        if (AutoReturnQuickButton is not null)
        {
            var enabled = _slotAutoReturnDiscreteBySlot.Count(item => item.Value);
            var total = Slots.Count > 0 ? Slots.Count : Math.Clamp(_settings.SlotCount, 1, 10);
            AutoReturnQuickButton.Content = enabled > 0
                ? $"Auto: Slots {enabled}/{total}"
                : "Auto: Off";
        }
    }

    
    private int GetAutoReturnCancellationGeneration(int slotNumber) =>
        _autoReturnCancellationGenerationBySlot.TryGetValue(slotNumber, out var generation) ? generation : 0;

    private bool IsAutoReturnAttemptCurrent(PipSlot slot, AutoReturnSlotState state, string attemptId, string checkpoint, bool logCancellation = true)
    {
        var currentGeneration = GetAutoReturnCancellationGeneration(slot.Number);
        var sameState = _autoReturnStatesBySlot.TryGetValue(slot.Number, out var currentState) && ReferenceEquals(currentState, state);
        var enabled = IsAutoReturnEnabledForSlot(slot.Number);
        var current = sameState && enabled && currentGeneration == state.CancellationGeneration;

        if (!current && logCancellation)
            AppLogger.Warn($"auto-return-operation-cancelled: attemptId={attemptId}; slot={slot.Number}; checkpoint={checkpoint}; stateGeneration={state.CancellationGeneration}; currentGeneration={currentGeneration}; sameState={sameState}; slotEnabled={enabled}");

        return current;
    }

    private void CancelAutoReturnPendingForSlot(int slotNumber, string source)
    {
        _autoReturnCancellationGenerationBySlot[slotNumber] = GetAutoReturnCancellationGeneration(slotNumber) + 1;

        var hadPendingState = _autoReturnStatesBySlot.Remove(slotNumber);
        var hadCooldown = _autoReturnCooldownUntilBySlot.Remove(slotNumber);
        var hadReconnectAttempt = _shadowReconnectAttemptIdBySlot.ContainsKey(slotNumber);

        var slot = Slots.FirstOrDefault(item => item.Number == slotNumber);

        if (_armedPipTargetSlotNumber == slotNumber)
        {
            if (IsActiveUserOpenPipAttemptForSlot(slotNumber))
            {
                AppLogger.InfoAggregated(
                    $"auto-return-cleanup-preserved-user-open:{slotNumber}",
                    TimeSpan.FromSeconds(2),
                    $"auto-return-cleanup-preserved-user-open: slot={slotNumber}; " +
                    $"openAll={_openAllPipsInProgress}; lockSlot={_openPipAttemptSlotNumber}; owner={_openPipAttemptOwner}");
            }
            else
            {
                _armedPipTargetSlotNumber = 0;
                _armedPipPairTab = null;
                _armedPipPairStartedUtc = DateTime.MinValue;
                _armedPipPairUntilUtc = DateTime.MinValue;
                _armedPipCandidateWindow = null;
                _armedPipCandidateDetectedUtc = DateTime.MinValue;
                _armedPipPairTimer.Stop();
            }
        }

        if (hadPendingState || hadCooldown || hadReconnectAttempt)
            AppLogger.Warn($"auto-return-disabled-cancelled-pending: slot={slotNumber}; source={source}; hadState={hadPendingState}; hadCooldown={hadCooldown}; hadShadowAttempt={hadReconnectAttempt}; terminalEvent={hadPendingState || hadReconnectAttempt}");

        if (hadPendingState || hadReconnectAttempt)
        {
            if (slot is not null)
                ShadowMirrorAutoReturnCancelled(slot, "auto-return-disabled", "CancelAutoReturnPendingForSlot/" + source);
            else
                ClearShadowReconnectAttemptForSlot(slotNumber, "CancelAutoReturnPendingForSlot/" + source);
        }
    }

    private void CancelAutoReturnPendingForDisabledSlots(string source)
    {
        NormalizeSlotAutoReturnSettings(migrateFromGlobal: false);

        var disabledSlots = Slots
            .Where(slot => !_slotAutoReturnDiscreteBySlot.TryGetValue(slot.Number, out var enabled) || !enabled)
            .Select(slot => slot.Number)
            .Distinct()
            .ToList();

        foreach (var slotNumber in disabledSlots)
            CancelAutoReturnPendingForSlot(slotNumber, source);
    }

    private void CancelAllAutoReturnPending(string source)
    {
        var slotNumbers = _autoReturnStatesBySlot.Keys
            .Concat(_autoReturnCooldownUntilBySlot.Keys)
            .Concat(_shadowReconnectAttemptIdBySlot.Keys)
            .Concat(_armedPipTargetSlotNumber > 0 ? new[] { _armedPipTargetSlotNumber } : Array.Empty<int>())
            .Distinct()
            .ToList();

        foreach (var slotNumber in slotNumbers)
            CancelAutoReturnPendingForSlot(slotNumber, source);
    }


    private void SetAutoReturnEnabledForSlot(int slotNumber, bool enabled, string source)
    {
        NormalizeSlotAutoReturnSettings(migrateFromGlobal: false);

        _slotAutoReturnDiscreteBySlot[slotNumber] = enabled;
        _settings.AutoReturnDiscreteBySlot = _slotAutoReturnDiscreteBySlot
            .Where(item => item.Key >= 1 && item.Key <= 10)
            .OrderBy(item => item.Key)
            .ToDictionary(item => item.Key, item => item.Value);

        _autoReturnPolicy = _slotAutoReturnDiscreteBySlot.Values.Any(value => value)
            ? AutoReturnPolicy.Discrete
            : AutoReturnPolicy.Off;
        _settings.AutoReturnPolicy = _autoReturnPolicy.ToString();
        _settings.AutomaticReactorCaptureEnabled = _automaticReactorCaptureEnabled;
        _settings.AutoAdvanceOnVideoEndEnabled = _autoAdvanceOnVideoEndEnabled;
        _settings.LayoutMonitorDeviceName = GetSelectedLayoutMonitor()?.DeviceName ?? string.Empty;
        _settings.NativeLayoutEngineMode = _nativeLayoutEngineMode.ToString();

        if (Slots.FirstOrDefault(slot => slot.Number == slotNumber) is { } slot)
            slot.IsAutoReturnEnabled = enabled;

        if (EditableSlots.FirstOrDefault(slot => slot.Number == slotNumber) is { } editable)
            editable.IsAutoReturnEnabled = enabled;

        if (!enabled)
            CancelAutoReturnPendingForSlot(slotNumber, "slot-policy-disabled/" + source);

        SaveSettings();
        UpdateAutoReturnPolicyVisual();

        var status = enabled
            ? $"Auto-retorno ligado no slot {slotNumber}"
            : $"Auto-retorno desligado no slot {slotNumber}";

        SetStatus(status);
        AppLogger.Info($"auto-return-slot-policy-changed: slot={slotNumber}; enabled={enabled}; source={source}; globalPolicy={_autoReturnPolicy}; slots={string.Join(",", _settings.AutoReturnDiscreteBySlot.Select(item => $"{item.Key}:{item.Value}"))}");
    }

    private void SlotAutoReturnDot_Click(object sender, RoutedEventArgs e)
    {
        e.Handled = true;

        var slotNumber = 0;
        var currentEnabled = false;

        if (sender is FrameworkElement { DataContext: PipSlot slot })
        {
            slotNumber = slot.Number;
            currentEnabled = slot.IsAutoReturnEnabled;
        }
        else if (sender is FrameworkElement { DataContext: EditableSlotRect editable })
        {
            slotNumber = editable.Number;
            currentEnabled = editable.IsAutoReturnEnabled;
        }

        if (slotNumber <= 0)
            return;

        SetAutoReturnEnabledForSlot(slotNumber, !currentEnabled, "slot-dot");
    }

private void AutoReturnPolicyButton_Click(object sender, RoutedEventArgs e)
    {
        NormalizeSlotAutoReturnSettings(migrateFromGlobal: false);

        var enableAll = !IsAnySlotAutoReturnEnabled();
        foreach (var slot in Slots)
            _slotAutoReturnDiscreteBySlot[slot.Number] = enableAll;

        _settings.AutoReturnDiscreteBySlot = _slotAutoReturnDiscreteBySlot
            .Where(item => item.Key >= 1 && item.Key <= 10)
            .OrderBy(item => item.Key)
            .ToDictionary(item => item.Key, item => item.Value);

        _autoReturnPolicy = enableAll ? AutoReturnPolicy.Discrete : AutoReturnPolicy.Off;
        _settings.AutoReturnPolicy = _autoReturnPolicy.ToString();
        _settings.AutomaticReactorCaptureEnabled = _automaticReactorCaptureEnabled;
        _settings.NextVideoPreviewEnabled = _nextVideoPreviewEnabled;
        _settings.NextVideoPreloadEnabled = _nextVideoPreloadEnabled;
        _settings.LayoutMonitorDeviceName = GetSelectedLayoutMonitor()?.DeviceName ?? string.Empty;
        _settings.NativeLayoutEngineMode = _nativeLayoutEngineMode.ToString();

        foreach (var slot in Slots)
            slot.IsAutoReturnEnabled = enableAll;

        foreach (var editable in EditableSlots)
            editable.IsAutoReturnEnabled = enableAll;

        if (!enableAll)
            CancelAllAutoReturnPending("all-slots-policy-disabled");

        SaveSettings();
        UpdateAutoReturnPolicyVisual();

        var status = enableAll
            ? $"Auto-retorno Discreto ligado em {Slots.Count} slot(s)"
            : "Auto-retorno Discreto desligado em todos os slots";

        SetStatus(status);
        AppLogger.Info($"auto-return-all-slots-policy-changed: enabled={enableAll}; slots={string.Join(",", _settings.AutoReturnDiscreteBySlot.Select(item => $"{item.Key}:{item.Value}"))}");
    }

    private void CaptureButton_Click(object sender, RoutedEventArgs e)
    {
        CapturePipsStable();
    }

    private void CaptureAllButton_Click(object sender, RoutedEventArgs e)
    {
        CaptureAllPipsSafe();
    }

    private void CaptureAllPipsSafe()
    {
        // Capturar todos preserva slots reservados/offline para permitir reconexão inteligente.
        // Limpa apenas slots sem janela real; slots com HWND perdido entram na janela de reconexão.
        var cleanedGhosts = ClearNullGhostSlotsForNewPip("Capturar todos");
        var duplicateSlotsCleared = ClearDuplicateWindowSlots();

        var discovered = _discovery.FindPipWindows()
            .GroupBy(window => window.Handle)
            .Select(group => group.First())
            .ToList();

        if (discovered.Count == 0)
        {
            SetStatus(cleanedGhosts + duplicateSlotsCleared > 0
                ? $"Nenhuma janela PiP encontrada; {cleanedGhosts + duplicateSlotsCleared} slot(s) limpo(s)"
                : "Nenhuma janela Picture-in-Picture foi encontrada");
            return;
        }

        var discoveredByHandle = discovered.ToDictionary(window => window.Handle, window => window);
        var alreadyCapturedHandles = new HashSet<IntPtr>();
        var refreshed = 0;
        var lost = 0;
        var reconnectSlots = new List<PipSlot>();

        foreach (var slot in Slots.OrderBy(slot => slot.Number))
        {
            if (slot.Window is null) continue;

            var handle = slot.Window.Handle;
            if (discoveredByHandle.TryGetValue(handle, out var updated) && PipWindowService.IsUsable(handle))
            {
                slot.RefreshWindow(updated);
                slot.IsHidden = false;
                MarkSlotActive(slot);
                ClearLostSlotState(slot);
                alreadyCapturedHandles.Add(handle);
                refreshed++;
                continue;
            }

            lost++;
            if (!ShouldRemoveLostSlot(slot, "Capturar todos"))
            {
                reconnectSlots.Add(slot);
            }
            else
            {
                RemoveSlotPipFinal(slot, "Capturar todos");
            }
        }

        var newPips = discovered
            .Where(window => !alreadyCapturedHandles.Contains(window.Handle))
            .Where(window => !Slots.Any(slot => slot.Window?.Handle == window.Handle))
            .OrderBy(window => window.VisualRect.Top)
            .ThenBy(window => window.VisualRect.Left)
            .ThenByDescending(window => window.Score)
            .Take(10)
            .ToList();

        var reconnected = ReconnectLostSlotsIntelligently(reconnectSlots, newPips, alreadyCapturedHandles, "Capturar todos");

        if (newPips.Count == 0)
        {
            RefreshAllSlotStates();
            RefreshAllSlotPairVisuals();
            UpdateCounts();
            RefreshPipDragTargets();
            PositionToolbar();
            UpdateSelectedActions(setStatus: false);
            UpdatePairPreviewNotice();
            SetStatus($"Capturar todos: nenhum PiP novo; {refreshed} atualizado(s), {reconnected} reconectado(s)");
            AppLogger.Info($"Capturar todos concluído sem novos PiPs: encontrados={discovered.Count}, atualizados={refreshed}, reconectados={reconnected}, perdidos={lost}, slotsLimpos={cleanedGhosts + duplicateSlotsCleared}");
            return;
        }

        var occupiedCount = Slots.Count(slot => slot.Window is not null);
        var requiredSlots = Math.Clamp(Math.Max(Slots.Count, occupiedCount + newPips.Count), 1, 10);
        if (Slots.Count != requiredSlots)
        {
            SetSlotCount(requiredSlots);
            UpdatePipCountButton();
        }

        var added = 0;
        foreach (var slot in Slots.OrderBy(slot => slot.Number).Where(slot => slot.Window is null))
        {
            if (added >= newPips.Count) break;

            var pip = newPips[added];
            slot.Window = pip;
            slot.IsHidden = false;
            MarkSlotActive(slot);
            ShadowMirrorPipCaptured(slot, pip.Handle, "CaptureAllPipsSafe/new");
            ClearLostSlotState(slot);
            alreadyCapturedHandles.Add(pip.Handle);
            AppLogger.Info($"Capturar todos: PiP novo vinculado ao slot {slot.Number}; handle=0x{pip.Handle.ToInt64():X}; processo={pip.ProcessName}; titulo={pip.Title}");
            added++;
        }

        _allHidden = false;
        VisibilityButton.Content = "Ocultar PiPs";
        _toolbar?.SetHiddenState(false);
        UpdateMainQuickActionLabels();
        RefreshAllSlotStates();
        RefreshAllSlotPairVisuals();
        UpdateCounts();
        RefreshCapturedRectsOnly();
        QueueStableGroupLayout("capture-all", debounceMs: 500);
        AppLogger.Info($"capture-all-stable-layout-debounce-requested: slots={Slots.Count(slot => slot.Window is not null)}; layout={CurrentLayout}");
        EnsureVisiblePipsTopMost(force: true);
        PositionToolbar();
        RefreshPipDragTargets();
        RefreshVideoPickerVisualStates();
        UpdateSelectedActions(setStatus: false);
        UpdatePairPreviewNotice();

        SetStatus($"Capturar todos: {added} novo(s), {reconnected} reconectado(s), {refreshed} atualizado(s), {cleanedGhosts + duplicateSlotsCleared} limpo(s)");
        AppLogger.Info($"Capturar todos concluído: encontrados={discovered.Count}, novos={added}, reconectados={reconnected}, atualizados={refreshed}, perdidos={lost}, slotsLimpos={cleanedGhosts + duplicateSlotsCleared}");
        QueueAutoRecoverSlotPairs("capturar todos", onlySuspicious: true);
    }

    private int ClearDuplicateWindowSlots()
    {
        var cleaned = 0;
        var groups = Slots
            .Where(slot => slot.Window is not null)
            .GroupBy(slot => slot.Window!.Handle)
            .Where(group => group.Key != IntPtr.Zero && group.Count() > 1)
            .ToArray();

        foreach (var group in groups)
        {
            var keep = group.OrderBy(slot => slot.Number).First();
            foreach (var duplicate in group.OrderBy(slot => slot.Number).Skip(1).ToArray())
            {
                AppLogger.Warn($"Slot duplicado liberado; slotMantido={keep.Number}; slotLimpo={duplicate.Number}; handle=0x{group.Key.ToInt64():X}");
                ClearSlotCompletely(duplicate, "HWND duplicado");
                cleaned++;
            }
        }

        if (cleaned > 0)
        {
            RefreshAllSlotStates();
            RefreshAllSlotPairVisuals();
            RefreshVideoPickerVisualStates();
            UpdateCounts();
            RefreshPipDragTargets();
            PositionToolbar();
        }

        return cleaned;
    }

    private void ReorganizeButton_Click(object sender, RoutedEventArgs e)
    {
        if (!Slots.Any(slot => slot.Window is not null))
        {
            SetStatus("Nenhum PiP capturado para reorganizar");
            return;
        }

        ArrangeCaptured(preferPanelTemplateAnchor: false);
        PositionToolbar();
        RefreshPipDragTargets();
        UpdateSelectedPipNotice();
        UpdatePairPreviewNotice();
        SetStatus($"PiPs reorganizados pelo layout {CurrentLayout.ToLabel()} sem alterar vínculos");
        AppLogger.Info($"Reorganizar executado manualmente: layout={CurrentLayout}; capturados={Slots.Count(slot => slot.Window is not null)}");
    }

    private void CapturePipsStable()
    {
        ClearGhostSlotsForNewPip("Captura");
        var duplicateSlotsCleared = ClearDuplicateWindowSlots();
        var discovered = _discovery.FindPipWindows();
        if (discovered.Count == 0)
        {
            SetStatus("Nenhuma janela Picture-in-Picture foi encontrada");
            return;
        }

        // Captura estável com preservação de slots:
        // - PiP já preso permanece no mesmo slot enquanto a janela existir;
        // - slot de PiP fechado fica livre;
        // - PiP novo entra no primeiro slot livre;
        // - evita reorganizar todos automaticamente.
        var byHandle = discovered
            .GroupBy(window => window.Handle)
            .ToDictionary(group => group.Key, group => group.First());

        var usedHandles = new HashSet<IntPtr>();
        var removed = 0;
        var preserved = 0;
        var hadCapturedBefore = Slots.Any(slot => slot.Window is not null);

        foreach (var slot in Slots.OrderBy(slot => slot.Number))
        {
            if (slot.Window is null) continue;

            var handle = slot.Window.Handle;
            if (byHandle.TryGetValue(handle, out var updated))
            {
                ClearLostSlotState(slot);
                slot.RefreshWindow(updated);
                slot.IsHidden = false;
                MarkSlotActive(slot);
                usedHandles.Add(handle);
                preserved++;
                continue;
            }

            var replacement = TryFindReplacementForSlot(slot, discovered, usedHandles);
            if (replacement is not null)
            {
                var reconnectReference = GetReconnectReferenceRect(slot);
                AppLogger.Info($"Captura: slot {slot.Number} reconectado a novo HWND; antigo=0x{handle.ToInt64():X}, novo=0x{replacement.Handle.ToInt64():X}");
                _hiddenPipRects.Remove(handle);
                _lockedGroupModelRects.Remove(handle);
                ClearLostSlotState(slot);
                slot.RefreshWindow(replacement);
                slot.IsHidden = false;
                MarkSlotActive(slot);
                RestoreReconnectedWindowPosition(slot, handle, replacement.Handle, reconnectReference, "CapturePipsStable");
                usedHandles.Add(replacement.Handle);
                preserved++;
                continue;
            }

            if (!ShouldRemoveLostSlot(slot, "Captura"))
            {
                preserved++;
                continue;
            }

            RemoveSlotPipFinal(slot, "Captura");
            removed++;
        }

        var newPips = discovered
            .Where(window => !usedHandles.Contains(window.Handle))
            .Take(10)
            .ToList();

        var occupiedCount = Slots.Count(slot => slot.Window is not null);
        var requiredSlots = Math.Clamp(Math.Max(Slots.Count, occupiedCount + newPips.Count), 1, 10);
        if (Slots.Count != requiredSlots)
        {
            SetSlotCount(requiredSlots);
            UpdatePipCountButton();
        }

        var added = 0;
        foreach (var slot in Slots.OrderBy(slot => slot.Number).Where(slot => slot.Window is null))
        {
            if (added >= newPips.Count) break;
            slot.Window = newPips[added];
            slot.IsHidden = false;
            MarkSlotActive(slot);
            ShadowMirrorPipCaptured(slot, newPips[added].Handle, "CapturePipsStable/new");
            usedHandles.Add(newPips[added].Handle);
            added++;
        }

        _allHidden = false;
        VisibilityButton.Content = "Ocultar PiPs";
        _toolbar?.SetHiddenState(false);
        UpdateMainQuickActionLabels();
        RefreshAllSlotStates();
        RefreshAllSlotPairVisuals();

        UpdateCounts();
        if (!hadCapturedBefore && added > 0)
        {
            // Primeira captura: monta o layout inicial normalmente.
            RebuildGroupFromLayout(preferPanelTemplateAnchor: true, resizeToTargets: false, saveLockedModel: _groupLocked);
        }
        else
        {
            // Capturas seguintes: preserva posições e slots, sem reorganizar todos automaticamente.
            RefreshCapturedRectsOnly();
            if (_groupLocked)
                SaveLockedGroupModelFromCurrentRects();
            EnsureVisiblePipsTopMost(force: true);
            PositionToolbar();
            RefreshPipDragTargets();
        }

        var captureCount = Slots.Count(slot => slot.Window is not null);
        SetStatus($"{captureCount} PiP(s): {preserved} preservado(s), {added} novo(s), {removed} removido(s), {duplicateSlotsCleared} duplicado(s) limpo(s)");
        AppLogger.Info($"Captura estável concluída: capturados={captureCount}, preservados={preserved}, novos={added}, removidos={removed}, duplicadosLimpos={duplicateSlotsCleared}");
        QueueAutoRecoverSlotPairs("captura", onlySuspicious: true);
    }

    private void EqualizeButton_Click(object sender, RoutedEventArgs e) => EqualizeCaptured();
    private void VisibilityButton_Click(object sender, RoutedEventArgs e) => ToggleAllVisibility();

    private void UpdateMainQuickActionLabels()
    {
        if (MainLockQuickButton is not null)
        {
            MainLockQuickButton.Content = _groupLocked ? "Soltar" : "Travar";
            MainLockQuickButton.ToolTip = _groupLocked
                ? "Grupo travado — clique para soltar"
                : "PiPs soltos — clique para travar";
        }

        if (MainVisibilityQuickButton is not null)
            MainVisibilityQuickButton.Content = _allHidden ? "Mostrar" : "Ocultar";
    }

    private void MainPanelToggleLockButton_Click(object sender, RoutedEventArgs e) => ToggleLockMode();

    private void MainPanelShowPanelButton_Click(object sender, RoutedEventArgs e) => ShowPanel();


    private async void QueueStableGroupLayout(string source, int debounceMs = 500)
    {
        if (_fixedLayoutRecoveryCycleActive)
        {
            AppLogger.Info($"stable-group-layout-debounce-skipped: source={source}; reason=fixed-layout-recovery-cycle; generation={_fixedLayoutRecoveryGeneration}");
            return;
        }
        _stableGroupLayoutDebounceCts?.Cancel();
        _stableGroupLayoutDebounceCts?.Dispose();
        var cts = new System.Threading.CancellationTokenSource();
        _stableGroupLayoutDebounceCts = cts;
        var generation = ++_stableGroupLayoutDebounceGeneration;
        var requestedCount = Slots.Count(slot => slot.Window is { } window && PipWindowService.IsUsable(window.Handle));
        AppLogger.Info($"stable-group-layout-debounce-queued: generation={generation}; source={source}; debounceMs={debounceMs}; windows={requestedCount}");

        try
        {
            await Task.Delay(Math.Max(350, debounceMs), cts.Token);
            if (cts.IsCancellationRequested || generation != _stableGroupLayoutDebounceGeneration)
                return;

            if (_fixedLayoutRecoveryCycleActive)
            {
                AppLogger.Info($"stable-group-layout-debounce-skipped: generation={generation}; source={source}; reason=recovery-started-during-debounce");
                return;
            }

            var stableCount = Slots.Count(slot => slot.Window is { } window && PipWindowService.IsUsable(window.Handle));
            if (stableCount == 0)
                return;

            if (IsLayoutTransactionActive())
            {
                AppLogger.Info($"stable-group-layout-debounce-deferred: generation={generation}; source={source}; windows={stableCount}; reason=layout-transaction-active");
                await Task.Delay(250, cts.Token);
                if (cts.IsCancellationRequested || generation != _stableGroupLayoutDebounceGeneration)
                    return;
            }

            RefreshCapturedRectsOnly();
            RebuildGroupFromLayout(preferPanelTemplateAnchor: false, resizeToTargets: false, saveLockedModel: _groupLocked);
            if (_groupLocked)
                SaveLockedGroupModelFromCurrentRects();
            EnsureVisiblePipsTopMost(force: true);
            AppLogger.Info($"stable-group-layout-debounce-applied: generation={generation}; source={source}; windows={stableCount}; layout={CurrentLayout}");
        }
        catch (TaskCanceledException)
        {
            AppLogger.Info($"stable-group-layout-debounce-cancelled: generation={generation}; source={source}");
        }
        finally
        {
            if (ReferenceEquals(_stableGroupLayoutDebounceCts, cts))
            {
                _stableGroupLayoutDebounceCts = null;
                cts.Dispose();
            }
        }
    }

    private void ArrangeCaptured(bool preferPanelTemplateAnchor = false)
    {
        RebuildGroupFromLayout(preferPanelTemplateAnchor, resizeToTargets: false, saveLockedModel: _groupLocked);
        SetStatus(_customLayoutActive ? "Layout personalizado aplicado" : $"Layout {CurrentLayout.ToLabel()} aplicado");
        AppLogger.Info(_customLayoutActive ? "Layout personalizado aplicado" : $"Layout aplicado: {CurrentLayout}");
    }

    private void RebuildGroupFromLayout(bool preferPanelTemplateAnchor = false, bool resizeToTargets = false, bool saveLockedModel = true)
    {
        if (_fixedCustomLayoutEnabled && HasCompleteFixedLayoutAuthority())
        {
            ApplyFixedLayoutToAllActive("rebuild-group");
            return;
        }

        var occupied = GetOccupiedSlotsInNumberOrder();
        if (occupied.Length == 0) return;

        var targetMonitor = GetSelectedLayoutMonitor();
        var anchor = preferPanelTemplateAnchor
            ? GetMonitorLayoutAnchor(targetMonitor, occupied.Length)
            : _layoutService.GetGroupBounds(Slots);

        if (targetMonitor is not null && !anchor.Intersects(targetMonitor.WorkArea))
            anchor = GetMonitorLayoutAnchor(targetMonitor, occupied.Length);

        if (!anchor.IsValid)
            anchor = _lastKnownGroupBounds.IsValid ? _lastKnownGroupBounds : GetPanelTemplateAnchorBounds(occupied.Length);
        if (!anchor.IsValid) return;

        var sourceRects = occupied
            .Select(slot => PipWindowService.GetVisualRect(slot.Window!.Handle))
            .Where(rect => rect.IsValid)
            .ToArray();
        if (sourceRects.Length != occupied.Length || sourceRects.Length == 0) return;

        var targets = BuildTargetsForOccupiedSlots(occupied, sourceRects, anchor, targetMonitor?.WorkArea);
        var resizeForJogoWorkArea = CurrentLayout == LayoutMode.Jogo
            && TargetsRequireResize(sourceRects, targets);
        ApplyTargetsToOccupiedSlots(occupied, targets, resizeToTargets || resizeForJogoWorkArea);
        CaptureCurrentRectsIntoSlotLayout();
        if (saveLockedModel)
            SaveLockedGroupModelFromCurrentRects();
        PositionToolbar();
        RefreshPipDragTargets();
    }

    private void EqualizeCaptured()
    {
        if (CurrentLayout == LayoutMode.Jogo)
        {
            var jogoOccupied = GetOccupiedSlotsInNumberOrder()
                .Where(slot => slot.Window is not null && PipWindowService.IsUsable(slot.Window.Handle))
                .ToArray();
            if (jogoOccupied.Length == 0)
                return;

            var currentRects = jogoOccupied
                .Select(slot => PipWindowService.GetVisualRect(slot.Window!.Handle))
                .ToArray();
            if (currentRects.Any(rect => !rect.IsValid))
                return;

            var jogoReference = GetEqualizeReferenceSlot(jogoOccupied) ?? jogoOccupied[^1];
            var workArea = GetSelectedLayoutMonitor()?.WorkArea
                ?? PipWindowService.GetVirtualScreenBounds();
            var jogoTargets = BuildJogoReferenceGroupEqualizeTargets(
                    jogoOccupied,
                    currentRects,
                    jogoReference,
                    workArea,
                    out var referenceIsTop)
                .ToArray();
            if (jogoTargets.Length != jogoOccupied.Length
                || jogoTargets.Any(rect => !rect.IsValid))
                return;

            ApplyTargetsToOccupiedSlots(jogoOccupied, jogoTargets, resizeToTargets: true);
            CaptureCurrentRectsIntoSlotLayout();
            CommitJogoTargetsAsFixedAuthority(
                jogoOccupied,
                jogoTargets,
                "equalize-request-jogo-reference-group");
            SaveLockedGroupModel(jogoOccupied, jogoTargets);
            _lastKnownGroupBounds = GetBounds(jogoTargets);

            var referenceTarget = jogoTargets[Array.FindIndex(
                jogoOccupied,
                slot => slot.Number == jogoReference.Number)];
            if (workArea.Width > 0 && referenceTarget.IsValid)
            {
                if (referenceIsTop)
                    _jogoTopWidthRatio = NormalizeJogoGroupWidthRatio(referenceTarget.Width / (double)workArea.Width);
                else
                    _jogoSideWidthRatio = NormalizeJogoGroupWidthRatio(referenceTarget.Width / (double)workArea.Width);
            }
            UpdateJogoFreeAreaUi();
            SaveSettings();
            PositionToolbar();
            EnsureVisiblePipsTopMost(force: true);
            RefreshPipDragTargets();

            var groupLabel = referenceIsTop ? "superior" : "lateral";
            SetStatus($"Grupo {groupLabel} igualado ao último PiP ajustado: slot {jogoReference.Number}");
            AppLogger.Info(
                $"jogo-group-equalize-from-last-resize: referenceSlot={jogoReference.Number}; " +
                $"referenceSource={(_lastManuallyResizedSlotNumber == jogoReference.Number ? "last-manual-resize" : "selected-or-fallback")}; " +
                $"group={(referenceIsTop ? "top" : "side")}; groupOnly=True; " +
                $"otherGroupResize=False; windows={jogoOccupied.Length}; fixed={_fixedCustomLayoutEnabled}; " +
                "nativeBorderReference=True; connectedMosaic=True");
            return;
        }

        if (_fixedCustomLayoutEnabled && HasCompleteFixedLayoutAuthority())
        {
            var fixedOccupied = GetOccupiedSlotsInNumberOrder()
                .Where(slot => slot.Window is not null && PipWindowService.IsUsable(slot.Window.Handle))
                .ToArray();
            var fixedReference = GetEqualizeReferenceSlot(fixedOccupied);
            var fixedReferenceRect = fixedReference?.Window is not null
                ? PipWindowService.GetVisualRect(fixedReference.Window.Handle)
                : default;

            RecordFixedLayoutAuthority(
                "equalize-request-fixed-authority",
                fixedReferenceRect.IsValid ? fixedReferenceRect : null);
            ApplyFixedLayoutToAllActive("equalize-request-fixed-authority", resizeToTargets: true);
            SetStatus("Layout fixo igualado: todos os slots usam o mesmo tamanho e permanecem dentro da tela");
            AppLogger.Info(
                $"Tamanhos igualados em mosaico fixo; referência={fixedReference?.Number.ToString() ?? "molde"}; " +
                $"referenceSource={(_lastManuallyResizedSlotNumber == fixedReference?.Number ? "last-manual-resize" : "selected-or-fallback")}; " +
                $"windows={fixedOccupied.Length}; connectedMosaic=True");
            return;
        }

        var occupiedInOrder = GetOccupiedSlotsInNumberOrder();
        if (occupiedInOrder.Length == 0) return;

        var anchor = _layoutService.GetGroupBounds(Slots);
        if (!anchor.IsValid) return;

        var reference = GetEqualizeReferenceSlot(occupiedInOrder) ?? occupiedInOrder[^1];
        var referenceRect = PipWindowService.GetVisualRect(reference.Window!.Handle);
        if (!referenceRect.IsValid) return;

        var equalRects = occupiedInOrder
            .Select(_ => new NativeRect(0, 0, referenceRect.Width, referenceRect.Height))
            .ToArray();

        var targets = BuildTargetsForOccupiedSlots(occupiedInOrder, equalRects, anchor, GetSelectedLayoutMonitor()?.WorkArea);
        ApplyTargetsToOccupiedSlots(occupiedInOrder, targets, resizeToTargets: true);
        CaptureCurrentRectsIntoSlotLayout();
        SaveLockedGroupModel(occupiedInOrder, targets);
        _lastKnownGroupBounds = GetBounds(targets.ToArray());
        PositionToolbar();
        EnsureVisiblePipsTopMost(force: true);
        RefreshPipDragTargets();
        SetStatus("Igualado e recolado pelo layout ativo");
        AppLogger.Info(
            $"Tamanhos igualados; referência={reference.Number}; " +
            $"referenceSource={(_lastManuallyResizedSlotNumber == reference.Number ? "last-manual-resize" : "selected-or-fallback")}; " +
            $"windows={occupiedInOrder.Length}; layout={CurrentLayout}; connectedMosaic=True");
    }

    private void ToggleAllVisibility()
    {
        var cleanupBefore = CleanupLostPipsForVisibility("Ocultar/Mostrar");

        if (!_allHidden)
        {
            var activeSlots = Slots
                .Where(slot => slot.Window is not null && PipWindowService.IsUsable(slot.Window.Handle))
                .ToArray();

            if (activeSlots.Length == 0)
            {
                _allHidden = false;
                VisibilityButton.Content = "Ocultar PiPs";
                _toolbar?.SetHiddenState(false);
                UpdateMainQuickActionLabels();
                ClearPipDragTargets();
                UpdateCounts();
                UpdateSelectedActions();
                SetStatus(cleanupBefore.Removed > 0
                    ? $"Nenhum PiP ativo para ocultar; {cleanupBefore.Removed} perdido(s) removido(s)"
                    : "Nenhum PiP ativo para ocultar");
                return;
            }

            _hiddenPipRects.Clear();
            foreach (var slot in activeSlots)
            {
                var handle = slot.Window!.Handle;
                var rect = PipWindowService.GetVisualRect(handle);
                if (rect.IsValid)
                {
                    _hiddenPipRects[handle] = rect;
                    slot.RefreshWindow(slot.Window with { VisualRect = rect });
                }
            }

            if (_groupLocked)
                SaveLockedGroupModelFromCurrentRects();

            ClearPipDragTargets();
            foreach (var slot in activeSlots)
            {
                try
                {
                    PipWindowService.Hide(slot.Window!.Handle);
                    slot.IsHidden = true;
                    MarkSlotHidden(slot);
                }
                catch (Exception ex)
                {
                    AppLogger.Error($"Falha ao ocultar o slot {slot.Number}", ex);
                }
            }

            _allHidden = true;
            VisibilityButton.Content = "Mostrar PiPs";
            _toolbar?.SetHiddenState(true);
            UpdateMainQuickActionLabels();
            UpdateCounts();
            UpdateSelectedActions();
            PositionToolbar();
            SetStatus(cleanupBefore.Removed > 0
                ? $"PiPs ocultos; {cleanupBefore.Removed} perdido(s) removido(s) antes da ação"
                : "PiPs ocultos; posição salva");
            AppLogger.Info($"Ocultar/Mostrar inteligente: ocultados={activeSlots.Length}, removidosAntes={cleanupBefore.Removed}");
            return;
        }

        var restored = 0;
        var removedDuringShow = 0;
        foreach (var slot in Slots.Where(slot => slot.Window is not null).ToArray())
        {
            var handle = slot.Window!.Handle;
            if (!PipWindowService.IsUsable(handle))
            {
                AppLogger.Info($"Mostrar: slot {slot.Number} removido porque a janela não existe mais; handle=0x{handle.ToInt64():X}");
                slot.Window = null;
                slot.IsHidden = false;
                _hiddenPipRects.Remove(handle);
                _lockedGroupModelRects.Remove(handle);
                if (SlotHasVideoPair(slot))
                    MarkSlotOffline(slot);
                else
                    MarkSlotFree(slot);
                removedDuringShow++;
                continue;
            }

            try
            {
                if (_hiddenPipRects.TryGetValue(handle, out var savedRect) && savedRect.IsValid)
                    PipWindowService.MoveVisual(handle, savedRect.Left, savedRect.Top);

                PipWindowService.Show(handle);
                PipWindowService.SetTopMost(handle);
                slot.IsHidden = false;
                MarkSlotActive(slot);

                var finalRect = PipWindowService.GetVisualRect(handle);
                if (!finalRect.IsValid && _hiddenPipRects.TryGetValue(handle, out var fallbackRect) && fallbackRect.IsValid)
                    finalRect = fallbackRect;
                if (finalRect.IsValid)
                    slot.RefreshWindow(slot.Window with { VisualRect = finalRect });

                restored++;
            }
            catch (Exception ex)
            {
                AppLogger.Error($"Falha ao mostrar o slot {slot.Number}; removendo referência", ex);
                slot.Window = null;
                slot.IsHidden = false;
                _hiddenPipRects.Remove(handle);
                _lockedGroupModelRects.Remove(handle);
                if (SlotHasVideoPair(slot))
                    MarkSlotOffline(slot);
                else
                    MarkSlotFree(slot);
                removedDuringShow++;
            }
        }

        _hiddenPipRects.Clear();
        _allHidden = false;
        VisibilityButton.Content = "Ocultar PiPs";
        _toolbar?.SetHiddenState(false);
        UpdateMainQuickActionLabels();
        RefreshAllSlotStates();
        RefreshAllSlotPairVisuals();

        RefreshCapturedRectsOnly();
        if (_groupLocked)
            SaveLockedGroupModelFromCurrentRects();
        EnsureVisiblePipsTopMost(force: true);
        PositionToolbar();
        RefreshPipDragTargets();
        UpdateCounts();
        UpdateSelectedActions();

        var totalRemoved = cleanupBefore.Removed + removedDuringShow;
        SetStatus(totalRemoved > 0
            ? $"PiPs restaurados: {restored}; {totalRemoved} perdido(s) removido(s)"
            : $"PiPs restaurados: {restored}; topo reaplicado");
        AppLogger.Info($"Ocultar/Mostrar inteligente: restaurados={restored}, removidosAntes={cleanupBefore.Removed}, removidosAoMostrar={removedDuringShow}");
    }

    private bool SlotHasVideoPair(PipSlot slot) =>
        _slotVideoPairs.ContainsKey(slot.Number)
        || _slotStableVideoPairs.ContainsKey(slot.Number)
        || _slotPairedTabIds.ContainsKey(slot.Number);

    private void ClearSlotPairMetadata(int slotNumber)
    {
        _slotVideoPairs.Remove(slotNumber);
        _slotStableVideoPairs.Remove(slotNumber);
        _slotPairedTabIds.Remove(slotNumber);
        _slotPairDomains.Remove(slotNumber);
        _slotPairUrls.Remove(slotNumber);
        _slotIntrinsicContentAspectRatios.Remove(slotNumber);
        _autoReturnStatesBySlot.Remove(slotNumber);
        _autoReturnCooldownUntilBySlot.Remove(slotNumber);
        _videoSwitchPreservationBySlot.Remove(slotNumber);
        _missingPairLoggedSlots.Remove(slotNumber);
        var slot = Slots.FirstOrDefault(item => item.Number == slotNumber);
        if (slot is not null)
        {
            if (slot.Window is null)
                RefreshSlotState(slot);
            RefreshSlotPairVisual(slot);
        }
    }

    private void ClearSlotCompletely(PipSlot slot, string source)
    {
        var oldHandle = slot.Window?.Handle;

        slot.Window = null;
        slot.IsHidden = false;
        ClearSlotPairMetadata(slot.Number);
        _pendingLostPipsBySlot.Remove(slot.Number);
        _missingPairLoggedSlots.Remove(slot.Number);
        ClearAwaitingPipSlot(slot.Number);

        if (oldHandle is IntPtr handle)
        {
            _hiddenPipRects.Remove(handle);
            _lockedGroupModelRects.Remove(handle);
        }

        MarkSlotFree(slot);
        RefreshSlotPairVisual(slot);
        AppLogger.Info($"{source}: slot {slot.Number} limpo completamente; handleAntigo={(oldHandle is IntPtr h ? $"0x{h.ToInt64():X}" : "nenhum")}");
    }

    private int ClearNullGhostSlotsForNewPip(string source)
    {
        var cleaned = 0;
        var preserved = 0;

        foreach (var slot in Slots.OrderBy(slot => slot.Number).ToArray())
        {
            if (slot.State == PipSlotState.AwaitingPip)
            {
                preserved++;
                continue;
            }

            if (slot.Window is not null)
                continue;

            if (ShouldPreserveNullSlotForReconnect(slot))
            {
                preserved++;
                AppLogger.Info($"{source}: slot {slot.Number} reservado para reconexão; estado={slot.State}; vinculo={SlotHasVideoPair(slot)}; sinal={SlotHasPairRecoverySignal(slot.Number)}");
                continue;
            }

            if (slot.State == PipSlotState.Free && !SlotHasPairRecoverySignal(slot.Number))
                continue;

            ClearSlotCompletely(slot, source);
            cleaned++;
        }

        if (cleaned > 0 || preserved > 0)
        {
            RefreshAllSlotStates();
            RefreshAllSlotPairVisuals();
            RefreshVideoPickerVisualStates();
            UpdateCounts();
            UpdateSelectedActions(setStatus: false);
            RefreshPipDragTargets();
            PositionToolbar();

            if (cleaned > 0)
                AppLogger.Info($"{source}: {cleaned} slot(s) sem janela limpo(s); {preserved} preservado(s) para reconexão");
        }

        return cleaned;
    }

    private bool ShouldPreserveNullSlotForReconnect(PipSlot slot)
    {
        if (slot.State == PipSlotState.AwaitingPip)
            return true;

        if (slot.State == PipSlotState.Offline && SlotHasPairRecoverySignal(slot.Number))
            return true;

        if (_pendingLostPipsBySlot.ContainsKey(slot.Number) && SlotHasPairRecoverySignal(slot.Number))
            return true;

        return false;
    }

    private int ClearGhostSlotsForNewPip(string source)
    {
        var cleaned = 0;
        var preserved = 0;

        foreach (var slot in Slots.OrderBy(slot => slot.Number).ToArray())
        {
            if (slot.State == PipSlotState.AwaitingPip)
            {
                preserved++;
                continue;
            }

            if (slot.Window is null)
            {
                if (ShouldPreserveNullSlotForReconnect(slot))
                {
                    preserved++;
                    AppLogger.Info($"{source}: slot {slot.Number} reservado sem janela reservado para reconexão; estado={slot.State}; sinal={SlotHasPairRecoverySignal(slot.Number)}");
                    continue;
                }

                if (SlotHasVideoPair(slot) || slot.State == PipSlotState.Offline || slot.IsHidden)
                {
                    ClearSlotCompletely(slot, source);
                    cleaned++;
                }
                continue;
            }

            if (!PipWindowService.IsUsable(slot.Window.Handle)
                && (SlotHasVideoPair(slot) || slot.State == PipSlotState.Offline || slot.IsHidden))
            {
                // Janela perdida com vínculo forte deve entrar na janela de reconexão, não ser apagada na hora.
                if (SlotHasPairRecoverySignal(slot.Number))
                {
                    if (!ShouldRemoveLostSlot(slot, source))
                    {
                        preserved++;
                        continue;
                    }
                }

                ClearSlotCompletely(slot, source);
                cleaned++;
            }
        }

        if (cleaned > 0 || preserved > 0)
        {
            RefreshAllSlotStates();
            RefreshAllSlotPairVisuals();
            RefreshVideoPickerVisualStates();
            UpdateCounts();
            UpdateSelectedActions(setStatus: false);
            RefreshPipDragTargets();
            PositionToolbar();

            if (cleaned > 0)
                AppLogger.Info($"{source}: {cleaned} slot(s) fantasma/órfão(s) limpo(s); {preserved} preservado(s) para reconexão");
        }

        return cleaned;
    }

    private bool ShouldPreserveSlotPairOnLoss(PipSlot slot) => SlotHasVideoPair(slot);

    private bool ShouldLogMissingPair(int slotNumber) => _missingPairLoggedSlots.Add(slotNumber);

    private bool ShouldRemoveLostSlot(PipSlot slot, string source)
    {
        if (slot.Window is null) return true;

        var now = DateTime.UtcNow;
        var hasPair = SlotHasVideoPair(slot);
        var graceSeconds = hasPair ? PairedPipLostGraceSeconds : PipLostGraceSeconds;

        if (!_pendingLostPipsBySlot.TryGetValue(slot.Number, out var pending))
        {
            _pendingLostPipsBySlot[slot.Number] = new PendingLostPip(slot.Window, now, hasPair);
            if (hasPair)
            {
                MarkSlotOffline(slot);
                MarkAutoReturnPending(slot, "pip-window-lost");
            }
            AppLogger.Info($"{source}: PiP no slot {slot.Number} ficou reservado; aguardando reconexão por até {graceSeconds}s; handle=0x{slot.Window.Handle.ToInt64():X}; vinculado={hasPair}");
            return false;
        }

        if ((now - pending.FirstLostUtc).TotalSeconds < graceSeconds)
        {
            if (hasPair)
                MarkSlotOffline(slot);
            return false;
        }

        return true;
    }

    private void ClearLostSlotState(PipSlot slot)
    {
        _pendingLostPipsBySlot.Remove(slot.Number);
        _autoReturnStatesBySlot.Remove(slot.Number);
        RefreshSlotState(slot);
    }

    private void RemoveSlotPipFinal(PipSlot slot, string source)
    {
        if (slot.Window is null) return;
        var handle = slot.Window.Handle;
        var hadPair = SlotHasVideoPair(slot);
        var preservePair = hadPair && !source.StartsWith("Slot", StringComparison.OrdinalIgnoreCase) && !source.StartsWith("Todos", StringComparison.OrdinalIgnoreCase);
        AppLogger.Info($"{source}: slot {slot.Number} removido após confirmação de perda; handle=0x{handle.ToInt64():X}; vinculoApagado={!preservePair && hadPair}; vinculoPreservado={preservePair}");
        ShadowMirrorPipLost(slot, handle, source + "/RemoveSlotPipFinal");
        slot.Window = null;
        if (!preservePair)
            ClearSlotPairMetadata(slot.Number);
        slot.IsHidden = false;
        _hiddenPipRects.Remove(handle);
        _lockedGroupModelRects.Remove(handle);
        ClearFixedLayoutExternalResizeEcho(handle, "slot-window-removed");
        CancelReconnectGeometryAuthority(handle, "slot-window-removed");
        _pendingLostPipsBySlot.Remove(slot.Number);
        if (preservePair)
        {
            MarkSlotOffline(slot);
            MarkAutoReturnPending(slot, "pip-window-removed-preserved-pair");
        }
        else
        {
            _autoReturnStatesBySlot.Remove(slot.Number);
            MarkSlotFree(slot);
        }
    }

    private bool IsGenericReconnectBlockedByOpenOperation(PipSlot slot, string source)
    {
        // A autoridade da abertura explícita é o lock da operação, não apenas o campo armado.
        // O campo armado pode ser limpo por uma callback antiga entre dois refreshes do monitor;
        // enquanto o lock ou o lote Abrir todos estiver ativo, nenhum slot offline pode consumir
        // um HWND novo que ainda precisa ser confirmado no slot solicitado.
        if (!_openPipAttemptInProgress && !_openAllPipsInProgress)
            return false;

        var preparedSlot = _armedPipTargetSlotNumber > 0
            ? _armedPipTargetSlotNumber
            : _openPipAttemptSlotNumber;
        AppLogger.InfoAggregated(
            $"smart-reconnect-blocked-by-prepared-open:{slot.Number}",
            TimeSpan.FromSeconds(2),
            $"smart-reconnect-blocked-by-prepared-open: preparedSlot={preparedSlot}; blockedSlot={slot.Number}; " +
            $"source={source}; openAttempt={_openPipAttemptInProgress}; openAll={_openAllPipsInProgress}; " +
            $"armedSlot={_armedPipTargetSlotNumber}; lockSlot={_openPipAttemptSlotNumber}; authority=open-operation");
        return true;
    }

    private static string NormalizeReconnectProcessName(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return string.Empty;
        return Path.GetFileNameWithoutExtension(value.Trim()).ToLowerInvariant();
    }

    private string GetExpectedReconnectProcessName(PipSlot slot)
    {
        var expected = NormalizeReconnectProcessName(slot.Window?.ProcessName);
        if (!string.IsNullOrWhiteSpace(expected)) return expected;

        if (_autoReturnStatesBySlot.TryGetValue(slot.Number, out var autoReturnState))
        {
            expected = NormalizeReconnectProcessName(autoReturnState.ExpectedBrowserProcess);
            if (!string.IsNullOrWhiteSpace(expected)) return expected;
        }

        if (_pendingLostPipsBySlot.TryGetValue(slot.Number, out var pending))
            return NormalizeReconnectProcessName(pending.Window.ProcessName);

        return string.Empty;
    }

    private bool IsReconnectCandidateProcessCompatible(PipSlot slot, PipWindowInfo candidate, string source)
    {
        var expected = GetExpectedReconnectProcessName(slot);
        var actual = NormalizeReconnectProcessName(candidate.ProcessName);
        if (string.IsNullOrWhiteSpace(expected) || string.Equals(expected, actual, StringComparison.OrdinalIgnoreCase))
            return true;

        AppLogger.WarnAggregated(
            $"smart-reconnect-cross-browser-rejected:{slot.Number}:{candidate.Handle.ToInt64():X}",
            TimeSpan.FromSeconds(2),
            $"smart-reconnect-cross-browser-rejected: source={source}; slot={slot.Number}; " +
            $"candidate=0x{candidate.Handle.ToInt64():X}; expectedProcess={expected}; actualProcess={actual}; " +
            "action=keep-slot-reserved");
        return false;
    }

    private PipWindowInfo? TryFindReplacementForSlot(PipSlot slot, IEnumerable<PipWindowInfo> candidates, HashSet<IntPtr> usedHandles)
    {
        if (slot.Window is null) return null;

        if (IsGenericReconnectBlockedByOpenOperation(slot, "TryFindReplacementForSlot"))
            return null;

        if (!string.IsNullOrWhiteSpace(_activeAutoReturnAttemptId)
            && _activeAutoReturnSlotNumber > 0
            && slot.Number != _activeAutoReturnSlotNumber)
        {
            AppLogger.Info($"smart-reconnect-candidate-blocked-by-active-attempt: attemptId={_activeAutoReturnAttemptId}; activeSlot={_activeAutoReturnSlotNumber}; blockedSlot={slot.Number}");
            return null;
        }

        var options = candidates
            .Where(candidate => !usedHandles.Contains(candidate.Handle))
            .Where(candidate => IsReconnectCandidateProcessCompatible(slot, candidate, "TryFindReplacementForSlot"))
            .Where(candidate => string.IsNullOrWhiteSpace(_activeAutoReturnAttemptId)
                || !_autoReturnCandidateAttemptByHwnd.TryGetValue(candidate.Handle, out var claim)
                || string.Equals(claim, _activeAutoReturnAttemptId, StringComparison.Ordinal))
            .Where(candidate => candidate.Handle != slot.Window!.Handle)
            .Select(candidate => EvaluateSlotReconnect(slot, candidate, Slots.Count(item => item.Window is not null && !PipWindowService.IsUsable(item.Window.Handle))))
            .Where(item => item.Score >= 115)
            .OrderByDescending(item => item.Score)
            .ToList();

        if (options.Count == 0) return null;

        var best = options[0];
        var second = options.Skip(1).FirstOrDefault();
        if (second is not null && best.Score - second.Score < 35)
        {
            AppLogger.Warn($"Reconexão inteligente ambígua na captura: slot={slot.Number}; melhor=0x{best.Window.Handle.ToInt64():X}/{best.Score}; segundo=0x{second.Window.Handle.ToInt64():X}/{second.Score}; mantendo reservado");
            return null;
        }

        AppLogger.Info($"Reconexão inteligente escolhida na captura: slot={slot.Number}; novo=0x{best.Window.Handle.ToInt64():X}; score={best.Score}; motivos={best.Reasons}");
        return best.Window;
    }

    private int ReconnectLostSlotsIntelligently(IReadOnlyList<PipSlot> lostSlots, List<PipWindowInfo> candidates, HashSet<IntPtr> usedHandles, string source)
    {
        if (_openPipAttemptInProgress || _openAllPipsInProgress)
        {
            AppLogger.InfoAggregated(
                "smart-reconnect-batch-blocked-by-prepared-open",
                TimeSpan.FromSeconds(2),
                $"smart-reconnect-batch-blocked-by-prepared-open: source={source}; " +
                $"openAttempt={_openPipAttemptInProgress}; openAll={_openAllPipsInProgress}; " +
                $"armedSlot={_armedPipTargetSlotNumber}; lockSlot={_openPipAttemptSlotNumber}; authority=open-operation");
            return 0;
        }

        var slots = lostSlots
            .Where(slot => slot.Window is not null)
            .Where(slot => !PipWindowService.IsUsable(slot.Window!.Handle))
            .OrderBy(slot => slot.Number)
            .ToList();

        // Durante um AutoReturn serializado, somente o slot da tentativa ativa pode
        // consumir uma janela nova. Isso impede a reconexão inteligente de atribuir
        // temporariamente o HWND esperado a outro slot antes da confirmação oficial.
        if (!string.IsNullOrWhiteSpace(_activeAutoReturnAttemptId) && _activeAutoReturnSlotNumber > 0)
        {
            var blockedSlotCount = slots.Count(slot => slot.Number != _activeAutoReturnSlotNumber);
            slots = slots.Where(slot => slot.Number == _activeAutoReturnSlotNumber).ToList();
            AppLogger.Info(
                $"smart-reconnect-restricted-to-active-auto-return-slot: attemptId={_activeAutoReturnAttemptId}; " +
                $"activeSlot={_activeAutoReturnSlotNumber}; blockedSlots={blockedSlotCount}; source={source}");
        }

        if (slots.Count == 0 || candidates.Count == 0) return 0;

        var reconnected = 0;
        var blockedHandles = new HashSet<IntPtr>();

        foreach (var slot in slots)
        {
            var options = candidates
                .Where(candidate => !usedHandles.Contains(candidate.Handle))
                .Where(candidate => !blockedHandles.Contains(candidate.Handle))
                .Where(candidate => IsReconnectCandidateProcessCompatible(slot, candidate, "ReconnectLostSlotsIntelligently"))
                .Where(candidate => candidate.Handle != slot.Window!.Handle)
                .Select(candidate => EvaluateSlotReconnect(slot, candidate, slots.Count))
                .Where(item => item.Score >= 120)
                .OrderByDescending(item => item.Score)
                .ToList();

            if (options.Count == 0) continue;

            var best = options[0];
            var secondForSlot = options.Skip(1).FirstOrDefault();
            if (secondForSlot is not null && best.Score - secondForSlot.Score < 35)
            {
                AppLogger.Warn($"Reconexão inteligente ignorada por ambiguidade no slot {slot.Number}: melhor=0x{best.Window.Handle.ToInt64():X}/{best.Score}; segundo=0x{secondForSlot.Window.Handle.ToInt64():X}/{secondForSlot.Score}");
                continue;
            }

            var competitor = slots
                .Where(other => other.Number != slot.Number && other.Window is not null && !PipWindowService.IsUsable(other.Window.Handle))
                .Where(other => IsReconnectCandidateProcessCompatible(other, best.Window, "ReconnectLostSlotsIntelligently/competitor"))
                .Select(other => EvaluateSlotReconnect(other, best.Window, slots.Count))
                .OrderByDescending(item => item.Score)
                .FirstOrDefault();

            if (competitor is not null && best.Score - competitor.Score < 35)
            {
                AppLogger.Warn($"Reconexão inteligente ignorada: PiP 0x{best.Window.Handle.ToInt64():X} também combina com slot {competitor.Slot.Number}; slotAtual={slot.Number}; scoreAtual={best.Score}; scoreConcorrente={competitor.Score}");
                blockedHandles.Add(best.Window.Handle);
                continue;
            }

            ApplyIntelligentReconnect(slot, best.Window, source, best.Score, best.Reasons);
            usedHandles.Add(best.Window.Handle);
            candidates.RemoveAll(item => item.Handle == best.Window.Handle);
            reconnected++;
        }

        return reconnected;
    }

    private SlotReconnectCandidate EvaluateSlotReconnect(PipSlot slot, PipWindowInfo candidate, int waitingSlotCount)
    {
        var score = 0;
        var reasons = new List<string>();
        var old = slot.Window;
        var reference = GetReconnectReferenceRect(slot);

        if (slot.State == PipSlotState.Offline)
        {
            score += 45;
            reasons.Add("slot-offline:+45");
        }

        if (_pendingLostPipsBySlot.TryGetValue(slot.Number, out var pending))
        {
            score += 50;
            reasons.Add("perda-pendente:+50");

            var ageSeconds = (DateTime.UtcNow - pending.FirstLostUtc).TotalSeconds;
            var limit = pending.HadVideoPair ? PairedPipLostGraceSeconds : PipLostGraceSeconds;
            if (ageSeconds <= limit)
            {
                score += 25;
                reasons.Add($"janela-tempo:{ageSeconds:0}s:+25");
            }
        }

        if (waitingSlotCount == 1)
        {
            score += 35;
            reasons.Add("unico-reservado:+35");
        }

        if (SlotHasVideoPair(slot))
        {
            score += 25;
            reasons.Add("vinculo-preservado:+25");
        }

        if (old is not null)
        {
            if (string.Equals(candidate.ProcessName, old.ProcessName, StringComparison.OrdinalIgnoreCase))
            {
                score += 20;
                reasons.Add("processo-igual:+20");
            }

            if (candidate.ProcessId == old.ProcessId)
            {
                score += 15;
                reasons.Add("pid-igual:+15");
            }

            if (string.Equals(candidate.ClassName, old.ClassName, StringComparison.OrdinalIgnoreCase))
            {
                score += 10;
                reasons.Add("classe-igual:+10");
            }
        }

        if (reference.IsValid && candidate.VisualRect.IsValid)
        {
            var distance = Math.Abs(candidate.VisualRect.Left - reference.Left) + Math.Abs(candidate.VisualRect.Top - reference.Top);
            if (distance <= 60)
            {
                score += 45;
                reasons.Add($"posicao-muito-proxima:{distance}:+45");
            }
            else if (distance <= 140)
            {
                score += 30;
                reasons.Add($"posicao-proxima:{distance}:+30");
            }
            else if (distance <= 260)
            {
                score += 15;
                reasons.Add($"posicao-aceitavel:{distance}:+15");
            }

            var sizeDiff = Math.Abs(candidate.VisualRect.Width - reference.Width) + Math.Abs(candidate.VisualRect.Height - reference.Height);
            if (sizeDiff <= 30)
            {
                score += 10;
                reasons.Add($"tamanho-parecido:{sizeDiff}:+10");
            }
        }

        return new SlotReconnectCandidate(slot, candidate, score, string.Join(", ", reasons));
    }

    private NativeRect GetReconnectReferenceRect(PipSlot slot)
    {
        if (TryGetSlotNavigationGeometryTarget(slot.Number, out var navigationTarget))
            return navigationTarget;
        if (_lastManualUserRectBySlot.TryGetValue(slot.Number, out var stableUserRect) && stableUserRect.IsValid)
            return stableUserRect;
        if (slot.Window is null) return default;

        var handle = slot.Window.Handle;
        if (_hiddenPipRects.TryGetValue(handle, out var hiddenRect) && hiddenRect.IsValid)
            return hiddenRect;

        // Hotfix 6: the last real rect before loss is authoritative for reconnect size.
        // A newly published intrinsic aspect must not inflate the replacement window.
        if (_pendingLostPipsBySlot.TryGetValue(slot.Number, out var pending) && pending.Window.VisualRect.IsValid)
            return pending.Window.VisualRect;

        if (_lockedGroupModelRects.TryGetValue(handle, out var modelRect) && modelRect.IsValid)
            return modelRect;

        if (TryGetFixedSlotRect(slot.Number, out var fixedRect))
            return fixedRect;

        return slot.Window.VisualRect;
    }


    private NativeRect GetNavigationGeometryWorkArea()
    {
        var workArea = GetSelectedLayoutMonitor()?.WorkArea ?? PipWindowService.GetVirtualScreenBounds();
        return workArea.IsValid ? workArea : new NativeRect(0, 0, 1920, 1080);
    }

    private static NativeRect AnchorContainedRect(NativeRect container, int width, int height, NativeRect workArea)
    {
        var distanceRight = Math.Abs(workArea.Right - container.Right);
        var distanceLeft = Math.Abs(container.Left - workArea.Left);
        var distanceBottom = Math.Abs(workArea.Bottom - container.Bottom);
        var distanceTop = Math.Abs(container.Top - workArea.Top);
        var left = distanceRight <= distanceLeft ? container.Right - width : container.Left;
        var top = distanceBottom < distanceTop ? container.Bottom - height : container.Top;
        return ClampRectInsideWorkArea(new NativeRect(left, top, left + width, top + height), workArea, margin: 8);
    }

    private bool IsSafeNavigationGeometry(NativeRect candidate, NativeRect workArea)
    {
        if (!candidate.IsValid || !workArea.IsValid) return false;
        var maxWidth = Math.Min(NavigationGeometrySafeMaxWidthPx, Math.Max(320, (int)Math.Round(workArea.Width * 0.45)));
        var maxHeight = Math.Min(NavigationGeometrySafeMaxHeightPx, Math.Max(240, (int)Math.Round(workArea.Height * 0.65)));
        var maxArea = Math.Max(320L * 180L, (long)Math.Round((long)workArea.Width * workArea.Height * NavigationGeometrySafeMaxWorkAreaFraction));
        var area = (long)candidate.Width * candidate.Height;
        return candidate.Width <= maxWidth && candidate.Height <= maxHeight && area <= maxArea;
    }

    private NativeRect BuildSafeNavigationGeometry(NativeRect candidate, double preferredAspectRatio = 0)
    {
        var workArea = GetNavigationGeometryWorkArea();
        if (candidate.IsValid && IsSafeNavigationGeometry(candidate, workArea))
            return ClampRectInsideWorkArea(candidate, workArea, margin: 8);

        var ratio = preferredAspectRatio > 0.20 && preferredAspectRatio < 5.0
            ? preferredAspectRatio
            : (candidate.IsValid && candidate.Height > 0 ? candidate.Width / (double)candidate.Height : 16.0 / 9.0);
        ratio = Math.Clamp(ratio, 0.35, 2.85);
        var maxWidth = Math.Min(NavigationGeometrySafeMaxWidthPx, Math.Max(320, (int)Math.Round(workArea.Width * 0.45)));
        var maxHeight = Math.Min(NavigationGeometrySafeMaxHeightPx, Math.Max(240, (int)Math.Round(workArea.Height * 0.65)));
        var maxArea = Math.Max(320.0 * 180.0, workArea.Width * (double)workArea.Height * NavigationGeometrySafeMaxWorkAreaFraction);
        var width = maxWidth;
        var height = (int)Math.Round(width / ratio);
        if (height > maxHeight)
        {
            height = maxHeight;
            width = (int)Math.Round(height * ratio);
        }
        var area = width * (double)height;
        if (area > maxArea)
        {
            var scale = Math.Sqrt(maxArea / area);
            width = Math.Max(220, (int)Math.Floor(width * scale));
            height = Math.Max(135, (int)Math.Floor(height * scale));
        }
        var anchor = candidate.IsValid
            ? candidate
            : new NativeRect(workArea.Right - width - 8, workArea.Top + 8, workArea.Right - 8, workArea.Top + height + 8);
        return AnchorContainedRect(anchor, width, height, workArea);
    }

    private NativeRect FitAspectInsideGeometryBox(NativeRect box, double preferredAspectRatio)
    {
        if (!box.IsValid || preferredAspectRatio <= 0.20 || preferredAspectRatio >= 5.0)
            return box;
        var ratio = Math.Clamp(preferredAspectRatio, 0.35, 2.85);
        var width = box.Width;
        var height = (int)Math.Round(width / ratio);
        if (height > box.Height)
        {
            height = box.Height;
            width = (int)Math.Round(height * ratio);
        }
        width = Math.Max(180, Math.Min(width, box.Width));
        height = Math.Max(120, Math.Min(height, box.Height));
        return AnchorContainedRect(box, width, height, GetNavigationGeometryWorkArea());
    }

    private void ArmSlotNavigationGeometryAuthority(PipSlot slot, string source)
    {
        var sourceHandle = slot.Window?.Handle ?? IntPtr.Zero;
        var observed = sourceHandle != IntPtr.Zero && PipWindowService.IsUsable(sourceHandle)
            ? PipWindowService.GetVisualRect(sourceHandle)
            : (slot.Window?.VisualRect ?? default);
        if (observed.IsValid)
            _lastObservedRectBySlot[slot.Number] = observed;

        var usesManualRect = _lastManualUserRectBySlot.TryGetValue(slot.Number, out var manualRect) && manualRect.IsValid;
        var target = usesManualRect ? manualRect : BuildSafeNavigationGeometry(observed);
        if (!target.IsValid)
        {
            AppLogger.Info($"slot-navigation-geometry-authority-skipped: slot={slot.Number}; source={source}; reason=no-safe-or-manual-rect");
            return;
        }
        if (!usesManualRect && observed.IsValid && target != observed)
        {
            _lastBrowserAutomaticRectBySlot[slot.Number] = observed;
            AppLogger.Warn(
                $"slot-navigation-geometry-safe-fallback: slot={slot.Number}; observed={FormatRect(observed)}; " +
                $"safe={FormatRect(target)}; source={source}; reason=no-trusted-manual-rect");
        }

        var generation = _reconnectGeometryGenerationBySlot.TryGetValue(slot.Number, out var current)
            ? current + 1
            : 1;
        _reconnectGeometryGenerationBySlot[slot.Number] = generation;
        var now = DateTime.UtcNow;
        _slotNavigationGeometryAuthorityBySlot[slot.Number] = new SlotNavigationGeometryAuthorityState(
            slot.Number,
            target,
            generation,
            now,
            now.AddMilliseconds(SlotNavigationGeometryAuthorityDurationMs),
            source,
            sourceHandle,
            usesManualRect);
        AppLogger.Info(
            $"slot-navigation-geometry-authority-armed: slot={slot.Number}; generation={generation}; " +
            $"durationMs={SlotNavigationGeometryAuthorityDurationMs}; target={FormatRect(target)}; " +
            $"sourceHandle=0x{sourceHandle.ToInt64():X}; authority={(usesManualRect ? "manual-user-rect" : "safe-fallback")}; source={source}");
    }

    private bool TryGetSlotNavigationGeometryTarget(int slotNumber, out NativeRect target)
    {
        target = default;
        if (!_slotNavigationGeometryAuthorityBySlot.TryGetValue(slotNumber, out var state))
            return false;
        if (DateTime.UtcNow > state.ExpiresUtc)
        {
            _slotNavigationGeometryAuthorityBySlot.Remove(slotNumber);
            AppLogger.Info(
                $"slot-navigation-geometry-authority-expired: slot={slotNumber}; generation={state.Generation}; source={state.Source}");
            return false;
        }
        target = state.TargetRect;
        return target.IsValid;
    }

    private void CancelSlotNavigationGeometryAuthority(int slotNumber, string source)
    {
        if (_slotNavigationGeometryAuthorityBySlot.Remove(slotNumber, out var state))
            AppLogger.Info(
                $"slot-navigation-geometry-authority-cancelled: slot={slotNumber}; generation={state.Generation}; source={source}");
    }

    private bool IsConfirmedManualResizeGesture(IntPtr handle)
    {
        if (handle == IntPtr.Zero
            || handle != _manualResizeCandidateHandle
            || !_manualResizeCandidateStartRect.IsValid)
            return false;
        var current = PipWindowService.GetVisualRect(handle);
        return current.IsValid
            && (Math.Abs(current.Width - _manualResizeCandidateStartRect.Width) > LayoutMoveSizeTolerancePx
                || Math.Abs(current.Height - _manualResizeCandidateStartRect.Height) > LayoutMoveSizeTolerancePx);
    }

    private bool BindSlotNavigationGeometryAuthority(PipSlot slot, IntPtr newHandle, string source, double preferredAspectRatio = 0)
    {
        if (newHandle == IntPtr.Zero || !TryGetSlotNavigationGeometryTarget(slot.Number, out var authorityBox))
            return false;
        var target = FitAspectInsideGeometryBox(authorityBox, preferredAspectRatio);
        if (_slotNavigationGeometryAuthorityBySlot.TryGetValue(slot.Number, out var slotAuthority))
        {
            _slotNavigationGeometryAuthorityBySlot[slot.Number] = slotAuthority with
            {
                TargetRect = target,
                ArmedUtc = DateTime.UtcNow,
                ExpiresUtc = DateTime.UtcNow.AddMilliseconds(ReconnectGeometryAuthorityDurationMs),
                Source = $"bound/{source}"
            };
        }
        ArmReconnectGeometryAuthority(slot, newHandle, target, $"slot-authority/{source}");
        var before = PipWindowService.GetVisualRect(newHandle);
        if (ReconnectGeometryDiffers(before, target))
        {
            _lastBrowserAutomaticRectBySlot[slot.Number] = before;
            PipWindowService.MoveAndResizeVisual(newHandle, target);
        }
        var after = PipWindowService.GetVisualRect(newHandle);
        if (slot.Window is not null && slot.Window.Handle == newHandle && after.IsValid)
            slot.RefreshWindow(slot.Window with { VisualRect = after });
        if (after.IsValid)
            _lastObservedRectBySlot[slot.Number] = after;
        AppLogger.Info(
            $"slot-navigation-geometry-authority-bound: slot={slot.Number}; hwnd=0x{newHandle.ToInt64():X}; " +
            $"box={FormatRect(authorityBox)}; target={FormatRect(target)}; preferredAspect={preferredAspectRatio:0.###}; " +
            $"before={FormatRect(before)}; after={FormatRect(after)}; source={source}");
        _ = VerifyReconnectedWindowGeometryAsync(slot.Number, newHandle, target, $"slot-authority/{source}");
        return true;
    }

    private bool ApplyPreparedCaptureGeometryGuard(PipSlot slot, IntPtr newHandle, double preferredAspectRatio, string source)
    {
        if (newHandle == IntPtr.Zero || !PipWindowService.IsUsable(newHandle))
            return false;
        var before = PipWindowService.GetVisualRect(newHandle);
        if (before.IsValid)
            _lastObservedRectBySlot[slot.Number] = before;
        var usesManual = _lastManualUserRectBySlot.TryGetValue(slot.Number, out var manualRect) && manualRect.IsValid;
        var box = usesManual ? manualRect : BuildSafeNavigationGeometry(before, preferredAspectRatio);
        var target = FitAspectInsideGeometryBox(box, preferredAspectRatio);
        if (!target.IsValid)
            return false;
        if (before.IsValid && before != target)
            _lastBrowserAutomaticRectBySlot[slot.Number] = before;
        ArmReconnectGeometryAuthority(slot, newHandle, target, $"prepared-capture/{source}");
        if (ReconnectGeometryDiffers(before, target))
            PipWindowService.MoveAndResizeVisual(newHandle, target);
        var after = PipWindowService.GetVisualRect(newHandle);
        if (slot.Window is not null && slot.Window.Handle == newHandle && after.IsValid)
            slot.RefreshWindow(slot.Window with { VisualRect = after });
        if (after.IsValid)
            _lastObservedRectBySlot[slot.Number] = after;
        AppLogger.Info(
            $"prepared-capture-geometry-guard-applied: slot={slot.Number}; hwnd=0x{newHandle.ToInt64():X}; " +
            $"authority={(usesManual ? "manual-user-rect" : "safe-fallback")}; box={FormatRect(box)}; " +
            $"target={FormatRect(target)}; before={FormatRect(before)}; after={FormatRect(after)}; source={source}");
        _ = VerifyReconnectedWindowGeometryAsync(slot.Number, newHandle, target, source);
        return true;
    }

    private bool TryGetReconnectGeometryTarget(int slotNumber, IntPtr handle, out NativeRect target)
    {
        target = default;
        if (!_reconnectGeometryAuthorityByHwnd.TryGetValue(handle, out var state)
            || state.SlotNumber != slotNumber
            || DateTime.UtcNow > state.ExpiresUtc)
            return false;
        target = state.TargetRect;
        return target.IsValid;
    }

    private NativeRect ClampLayoutTargetToGeometryAuthority(PipSlot slot, NativeRect candidate, string source)
    {
        if (TryGetSlotNavigationGeometryTarget(slot.Number, out var slotTarget))
        {
            if (candidate != slotTarget)
                AppLogger.Info($"layout-target-clamped-before-apply: slot={slot.Number}; candidate={FormatRect(candidate)}; target={FormatRect(slotTarget)}; source={source}; authority=slot-navigation");
            return slotTarget;
        }
        if (slot.Window is not null && TryGetReconnectGeometryTarget(slot.Number, slot.Window.Handle, out var reconnectTarget))
        {
            if (candidate != reconnectTarget)
                AppLogger.Info($"layout-target-clamped-before-apply: slot={slot.Number}; candidate={FormatRect(candidate)}; target={FormatRect(reconnectTarget)}; source={source}; authority=reconnect-hwnd");
            return reconnectTarget;
        }
        return candidate;
    }

    private static bool ReconnectGeometryDiffers(NativeRect current, NativeRect target)
    {
        if (!current.IsValid || !target.IsValid) return true;
        return Math.Abs(current.Left - target.Left) > LayoutMovePositionTolerancePx
            || Math.Abs(current.Top - target.Top) > LayoutMovePositionTolerancePx
            || Math.Abs(current.Width - target.Width) > LayoutMoveSizeTolerancePx
            || Math.Abs(current.Height - target.Height) > LayoutMoveSizeTolerancePx;
    }

    private static bool IsReconnectGeometryOversized(NativeRect candidate, NativeRect reference)
    {
        if (!candidate.IsValid || !reference.IsValid) return false;
        var referenceArea = (long)reference.Width * reference.Height;
        var candidateArea = (long)candidate.Width * candidate.Height;
        return candidate.Width > Math.Max(reference.Width + 120, (int)Math.Ceiling(reference.Width * 1.60))
            || candidate.Height > Math.Max(reference.Height + 120, (int)Math.Ceiling(reference.Height * 1.60))
            || (referenceArea > 0 && candidateArea > referenceArea * 2);
    }

    private NativeRect BuildReconnectGeometryTarget(PipSlot slot, NativeRect referenceRect)
    {
        if (TryGetSlotNavigationGeometryTarget(slot.Number, out var navigationTarget))
            return navigationTarget;
        if (!referenceRect.IsValid && TryGetFixedSlotRect(slot.Number, out var onlyFixed))
            return onlyFixed;
        if (!referenceRect.IsValid)
            return default;

        if (!TryGetFixedSlotRect(slot.Number, out var fixedRect))
            return referenceRect;

        if (!IsReconnectGeometryOversized(fixedRect, referenceRect))
            return fixedRect;

        var preserved = new NativeRect(
            fixedRect.Left,
            fixedRect.Top,
            fixedRect.Left + referenceRect.Width,
            fixedRect.Top + referenceRect.Height);
        var workArea = GetSelectedLayoutMonitor()?.WorkArea ?? PipWindowService.GetVirtualScreenBounds();
        preserved = ClampRectInsideWorkArea(preserved, workArea, margin: 8);
        AppLogger.Warn(
            $"reconnect-oversized-layout-target-clamped: slot={slot.Number}; fixedTarget={FormatRect(fixedRect)}; " +
            $"previousRect={FormatRect(referenceRect)}; preservedTarget={FormatRect(preserved)}; " +
            "reason=prevent-reconnect-size-inflation");
        SetFixedSlotAuthorityRect(slot.Number, preserved, "reconnect-oversized-layout-target-clamped");
        return preserved;
    }

    private void ArmReconnectGeometryAuthority(PipSlot slot, IntPtr handle, NativeRect target, string source)
    {
        if (handle == IntPtr.Zero || !target.IsValid) return;
        var generation = _reconnectGeometryGenerationBySlot.TryGetValue(slot.Number, out var current)
            ? current + 1
            : 1;
        _reconnectGeometryGenerationBySlot[slot.Number] = generation;
        var now = DateTime.UtcNow;
        _reconnectGeometryAuthorityByHwnd[handle] = new ReconnectGeometryAuthorityState(
            slot.Number,
            handle,
            target,
            generation,
            now,
            now.AddMilliseconds(ReconnectGeometryAuthorityDurationMs),
            source);
        _windowEventFlowControl.ArmInternalMovementSuppression(
            [handle],
            generation,
            TimeSpan.FromMilliseconds(ReconnectGeometryAuthorityDurationMs + 500),
            "reconnect-geometry-authority");
        AppLogger.Info(
            $"reconnect-geometry-authority-armed: slot={slot.Number}; hwnd=0x{handle.ToInt64():X}; " +
            $"generation={generation}; durationMs={ReconnectGeometryAuthorityDurationMs}; target={FormatRect(target)}; source={source}");
    }

    private bool IsReconnectGeometryAuthorityActive(int slotNumber, IntPtr handle)
    {
        if (!_reconnectGeometryAuthorityByHwnd.TryGetValue(handle, out var state)
            || state.SlotNumber != slotNumber)
            return false;
        if (DateTime.UtcNow <= state.ExpiresUtc)
            return true;
        _reconnectGeometryAuthorityByHwnd.Remove(handle);
        return false;
    }

    private void CancelReconnectGeometryAuthority(IntPtr handle, string source)
    {
        if (handle == IntPtr.Zero) return;
        if (_reconnectGeometryAuthorityByHwnd.Remove(handle, out var state))
            AppLogger.Info(
                $"reconnect-geometry-authority-cancelled: slot={state.SlotNumber}; hwnd=0x{handle.ToInt64():X}; " +
                $"generation={state.Generation}; source={source}");
    }

    private bool TryEnforceReconnectGeometryAuthority(PipSlot slot, NativeRect observed, string source)
    {
        if (slot.Window is null
            || !_reconnectGeometryAuthorityByHwnd.TryGetValue(slot.Window.Handle, out var state)
            || state.SlotNumber != slot.Number)
            return false;

        if (DateTime.UtcNow > state.ExpiresUtc)
        {
            _reconnectGeometryAuthorityByHwnd.Remove(slot.Window.Handle);
            AppLogger.Info(
                $"reconnect-geometry-authority-expired: slot={slot.Number}; hwnd=0x{slot.Window.Handle.ToInt64():X}; " +
                $"generation={state.Generation}; source={source}");
            return false;
        }

        if (IsConfirmedManualResizeGesture(slot.Window.Handle))
        {
            CancelReconnectGeometryAuthority(slot.Window.Handle, "manual-pip-resize-confirmed");
            CancelSlotNavigationGeometryAuthority(slot.Number, "manual-pip-resize-confirmed");
            return false;
        }

        var before = observed.IsValid ? observed : PipWindowService.GetVisualRect(slot.Window.Handle);
        var corrected = ReconnectGeometryDiffers(before, state.TargetRect);
        if (corrected)
        {
            if (before.IsValid) _lastBrowserAutomaticRectBySlot[slot.Number] = before;
            PipWindowService.MoveAndResizeVisual(slot.Window.Handle, state.TargetRect);
            var afterCorrection = PipWindowService.GetVisualRect(slot.Window.Handle);
            if (afterCorrection.IsValid)
                slot.RefreshWindow(slot.Window with { VisualRect = afterCorrection });
            AppLogger.WarnAggregated(
                $"reconnect-geometry-corrected:{slot.Number}:{state.Generation}",
                TimeSpan.FromMilliseconds(350),
                $"reconnect-geometry-corrected: slot={slot.Number}; hwnd=0x{slot.Window.Handle.ToInt64():X}; " +
                $"generation={state.Generation}; source={source}; before={FormatRect(before)}; " +
                $"target={FormatRect(state.TargetRect)}; after={FormatRect(afterCorrection)}; " +
                "reason=browser-size-inflation-blocked");
        }
        return true;
    }

    private void RestoreReconnectedWindowPosition(
        PipSlot slot,
        IntPtr oldHandle,
        IntPtr newHandle,
        NativeRect referenceRect,
        string source)
    {
        referenceRect = BuildReconnectGeometryTarget(slot, referenceRect);
        var fixedAuthorityPosition = TryGetFixedSlotRect(slot.Number, out _);

        if (newHandle == IntPtr.Zero || (oldHandle != IntPtr.Zero && oldHandle == newHandle) || !referenceRect.IsValid)
        {
            AppLogger.Info($"reconnect-position-restore-skipped: slot={slot.Number}; source={source}; old=0x{oldHandle.ToInt64():X}; new=0x{newHandle.ToInt64():X}; reason=invalid-reference-or-same-hwnd");
            return;
        }

        if (!PipWindowService.IsUsable(newHandle))
        {
            AppLogger.Info($"reconnect-position-restore-skipped: slot={slot.Number}; source={source}; old=0x{oldHandle.ToInt64():X}; new=0x{newHandle.ToInt64():X}; reason=new-hwnd-not-usable");
            return;
        }

        ArmReconnectGeometryAuthority(slot, newHandle, referenceRect, source);
        var before = PipWindowService.GetVisualRect(newHandle);
        var corrected = ReconnectGeometryDiffers(before, referenceRect);
        if (corrected)
            PipWindowService.MoveAndResizeVisual(newHandle, referenceRect);

        var after = PipWindowService.GetVisualRect(newHandle);
        if (slot.Window is not null && slot.Window.Handle == newHandle && after.IsValid)
            slot.RefreshWindow(slot.Window with { VisualRect = after });

        AppLogger.Info(
            $"reconnect-position-restored: phase=immediate; slot={slot.Number}; source={source}; " +
            $"old=0x{oldHandle.ToInt64():X}; new=0x{newHandle.ToInt64():X}; corrected={corrected}; " +
            $"target={FormatRect(referenceRect)}; before={FormatRect(before)}; after={FormatRect(after)}; " +
            $"fixedAuthorityPosition={fixedAuthorityPosition}; sizePreserved=True; resize=True");

        _ = VerifyReconnectedWindowGeometryAsync(slot.Number, newHandle, referenceRect, source);
    }

    private async Task VerifyReconnectedWindowGeometryAsync(
        int slotNumber,
        IntPtr newHandle,
        NativeRect referenceRect,
        string source)
    {
        try
        {
            var previousCheckpoint = 0;
            foreach (var checkpoint in ReconnectGeometryVerifyCheckpointsMs)
            {
                await Task.Delay(Math.Max(0, checkpoint - previousCheckpoint));
                previousCheckpoint = checkpoint;
                await Dispatcher.InvokeAsync(() =>
                {
                    var slot = Slots.FirstOrDefault(item => item.Number == slotNumber);
                    if (slot is null || slot.Window is null || slot.Window.Handle != newHandle || !PipWindowService.IsUsable(newHandle))
                    {
                        CancelReconnectGeometryAuthority(newHandle, "slot-or-hwnd-changed");
                        return;
                    }

                    if (!IsReconnectGeometryAuthorityActive(slotNumber, newHandle))
                        return;

                    if (IsConfirmedManualResizeGesture(newHandle))
                    {
                        CancelReconnectGeometryAuthority(newHandle, "manual-pip-resize-confirmed");
                        CancelSlotNavigationGeometryAuthority(slotNumber, "manual-pip-resize-confirmed");
                        return;
                    }

                    var before = PipWindowService.GetVisualRect(newHandle);
                    var corrected = ReconnectGeometryDiffers(before, referenceRect);
                    if (corrected)
                        PipWindowService.MoveAndResizeVisual(newHandle, referenceRect);
                    var after = PipWindowService.GetVisualRect(newHandle);
                    if (after.IsValid)
                        slot.RefreshWindow(slot.Window with { VisualRect = after });

                    AppLogger.Info(
                        $"reconnect-position-restored: phase=verify-{checkpoint}ms; slot={slotNumber}; source={source}; " +
                        $"new=0x{newHandle.ToInt64():X}; corrected={corrected}; target={FormatRect(referenceRect)}; " +
                        $"before={FormatRect(before)}; after={FormatRect(after)}; sizePreserved=True; resize=True");
                });
            }
        }
        catch (Exception ex)
        {
            AppLogger.Error($"Falha ao verificar geometria restaurada do slot {slotNumber}; source={source}; hwnd=0x{newHandle.ToInt64():X}", ex);
        }
    }

    private void ApplyIntelligentReconnect(PipSlot slot, PipWindowInfo replacement, string source, int score, string reasons)
    {
        if (slot.Window is null) return;

        var oldHandle = slot.Window.Handle;
        var reconnectReference = GetReconnectReferenceRect(slot);

        if (_hiddenPipRects.TryGetValue(oldHandle, out var hiddenRect))
        {
            _hiddenPipRects.Remove(oldHandle);
            _hiddenPipRects[replacement.Handle] = hiddenRect;
        }
        else
        {
            _hiddenPipRects.Remove(oldHandle);
        }

        if (_lockedGroupModelRects.TryGetValue(oldHandle, out var modelRect))
        {
            _lockedGroupModelRects.Remove(oldHandle);
            _lockedGroupModelRects[replacement.Handle] = modelRect;
        }

        slot.RefreshWindow(replacement);
        slot.IsHidden = false;
        MarkSlotActive(slot);
        ClearLostSlotState(slot);
        RestoreReconnectedWindowPosition(slot, oldHandle, replacement.Handle, reconnectReference, $"ApplyIntelligentReconnect/{source}");
        RefreshSlotPairVisual(slot);

        AppLogger.Info($"Reconexão inteligente: {source}; slot={slot.Number}; antigo=0x{oldHandle.ToInt64():X}; novo=0x{replacement.Handle.ToInt64():X}; score={score}; motivos={reasons}");
        ClassifyReconnectedNewHwnd(slot, oldHandle, replacement.Handle, source, $"intelligent-reconnect-score-{score}");
    }

    private bool TryReconnectSlotWindow(PipSlot slot, IReadOnlyList<PipWindowInfo> discovered, HashSet<IntPtr> usedHandles, string source)
    {
        if (slot.Window is null) return false;

        var handle = slot.Window.Handle;
        var reconnectReference = GetReconnectReferenceRect(slot);
        var replacement = TryFindReplacementForSlot(slot, discovered, usedHandles);
        if (replacement is null) return false;

        if (_hiddenPipRects.TryGetValue(handle, out var hiddenRect))
        {
            _hiddenPipRects.Remove(handle);
            _hiddenPipRects[replacement.Handle] = hiddenRect;
        }
        else
        {
            _hiddenPipRects.Remove(handle);
        }
        if (_lockedGroupModelRects.TryGetValue(handle, out var modelRect))
        {
            _lockedGroupModelRects.Remove(handle);
            _lockedGroupModelRects[replacement.Handle] = modelRect;
        }

        slot.RefreshWindow(replacement);
        slot.IsHidden = false;
        MarkSlotActive(slot);
        usedHandles.Add(replacement.Handle);
        ClearLostSlotState(slot);
        RestoreReconnectedWindowPosition(slot, handle, replacement.Handle, reconnectReference, $"TryReconnectSlotWindow/{source}");
        AppLogger.Info($"{source}: slot {slot.Number} reconectado a novo HWND; antigo=0x{handle.ToInt64():X}, novo=0x{replacement.Handle.ToInt64():X}; vínculoPreservado={SlotHasVideoPair(slot)}");
        ClassifyReconnectedNewHwnd(slot, handle, replacement.Handle, source, "try-reconnect-slot-window");
        return true;
    }

    private (int Removed, int Active) CleanupLostPipsForVisibility(string source)
    {
        var removed = 0;
        var active = 0;

        foreach (var slot in Slots.Where(slot => slot.Window is not null).ToArray())
        {
            var handle = slot.Window!.Handle;
            if (PipWindowService.IsUsable(handle))
            {
                active++;
                ClearLostSlotState(slot);
                continue;
            }

            if (!ShouldRemoveLostSlot(slot, source))
            {
                continue;
            }

            RemoveSlotPipFinal(slot, source);
            removed++;
        }

        if (removed > 0)
        {
            UpdateCounts();
            UpdateSelectedActions();
            RefreshPipDragTargets();
            if (_groupLocked)
                SaveLockedGroupModelFromCurrentRects();
        }

        return (removed, active);
    }

    private void ReleaseSelectedButton_Click(object sender, RoutedEventArgs e)
    {
        if (SelectedSlot is null) return;
        ClearSlotCompletely(SelectedSlot, "Soltar slot");
        UpdateCounts();
        UpdateSelectedActions();
        PositionToolbar();
        RefreshPipDragTargets();
        RefreshVideoPickerVisualStates();
    }

    private void ClearSelectedSlotButton_Click(object sender, RoutedEventArgs e)
    {
        if (SelectedSlot is null)
        {
            SetStatus("Nenhum slot selecionado");
            return;
        }

        var number = SelectedSlot.Number;
        ClearSlotCompletely(SelectedSlot, "Limpar slot manual");
        UpdateCounts();
        UpdateSelectedActions(setStatus: false);
        PositionToolbar();
        RefreshPipDragTargets();
        RefreshVideoPickerVisualStates();
        SetStatus($"Slot {number} limpo e liberado para a próxima captura/preparação");
    }

    private void ReleaseAllButton_Click(object sender, RoutedEventArgs e)
    {
        foreach (var slot in Slots)
        {
            slot.Window = null;
            MarkSlotFree(slot);
        }
        _slotVideoPairs.Clear();
        _slotStableVideoPairs.Clear();
        _slotPairedTabIds.Clear();
        _slotPairDomains.Clear();
        _slotIntrinsicContentAspectRatios.Clear();
        _missingPairLoggedSlots.Clear();
        _pendingLostPipsBySlot.Clear();
        _awaitingPipSlotNumber = null;
        RefreshAllSlotPairVisuals();
        _allHidden = false;
        VisibilityButton.Content = "Ocultar PiPs";
        _toolbar?.SetHiddenState(false);
        UpdateMainQuickActionLabels();
        UpdateCounts();
        UpdateSelectedActions();
        ClearPipDragTargets();
        SetStatus("Todos os slots foram liberados");
        AppLogger.Info("Todos os slots foram liberados");
    }

    private void OpenLogsButton_Click(object sender, RoutedEventArgs e) => AppLogger.OpenDataFolder();

    private void OpenDataFolderButton_Click(object sender, RoutedEventArgs e) => AppLogger.OpenDataFolder();

    private void OpenLogFileButton_Click(object sender, RoutedEventArgs e)
    {
        AppLogger.OpenLogFile();
        SetStatus("Log aberto");
    }

    private void ShowStrongDiagnosticButton_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var window = new Window
            {
                Title = "Diagnóstico forte — PiP Manager",
                Width = 920,
                Height = 680,
                Owner = this,
                WindowStartupLocation = WindowStartupLocation.CenterOwner,
                Background = System.Windows.Media.Brushes.Black
            };

            var root = new DockPanel { Margin = new Thickness(10) };
            var buttons = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, 0, 8) };
            var copy = new Button { Content = "Copiar", Width = 86, Margin = new Thickness(0, 0, 6, 0) };
            var save = new Button { Content = "Salvar", Width = 86, Margin = new Thickness(0, 0, 6, 0) };
            var close = new Button { Content = "Fechar", Width = 86 };

            var textBox = new TextBox
            {
                Text = BuildDiagnosticText(),
                IsReadOnly = true,
                AcceptsReturn = true,
                AcceptsTab = true,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Auto,
                FontFamily = new System.Windows.Media.FontFamily("Consolas"),
                FontSize = 12,
                TextWrapping = TextWrapping.NoWrap
            };

            copy.Click += (_, _) =>
            {
                Clipboard.SetText(textBox.Text);
                SetStatus("Diagnóstico forte copiado");
            };
            save.Click += (_, _) =>
            {
                AppLogger.WriteDiagnostic(textBox.Text);
                SetStatus("Diagnóstico forte salvo");
            };
            close.Click += (_, _) => window.Close();

            buttons.Children.Add(copy);
            buttons.Children.Add(save);
            buttons.Children.Add(close);
            DockPanel.SetDock(buttons, Dock.Top);
            root.Children.Add(buttons);
            root.Children.Add(textBox);
            window.Content = root;
            window.ShowDialog();
        }
        catch (Exception ex)
        {
            AppLogger.Error("Falha ao abrir diagnóstico forte", ex);
            MessageBox.Show("Não foi possível abrir o diagnóstico forte.", "PiP Manager",
                MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }

    private void CopyDiagnosticButton_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var text = BuildDiagnosticText();
            Clipboard.SetText(text);
            AppLogger.Info("Diagnóstico copiado para a área de transferência");
            SetStatus("Diagnóstico copiado");
        }
        catch (Exception ex)
        {
            AppLogger.Error("Falha ao copiar diagnóstico", ex);
            MessageBox.Show("Não foi possível copiar o diagnóstico.", "PiP Manager",
                MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }

    private void SaveDiagnosticButton_Click(object sender, RoutedEventArgs e)
    {
        var text = BuildDiagnosticText();
        AppLogger.WriteDiagnostic(text);
        SetStatus("Diagnóstico salvo");
        AppLogger.OpenDataFolder();
    }

    private void ClearLogsButton_Click(object sender, RoutedEventArgs e)
    {
        var result = MessageBox.Show(
            "Deseja limpar os arquivos de log e diagnóstico?",
            "PiP Manager",
            MessageBoxButton.YesNo,
            MessageBoxImage.Question);

        if (result != MessageBoxResult.Yes) return;

        SetStatus(AppLogger.ClearLogs() ? "Logs limpos" : "Falha ao limpar logs");
    }

    private string BuildDiagnosticText()
    {
        var sb = new StringBuilder();
        sb.AppendLine(AppLogger.BuildEnvironmentDiagnosticHeader());

        var occupiedSlots = Slots.Where(slot => slot.Window is not null).OrderBy(slot => slot.Number).ToList();
        var usableSlots = occupiedSlots.Where(slot => slot.Window is not null && PipWindowService.IsUsable(slot.Window.Handle)).ToList();
        var duplicateHandles = occupiedSlots
            .Where(slot => slot.Window is not null)
            .GroupBy(slot => slot.Window!.Handle)
            .Where(group => group.Count() > 1)
            .Select(group => new { Handle = group.Key, Slots = group.Select(slot => slot.Number).OrderBy(number => number).ToArray() })
            .ToList();
        var duplicateSessions = _slotVideoPairs
            .Where(pair => !string.IsNullOrWhiteSpace(pair.Value))
            .GroupBy(pair => pair.Value, StringComparer.OrdinalIgnoreCase)
            .Where(group => group.Count() > 1)
            .Select(group => new { PairKey = group.Key, Slots = group.Select(pair => pair.Key).OrderBy(number => number).ToArray() })
            .ToList();
        var duplicateStableKeys = _slotStableVideoPairs
            .Where(pair => !string.IsNullOrWhiteSpace(pair.Value))
            .GroupBy(pair => pair.Value, StringComparer.OrdinalIgnoreCase)
            .Where(group => group.Count() > 1)
            .Select(group => new { StableKey = group.Key, Slots = group.Select(pair => pair.Key).OrderBy(number => number).ToArray() })
            .ToList();
        var staleSlots = Slots
            .Where(slot => SlotHasPairRecoverySignal(slot.Number) && IsSlotPairSuspicious(slot.Number))
            .Select(slot => slot.Number)
            .OrderBy(number => number)
            .ToArray();

        sb.AppendLine("Resumo forte:");
        sb.AppendLine($"- Slots configurados: {Slots.Count}");
        sb.AppendLine($"- Slots com janela: {occupiedSlots.Count}");
        sb.AppendLine($"- Slots usáveis: {usableSlots.Count}");
        sb.AppendLine($"- Abas/vídeos no cache visual: {VideoTabs.Count}");
        sb.AppendLine($"- Extensão conectada: {_extensionBridge.IsConnected}");
        sb.AppendLine($"- Motor nativo de layout: mode={_nativeLayoutEngineMode}; available={PipWindowService.NativeLayoutEngineAvailable}; abi={PipWindowService.NativeLayoutEngineVersion}; failure={PipWindowService.NativeLayoutEngineFailure}");
        sb.AppendLine($"- Vídeo/aba preparado: {(_armedPipPairTab is null ? "nenhum" : _armedPipPairTab.ShortDescription)}");
        sb.AppendLine($"- Auto-recuperação em andamento: {_autoRecoverPairInProgress}");
        sb.AppendLine($"- Slots com vínculo suspeito: {(staleSlots.Length == 0 ? "nenhum" : string.Join(", ", staleSlots))}");
        sb.AppendLine($"- HWND duplicado em slots: {(duplicateHandles.Count == 0 ? "nenhum" : string.Join(" | ", duplicateHandles.Select(item => $"0x{item.Handle.ToInt64():X} -> PiP {string.Join(",", item.Slots)}")))}");
        sb.AppendLine($"- Sessão duplicada em slots: {(duplicateSessions.Count == 0 ? "nenhuma" : string.Join(" | ", duplicateSessions.Select(item => $"PiP {string.Join(",", item.Slots)}")))}");
        sb.AppendLine($"- StableKey duplicada em slots: {(duplicateStableKeys.Count == 0 ? "nenhuma" : string.Join(" | ", duplicateStableKeys.Select(item => $"PiP {string.Join(",", item.Slots)}")))}");
        sb.AppendLine();

        sb.AppendLine("Estado do aplicativo:");
        sb.AppendLine($"- Layout atual: {CurrentLayout} / {CurrentLayout.ToLabel()}");
        sb.AppendLine($"- Layout manual ativo: {_customLayoutActive}");
        sb.AppendLine($"- Grupo travado: {_groupLocked}");
        sb.AppendLine($"- PiPs ocultos: {_allHidden}");
        sb.AppendLine($"- Captura ao vivo local: {_liveCaptureActive}");
        sb.AppendLine($"- Janela principal: Left={Left:0}, Top={Top:0}, Width={ActualWidth:0}, Height={ActualHeight:0}, State={WindowState}");
        sb.AppendLine($"- Último slot redimensionado manualmente: {(_lastManuallyResizedSlotNumber?.ToString() ?? "nenhum")}");
        sb.AppendLine($"- Última alteração automática de tamanho: {(_lastResizedSlotNumber?.ToString() ?? "nenhuma")}");
        sb.AppendLine($"- Modelo travado válido: {_lockedGroupModelRects.Count > 0}");
        sb.AppendLine($"- Bounds do modelo travado: {FormatRect(_lockedGroupModelBounds)}");
        sb.AppendLine($"- Bounds do grupo conhecido: {FormatRect(_lastKnownGroupBounds)}");
        sb.AppendLine();

        sb.AppendLine("Tela virtual:");
        sb.AppendLine($"- {FormatRect(PipWindowService.GetVirtualScreenBounds())}");
        sb.AppendLine();

        sb.AppendLine("Mapa forte Slot → Janela → Aba/Vídeo:");
        foreach (var slot in Slots.OrderBy(slot => slot.Number))
        {
            _slotVideoPairs.TryGetValue(slot.Number, out var pairKey);
            _slotStableVideoPairs.TryGetValue(slot.Number, out var stableKey);
            _slotPairedTabIds.TryGetValue(slot.Number, out var tabId);
            _slotPairDomains.TryGetValue(slot.Number, out var savedDomain);

            var pairStatus = DescribePairStatus(slot.Number, pairKey, stableKey, tabId, savedDomain);
            var currentRect = slot.Window is null ? default : PipWindowService.GetVisualRect(slot.Window.Handle);
            var usable = slot.Window is not null && PipWindowService.IsUsable(slot.Window.Handle);
            var duplicateHandleText = slot.Window is not null && duplicateHandles.Any(item => item.Handle == slot.Window.Handle)
                ? "SIM"
                : "não";

            sb.AppendLine($"PiP {slot.Number}");
            sb.AppendLine($"  Estado visual: {slot.State}; ocupado={slot.IsOccupied}; oculto={slot.IsHidden}; usável={usable}");
            sb.AppendLine($"  Janela: {(slot.Window is null ? "vazia" : $"HWND=0x{slot.Window.Handle.ToInt64():X}; PID={slot.Window.ProcessId}; proc={slot.Window.ProcessName}; classe={slot.Window.ClassName}")}");
            if (slot.Window is not null)
            {
                sb.AppendLine($"  Título janela: {slot.Window.Title}");
                sb.AppendLine($"  Score captura: {slot.Window.Score}");
                sb.AppendLine($"  Rect salvo: {FormatRect(slot.Window.VisualRect)}");
                sb.AppendLine($"  Rect atual: {FormatRect(currentRect)}");
                sb.AppendLine($"  HWND duplicado: {duplicateHandleText}");
            }
            sb.AppendLine($"  Vínculo salvo: pairKey={SafeShort(pairKey, 90)}");
            sb.AppendLine($"  StableKey: {SafeShort(stableKey, 90)}");
            sb.AppendLine($"  TabId salvo: {(tabId > 0 ? tabId.ToString() : "nenhum")}; domínio salvo: {(string.IsNullOrWhiteSpace(savedDomain) ? "nenhum" : savedDomain)}");
            sb.AppendLine($"  Status vínculo: {pairStatus}");
            sb.AppendLine($"  Visual slot: {slot.PairStateText}; domínio={slot.PairDomain}; nome={slot.DisplayTitle}");
        }
        sb.AppendLine();

        sb.AppendLine("Abas de vídeo detectadas pela extensão:");
        foreach (var tab in VideoTabs.OrderBy(tab => tab.TabId).ThenBy(tab => tab.VideoIndex))
        {
            var existingSlot = FindExistingSlotForVideoTab(tab);
            sb.AppendLine($"- Aba {tab.TabId} / vídeo {tab.VideoIndex}: {(existingSlot is null ? "sem PiP vinculado" : $"PiP {existingSlot.Number}")} | {tab.ShortDescription}");
            sb.AppendLine($"  PairKey: {SafeShort(tab.PairKey, 110)}");
            sb.AppendLine($"  Session: {SafeShort(tab.VideoSessionId, 110)}");
            sb.AppendLine($"  Stable: {SafeShort(tab.StableVideoKey, 110)}");
            sb.AppendLine($"  Playing={tab.IsPlaying}; activeTab={tab.IsActiveTab}; current={tab.CurrentTime:0}; duration={tab.Duration:0}; videosNaAba={tab.VideoCount}");
            sb.AppendLine($"  Título: {tab.Title}");
            sb.AppendLine($"  URL: {tab.Url}");
        }
        if (VideoTabs.Count == 0) sb.AppendLine("- nenhuma");
        sb.AppendLine();

        sb.AppendLine("Vínculos salvos por dicionário:");
        foreach (var slot in Slots.OrderBy(slot => slot.Number))
        {
            var hasAny = _slotVideoPairs.ContainsKey(slot.Number) || _slotStableVideoPairs.ContainsKey(slot.Number) || _slotPairedTabIds.ContainsKey(slot.Number) || _slotPairDomains.ContainsKey(slot.Number);
            if (!hasAny) continue;
            _slotVideoPairs.TryGetValue(slot.Number, out var pairKey);
            _slotStableVideoPairs.TryGetValue(slot.Number, out var stableKey);
            _slotPairedTabIds.TryGetValue(slot.Number, out var tabId);
            _slotPairDomains.TryGetValue(slot.Number, out var domain);
            sb.AppendLine($"- PiP {slot.Number}: pair={SafeShort(pairKey, 100)} | stable={SafeShort(stableKey, 100)} | tabId={(tabId > 0 ? tabId.ToString() : "-")} | domain={(string.IsNullOrWhiteSpace(domain) ? "-" : domain)}");
        }
        if (!_slotVideoPairs.Any() && !_slotStableVideoPairs.Any() && !_slotPairedTabIds.Any() && !_slotPairDomains.Any()) sb.AppendLine("- nenhum");
        sb.AppendLine();

        sb.AppendLine("Eventos PiP recentes:");
        foreach (var item in _recentPipEvents.OrderByDescending(item => item.EventUnixMs).Take(12))
        {
            sb.AppendLine($"- {item.EventName}; tab={item.TabId}; session={SafeShort(item.VideoSessionId, 80)}; stable={SafeShort(item.StableVideoKey, 80)}; {item.ShortDescription}; url={item.Url}");
        }
        if (_recentPipEvents.Count == 0) sb.AppendLine("- nenhum");
        sb.AppendLine();

        sb.AppendLine("Layout salvo:");
        for (var i = 0; i < _slotLayoutRects.Count; i++)
            sb.AppendLine($"- SlotLayout[{i + 1}]: {FormatRect(_slotLayoutRects[i])}");
        if (_slotLayoutRects.Count == 0) sb.AppendLine("- vazio");
        sb.AppendLine();

        sb.AppendLine("Slots manuais/editáveis:");
        foreach (var slot in EditableSlots.OrderBy(slot => slot.Number))
            sb.AppendLine($"- {slot.Number}: Left={slot.Left:0}, Top={slot.Top:0}, Width={slot.Width:0}, Height={slot.Height:0}");
        if (EditableSlots.Count == 0) sb.AppendLine("- vazio");
        sb.AppendLine();

        sb.AppendLine("Arquivos:");
        sb.AppendLine($"- Log: {AppLogger.LogFile}");
        sb.AppendLine($"- Log existe: {File.Exists(AppLogger.LogFile)}");
        sb.AppendLine($"- Log tamanho: {GetFileSizeText(AppLogger.LogFile)}");
        sb.AppendLine($"- Config: {AppLogger.SettingsFile}");
        sb.AppendLine($"- Config existe: {File.Exists(AppLogger.SettingsFile)}");
        sb.AppendLine($"- Config tamanho: {GetFileSizeText(AppLogger.SettingsFile)}");

        return sb.ToString();
    }

    private string DescribePairStatus(int slotNumber, string? pairKey, string? stableKey, int tabId, string? savedDomain)
    {
        if (string.IsNullOrWhiteSpace(pairKey) && string.IsNullOrWhiteSpace(stableKey) && tabId <= 0 && string.IsNullOrWhiteSpace(savedDomain))
            return "SEM VÍNCULO";

        if (!string.IsNullOrWhiteSpace(pairKey))
        {
            var exact = VideoTabs.Where(tab => string.Equals(tab.PairKey, pairKey, StringComparison.OrdinalIgnoreCase)
                || string.Equals(tab.VideoSessionId, pairKey, StringComparison.OrdinalIgnoreCase)).ToList();
            if (exact.Count == 1)
                return $"OK por videoSessionId → {exact[0].ShortDescription}";
            if (exact.Count > 1)
                return $"AMBÍGUO por videoSessionId: {exact.Count} candidatos";
        }

        if (!string.IsNullOrWhiteSpace(stableKey))
        {
            var stableMatches = VideoTabs.Where(tab => string.Equals(tab.StableVideoKey, stableKey, StringComparison.OrdinalIgnoreCase)).ToList();
            if (stableMatches.Count == 1)
                return $"RECUPERÁVEL por stableVideoKey → {stableMatches[0].ShortDescription}";
            if (stableMatches.Count > 1 && tabId > 0)
            {
                var sameTab = stableMatches.Where(tab => tab.TabId == tabId).ToList();
                if (sameTab.Count == 1)
                    return $"RECUPERÁVEL por stableVideoKey+tabId → {sameTab[0].ShortDescription}";
                return $"AMBÍGUO por stableVideoKey: {stableMatches.Count} candidatos; mesma aba={sameTab.Count}";
            }
            if (stableMatches.Count > 1)
                return $"AMBÍGUO por stableVideoKey: {stableMatches.Count} candidatos";
        }

        if (tabId > 0)
        {
            var tabMatches = VideoTabs.Where(tab => tab.TabId == tabId).ToList();
            if (tabMatches.Count == 1)
                return $"RECUPERÁVEL por tabId único → {tabMatches[0].ShortDescription}";
            if (tabMatches.Count > 1)
                return $"AMBÍGUO por tabId: {tabMatches.Count} vídeos na mesma aba";
        }

        if (!string.IsNullOrWhiteSpace(savedDomain))
        {
            var domainMatches = VideoTabs.Where(tab => string.Equals(GetDomainForTab(tab), savedDomain, StringComparison.OrdinalIgnoreCase)).ToList();
            if (domainMatches.Count == 1)
                return $"RECUPERÁVEL por domínio único → {domainMatches[0].ShortDescription}";
            if (domainMatches.Count > 1)
                return $"AMBÍGUO por domínio: {domainMatches.Count} candidatos em {savedDomain}";
        }

        return "SUSPEITO: alvo não encontrado no cache atual; pode precisar de Rec. vínculo";
    }

    private static string SafeShort(string? value, int maxLength)
    {
        if (string.IsNullOrWhiteSpace(value)) return "-";
        return value.Length <= maxLength ? value : value[..maxLength] + "...";
    }

    private static string FormatRect(NativeRect rect) => rect.IsValid
        ? $"L={rect.Left}, T={rect.Top}, R={rect.Right}, B={rect.Bottom}, W={rect.Width}, H={rect.Height}"
        : "inválido";

    private static string GetFileSizeText(string path)
    {
        try
        {
            return File.Exists(path) ? $"{new FileInfo(path).Length} bytes" : "não existe";
        }
        catch
        {
            return "erro ao ler";
        }
    }

    private void RejoinButton_Click(object sender, RoutedEventArgs e)
    {
        EqualizeCaptured();
    }

    private void RecoverControlButton_Click(object sender, RoutedEventArgs e) => RecoverControl();

    private async void VideoNextMenuItem_Click(object sender, RoutedEventArgs e) =>
        await SendVideoCommandToCapturedAsync(VideoCommandKind.Next);

    private async void VideoPreviousMenuItem_Click(object sender, RoutedEventArgs e) =>
        await SendVideoCommandToCapturedAsync(VideoCommandKind.Previous);

    
    
    private bool IsVideoSwitchPreservationStateAlive(VideoSwitchPreservationState state)
    {
        return state.ExpiresUtc >= DateTime.UtcNow;
    }

    private bool TryMarkNewVideoDetectedFromSnapshot(VideoSwitchPreservationState state, string source = "observer")
    {
        var candidates = VideoTabs
            .Where(tab => state.TabId is null || tab.TabId == state.TabId)
            .Where(tab =>
                (!string.IsNullOrWhiteSpace(state.OldStable) && !string.IsNullOrWhiteSpace(tab.StableVideoKey) && !string.Equals(tab.StableVideoKey, state.OldStable, StringComparison.OrdinalIgnoreCase))
                || (!string.IsNullOrWhiteSpace(state.OldSession) && !string.IsNullOrWhiteSpace(tab.VideoSessionId) && !string.Equals(tab.VideoSessionId, state.OldSession, StringComparison.OrdinalIgnoreCase))
                || (!string.IsNullOrWhiteSpace(state.OldUrl) && !string.IsNullOrWhiteSpace(tab.Url) && !string.Equals(tab.Url, state.OldUrl, StringComparison.OrdinalIgnoreCase)))
            .OrderByDescending(tab => tab.IsPlaying)
            .ThenByDescending(tab => tab.CurrentTime)
            .ToList();

        if (candidates.Count == 0)
            return false;

        var candidate = candidates[0];
        var wasAlreadyDetected = state.NewVideoDetected;
        state.NewVideoDetected = true;
        if (state.NewVideoDetectedUtc == DateTime.MinValue)
            state.NewVideoDetectedUtc = DateTime.UtcNow;

        if (!wasAlreadyDetected)
        {
            AppLogger.Info($"pip-preserve-video-change-detected: slot={state.SlotNumber}; source={source}; tabId={candidate.TabId}; command={state.CommandType}; oldSession={state.OldSession}; newSession={candidate.VideoSessionId}; oldStable={state.OldStable}; newStable={candidate.StableVideoKey}; oldUrl={state.OldUrl}; newUrl={candidate.Url}; title={candidate.Title}; playing={candidate.IsPlaying}; currentTime={candidate.CurrentTime:0.###}; duration={candidate.Duration:0.###}");

            var slot = Slots.FirstOrDefault(item => item.Number == state.SlotNumber);
            if (slot is not null)
            {
                var newSessionForShadow = !string.IsNullOrWhiteSpace(candidate.VideoSessionId)
                    ? candidate.VideoSessionId
                    : candidate.PairKey;
                ShadowMirrorVideoChanged(slot, newSessionForShadow, candidate.StableVideoKey, source + "/TryMarkNewVideoDetectedFromSnapshot");
                ShadowLogLegacyComparison(slot, source + "/VideoChanged", "legacy-video-change-detected");
            }
        }

        AppLogger.InfoAggregated(
            $"pip-preserve-new-video-detected:{state.SlotNumber}:{state.CommandType}",
            TimeSpan.FromMilliseconds(1200),
            $"pip-preserve-new-video-detected: slot={state.SlotNumber}; source={source}; tabId={candidate.TabId}; command={state.CommandType}; oldSession={state.OldSession}; newSession={candidate.VideoSessionId}; oldStable={state.OldStable}; newStable={candidate.StableVideoKey}; oldUrl={state.OldUrl}; newUrl={candidate.Url}; title={candidate.Title}; playing={candidate.IsPlaying}; currentTime={candidate.CurrentTime:0.###}; duration={candidate.Duration:0.###}");
        return true;
    }

    private bool TryClassifyPreservedSameHwnd(PipSlot slot, string source)
    {
        if (!_videoSwitchPreservationBySlot.TryGetValue(slot.Number, out var state))
            return false;

        if (!IsVideoSwitchPreservationStateAlive(state))
            return false;

        if (slot.Window is null)
            return false;

        var currentHandle = slot.Window.Handle;
        if (state.OldHandle == IntPtr.Zero || currentHandle != state.OldHandle)
            return false;

        if (!PipWindowService.IsUsable(currentHandle))
            return false;

        TryMarkNewVideoDetectedFromSnapshot(state, source);

        state.SameHwndStillAliveSeen = true;
        if (state.SameHwndStableSinceUtc == DateTime.MinValue)
            state.SameHwndStableSinceUtc = DateTime.UtcNow;

        var elapsedMs = (DateTime.UtcNow - state.StartedUtc).TotalMilliseconds;
        var stableMs = (DateTime.UtcNow - state.SameHwndStableSinceUtc).TotalMilliseconds;

        if (!state.NewVideoDetected || elapsedMs < VideoSwitchPreservedSameHwndConfirmMs)
        {
            AppLogger.Info($"pip-preserve-same-hwnd-waiting: slot={slot.Number}; source={source}; command={state.CommandType}; elapsedMs={elapsedMs:0}; stableMs={stableMs:0}; requiredMs={VideoSwitchPreservedSameHwndConfirmMs}; newVideoDetected={state.NewVideoDetected}; oldHandle=0x{state.OldHandle.ToInt64():X}; currentHandle=0x{currentHandle.ToInt64():X}; slotState={slot.State}");
            return false;
        }

        if (!state.PreservedSameHwndConfirmed)
        {
            state.PreservedSameHwndConfirmed = true;
            state.PreservedConfirmedUtc = DateTime.UtcNow;
            AppLogger.Info($"pip-preserve-result: result=preserved-same-hwnd-confirmed; slot={slot.Number}; source={source}; command={state.CommandType}; elapsedMs={elapsedMs:0}; stableMs={stableMs:0}; requiredMs={VideoSwitchPreservedSameHwndConfirmMs}; oldHandle=0x{state.OldHandle.ToInt64():X}; currentHandle=0x{currentHandle.ToInt64():X}; tabId={state.TabId}; oldSession={state.OldSession}; oldStable={state.OldStable}; oldUrl={state.OldUrl}; newVideoDetected={state.NewVideoDetected}; fallbackAllowed={state.FallbackAllowed}; provisional=True");
            if (slot.Window is not null)
                ShadowMirrorPreservedSameHwndConfirmed(slot, slot.Window.Handle, "preserved-same-hwnd-confirmed");
            AppLogger.Info($"pip-preserve-result: result=preserved-same-hwnd; slot={slot.Number}; source={source}; command={state.CommandType}; elapsedMs={elapsedMs:0}; stableMs={stableMs:0}; oldHandle=0x{state.OldHandle.ToInt64():X}; currentHandle=0x{currentHandle.ToInt64():X}; tabId={state.TabId}; oldSession={state.OldSession}; oldStable={state.OldStable}; oldUrl={state.OldUrl}; newVideoDetected={state.NewVideoDetected}; fallbackAllowed={state.FallbackAllowed}; provisional=True");
            SetStatus($"PiP {slot.Number}: preservação provisória confirmada; observando estabilidade final");
        }
        else
        {
            AppLogger.Info($"pip-preserve-same-hwnd-confirmed-still-watching: slot={slot.Number}; source={source}; command={state.CommandType}; elapsedMs={elapsedMs:0}; stableMs={stableMs:0}; oldHandle=0x{state.OldHandle.ToInt64():X}; currentHandle=0x{currentHandle.ToInt64():X}; newVideoDetected={state.NewVideoDetected}; ttlRemainingMs={(state.ExpiresUtc - DateTime.UtcNow).TotalMilliseconds:0}");
        }

        return true;
    }

    private void ClassifyReconnectedNewHwnd(PipSlot slot, IntPtr oldHandle, IntPtr newHandle, string source, string reason)
    {
        if (!_videoSwitchPreservationBySlot.TryGetValue(slot.Number, out var state))
            return;

        if (!IsVideoSwitchPreservationStateAlive(state))
            return;

        if (state.OldHandle != IntPtr.Zero && oldHandle != state.OldHandle)
            return;

        TryMarkNewVideoDetectedFromSnapshot(state, source);

        state.NewHwndCandidateSeen = true;
        state.OldHwndLostSeen = true;

        _videoSwitchPreservationBySlot.Remove(slot.Number);
        var elapsedMs = (DateTime.UtcNow - state.StartedUtc).TotalMilliseconds;
        AppLogger.Info($"pip-preserve-result: result=reconnected-new-hwnd; slot={slot.Number}; source={source}; reason={reason}; command={state.CommandType}; elapsedMs={elapsedMs:0}; oldHandle=0x{oldHandle.ToInt64():X}; newHandle=0x{newHandle.ToInt64():X}; tabId={state.TabId}; oldSession={state.OldSession}; oldStable={state.OldStable}; oldUrl={state.OldUrl}; newVideoDetected={state.NewVideoDetected}; oldHwndLostSeen={state.OldHwndLostSeen}; newHwndCandidateSeen={state.NewHwndCandidateSeen}; preservedConfirmed={state.PreservedSameHwndConfirmed}; autoReturnOwned={state.AutoReturnTookOwnership}; autoReturnReason={state.AutoReturnOwnershipReason}; fallbackAllowed={state.FallbackAllowed}; hasPairSignal={SlotHasPairRecoverySignal(slot.Number)}; slotState={slot.State}");

        if (state.AutoReturnTookOwnership)
        {
            var ownershipElapsedMs = state.AutoReturnOwnershipUtc == DateTime.MinValue ? -1 : (DateTime.UtcNow - state.AutoReturnOwnershipUtc).TotalMilliseconds;
            AppLogger.Info($"pip-preserve-reconnected-after-auto-return: slot={slot.Number}; source={source}; reason={reason}; autoReturnReason={state.AutoReturnOwnershipReason}; command={state.CommandType}; elapsedMs={elapsedMs:0}; ownershipElapsedMs={ownershipElapsedMs:0}; oldHandle=0x{oldHandle.ToInt64():X}; newHandle=0x{newHandle.ToInt64():X}; tabId={state.TabId}; newVideoDetected={state.NewVideoDetected}; oldHwndLostSeen={state.OldHwndLostSeen}; newHwndCandidateSeen={state.NewHwndCandidateSeen}; slotState={slot.State}");
        }

        SetStatus($"PiP {slot.Number}: reconectado a novo HWND na troca");
    }

    private void CompleteVideoSwitchPreservationAfterAutoReturn(
        PipSlot slot,
        VideoTabInfo tab,
        IntPtr confirmedHandle,
        string attemptId,
        string source)
    {
        if (!_videoSwitchPreservationBySlot.TryGetValue(slot.Number, out var state))
            return;

        if (!state.AutoReturnTookOwnership)
        {
            AppLogger.Info($"pip-preserve-auto-return-completion-skipped: attemptId={attemptId}; slot={slot.Number}; tabId={tab.TabId}; source={source}; reason=auto-return-not-owner; command={state.CommandType}");
            return;
        }

        var slotHandle = slot.Window?.Handle ?? IntPtr.Zero;
        if (confirmedHandle == IntPtr.Zero
            || slotHandle != confirmedHandle
            || !PipWindowService.IsUsable(confirmedHandle))
        {
            AppLogger.Warn($"pip-preserve-auto-return-completion-skipped: attemptId={attemptId}; slot={slot.Number}; tabId={tab.TabId}; source={source}; reason=confirmed-hwnd-not-owned-by-slot; confirmedHandle=0x{confirmedHandle.ToInt64():X}; slotHandle=0x{slotHandle.ToInt64():X}; command={state.CommandType}");
            return;
        }

        if (state.TabId is > 0 && state.TabId.Value != tab.TabId)
        {
            AppLogger.Warn($"pip-preserve-auto-return-completion-skipped: attemptId={attemptId}; slot={slot.Number}; tabId={tab.TabId}; expectedTabId={state.TabId}; source={source}; reason=tab-mismatch; confirmedHandle=0x{confirmedHandle.ToInt64():X}; command={state.CommandType}");
            return;
        }

        TryMarkNewVideoDetectedFromSnapshot(state, source);
        state.NewHwndCandidateSeen = true;
        state.OldHwndLostSeen = state.OldHandle == IntPtr.Zero
            || state.OldHandle != confirmedHandle
            || !PipWindowService.IsUsable(state.OldHandle);

        _videoSwitchPreservationBySlot.Remove(slot.Number);

        var elapsedMs = (DateTime.UtcNow - state.StartedUtc).TotalMilliseconds;
        var ownershipElapsedMs = state.AutoReturnOwnershipUtc == DateTime.MinValue
            ? -1
            : (DateTime.UtcNow - state.AutoReturnOwnershipUtc).TotalMilliseconds;

        AppLogger.Info($"pip-preserve-result: result=auto-return-confirmed; attemptId={attemptId}; slot={slot.Number}; tabId={tab.TabId}; source={source}; command={state.CommandType}; elapsedMs={elapsedMs:0}; ownershipElapsedMs={ownershipElapsedMs:0}; oldHandle=0x{state.OldHandle.ToInt64():X}; newHandle=0x{confirmedHandle.ToInt64():X}; oldSession={state.OldSession}; oldStable={state.OldStable}; oldUrl={state.OldUrl}; newSession={tab.VideoSessionId}; newStable={tab.StableVideoKey}; newUrl={tab.Url}; newVideoDetected={state.NewVideoDetected}; oldHwndLostSeen={state.OldHwndLostSeen}; newHwndCandidateSeen={state.NewHwndCandidateSeen}; preservedConfirmed=True; completionReason=auto-return-confirmed; autoReturnOwned={state.AutoReturnTookOwnership}; autoReturnReason={state.AutoReturnOwnershipReason}");
        AppLogger.Info($"pip-preserve-state-completed: slot={slot.Number}; tabId={tab.TabId}; command={state.CommandType}; reason={state.Reason}; completionReason=auto-return-confirmed; expireReason=auto-return-confirmed; timerCancelled=True; attemptId={attemptId}; handle=0x{confirmedHandle.ToInt64():X}");
    }


    
    
    private void FinalizeVideoSwitchPreservedSameHwndIfStable(VideoSwitchPreservationState state, string source)
    {
        if (!state.PreservedSameHwndConfirmed || state.PreservedFinalLogged || state.OldHwndLostSeen || state.AutoReturnTookOwnership)
            return;

        if (DateTime.UtcNow < state.ExpiresUtc)
            return;

        state.PreservedFinalLogged = true;
        var elapsedMs = (DateTime.UtcNow - state.StartedUtc).TotalMilliseconds;
        var confirmedAgeMs = state.PreservedConfirmedUtc == DateTime.MinValue ? -1 : (DateTime.UtcNow - state.PreservedConfirmedUtc).TotalMilliseconds;
        AppLogger.Info($"pip-preserve-result: result=preserved-same-hwnd-final; slot={state.SlotNumber}; source={source}; command={state.CommandType}; elapsedMs={elapsedMs:0}; confirmedAgeMs={confirmedAgeMs:0}; oldHandle=0x{state.OldHandle.ToInt64():X}; tabId={state.TabId}; oldSession={state.OldSession}; oldStable={state.OldStable}; oldUrl={state.OldUrl}; newVideoDetected={state.NewVideoDetected}; sameHwndStillAliveSeen={state.SameHwndStillAliveSeen}; fallbackAllowed={state.FallbackAllowed}; blockSameVideoFallback={state.BlockSameVideoFallback}; commandTargetAssetId={state.CommandTargetAssetId}; commandTargetGeneration={state.CommandTargetGeneration}; commandTargetOperationId={state.CommandTargetOperationId}; silentAttempted={state.SilentReopenAttempted}; silentConfirmed={state.SilentReopenConfirmed}; silentReason={state.SilentReopenReasonCode}");
    }

    private void MarkVideoSwitchPreservationFailedAfterConfirmedIfNeeded(VideoSwitchPreservationState state, string source)
    {
        if (!state.PreservedSameHwndConfirmed || state.FailedAfterConfirmedLogged || !state.OldHwndLostSeen)
            return;

        state.FailedAfterConfirmedLogged = true;
        var elapsedMs = (DateTime.UtcNow - state.StartedUtc).TotalMilliseconds;
        var confirmedAgeMs = state.PreservedConfirmedUtc == DateTime.MinValue ? -1 : (DateTime.UtcNow - state.PreservedConfirmedUtc).TotalMilliseconds;
        AppLogger.Info($"pip-preserve-failed-after-confirmed: slot={state.SlotNumber}; source={source}; command={state.CommandType}; elapsedMs={elapsedMs:0}; confirmedAgeMs={confirmedAgeMs:0}; oldHandle=0x{state.OldHandle.ToInt64():X}; tabId={state.TabId}; oldSession={state.OldSession}; oldStable={state.OldStable}; oldUrl={state.OldUrl}; newVideoDetected={state.NewVideoDetected}; autoReturnOwned={state.AutoReturnTookOwnership}; autoReturnReason={state.AutoReturnOwnershipReason}; newHwndCandidateSeen={state.NewHwndCandidateSeen}");
    }

private void MarkVideoSwitchPreservationHwndLostIfNeeded(VideoSwitchPreservationState state, string source)
    {
        if (state.PreserveFailedHwndLostLogged || !state.NewVideoDetected || !state.OldHwndLostSeen)
            return;

        state.PreserveFailedHwndLostLogged = true;
        var elapsedMs = (DateTime.UtcNow - state.StartedUtc).TotalMilliseconds;
        AppLogger.Info($"pip-preserve-failed-hwnd-lost: slot={state.SlotNumber}; source={source}; command={state.CommandType}; elapsedMs={elapsedMs:0}; oldHandle=0x{state.OldHandle.ToInt64():X}; tabId={state.TabId}; oldSession={state.OldSession}; oldStable={state.OldStable}; oldUrl={state.OldUrl}; newVideoDetected={state.NewVideoDetected}; sameHwndStillAliveSeen={state.SameHwndStillAliveSeen}; preservedConfirmed={state.PreservedSameHwndConfirmed}; newHwndCandidateSeen={state.NewHwndCandidateSeen}");
        MarkVideoSwitchPreservationFailedAfterConfirmedIfNeeded(state, source);
    }

    private void MarkVideoSwitchPreservationAutoReturnOwned(PipSlot slot, string reason, string source)
    {
        if (!_videoSwitchPreservationBySlot.TryGetValue(slot.Number, out var state))
            return;

        if (!IsVideoSwitchPreservationStateAlive(state))
            return;

        state.AutoReturnTookOwnership = true;
        state.AutoReturnOwnershipReason = reason;
        if (state.AutoReturnOwnershipUtc == DateTime.MinValue)
            state.AutoReturnOwnershipUtc = DateTime.UtcNow;

        MarkVideoSwitchPreservationHwndLostIfNeeded(state, source);

        if (!state.FallbackOwnedByAutoReturnLogged)
        {
            state.FallbackOwnedByAutoReturnLogged = true;
            var elapsedMs = (DateTime.UtcNow - state.StartedUtc).TotalMilliseconds;
            AppLogger.Info($"pip-preserve-fallback-owned-by-auto-return: slot={slot.Number}; source={source}; reason={reason}; command={state.CommandType}; elapsedMs={elapsedMs:0}; oldHandle=0x{state.OldHandle.ToInt64():X}; tabId={state.TabId}; oldSession={state.OldSession}; oldStable={state.OldStable}; oldUrl={state.OldUrl}; newVideoDetected={state.NewVideoDetected}; oldHwndLostSeen={state.OldHwndLostSeen}; newHwndCandidateSeen={state.NewHwndCandidateSeen}; autoReturnPolicy={_autoReturnPolicy}; slotEnabled={IsAutoReturnEnabledForSlot(slot.Number)}; slotState={slot.State}; hasPairSignal={SlotHasPairRecoverySignal(slot.Number)}");
        }
    }

private void ObserveVideoSwitchPreservationStates(string source)
    {
        if (_videoSwitchPreservationBySlot.Count == 0)
            return;

        var now = DateTime.UtcNow;

        foreach (var item in _videoSwitchPreservationBySlot.ToArray())
        {
            var state = item.Value;
            if (state.ExpiresUtc <= now)
                continue;

            var slot = Slots.FirstOrDefault(candidate => candidate.Number == state.SlotNumber);
            if (slot is null)
            {
                state.LastObserverReason = "slot-not-found";
                state.LastObservedUtc = now;
                AppLogger.Info($"pip-preserve-observer-tick: slot={state.SlotNumber}; source={source}; reason=slot-not-found; command={state.CommandType}; ageMs={(now - state.StartedUtc).TotalMilliseconds:0}; ttlRemainingMs={(state.ExpiresUtc - now).TotalMilliseconds:0}; newVideoDetected={state.NewVideoDetected}");
                continue;
            }

            TryMarkNewVideoDetectedFromSnapshot(state, source);

            var sameHwndAlive = slot.Window is not null
                && state.OldHandle != IntPtr.Zero
                && slot.Window.Handle == state.OldHandle
                && PipWindowService.IsUsable(state.OldHandle);

            var oldHwndLost = state.OldHandle != IntPtr.Zero && !PipWindowService.IsUsable(state.OldHandle);
            var hasNewWindowForSlot = slot.Window is not null
                && state.OldHandle != IntPtr.Zero
                && slot.Window.Handle != state.OldHandle
                && PipWindowService.IsUsable(slot.Window.Handle);

            if (sameHwndAlive)
            {
                if (!state.SameHwndStillAliveSeen)
                    AppLogger.Info($"pip-preserve-hwnd-still-alive: slot={state.SlotNumber}; source={source}; oldHandle=0x{state.OldHandle.ToInt64():X}; command={state.CommandType}; ageMs={(now - state.StartedUtc).TotalMilliseconds:0}");

                state.SameHwndStillAliveSeen = true;
                if (state.SameHwndStableSinceUtc == DateTime.MinValue)
                    state.SameHwndStableSinceUtc = now;
            }

            if (oldHwndLost)
            {
                if (!state.OldHwndLostSeen)
                    AppLogger.Info($"pip-preserve-hwnd-lost: slot={state.SlotNumber}; source={source}; oldHandle=0x{state.OldHandle.ToInt64():X}; command={state.CommandType}; ageMs={(now - state.StartedUtc).TotalMilliseconds:0}");

                state.OldHwndLostSeen = true;
                MarkVideoSwitchPreservationHwndLostIfNeeded(state, source);
                MarkVideoSwitchPreservationFailedAfterConfirmedIfNeeded(state, source);
            }

            if (hasNewWindowForSlot && slot.Window is not null)
            {
                if (!state.NewHwndCandidateSeen)
                    AppLogger.Info($"pip-preserve-new-hwnd-candidate: slot={state.SlotNumber}; source={source}; oldHandle=0x{state.OldHandle.ToInt64():X}; newHandle=0x{slot.Window.Handle.ToInt64():X}; command={state.CommandType}; ageMs={(now - state.StartedUtc).TotalMilliseconds:0}");

                state.NewHwndCandidateSeen = true;
            }

            state.LastObserverReason = sameHwndAlive
                ? "same-hwnd-alive"
                : hasNewWindowForSlot
                    ? "new-hwnd-for-slot"
                    : oldHwndLost
                        ? "old-hwnd-lost"
                        : "waiting";
            state.LastObservedUtc = now;

            AppLogger.Info($"pip-preserve-observer-tick: slot={state.SlotNumber}; source={source}; reason={state.LastObserverReason}; command={state.CommandType}; ageMs={(now - state.StartedUtc).TotalMilliseconds:0}; ttlRemainingMs={(state.ExpiresUtc - now).TotalMilliseconds:0}; newVideoDetected={state.NewVideoDetected}; sameHwndAlive={sameHwndAlive}; oldHwndLost={oldHwndLost}; newHwndCandidate={hasNewWindowForSlot}; slotState={slot.State}; hasWindow={slot.Window is not null}; hasPairSignal={SlotHasPairRecoverySignal(slot.Number)}");
        }
    }

    private string GetVideoSwitchPreservationExpireReason(VideoSwitchPreservationState state)
    {
        if (state.PreservedSameHwndConfirmed && state.OldHwndLostSeen && state.AutoReturnTookOwnership)
            return "preserve-expired-confirmed-then-lost-auto-return-owned";
        if (state.PreservedSameHwndConfirmed && state.OldHwndLostSeen)
            return "preserve-expired-confirmed-then-lost";
        if (state.PreservedSameHwndConfirmed && !state.OldHwndLostSeen)
            return "preserve-expired-confirmed-final";
        if (state.AutoReturnTookOwnership && state.NewHwndCandidateSeen)
            return "preserve-expired-fallback-owned-by-auto-return-new-hwnd-unclassified";
        if (state.AutoReturnTookOwnership)
            return "preserve-expired-fallback-owned-by-auto-return";
        if (!state.NewVideoDetected)
            return "preserve-expired-no-video-change";
        if (state.OldHwndLostSeen && !state.NewHwndCandidateSeen)
            return "preserve-expired-video-detected-hwnd-lost";
        if (state.NewHwndCandidateSeen)
            return "preserve-expired-video-detected-new-hwnd-unclassified";
        if (state.SameHwndStillAliveSeen)
            return "preserve-expired-video-detected-same-hwnd-not-stable";
        return "preserve-expired-video-detected-no-result";
    }

private void ExpireVideoSwitchPreservationStates()
    {
        if (_videoSwitchPreservationBySlot.Count == 0)
            return;

        var now = DateTime.UtcNow;
        foreach (var item in _videoSwitchPreservationBySlot.ToArray())
        {
            var state = item.Value;
            if (state.ExpiresUtc > now)
                continue;

            TryMarkNewVideoDetectedFromSnapshot(state, "expire");
            if (state.OldHwndLostSeen)
                MarkVideoSwitchPreservationFailedAfterConfirmedIfNeeded(state, "expire");
            FinalizeVideoSwitchPreservedSameHwndIfStable(state, "expire");

            _videoSwitchPreservationBySlot.Remove(item.Key);
            var elapsedMs = (now - state.StartedUtc).TotalMilliseconds;
            var expireReason = GetVideoSwitchPreservationExpireReason(state);
            AppLogger.Info($"pip-preserve-expired-with-reason: slot={state.SlotNumber}; expireReason={expireReason}; tabId={state.TabId}; command={state.CommandType}; ttlMs={(state.ExpiresUtc - state.StartedUtc).TotalMilliseconds:0}; elapsedMs={elapsedMs:0}; oldHandle=0x{state.OldHandle.ToInt64():X}; oldSession={state.OldSession}; oldStable={state.OldStable}; oldUrl={state.OldUrl}; newVideoDetected={state.NewVideoDetected}; sameHwndStillAliveSeen={state.SameHwndStillAliveSeen}; oldHwndLostSeen={state.OldHwndLostSeen}; newHwndCandidateSeen={state.NewHwndCandidateSeen}; preservedConfirmed={state.PreservedSameHwndConfirmed}; preservedFinalLogged={state.PreservedFinalLogged}; failedAfterConfirmed={state.FailedAfterConfirmedLogged}; autoReturnOwned={state.AutoReturnTookOwnership}; autoReturnReason={state.AutoReturnOwnershipReason}; lastObserverReason={state.LastObserverReason}; fallbackAllowed={state.FallbackAllowed}; silentAttempted={state.SilentReopenAttempted}; silentConfirmed={state.SilentReopenConfirmed}; silentReason={state.SilentReopenReasonCode}");
            AppLogger.Info($"pip-preserve-state-expired: slot={state.SlotNumber}; tabId={state.TabId}; command={state.CommandType}; reason={state.Reason}; expireReason={expireReason}; ttlMs={(state.ExpiresUtc - state.StartedUtc).TotalMilliseconds:0}; elapsedMs={elapsedMs:0}; oldHandle=0x{state.OldHandle.ToInt64():X}; oldSession={state.OldSession}; oldStable={state.OldStable}; oldUrl={state.OldUrl}; newVideoDetected={state.NewVideoDetected}; preservedConfirmed={state.PreservedSameHwndConfirmed}; autoReturnOwned={state.AutoReturnTookOwnership}; fallbackAllowed={state.FallbackAllowed}; silentAttempted={state.SilentReopenAttempted}; silentConfirmed={state.SilentReopenConfirmed}; silentReason={state.SilentReopenReasonCode}");
        }
    }

    private void ArmVideoSwitchPreservationIfPossible(PipSlot? slot, string? pairKey, string? videoSessionId, string? stableVideoKey, int? tabId, VideoCommandKind command, string selectedLabel, VideoTabInfo? commandTarget = null)
    {
        ExpireVideoSwitchPreservationStates();

        var commandText = command == VideoCommandKind.Next ? "next" : "previous";

        if (slot is null)
        {
            AppLogger.Info($"pip-preserve-no-slot: command={commandText}; selected={selectedLabel}");
            return;
        }

        CancelAutoAdvanceLostPipWatch(slot.Number, $"video-command-{commandText}");

        AppLogger.Info($"pip-preserve-switch-start: slot={slot.Number}; command={commandText}; selected={selectedLabel}; state={slot.State}; autoReturnSlotEnabled={slot.IsAutoReturnEnabled}; hasWindow={slot.Window is not null}; hasPairSignal={SlotHasPairRecoverySignal(slot.Number)}");

        if (!slot.IsAutoReturnEnabled)
        {
            AppLogger.Info($"pip-preserve-slot-disabled: slot={slot.Number}; command={commandText}; shouldPreserve=False; disabledReason=slot-auto-return-off; state={slot.State}; hasWindow={slot.Window is not null}; hasPairSignal={SlotHasPairRecoverySignal(slot.Number)}");
            return;
        }

        if (!SlotHasPairRecoverySignal(slot.Number)
            && string.IsNullOrWhiteSpace(pairKey)
            && string.IsNullOrWhiteSpace(videoSessionId)
            && string.IsNullOrWhiteSpace(stableVideoKey))
        {
            AppLogger.Info($"pip-preserve-no-pair-signal: slot={slot.Number}; command={commandText}; shouldPreserve=False; state={slot.State}; hasWindow={slot.Window is not null}");
            return;
        }

        var now = DateTime.UtcNow;
        var oldHandle = slot.Window?.Handle ?? IntPtr.Zero;
        var oldSession = !string.IsNullOrWhiteSpace(videoSessionId)
            ? videoSessionId!
            : (!string.IsNullOrWhiteSpace(pairKey) ? pairKey! : (_slotVideoPairs.TryGetValue(slot.Number, out var savedPair) ? savedPair : string.Empty));
        var oldStable = !string.IsNullOrWhiteSpace(stableVideoKey)
            ? stableVideoKey!
            : (_slotStableVideoPairs.TryGetValue(slot.Number, out var savedStable) ? savedStable : string.Empty);
        var oldUrl = _slotPairUrls.TryGetValue(slot.Number, out var savedUrl) ? savedUrl : string.Empty;
        var oldHandleUsable = oldHandle != IntPtr.Zero && PipWindowService.IsUsable(oldHandle);
        if (command == VideoCommandKind.Next)
            ArmSlotNavigationGeometryAuthority(slot, "video-command-next");

        var state = new VideoSwitchPreservationState
        {
            SlotNumber = slot.Number,
            TabId = tabId,
            OldSession = oldSession,
            OldStable = oldStable,
            OldUrl = oldUrl,
            OldHandle = oldHandle,
            CommandType = commandText,
            Reason = "video-command",
            StartedUtc = now,
            ExpiresUtc = now.AddSeconds(VideoSwitchPreservationTtlSeconds),
            FallbackAllowed = command != VideoCommandKind.Next,
            BlockSameVideoFallback = command == VideoCommandKind.Next,
            CommandTargetAssetId = commandTarget?.NextAssetId ?? string.Empty,
            CommandTargetOperationId = commandTarget?.NextTargetOperationId ?? string.Empty,
            CommandTargetGeneration = commandTarget?.NextTargetGeneration ?? 0,
            CommandTargetCurrentIndex = commandTarget?.PlaylistIndex ?? -1,
            CommandTargetNextIndex = commandTarget?.NextPreviewIndex ?? -1
        };

        _videoSwitchPreservationBySlot[slot.Number] = state;

        AppLogger.Info($"pip-preserve-state-created: slot={slot.Number}; tabId={tabId}; command={commandText}; ttlSeconds={VideoSwitchPreservationTtlSeconds}; expiresUtc={state.ExpiresUtc:O}; oldHandle=0x{oldHandle.ToInt64():X}; oldHandleUsable={oldHandleUsable}; oldSession={oldSession}; oldStable={oldStable}; oldUrl={oldUrl}; fallbackAllowed={state.FallbackAllowed}; silentAttempted={state.SilentReopenAttempted}; silentConfirmed={state.SilentReopenConfirmed}; silentReason={state.SilentReopenReasonCode}");
        AppLogger.Info($"pip-preserve-slot-armed: slot={slot.Number}; tabId={tabId}; command={commandText}; oldHandle=0x{oldHandle.ToInt64():X}; oldHandleUsable={oldHandleUsable}; oldSession={oldSession}; oldStable={oldStable}; oldUrl={oldUrl}; ttlSeconds={VideoSwitchPreservationTtlSeconds}");
        SetStatus($"Preservação armada no slot {slot.Number} para {commandText}; observando por {VideoSwitchPreservationTtlSeconds}s");
    }

    private static bool IsPlaylistCollectionRootUrl(string? url)
    {
        try
        {
            if (!Uri.TryCreate(url, UriKind.Absolute, out var uri)) return false;
            var path = uri.AbsolutePath.Trim('/');
            return string.Equals(path, "playlists", StringComparison.OrdinalIgnoreCase)
                || string.Equals(path, "playlist", StringComparison.OrdinalIgnoreCase);
        }
        catch { return false; }
    }

    private static bool IsAuthoritativeNextCommandTarget(VideoTabInfo? tab)
    {
        if (tab is null
            || !tab.PlaylistDetected
            || IsPlaylistCollectionRootUrl(tab.Url)
            || IsPlaylistCollectionRootUrl(tab.NextTargetPageUrl)
            || !string.Equals(tab.NextTargetStatus, "TARGET_RESOLVED", StringComparison.OrdinalIgnoreCase)
            || string.IsNullOrWhiteSpace(tab.NextAssetId)
            || string.Equals(tab.NextAssetId, tab.CurrentAssetId, StringComparison.OrdinalIgnoreCase)
            || tab.NextTargetGeneration <= 0
            || string.IsNullOrWhiteSpace(tab.NextTargetOperationId))
            return false;

        // O asset + geração + operationId são a identidade autoritativa. Índices podem
        // permanecer -1 em playlists que não expõem ?index= na URL.
        return string.IsNullOrWhiteSpace(tab.NextPreviewAssetId)
            || string.Equals(tab.NextPreviewAssetId, tab.NextAssetId, StringComparison.OrdinalIgnoreCase);
    }

    private VideoTabInfo? ResolveAuthoritativeNextCandidateForSlot(PipSlot slot, out string source)
    {
        var paired = ResolvePairedVideoTab(slot.Number);
        if (IsAuthoritativeNextCommandTarget(paired))
        {
            source = "paired-identity";
            return paired;
        }

        _slotPairedTabIds.TryGetValue(slot.Number, out var pairedTabId);
        if (pairedTabId > 0)
        {
            var sameTab = VideoTabs
                .Where(tab => tab.TabId == pairedTabId && IsAuthoritativeNextCommandTarget(tab))
                .ToList();
            if (sameTab.Count == 1)
            {
                source = "same-tab-authoritative-target";
                return sameTab[0];
            }
        }

        source = "paired-target-incomplete";
        return paired;
    }

    private async Task<VideoTabInfo?> ResolveAuthoritativeNextCommandTargetAsync(PipSlot slot)
    {
        var checkpoints = new[] { 0, 120, 260, 480 };
        for (var attempt = 0; attempt < checkpoints.Length; attempt++)
        {
            if (checkpoints[attempt] > 0)
                await Task.Delay(checkpoints[attempt] - checkpoints[attempt - 1]);
            try
            {
                await _extensionBridge.RequestVideoSessionsSnapshotAsync();
            }
            catch { }
            if (attempt < checkpoints.Length - 1)
                await Task.Delay(45);

            var candidate = ResolveAuthoritativeNextCandidateForSlot(slot, out var source);
            if (IsAuthoritativeNextCommandTarget(candidate))
            {
                AppLogger.Info(
                    $"next-command-target-reresolved: slot={slot.Number}; attempt={attempt + 1}; source={source}; " +
                    $"currentAssetId={candidate!.CurrentAssetId}; nextAssetId={candidate.NextAssetId}; " +
                    $"currentIndex={candidate.PlaylistIndex}; nextIndex={candidate.NextPreviewIndex}; " +
                    $"generation={candidate.NextTargetGeneration}; operationId={candidate.NextTargetOperationId}; " +
                    $"indexlessAccepted={candidate.PlaylistIndex < 0 || candidate.NextPreviewIndex < 0}");
                return candidate;
            }
        }

        return ResolveAuthoritativeNextCandidateForSlot(slot, out _);
    }

private async Task SendVideoCommandToCapturedAsync(VideoCommandKind command)
    {
        if (_videoCommandBusy)
        {
            SetStatus("Comando de vídeo ainda em execução");
            return;
        }

        var cleanup = CleanupLostPipsForVisibility("Comando de vídeo");
        var label = command == VideoCommandKind.Next ? "Próximo vídeo" : "Vídeo anterior";
        var shortcut = command == VideoCommandKind.Next ? "Shift+N" : "Alt+←";

        // Fase 2 corefix: comando só vai para PiP vinculado.
        // Sem vínculo confiável, bloqueia para não comandar vídeo errado.
        if (_extensionBridge.IsConnected)
        {
            _videoCommandBusy = true;
            try
            {
                if (command == VideoCommandKind.Next)
                    await PreemptOpenAllForNextNavigationAsync(SelectedSlot, null);

                try
                {
                    await _extensionBridge.RequestVideoSessionsSnapshotAsync();
                }
                catch { }

                var selected = GetSelectedPipLabel();
                var target = TryGetSelectedPairedVideoTarget();
                if (string.IsNullOrWhiteSpace(target.PairKey) && string.IsNullOrWhiteSpace(target.VideoSessionId) && string.IsNullOrWhiteSpace(target.StableVideoKey))
                {
                    SetStatus($"{label}: selecione um PiP vinculado antes de enviar comando. Selecionado: {selected}");
                    AppLogger.Info($"Comando de vídeo bloqueado sem vínculo: {label}; selecionado={selected}");
                    return;
                }

                var targetText = !string.IsNullOrWhiteSpace(target.PairKey)
                    ? GetPairTextForSession(target.PairKey)
                    : "vínculo pendente";

                var preservationSlot = SelectedSlot;
                var pairedTabBeforeResolution = preservationSlot is not null
                    ? ResolvePairedVideoTab(preservationSlot.Number)
                    : null;
                var selectedWindow = preservationSlot?.Window;
                var hasUsableSelectedWindow = selectedWindow is not null
                    && PipWindowService.IsUsable(selectedWindow.Handle);
                var snapshotHasVideo = pairedTabBeforeResolution is not null
                    && !IsPlaylistCollectionRootUrl(pairedTabBeforeResolution.Url)
                    && (pairedTabBeforeResolution.HasSource || pairedTabBeforeResolution.ReadyState > 0);

                if (preservationSlot is null
                    || ((!hasUsableSelectedWindow || preservationSlot.State is PipSlotState.Offline or PipSlotState.AwaitingPip)
                        && !snapshotHasVideo))
                {
                    SetStatus($"{label}: slot sem PiP ativo e sem vídeo confirmado; comando bloqueado");
                    AppLogger.Warn(
                        $"video-command-blocked-offline-no-video: command={command}; slot={preservationSlot?.Number ?? 0}; " +
                        $"state={preservationSlot?.State}; hasWindow={hasUsableSelectedWindow}; tabId={target.TabId}; " +
                        $"snapshotPresent={pairedTabBeforeResolution is not null}; readyState={pairedTabBeforeResolution?.ReadyState ?? 0}; " +
                        $"hasSource={pairedTabBeforeResolution?.HasSource ?? false}; url={pairedTabBeforeResolution?.Url}");
                    return;
                }

                if (pairedTabBeforeResolution is not null && IsPlaylistCollectionRootUrl(pairedTabBeforeResolution.Url))
                {
                    SetStatus($"{label}: a página geral de playlists não é um player válido");
                    AppLogger.Warn($"video-command-blocked-playlist-collection-root: command={command}; slot={preservationSlot.Number}; tabId={pairedTabBeforeResolution.TabId}; url={pairedTabBeforeResolution.Url}");
                    return;
                }

                if (command == VideoCommandKind.Previous && !snapshotHasVideo)
                {
                    SetStatus("Vídeo anterior: player atual não está confirmado; comando bloqueado para não sair da playlist");
                    AppLogger.Warn($"previous-command-blocked-no-authoritative-player: slot={preservationSlot.Number}; tabId={target.TabId}; readyState={pairedTabBeforeResolution?.ReadyState ?? 0}; hasSource={pairedTabBeforeResolution?.HasSource ?? false}; url={pairedTabBeforeResolution?.Url}");
                    return;
                }
                var commandTarget = command == VideoCommandKind.Next && preservationSlot is not null
                    ? await ResolveAuthoritativeNextCommandTargetAsync(preservationSlot)
                    : null;
                if (command == VideoCommandKind.Next)
                {
                    if (pairedTabBeforeResolution?.PlaylistDetected == true && !IsAuthoritativeNextCommandTarget(commandTarget))
                    {
                        ArmNextPreviewCommandBarrier(preservationSlot, null);
                        SetStatus("Próximo vídeo: alvo autoritativo ainda não está pronto; comando não enviado para evitar salto incorreto");
                        AppLogger.Warn(
                            $"next-command-blocked-no-authoritative-target: slot={preservationSlot?.Number ?? 0}; " +
                            $"tabId={target.TabId}; targetStatus={commandTarget?.NextTargetStatus}; " +
                            $"currentAssetId={commandTarget?.CurrentAssetId}; nextAssetId={commandTarget?.NextAssetId}; " +
                            $"generation={commandTarget?.NextTargetGeneration ?? 0}; operationId={commandTarget?.NextTargetOperationId}; " +
                            "action=wait-for-next-snapshot");
                        return;
                    }

                    await PreemptOpenAllForNextNavigationAsync(preservationSlot, commandTarget);
                    ArmNextPreviewCommandBarrier(preservationSlot, commandTarget);
                }
                ArmVideoSwitchPreservationIfPossible(preservationSlot, target.PairKey, target.VideoSessionId, target.StableVideoKey, target.TabId, command, selected, commandTarget);

                SetStatus($"Enviando {label} ({shortcut}) para {targetText}. Selecionado: {selected}");
                // O comando manual já possui uma aba escolhida e vinculada ao slot.
                // Se o site recriar/remover momentaneamente o <video>, a extensão
                // ainda pode executar a navegação somente nessa aba, sem procurar
                // outro vídeo/slot.
                var clients = await _extensionBridge.SendVideoCommandAsync(
                    command,
                    target.VideoSessionId,
                    target.StableVideoKey,
                    target.TabId,
                    allowNoVideoTarget: false,
                    allowSameTabNavigation: command == VideoCommandKind.Next,
                    commandTarget: commandTarget);
                ObserveVideoSwitchPreservationStates("after-video-command");
                SetStatus(clients > 0
                    ? $"{label}: enviado para {targetText} via extensão. Selecionado: {selected}"
                    : "Extensão não conectada");
                AppLogger.Info($"Comando de vídeo via extensão: {label}; conexoes={clients}; selecionado={selected}; alvo={targetText}; session={target.VideoSessionId}; stable={target.StableVideoKey}; removidosAntes={cleanup.Removed}; commandTargetAssetId={commandTarget?.NextAssetId}; commandTargetGeneration={commandTarget?.NextTargetGeneration ?? 0}; commandTargetOperationId={commandTarget?.NextTargetOperationId}");

                if (clients > 0 && command == VideoCommandKind.Next)
                    AppLogger.Info($"Base limpa: recuperação agressiva pós-Próximo desativada; use Capturar todos se o Zen fechar o PiP; tabId={target.TabId}");
            }
            finally
            {
                _videoCommandBusy = false;
            SignalPipOperationAvailability("video-command-finished");
            }

            return;
        }

        // Fallback local/experimental: tenta mandar o atalho para as janelas PiP.
        var targets = Slots
            .Where(slot => slot.Window is not null && !slot.IsHidden && PipWindowService.IsUsable(slot.Window!.Handle))
            .OrderBy(slot => slot.Number)
            .Select(slot => slot.Window!.Handle)
            .Distinct()
            .ToList();

        if (targets.Count == 0)
        {
            SetStatus(_allHidden
                ? "Mostre os PiPs antes de enviar comando de vídeo"
                : "Nenhum PiP ativo para comando de vídeo");
            return;
        }

        _videoCommandBusy = true;
        var sent = 0;
        var failed = 0;

        SetStatus($"Extensão desconectada. Tentando {label} ({shortcut}) local em {targets.Count} PiP(s)...");
        AppLogger.Info($"Comando de vídeo local iniciado: {label}; alvos={targets.Count}; removidosAntes={cleanup.Removed}");

        try
        {
            foreach (var handle in targets)
            {
                if (!PipWindowService.IsUsable(handle))
                {
                    failed++;
                    continue;
                }

                if (await VideoCommandService.SendToWindowAsync(handle, command))
                    sent++;
                else
                    failed++;

                await Task.Delay(90);
            }
        }
        finally
        {
            _videoCommandBusy = false;
            SignalPipOperationAvailability("video-command-finished");
        }

        EnsureVisiblePipsTopMost(force: true);
        PositionToolbar();
        SetStatus(failed > 0
            ? $"{label}: enviado local para {sent} PiP(s), falhou em {failed}"
            : $"{label}: enviado local para {sent} PiP(s)");
        AppLogger.Info($"Comando de vídeo local concluído: {label}; enviados={sent}; falhas={failed}");

        if (command == VideoCommandKind.Next && sent > 0)
            AppLogger.Info("Base limpa: recuperação agressiva pós-Próximo local desativada");
    }

    private async Task HandleVideoCommandResultAsync(VideoCommandResultInfo info)
    {
        // Sucesso confirmado limpa a sequência de retries — o próximo bloqueio
        // (se houver) começa a contagem do zero.
        if (info.Ok)
        {
            _autoRetryNextStreak = 0;
            return;
        }

        // Só reagimos a "next": é o caso relatado — o comando avança para um
        // vídeo/sala que a extensão não consegue localizar (bloqueado, offline,
        // removido) e o slot fica parado ali. "Previous" já tem seu próprio
        // fallback (tabs.goBack) no lado da extensão.
        if (!string.Equals(info.Command, "next", StringComparison.OrdinalIgnoreCase)) return;
        if (!info.IsBlockedTarget) return;
        if (_videoCommandBusy) return;

        var now = DateTime.UtcNow;
        if (now - _lastAutoRetryNextUtc < AutoRetryNextCooldown)
        {
            // Ainda dentro do cooldown do retry anterior: evita disparar dois
            // reenvios quase simultâneos para o mesmo bloqueio.
            return;
        }

        if (_autoRetryNextStreak >= AutoRetryNextMaxStreak)
        {
            AppLogger.Warn($"auto-retry-next-abandoned: streak={_autoRetryNextStreak}; method={info.Method}; reason={info.Reason}; target={info.TargetVideoSessionId}; stable={info.TargetStableVideoKey}");
            return;
        }

        _autoRetryNextStreak++;
        _lastAutoRetryNextUtc = now;
        AppLogger.Warn($"auto-retry-next-triggered: streak={_autoRetryNextStreak}/{AutoRetryNextMaxStreak}; method={info.Method}; reason={info.Reason}; target={info.TargetVideoSessionId}; stable={info.TargetStableVideoKey}");
        SetStatus($"Vídeo bloqueado/indisponível — avançando automaticamente ({_autoRetryNextStreak}/{AutoRetryNextMaxStreak})");

        // Pequena espera para dar tempo da página assentar antes de tentar de novo.
        await Task.Delay(450);
        await SendVideoCommandToCapturedAsync(VideoCommandKind.Next);
    }

    private void ScheduleFastPipReconnectAfterVideoNext(string source, int? targetTabId = null)
    {
        // Base limpa: método mantido apenas por compatibilidade interna.
        // Não dispara timers nem atalhos automáticos para evitar instabilidade no Zen.
        AppLogger.Info($"Base limpa: ScheduleFastPipReconnectAfterVideoNext ignorado; origem={source}; tabId={targetTabId}");
    }

    private void RecoverControl()
    {
        _allHidden = false;
        var restored = 0;
        var removed = 0;

        foreach (var slot in Slots.Where(slot => slot.Window is not null).ToArray())
        {
            var handle = slot.Window!.Handle;
            if (!PipWindowService.IsUsable(handle))
            {
                AppLogger.Info($"Recuperar: slot {slot.Number} removido porque a janela não existe mais");
                slot.Window = null;
                slot.IsHidden = false;
                _hiddenPipRects.Remove(handle);
                _lockedGroupModelRects.Remove(handle);
                if (SlotHasVideoPair(slot))
                    MarkSlotOffline(slot);
                else
                    MarkSlotFree(slot);
                removed++;
                continue;
            }

            try
            {
                PipWindowService.Show(handle);
                PipWindowService.SetTopMost(handle);
                slot.IsHidden = false;
                MarkSlotActive(slot);
                var rect = PipWindowService.GetVisualRect(handle);
                if (rect.IsValid)
                    slot.RefreshWindow(slot.Window with { VisualRect = rect });
                restored++;
            }
            catch (Exception ex)
            {
                AppLogger.Error($"Falha ao recuperar o slot {slot.Number}", ex);
            }
        }

        VisibilityButton.Content = "Ocultar PiPs";
        _toolbar?.SetHiddenState(false);
        UpdateMainQuickActionLabels();
        RefreshAllSlotStates();
        RefreshCapturedWindows();
        if (_groupLocked)
            SaveLockedGroupModelFromCurrentRects();
        EnsureVisiblePipsTopMost(force: true);
        PositionToolbar();
        RefreshPipDragTargets();
        UpdateCounts();
        UpdateSelectedActions();
        SetStatus(removed > 0
            ? $"Controle recuperado: {restored} PiP(s) restaurado(s), {removed} perdido(s) removido(s)"
            : $"Controle recuperado: {restored} PiP(s) visível(is) e no topo");
        AppLogger.Info($"Recuperar controle concluído: restaurados={restored}, removidos={removed}");
    }

    private void CloseAllButton_Click(object sender, RoutedEventArgs e)
    {
        foreach (var slot in Slots.Where(slot => slot.Window is not null).ToArray())
        {
            ShadowMirrorSlotReset(slot, "CloseAllButton_Click");
            PipWindowService.Close(slot.Window!.Handle);
            slot.Window = null;
            slot.IsHidden = false;
            ClearSlotPairMetadata(slot.Number);
            MarkSlotFree(slot);
        }
        _allHidden = false;
        _lockedGroupModelRects.Clear();
        _lockedGroupModelBounds = default;
        UpdateCounts();
        UpdateSelectedActions();
        PositionToolbar();
        SetStatus("Fechar todos enviado para os PiPs capturados");
    }

    private void ResetStateButton_Click(object sender, RoutedEventArgs e)
    {
        foreach (var slot in Slots)
        {
            ShadowMirrorSlotReset(slot, "ResetStateButton_Click");
            slot.Window = null;
            slot.IsHidden = false;
            MarkSlotFree(slot);
        }
        _slotVideoPairs.Clear();
        _slotStableVideoPairs.Clear();
        _slotPairedTabIds.Clear();
        _slotIntrinsicContentAspectRatios.Clear();
        _allHidden = false;
        _lastResizedSlotNumber = null;
        _lastManuallyResizedSlotNumber = null;
        _slotLayoutRects.Clear();
        _lockedGroupModelRects.Clear();
        _lockedGroupModelBounds = default;
        _hiddenPipRects.Clear();
        _customLayoutActive = CurrentLayout == LayoutMode.Custom;
        EnsureSlotLayoutRects();
        UpdatePanelSlotVisuals();
        UpdateCounts();
        SaveSettings();
        SetStatus("Estado local resetado");
    }

    private void ToggleLiveCaptureButton_Click(object sender, RoutedEventArgs e)
    {
        _liveCaptureActive = !_liveCaptureActive;
        if (_liveCaptureActive)
        {
            _liveCaptureStopAtUtc = DateTime.UtcNow.AddSeconds(45);
            _liveCaptureTimer.Start();
            SetStatus("Captura ao vivo local iniciada: abra PiPs agora");
        }
        else
        {
            _liveCaptureTimer.Stop();
            SetStatus("Captura ao vivo local encerrada");
        }
    }

    private void LiveCaptureTick()
    {
        if (!_liveCaptureActive) return;
        if (DateTime.UtcNow > _liveCaptureStopAtUtc)
        {
            _liveCaptureActive = false;
            _liveCaptureTimer.Stop();
            SetStatus("Captura ao vivo local encerrada por tempo");
            return;
        }
        CapturePipsStable();
    }

    private void HidePanelButton_Click(object sender, RoutedEventArgs e) => Hide();

    private void ShowPanel()
    {
        Show();
        if (WindowState == WindowState.Minimized) WindowState = WindowState.Normal;
        Activate();
    }

    private void MoveCapturedGroup(int deltaX, int deltaY)
    {
        if (!_groupLocked) return;
        if (deltaX == 0 && deltaY == 0) return;

        var occupied = GetOccupiedSlotsInNumberOrder();
        if (occupied.Length == 0) return;

        var bounds = _layoutService.GetGroupBounds(Slots);
        if (!bounds.IsValid) return;

        var screen = PipWindowService.GetVirtualScreenBounds();

        // Um grupo pode ficar 1 px (ou mais) maior que a tela por arredondamento
        // de DPI/aspect ratio. Nesse caso os limites naturais ficam invertidos
        // (por exemplo: min=0, max=-1) e Math.Clamp lanca ArgumentException.
        // Ordenar os limites mantem o grupo movel dentro da faixa de sobreposicao
        // possivel sem interromper a thread da interface.
        var minDeltaX = screen.Left - bounds.Left;
        var maxDeltaX = screen.Right - bounds.Right;
        var minDeltaY = screen.Top - bounds.Top;
        var maxDeltaY = screen.Bottom - bounds.Bottom;
        var constrainedX = Math.Clamp(deltaX, Math.Min(minDeltaX, maxDeltaX), Math.Max(minDeltaX, maxDeltaX));
        var constrainedY = Math.Clamp(deltaY, Math.Min(minDeltaY, maxDeltaY), Math.Max(minDeltaY, maxDeltaY));
        if (constrainedX == 0 && constrainedY == 0) return;

        _ignoreWindowMovesUntilUtc = DateTime.UtcNow.AddMilliseconds(200);
        var moves = new List<(IntPtr Handle, NativeRect Target)>(occupied.Length);
        foreach (var slot in occupied)
        {
            var current = PipWindowService.GetVisualRect(slot.Window!.Handle);
            if (!current.IsValid) continue;
            var target = new NativeRect(
                current.Left + constrainedX,
                current.Top + constrainedY,
                current.Right + constrainedX,
                current.Bottom + constrainedY);
            moves.Add((slot.Window!.Handle, target));
            slot.RefreshWindow(slot.Window! with { VisualRect = target });
        }

        if (moves.Count > 0)
            PipWindowService.MoveVisualBatch(moves, pixelThreshold: 0);

        if (_fixedCustomLayoutEnabled)
        {
            OffsetFixedSlotAuthority(constrainedX, constrainedY, "toolbar-group-move");
            if (CurrentLayout == LayoutMode.Jogo)
                ApplyFixedLayoutToAllActive("toolbar-group-move/jogo-reanchor");
        }

        _lastKnownGroupBounds = _fixedCustomLayoutEnabled && CurrentLayout == LayoutMode.Jogo
            ? _layoutService.GetGroupBounds(Slots)
            : new NativeRect(
                bounds.Left + constrainedX,
                bounds.Top + constrainedY,
                bounds.Right + constrainedX,
                bounds.Bottom + constrainedY);
        CaptureCurrentRectsIntoSlotLayout();
        PositionToolbar();
        RefreshPipDragTargets();
    }

    private void PipCountButton_Click(object sender, RoutedEventArgs e)
    {
        if (PipCountButton.ContextMenu is null) return;
        PipCountButton.ContextMenu.PlacementTarget = PipCountButton;
        PipCountButton.ContextMenu.IsOpen = true;
    }

    private void SlotCountMenuItem_Click(object sender, RoutedEventArgs e)
    {
        if (sender is not MenuItem { Tag: string countText } ||
            !int.TryParse(countText, out var count)) return;

        if (!TrySetSlotCountPreservingPips(count))
            return;

        EnsureSlotLayoutRects();
        UpdatePipCountButton();
        UpdateCounts();
        SaveSettings();
        SetStatus($"Quantidade ajustada para {Slots.Count} slot(s)");
    }

    private void UpdatePipCountButton() => PipCountButton.Content = $"PiPs: {Slots.Count} ▼";

    private void LayoutMenuItem_Click(object sender, RoutedEventArgs e)
    {
        if (sender is not MenuItem { Tag: string modeName } ||
            !Enum.TryParse<LayoutMode>(modeName, out var mode)) return;

        // Jogo e Fixar layout são compatíveis. Somente outros perfis automáticos
        // desligam a autoridade fixa personalizada.
        if (mode != LayoutMode.Custom
            && mode != LayoutMode.Jogo
            && _fixedCustomLayoutEnabled)
        {
            _fixedCustomLayoutEnabled = false;
            _respectFixedLayoutAreaEnabled = false;
            _fixedLayoutRespectTimer?.Stop();
            RestoreManagedWindows("layout-mode-changed");
        }

        if (mode == LayoutMode.Jogo && Slots.Count != 10)
        {
            if (!TrySetSlotCountPreservingPips(10))
                return;
            UpdatePipCountButton();
            UpdateCounts();
        }

        _customLayoutActive = mode == LayoutMode.Custom;
        _settings.LayoutMode = mode;
        UpdateJogoSpaceHideHotkeyRegistration("layout-changed");
        UpdateJogoFreeAreaUi();
        RefreshLayoutText();

        if (_customLayoutActive)
            BuildCustomSlotOverlay(forceReset: EditableSlots.Count != Slots.Count);

        SaveSettings();
        UpdatePanelSlotVisuals();
        UpdateFixedLayoutUi();

        if (Slots.Any(slot => slot.Window is not null))
        {
            if (mode == LayoutMode.Jogo)
                EqualizeCaptured();
            else
                ArrangeCaptured(preferPanelTemplateAnchor: !_customLayoutActive);
            CaptureCurrentRectsIntoSlotLayout();
            PositionToolbar();
        }

        SetStatus(_customLayoutActive
            ? "Personalizado aplicado automaticamente: molde salvo preservado"
            : mode == LayoutMode.Jogo
                ? "Perfil Jogo aplicado: 1–6 em linha, 7–10 em coluna e encaixe rente à área útil"
                : $"Layout aplicado automaticamente: {mode.ToLabel()}");
    }

    private void LockGroupButton_Changed(object sender, RoutedEventArgs e)
    {
        if (LockGroupButton is null || StatusText is null) return;

        // Travar/Soltar não altera os slots.
        // Como o botão Aplicar foi removido, ao travar alinhamos os PiPs uma vez
        // no layout atual e depois apenas prendemos o bloco para arrastar em conjunto.
        _groupLocked = LockGroupButton.IsChecked == true;
        _toolbar?.SetLockState(_groupLocked);
        LockGroupButton.Content = _groupLocked ? "Soltar grupo" : "Travar grupo";

        if (_groupLocked)
        {
            // Ao travar, cola e estabiliza o grupo uma única vez em transação atômica.
            // Depois disso o modo permanece passivo e não corrige as janelas em loop.
            RebuildGroupFromLayout(preferPanelTemplateAnchor: false, resizeToTargets: false, saveLockedModel: false);
            SaveLockedGroupModelFromCurrentRects();
            AppLogger.Info($"lock-group-atomic-layout-applied: slots={Slots.Count(slot => slot.Window is not null)}; layout={CurrentLayout}");
            _lastKnownGroupBounds = _lockedGroupModelBounds.IsValid
                ? _lockedGroupModelBounds
                : _layoutService.GetGroupBounds(Slots);
            PositionToolbar();
            SetStatus("Grupo travado: molde salvo. Arraste qualquer PiP para mover o bloco.");
            AppLogger.Info("Grupo travado em modo passivo/performance");
        }
        else
        {
            _lockedGroupModelRects.Clear();
            _lockedGroupModelBounds = default;
            SetStatus(_customLayoutActive
                ? "Grupo solto: ajuste os slots ou mova os PiPs livremente"
                : "Grupo solto: PiPs livres");
            AppLogger.Info("Grupo solto");
        }

        UpdateMainQuickActionLabels();
    }

    private void CustomModeButton_Click(object sender, RoutedEventArgs e) => EnterCustomMode();

    private void EnterCustomMode()
    {
        _customLayoutActive = true;
        _settings.LayoutMode = LayoutMode.Custom;
        UpdateJogoSpaceHideHotkeyRegistration("enter-custom-mode");
        RefreshLayoutText();
        BuildCustomSlotOverlay(forceReset: EditableSlots.Count != Slots.Count);

        UpdatePanelSlotVisuals();
        SaveSettings();

        if (Slots.Any(slot => slot.Window is not null))
        {
            RebuildGroupFromLayout(preferPanelTemplateAnchor: false, resizeToTargets: false, saveLockedModel: _groupLocked);
        }

        SetStatus("Personalizado ativo: molde salvo aplicado automaticamente");
    }

    private void ToggleLockMode()
    {
        LockGroupButton.IsChecked = LockGroupButton.IsChecked != true;
    }

    private void SlotsList_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        UpdateSelectedActions();
        UpdatePairPreviewNotice();
    }

    private void SlotItem_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (sender is FrameworkElement { DataContext: PipSlot slot })
        {
            _slotDragStartPoint = e.GetPosition(SlotsList);
            _slotDragSource = slot;
            SelectSlotFromPipClick(slot, setStatus: true);
            e.Handled = false;
        }
    }

    private void SlotItem_MouseEnter(object sender, MouseEventArgs e)
    {
        if (sender is FrameworkElement { DataContext: PipSlot slot })
        {
            _hoveredPreviewSlotNumber = slot.Number;
            UpdateNextPreviewWindow();
            if (sender is FrameworkElement element)
            {
                _ = LoadSlotPreviewImageAsync(element, slot);
                var media = element.FindName("SlotPreviewMedia") as MediaElement;
                if (media is not null && _nextVideoPreviewEnabled && slot.HasAnimatedNextPreview && Uri.TryCreate(slot.NextPreviewVideoUrl, UriKind.Absolute, out var source))
                {
                    media.Source = source;
                    media.Visibility = Visibility.Visible;
                    media.Play();
                }
            }
        }
    }

    private static HttpClient CreateSlotPreviewHttpClient()
    {
        var client = new HttpClient { Timeout = TimeSpan.FromSeconds(8) };
        client.DefaultRequestHeaders.UserAgent.ParseAdd("Mozilla/5.0 (Windows NT 10.0; Win64; x64) Firefox/128.0");
        return client;
    }

    private async Task LoadSlotPreviewImageAsync(FrameworkElement element, PipSlot slot)
    {
        if (element.FindName("SlotPreviewImage") is not Image image || string.IsNullOrWhiteSpace(slot.NextPreviewThumbnailUrl)) return;
        var url = slot.NextPreviewThumbnailUrl;
        try
        {
            var bitmap = await GetSlotPreviewBitmapAsync(url);
            if (slot.NextPreviewThumbnailUrl == url) image.Source = bitmap;
            AppLogger.InfoAggregated($"next-preview-image-loaded:{slot.Number}", TimeSpan.FromSeconds(15), $"next-preview-image-loaded: slot={slot.Number}; url={url}");
            if (IsNumberedThumbnailSequence(url))
            {
                var generation = _slotPreviewAnimationGeneration.TryGetValue(slot.Number, out var current) ? current + 1 : 1;
                _slotPreviewAnimationGeneration[slot.Number] = generation;
                _ = AnimateThumbnailSequencePreviewAsync(element, slot, url, generation);
            }
        }
        catch (Exception ex)
        {
            image.Source = null;
            AppLogger.WarnAggregated($"next-preview-image-failed:{slot.Number}", TimeSpan.FromSeconds(10), $"next-preview-image-failed: slot={slot.Number}; type={ex.GetType().Name}; message={ex.Message.Replace(';', '_')}; url={url}");
        }
    }

    private async Task<BitmapImage> GetSlotPreviewBitmapAsync(string url)
    {
        if (_slotPreviewImageCache.TryGetValue(url, out var cached)) return cached;
        using var request = new HttpRequestMessage(HttpMethod.Get, url);
        if (Uri.TryCreate(url, UriKind.Absolute, out var sourceUri))
            request.Headers.Referrer = new Uri(sourceUri.GetLeftPart(UriPartial.Authority) + "/");
        using var response = await SlotPreviewHttpClient.SendAsync(request, HttpCompletionOption.ResponseHeadersRead);
        response.EnsureSuccessStatusCode();
        var bytes = await response.Content.ReadAsByteArrayAsync();
        if (bytes.Length == 0 || bytes.Length > 12 * 1024 * 1024) throw new InvalidDataException($"invalid-image-size:{bytes.Length}");
        using var stream = new MemoryStream(bytes);
        var bitmap = new BitmapImage();
        bitmap.BeginInit();
        bitmap.CacheOption = BitmapCacheOption.OnLoad;
        bitmap.StreamSource = stream;
        bitmap.EndInit();
        bitmap.Freeze();
        if (_slotPreviewImageCache.Count >= 80) _slotPreviewImageCache.Clear();
        _slotPreviewImageCache[url] = bitmap;
        return bitmap;
    }

    private static bool IsNumberedThumbnailSequence(string url) =>
        System.Text.RegularExpressions.Regex.IsMatch(
            url ?? string.Empty,
            @"\d+\.(?:jpe?g|webp)(?:\?.*)?$",
            System.Text.RegularExpressions.RegexOptions.IgnoreCase);

    private async Task AnimateThumbnailSequencePreviewAsync(FrameworkElement element, PipSlot slot, string baseUrl, int generation)
    {
        var match = System.Text.RegularExpressions.Regex.Match(baseUrl, @"(?<frame>\d+)(?<ext>\.(?:jpe?g|webp))(?:\?.*)?$", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
        if (!match.Success || element.FindName("SlotPreviewImage") is not Image image) return;
        var prefix = baseUrl[..match.Index];
        var suffix = match.Groups["ext"].Value;
        var loadedFrames = 0;
        for (var frame = 1; frame <= 12; frame++)
        {
            if (!element.IsMouseOver || !_slotPreviewAnimationGeneration.TryGetValue(slot.Number, out var active) || active != generation) return;
            var frameUrl = $"{prefix}{frame}{suffix}";
            try
            {
                var bitmap = await GetSlotPreviewBitmapAsync(frameUrl);
                if (element.IsMouseOver && active == generation) image.Source = bitmap;
                loadedFrames++;
            }
            catch { }
            await Task.Delay(180);
        }
        if (loadedFrames >= 2 && element.IsMouseOver && _slotPreviewAnimationGeneration.TryGetValue(slot.Number, out var latest) && latest == generation)
            _ = AnimateThumbnailSequencePreviewAsync(element, slot, baseUrl, generation);
    }

    private async void SlotItem_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
    {
        if (sender is not FrameworkElement { DataContext: PipSlot slot } || !slot.HasNextPreview || !_nextVideoPreviewEnabled) return;
        if (e.OriginalSource is DependencyObject source && FindVisualParent<Button>(source) is not null) return;
        var delta = e.GetPosition(SlotsList) - _slotDragStartPoint;
        if (Math.Abs(delta.X) >= SystemParameters.MinimumHorizontalDragDistance || Math.Abs(delta.Y) >= SystemParameters.MinimumVerticalDragDistance) return;
        SelectedSlot = slot;
        SlotsList.SelectedItem = slot;
        e.Handled = true;
        AppLogger.Info($"next-preview-inline-clicked: slot={slot.Number}");
        await SendVideoCommandToCapturedAsync(VideoCommandKind.Next);
    }

    private static T? FindVisualParent<T>(DependencyObject? node) where T : DependencyObject
    {
        while (node is not null)
        {
            if (node is T match) return match;
            node = VisualTreeHelper.GetParent(node);
        }
        return null;
    }

    private async void SlotItem_MouseLeave(object sender, MouseEventArgs e)
    {
        if (sender is not FrameworkElement { DataContext: PipSlot slot }) return;
        _slotPreviewAnimationGeneration[slot.Number] = (_slotPreviewAnimationGeneration.TryGetValue(slot.Number, out var generation) ? generation : 0) + 1;
        await Task.Delay(150);
        if (sender is FrameworkElement element && element.IsMouseOver) return;
        if (sender is FrameworkElement previewElement)
        {
            if (previewElement.FindName("SlotPreviewMedia") is MediaElement media)
            {
                media.Stop();
                media.Source = null;
                media.Visibility = Visibility.Collapsed;
            }
        }
        if (_hoveredPreviewSlotNumber == slot.Number)
        {
            _hoveredPreviewSlotNumber = null;
            ScheduleNextPreviewUpdate();
        }
    }

    private void SlotItem_MouseMove(object sender, MouseEventArgs e)
    {
        if (e.LeftButton != MouseButtonState.Pressed || _slotDragSource is null) return;
        var current = e.GetPosition(SlotsList);
        if (Math.Abs(current.X - _slotDragStartPoint.X) < SystemParameters.MinimumHorizontalDragDistance &&
            Math.Abs(current.Y - _slotDragStartPoint.Y) < SystemParameters.MinimumVerticalDragDistance) return;

        var source = _slotDragSource;
        _slotDragSource = null;
        DragDrop.DoDragDrop((DependencyObject)sender, source, DragDropEffects.Move);
    }

    private void SlotItem_DragOver(object sender, DragEventArgs e)
    {
        var target = (sender as FrameworkElement)?.DataContext as PipSlot;
        var source = e.Data.GetData(typeof(PipSlot)) as PipSlot;
        e.Effects = source is not null && target is not null && CanSwapSlots(source, target, out _)
            ? DragDropEffects.Move
            : DragDropEffects.None;
        e.Handled = true;
    }

    private void SlotItem_Drop(object sender, DragEventArgs e)
    {
        var target = (sender as FrameworkElement)?.DataContext as PipSlot;
        var source = e.Data.GetData(typeof(PipSlot)) as PipSlot;
        if (source is null || target is null || ReferenceEquals(source, target)) return;
        if (!CanSwapSlots(source, target, out var reason))
        {
            SetStatus(reason);
            return;
        }
        SwapSlotAssignments(source, target);
        e.Handled = true;
    }

    private bool CanSwapSlots(PipSlot source, PipSlot target, out string reason)
    {
        reason = string.Empty;
        if (ReferenceEquals(source, target)) return false;
        if (_openPipAttemptInProgress || _armedPipTargetSlotNumber == source.Number || _armedPipTargetSlotNumber == target.Number)
        {
            reason = "Aguarde a abertura de PiP terminar antes de trocar slots.";
            return false;
        }
        if (source.State is PipSlotState.AwaitingPip or PipSlotState.Offline ||
            target.State is PipSlotState.AwaitingPip or PipSlotState.Offline ||
            _autoReturnStatesBySlot.ContainsKey(source.Number) || _autoReturnStatesBySlot.ContainsKey(target.Number) ||
            _pendingLostPipsBySlot.ContainsKey(source.Number) || _pendingLostPipsBySlot.ContainsKey(target.Number))
        {
            reason = "Não é possível trocar slots enquanto há abertura ou reconexão em andamento.";
            return false;
        }
        return true;
    }

    private sealed record SlotAssignmentSnapshot(
        PipWindowInfo? Window, PipSlotState State, string PairDomain, string PairStateText,
        string PairDetailText, string PlaylistText, bool AutoReturnEnabled);

    private static SlotAssignmentSnapshot SnapshotSlot(PipSlot slot) =>
        new(slot.Window, slot.State, slot.PairDomain, slot.PairStateText, slot.PairDetailText, slot.PlaylistText, slot.IsAutoReturnEnabled);

    private static void ApplySlotSnapshot(PipSlot slot, SlotAssignmentSnapshot snapshot)
    {
        slot.Window = snapshot.Window;
        slot.State = snapshot.State;
        slot.PairDomain = snapshot.PairDomain;
        slot.PairStateText = snapshot.PairStateText;
        slot.PairDetailText = snapshot.PairDetailText;
        slot.PlaylistText = snapshot.PlaylistText;
        slot.IsAutoReturnEnabled = snapshot.AutoReturnEnabled;
    }

    private static void SwapDictionaryValues<T>(Dictionary<int, T> dictionary, int first, int second)
    {
        var hasFirst = dictionary.TryGetValue(first, out var firstValue);
        var hasSecond = dictionary.TryGetValue(second, out var secondValue);
        if (hasSecond) dictionary[first] = secondValue!; else dictionary.Remove(first);
        if (hasFirst) dictionary[second] = firstValue!; else dictionary.Remove(second);
    }

    private NativeRect GetSlotDropTargetRect(PipSlot slot, NativeRect fallback)
    {
        var index = slot.Number - 1;
        if (index >= 0 && index < _slotLayoutRects.Count && _slotLayoutRects[index].IsValid)
            return _slotLayoutRects[index];
        return fallback;
    }

    private void SwapSlotAssignments(PipSlot source, PipSlot target)
    {
        var sourceSnapshot = SnapshotSlot(source);
        var targetSnapshot = SnapshotSlot(target);
        var sourceRect = source.Window is not null ? PipWindowService.GetVisualRect(source.Window.Handle) : default;
        var targetRect = target.Window is not null ? PipWindowService.GetVisualRect(target.Window.Handle) : default;
        var jogoManualSwap = CurrentLayout == LayoutMode.Jogo;

        if (jogoManualSwap)
        {
            var occupiedBeforeSwap = GetOccupiedSlotsInNumberOrder()
                .Where(slot => slot.Window is not null && PipWindowService.IsUsable(slot.Window.Handle))
                .ToArray();
            var sourceRectsBeforeSwap = occupiedBeforeSwap
                .Select(slot => PipWindowService.GetVisualRect(slot.Window!.Handle))
                .ToArray();
            if (sourceRectsBeforeSwap.Length == occupiedBeforeSwap.Length
                && sourceRectsBeforeSwap.All(rect => rect.IsValid))
            {
                EnableJogoManualPlacementFromCurrentTopology(
                    occupiedBeforeSwap,
                    sourceRectsBeforeSwap,
                    "slot-drag-swap");
            }
        }

        SwapDictionaryValues(_slotVideoPairs, source.Number, target.Number);
        SwapDictionaryValues(_slotStableVideoPairs, source.Number, target.Number);
        SwapDictionaryValues(_slotPairedTabIds, source.Number, target.Number);
        SwapDictionaryValues(_slotPairDomains, source.Number, target.Number);
        SwapDictionaryValues(_slotPairUrls, source.Number, target.Number);
        SwapDictionaryValues(_slotIntrinsicContentAspectRatios, source.Number, target.Number);
        SwapDictionaryValues(_slotAutoReturnDiscreteBySlot, source.Number, target.Number);

        ApplySlotSnapshot(source, targetSnapshot);
        ApplySlotSnapshot(target, sourceSnapshot);

        if (jogoManualSwap)
        {
            // No perfil Jogo, trocar os cartões significa trocar o conteúdo entre
            // duas posições visuais. A topologia manual impede que a classificação
            // automática horizontal/vertical desfaça a escolha no próximo reflow.
            if (_fixedCustomLayoutEnabled && HasCompleteFixedLayoutAuthority())
            {
                ApplyFixedLayoutToAllActive(
                    "slot-drag-swap/jogo-manual-placement",
                    resizeToTargets: true);
            }
            else
            {
                RebuildGroupFromLayout(
                    preferPanelTemplateAnchor: false,
                    resizeToTargets: true,
                    saveLockedModel: _groupLocked);
            }
        }
        else
        {
            if (source.Window is not null)
            {
                var rect = GetSlotDropTargetRect(source, targetRect.IsValid ? targetRect : sourceRect);
                if (rect.IsValid)
                {
                    PipWindowService.MoveVisual(source.Window.Handle, rect.Left, rect.Top);
                    var actual = PipWindowService.GetVisualRect(source.Window.Handle);
                    if (actual.IsValid)
                        source.RefreshWindow(source.Window with { VisualRect = actual });
                }
            }
            if (target.Window is not null)
            {
                var rect = GetSlotDropTargetRect(target, sourceRect.IsValid ? sourceRect : targetRect);
                if (rect.IsValid)
                {
                    PipWindowService.MoveVisual(target.Window.Handle, rect.Left, rect.Top);
                    var actual = PipWindowService.GetVisualRect(target.Window.Handle);
                    if (actual.IsValid)
                        target.RefreshWindow(target.Window with { VisualRect = actual });
                }
            }
        }

        NormalizeSlotAutoReturnSettings(migrateFromGlobal: false);
        UpdateAutoReturnPolicyVisual();
        CaptureCurrentRectsIntoSlotLayout();
        SaveSettings();
        SelectedSlot = target;
        SlotsList.SelectedItem = target;
        UpdateSelectedActions(setStatus: false);
        PositionToolbar();
        SetStatus(jogoManualSwap
            ? $"Posições Jogo dos slots {source.Number} e {target.Number} trocadas"
            : $"Slots {source.Number} e {target.Number} trocados");
        AppLogger.Info(
            $"slot-drag-swap-completed: source={source.Number}; target={target.Number}; " +
            $"sourceHwnd={(source.Window is null ? "none" : $"0x{source.Window.Handle.ToInt64():X}")}; " +
            $"targetHwnd={(target.Window is null ? "none" : $"0x{target.Window.Handle.ToInt64():X}")}; " +
            $"jogoManualPlacement={jogoManualSwap}; manualPlacementEnabled={_jogoManualPlacementEnabled}");
    }

    private void SelectSlotFromPipClick(PipSlot slot, bool setStatus)
    {
        SelectedSlot = slot;
        if (SlotsList is not null)
            SlotsList.SelectedItem = slot;
        UpdateSelectedActions(setStatus);
    }


    private void UpdateSelectedActions() => UpdateSelectedActions(setStatus: true);

    private void UpdateSelectedActions(bool setStatus)
    {
        var occupied = SlotHasAssignment(SelectedSlot);
        ReleaseSelectedButton.IsEnabled = occupied;
        UpdateSelectedPipNotice();
        if (setStatus && SelectedSlot is not null)
            SetStatus(occupied ? $"Slot {SelectedSlot.Number} selecionado ({SelectedSlot.State})" : $"Slot {SelectedSlot.Number} vazio");
    }

    private string GetSelectedPipLabel()
    {
        if (SelectedSlot is null) return "nenhum PiP";
        if (SelectedSlot.Window is null)
        {
            var pendingPairText = GetPairTextForSlot(SelectedSlot.Number);
            return SelectedSlot.State switch
            {
                PipSlotState.AwaitingPip => $"slot {SelectedSlot.Number} aguardando PiP" + (string.IsNullOrWhiteSpace(pendingPairText) ? string.Empty : $" → {pendingPairText}"),
                PipSlotState.Offline => $"slot {SelectedSlot.Number} offline" + (string.IsNullOrWhiteSpace(pendingPairText) ? string.Empty : $" → {pendingPairText}"),
                _ => string.IsNullOrWhiteSpace(pendingPairText)
                    ? $"slot {SelectedSlot.Number} vazio"
                    : $"slot {SelectedSlot.Number} aguardando reconexao → {pendingPairText}"
            };
        }

        var title = string.IsNullOrWhiteSpace(SelectedSlot.Window.Title)
            ? "Picture-in-Picture"
            : SelectedSlot.Window.Title.Trim();

        if (title.Length > 54) title = title[..54] + "...";

        var pairText = GetPairTextForSlot(SelectedSlot.Number);
        return string.IsNullOrWhiteSpace(pairText)
            ? $"PiP {SelectedSlot.Number} — {title}"
            : $"PiP {SelectedSlot.Number} — {title} → {pairText}";
    }

    private void AutoAdvanceOnEndButton_Click(object sender, RoutedEventArgs e)
    {
        if (!_initializationComplete)
            return;

        _autoAdvanceOnVideoEndEnabled = !_autoAdvanceOnVideoEndEnabled;
        _settings.AutoAdvanceOnVideoEndEnabled = _autoAdvanceOnVideoEndEnabled;
        UpdateAutoAdvanceOnEndVisual();
        SaveSettings();
        SetStatus(_autoAdvanceOnVideoEndEnabled
            ? "Próximo automático ao terminar: ligado"
            : "Próximo automático ao terminar: desligado");
        AppLogger.Info($"auto-advance-terminal-setting-changed: enabled={_autoAdvanceOnVideoEndEnabled}");
    }

    private void UpdateAutoAdvanceOnEndVisual()
    {
        if (AutoAdvanceOnEndButton is null)
            return;

        AutoAdvanceOnEndButton.Content = _autoAdvanceOnVideoEndEnabled
            ? "Fim→Próx: ON"
            : "Fim→Próx: OFF";
    }

    private void NextPreviewQuickButton_Click(object sender, RoutedEventArgs e)
    {
        if (!_initializationComplete) return;
        _nextVideoPreviewEnabled = !_nextVideoPreviewEnabled;
        _settings.NextVideoPreviewEnabled = _nextVideoPreviewEnabled;
        UpdateNextPreviewVisual();
        SaveSettings();
        ScheduleNextPreviewUpdate();
        SetStatus(_nextVideoPreviewEnabled ? "Preview animado do próximo vídeo: ligado" : "Preview do próximo vídeo: desligado");
        AppLogger.Info($"next-preview-setting-changed: enabled={_nextVideoPreviewEnabled}");
    }

    private void UpdateNextPreviewVisual()
    {
        if (NextPreviewQuickButton is not null)
            NextPreviewQuickButton.Content = _nextVideoPreviewEnabled ? "Preview: ON" : "Preview: OFF";
        if (!_nextVideoPreviewEnabled)
            foreach (var preview in _nextVideoPreviewWindowsBySlot.Values) preview.Hide();
    }

    private async void NextPreloadQuickButton_Click(object sender, RoutedEventArgs e)
    {
        if (!_initializationComplete) return;
        _nextVideoPreloadEnabled = !_nextVideoPreloadEnabled;
        _settings.NextVideoPreloadEnabled = _nextVideoPreloadEnabled;
        foreach (var slot in Slots) _slotNextVideoPreloadBySlot[slot.Number] = _nextVideoPreloadEnabled;
        _settings.NextVideoPreloadBySlot = _slotNextVideoPreloadBySlot.ToDictionary(item => item.Key, item => item.Value);
        foreach (var slot in Slots) slot.IsPreloadEnabled = _nextVideoPreloadEnabled;
        UpdateNextPreloadVisual();
        SaveSettings();
        var clients = await _extensionBridge.SendNextVideoPreloadSettingAsync(_nextVideoPreloadEnabled);
        SetStatus(_nextVideoPreloadEnabled ? "Pré-carregamento do próximo vídeo: ligado" : "Pré-carregamento do próximo vídeo: desligado");
        AppLogger.Info($"next-preload-setting-changed: enabled={_nextVideoPreloadEnabled}; clients={clients}");
    }

    private void UpdateNextPreloadVisual()
    {
        if (NextPreloadQuickButton is not null)
            NextPreloadQuickButton.Content = _nextVideoPreloadEnabled ? "Preload: ON" : "Preload: OFF";
    }

    private void NormalizeSlotPreloadSettings()
    {
        var persisted = _settings.NextVideoPreloadBySlot is { Count: > 0 };
        _slotNextVideoPreloadBySlot.Clear();
        foreach (var slot in Slots)
        {
            var enabled = persisted && _settings.NextVideoPreloadBySlot.TryGetValue(slot.Number, out var saved) ? saved : _settings.NextVideoPreloadEnabled;
            _slotNextVideoPreloadBySlot[slot.Number] = enabled;
            slot.IsPreloadEnabled = enabled;
        }
        _settings.NextVideoPreloadBySlot = _slotNextVideoPreloadBySlot.ToDictionary(item => item.Key, item => item.Value);
        _nextVideoPreloadEnabled = _slotNextVideoPreloadBySlot.Values.Any(value => value);
    }

    private async void SlotPreload_Click(object sender, RoutedEventArgs e)
    {
        e.Handled = true;
        if (sender is not FrameworkElement { DataContext: PipSlot slot }) return;
        var enabled = !slot.IsPreloadEnabled;
        slot.IsPreloadEnabled = enabled;
        _slotNextVideoPreloadBySlot[slot.Number] = enabled;
        _settings.NextVideoPreloadBySlot = _slotNextVideoPreloadBySlot.ToDictionary(item => item.Key, item => item.Value);
        _nextVideoPreloadEnabled = _slotNextVideoPreloadBySlot.Values.Any(value => value);
        _settings.NextVideoPreloadEnabled = _nextVideoPreloadEnabled;
        SaveSettings();
        var tab = ResolvePairedVideoTab(slot.Number);
        var clients = tab is null ? 0 : await _extensionBridge.SendNextVideoPreloadSettingAsync(enabled, tab.TabId);
        UpdateNextPreloadVisual();
        SetStatus($"Preload {(enabled ? "ligado" : "desligado")} no slot {slot.Number}");
        AppLogger.Info($"next-preload-slot-setting-changed: slot={slot.Number}; tab={tab?.TabId ?? 0}; enabled={enabled}; clients={clients}");
    }

    private async Task ApplySlotPreloadSettingAsync(int slotNumber, VideoTabInfo? tab)
    {
        if (tab is null || tab.TabId <= 0) return;
        var enabled = _slotNextVideoPreloadBySlot.TryGetValue(slotNumber, out var saved) && saved;
        if (_lastPreloadSentByTab.TryGetValue(tab.TabId, out var previous) && previous == enabled) return;
        _lastPreloadSentByTab[tab.TabId] = enabled;
        await _extensionBridge.SendNextVideoPreloadSettingAsync(enabled, tab.TabId);
    }

    private static string ExtractPreviewAssetId(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return string.Empty;
        var match = System.Text.RegularExpressions.Regex.Match(value, "[a-fA-F0-9]{20,64}");
        return match.Success ? match.Value : string.Empty;
    }

    private void ArmNextPreviewCommandBarrier(PipSlot? slot, VideoTabInfo? commandTarget)
    {
        if (slot is null) return;

        _slotPreviewAnimationGeneration[slot.Number] = _slotPreviewAnimationGeneration.TryGetValue(slot.Number, out var generation) ? generation + 1 : 1;
        slot.NextPreviewTitle = string.Empty;
        slot.NextPreviewThumbnailUrl = string.Empty;
        slot.NextPreviewVideoUrl = string.Empty;

        var hasAuthoritativeTarget = commandTarget is not null && !string.IsNullOrWhiteSpace(commandTarget.NextAssetId);
        var barrier = new NextPreviewCommandBarrier
        {
            SlotNumber = slot.Number,
            CurrentAssetId = commandTarget?.CurrentAssetId ?? string.Empty,
            CommandTargetAssetId = commandTarget?.NextAssetId ?? string.Empty,
            CurrentIndex = commandTarget?.PlaylistIndex ?? -1,
            NextIndex = commandTarget?.NextPreviewIndex ?? -1,
            TargetGeneration = commandTarget?.NextTargetGeneration ?? 0,
            TargetOperationId = commandTarget?.NextTargetOperationId ?? string.Empty,
            StartedUtc = DateTime.UtcNow
        };
        _nextPreviewCommandBarriersBySlot[slot.Number] = barrier;
        AppLogger.Info($"next-preview-command-stale-cleared: slot={slot.Number}; currentAssetId={barrier.CurrentAssetId}; commandTargetAssetId={barrier.CommandTargetAssetId}; currentIndex={barrier.CurrentIndex}; nextIndex={barrier.NextIndex}; generation={barrier.TargetGeneration}; operationId={barrier.TargetOperationId}; previewState=STALE; reason={(hasAuthoritativeTarget ? "command-target-frozen" : "no-authoritative-command-target")}");
    }

    private bool IsNextPreviewCommandBarrierActive(PipSlot slot, VideoTabInfo? tab, out string reason)
    {
        reason = string.Empty;
        if (!_nextPreviewCommandBarriersBySlot.TryGetValue(slot.Number, out var barrier)) return false;
        var barrierAge = DateTime.UtcNow - barrier.StartedUtc;
        if (barrierAge.TotalSeconds >= NextPreviewCommandBarrierMaxAgeSeconds)
        {
            _nextPreviewCommandBarriersBySlot.Remove(slot.Number);
            AppLogger.Info($"next-preview-command-barrier-expired: slot={slot.Number}; ageMs={barrierAge.TotalMilliseconds:0}; commandTargetAssetId={barrier.CommandTargetAssetId}; generation={barrier.TargetGeneration}; operationId={barrier.TargetOperationId}; action=allow-current-authoritative-target");
            return false;
        }
        if (tab is null)
        {
            reason = "command-target-awaiting-tab";
            return true;
        }
        if (string.IsNullOrWhiteSpace(barrier.CommandTargetAssetId))
        {
            reason = "command-target-unresolved";
            return true;
        }

        var reachedCommandTarget = !string.IsNullOrWhiteSpace(barrier.CommandTargetAssetId)
            && string.Equals(tab.CurrentAssetId, barrier.CommandTargetAssetId, StringComparison.OrdinalIgnoreCase);
        var indexAdvanced = barrier.NextIndex >= 0 && tab.PlaylistIndex >= barrier.NextIndex;
        var newTargetGeneration = tab.NextTargetGeneration > barrier.TargetGeneration
            || (!string.IsNullOrWhiteSpace(tab.NextTargetOperationId)
                && !string.Equals(tab.NextTargetOperationId, barrier.TargetOperationId, StringComparison.OrdinalIgnoreCase));
        var nextTargetMovedPastCommand = !string.IsNullOrWhiteSpace(tab.NextAssetId)
            && !string.Equals(tab.NextAssetId, barrier.CommandTargetAssetId, StringComparison.OrdinalIgnoreCase);

        if ((reachedCommandTarget || indexAdvanced)
            && newTargetGeneration
            && nextTargetMovedPastCommand
            && string.Equals(tab.NextTargetStatus, "TARGET_RESOLVED", StringComparison.OrdinalIgnoreCase))
        {
            _nextPreviewCommandBarriersBySlot.Remove(slot.Number);
            AppLogger.Info($"next-preview-command-barrier-released: slot={slot.Number}; currentAssetId={tab.CurrentAssetId}; nextAssetId={tab.NextAssetId}; previewAssetId={tab.NextPreviewAssetId}; previewState={tab.NextPreviewState}; generation={tab.NextTargetGeneration}; operationId={tab.NextTargetOperationId}");
            return false;
        }

        reason = reachedCommandTarget || indexAdvanced ? "new-next-target-resolving" : "command-target-not-reached";
        return true;
    }

    private static bool IsAuthoritativeNextPreview(VideoTabInfo tab, out string reason)
    {
        reason = string.Empty;
        if (!string.Equals(tab.NextPreviewState, "READY_METADATA", StringComparison.OrdinalIgnoreCase)
            && !string.Equals(tab.NextPreviewState, "READY_ANIMATED", StringComparison.OrdinalIgnoreCase))
        {
            reason = string.IsNullOrWhiteSpace(tab.NextPreviewState) ? "preview-state-empty" : $"preview-state-{tab.NextPreviewState.ToLowerInvariant()}";
            return false;
        }
        if (!string.Equals(tab.NextTargetStatus, "TARGET_RESOLVED", StringComparison.OrdinalIgnoreCase))
        {
            reason = "target-not-resolved";
            return false;
        }
        if (string.IsNullOrWhiteSpace(tab.NextAssetId))
        {
            reason = "next-asset-empty";
            return false;
        }
        if (string.Equals(tab.NextAssetId, tab.CurrentAssetId, StringComparison.OrdinalIgnoreCase))
        {
            reason = "next-equals-current";
            return false;
        }
        if (!string.Equals(tab.NextPreviewAssetId, tab.NextAssetId, StringComparison.OrdinalIgnoreCase))
        {
            reason = "preview-asset-not-authoritative";
            return false;
        }

        var thumbnailAssetId = ExtractPreviewAssetId(tab.NextPreviewThumbnailUrl);
        if (!string.IsNullOrWhiteSpace(tab.NextPreviewThumbnailUrl)
            && !string.Equals(thumbnailAssetId, tab.NextAssetId, StringComparison.OrdinalIgnoreCase))
        {
            reason = "thumbnail-asset-mismatch";
            return false;
        }

        var videoAssetId = ExtractPreviewAssetId(tab.NextPreviewVideoUrl);
        if (!string.IsNullOrWhiteSpace(videoAssetId)
            && !string.Equals(videoAssetId, tab.NextAssetId, StringComparison.OrdinalIgnoreCase))
        {
            reason = "video-asset-mismatch";
            return false;
        }

        if (string.IsNullOrWhiteSpace(tab.NextPreviewThumbnailUrl) && string.IsNullOrWhiteSpace(tab.NextPreviewVideoUrl))
        {
            reason = "preview-media-pending";
            return false;
        }
        return true;
    }

    private void ScheduleNextPreviewUpdate() => Dispatcher.BeginInvoke(UpdateNextPreviewWindow, DispatcherPriority.Loaded);

    private void UpdateNextPreviewWindow()
    {
        foreach (var slot in Slots)
        {
            var tab = ResolvePairedVideoTab(slot.Number);
            var previewRejectReason = "tab-not-found";
            var commandBarrierActive = IsNextPreviewCommandBarrierActive(slot, tab, out var commandBarrierReason);
            var authoritativePreview = !commandBarrierActive && tab is not null && IsAuthoritativeNextPreview(tab, out previewRejectReason);
            if (commandBarrierActive) previewRejectReason = commandBarrierReason;
            var valid = _nextVideoPreviewEnabled && tab is { PlaylistDetected: true }
                && !commandBarrierActive
                && authoritativePreview
                && !string.Equals(tab.SiteContentKind, "live", StringComparison.OrdinalIgnoreCase);
            if (_nextVideoPreviewEnabled && tab is not null && !valid && !string.IsNullOrWhiteSpace(tab.NextAssetId))
            {
                AppLogger.InfoAggregated(
                    $"next-preview-rejected:{slot.Number}",
                    TimeSpan.FromSeconds(5),
                    $"next-preview-authority-rejected: slot={slot.Number}; reason={previewRejectReason}; currentAssetId={tab.CurrentAssetId}; nextAssetId={tab.NextAssetId}; previewAssetId={tab.NextPreviewAssetId}; thumbnailAssetId={ExtractPreviewAssetId(tab.NextPreviewThumbnailUrl)}; videoAssetId={ExtractPreviewAssetId(tab.NextPreviewVideoUrl)}; previewState={tab.NextPreviewState}; generation={tab.NextTargetGeneration}; operationId={tab.NextTargetOperationId}");
            }
            slot.CurrentVideoTitle = tab is null ? string.Empty : (string.IsNullOrWhiteSpace(tab.CurrentItemTitle) ? tab.Title : tab.CurrentItemTitle);
            slot.NextPreviewTitle = valid ? tab!.NextPreviewTitle : string.Empty;
            slot.NextPreviewThumbnailUrl = valid ? tab!.NextPreviewThumbnailUrl : string.Empty;
            slot.NextPreviewVideoUrl = valid ? tab!.NextPreviewVideoUrl : string.Empty;
            if (valid && slot.HasNextPreview)
            {
                var animationMode = slot.HasAnimatedNextPreview
                    ? "direct-video"
                    : IsNumberedThumbnailSequence(slot.NextPreviewThumbnailUrl)
                        ? "cdn-frame-sequence"
                        : "static-image";
                AppLogger.InfoAggregated($"next-preview-inline:{slot.Number}", TimeSpan.FromSeconds(10), $"next-preview-inline-ready: slot={slot.Number}; title={slot.NextPreviewTitle}; animationMode={animationMode}; animated={slot.HasAnimatedNextPreview || animationMode == "cdn-frame-sequence"}; nativeVideo={slot.HasAnimatedNextPreview}; thumbnailPresent={!string.IsNullOrWhiteSpace(slot.NextPreviewThumbnailUrl)}; thumbnail={slot.NextPreviewThumbnailUrl}; currentAssetId={tab!.CurrentAssetId}; nextAssetId={tab.NextAssetId}; previewAssetId={tab.NextPreviewAssetId}; previewState={tab.NextPreviewState}; generation={tab.NextTargetGeneration}; operationId={tab.NextTargetOperationId}");
            }
        }
    }

    private NextVideoPreviewWindow CreateNextPreviewWindow()
    {
        var window = new NextVideoPreviewWindow { Owner = this };
        window.NextRequested += () => Dispatcher.BeginInvoke(async () => await OpenNextFromPreviewAsync(window));
        window.MediaStateChanged += state => AppLogger.InfoAggregated($"next-preview-media:{state}", TimeSpan.FromSeconds(10), $"next-preview-{state}");
        window.MouseEnter += (_, _) =>
        {
            if (window.Tag is int slotNumber) _hoveredPreviewSlotNumber = slotNumber;
        };
        window.MouseLeave += async (_, _) =>
        {
            await Task.Delay(150);
            if (!window.IsMouseOver && window.Tag is int slotNumber && _hoveredPreviewSlotNumber == slotNumber)
            {
                _hoveredPreviewSlotNumber = null;
                ScheduleNextPreviewUpdate();
            }
        };
        return window;
    }

    private async Task OpenNextFromPreviewAsync(NextVideoPreviewWindow window)
    {
        if (!_nextVideoPreviewEnabled || window.Tag is not int slotNumber) return;
        var slot = Slots.FirstOrDefault(item => item.Number == slotNumber);
        if (slot is null || ResolvePairedVideoTab(slotNumber) is null) return;
        SelectedSlot = slot;
        SlotsList.SelectedItem = slot;
        AppLogger.Info($"next-preview-clicked: slot={slotNumber}; action=validated-next-command");
        await SendVideoCommandToCapturedAsync(VideoCommandKind.Next);
    }

    private VideoTabInfo? ResolvePairedVideoTab(int slotNumber)
    {
        _slotVideoPairs.TryGetValue(slotNumber, out var pair);
        _slotStableVideoPairs.TryGetValue(slotNumber, out var stable);
        _slotPairedTabIds.TryGetValue(slotNumber, out var tabId);
        return VideoTabs.FirstOrDefault(tab => !string.IsNullOrWhiteSpace(pair) && string.Equals(tab.PairKey, pair, StringComparison.OrdinalIgnoreCase))
            ?? VideoTabs.FirstOrDefault(tab => !string.IsNullOrWhiteSpace(stable) && string.Equals(tab.StableVideoKey, stable, StringComparison.OrdinalIgnoreCase) && (tabId <= 0 || tab.TabId == tabId));
    }

    private void ArmAutoAdvanceLostPipWatch(PipSlot slot, string reason)
    {
        if (!_autoAdvanceOnVideoEndEnabled)
            return;

        if (!string.Equals(reason, "pip-window-lost", StringComparison.OrdinalIgnoreCase)
            && !string.Equals(reason, "pip-window-removed-preserved-pair", StringComparison.OrdinalIgnoreCase))
            return;

        if (!AutoAdvanceSafetyPolicy.ShouldArmLostPipWatch(IsVideoNavigationInProgress(slot.Number, DateTime.UtcNow)))
        {
            CancelAutoAdvanceLostPipWatch(slot.Number, "navigation-in-progress");
            AppLogger.Info($"auto-advance-loss-watch-suppressed: slot={slot.Number}; reason=navigation-in-progress; lossReason={reason}");
            return;
        }

        var tabId = _slotPairedTabIds.TryGetValue(slot.Number, out var pairedTabId) ? pairedTabId : 0;
        var session = _slotVideoPairs.TryGetValue(slot.Number, out var pair) ? pair : string.Empty;
        var stable = _slotStableVideoPairs.TryGetValue(slot.Number, out var stableKey) ? stableKey : string.Empty;

        if (tabId <= 0 || (string.IsNullOrWhiteSpace(session) && string.IsNullOrWhiteSpace(stable)))
            return;

        var generation = _autoAdvanceLostPipWatchGenerationBySlot.TryGetValue(slot.Number, out var current)
            ? current + 1
            : 1;
        _autoAdvanceLostPipWatchGenerationBySlot[slot.Number] = generation;
        _autoAdvanceLostPipWatchStartedUtcBySlot[slot.Number] = DateTime.UtcNow;

        AppLogger.Warn($"auto-advance-loss-watch-armed: slot={slot.Number}; tabId={tabId}; generation={generation}; reason={reason}; session={session}; stable={stable}; pollMs={AutoAdvanceLostPipPollMs}; staleThresholdMs={AutoAdvanceLostPipStaleSignalMs}");
        _ = ObserveLostPipForAutoAdvanceAsync(slot.Number, tabId, session, stable, reason, generation);
    }

    private bool IsAutoAdvanceTerminalProbeActive(int slotNumber, DateTime now, out double ageMs)
    {
        ageMs = 0;
        if (!_autoAdvanceOnVideoEndEnabled
            || !_autoAdvanceLostPipWatchGenerationBySlot.ContainsKey(slotNumber)
            || !_autoAdvanceLostPipWatchStartedUtcBySlot.TryGetValue(slotNumber, out var startedUtc))
            return false;

        ageMs = (now - startedUtc).TotalMilliseconds;
        return ageMs >= 0 && ageMs <= AutoAdvanceTerminalProbeGraceMs;
    }

    private static bool IsDirectTerminalVideoSnapshot(VideoTabInfo tab) =>
        AutoAdvanceSafetyPolicy.IsProvenTerminalSnapshot(tab.IsEnded, tab.IsPlaying, tab.ReadyState, tab.HasSource);

    private bool IsVideoNavigationInProgress(int slotNumber, DateTime now) =>
        _videoSwitchPreservationBySlot.TryGetValue(slotNumber, out var preservation)
        && preservation.ExpiresUtc > now
        && (string.Equals(preservation.CommandType, "next", StringComparison.OrdinalIgnoreCase)
            || string.Equals(preservation.CommandType, "previous", StringComparison.OrdinalIgnoreCase));

    private void CancelAutoAdvanceLostPipWatch(int slotNumber, string reason)
    {
        var generation = _autoAdvanceLostPipWatchGenerationBySlot.TryGetValue(slotNumber, out var current)
            ? current + 1
            : 1;
        _autoAdvanceLostPipWatchGenerationBySlot[slotNumber] = generation;
        _autoAdvanceLostPipWatchStartedUtcBySlot.Remove(slotNumber);
        AppLogger.Info($"auto-advance-loss-watch-generation-cancelled: slot={slotNumber}; generation={generation}; reason={reason}");
    }

    private static bool MatchesAutoAdvanceLostPipIdentity(VideoTabInfo tab, int tabId, string session, string stable)
    {
        if (tab.TabId != tabId)
            return false;

        if (!string.IsNullOrWhiteSpace(session)
            && string.Equals(tab.VideoSessionId, session, StringComparison.OrdinalIgnoreCase))
            return true;

        return !string.IsNullOrWhiteSpace(stable)
            && string.Equals(tab.StableVideoKey, stable, StringComparison.OrdinalIgnoreCase);
    }

    private async Task ObserveLostPipForAutoAdvanceAsync(
        int slotNumber,
        int tabId,
        string session,
        string stable,
        string lossReason,
        int generation)
    {
        var terminalConfirmations = 0;
        VideoTabInfo? lastExact = null;

        for (var attempt = 1; attempt <= AutoAdvanceLostPipMaxAttempts; attempt++)
        {
            await Task.Delay(AutoAdvanceLostPipPollMs);

            if (!_autoAdvanceOnVideoEndEnabled)
                return;

            if (!_autoAdvanceLostPipWatchGenerationBySlot.TryGetValue(slotNumber, out var activeGeneration)
                || activeGeneration != generation)
                return;

            var slot = Slots.FirstOrDefault(item => item.Number == slotNumber);
            if (slot is null)
                return;

            if (IsVideoNavigationInProgress(slotNumber, DateTime.UtcNow))
            {
                CancelAutoAdvanceLostPipWatch(slotNumber, "navigation-in-progress-during-watch");
                AppLogger.Info($"auto-advance-loss-watch-cancelled: slot={slotNumber}; tabId={tabId}; generation={generation}; reason=navigation-in-progress; attempt={attempt}");
                return;
            }

            if (slot.Window is not null && PipWindowService.IsUsable(slot.Window.Handle))
            {
                AppLogger.Info($"auto-advance-loss-watch-cancelled: slot={slotNumber}; tabId={tabId}; generation={generation}; reason=pip-recovered; attempt={attempt}");
                return;
            }

            var currentTabId = _slotPairedTabIds.TryGetValue(slotNumber, out var pairedTabId) ? pairedTabId : 0;
            var currentSession = _slotVideoPairs.TryGetValue(slotNumber, out var pair) ? pair : string.Empty;
            var currentStable = _slotStableVideoPairs.TryGetValue(slotNumber, out var stableKey) ? stableKey : string.Empty;
            var sessionChanged = !string.IsNullOrWhiteSpace(session)
                && !string.Equals(currentSession, session, StringComparison.OrdinalIgnoreCase);
            var stableChanged = !string.IsNullOrWhiteSpace(stable)
                && !string.IsNullOrWhiteSpace(currentStable)
                && !string.Equals(currentStable, stable, StringComparison.OrdinalIgnoreCase);

            // StableVideoKey inclui sinais visuais como tamanho. O Firefox pode mudar a
            // dimensão do mesmo elemento durante o fechamento do PiP; com a mesma sessão,
            // isso não representa troca real e não deve cancelar o detector terminal.
            var strongStableChange = stableChanged && string.IsNullOrWhiteSpace(session);
            if (currentTabId != tabId || sessionChanged || strongStableChange)
            {
                AppLogger.Info($"auto-advance-loss-watch-cancelled: slot={slotNumber}; tabId={tabId}; generation={generation}; reason=pair-changed; attempt={attempt}; currentTabId={currentTabId}; currentSession={currentSession}; currentStable={currentStable}");
                return;
            }

            if (attempt <= 4 || attempt % 3 == 0)
            {
                try { await _extensionBridge.RequestVideoSessionsSnapshotAsync(); }
                catch (Exception ex) { AppLogger.Info($"auto-advance-loss-watch-snapshot-failed: slot={slotNumber}; attempt={attempt}; error={ex.GetType().Name}"); }
                await Task.Delay(90);
            }

            var nowUnixMs = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
            var sameTab = _videoTabCache.Values
                .Select(value => value.Tab)
                .Where(tab => tab.TabId == tabId && !IsLikelyAdvertisementVideo(tab, out _))
                .ToList();

            var exact = sameTab.FirstOrDefault(tab => MatchesAutoAdvanceLostPipIdentity(tab, tabId, session, stable));
            if (exact is not null)
                lastExact = exact;

            var replacementPlaying = sameTab.Any(tab =>
                !MatchesAutoAdvanceLostPipIdentity(tab, tabId, session, stable)
                && tab.IsPlaying
                && tab.LastSeenUnixMs > 0
                && nowUnixMs - tab.LastSeenUnixMs <= 5000);

            if (replacementPlaying)
            {
                AppLogger.Info($"auto-advance-loss-watch-cancelled: slot={slotNumber}; tabId={tabId}; generation={generation}; reason=site-already-advanced; attempt={attempt}");
                return;
            }

            var signalAgeMs = exact?.LastSeenUnixMs > 0
                ? Math.Max(0, nowUnixMs - exact.LastSeenUnixMs)
                : long.MaxValue;
            var missing = exact is null;
            var stale = exact is not null && signalAgeMs >= AutoAdvanceLostPipStaleSignalMs;
            var directTerminal = exact is not null && IsDirectTerminalVideoSnapshot(exact);

            if (!directTerminal)
            {
                terminalConfirmations = 0;
                if (attempt == 1 || attempt % 4 == 0)
                    AppLogger.Info($"auto-advance-loss-watch-waiting: slot={slotNumber}; tabId={tabId}; generation={generation}; attempt={attempt}; reason=terminal-not-proven; missing={missing}; stale={stale}; signalAgeMs={(signalAgeMs == long.MaxValue ? -1 : signalAgeMs)}; playing={exact?.IsPlaying ?? false}; readyState={exact?.ReadyState ?? 0}; paused={exact?.IsPaused ?? true}; ended={exact?.IsEnded ?? false}; hasSource={exact?.HasSource ?? false}; currentTime={(exact?.CurrentTime ?? 0):0.###}");
                continue;
            }

            terminalConfirmations++;
            AppLogger.Warn($"auto-advance-loss-watch-candidate: slot={slotNumber}; tabId={tabId}; generation={generation}; attempt={attempt}; missing={missing}; stale={stale}; directTerminal={directTerminal}; signalAgeMs={(signalAgeMs == long.MaxValue ? -1 : signalAgeMs)}; confirmations={terminalConfirmations}/{AutoAdvanceLostPipRequiredConfirmations}; lossReason={lossReason}");

            var minimumAttempt = AutoAdvanceLostPipDirectTerminalMinimumAttempt;
            if (attempt < minimumAttempt || terminalConfirmations < AutoAdvanceLostPipRequiredConfirmations)
                continue;

            var source = exact ?? lastExact;
            var terminal = new VideoPlaybackTerminalInfo
            {
                Reason = missing ? "pip-lost-session-missing" : "pip-lost-session-stale",
                VideoSessionId = session,
                StableVideoKey = stable,
                TabId = tabId,
                FrameId = source?.FrameId ?? 0,
                VideoIndex = source?.VideoIndex ?? 0,
                PageInstanceId = source?.PageInstanceId ?? string.Empty,
                ElementInstanceId = source?.ElementInstanceId ?? string.Empty,
                Title = source?.Title ?? string.Empty,
                Url = source?.Url ?? (_slotPairUrls.TryGetValue(slotNumber, out var savedUrl) ? savedUrl : string.Empty),
                Domain = source?.Domain ?? (_slotPairDomains.TryGetValue(slotNumber, out var savedDomain) ? savedDomain : string.Empty),
                CurrentTime = source?.CurrentTime ?? 0,
                Duration = source?.Duration ?? 0,
                ReadyState = source?.ReadyState ?? 0,
                IsPaused = source?.IsPaused ?? true,
                IsEnded = source?.IsEnded ?? false,
                HasSource = source?.HasSource ?? false,
                EventUnixMs = nowUnixMs
            };

            AppLogger.Warn($"auto-advance-loss-watch-terminal-confirmed: slot={slotNumber}; tabId={tabId}; generation={generation}; reason={terminal.Reason}; signalAgeMs={(signalAgeMs == long.MaxValue ? -1 : signalAgeMs)}; action=next");
            await HandlePlaybackTerminalAsync(terminal);
            return;
        }

        AppLogger.Info($"auto-advance-loss-watch-expired: slot={slotNumber}; tabId={tabId}; generation={generation}; attempts={AutoAdvanceLostPipMaxAttempts}; action=none");
    }

    private PipSlot? FindSlotForPlaybackTerminal(VideoPlaybackTerminalInfo info)
    {
        var exactSession = Slots
            .Where(slot => _slotVideoPairs.TryGetValue(slot.Number, out var pair)
                && !string.IsNullOrWhiteSpace(info.VideoSessionId)
                && string.Equals(pair, info.VideoSessionId, StringComparison.OrdinalIgnoreCase))
            .ToList();

        if (exactSession.Count == 1)
            return exactSession[0];

        if (exactSession.Count > 1)
        {
            AppLogger.Warn($"auto-advance-terminal-ambiguous-session: tabId={info.TabId}; session={info.VideoSessionId}; slots={string.Join(",", exactSession.Select(slot => slot.Number))}");
            return null;
        }

        var exactStableAndTab = Slots
            .Where(slot => _slotStableVideoPairs.TryGetValue(slot.Number, out var stable)
                && _slotPairedTabIds.TryGetValue(slot.Number, out var tabId)
                && tabId == info.TabId
                && !string.IsNullOrWhiteSpace(info.StableVideoKey)
                && string.Equals(stable, info.StableVideoKey, StringComparison.OrdinalIgnoreCase))
            .ToList();

        if (exactStableAndTab.Count == 1)
            return exactStableAndTab[0];

        if (exactStableAndTab.Count > 1)
            AppLogger.Warn($"auto-advance-terminal-ambiguous-stable: tabId={info.TabId}; stable={info.StableVideoKey}; slots={string.Join(",", exactStableAndTab.Select(slot => slot.Number))}");

        return null;
    }

    private void EnsureAutoReturnEnabledForTerminalSlot(PipSlot slot)
    {
        if (IsAutoReturnEnabledForSlot(slot.Number))
            return;

        _slotAutoReturnDiscreteBySlot[slot.Number] = true;
        _settings.AutoReturnDiscreteBySlot[slot.Number] = true;
        _autoReturnPolicy = AutoReturnPolicy.Discrete;
        _settings.AutoReturnPolicy = _autoReturnPolicy.ToString();
        slot.IsAutoReturnEnabled = true;

        var editable = EditableSlots.FirstOrDefault(item => item.Number == slot.Number);
        if (editable is not null)
            editable.IsAutoReturnEnabled = true;

        UpdateAutoReturnPolicyVisual();
        SaveSettings();
        AppLogger.Warn($"auto-advance-terminal-autoreturn-enabled: slot={slot.Number}; reason=required-to-preserve-pip");
    }

    private string PreemptAutoReturnForTerminalAdvance(PipSlot slot, VideoPlaybackTerminalInfo info)
    {
        var expectedProcess = slot.Window?.ProcessName ?? string.Empty;
        if (_autoReturnStatesBySlot.TryGetValue(slot.Number, out var existing))
        {
            if (!string.IsNullOrWhiteSpace(existing.ExpectedBrowserProcess))
                expectedProcess = existing.ExpectedBrowserProcess;
            _autoReturnStatesBySlot.Remove(slot.Number);
        }

        _autoReturnCooldownUntilBySlot.Remove(slot.Number);
        _autoReturnCancellationGenerationBySlot[slot.Number] = GetAutoReturnCancellationGeneration(slot.Number) + 1;

        if (_armedPipTargetSlotNumber == slot.Number)
        {
            _armedPipTargetSlotNumber = 0;
            _armedPipPairTab = null;
            _armedPipPairStartedUtc = DateTime.MinValue;
            _armedPipPairUntilUtc = DateTime.MinValue;
            _armedPipCandidateWindow = null;
            _armedPipCandidateDetectedUtc = DateTime.MinValue;
            _armedPipPairTimer.Stop();
        }

        AppLogger.Warn($"auto-advance-terminal-preempted-old-autoreturn: slot={slot.Number}; tabId={info.TabId}; expectedProcess={expectedProcess}; cancellationGeneration={GetAutoReturnCancellationGeneration(slot.Number)}");
        return expectedProcess;
    }

    private void ArmFastAutoReturnAfterTerminalAdvance(PipSlot slot, VideoPlaybackTerminalInfo info, string expectedProcess)
    {
        if (!IsAutoReturnEnabledForSlot(slot.Number))
            return;

        var baselineSource = "terminal-event";
        var baselineSession = info.VideoSessionId;
        var baselineStable = info.StableVideoKey;
        var baselineUrl = info.Url;
        if (_videoSwitchPreservationBySlot.TryGetValue(slot.Number, out var preservation)
            && IsVideoSwitchPreservationStateAlive(preservation))
        {
            if (!string.IsNullOrWhiteSpace(preservation.OldSession)) baselineSession = preservation.OldSession;
            if (!string.IsNullOrWhiteSpace(preservation.OldStable)) baselineStable = preservation.OldStable;
            if (!string.IsNullOrWhiteSpace(preservation.OldUrl)) baselineUrl = preservation.OldUrl;
            baselineSource = "preservation-before-next";
        }

        var queuePosition = _autoReturnStatesBySlot.ContainsKey(slot.Number)
            ? Math.Max(1, _autoReturnStatesBySlot.Count)
            : _autoReturnStatesBySlot.Count + 1;
        var maxPendingAgeSeconds = AutoReturnBurstPolicy.GetPendingMaxAgeSeconds(
            queuePosition,
            AutoReturnMaxAgeSeconds);
        var terminalNavigationGeneration = _terminalAutoNextGenerationBySlot.TryGetValue(slot.Number, out var currentTerminalGeneration)
            ? currentTerminalGeneration + 1
            : 1;
        _terminalAutoNextGenerationBySlot[slot.Number] = terminalNavigationGeneration;
        _autoReturnStatesBySlot[slot.Number] = new AutoReturnSlotState
        {
            SlotNumber = slot.Number,
            TabId = info.TabId,
            OldSession = baselineSession,
            OldStable = baselineStable,
            OldUrl = baselineUrl,
            ExpectedBrowserProcess = expectedProcess,
            PendingSinceUtc = DateTime.UtcNow,
            MaxPendingAgeSeconds = maxPendingAgeSeconds,
            Reason = "terminal-auto-next",
            RequiresRealVideoChange = true,
            EligibilityMode = "terminal-auto-next-real-change",
            CancellationGeneration = GetAutoReturnCancellationGeneration(slot.Number),
            BlockSameVideoFallback = true,
            NavigationReason = "terminal-auto-next",
            TerminalNavigationGeneration = terminalNavigationGeneration
        };

        AppLogger.Warn($"auto-return-terminal-fast-armed: slot={slot.Number}; tabId={info.TabId}; queuePosition={queuePosition}; maxPendingAgeSeconds={maxPendingAgeSeconds}; oldSession={baselineSession}; oldStable={baselineStable}; oldUrl={baselineUrl}; baselineSource={baselineSource}; expectedProcess={expectedProcess}; terminalNavigationGeneration={terminalNavigationGeneration}; stabilizeMs={AutoReturnTerminalAdvanceStabilizeMs}");
        _ = TriggerFastAutoReturnAfterTerminalAdvanceAsync(slot.Number, GetAutoReturnCancellationGeneration(slot.Number));
    }

    private async Task TriggerFastAutoReturnAfterTerminalAdvanceAsync(int slotNumber, int cancellationGeneration)
    {
        for (var attempt = 1; attempt <= 12; attempt++)
        {
            await Task.Delay(attempt == 1 ? 120 : 150);

            if (GetAutoReturnCancellationGeneration(slotNumber) != cancellationGeneration)
                return;

            var slot = Slots.FirstOrDefault(item => item.Number == slotNumber);
            if (slot is null || (slot.Window is not null && PipWindowService.IsUsable(slot.Window.Handle)))
                return;

            if (!_autoReturnStatesBySlot.TryGetValue(slotNumber, out var state)
                || !string.Equals(state.EligibilityMode, "terminal-auto-next-real-change", StringComparison.OrdinalIgnoreCase))
                return;

            if (attempt == 1 || attempt == 3 || attempt == 6)
            {
                try { await _extensionBridge.RequestVideoSessionsSnapshotAsync(); }
                catch { }
                await Task.Delay(70);
                ApplyVideoTabsFromCache(force: true);
            }

            await AutoReturnTickAsync();
            if (state.InProgress)
                return;
        }
    }

    private void QueueFastAutoReturnTickFromSnapshot()
    {
        if (_autoReturnFastTickQueued
            || !_autoReturnStatesBySlot.Values.Any(state => state.RequiresRealVideoChange && !state.InProgress))
            return;

        _autoReturnFastTickQueued = true;
        Dispatcher.BeginInvoke(new Action(async () =>
        {
            try
            {
                await Task.Delay(35);
                await AutoReturnTickAsync();
            }
            finally
            {
                _autoReturnFastTickQueued = false;
            }
        }), DispatcherPriority.Background);
    }

    private async Task HandlePlaybackTerminalAsync(VideoPlaybackTerminalInfo info)
    {
        if (!_autoAdvanceOnVideoEndEnabled)
        {
            AppLogger.Info($"auto-advance-terminal-skipped: reason=feature-disabled; tabId={info.TabId}; session={info.VideoSessionId}; terminalReason={info.Reason}");
            return;
        }

        if (info.TabId <= 0 || (string.IsNullOrWhiteSpace(info.VideoSessionId) && string.IsNullOrWhiteSpace(info.StableVideoKey)))
        {
            AppLogger.Warn($"auto-advance-terminal-skipped: reason=missing-identity; tabId={info.TabId}; session={info.VideoSessionId}; stable={info.StableVideoKey}; terminalReason={info.Reason}");
            return;
        }

        var slot = FindSlotForPlaybackTerminal(info);
        if (slot is null)
        {
            AppLogger.Info($"auto-advance-terminal-skipped: reason=no-exact-linked-slot; tabId={info.TabId}; session={info.VideoSessionId}; stable={info.StableVideoKey}; terminalReason={info.Reason}");
            return;
        }

        if (!AutoAdvanceSafetyPolicy.ShouldAcceptPlaybackTerminal(IsVideoNavigationInProgress(slot.Number, DateTime.UtcNow)))
        {
            AppLogger.Info($"auto-advance-terminal-skipped: reason=navigation-in-progress; slot={slot.Number}; tabId={info.TabId}; terminalReason={info.Reason}; ended={info.IsEnded}; readyState={info.ReadyState}; hasSource={info.HasSource}");
            return;
        }

        var now = DateTime.UtcNow;
        if (_autoAdvanceTerminalCooldownUntilBySlot.TryGetValue(slot.Number, out var cooldownUntil) && now < cooldownUntil)
        {
            AppLogger.Info($"auto-advance-terminal-skipped: reason=cooldown; slot={slot.Number}; tabId={info.TabId}; remainingMs={(cooldownUntil - now).TotalMilliseconds:0}; terminalReason={info.Reason}");
            return;
        }

        await _autoAdvanceTerminalGate.WaitAsync();
        try
        {
            slot = FindSlotForPlaybackTerminal(info);
            if (slot is null)
                return;

            if (!AutoAdvanceSafetyPolicy.ShouldAcceptPlaybackTerminal(IsVideoNavigationInProgress(slot.Number, DateTime.UtcNow)))
            {
                AppLogger.Info($"auto-advance-terminal-skipped: reason=navigation-in-progress-after-gate; slot={slot.Number}; tabId={info.TabId}; terminalReason={info.Reason}");
                return;
            }

            var expectedProcess = PreemptAutoReturnForTerminalAdvance(slot, info);
            now = DateTime.UtcNow;
            if (_autoAdvanceTerminalCooldownUntilBySlot.TryGetValue(slot.Number, out cooldownUntil) && now < cooldownUntil)
                return;

            var terminalBusyWaitStartedUtc = DateTime.UtcNow;
            var terminalBusyDeadlineUtc = terminalBusyWaitStartedUtc.AddMilliseconds(AutoAdvanceTerminalBusyWaitMaxMs);
            if (IsPipOperationBusy())
            {
                AppLogger.Info($"auto-advance-terminal-waiting: slot={slot.Number}; tabId={info.TabId}; mode=signal; maxWaitMs={AutoAdvanceTerminalBusyWaitMaxMs}; videoCommandBusy={_videoCommandBusy}; openAttempt={_openPipAttemptInProgress}; openAttemptSlot={_openPipAttemptSlotNumber}; openAll={_openAllPipsInProgress}; elapsedMs=0");
            }

            while (IsPipOperationBusy() && DateTime.UtcNow < terminalBusyDeadlineUtc)
            {
                ReleaseExpiredOpenPipAttemptLock();
                if (!IsPipOperationBusy())
                    break;

                var remainingMs = Math.Max(25, (int)(terminalBusyDeadlineUtc - DateTime.UtcNow).TotalMilliseconds);
                await WaitForPipOperationAvailabilityAsync(Math.Min(AutoAdvanceTerminalSignalFallbackMs, remainingMs));
            }

            var terminalBusyWaitElapsedMs = (DateTime.UtcNow - terminalBusyWaitStartedUtc).TotalMilliseconds;
            if (IsPipOperationBusy())
            {
                AppLogger.Warn($"auto-advance-terminal-skipped: reason=busy-timeout; slot={slot.Number}; tabId={info.TabId}; terminalReason={info.Reason}; waitedMs={terminalBusyWaitElapsedMs:0}; waitMode=signal; videoCommandBusy={_videoCommandBusy}; openAttempt={_openPipAttemptInProgress}; openAttemptSlot={_openPipAttemptSlotNumber}; openAll={_openAllPipsInProgress}");
                return;
            }

            if (terminalBusyWaitElapsedMs >= 25)
                AppLogger.Info($"auto-advance-terminal-handoff-ready: slot={slot.Number}; tabId={info.TabId}; waitedMs={terminalBusyWaitElapsedMs:0}; waitMode=signal; oldAutoReturnReleased=True");

            if (!_extensionBridge.IsConnected)
            {
                AppLogger.Warn($"auto-advance-terminal-skipped: reason=extension-disconnected; slot={slot.Number}; tabId={info.TabId}; terminalReason={info.Reason}");
                return;
            }

            _autoAdvanceTerminalCooldownUntilBySlot[slot.Number] = now.AddSeconds(AutoAdvanceTerminalCooldownSeconds);
            EnsureAutoReturnEnabledForTerminalSlot(slot);
            var selectedLabel = $"PiP {slot.Number} — término automático";
            ArmVideoSwitchPreservationIfPossible(
                slot,
                info.PairKey,
                info.VideoSessionId,
                info.StableVideoKey,
                info.TabId,
                VideoCommandKind.Next,
                selectedLabel);

            _videoCommandBusy = true;
            try
            {
                AppLogger.Warn($"auto-advance-terminal-start: slot={slot.Number}; tabId={info.TabId}; frameId={info.FrameId}; reason={info.Reason}; session={info.VideoSessionId}; stable={info.StableVideoKey}; ended={info.IsEnded}; paused={info.IsPaused}; readyState={info.ReadyState}; hasSource={info.HasSource}");
                var clients = await _extensionBridge.SendVideoCommandAsync(
                    VideoCommandKind.Next,
                    info.VideoSessionId,
                    info.StableVideoKey,
                    info.TabId,
                    allowNoVideoTarget: true);

                ObserveVideoSwitchPreservationStates("auto-advance-terminal/after-next");
                if (clients > 0)
                    ArmFastAutoReturnAfterTerminalAdvance(slot, info, expectedProcess);
                AppLogger.Warn($"auto-advance-terminal-result: result={(clients > 0 ? "SENT" : "NO-CLIENT")}; slot={slot.Number}; tabId={info.TabId}; clients={clients}; reason={info.Reason}; autoReturnSlotEnabled={slot.IsAutoReturnEnabled}; cooldownSeconds={AutoAdvanceTerminalCooldownSeconds}");
                SetStatus(clients > 0
                    ? $"PiP {slot.Number}: vídeo terminou; Próximo enviado automaticamente"
                    : $"PiP {slot.Number}: vídeo terminou, mas a extensão não respondeu");
            }
            finally
            {
                _videoCommandBusy = false;
            SignalPipOperationAvailability("video-command-finished");
            }
        }
        catch (Exception ex)
        {
            AppLogger.Error($"auto-advance-terminal-failed: tabId={info.TabId}; session={info.VideoSessionId}; reason={info.Reason}", ex);
        }
        finally
        {
            _autoAdvanceTerminalGate.Release();
        }
    }

    private void UpdateSelectedPipNotice()
    {
        if (SelectedPipText is null) return;
        SelectedPipText.Text = $"Selecionado: {GetSelectedPipLabel()}";
    }


    private static string BuildAutomationVideoTabsSignature(IReadOnlyList<VideoTabInfo> tabs)
    {
        if (tabs.Count == 0)
            return "empty";

        return string.Join("|", tabs
            .OrderBy(tab => tab.TabId)
            .ThenBy(tab => tab.FrameId)
            .ThenBy(tab => tab.Domain)
            .Select(tab => $"{tab.BrowserWindowId}:{tab.TabId}:{tab.FrameId}:{tab.Domain}:{tab.PairKey}:{tab.StableVideoKey}:{tab.VideoSessionId}:{tab.IsPlaying}:{tab.IsActiveTab}"));
    }

    private void ObserveAutomationVideoTabsUpdatedIfChanged(IReadOnlyList<VideoTabInfo> tabs)
    {
        var now = DateTime.UtcNow;
        var signature = BuildAutomationVideoTabsSignature(tabs);
        var changed = !string.Equals(signature, _lastAutomationVideoTabsSignature, StringComparison.OrdinalIgnoreCase);
        var elapsedMs = (now - _lastAutomationVideoTabsObservedUtc).TotalMilliseconds;

        if (!changed && elapsedMs < AutomationVideoTabsSnapshotThrottleMs)
            return;

        _lastAutomationVideoTabsSignature = signature;
        _lastAutomationVideoTabsObservedUtc = now;

        AppLogger.InfoAggregated(
            "automation-video-tabs-observed",
            TimeSpan.FromMilliseconds(changed ? AutomationVideoTabsChangedLogAggregateMs : AutomationVideoTabsSnapshotThrottleMs),
            $"automation-video-tabs-observed: changed={changed}; elapsedMs={elapsedMs:0}; tabCount={tabs.Count}; structuralSignature=True; heartbeat={!changed}");
        _automationCoordinator.ObserveVideoTabsUpdated(tabs.Count);
    }

    private static readonly string[] AdvertisementDomainSuffixes =
    [
        "aphroxa.com",
        "trendbuzz.to",
        "ads.quality-traffic.com",
        "syndicate.contentsserved.com",
        "creative.cambaddies.com",
        "creative.prncams.com",
        "doubleclick.net",
        "googlesyndication.com",
        "adnxs.com",
        "adsrvr.org",
        "criteo.com",
        "taboola.com",
        "outbrain.com"
    ];

    private static readonly string[] AdvertisementTitleMarkers =
    [
        "outstream ad",
        "ad content",
        "video advertisement",
        "video ad",
        "sponsored video",
        "instream ad",
        "pre-roll ad",
        "preroll ad",
        "mobile slider"
    ];

    private static bool IsLikelyAdvertisementVideo(VideoTabInfo tab, out string reason)
    {
        reason = string.Empty;
        if (tab is null) return false;

        var title = (tab.Title ?? string.Empty).Trim().ToLowerInvariant();
        var domain = (tab.Domain ?? string.Empty).Trim().TrimStart('.').ToLowerInvariant();
        var url = (tab.Url ?? string.Empty).Trim().ToLowerInvariant();

        var titleMarker = AdvertisementTitleMarkers.FirstOrDefault(marker => title.Contains(marker, StringComparison.Ordinal));
        if (!string.IsNullOrWhiteSpace(titleMarker))
        {
            reason = $"title:{titleMarker}";
            return true;
        }

        var domainMarker = AdvertisementDomainSuffixes.FirstOrDefault(suffix =>
            string.Equals(domain, suffix, StringComparison.OrdinalIgnoreCase)
            || domain.EndsWith($".{suffix}", StringComparison.OrdinalIgnoreCase));
        if (!string.IsNullOrWhiteSpace(domainMarker))
        {
            reason = $"domain:{domainMarker}";
            return true;
        }

        var routeMarkers = new[]
        {
            "trafficType=banner",
            "campaignId=",
            "creativeId=",
            "smartpopId=",
            "bannerIframe",
            "/outstream",
            "/vast/",
            "/prebid/",
            "/ads/"
        };

        var routeMarker = routeMarkers.FirstOrDefault(marker => url.Contains(marker, StringComparison.OrdinalIgnoreCase));
        if (!string.IsNullOrWhiteSpace(routeMarker))
        {
            reason = $"url:{routeMarker}";
            return true;
        }

        return false;
    }

    private void MergeTabDiscoverySnapshot(string correlationId, IReadOnlyList<TabDiscoveryInfo> tabs)
    {
        var observedUtc = DateTime.UtcNow;
        _extensionTabDiscoverySnapshotUtc = observedUtc;
        _extensionTabDiscoverySnapshotGeneration++;
        _extensionTabDiscoveryCorrelationId = correlationId ?? string.Empty;
        _extensionTabDiscoveryByTabId.Clear();

        foreach (var tab in tabs.Where(item => item.TabId > 0))
            _extensionTabDiscoveryByTabId[tab.TabId] = (tab, observedUtc);
    }

    private bool TryGetFreshNoVideoTabAuthority(
        int tabId,
        DateTime snapshotRequestedUtc,
        out TabDiscoveryInfo discovery)
    {
        discovery = null!;
        if (tabId <= 0 || _extensionTabDiscoverySnapshotUtc < snapshotRequestedUtc)
            return false;

        if (!_extensionTabDiscoveryByTabId.TryGetValue(tabId, out var observed)
            || observed.ObservedUtc < snapshotRequestedUtc
            || !observed.Info.IsExactNoVideo)
        {
            return false;
        }

        discovery = observed.Info;
        return true;
    }

    private async Task<(bool ResponseReceived, bool CanProceed, bool ExactNoVideo, VideoTabInfo Tab, TabDiscoveryInfo? Discovery, long Generation)> RequestCorrelatedAutoReturnSnapshotAsync(
        VideoTabInfo tab,
        string attemptId,
        int slotNumber,
        string checkpoint,
        int timeoutMs = 700)
    {
        var generationBefore = _extensionTabDiscoverySnapshotGeneration;
        var requestedUtc = DateTime.UtcNow;
        var correlationId = $"{attemptId}:{checkpoint}:{Guid.NewGuid():N}";
        var clients = 0;

        try
        {
            AppLogger.Info($"auto-return-fresh-snapshot-start: attemptId={attemptId}; slot={slotNumber}; tabId={tab.TabId}; phase={checkpoint}; correlationId={correlationId}; generationBefore={generationBefore}; timeoutMs={timeoutMs}");
            clients = await _extensionBridge.RequestVideoSessionsSnapshotAsync(force: true, correlationId: correlationId);
        }
        catch (Exception ex)
        {
            AppLogger.Warn($"auto-return-fresh-snapshot-failed: attemptId={attemptId}; slot={slotNumber}; tabId={tab.TabId}; phase={checkpoint}; generationBefore={generationBefore}; reason={ex.Message}");
            return (false, false, false, tab, null, generationBefore);
        }

        if (clients <= 0)
        {
            AppLogger.Warn($"auto-return-fresh-snapshot-no-clients: attemptId={attemptId}; slot={slotNumber}; tabId={tab.TabId}; phase={checkpoint}; generationBefore={generationBefore}; action=fail-safe-defer");
            return (false, false, false, tab, null, generationBefore);
        }

        var deadlineUtc = DateTime.UtcNow.AddMilliseconds(Math.Max(100, timeoutMs));
        while (DateTime.UtcNow < deadlineUtc)
        {
            await Dispatcher.Yield(DispatcherPriority.Background);

            var generationAfter = _extensionTabDiscoverySnapshotGeneration;
            if (generationAfter > generationBefore
                && _extensionTabDiscoverySnapshotUtc >= requestedUtc
                && string.Equals(_extensionTabDiscoveryCorrelationId, correlationId, StringComparison.Ordinal))
            {
                ApplyVideoTabsFromCache(force: true);
                var refreshed = ResolveFreshAutoReturnTabSnapshot(tab);

                if (!_extensionTabDiscoveryByTabId.TryGetValue(tab.TabId, out var observed)
                    || observed.ObservedUtc < requestedUtc)
                {
                    AppLogger.Warn($"auto-return-fresh-snapshot-correlated-tab-missing: attemptId={attemptId}; slot={slotNumber}; tabId={tab.TabId}; phase={checkpoint}; correlationId={correlationId}; generationBefore={generationBefore}; generationAfter={generationAfter}; elapsedMs={(DateTime.UtcNow - requestedUtc).TotalMilliseconds:0}; action=fail-safe-defer");
                    return (true, false, false, refreshed, null, generationAfter);
                }

                var discovery = observed.Info;
                var exactNoVideo = discovery.IsExactNoVideo;
                var videoReady = string.Equals(discovery.Status, "video-ready", StringComparison.OrdinalIgnoreCase)
                    && (discovery.RawVideoCount > 0 || discovery.SessionCount > 0);

                AppLogger.Info($"auto-return-fresh-snapshot-correlated-response: attemptId={attemptId}; slot={slotNumber}; tabId={tab.TabId}; phase={checkpoint}; correlationId={correlationId}; generationBefore={generationBefore}; generationAfter={generationAfter}; elapsedMs={(DateTime.UtcNow - requestedUtc).TotalMilliseconds:0}; status={discovery.Status}; rawVideoCount={discovery.RawVideoCount}; sessionCount={discovery.SessionCount}; exactNoVideo={exactNoVideo}; canProceed={videoReady}");
                return (true, videoReady, exactNoVideo, refreshed, discovery, generationAfter);
            }

            await Task.Delay(25);
        }

        AppLogger.Warn($"auto-return-fresh-snapshot-timeout: attemptId={attemptId}; slot={slotNumber}; tabId={tab.TabId}; phase={checkpoint}; correlationId={correlationId}; observedCorrelationId={_extensionTabDiscoveryCorrelationId}; generationBefore={generationBefore}; generationAfter={_extensionTabDiscoverySnapshotGeneration}; timeoutMs={timeoutMs}; action=fail-safe-defer");
        return (false, false, false, tab, null, _extensionTabDiscoverySnapshotGeneration);
    }

    private bool ClearUnusableAutoReturnWindow(PipSlot slot, string attemptId, string source)
    {
        var staleWindow = slot.Window;
        if (staleWindow is null)
            return false;

        var usable = false;
        try { usable = PipWindowService.IsUsable(staleWindow.Handle); } catch { }
        if (usable)
            return false;

        slot.Window = null;
        _hiddenPipRects.Remove(staleWindow.Handle);
        _lockedGroupModelRects.Remove(staleWindow.Handle);
        RefreshSlotState(slot);
        AppLogger.Info($"auto-return-stale-hwnd-cleared: attemptId={attemptId}; slot={slot.Number}; hwnd=0x{staleWindow.Handle.ToInt64():X}; source={source}; pairPreserved={SlotHasPairRecoverySignal(slot.Number)}");
        return true;
    }

    private void MergeVideoTabsSnapshot(IReadOnlyList<VideoTabInfo> tabs)
    {
        var now = DateTime.UtcNow;
        var acceptedTabs = new List<VideoTabInfo>(tabs.Count);
        var filteredAds = new List<(VideoTabInfo Tab, string Reason)>();

        foreach (var tab in tabs)
        {
            if (IsLikelyAdvertisementVideo(tab, out var adReason))
            {
                filteredAds.Add((tab, adReason));
                var staleKey = GetVideoCacheKey(tab);
                if (!string.IsNullOrWhiteSpace(staleKey))
                    _videoTabCache.Remove(staleKey);
                continue;
            }

            acceptedTabs.Add(tab);
            var key = GetVideoCacheKey(tab);
            if (string.IsNullOrWhiteSpace(key)) continue;
            _videoTabCache[key] = (tab, now);
        }

        ObserveAutomationVideoTabsUpdatedIfChanged(acceptedTabs);

        if (filteredAds.Count > 0 && (now - _lastAdvertisementFilterLogUtc).TotalSeconds >= 8)
        {
            _lastAdvertisementFilterLogUtc = now;
            var sample = filteredAds[0];
            AppLogger.Warn(
                $"video-ad-isolation-filtered: count={filteredAds.Count}; " +
                $"sampleTabId={sample.Tab.TabId}; sampleDomain={sample.Tab.Domain}; " +
                $"sampleTitle={sample.Tab.Title}; reason={sample.Reason}");
        }

        _videoTabsDirty = true;
        QueueJogoIntrinsicAspectReflowIfNeeded("extension/intrinsic-video-aspect-update");
        QueueFastAutoReturnTickFromSnapshot();
    }

    private void ApplyVideoTabsFromCache(bool force = false)
    {
        if (!_videoTabsDirty && !force) return;
        if (VideoTabsCombo?.IsDropDownOpen == true && !force) return;

        var now = DateTime.UtcNow;
        foreach (var item in _videoTabCache.ToArray())
        {
            if ((now - item.Value.LastSeenUtc).TotalSeconds > VideoTabsCacheTtlSeconds
                || IsLikelyAdvertisementVideo(item.Value.Tab, out _))
            {
                _videoTabCache.Remove(item.Key);
            }
        }

        var selectedKey = VideoTabsCombo?.SelectedItem is VideoTabInfo selected
            ? GetVideoCacheKey(selected)
            : null;

        var newTabs = _videoTabCache.Values
            .Select(value => value.Tab)
            .OrderByDescending(tab => tab.IsPlaying)
            .ThenByDescending(tab => tab.IsActiveTab)
            .ThenBy(tab => tab.Domain)
            .ThenBy(tab => tab.TabId)
            .ThenBy(tab => tab.FrameId)
            .ThenBy(tab => tab.VisualRank)
            .ToList();

        foreach (var tab in newTabs)
            ApplyVideoTabPickerStatus(tab);

        VideoTabs.Clear();
        foreach (var tab in newTabs)
            VideoTabs.Add(tab);

        if (VideoTabsCombo is not null)
        {
            VideoTabsCombo.ItemsSource = VideoTabs;
            if (!string.IsNullOrWhiteSpace(selectedKey))
                VideoTabsCombo.SelectedItem = VideoTabs.FirstOrDefault(tab => string.Equals(GetVideoCacheKey(tab), selectedKey, StringComparison.OrdinalIgnoreCase));

            // Não seleciona automaticamente o primeiro item. Isso evita que snapshots rápidos de frames/iframes
            // troquem o vídeo escolhido enquanto o usuário está tentando vincular.
        }

        var validIds = VideoTabs.Select(tab => tab.PairKey).ToHashSet(StringComparer.OrdinalIgnoreCase);
        foreach (var pair in _slotVideoPairs.ToArray())
        {
            if (!validIds.Contains(pair.Value))
            {
                if (ShouldLogMissingPair(pair.Key))
                    AppLogger.Info($"Vínculo ainda não encontrado no cache visual atual: slot={pair.Key}, pairKey={pair.Value}. Mantendo para permitir reconexão por stableVideoKey.");
            }
            else
            {
                // Base limpa: sem dicionário experimental de throttle de log.
            }
        }

        RefreshAllSlotPairVisuals();
        _videoTabsDirty = false;
        UpdateSelectedPipNotice();
    }

    private void ApplyVideoTabPickerStatus(VideoTabInfo tab)
    {
        var existingSlot = FindExistingSlotForVideoTab(tab);
        tab.LinkedSlotNumber = existingSlot?.Number ?? 0;
        tab.IsPreparedForPip = IsArmedPreparedTab(tab);
        tab.PreparedSlotNumber = tab.IsPreparedForPip
            ? GetAwaitingPreparedSlotNumber(tab) ?? existingSlot?.Number ?? 0
            : 0;
    }

    private bool IsArmedPreparedTab(VideoTabInfo tab) =>
        _armedPipPairTab is not null && AreSameVideoChoice(_armedPipPairTab, tab);

    private int? GetAwaitingPreparedSlotNumber(VideoTabInfo tab)
    {
        var awaiting = Slots.OrderBy(slot => slot.Number).FirstOrDefault(slot => slot.State == PipSlotState.AwaitingPip);
        if (awaiting is not null) return awaiting.Number;

        var existing = FindExistingSlotForVideoTab(tab);
        if (existing is not null) return existing.Number;

        return SelectedSlot?.Number;
    }

    private static bool AreSameVideoChoice(VideoTabInfo left, VideoTabInfo right)
    {
        if (!string.IsNullOrWhiteSpace(left.PairKey) && string.Equals(left.PairKey, right.PairKey, StringComparison.OrdinalIgnoreCase))
            return true;
        if (!string.IsNullOrWhiteSpace(left.VideoSessionId) && string.Equals(left.VideoSessionId, right.VideoSessionId, StringComparison.OrdinalIgnoreCase))
            return true;
        if (!string.IsNullOrWhiteSpace(left.StableVideoKey) && string.Equals(left.StableVideoKey, right.StableVideoKey, StringComparison.OrdinalIgnoreCase)
            && (left.TabId == right.TabId || left.TabId <= 0 || right.TabId <= 0))
            return true;
        return left.TabId == right.TabId && left.VideoIndex == right.VideoIndex && left.TabId > 0;
    }

    private void RefreshVideoPickerVisualStates()
    {
        foreach (var tab in VideoTabs)
            ApplyVideoTabPickerStatus(tab);
        CollectionViewSource.GetDefaultView(VideoTabs)?.Refresh();
    }

    private async void VideoTabsCombo_DropDownOpened(object sender, EventArgs e)
    {
        // Enquanto o usuário escolhe uma sessão, congelamos a atualização visual da lista.
        // Os snapshots continuam entrando no cache e serão aplicados ao fechar o dropdown.
        if (_extensionBridge.IsConnected)
        {
            try
            {
                await _extensionBridge.RequestVideoSessionsSnapshotAsync();
            }
            catch { }
        }
    }

    private void VideoTabsCombo_DropDownClosed(object sender, EventArgs e)
    {
        ApplyVideoTabsFromCache(force: true);
        UpdatePairPreviewNotice();
    }

    private void VideoTabsCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        UpdatePairPreviewNotice();
    }

    private static string GetVideoCacheKey(VideoTabInfo tab)
    {
        if (!string.IsNullOrWhiteSpace(tab.VideoSessionId)) return tab.VideoSessionId;
        if (!string.IsNullOrWhiteSpace(tab.PageInstanceId) && !string.IsNullOrWhiteSpace(tab.ElementInstanceId))
            return $"{tab.PageInstanceId}:{tab.ElementInstanceId}";
        if (!string.IsNullOrWhiteSpace(tab.StableVideoKey)) return tab.StableVideoKey;
        return tab.PairKey;
    }

    private void PairSelectedPipButton_Click(object sender, RoutedEventArgs e)
    {
        if (SelectedSlot?.Window is null)
        {
            SetStatus("Selecione um PiP ocupado antes de vincular");
            UpdatePairPreviewNotice();
            return;
        }

        if (VideoTabsCombo?.SelectedItem is not VideoTabInfo tab)
        {
            SetStatus("Nenhuma aba com vídeo detectada pela extensão");
            UpdatePairPreviewNotice();
            return;
        }

        if (!ConfirmManualPairChange(SelectedSlot.Number, tab))
        {
            SetStatus("Vinculação cancelada para evitar vínculo errado ou duplicado");
            UpdatePairPreviewNotice();
            return;
        }

        var previousText = GetPairTextForSlot(SelectedSlot.Number);
        StoreSlotPair(SelectedSlot.Number, tab);
        RefreshVideoPickerVisualStates();
        UpdateSelectedPipNotice();
        UpdatePairPreviewNotice();
        SetStatus($"Confirmado: PiP {SelectedSlot.Number} → aba {tab.TabId}, vídeo {tab.VideoIndex + 1}, {tab.ShortDescription}");
        AppLogger.Info($"Vínculo criado: slot={SelectedSlot.Number}, anterior={previousText}, videoSessionId={tab.PairKey}, stable={tab.StableVideoKey}, tabId={tab.TabId}, videoIndex={tab.VideoIndex}, title={tab.Title}, url={tab.Url}");
    }


    private bool ConfirmManualPairChange(int targetSlotNumber, VideoTabInfo tab)
    {
        var messages = new List<string>();

        var existingSlot = FindExistingSlotForVideoTab(tab);
        if (existingSlot is not null && existingSlot.Number != targetSlotNumber)
        {
            messages.Add($"Esse vídeo/aba já está vinculado ao PiP {existingSlot.Number}.");
            messages.Add($"Ao confirmar, o vínculo será removido do PiP {existingSlot.Number} e ficará no PiP {targetSlotNumber}.");
        }

        var currentPair = GetPairTextForSlot(targetSlotNumber);
        if (!string.IsNullOrWhiteSpace(currentPair))
        {
            messages.Add($"O PiP {targetSlotNumber} já tem vínculo atual: {currentPair}.");
            messages.Add("Ao confirmar, esse vínculo será substituído.");
        }

        if (messages.Count == 0)
            return true;

        messages.Add(string.Empty);
        messages.Add($"Novo vínculo: PiP {targetSlotNumber} → aba {tab.TabId}, vídeo {tab.VideoIndex + 1}, {tab.ShortDescription}");
        messages.Add(string.Empty);
        messages.Add("Continuar?");

        var result = MessageBox.Show(
            string.Join(Environment.NewLine, messages),
            "Confirmar vínculo do PiP",
            MessageBoxButton.YesNo,
            MessageBoxImage.Warning);

        return result == MessageBoxResult.Yes;
    }

    private void UpdatePairPreviewNotice()
    {
        if (PairPreviewText is null) return;

        if (SelectedSlot is null)
        {
            PairPreviewText.Text = "Vínculo: selecione um PiP antes de vincular";
            return;
        }

        if (VideoTabsCombo?.SelectedItem is not VideoTabInfo tab)
        {
            var current = GetPairTextForSlot(SelectedSlot.Number);
            PairPreviewText.Text = string.IsNullOrWhiteSpace(current)
                ? $"Vínculo: PiP {SelectedSlot.Number} selecionado; escolha uma aba/vídeo"
                : $"Vínculo atual: PiP {SelectedSlot.Number} → {current}";
            return;
        }

        var existingSlot = FindExistingSlotForVideoTab(tab);
        var conflict = existingSlot is not null && existingSlot.Number != SelectedSlot.Number
            ? $"  ⚠ já está no PiP {existingSlot.Number}"
            : string.Empty;

        var currentPair = GetPairTextForSlot(SelectedSlot.Number);
        var replacing = !string.IsNullOrWhiteSpace(currentPair)
            ? $"  | atual: {currentPair}"
            : string.Empty;

        PairPreviewText.Text = $"Vai vincular: PiP {SelectedSlot.Number} → aba {tab.TabId}, vídeo {tab.VideoIndex + 1}, {tab.ShortDescription}{conflict}{replacing}";
    }

    private bool HasActiveNextNavigationOperation()
    {
        var now = DateTime.UtcNow;
        if (_videoCommandBusy) return true;
        if (_videoSwitchPreservationBySlot.Values.Any(state =>
                string.Equals(state.CommandType, "next", StringComparison.OrdinalIgnoreCase)
                && state.ExpiresUtc > now))
            return true;
        return _autoReturnStatesBySlot.Values.Any(state => state.BlockSameVideoFallback);
    }

    private async Task PreemptOpenAllForNextNavigationAsync(PipSlot? slot, VideoTabInfo? commandTarget)
    {
        var cts = _openAllCancellationCts;
        if (!_openAllPipsInProgress || cts is null) return;

        if (!cts.IsCancellationRequested)
        {
            try { cts.Cancel(); } catch (ObjectDisposedException) { return; }
            AppLogger.Warn($"open-all-cancel-requested-by-next: slot={slot?.Number ?? 0}; commandTargetAssetId={commandTarget?.NextAssetId}; generation={commandTarget?.NextTargetGeneration ?? 0}; operationId={commandTarget?.NextTargetOperationId}; action=yield-physical-authority");
        }

        var startedUtc = DateTime.UtcNow;
        while (_openAllPipsInProgress && (DateTime.UtcNow - startedUtc).TotalMilliseconds < 1200)
            await Task.Delay(40);

        AppLogger.Info($"next-navigation-open-all-preemption-result: slot={slot?.Number ?? 0}; openAllStillActive={_openAllPipsInProgress}; waitedMs={(DateTime.UtcNow - startedUtc).TotalMilliseconds:0}; action={( _openAllPipsInProgress ? "continue-navigation-open-all-draining" : "navigation-has-priority" )}");
    }

    private void ThrowIfOpenAllMustYield(System.Threading.CancellationToken token, string checkpoint)
    {
        if (!token.IsCancellationRequested && !HasActiveNextNavigationOperation()) return;
        AppLogger.Warn($"open-all-yielded-to-next-navigation: checkpoint={checkpoint}; cancelled={token.IsCancellationRequested}; activeNextNavigation={HasActiveNextNavigationOperation()}; action=cancel-open-all");
        throw new OperationCanceledException("Abrir todos cancelado para priorizar navegação Próximo", token);
    }

    private async void OpenAllPipsButton_Click(object sender, RoutedEventArgs e) =>
        await OpenAllDetectedPipsAsync();

    private async Task StabilizeVideoSourcesForOpenAllAsync(System.Threading.CancellationToken token)
    {
        var previousCount = -1;
        var stableRounds = 0;
        const int maxRounds = 5;

        for (var round = 1; round <= maxRounds; round++)
        {
            ThrowIfOpenAllMustYield(token, $"source-stabilization-round-{round}-before-snapshot");
            await _extensionBridge.RequestVideoSessionsSnapshotAsync();
            await Task.Delay(round == 1 ? 850 : 450, token);
            ThrowIfOpenAllMustYield(token, $"source-stabilization-round-{round}-after-delay");
            ApplyVideoTabsFromCache(force: true);

            var detected = VideoTabs
                .Where(tab => tab.TabId > 0
                    && !string.IsNullOrWhiteSpace(tab.PairKey)
                    && !IsLikelyAdvertisementVideo(tab, out _))
                .Select(tab => tab.TabId)
                .Distinct()
                .Count();

            stableRounds = detected == previousCount ? stableRounds + 1 : 0;
            AppLogger.Info(
                $"open-all-source-stabilization: round={round}/{maxRounds}; detected={detected}; " +
                $"slotCapacity={Slots.Count}; stableRounds={stableRounds}");

            if (detected >= Slots.Count || (detected > 0 && round >= 3 && stableRounds >= 2))
                break;

            previousCount = detected;
        }
    }

    private async Task OpenAllDetectedPipsAsync()
    {
        if (HasActiveNextNavigationOperation())
        {
            SetStatus("Abrir todos adiado: há uma navegação Próximo em andamento");
            AppLogger.Info("open-all-deferred-by-next-navigation: checkpoint=entry; action=do-not-acquire-physical-authority");
            return;
        }

        if (_openAllPipsInProgress || _openPipAttemptInProgress)
        {
            SetStatus("Já existe uma abertura de PiP em andamento");
            return;
        }

        if (!_extensionBridge.IsConnected)
        {
            SetStatus("Extensão não conectada. Recarregue a extensão e tente novamente");
            return;
        }

        _openAllPipsInProgress = true;
        var openAllCts = new System.Threading.CancellationTokenSource();
        _openAllCancellationCts = openAllCts;
        var openAllToken = openAllCts.Token;
        UpdateOpenPipButtonsState();

        var opened = 0;
        var skipped = 0;
        var failed = 0;
        var autoReturnGateAcquired = false;

        try
        {
            // Abrir todos é a autoridade física exclusiva do navegador durante todo o lote.
            // Aguarda uma tentativa AutoReturn já em voo e impede novas tentativas até o final,
            // evitando que um slot offline capture o HWND recém-criado para outro slot.
            AppLogger.Info("open-all-physical-authority-wait: gate=auto-return-execution; action=acquire-exclusive");
            await _autoReturnExecutionGate.WaitAsync(openAllToken);
            autoReturnGateAcquired = true;
            AppLogger.Info("open-all-physical-authority-acquired: gate=auto-return-execution; exclusive=True");
            ThrowIfOpenAllMustYield(openAllToken, "after-physical-authority-acquired");

            ClearDisabledAutoReturnLostReservationsForOpenAll();

            try
            {
                await StabilizeVideoSourcesForOpenAllAsync(openAllToken);
            }
            catch (OperationCanceledException) when (openAllToken.IsCancellationRequested)
            {
                throw;
            }
            catch (Exception ex)
            {
                AppLogger.Warn($"open-all-snapshot-warning: error={ex.Message}");
            }

            ApplyVideoTabsFromCache(force: true);

            // Uma abertura por aba. Dentro de cada aba escolhemos a sessão mais provável:
            // vídeo tocando, melhor rank visual e snapshot mais recente.
            var candidates = VideoTabs
                .Where(tab => tab.TabId > 0
                    && !string.IsNullOrWhiteSpace(tab.PairKey)
                    && !IsLikelyAdvertisementVideo(tab, out _))
                .GroupBy(tab => tab.TabId)
                .Select(group => group
                    .OrderByDescending(tab => tab.IsPlaying)
                    .ThenBy(tab => tab.VisualRank)
                    .ThenByDescending(tab => tab.LastSeenUnixMs)
                    .First())
                .OrderBy(tab => tab.TabId)
                .ToList();

            if (candidates.Count == 0)
            {
                SetStatus("Nenhuma aba com vídeo foi detectada pela extensão");
                AppLogger.Warn("open-all-finished: result=no-video-tabs");
                return;
            }

            var activeWindowCount = Slots
                .Where(slot => slot.Window is not null && PipWindowService.IsUsable(slot.Window.Handle))
                .Select(slot => slot.Window!.Handle)
                .Distinct()
                .Count();
            var detectedSourceCount = candidates.Count;
            var slotCapacity = Slots.Count;
            var availableCapacity = Math.Max(0, slotCapacity - activeWindowCount);

            var pending = new List<VideoTabInfo>();
            foreach (var tab in candidates)
            {
                var existing = FindExistingSlotForVideoTab(tab);
                if (existing?.Window is not null && PipWindowService.IsUsable(existing.Window.Handle))
                {
                    skipped++;
                    AppLogger.Info($"open-all-skip-already-active: slot={existing.Number}; tabId={tab.TabId}; pairKey={tab.PairKey}; hwnd=0x{existing.Window.Handle.ToInt64():X}");
                    continue;
                }

                pending.Add(tab);
            }

            if (pending.Count == 0)
            {
                SetStatus($"Todos os {skipped} vídeo(s) detectados já estão abertos e vinculados");
                AppLogger.Info($"open-all-finished: result=already-open; skipped={skipped}");
                return;
            }

            if (availableCapacity == 0)
            {
                SetStatus($"Os {slotCapacity} slots já estão ocupados; nenhum novo PiP foi aberto");
                AppLogger.Warn($"open-all-finished: result=no-capacity; candidates={pending.Count}; active={activeWindowCount}");
                return;
            }

            if (pending.Count > availableCapacity)
            {
                AppLogger.Warn($"open-all-capacity-limited: requested={pending.Count}; available={availableCapacity}; maxSlots={slotCapacity}");
                pending = pending.Take(availableCapacity).ToList();
            }

            AppLogger.Warn(
                $"open-all-start: candidates={pending.Count}; detectedSources={detectedSourceCount}; " +
                $"slotCapacity={slotCapacity}; sourceDeficit={Math.Max(0, slotCapacity - detectedSourceCount)}; " +
                $"skippedAlreadyActive={skipped}; activeWindows={activeWindowCount}; serial=True; failFast=False");

            for (var index = 0; index < pending.Count; index++)
            {
                ThrowIfOpenAllMustYield(openAllToken, $"before-item-{index + 1}");
                var requested = pending[index];

                // Revalida a sessão imediatamente antes de cada abertura, pois páginas dinâmicas
                // podem substituir o elemento de vídeo enquanto a fila está em execução.
                try
                {
                    await _extensionBridge.RequestVideoSessionsSnapshotAsync();
                    await Task.Delay(140, openAllToken);
                    ThrowIfOpenAllMustYield(openAllToken, $"item-{index + 1}-after-snapshot");
                    ApplyVideoTabsFromCache(force: true);
                }
                catch (OperationCanceledException) when (openAllToken.IsCancellationRequested)
                {
                    throw;
                }
                catch { }

                var current = VideoTabs
                    .Where(tab => tab.TabId == requested.TabId
                        && !IsLikelyAdvertisementVideo(tab, out _))
                    .OrderByDescending(tab => AreSameVideoChoice(tab, requested))
                    .ThenByDescending(tab => tab.IsPlaying)
                    .ThenBy(tab => tab.VisualRank)
                    .ThenByDescending(tab => tab.LastSeenUnixMs)
                    .FirstOrDefault();

                if (current is null)
                {
                    failed++;
                    AppLogger.Warn($"open-all-item-skipped: index={index + 1}/{pending.Count}; tabId={requested.TabId}; reason=video-session-disappeared; continueBatch=True");
                    SetStatus($"Abrir todos: aba {requested.TabId} sem vídeo válido; continuando com as demais");
                    continue;
                }

                SetStatus($"Abrindo e vinculando PiP {index + 1} de {pending.Count}: aba {current.TabId}");
                AppLogger.Warn($"open-all-item-start: index={index + 1}/{pending.Count}; tabId={current.TabId}; frameId={current.FrameId}; pairKey={current.PairKey}; stable={current.StableVideoKey}");

                await OpenPipManualFromSelectedVideoAsync(
                    requestedTab: current,
                    forceNextFreeSlot: true,
                    mode: "Abrir todos");
                ThrowIfOpenAllMustYield(openAllToken, $"item-{index + 1}-after-open-command");

                var linkedSlot = await WaitForOpenAllPairConfirmationAsync(current, timeoutMs: 4500);
                ThrowIfOpenAllMustYield(openAllToken, $"item-{index + 1}-after-confirmation");
                if (linkedSlot is null)
                {
                    failed++;
                    AppLogger.Warn($"open-all-item-skipped: index={index + 1}/{pending.Count}; tabId={current.TabId}; pairKey={current.PairKey}; reason=no-confirmed-hwnd; failFast=False; continueBatch=True");

                    // Uma fonte incompatível não pode bloquear as demais. Limpa somente
                    // a reserva sem HWND criada por esta tentativa antes de avançar.
                    var failedSlot = FindExistingSlotForVideoTab(current);
                    if (failedSlot is not null
                        && (failedSlot.Window is null || !PipWindowService.IsUsable(failedSlot.Window.Handle)))
                    {
                        EndOpenPipAttempt(failedSlot, current, "Abrir todos", "open-all-item-no-confirmed-hwnd");
                        ClearArmedPipPairState(stopTimer: true);
                        ClearSlotCompletely(failedSlot, "Abrir todos/ignorar fonte incompatível");
                    }

                    SetStatus($"Abrir todos: aba {current.TabId} não criou PiP; continuando com as demais");
                    await Task.Delay(220, openAllToken);
                    continue;
                }

                opened++;
                AppLogger.Warn($"open-all-item-pass: index={index + 1}/{pending.Count}; slot={linkedSlot.Number}; tabId={current.TabId}; hwnd=0x{linkedSlot.Window!.Handle.ToInt64():X}; pairKey={current.PairKey}; ownership=exclusive");
                await Task.Delay(180, openAllToken);
            }

            if (opened > 0)
            {
                QueueStableGroupLayout("open-all/final", debounceMs: 500);
                RefreshAllSlotStates();
                RefreshAllSlotPairVisuals();
                RefreshVideoPickerVisualStates();
                UpdateCounts();
                UpdatePairPreviewNotice();
            }

            var result = failed == 0 ? "PASS" : "PARTIAL";
            var freeBecauseNoSource = Math.Max(0, slotCapacity - activeWindowCount - opened);
            SetStatus(failed == 0
                ? freeBecauseNoSource > 0
                    ? $"Abrir todos concluído: {opened} aberto(s), {skipped} já existente(s); {freeBecauseNoSource} slot(s) livre(s) porque foram detectadas {detectedSourceCount} fonte(s)"
                    : $"Abrir todos concluído: {opened} aberto(s) e vinculado(s), {skipped} já existente(s)"
                : $"Abrir todos parcial: {opened} aberto(s), {skipped} já existente(s), {failed} falha(s)");
            AppLogger.Warn(
                $"open-all-finished: result={result}; opened={opened}; skipped={skipped}; failed={failed}; " +
                $"requested={pending.Count}; detectedSources={detectedSourceCount}; slotCapacity={slotCapacity}; " +
                $"freeWithoutSource={freeBecauseNoSource}");
        }
        catch (OperationCanceledException) when (openAllToken.IsCancellationRequested || HasActiveNextNavigationOperation())
        {
            SetStatus("Abrir todos cancelado para priorizar o comando Próximo");
            AppLogger.Warn($"open-all-cancelled-for-video-navigation: opened={opened}; skipped={skipped}; failed={failed}; physicalAuthorityAcquired={autoReturnGateAcquired}; action=release-and-resume-auto-return");
        }
        catch (Exception ex)
        {
            failed++;
            SetStatus($"Falha em Abrir todos: {ex.Message}");
            AppLogger.Error($"open-all-exception: opened={opened}; skipped={skipped}; failed={failed}; error={ex}");
        }
        finally
        {
            _openAllPipsInProgress = false;
            if (ReferenceEquals(_openAllCancellationCts, openAllCts))
                _openAllCancellationCts = null;
            openAllCts.Dispose();
            if (autoReturnGateAcquired)
            {
                _autoReturnExecutionGate.Release();
                AppLogger.Info("open-all-physical-authority-released: gate=auto-return-execution; exclusive=False");
            }
            SignalPipOperationAvailability("open-all-finished");
            UpdateOpenPipButtonsState();
        }
    }

    private int ClearDisabledAutoReturnLostReservationsForOpenAll()
    {
        var cleared = 0;
        foreach (var slot in Slots.OrderBy(item => item.Number).ToArray())
        {
            if (IsAutoReturnEnabledForSlot(slot.Number)
                || slot.State == PipSlotState.AwaitingPip
                || (slot.Window is not null && PipWindowService.IsUsable(slot.Window.Handle)))
                continue;

            var hasStaleReservation = slot.Window is not null
                || SlotHasPairRecoverySignal(slot.Number)
                || slot.State == PipSlotState.Offline
                || _pendingLostPipsBySlot.ContainsKey(slot.Number);
            if (!hasStaleReservation)
                continue;

            ClearSlotCompletely(slot, "Abrir todos/limpar reserva offline com AutoReturn desligado");
            cleared++;
        }

        if (cleared > 0)
            AppLogger.Info($"open-all-disabled-autoreturn-reservations-cleared: count={cleared}; action=prepared-open-owns-new-hwnd");
        return cleared;
    }

    private async Task<PipSlot?> WaitForOpenAllPairConfirmationAsync(VideoTabInfo tab, int timeoutMs)
    {
        var timeoutAt = DateTime.UtcNow.AddMilliseconds(Math.Max(250, timeoutMs));
        while (DateTime.UtcNow < timeoutAt)
        {
            var slot = FindExistingSlotForVideoTab(tab);
            if (slot?.Window is not null && PipWindowService.IsUsable(slot.Window.Handle))
                return slot;

            ReleaseExpiredOpenPipAttemptLock();
            await Task.Delay(50);
        }

        return null;
    }

    private async void OpenPipFromSelectedVideoButton_Click(object sender, RoutedEventArgs e) =>
        await OpenPipFromSelectedVideoAsync();

    private async void OpenPipManualButton_Click(object sender, RoutedEventArgs e) =>
        await OpenPipManualFromSelectedVideoAsync();

    private async void OpenPipFocuslessButton_Click(object sender, RoutedEventArgs e) =>
        await OpenPipFocuslessFromSelectedVideoAsync();

    private async void OpenPipSilentButton_Click(object sender, RoutedEventArgs e) =>
        await OpenPipSilentFromSelectedVideoAsync();

    private static string DescribeForegroundWindow(IntPtr handle)
    {
        if (handle == IntPtr.Zero)
            return "zero";

        try
        {
            var buffer = new StringBuilder(260);
            _ = GetWindowText(handle, buffer, buffer.Capacity);
            var title = buffer.ToString();
            return $"0x{handle.ToInt64():X}" + (string.IsNullOrWhiteSpace(title) ? string.Empty : $" | {title}");
        }
        catch
        {
            return $"0x{handle.ToInt64():X}";
        }
    }

    private static bool TryRestoreForegroundWindow(IntPtr previousForeground, string attemptId)
    {
        if (previousForeground == IntPtr.Zero)
        {
            AppLogger.Warn($"focusless-restore-focus: attemptId={attemptId}; ok=False; reason=zero-handle");
            return false;
        }

        if (!IsWindow(previousForeground))
        {
            AppLogger.Warn($"focusless-restore-focus: attemptId={attemptId}; handle=0x{previousForeground.ToInt64():X}; ok=False; reason=window-not-valid");
            return false;
        }

        try
        {
            var ok = SetForegroundWindow(previousForeground);
            AppLogger.Info($"focusless-restore-focus: attemptId={attemptId}; handle=0x{previousForeground.ToInt64():X}; ok={ok}");
            return ok;
        }
        catch (Exception ex)
        {
            AppLogger.Warn($"focusless-restore-focus: attemptId={attemptId}; handle=0x{previousForeground.ToInt64():X}; ok=False; reason={ex.Message}");
            return false;
        }
    }


    private sealed record MainWindowNoActivateLease(IntPtr Hwnd, IntPtr OriginalExStyle, bool Changed);

    private MainWindowNoActivateLease? BeginMainWindowNoActivateLease(IntPtr intendedForeground, string attemptId)
    {
        try
        {
            var hwnd = new WindowInteropHelper(this).Handle;
            if (hwnd == IntPtr.Zero || !Win32.IsWindow(hwnd) || intendedForeground == hwnd)
                return null;

            var original = Win32.GetWindowLongPtr(hwnd, Win32.GWL_EXSTYLE);
            var updatedValue = original.ToInt64() | Win32.WS_EX_NOACTIVATE;
            var changed = updatedValue != original.ToInt64();
            if (changed)
            {
                Win32.SetWindowLongPtr(hwnd, Win32.GWL_EXSTYLE, new IntPtr(updatedValue));
                Win32.SetWindowPos(hwnd, IntPtr.Zero, 0, 0, 0, 0,
                    Win32.SWP_NOMOVE | Win32.SWP_NOSIZE | Win32.SWP_NOZORDER |
                    Win32.SWP_NOACTIVATE | Win32.SWP_FRAMECHANGED);
            }

            AppLogger.Info($"main-window-auto-activation-block-start: attemptId={attemptId}; hwnd=0x{hwnd.ToInt64():X}; changed={changed}; intendedForeground={DescribeForegroundWindow(intendedForeground)}");
            return new MainWindowNoActivateLease(hwnd, original, changed);
        }
        catch (Exception ex)
        {
            AppLogger.Warn($"main-window-auto-activation-block-start: attemptId={attemptId}; ok=False; reason={ex.Message}");
            return null;
        }
    }

    private static void EndMainWindowNoActivateLease(MainWindowNoActivateLease? lease, string attemptId)
    {
        if (lease is null || !lease.Changed)
            return;

        try
        {
            if (Win32.IsWindow(lease.Hwnd))
            {
                Win32.SetWindowLongPtr(lease.Hwnd, Win32.GWL_EXSTYLE, lease.OriginalExStyle);
                Win32.SetWindowPos(lease.Hwnd, IntPtr.Zero, 0, 0, 0, 0,
                    Win32.SWP_NOMOVE | Win32.SWP_NOSIZE | Win32.SWP_NOZORDER |
                    Win32.SWP_NOACTIVATE | Win32.SWP_FRAMECHANGED);
            }
            AppLogger.Info($"main-window-auto-activation-block-end: attemptId={attemptId}; hwnd=0x{lease.Hwnd.ToInt64():X}; restored=True");
        }
        catch (Exception ex)
        {
            AppLogger.Warn($"main-window-auto-activation-block-end: attemptId={attemptId}; hwnd=0x{lease.Hwnd.ToInt64():X}; restored=False; reason={ex.Message}");
        }
    }

    private static async Task<bool> TryRestoreForegroundWindowVerifiedAsync(IntPtr target, string attemptId, int settleMs = 80)
    {
        if (target == IntPtr.Zero || !IsWindow(target))
        {
            AppLogger.Warn($"focusless-restore-focus-verified: attemptId={attemptId}; handle=0x{target.ToInt64():X}; ok=False; reason=invalid-target");
            return false;
        }

        for (var attempt = 1; attempt <= 3; attempt++)
        {
            var directOk = false;
            try { directOk = SetForegroundWindow(target); } catch { }
            await Task.Delay(attempt == 1 ? 20 : 35);
            if (GetForegroundWindow() == target)
            {
                AppLogger.Info($"focusless-restore-focus-verified: attemptId={attemptId}; handle=0x{target.ToInt64():X}; ok=True; attempt={attempt}; method=direct; setForegroundOk={directOk}");
                if (settleMs > 0) await Task.Delay(settleMs);
                return GetForegroundWindow() == target;
            }

            var currentThreadId = GetCurrentThreadId();
            var foreground = GetForegroundWindow();
            var foregroundThreadId = foreground == IntPtr.Zero ? 0 : GetWindowThreadProcessId(foreground, out _);
            var targetThreadId = GetWindowThreadProcessId(target, out _);
            var attachedForeground = false;
            var attachedTarget = false;
            try
            {
                if (foregroundThreadId != 0 && foregroundThreadId != currentThreadId)
                    attachedForeground = AttachThreadInput(currentThreadId, foregroundThreadId, true);
                if (targetThreadId != 0 && targetThreadId != currentThreadId)
                    attachedTarget = AttachThreadInput(currentThreadId, targetThreadId, true);
                _ = SetForegroundWindow(target);
            }
            finally
            {
                if (attachedTarget && targetThreadId != currentThreadId)
                    _ = AttachThreadInput(currentThreadId, targetThreadId, false);
                if (attachedForeground && foregroundThreadId != currentThreadId)
                    _ = AttachThreadInput(currentThreadId, foregroundThreadId, false);
            }

            await Task.Delay(25);
            if (GetForegroundWindow() == target)
            {
                AppLogger.Info($"focusless-restore-focus-verified: attemptId={attemptId}; handle=0x{target.ToInt64():X}; ok=True; attempt={attempt}; method=attach-thread");
                if (settleMs > 0) await Task.Delay(settleMs);
                return GetForegroundWindow() == target;
            }
        }

        AppLogger.Warn($"focusless-restore-focus-verified: attemptId={attemptId}; handle=0x{target.ToInt64():X}; ok=False; foreground={DescribeForegroundWindow(GetForegroundWindow())}");
        return false;
    }

    private static string GetForegroundProcessName(IntPtr handle)
    {
        if (handle == IntPtr.Zero) return string.Empty;

        try
        {
            _ = GetWindowThreadProcessId(handle, out var pid);
            if (pid == 0) return string.Empty;
            using var process = Process.GetProcessById((int)pid);
            return process.ProcessName ?? string.Empty;
        }
        catch
        {
            return string.Empty;
        }
    }

    private bool IsLikelyBrowserForeground(IntPtr handle, VideoTabInfo tab, int slotNumber = 0)
    {
        if (handle == IntPtr.Zero) return false;

        var processName = GetForegroundProcessName(handle).ToLowerInvariant();
        var description = DescribeForegroundWindow(handle).ToLowerInvariant();
        var domain = (tab.Domain ?? string.Empty).ToLowerInvariant();
        var title = (tab.Title ?? string.Empty).ToLowerInvariant();
        var expectedProcess = slotNumber > 0
            ? (Slots.FirstOrDefault(item => item.Number == slotNumber)?.Window?.ProcessName ?? string.Empty).ToLowerInvariant()
            : string.Empty;
        if (slotNumber > 0 && string.IsNullOrWhiteSpace(expectedProcess)
            && _autoReturnStatesBySlot.TryGetValue(slotNumber, out var pendingState))
        {
            expectedProcess = (pendingState.ExpectedBrowserProcess ?? string.Empty).ToLowerInvariant();
        }

        // AutoReturn must validate the browser that owns the linked PiP, not merely any browser.
        // This rejects Brave/Chrome foreground when the slot belongs to Firefox, and vice versa.
        if (!string.IsNullOrWhiteSpace(expectedProcess))
        {
            var expectedBase = Path.GetFileNameWithoutExtension(expectedProcess);
            if (!processName.Contains(expectedBase, StringComparison.OrdinalIgnoreCase))
                return false;
        }
        else
        {
            var browserProcess = processName.Contains("firefox")
                || processName.Contains("zen")
                || processName.Contains("chrome")
                || processName.Contains("msedge")
                || processName.Contains("brave")
                || processName.Contains("opera");
            if (!browserProcess) return false;
        }

        if (!string.IsNullOrWhiteSpace(domain) && description.Contains(domain)) return true;
        if (!string.IsNullOrWhiteSpace(title))
        {
            var titleToken = title.Length > 24 ? title[..24] : title;
            if (!string.IsNullOrWhiteSpace(titleToken) && description.Contains(titleToken)) return true;
        }

        // Process identity is authoritative after the extension focused the exact tab.
        return !string.IsNullOrWhiteSpace(expectedProcess);
    }

    private async Task<bool> EnsureBrowserForegroundForAutoReturnAsync(VideoTabInfo tab, string attemptId, int slotNumber, int tryNumber, int maxAttempts = 3)
    {
        AppLogger.Info($"auto-return-focusless-foreground-verify-start: attemptId={attemptId}; slot={slotNumber}; tabId={tab.TabId}; try={tryNumber}; maxAttempts={maxAttempts}");

        // FocusVideoTabAsync itself can restore and foreground the browser. Cloak the
        // owning browser window before asking the extension to focus the tab, otherwise
        // the visible frame occurs hundreds of milliseconds before the physical shortcut.
        var preFocusBrowserHwnd = IntPtr.Zero;
        try
        {
            var preFocusCandidates = FindBrowserWindowCandidates(tab);
            if (preFocusCandidates.Count > 0)
            {
                preFocusBrowserHwnd = preFocusCandidates[0].Handle;
                var cloakDiagnostic = VideoCommandService.PrepareBrowserForegroundCloak(preFocusBrowserHwnd);
                AppLogger.Info($"auto-return-browser-prefocus-cloak: attemptId={attemptId}; slot={slotNumber}; tabId={tab.TabId}; hwnd=0x{preFocusBrowserHwnd.ToInt64():X}; diagnostic={cloakDiagnostic}");
                _ = Win32.DwmFlush();
                await Task.Delay(24);
            }
            else
            {
                AppLogger.Info($"auto-return-browser-prefocus-cloak-skipped: attemptId={attemptId}; slot={slotNumber}; tabId={tab.TabId}; reason=no-browser-candidate");
            }
        }
        catch (Exception ex)
        {
            AppLogger.Warn($"auto-return-browser-prefocus-cloak-error: attemptId={attemptId}; slot={slotNumber}; tabId={tab.TabId}; error={ex.Message}");
        }

        for (var attempt = 1; attempt <= maxAttempts; attempt++)
        {
            try
            {
                var clients = await _extensionBridge.FocusVideoTabAsync(tab.TabId);
                AppLogger.Info($"auto-return-focusless-focus-tab-verified: attemptId={attemptId}; slot={slotNumber}; tabId={tab.TabId}; try={tryNumber}; attempt={attempt}; conexoes={clients}; requestOk=True");
            }
            catch (Exception ex)
            {
                AppLogger.Warn($"auto-return-focusless-focus-tab-verified: attemptId={attemptId}; slot={slotNumber}; tabId={tab.TabId}; try={tryNumber}; attempt={attempt}; requestOk=False; reason={ex.Message}");
            }

            var verifyWindowMs = attempt == 1 ? 260 : 420;
            var verifyStartedUtc = DateTime.UtcNow;
            var foreground = IntPtr.Zero;
            var foregroundOk = false;
            do
            {
                await Task.Delay(25);
                foreground = GetForegroundWindow();
                foregroundOk = IsLikelyBrowserForeground(foreground, tab, slotNumber);
                if (foregroundOk)
                    break;
            }
            while ((DateTime.UtcNow - verifyStartedUtc).TotalMilliseconds < verifyWindowMs);

            AppLogger.Warn($"auto-return-focusless-foreground-check: attemptId={attemptId}; slot={slotNumber}; tabId={tab.TabId}; try={tryNumber}; attempt={attempt}; phase=after-extension-focus; adaptive=True; waitMs={(DateTime.UtcNow - verifyStartedUtc).TotalMilliseconds:0}; maxWaitMs={verifyWindowMs}; foregroundBrowser={foregroundOk}; foreground={DescribeForegroundWindow(foreground)}; process={GetForegroundProcessName(foreground)}");

            if (foregroundOk)
                return true;

            var activated = await TryActivateBrowserWindowStrongAsync(tab, attemptId, slotNumber, tryNumber, attempt);
            var strongVerifyWindowMs = activated ? 220 : 320;
            var strongVerifyStartedUtc = DateTime.UtcNow;
            do
            {
                await Task.Delay(25);
                foreground = GetForegroundWindow();
                foregroundOk = IsLikelyBrowserForeground(foreground, tab, slotNumber);
                if (foregroundOk)
                    break;
            }
            while ((DateTime.UtcNow - strongVerifyStartedUtc).TotalMilliseconds < strongVerifyWindowMs);

            AppLogger.Warn($"auto-return-focusless-foreground-check: attemptId={attemptId}; slot={slotNumber}; tabId={tab.TabId}; try={tryNumber}; attempt={attempt}; phase=after-strong-activation; adaptive=True; activated={activated}; waitMs={(DateTime.UtcNow - strongVerifyStartedUtc).TotalMilliseconds:0}; maxWaitMs={strongVerifyWindowMs}; foregroundBrowser={foregroundOk}; foreground={DescribeForegroundWindow(foreground)}; process={GetForegroundProcessName(foreground)}");

            if (foregroundOk)
                return true;
        }

        AppLogger.Warn($"auto-return-focusless-foreground-failed: attemptId={attemptId}; slot={slotNumber}; tabId={tab.TabId}; try={tryNumber}; reasonCode=browser-not-foreground");
        if (preFocusBrowserHwnd != IntPtr.Zero)
        {
            var restored = VideoCommandService.RestoreBrowserForegroundCloak(preFocusBrowserHwnd, "auto-return-foreground-failed");
            AppLogger.Info($"auto-return-browser-prefocus-cloak-restored: attemptId={attemptId}; slot={slotNumber}; tabId={tab.TabId}; restored={restored}; reason=foreground-failed");
        }
        return false;
    }

    
    private static List<BrowserWindowCandidate> FindBrowserWindowCandidates(VideoTabInfo tab)
    {
        var candidates = new List<BrowserWindowCandidate>();
        var domain = (tab.Domain ?? string.Empty).ToLowerInvariant();
        var title = (tab.Title ?? string.Empty).ToLowerInvariant();
        var titleToken = title.Length > 28 ? title[..28] : title;

        EnumWindows((hWnd, _) =>
        {
            if (hWnd == IntPtr.Zero || !IsWindowVisible(hWnd))
                return true;

            var buffer = new StringBuilder(512);
            GetWindowText(hWnd, buffer, buffer.Capacity);
            var windowTitle = buffer.ToString();
            if (string.IsNullOrWhiteSpace(windowTitle))
                return true;

            GetWindowThreadProcessId(hWnd, out var pid);
            if (pid == 0)
                return true;

            string processName;
            try
            {
                using var process = Process.GetProcessById((int)pid);
                processName = process.ProcessName ?? string.Empty;
            }
            catch
            {
                return true;
            }

            var processLower = processName.ToLowerInvariant();
            var titleLower = windowTitle.ToLowerInvariant();
            var isBrowser =
                processLower.Contains("firefox")
                || processLower.Contains("zen")
                || processLower.Contains("chrome")
                || processLower.Contains("msedge")
                || processLower.Contains("brave")
                || processLower.Contains("opera");

            if (!isBrowser)
                return true;

            var score = 10;
            var reasons = new List<string> { $"process={processName}" };

            if (!string.IsNullOrWhiteSpace(domain) && titleLower.Contains(domain))
            {
                score += 80;
                reasons.Add("domain-title:+80");
            }

            if (!string.IsNullOrWhiteSpace(titleToken) && titleLower.Contains(titleToken))
            {
                score += 60;
                reasons.Add("page-title:+60");
            }

            if (titleLower.Contains("mozilla firefox") || titleLower.Contains("firefox"))
            {
                score += 20;
                reasons.Add("firefox-title:+20");
            }

            if (titleLower.Contains("private browsing") || titleLower.Contains("private"))
            {
                score += 5;
                reasons.Add("private:+5");
            }

            candidates.Add(new BrowserWindowCandidate(hWnd, processName, windowTitle, score, string.Join(",", reasons)));
            return true;
        }, IntPtr.Zero);

        return candidates
            .OrderByDescending(item => item.Score)
            .ThenBy(item => item.Title.Length)
            .ToList();
    }

    private static bool TryStrongForegroundWindow(IntPtr hWnd, string attemptId, int slotNumber, int tabId, int tryNumber, int focusAttempt)
    {
        if (hWnd == IntPtr.Zero || !IsWindow(hWnd))
        {
            AppLogger.Warn($"auto-return-browser-activate-result: attemptId={attemptId}; slot={slotNumber}; tabId={tabId}; try={tryNumber}; attempt={focusAttempt}; ok=False; reason=invalid-hwnd");
            return false;
        }

        try
        {
            var cloakDiagnostic = VideoCommandService.PrepareBrowserForegroundCloak(hWnd);
            AppLogger.Info($"auto-return-browser-activate-cloak: attemptId={attemptId}; slot={slotNumber}; tabId={tabId}; try={tryNumber}; attempt={focusAttempt}; hwnd=0x{hWnd.ToInt64():X}; diagnostic={cloakDiagnostic}");
            _ = Win32.DwmFlush();
            AppLogger.Info($"auto-return-browser-activate-showwindow: attemptId={attemptId}; slot={slotNumber}; tabId={tabId}; try={tryNumber}; attempt={focusAttempt}; hwnd=0x{hWnd.ToInt64():X}");
            _ = ShowWindow(hWnd, SwRestore);
            _ = ShowWindow(hWnd, SwShow);
            _ = SetWindowPos(hWnd, HwndTop, 0, 0, 0, 0, SwpNoMove | SwpNoSize | SwpShowWindow);

            var setForegroundOk = SetForegroundWindow(hWnd);
            AppLogger.Info($"auto-return-browser-activate-setforeground: attemptId={attemptId}; slot={slotNumber}; tabId={tabId}; try={tryNumber}; attempt={focusAttempt}; hwnd=0x{hWnd.ToInt64():X}; ok={setForegroundOk}");

            var foreground = GetForegroundWindow();
            if (foreground == hWnd)
            {
                AppLogger.Warn($"auto-return-browser-activate-result: attemptId={attemptId}; slot={slotNumber}; tabId={tabId}; try={tryNumber}; attempt={focusAttempt}; ok=True; method=setforeground; foreground={DescribeForegroundWindow(foreground)}");
                return true;
            }

            var currentThreadId = GetCurrentThreadId();
            var foregroundThreadId = GetWindowThreadProcessId(foreground, out _);
            var targetThreadId = GetWindowThreadProcessId(hWnd, out _);

            var attachedForeground = false;
            var attachedTarget = false;

            try
            {
                if (foregroundThreadId != 0 && foregroundThreadId != currentThreadId)
                    attachedForeground = AttachThreadInput(currentThreadId, foregroundThreadId, true);

                if (targetThreadId != 0 && targetThreadId != currentThreadId)
                    attachedTarget = AttachThreadInput(currentThreadId, targetThreadId, true);

                _ = ShowWindow(hWnd, SwRestore);
                _ = SetWindowPos(hWnd, HwndTop, 0, 0, 0, 0, SwpNoMove | SwpNoSize | SwpShowWindow);
                var attachSetForegroundOk = SetForegroundWindow(hWnd);
                AppLogger.Info($"auto-return-browser-activate-attachthread: attemptId={attemptId}; slot={slotNumber}; tabId={tabId}; try={tryNumber}; attempt={focusAttempt}; hwnd=0x{hWnd.ToInt64():X}; attachedForeground={attachedForeground}; attachedTarget={attachedTarget}; setForegroundOk={attachSetForegroundOk}");
            }
            finally
            {
                if (attachedTarget && targetThreadId != 0 && targetThreadId != currentThreadId)
                    _ = AttachThreadInput(currentThreadId, targetThreadId, false);

                if (attachedForeground && foregroundThreadId != 0 && foregroundThreadId != currentThreadId)
                    _ = AttachThreadInput(currentThreadId, foregroundThreadId, false);
            }

            foreground = GetForegroundWindow();
            var ok = foreground == hWnd;
            AppLogger.Warn($"auto-return-browser-activate-result: attemptId={attemptId}; slot={slotNumber}; tabId={tabId}; try={tryNumber}; attempt={focusAttempt}; ok={ok}; method=strong; foreground={DescribeForegroundWindow(foreground)}; process={GetForegroundProcessName(foreground)}");
            return ok;
        }
        catch (Exception ex)
        {
            AppLogger.Warn($"auto-return-browser-activate-result: attemptId={attemptId}; slot={slotNumber}; tabId={tabId}; try={tryNumber}; attempt={focusAttempt}; ok=False; reason={ex.Message}");
            return false;
        }
    }

    private async Task<bool> TryActivateBrowserWindowStrongAsync(VideoTabInfo tab, string attemptId, int slotNumber, int tryNumber, int focusAttempt)
    {
        await Task.Yield();

        var candidates = FindBrowserWindowCandidates(tab);
        if (candidates.Count == 0)
        {
            AppLogger.Warn($"auto-return-browser-hwnd-selected: attemptId={attemptId}; slot={slotNumber}; tabId={tab.TabId}; try={tryNumber}; attempt={focusAttempt}; ok=False; reason=no-browser-candidates; domain={tab.Domain}; title={tab.Title}");
            return false;
        }

        var best = candidates[0];
        AppLogger.Warn($"auto-return-browser-hwnd-selected: attemptId={attemptId}; slot={slotNumber}; tabId={tab.TabId}; try={tryNumber}; attempt={focusAttempt}; hwnd=0x{best.Handle.ToInt64():X}; process={best.ProcessName}; score={best.Score}; reasons={best.Reasons}; title={best.Title}");
        AppLogger.Info($"auto-return-browser-activate-start: attemptId={attemptId}; slot={slotNumber}; tabId={tab.TabId}; try={tryNumber}; attempt={focusAttempt}; candidates={candidates.Count}");

        try
        {
            EnsureHiddenBrowserWorkspaceForShortcut(best.Handle, attemptId, slotNumber, "auto-return-before-shortcut");
        }
        catch (Exception ex)
        {
            AppLogger.Warn($"hidden-browser-workspace-error: attemptId={attemptId}; slot={slotNumber}; error={ex.Message}; reason=auto-return-before-shortcut");
        }

        return TryStrongForegroundWindow(best.Handle, attemptId, slotNumber, tab.TabId, tryNumber, focusAttempt);
    }

private async Task<IntPtr> WaitForAutoReturnHwndAsync(PipSlot slot, string attemptId, int tryNumber, int waitMs = 4400, string phase = "standard", bool logTimeout = true, string? abortOnSilentFailureAttemptId = null)
    {
        var started = DateTime.UtcNow;
        var iteration = 0;
        AppLogger.Info($"auto-return-focusless-hwnd-wait: attemptId={attemptId}; slot={slot.Number}; try={tryNumber}; phase={phase}; waitMs={waitMs}");

        while ((DateTime.UtcNow - started).TotalMilliseconds < waitMs)
        {
            RefreshCapturedWindows();
            var currentHandle = slot.Window?.Handle ?? IntPtr.Zero;
            if (currentHandle != IntPtr.Zero && PipWindowService.IsUsable(currentHandle))
            {
                var elapsed = (DateTime.UtcNow - started).TotalMilliseconds;
                AppLogger.Warn($"auto-return-monitor-confirmed: attemptId={attemptId}; slot={slot.Number}; handle=0x{currentHandle.ToInt64():X}; try={tryNumber}; iteration={iteration}; elapsedMs={elapsed:0}");
                if (elapsed > 2600)
                    AppLogger.Warn($"auto-return-focusless-hwnd-late-captured: attemptId={attemptId}; slot={slot.Number}; handle=0x{currentHandle.ToInt64():X}; try={tryNumber}; elapsedMs={elapsed:0}");
                return currentHandle;
            }

            if (!string.IsNullOrWhiteSpace(abortOnSilentFailureAttemptId)
                && string.Equals(_lastSilentAttemptId, abortOnSilentFailureAttemptId, StringComparison.OrdinalIgnoreCase)
                && IsSilentReopenImmediateFallbackReason(_lastSilentExtensionReasonCode))
            {
                var elapsed = (DateTime.UtcNow - started).TotalMilliseconds;
                AppLogger.Warn($"auto-return-focusless-hwnd-wait-aborted-by-silent-result: attemptId={attemptId}; silentAttemptId={abortOnSilentFailureAttemptId}; slot={slot.Number}; try={tryNumber}; phase={phase}; reasonCode={_lastSilentExtensionReasonCode}; elapsedMs={elapsed:0}; fallback=discrete-immediate");
                return IntPtr.Zero;
            }

            iteration++;
            var remainingMs = waitMs - (int)(DateTime.UtcNow - started).TotalMilliseconds;
            if (remainingMs <= 0) break;
            var delayMs = iteration <= 8 ? 45 : iteration <= 16 ? 80 : 140;
            await Task.Delay(Math.Min(delayMs, remainingMs));
        }

        // The assisted capture can complete on the Dispatcher immediately before the
        // wait deadline. Re-read the slot once after the loop so a confirmed HWND is not
        // misclassified as a timeout merely because the next polling iteration did not run.
        RefreshCapturedWindows();
        var finalHandle = slot.Window?.Handle ?? IntPtr.Zero;
        if (finalHandle != IntPtr.Zero && PipWindowService.IsUsable(finalHandle))
        {
            var elapsed = (DateTime.UtcNow - started).TotalMilliseconds;
            AppLogger.Warn($"auto-return-monitor-confirmed-post-timeout: attemptId={attemptId}; slot={slot.Number}; handle=0x{finalHandle.ToInt64():X}; try={tryNumber}; phase={phase}; elapsedMs={elapsed:0}; reason=dispatcher-capture-race-reconciled");
            return finalHandle;
        }

        if (logTimeout)
        {
            AppLogger.Warn($"auto-return-focusless-hwnd-not-found: attemptId={attemptId}; slot={slot.Number}; try={tryNumber}; phase={phase}; reasonCode=hwnd-not-found; eventAssist=enabled; waitingForWindowEvents=True");
            _windowEventMonitor.MarkPollingObserved("auto-return-hwnd-not-found");
        }
        else
        {
            AppLogger.Info($"auto-return-focusless-hwnd-phase-expired: attemptId={attemptId}; slot={slot.Number}; try={tryNumber}; phase={phase}; waitMs={waitMs}");
        }
        return IntPtr.Zero;
    }

    private IntPtr TryReconcileAutoReturnCapturedHandle(PipSlot slot, string attemptId, string phase)
    {
        var handle = slot.Window?.Handle ?? IntPtr.Zero;
        if (handle == IntPtr.Zero || !PipWindowService.IsUsable(handle))
            return IntPtr.Zero;

        var claimedByAttempt = _autoReturnCandidateAttemptByHwnd.TryGetValue(handle, out var claim)
            && string.Equals(claim, attemptId, StringComparison.Ordinal);
        var newForPreparedAttempt = !_armedPipExistingHandles.Contains(handle);

        if (!claimedByAttempt && !newForPreparedAttempt)
            return IntPtr.Zero;

        AppLogger.Warn($"auto-return-focusless-late-capture-reconciled: attemptId={attemptId}; slot={slot.Number}; phase={phase}; handle=0x{handle.ToInt64():X}; claimedByAttempt={claimedByAttempt}; newForPreparedAttempt={newForPreparedAttempt}");
        return handle;
    }

    private void CleanupBrowserVisibilityAfterCancelledAutoReturn(
        VideoTabInfo tab,
        PipSlot slot,
        IntPtr previousForeground,
        string attemptId,
        string checkpoint)
    {
        var previousWasExpectedBrowser = IsLikelyBrowserForeground(previousForeground, tab, slot.Number);
        var minimized = false;
        var cloakRestored = false;

        if (previousWasExpectedBrowser)
        {
            cloakRestored = VideoCommandService.RestoreBrowserForegroundCloak(
                IntPtr.Zero,
                $"auto-return-cancelled-{checkpoint}-previous-browser");
        }
        else
        {
            minimized = VideoCommandService.TryMinimizeExpectedBrowserWindow(tab.Domain, tab.Title);
        }

        AppLogger.Info($"auto-return-cancelled-browser-visibility-cleanup: attemptId={attemptId}; slot={slot.Number}; tabId={tab.TabId}; checkpoint={checkpoint}; previousForeground={DescribeForegroundWindow(previousForeground)}; previousWasExpectedBrowser={previousWasExpectedBrowser}; browserMinimized={minimized}; cloakRestored={cloakRestored}; foregroundNow={DescribeForegroundWindow(GetForegroundWindow())}; diagnostic={VideoCommandService.LastInputDiagnostic}");
    }

    private IntPtr TryDirectedAutoReturnHwndRecovery(PipSlot slot, VideoTabInfo tab, string attemptId, int tryNumber)
    {
        if (_armedPipPairTab is null
            || _armedPipTargetSlotNumber != slot.Number
            || !string.Equals(_armedPipPairTab.PairKey, tab.PairKey, StringComparison.OrdinalIgnoreCase))
        {
            AppLogger.Info($"auto-return-directed-hwnd-sweep-skipped: attemptId={attemptId}; slot={slot.Number}; try={tryNumber}; reason=armed-attempt-mismatch");
            return IntPtr.Zero;
        }

        var candidates = _discovery.FindPipWindows()
            .Where(window => !_armedPipExistingHandles.Contains(window.Handle))
            .Select(window => new
            {
                Window = window,
                Owner = Slots.FirstOrDefault(existing => existing.Window is not null && existing.Window.Handle == window.Handle),
                Claimed = _autoReturnCandidateAttemptByHwnd.TryGetValue(window.Handle, out var claim)
                    && string.Equals(claim, attemptId, StringComparison.Ordinal)
            })
            .Where(item => item.Owner is null || item.Owner.Number == slot.Number)
            .OrderByDescending(item => item.Claimed)
            .ThenByDescending(item => item.Window.Score)
            .Select(item => item.Window)
            .ToList();

        AppLogger.Warn($"auto-return-directed-hwnd-sweep: attemptId={attemptId}; slot={slot.Number}; tabId={tab.TabId}; try={tryNumber}; candidates={candidates.Count}; handles={string.Join(",", candidates.Select(candidate => $"0x{candidate.Handle.ToInt64():X}:{candidate.Score}"))}");

        if (candidates.Count != 1)
        {
            AppLogger.Warn($"auto-return-directed-hwnd-sweep-rejected: attemptId={attemptId}; slot={slot.Number}; try={tryNumber}; reason={(candidates.Count == 0 ? "no-new-candidate" : "ambiguous-candidates")}; candidates={candidates.Count}");
            return IntPtr.Zero;
        }

        var candidate = candidates[0];
        CapturePreparedPipWindow(candidate, tab, confirmedEvent: null, targetSlotNumber: slot.Number);
        AppLogger.Warn($"auto-return-directed-hwnd-sweep-captured: attemptId={attemptId}; slot={slot.Number}; tabId={tab.TabId}; try={tryNumber}; handle=0x{candidate.Handle.ToInt64():X}; score={candidate.Score}");
        return candidate.Handle;
    }


    private string BuildOpenPipAttemptKey(PipSlot slot, VideoTabInfo tab)
    {
        var session = !string.IsNullOrWhiteSpace(tab.PairKey)
            ? tab.PairKey
            : (!string.IsNullOrWhiteSpace(tab.VideoSessionId) ? tab.VideoSessionId : tab.StableVideoKey);

        if (string.IsNullOrWhiteSpace(session))
            session = $"tab:{tab.TabId}";

        return $"{slot.Number}|{tab.TabId}|{session}";
    }

    private void BeginAutoPairProof(PipSlot slot, VideoTabInfo tab, IEnumerable<IntPtr> existingHandles, string source)
    {
        _autoPairProofAttemptId = $"autopair-{DateTime.UtcNow:HHmmssfff}-{slot.Number}-{tab.TabId}";
        _autoPairProofSlotNumber = slot.Number;
        _autoPairProofTabId = tab.TabId;
        _autoPairProofPairKey = tab.PairKey ?? string.Empty;
        _autoPairProofStartedUtc = DateTime.UtcNow;
        _autoPairProofExistingHandles = existingHandles.Where(handle => handle != IntPtr.Zero).ToHashSet();

        AppLogger.Warn(
            $"auto-pair-proof-start: attemptId={_autoPairProofAttemptId}; source={source}; " +
            $"slot={slot.Number}; tabId={tab.TabId}; videoIndex={tab.VideoIndex}; " +
            $"pairKey={tab.PairKey}; videoSessionId={tab.VideoSessionId}; stableVideoKey={tab.StableVideoKey}; " +
            $"pageInstanceId={tab.PageInstanceId}; elementInstanceId={tab.ElementInstanceId}; " +
            $"handlesBefore={_autoPairProofExistingHandles.Count}; " +
            $"handles={string.Join(",", _autoPairProofExistingHandles.Select(handle => $"0x{handle.ToInt64():X}"))}");
    }

    private void CompleteAutoPairProof(PipSlot slot, VideoTabInfo tab, PipWindowInfo window, string source)
    {
        if (string.IsNullOrWhiteSpace(_autoPairProofAttemptId))
            return;

        var attemptId = _autoPairProofAttemptId;
        var elapsedMs = _autoPairProofStartedUtc == DateTime.MinValue
            ? -1
            : Math.Max(0, (DateTime.UtcNow - _autoPairProofStartedUtc).TotalMilliseconds);
        var attemptMatches = _autoPairProofSlotNumber == slot.Number
            && _autoPairProofTabId == tab.TabId
            && string.Equals(_autoPairProofPairKey, tab.PairKey, StringComparison.OrdinalIgnoreCase);
        var currentIsNew = window.Handle != IntPtr.Zero && !_autoPairProofExistingHandles.Contains(window.Handle);

        var newCandidates = _discovery.FindPipWindows()
            .Where(candidate => !_autoPairProofExistingHandles.Contains(candidate.Handle))
            .Select(candidate => candidate.Handle)
            .Distinct()
            .ToList();
        var uniqueCandidate = newCandidates.Count == 1 && newCandidates[0] == window.Handle;
        var slotOwnsHwnd = slot.Window?.Handle == window.Handle;
        var pairStored = _slotVideoPairs.TryGetValue(slot.Number, out var storedPair)
            && string.Equals(storedPair, tab.PairKey, StringComparison.OrdinalIgnoreCase);
        var tabStored = tab.TabId <= 0
            || (_slotPairedTabIds.TryGetValue(slot.Number, out var storedTabId) && storedTabId == tab.TabId);
        var noOtherSlotOwnsHwnd = !Slots.Any(other => other.Number != slot.Number && other.Window?.Handle == window.Handle);
        var passed = attemptMatches && currentIsNew && uniqueCandidate && slotOwnsHwnd && pairStored && tabStored && noOtherSlotOwnsHwnd;

        AppLogger.Warn(
            $"auto-pair-proof-result: result={(passed ? "PASS" : "FAIL")}; attemptId={attemptId}; source={source}; " +
            $"slot={slot.Number}; tabId={tab.TabId}; hwnd=0x{window.Handle.ToInt64():X}; elapsedMs={elapsedMs:0.0}; " +
            $"attemptMatches={attemptMatches}; currentIsNew={currentIsNew}; uniqueCandidate={uniqueCandidate}; " +
            $"newCandidateCount={newCandidates.Count}; newCandidates={string.Join(",", newCandidates.Select(handle => $"0x{handle.ToInt64():X}"))}; " +
            $"slotOwnsHwnd={slotOwnsHwnd}; pairStored={pairStored}; tabStored={tabStored}; " +
            $"noOtherSlotOwnsHwnd={noOtherSlotOwnsHwnd}; pairKey={tab.PairKey}; stableVideoKey={tab.StableVideoKey}");

        SetStatus(passed
            ? $"Teste AutoVínculo: PASS — PiP {slot.Number} vinculado automaticamente à aba {tab.TabId}"
            : $"Teste AutoVínculo: FAIL — consulte auto-pair-proof-result no log");
        ClearAutoPairProof();
    }

    private void FailAutoPairProof(string source, string reason)
    {
        if (string.IsNullOrWhiteSpace(_autoPairProofAttemptId))
            return;

        var elapsedMs = _autoPairProofStartedUtc == DateTime.MinValue
            ? -1
            : Math.Max(0, (DateTime.UtcNow - _autoPairProofStartedUtc).TotalMilliseconds);
        AppLogger.Warn(
            $"auto-pair-proof-result: result=FAIL; attemptId={_autoPairProofAttemptId}; source={source}; " +
            $"slot={_autoPairProofSlotNumber}; tabId={_autoPairProofTabId}; elapsedMs={elapsedMs:0.0}; " +
            $"reason={reason}; handlesBefore={_autoPairProofExistingHandles.Count}");
        SetStatus("Teste AutoVínculo: FAIL — consulte o log");
        ClearAutoPairProof();
    }

    private void ClearAutoPairProof()
    {
        _autoPairProofAttemptId = string.Empty;
        _autoPairProofSlotNumber = 0;
        _autoPairProofTabId = 0;
        _autoPairProofPairKey = string.Empty;
        _autoPairProofStartedUtc = DateTime.MinValue;
        _autoPairProofExistingHandles.Clear();
    }

    private bool TryBeginOpenPipAttempt(PipSlot slot, VideoTabInfo tab, string mode, int seconds = 8, OpenPipAttemptOwner owner = OpenPipAttemptOwner.User)
    {
        if (IsLikelyAdvertisementVideo(tab, out var advertisementReason))
        {
            SetStatus("Anúncio ou player auxiliar ignorado; escolha o vídeo principal da página");
            AppLogger.Warn(
                $"openpip-ad-isolation-blocked: mode={mode}; slot={slot.Number}; tabId={tab.TabId}; " +
                $"domain={tab.Domain}; title={tab.Title}; reason={advertisementReason}");
            return false;
        }

        var now = DateTime.UtcNow;
        var key = BuildOpenPipAttemptKey(slot, tab);

        if (_openPipAttemptInProgress && now <= _openPipAttemptUntilUtc)
        {
            var sameAttempt = _openPipAttemptSlotNumber == slot.Number
                && string.Equals(_openPipAttemptKey, key, StringComparison.OrdinalIgnoreCase);

            var remaining = Math.Max(1, (int)Math.Ceiling((_openPipAttemptUntilUtc - now).TotalSeconds));
            var message = sameAttempt
                ? $"{mode}: já existe tentativa em andamento para o slot {slot.Number}. Aguarde {remaining}s."
                : $"{mode}: outra tentativa de Abrir PiP está em andamento no slot {_openPipAttemptSlotNumber}. Aguarde {remaining}s.";

            SetStatus(message);
            AppLogger.Warn($"Abrir PiP bloqueado por lock: modo={mode}; slot={slot.Number}; tabId={tab.TabId}; key={key}; tentativaAtualSlot={_openPipAttemptSlotNumber}; tentativaAtualKey={_openPipAttemptKey}; restante={remaining}s");
            return false;
        }

        _openPipAttemptInProgress = true;
        _openPipAttemptSlotNumber = slot.Number;
        _openPipAttemptKey = key;
        _openPipAttemptTab = tab;
        _openPipAttemptOwner = owner;
        _openPipAttemptStartedUtc = now;
        _openPipAttemptUntilUtc = now.AddSeconds(seconds);
        UpdateOpenPipButtonsState();

        AppLogger.Info($"Abrir PiP lock iniciado: modo={mode}; slot={slot.Number}; tabId={tab.TabId}; key={key}; ttl={seconds}s");
        return true;
    }

    private void EndOpenPipAttempt(PipSlot slot, VideoTabInfo tab, string mode, string reason)
    {
        var key = BuildOpenPipAttemptKey(slot, tab);
        if (_openPipAttemptSlotNumber == slot.Number
            && string.Equals(_openPipAttemptKey, key, StringComparison.OrdinalIgnoreCase))
        {
            AppLogger.Info($"Abrir PiP lock finalizado: modo={mode}; slot={slot.Number}; tabId={tab.TabId}; reason={reason}");
            FailAutoPairProof("EndOpenPipAttempt", reason);
            ClearShadowOpenAttemptForSlot(slot.Number, mode + "/EndOpenPipAttempt/" + reason);
            _openPipAttemptInProgress = false;
            SignalPipOperationAvailability("open-pip-attempt-finished");
            _openPipAttemptSlotNumber = 0;
            UpdateOpenPipButtonsState();
            _openPipAttemptKey = string.Empty;
            _openPipAttemptTab = null;
            _openPipAttemptOwner = OpenPipAttemptOwner.User;
            _openPipAttemptStartedUtc = DateTime.MinValue;
            _openPipAttemptUntilUtc = DateTime.MinValue;
        }
    }

    private void ReleaseExpiredOpenPipAttemptLock()
    {
        if (_openPipAttemptInProgress && DateTime.UtcNow > _openPipAttemptUntilUtc)
        {
            AppLogger.Warn($"Abrir PiP lock expirado automaticamente: slot={_openPipAttemptSlotNumber}; key={_openPipAttemptKey}");
            FailAutoPairProof("ReleaseExpiredOpenPipAttemptLock", "open-attempt-expired");
            ClearShadowOpenAttemptForSlot(_openPipAttemptSlotNumber, "ReleaseExpiredOpenPipAttemptLock");
            _openPipAttemptInProgress = false;
            SignalPipOperationAvailability("open-pip-attempt-expired");
            _openPipAttemptSlotNumber = 0;
            UpdateOpenPipButtonsState();
            _openPipAttemptKey = string.Empty;
            _openPipAttemptTab = null;
            _openPipAttemptOwner = OpenPipAttemptOwner.User;
            _openPipAttemptStartedUtc = DateTime.MinValue;
            _openPipAttemptUntilUtc = DateTime.MinValue;
        }
    }

    private bool IsActiveUserOpenPipAttemptForSlot(int slotNumber)
    {
        return _openPipAttemptInProgress
            && _openPipAttemptOwner == OpenPipAttemptOwner.User
            && _openPipAttemptSlotNumber == slotNumber
            && _openPipAttemptTab is not null
            && DateTime.UtcNow <= _openPipAttemptUntilUtc;
    }

    private bool TryRestorePreparedPipStateFromOpenAttempt(string source)
    {
        if (_armedPipPairTab is not null && _armedPipTargetSlotNumber > 0)
            return true;

        var attemptTab = _openPipAttemptTab;
        if (!_openPipAttemptInProgress
            || _openPipAttemptSlotNumber <= 0
            || attemptTab is null
            || DateTime.UtcNow > _openPipAttemptUntilUtc)
            return false;

        var slot = Slots.FirstOrDefault(item => item.Number == _openPipAttemptSlotNumber);
        if (slot is null || slot.Window is not null)
            return false;

        var expectedKey = BuildOpenPipAttemptKey(slot, attemptTab);
        if (!string.Equals(expectedKey, _openPipAttemptKey, StringComparison.OrdinalIgnoreCase))
            return false;

        MarkSlotAwaitingPip(slot);
        _armedPipTargetSlotNumber = slot.Number;
        _armedPipPairTab = attemptTab;
        _armedPipPairStartedUtc = _openPipAttemptStartedUtc;
        _armedPipPairUntilUtc = _openPipAttemptUntilUtc;
        _armedPipCandidateWindow = null;
        _armedPipCandidateDetectedUtc = DateTime.MinValue;

        if (_armedPipExistingHandles.Count == 0
            && _autoPairProofSlotNumber == slot.Number
            && _autoPairProofTabId == attemptTab.TabId
            && string.Equals(_autoPairProofPairKey, attemptTab.PairKey, StringComparison.OrdinalIgnoreCase))
        {
            _armedPipExistingHandles = _autoPairProofExistingHandles.ToHashSet();
        }

        AppLogger.InfoAggregated(
            $"prepared-state-restored-from-open-lock:{slot.Number}",
            TimeSpan.FromSeconds(1),
            $"prepared-state-restored-from-open-lock: source={source}; slot={slot.Number}; " +
            $"tabId={attemptTab.TabId}; owner={_openPipAttemptOwner}; openAll={_openAllPipsInProgress}; " +
            $"baselineHandles={_armedPipExistingHandles.Count}");
        return true;
    }

    private static int GetReactorPreArmDiagnosticDelayMs()
    {
        var raw = Environment.GetEnvironmentVariable(ReactorPreArmDiagnosticDelayEnvironmentVariable);
        return int.TryParse(raw, out var parsed)
            ? Math.Clamp(parsed, 0, ReactorPreArmDiagnosticDelayMaxMs)
            : 0;
    }

    private void ArmPreparedPipPair(PipSlot targetSlot, VideoTabInfo tab, string source)
    {
        _armedPipTargetSlotNumber = targetSlot.Number;
        _armedPipPairTab = tab;
        _armedPipPairStartedUtc = DateTime.UtcNow;
        _armedPipPairUntilUtc = DateTime.UtcNow.AddSeconds(35);
        _armedPipCandidateWindow = null;
        _armedPipCandidateDetectedUtc = DateTime.MinValue;
        AppLogger.Info($"window-event-reactor-prepared-state-armed: source={source}; slot={targetSlot.Number}; pairKey={tab.PairKey}");
    }

    private bool TryGetConfirmedInitialOpenHwnd(
        PipSlot slot,
        VideoTabInfo tab,
        out IntPtr handle,
        out string identityMatch)
    {
        handle = slot.Window?.Handle ?? IntPtr.Zero;
        identityMatch = string.Empty;

        if (handle == IntPtr.Zero || !PipWindowService.IsUsable(handle))
            return false;

        _slotVideoPairs.TryGetValue(slot.Number, out var pairKey);
        _slotStableVideoPairs.TryGetValue(slot.Number, out var stableVideoKey);
        _slotPairedTabIds.TryGetValue(slot.Number, out var pairedTabId);

        var tabMatches = pairedTabId <= 0 || tab.TabId <= 0 || pairedTabId == tab.TabId;
        var pairMatches = !string.IsNullOrWhiteSpace(pairKey)
            && !string.IsNullOrWhiteSpace(tab.PairKey)
            && string.Equals(pairKey, tab.PairKey, StringComparison.OrdinalIgnoreCase);
        var stableMatches = !string.IsNullOrWhiteSpace(stableVideoKey)
            && !string.IsNullOrWhiteSpace(tab.StableVideoKey)
            && string.Equals(stableVideoKey, tab.StableVideoKey, StringComparison.OrdinalIgnoreCase);

        if (!tabMatches || (!pairMatches && !stableMatches))
        {
            handle = IntPtr.Zero;
            return false;
        }

        identityMatch = pairMatches ? "pairKey" : "stableVideoKey";
        return true;
    }

    private bool TryCancelInitialOpenRetryAfterConfirmedCapture(
        PipSlot slot,
        VideoTabInfo tab,
        string mode,
        string checkpoint,
        string layoutSource)
    {
        if (!TryGetConfirmedInitialOpenHwnd(slot, tab, out var handle, out var identityMatch))
            return false;

        var browserMinimized = VideoCommandService.TryMinimizeExpectedBrowserWindow(tab.Domain, tab.Title);
        AppLogger.Info(
            $"initial-open-physical-shortcut-retry-cancelled: slot={slot.Number}; tabId={tab.TabId}; " +
            $"checkpoint={checkpoint}; reason=slot-already-confirmed; handle=0x{handle.ToInt64():X}; " +
            $"identityMatch={identityMatch}; browserMinimized={browserMinimized}; diagnostic={VideoCommandService.LastInputDiagnostic}");
        SetStatus($"PiP {slot.Number} já confirmado; repetição cancelada");
        QueueStableGroupLayout(layoutSource);
        EndOpenPipAttempt(slot, tab, mode, "retry-cancelado-slot-ja-confirmado");
        return true;
    }

    private async Task<IntPtr> WaitForInitialOpenHwndAsync(PipSlot slot, VideoTabInfo tab, string source, int timeoutMs)
    {
        var started = DateTime.UtcNow;
        var timeoutAt = started.AddMilliseconds(Math.Max(100, timeoutMs));

        while (DateTime.UtcNow < timeoutAt)
        {
            if (TryGetConfirmedInitialOpenHwnd(slot, tab, out var handle, out var identityMatch))
            {
                var elapsedMs = (DateTime.UtcNow - started).TotalMilliseconds;
                var browserMinimized = VideoCommandService.TryMinimizeExpectedBrowserWindow(tab.Domain, tab.Title);
                AppLogger.Info($"initial-open-browser-minimized-after-confirmation: source={source}; slot={slot.Number}; tabId={tab.TabId}; handle=0x{handle.ToInt64():X}; elapsedMs={elapsedMs:0}; identityMatch={identityMatch}; ok={browserMinimized}; diagnostic={VideoCommandService.LastInputDiagnostic}");
                return handle;
            }

            await Task.Delay(25);
        }

        // A captura assistida roda no Dispatcher e pode ocupar a thread de UI por mais
        // tempo do que a janela de espera. Verifique uma última vez depois do timeout:
        // o HWND pode ter sido confirmado enquanto este método aguardava para retomar.
        if (TryGetConfirmedInitialOpenHwnd(slot, tab, out var finalHandle, out var finalIdentityMatch))
        {
            var elapsedMs = (DateTime.UtcNow - started).TotalMilliseconds;
            var browserMinimized = VideoCommandService.TryMinimizeExpectedBrowserWindow(tab.Domain, tab.Title);
            AppLogger.Info($"initial-open-post-timeout-capture-confirmed: source={source}; slot={slot.Number}; tabId={tab.TabId}; handle=0x{finalHandle.ToInt64():X}; elapsedMs={elapsedMs:0}; identityMatch={finalIdentityMatch}; ok={browserMinimized}; diagnostic={VideoCommandService.LastInputDiagnostic}");
            return finalHandle;
        }

        return IntPtr.Zero;
    }

    private async Task OpenPipManualFromSelectedVideoAsync(
        VideoTabInfo? requestedTab = null,
        bool forceNextFreeSlot = false,
        string mode = "Abrir PiP")
    {
        ReleaseExpiredOpenPipAttemptLock();

        if (!_extensionBridge.IsConnected)
        {
            SetStatus("Extensão não conectada. Recarregue a extensão e tente novamente");
            return;
        }

        try
        {
            await _extensionBridge.RequestVideoSessionsSnapshotAsync();
            await Task.Delay(180);
        }
        catch { }

        (PipSlot? Slot, VideoTabInfo? Tab) prepared = forceNextFreeSlot
            ? (null, null)
            : GetPreparedOpenPipTarget();
        var selectedComboTab = requestedTab ?? VideoTabsCombo?.SelectedItem as VideoTabInfo;

        if (selectedComboTab is not null && prepared.Tab is not null && !AreSameVideoChoice(selectedComboTab, prepared.Tab))
        {
            AppLogger.Warn($"openpip-selected-tab-guard: prepared-target-ignored; selectedTabId={selectedComboTab.TabId}; selectedSession={selectedComboTab.VideoSessionId}; selectedStable={selectedComboTab.StableVideoKey}; selectedDomain={selectedComboTab.Domain}; preparedTabId={prepared.Tab.TabId}; preparedSession={prepared.Tab.VideoSessionId}; preparedStable={prepared.Tab.StableVideoKey}; preparedDomain={prepared.Tab.Domain}");
            prepared = (null, null);
            _armedPipTargetSlotNumber = 0;
            _armedPipPairTab = null;
            _armedPipPairUntilUtc = DateTime.MinValue;
        }

        var usingPreparedTarget = prepared.Tab is not null && prepared.Slot is not null;

        var tab = selectedComboTab ?? prepared.Tab ?? GetVideoTabForManualOpenPip();
        if (tab is null)
        {
            SetStatus("Escolha um vídeo na lista ou prepare um slot antes de clicar em Abrir PiP");
            AppLogger.Warn("Abrir PiP manual ignorado: nenhum vídeo selecionado e nenhum slot preparado/vinculado");
            return;
        }

        if (string.Equals(mode, "Abrir PiP", StringComparison.Ordinal))
        {
            if (BlockDuplicateActiveVideoOpen(tab, "Abrir PiP"))
                return;
        }
        else if (BlockDuplicateActiveVideoOpen(tab, mode))
        {
            return;
        }

        var targetSlot = prepared.Slot
            ?? (forceNextFreeSlot
                ? GetTargetSlotForNewPip()
                : GetTargetSlotForOpenPipWithoutPrepared(tab, mode));

        if (!TryBeginOpenPipAttempt(targetSlot, tab, mode, seconds: 10))
            return;

        ShadowMirrorManualOpenRequested(targetSlot, tab, "OpenPipManualFromSelectedVideoAsync/after-trybegin-ok");

        try
        {
            var diagnosticPreArmDelayMs = !usingPreparedTarget
                ? GetReactorPreArmDiagnosticDelayMs()
                : 0;

            if (!usingPreparedTarget)
            {
                MarkSlotAwaitingPip(targetSlot);
                _armedPipTargetSlotNumber = targetSlot.Number;
                if (diagnosticPreArmDelayMs == 0)
                    ArmPreparedPipPair(targetSlot, tab, "manual-open/normal");
                StoreSlotPair(targetSlot.Number, tab);
            }
            else
            {
                _armedPipTargetSlotNumber = targetSlot.Number;
                AppLogger.Info($"Abrir PiP manual: usando preparação existente; slot={targetSlot.Number}; tabId={tab.TabId}; session={tab.VideoSessionId}; stable={tab.StableVideoKey}");
            }

            _armedPipExistingHandles = _discovery.FindPipWindows()
                .Select(window => window.Handle)
                .Concat(Slots.Where(slot => slot.Window is not null).Select(slot => slot.Window!.Handle))
                .ToHashSet();
            BeginAutoPairProof(targetSlot, tab, _armedPipExistingHandles, forceNextFreeSlot ? "open-all" : "manual-open");

            SelectedSlot = targetSlot;
            SlotsList.SelectedItem = targetSlot;
            RefreshSlotState(targetSlot);
            RefreshSlotPairVisual(targetSlot);
            RefreshVideoPickerVisualStates();
            UpdateSelectedActions(setStatus: false);
            UpdateSelectedPipNotice();
            UpdatePairPreviewNotice();

            AppLogger.Warn($"Abrir PiP manual acionado: slot={targetSlot.Number}; tabId={tab.TabId}; preparadoExistente={usingPreparedTarget}; session={tab.VideoSessionId}; stable={tab.StableVideoKey}; title={tab.Title}; url={tab.Url}; handlesExistentes={_armedPipExistingHandles.Count}");

            // FocusVideoTabAsync can restore and foreground the browser before the physical
            // shortcut service has a chance to cloak it. Apply the same pre-focus cloak used
            // by AutoReturn so manual opening never exposes the browser frame.
            var manualPreFocusBrowserHwnd = IntPtr.Zero;
            try
            {
                var preFocusCandidates = FindBrowserWindowCandidates(tab);
                if (preFocusCandidates.Count > 0)
                {
                    manualPreFocusBrowserHwnd = preFocusCandidates[0].Handle;
                    var cloakDiagnostic = VideoCommandService.PrepareBrowserForegroundCloak(manualPreFocusBrowserHwnd);
                    AppLogger.Info($"manual-open-browser-prefocus-cloak: slot={targetSlot.Number}; tabId={tab.TabId}; hwnd=0x{manualPreFocusBrowserHwnd.ToInt64():X}; diagnostic={cloakDiagnostic}");
                    _ = Win32.DwmFlush();
                    await Task.Delay(24);
                }
                else
                {
                    AppLogger.Info($"manual-open-browser-prefocus-cloak-skipped: slot={targetSlot.Number}; tabId={tab.TabId}; reason=no-browser-candidate");
                }
            }
            catch (Exception ex)
            {
                AppLogger.Warn($"manual-open-browser-prefocus-cloak-error: slot={targetSlot.Number}; tabId={tab.TabId}; error={ex.Message}");
            }

            try
            {
                var focusClients = await _extensionBridge.FocusVideoTabAsync(tab.TabId);
                AppLogger.Info($"Abrir PiP manual: foco da aba solicitado; slot={targetSlot.Number}; tabId={tab.TabId}; conexoes={focusClients}");
            }
            catch (Exception ex)
            {
                AppLogger.Warn($"Abrir PiP manual: falha ao focar aba; slot={targetSlot.Number}; tabId={tab.TabId}; erro={ex.Message}");
            }

            await Task.Delay(100);

            var sent = await VideoCommandService.SendOpenPictureInPictureShortcutToForegroundAsync(tab.Domain, tab.Title);
            AppLogger.Warn($"Abrir PiP manual: Ctrl+Shift+] físico enviado; slot={targetSlot.Number}; tabId={tab.TabId}; ok={sent}; diag={VideoCommandService.LastInputDiagnostic}");

            if (diagnosticPreArmDelayMs > 0)
            {
                AppLogger.Warn(
                    $"window-event-reactor-pre-arm-diagnostic-delay: enabled=True; mode=manual-open; " +
                    $"delayMs={diagnosticPreArmDelayMs}; slot={targetSlot.Number}; pairKey={tab.PairKey}; " +
                    $"environment={ReactorPreArmDiagnosticDelayEnvironmentVariable}");
                await Task.Delay(diagnosticPreArmDelayMs);
                ArmPreparedPipPair(targetSlot, tab, "manual-open/diagnostic-delayed");
            }

            _armedPipPairTimer.Start();

            var currentHandle = await WaitForInitialOpenHwndAsync(targetSlot, tab, "manual-open/shortcut", timeoutMs: 700);
            if (currentHandle != IntPtr.Zero)
            {
                SetStatus($"PiP {targetSlot.Number} aberto e navegador minimizado");
                AppLogger.Info($"Abrir PiP manual: slot confirmado e navegador minimizado; slot={targetSlot.Number}; handle=0x{currentHandle.ToInt64():X}");
                QueueStableGroupLayout($"manual-open/shortcut/slot-{targetSlot.Number}");
                EndOpenPipAttempt(targetSlot, tab, mode, "slot-ja-visivel");
                return;
            }

            // Dê prioridade a qualquer CapturePreparedPipWindow já enfileirado no Dispatcher
            // antes de decidir que a primeira abertura falhou.
            await System.Windows.Threading.Dispatcher.Yield(DispatcherPriority.Background);

            if (TryCancelInitialOpenRetryAfterConfirmedCapture(
                    targetSlot,
                    tab,
                    mode,
                    checkpoint: "before-physical-retry",
                    layoutSource: $"manual-open/retry-cancelled/slot-{targetSlot.Number}"))
                return;

            AppLogger.Warn($"initial-open-physical-shortcut-retry-start: slot={targetSlot.Number}; tabId={tab.TabId}; reason=no-hwnd-after-first-shortcut");
            try
            {
                if (manualPreFocusBrowserHwnd == IntPtr.Zero)
                {
                    var retryCandidates = FindBrowserWindowCandidates(tab);
                    if (retryCandidates.Count > 0)
                        manualPreFocusBrowserHwnd = retryCandidates[0].Handle;
                }

                if (manualPreFocusBrowserHwnd != IntPtr.Zero)
                {
                    var retryCloakDiagnostic = VideoCommandService.PrepareBrowserForegroundCloak(manualPreFocusBrowserHwnd);
                    AppLogger.Info($"manual-open-browser-retry-prefocus-cloak: slot={targetSlot.Number}; tabId={tab.TabId}; hwnd=0x{manualPreFocusBrowserHwnd.ToInt64():X}; diagnostic={retryCloakDiagnostic}");
                    _ = Win32.DwmFlush();
                    await Task.Delay(24);
                }

                if (TryCancelInitialOpenRetryAfterConfirmedCapture(
                        targetSlot,
                        tab,
                        mode,
                        checkpoint: "after-retry-cloak-before-focus",
                        layoutSource: $"manual-open/retry-cancelled/slot-{targetSlot.Number}"))
                    return;

                await _extensionBridge.FocusVideoTabAsync(tab.TabId);
                await Task.Delay(120);
            }
            catch (Exception ex)
            {
                AppLogger.Warn($"initial-open-physical-shortcut-retry-focus-failed: slot={targetSlot.Number}; tabId={tab.TabId}; erro={ex.Message}");
            }

            await System.Windows.Threading.Dispatcher.Yield(DispatcherPriority.Background);

            if (TryCancelInitialOpenRetryAfterConfirmedCapture(
                    targetSlot,
                    tab,
                    mode,
                    checkpoint: "before-physical-retry-send",
                    layoutSource: $"manual-open/retry-cancelled/slot-{targetSlot.Number}"))
                return;

            var retrySent = await VideoCommandService.SendOpenPictureInPictureShortcutToForegroundAsync(tab.Domain, tab.Title);
            AppLogger.Warn($"initial-open-physical-shortcut-retry-sent: slot={targetSlot.Number}; tabId={tab.TabId}; ok={retrySent}; diag={VideoCommandService.LastInputDiagnostic}");
            currentHandle = await WaitForInitialOpenHwndAsync(targetSlot, tab, "manual-open/physical-retry", timeoutMs: 900);
            if (currentHandle != IntPtr.Zero)
            {
                SetStatus($"PiP {targetSlot.Number} aberto após repetição e navegador minimizado");
                AppLogger.Info($"initial-open-physical-shortcut-retry-confirmed: slot={targetSlot.Number}; handle=0x{currentHandle.ToInt64():X}");
                QueueStableGroupLayout($"manual-open/physical-retry/slot-{targetSlot.Number}");
                EndOpenPipAttempt(targetSlot, tab, mode, "capturado-apos-retry-fisico");
                return;
            }

            await System.Windows.Threading.Dispatcher.Yield(DispatcherPriority.Background);

            if (TryCancelInitialOpenRetryAfterConfirmedCapture(
                    targetSlot,
                    tab,
                    mode,
                    checkpoint: "before-extension-fallback",
                    layoutSource: $"manual-open/retry-cancelled/slot-{targetSlot.Number}"))
                return;

            try
            {
                var clients = await _extensionBridge.SendOpenPictureInPictureAsync(tab.VideoSessionId, tab.StableVideoKey, tab.TabId);
                AppLogger.Info($"Abrir PiP manual: fallback requestPictureInPicture enviado por ação do usuário; slot={targetSlot.Number}; tabId={tab.TabId}; conexoes={clients}");
            }
            catch (Exception ex)
            {
                AppLogger.Warn($"Abrir PiP manual: fallback requestPictureInPicture falhou ao enviar; slot={targetSlot.Number}; tabId={tab.TabId}; erro={ex.Message}");
            }

            currentHandle = await WaitForInitialOpenHwndAsync(targetSlot, tab, "manual-open/fallback", timeoutMs: 850);
            if (currentHandle != IntPtr.Zero)
            {
                SetStatus($"PiP {targetSlot.Number} aberto e navegador minimizado");
                AppLogger.Info($"Abrir PiP manual: fallback confirmado e navegador minimizado; slot={targetSlot.Number}; handle=0x{currentHandle.ToInt64():X}");
                QueueStableGroupLayout($"manual-open/fallback/slot-{targetSlot.Number}");
                EndOpenPipAttempt(targetSlot, tab, mode, "capturado-apos-fallback");
                return;
            }

            SetStatus($"Abrir PiP enviado para o slot {targetSlot.Number}. Se a janela PiP aparecer, o app vai capturar/religar nesse mesmo slot.");

            // Mantém o lock por uma janela curta após o fallback para impedir clique por cima
            // enquanto o HWND ainda pode nascer e ser capturado pelo timer armado.
            _openPipAttemptUntilUtc = DateTime.UtcNow.AddSeconds(4);
        }
        catch
        {
            EndOpenPipAttempt(targetSlot, tab, mode, "excecao");
            throw;
        }
    }

    private async Task OpenPipFocuslessFromSelectedVideoAsync()
    {
        ReleaseExpiredOpenPipAttemptLock();

        var focuslessAttemptId = $"focusless-{DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()}-{Guid.NewGuid():N}".Substring(0, 31);
        var previousForeground = GetForegroundWindow();
        var previousForegroundDescription = DescribeForegroundWindow(previousForeground);
        PipSlot? targetSlot = null;
        VideoTabInfo? tab = null;
        var restoredFocus = false;
        var hwndCaptured = false;
        var finalReasonCode = string.Empty;

        AppLogger.Info($"focusless-open-start: attemptId={focuslessAttemptId}; previousForeground={previousForegroundDescription}");

        if (!_extensionBridge.IsConnected)
        {
            SetStatus("Extensão não conectada. Recarregue a extensão e tente novamente");
            TryRestoreForegroundWindow(previousForeground, focuslessAttemptId);
            return;
        }

        try
        {
            await _extensionBridge.RequestVideoSessionsSnapshotAsync();
            await Task.Delay(180);
        }
        catch { }

        var prepared = GetPreparedOpenPipTarget();
        var usingPreparedTarget = prepared.Tab is not null && prepared.Slot is not null;

        tab = prepared.Tab ?? GetVideoTabForManualOpenPip();
        if (tab is null)
        {
            SetStatus("Escolha um vídeo na lista ou prepare um slot antes de clicar em Abrir sem foco");
            AppLogger.Warn($"focusless-final-result: attemptId={focuslessAttemptId}; result=failed; reasonCode=target-not-found; reasonMessage=no-video-selected; restoredFocus=False; hwndCaptured=False");
            TryRestoreForegroundWindow(previousForeground, focuslessAttemptId);
            return;
        }

        if (BlockDuplicateActiveVideoOpen(tab, "Abrir sem foco"))
        {
            TryRestoreForegroundWindow(previousForeground, focuslessAttemptId);
            return;
        }

        targetSlot = prepared.Slot
            ?? GetTargetSlotForOpenPipWithoutPrepared(tab, "Abrir sem foco");

        if (!TryBeginOpenPipAttempt(targetSlot, tab, "Abrir sem foco", seconds: 10))
        {
            TryRestoreForegroundWindow(previousForeground, focuslessAttemptId);
            return;
        }

        try
        {
            if (!usingPreparedTarget)
            {
                MarkSlotAwaitingPip(targetSlot);
                _armedPipTargetSlotNumber = targetSlot.Number;
                _armedPipPairTab = tab;
                _armedPipPairStartedUtc = DateTime.UtcNow;
                _armedPipPairUntilUtc = DateTime.UtcNow.AddSeconds(35);
                _armedPipCandidateWindow = null;
                _armedPipCandidateDetectedUtc = DateTime.MinValue;
                StoreSlotPair(targetSlot.Number, tab);
            }
            else
            {
                _armedPipTargetSlotNumber = targetSlot.Number;
                AppLogger.Info($"Abrir sem foco: usando preparação existente; attemptId={focuslessAttemptId}; slot={targetSlot.Number}; tabId={tab.TabId}; session={tab.VideoSessionId}; stable={tab.StableVideoKey}");
            }

            _armedPipExistingHandles = _discovery.FindPipWindows()
                .Select(window => window.Handle)
                .Concat(Slots.Where(slot => slot.Window is not null).Select(slot => slot.Window!.Handle))
                .ToHashSet();

            SelectedSlot = targetSlot;
            SlotsList.SelectedItem = targetSlot;
            RefreshSlotState(targetSlot);
            RefreshSlotPairVisual(targetSlot);
            RefreshVideoPickerVisualStates();
            UpdateSelectedActions(setStatus: false);
            UpdateSelectedPipNotice();
            UpdatePairPreviewNotice();

            AppLogger.Warn($"Abrir sem foco acionado: attemptId={focuslessAttemptId}; slot={targetSlot.Number}; tabId={tab.TabId}; preparadoExistente={usingPreparedTarget}; session={tab.VideoSessionId}; stable={tab.StableVideoKey}; title={tab.Title}; url={tab.Url}; handlesExistentes={_armedPipExistingHandles.Count}; previousForeground={previousForegroundDescription}");

            try
            {
                var focusClients = await _extensionBridge.FocusVideoTabAsync(tab.TabId);
                AppLogger.Info($"focusless-focus-tab: attemptId={focuslessAttemptId}; slot={targetSlot.Number}; tabId={tab.TabId}; conexoes={focusClients}; ok=True");
            }
            catch (Exception ex)
            {
                finalReasonCode = "focus-tab-failed";
                AppLogger.Warn($"focusless-focus-tab: attemptId={focuslessAttemptId}; slot={targetSlot.Number}; tabId={tab.TabId}; ok=False; reason={ex.Message}");
            }

            await Task.Delay(650);

            var sent = await VideoCommandService.SendOpenPictureInPictureShortcutToForegroundAsync(tab.Domain, tab.Title);
            AppLogger.Warn($"focusless-shortcut-sent: attemptId={focuslessAttemptId}; slot={targetSlot.Number}; tabId={tab.TabId}; ok={sent}; diagnostic={VideoCommandService.LastInputDiagnostic}");

            _armedPipPairTimer.Start();

            await Task.Delay(120);

            restoredFocus = TryRestoreForegroundWindow(previousForeground, focuslessAttemptId);

            await Task.Delay(650);

            var currentHandle = targetSlot.Window?.Handle ?? IntPtr.Zero;
            if (currentHandle != IntPtr.Zero && PipWindowService.IsUsable(currentHandle))
            {
                hwndCaptured = true;
                var browserMinimized = VideoCommandService.TryMinimizeExpectedBrowserWindow(tab.Domain, tab.Title);
                AppLogger.Info($"focusless-browser-minimized-after-confirmation: attemptId={focuslessAttemptId}; slot={targetSlot.Number}; tabId={tab.TabId}; ok={browserMinimized}; diagnostic={VideoCommandService.LastInputDiagnostic}");
                SetStatus($"PiP {targetSlot.Number} aberto e navegador minimizado");
                AppLogger.Info($"focusless-final-result: attemptId={focuslessAttemptId}; slot={targetSlot.Number}; tabId={tab.TabId}; result=confirmed; reasonCode=; reasonMessage=hwnd-captured; restoredFocus={restoredFocus}; hwndCaptured=True; handle=0x{currentHandle.ToInt64():X}");
                EndOpenPipAttempt(targetSlot, tab, "Abrir sem foco", "slot-ja-visivel");
                return;
            }

            try
            {
                var clients = await _extensionBridge.SendOpenPictureInPictureAsync(tab.VideoSessionId, tab.StableVideoKey, tab.TabId);
                AppLogger.Info($"Abrir sem foco: fallback requestPictureInPicture enviado; attemptId={focuslessAttemptId}; slot={targetSlot.Number}; tabId={tab.TabId}; conexoes={clients}");
            }
            catch (Exception ex)
            {
                AppLogger.Warn($"Abrir sem foco: fallback requestPictureInPicture falhou; attemptId={focuslessAttemptId}; slot={targetSlot.Number}; tabId={tab.TabId}; erro={ex.Message}");
            }

            await Task.Delay(700);

            currentHandle = targetSlot.Window?.Handle ?? IntPtr.Zero;
            if (currentHandle != IntPtr.Zero && PipWindowService.IsUsable(currentHandle))
            {
                hwndCaptured = true;
                var browserMinimized = VideoCommandService.TryMinimizeExpectedBrowserWindow(tab.Domain, tab.Title);
                AppLogger.Info($"focusless-browser-minimized-after-confirmation: attemptId={focuslessAttemptId}; slot={targetSlot.Number}; tabId={tab.TabId}; ok={browserMinimized}; diagnostic={VideoCommandService.LastInputDiagnostic}");
                SetStatus($"PiP {targetSlot.Number} aberto e navegador minimizado");
                AppLogger.Info($"focusless-final-result: attemptId={focuslessAttemptId}; slot={targetSlot.Number}; tabId={tab.TabId}; result=confirmed; reasonCode=; reasonMessage=hwnd-captured-after-fallback; restoredFocus={restoredFocus}; hwndCaptured=True; handle=0x{currentHandle.ToInt64():X}");
                EndOpenPipAttempt(targetSlot, tab, "Abrir sem foco", "capturado-apos-fallback");
                return;
            }

            finalReasonCode = string.IsNullOrWhiteSpace(finalReasonCode) ? "hwnd-not-found" : finalReasonCode;
            SetStatus("Tentativa falhou. Pode tentar novamente.");
            AppLogger.Warn($"focusless-final-result: attemptId={focuslessAttemptId}; slot={targetSlot.Number}; tabId={tab.TabId}; result=failed; reasonCode={finalReasonCode}; reasonMessage=hwnd-not-confirmed; restoredFocus={restoredFocus}; hwndCaptured=False");

            if (_armedPipTargetSlotNumber == targetSlot.Number
                && _armedPipPairTab is not null
                && AreSameVideoChoice(_armedPipPairTab, tab))
            {
                ClearArmedPipPairState(stopTimer: true);
            }

            EndOpenPipAttempt(targetSlot, tab, "Abrir sem foco", "falha-final");
        }
        catch (Exception ex)
        {
            finalReasonCode = "unknown-error";
            AppLogger.Warn($"focusless-final-result: attemptId={focuslessAttemptId}; slot={targetSlot?.Number ?? 0}; tabId={tab?.TabId ?? 0}; result=failed; reasonCode={finalReasonCode}; reasonMessage={ex.Message}; restoredFocus={restoredFocus}; hwndCaptured={hwndCaptured}");
            if (targetSlot is not null && tab is not null)
                EndOpenPipAttempt(targetSlot, tab, "Abrir sem foco", "excecao");
            throw;
        }
        finally
        {
            if (!restoredFocus)
                restoredFocus = TryRestoreForegroundWindow(previousForeground, focuslessAttemptId);
        }
    }

    private async Task OpenPipSilentFromSelectedVideoAsync()
    {
        ReleaseExpiredOpenPipAttemptLock();

        var silentAttemptId = $"silent-{DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()}-{Guid.NewGuid():N}".Substring(0, 28);
        _lastSilentAttemptId = silentAttemptId;
        _lastSilentExtensionReasonCode = string.Empty;
        _lastSilentExtensionReasonMessage = string.Empty;
        _lastSilentExtensionEnterPipSeen = false;

        if (!_extensionBridge.IsConnected)
        {
            SetStatus("Extensão não conectada. Recarregue a extensão e tente novamente");
            return;
        }

        try
        {
            await _extensionBridge.RequestVideoSessionsSnapshotAsync();
            await Task.Delay(180);
        }
        catch { }

        var prepared = GetPreparedOpenPipTarget();
        var selectedComboTab = VideoTabsCombo?.SelectedItem as VideoTabInfo;

        if (selectedComboTab is not null && prepared.Tab is not null && !AreSameVideoChoice(selectedComboTab, prepared.Tab))
        {
            AppLogger.Warn($"openpip-selected-tab-guard: prepared-target-ignored; selectedTabId={selectedComboTab.TabId}; selectedSession={selectedComboTab.VideoSessionId}; selectedStable={selectedComboTab.StableVideoKey}; selectedDomain={selectedComboTab.Domain}; preparedTabId={prepared.Tab.TabId}; preparedSession={prepared.Tab.VideoSessionId}; preparedStable={prepared.Tab.StableVideoKey}; preparedDomain={prepared.Tab.Domain}");
            prepared = (null, null);
            _armedPipTargetSlotNumber = 0;
            _armedPipPairTab = null;
            _armedPipPairUntilUtc = DateTime.MinValue;
        }

        var usingPreparedTarget = prepared.Tab is not null && prepared.Slot is not null;

        var tab = selectedComboTab ?? prepared.Tab ?? GetVideoTabForManualOpenPip();
        if (tab is null)
        {
            SetStatus("Escolha um vídeo na lista ou prepare um slot antes de clicar em Abrir silencioso");
            AppLogger.Warn("Abrir silencioso ignorado: nenhum vídeo selecionado e nenhum slot preparado/vinculado");
            return;
        }

        if (BlockDuplicateActiveVideoOpen(tab, "Silencioso"))
            return;

        var targetSlot = prepared.Slot
            ?? GetTargetSlotForOpenPipWithoutPrepared(tab, "Abrir PiP");

        AppLogger.Info($"silent-preflight-start: attemptId={silentAttemptId}; slot={targetSlot.Number}; tabId={tab.TabId}; session={tab.VideoSessionId}; stable={tab.StableVideoKey}; domain={tab.Domain}; prepared={usingPreparedTarget}; selectedSlot={SelectedSlot?.Number}; targetSlot={targetSlot.Number}; title={tab.Title}");

        if (!TryBeginOpenPipAttempt(targetSlot, tab, "Silencioso", seconds: 7))
            return;

        try
        {
            if (!usingPreparedTarget)
            {
                MarkSlotAwaitingPip(targetSlot);
                _armedPipTargetSlotNumber = targetSlot.Number;
                _armedPipPairTab = tab;
                _armedPipPairStartedUtc = DateTime.UtcNow;
                _armedPipPairUntilUtc = DateTime.UtcNow.AddSeconds(35);
                _armedPipCandidateWindow = null;
                _armedPipCandidateDetectedUtc = DateTime.MinValue;
                StoreSlotPair(targetSlot.Number, tab);
            }
            else
            {
                _armedPipTargetSlotNumber = targetSlot.Number;
                AppLogger.Info($"Abrir silencioso: usando preparação existente; slot={targetSlot.Number}; tabId={tab.TabId}; session={tab.VideoSessionId}; stable={tab.StableVideoKey}");
            }

            _armedPipExistingHandles = _discovery.FindPipWindows()
                .Select(window => window.Handle)
                .Concat(Slots.Where(slot => slot.Window is not null).Select(slot => slot.Window!.Handle))
                .ToHashSet();

            SelectedSlot = targetSlot;
            SlotsList.SelectedItem = targetSlot;
            RefreshSlotState(targetSlot);
            RefreshSlotPairVisual(targetSlot);
            RefreshVideoPickerVisualStates();
            UpdateSelectedActions(setStatus: false);
            UpdateSelectedPipNotice();
            UpdatePairPreviewNotice();

            _armedPipPairTimer.Start();

            AppLogger.Warn($"Abrir silencioso acionado: slot={targetSlot.Number}; tabId={tab.TabId}; preparadoExistente={usingPreparedTarget}; session={tab.VideoSessionId}; stable={tab.StableVideoKey}; title={tab.Title}; url={tab.Url}; handlesExistentes={_armedPipExistingHandles.Count}");

            try
            {
                var clients = await _extensionBridge.SendOpenPictureInPictureSilentAsync(tab.VideoSessionId, tab.StableVideoKey, tab.TabId, silentAttemptId);
                AppLogger.Info($"Abrir silencioso: pedido enviado pela extensão sem focar aba; attemptId={silentAttemptId}; slot={targetSlot.Number}; tabId={tab.TabId}; conexoes={clients}");
            }
            catch (Exception ex)
            {
                AppLogger.Warn($"Abrir silencioso: falha ao enviar pedido pela extensão; slot={targetSlot.Number}; tabId={tab.TabId}; erro={ex.Message}");
                SetStatus($"Abrir silencioso falhou ao enviar para o slot {targetSlot.Number}: {ex.Message}");
                EndOpenPipAttempt(targetSlot, tab, "Silencioso", "falha-envio");
                return;
            }

            AppLogger.Info($"hwnd-scan-start: attemptId={silentAttemptId}; slot={targetSlot.Number}; handlesBefore={_armedPipExistingHandles.Count}; aguardandoMs=3800");
            await Task.Delay(3800);

            var handlesAfter = _discovery.FindPipWindows().Select(window => window.Handle).ToHashSet();
            var newHandles = handlesAfter.Where(handle => !_armedPipExistingHandles.Contains(handle)).ToList();
            AppLogger.Info($"hwnd-scan-after: attemptId={silentAttemptId}; slot={targetSlot.Number}; handlesBefore={_armedPipExistingHandles.Count}; handlesAfter={handlesAfter.Count}; newHandleFound={newHandles.Count > 0}; newHandles={string.Join(",", newHandles.Select(handle => $"0x{handle.ToInt64():X}"))}");

            var currentHandle = targetSlot.Window?.Handle ?? IntPtr.Zero;
            if (currentHandle != IntPtr.Zero && PipWindowService.IsUsable(currentHandle))
            {
                SetStatus($"PiP {targetSlot.Number} aberto silenciosamente");
                AppLogger.Info($"Abrir silencioso confirmado: attemptId={silentAttemptId}; slot={targetSlot.Number}; handle=0x{currentHandle.ToInt64():X}");
                AppLogger.Info($"silent-final-result: attemptId={silentAttemptId}; slot={targetSlot.Number}; tabId={tab.TabId}; result=confirmed; reasonCode=; reasonMessage=hwnd-captured; enterPipSeen=unknown; hwndCaptured=true; handle=0x{currentHandle.ToInt64():X}");
                EndOpenPipAttempt(targetSlot, tab, "Silencioso", "confirmado");
                return;
            }

            var finalReasonCode = string.IsNullOrWhiteSpace(_lastSilentExtensionReasonCode)
                ? "hwnd-not-found"
                : _lastSilentExtensionReasonCode;
            var finalReasonMessage = string.IsNullOrWhiteSpace(_lastSilentExtensionReasonMessage)
                ? "app-did-not-capture-hwnd"
                : _lastSilentExtensionReasonMessage;
            var finalStatus = finalReasonCode == "hwnd-not-found"
                ? $"Tentativa silenciosa não confirmada no slot {targetSlot.Number} [hwnd-not-found]. Use Abrir PiP para o caminho forte."
                : $"Silencioso falhou no slot {targetSlot.Number} [{finalReasonCode}]. Use Abrir PiP para o caminho forte.";

            SetStatus(finalStatus);
            AppLogger.Warn($"Abrir silencioso não confirmado: attemptId={silentAttemptId}; slot={targetSlot.Number}; tabId={tab.TabId}; reasonCode={finalReasonCode}; reasonMessage={finalReasonMessage}; nenhum HWND capturado em 3,8s");
            AppLogger.Warn($"silent-final-result: attemptId={silentAttemptId}; slot={targetSlot.Number}; tabId={tab.TabId}; result=failed; reasonCode={finalReasonCode}; reasonMessage={finalReasonMessage}; enterPipSeen={_lastSilentExtensionEnterPipSeen}; hwndCaptured=false");

            // Libera cedo o silencioso para permitir o caminho forte, mas sem deixar cliques sobrepostos
            // enquanto a tentativa ainda está em andamento.
            EndOpenPipAttempt(targetSlot, tab, "Silencioso", "nao-confirmado");
        }
        catch
        {
            EndOpenPipAttempt(targetSlot, tab, "Silencioso", "excecao");
            throw;
        }
    }

    private (PipSlot? Slot, VideoTabInfo? Tab) GetPreparedOpenPipTarget()
    {
        if (_armedPipTargetSlotNumber <= 0 || _armedPipPairTab is null)
            return (null, null);

        if (DateTime.UtcNow > _armedPipPairUntilUtc)
            return (null, null);

        var slot = Slots.FirstOrDefault(item => item.Number == _armedPipTargetSlotNumber);
        if (slot is null)
            return (null, null);

        if (slot.State != PipSlotState.AwaitingPip && slot.Window is not null)
            return (null, null);

        return (slot, _armedPipPairTab);
    }

    private VideoTabInfo? GetVideoTabForManualOpenPip()
    {
        // 9.32.04:
        // O clique em "Abrir PiP" deve obedecer primeiro a aba/vídeo selecionado na lista.
        // Antes, se o slot selecionado tinha vínculo antigo, o app podia ignorar a seleção visual
        // e abrir/focar a aba errada.
        if (VideoTabsCombo?.SelectedItem is VideoTabInfo selectedTab)
        {
            AppLogger.Warn($"openpip-selected-tab-guard: source=combo-selected; tabId={selectedTab.TabId}; session={selectedTab.VideoSessionId}; stable={selectedTab.StableVideoKey}; domain={selectedTab.Domain}; title={selectedTab.Title}");
            return selectedTab;
        }

        if (SelectedSlot is not null && SlotHasVideoPair(SelectedSlot))
        {
            if (_slotVideoPairs.TryGetValue(SelectedSlot.Number, out var pairKey) && !string.IsNullOrWhiteSpace(pairKey))
            {
                var byPair = VideoTabs
                    .Where(tab => string.Equals(tab.PairKey, pairKey, StringComparison.OrdinalIgnoreCase)
                        || string.Equals(tab.VideoSessionId, pairKey, StringComparison.OrdinalIgnoreCase))
                    .OrderByDescending(tab => tab.IsPlaying)
                    .ThenByDescending(tab => tab.LastSeenUnixMs)
                    .FirstOrDefault();
                if (byPair is not null)
                {
                    AppLogger.Warn($"openpip-selected-tab-guard: source=slot-pair-fallback; slot={SelectedSlot.Number}; tabId={byPair.TabId}; session={byPair.VideoSessionId}; domain={byPair.Domain}; title={byPair.Title}");
                    return byPair;
                }
            }

            if (_slotStableVideoPairs.TryGetValue(SelectedSlot.Number, out var stableKey) && !string.IsNullOrWhiteSpace(stableKey))
            {
                var byStable = VideoTabs
                    .Where(tab => string.Equals(tab.StableVideoKey, stableKey, StringComparison.OrdinalIgnoreCase))
                    .OrderByDescending(tab => tab.IsPlaying)
                    .ThenByDescending(tab => tab.LastSeenUnixMs)
                    .FirstOrDefault();
                if (byStable is not null)
                {
                    AppLogger.Warn($"openpip-selected-tab-guard: source=slot-stable-fallback; slot={SelectedSlot.Number}; tabId={byStable.TabId}; session={byStable.VideoSessionId}; domain={byStable.Domain}; title={byStable.Title}");
                    return byStable;
                }
            }

            if (_slotPairedTabIds.TryGetValue(SelectedSlot.Number, out var tabId) && tabId > 0)
            {
                var byTab = VideoTabs
                    .Where(tab => tab.TabId == tabId)
                    .OrderByDescending(tab => tab.IsPlaying)
                    .ThenByDescending(tab => tab.LastSeenUnixMs)
                    .FirstOrDefault();
                if (byTab is not null)
                {
                    AppLogger.Warn($"openpip-selected-tab-guard: source=slot-tabid-fallback; slot={SelectedSlot.Number}; tabId={byTab.TabId}; session={byTab.VideoSessionId}; domain={byTab.Domain}; title={byTab.Title}");
                    return byTab;
                }
            }

            AppLogger.Warn($"Abrir PiP manual: slot selecionado tem vínculo, mas a sessão ativa não foi localizada; slot={SelectedSlot.Number}");
        }

        var fallback = VideoTabs
            .OrderByDescending(tab => tab.IsPlaying)
            .ThenByDescending(tab => tab.LastSeenUnixMs)
            .FirstOrDefault();

        if (fallback is not null)
            AppLogger.Warn($"openpip-selected-tab-guard: source=playing-lastseen-fallback; tabId={fallback.TabId}; session={fallback.VideoSessionId}; stable={fallback.StableVideoKey}; domain={fallback.Domain}; title={fallback.Title}");

        return fallback;
    }


    private async Task OpenPipFromSelectedVideoAsync()
    {
        if (!_extensionBridge.IsConnected)
        {
            SetStatus("Extensão não conectada. Recarregue a extensão e tente novamente");
            return;
        }

        if (VideoTabsCombo?.SelectedItem is not VideoTabInfo tab)
        {
            SetStatus("Escolha um vídeo/sessão na lista antes de preparar o PiP");
            return;
        }

        try
        {
            await _extensionBridge.RequestVideoSessionsSnapshotAsync();
        }
        catch { }

        var targetSlot = GetTargetSlotForPreparedPip(tab);
        MarkSlotAwaitingPip(targetSlot);
        _armedPipTargetSlotNumber = targetSlot.Number;
        SelectedSlot = targetSlot;
        SlotsList.SelectedItem = targetSlot;
        UpdateSelectedActions(setStatus: false);
        RefreshVideoPickerVisualStates();
        UpdatePairPreviewNotice();

        _armedPipPairTab = tab;
        _armedPipExistingHandles = _discovery.FindPipWindows()
            .Select(window => window.Handle)
            .Concat(Slots.Where(slot => slot.Window is not null).Select(slot => slot.Window!.Handle))
            .ToHashSet();
        _armedPipPairStartedUtc = DateTime.UtcNow;
        _armedPipPairUntilUtc = DateTime.UtcNow.AddSeconds(20);
        _armedPipCandidateWindow = null;
        _armedPipCandidateDetectedUtc = DateTime.MinValue;

        AppLogger.Info($"Preparar PiP armado: pairKey={tab.PairKey}; session={tab.VideoSessionId}; stable={tab.StableVideoKey}; tabId={tab.TabId}; title={tab.Title}; url={tab.Url}");

        try
        {
            await _extensionBridge.FocusVideoTabAsync(tab.TabId);
        }
        catch (Exception ex)
        {
            AppLogger.Info($"Falha ao focar aba antes de preparar PiP: {ex.Message}");
        }

        _armedPipPairTimer.Start();
        SetStatus($"Preparado no slot {targetSlot.Number}: agora clique em Abrir PiP para usar este mesmo slot, ou abra manualmente pelo navegador.");
    }

    private async Task ArmedPipPairTickAsync()
    {
        if (_armedPipPairTab is null && !TryRestorePreparedPipStateFromOpenAttempt("armed-pip-timer"))
        {
            _armedPipPairTimer.Stop();
            return;
        }

        var tab = _armedPipPairTab;
        if (tab is null)
        {
            _armedPipPairTimer.Stop();
            return;
        }

        if (DateTime.UtcNow > _armedPipPairUntilUtc)
        {
            var expired = tab.ShortDescription;
            ClearArmedPipPairState();
            SetStatus($"Preparação do PiP expirou para {expired}. Clique em Preparar PiP e tente novamente");
            return;
        }

        var confirmedEvent = FindRecentEnterPipEventFor(tab, _armedPipPairStartedUtc);

        var discovered = _discovery.FindPipWindows();
        var newWindow = discovered.FirstOrDefault(window => !_armedPipExistingHandles.Contains(window.Handle));

        if (newWindow is null)
        {
            if (confirmedEvent is not null)
                SetStatus($"Evento PiP confirmado para {tab.ShortDescription}. Aguardando janela PiP aparecer...");
            return;
        }

        if (confirmedEvent is null)
        {
            // A janela apareceu antes do evento da extensão. Espera um curto intervalo
            // para permitir que enterpictureinpicture chegue e confirme a sessão.
            if (_armedPipCandidateWindow is null || _armedPipCandidateWindow.Handle != newWindow.Handle)
            {
                _armedPipCandidateWindow = newWindow;
                _armedPipCandidateDetectedUtc = DateTime.UtcNow;
                SetStatus($"Nova janela PiP detectada. Aguardando confirmação da extensão para {tab.ShortDescription}...");
                return;
            }

            if ((DateTime.UtcNow - _armedPipCandidateDetectedUtc).TotalMilliseconds < 1500)
                return;
        }

        // A callback do DispatcherTimer pode continuar executando mesmo depois de Stop().
        // Confirma novamente que esta ainda é a preparação oficial antes de finalizar pelo fallback legado.
        if (_armedPipPairTab is null
            || !string.Equals(_armedPipPairTab.PairKey, tab.PairKey, StringComparison.OrdinalIgnoreCase)
            || _armedPipTargetSlotNumber <= 0
            || DateTime.UtcNow > _armedPipPairUntilUtc)
        {
            _armedPipPairTimer.Stop();
            AppLogger.Info(
                $"armed-pip-fallback-cancelled-after-confirmation: hwnd=0x{newWindow.Handle.ToInt64():X}; " +
                $"reason=prepared-state-no-longer-current; pairKey={tab.PairKey}");
            return;
        }

        var targetSlotNumber = _armedPipTargetSlotNumber;
        var targetSlot = Slots.FirstOrDefault(slot => slot.Number == targetSlotNumber);
        if (targetSlot?.Window is not null)
        {
            if (targetSlot.Window.Handle == newWindow.Handle)
            {
                _armedPipPairTimer.Stop();
                AppLogger.Info(
                    $"armed-pip-fallback-cancelled-after-confirmation: hwnd=0x{newWindow.Handle.ToInt64():X}; " +
                    $"slot={targetSlotNumber}; capturedHwnd=0x{targetSlot.Window.Handle.ToInt64():X}; " +
                    $"reason=target-slot-already-confirmed-same-hwnd");
                return;
            }

            AppLogger.Warn(
                $"auto-return-target-slot-hwnd-mismatch: attemptId={_activeAutoReturnAttemptId}; slot={targetSlotNumber}; " +
                $"capturedHwnd=0x{targetSlot.Window.Handle.ToInt64():X}; newHwnd=0x{newWindow.Handle.ToInt64():X}; " +
                $"action=reassociate-expected-new-hwnd");
        }

        var existingOwner = Slots.FirstOrDefault(slot => slot.Window is not null && slot.Window.Handle == newWindow.Handle);
        if (existingOwner is not null && existingOwner.Number != targetSlotNumber)
        {
            var claimedByCurrentAttempt = !string.IsNullOrWhiteSpace(_activeAutoReturnAttemptId)
                && _autoReturnCandidateAttemptByHwnd.TryGetValue(newWindow.Handle, out var claimedAttemptId)
                && string.Equals(claimedAttemptId, _activeAutoReturnAttemptId, StringComparison.Ordinal);

            if (!claimedByCurrentAttempt)
            {
                _armedPipPairTimer.Stop();
                AppLogger.Info(
                    $"armed-pip-fallback-cancelled-after-confirmation: hwnd=0x{newWindow.Handle.ToInt64():X}; " +
                    $"slot={targetSlotNumber}; ownerSlot={existingOwner.Number}; reason=hwnd-already-owned-unclaimed");
                return;
            }

            _armedPipPairTimer.Stop();
            AppLogger.Warn(
                $"auto-return-hwnd-owner-mismatch: attemptId={_activeAutoReturnAttemptId}; expectedSlot={targetSlotNumber}; " +
                $"ownerSlot={existingOwner.Number}; hwnd=0x{newWindow.Handle.ToInt64():X}; action=reject-owned-by-other-slot-fallback");
            return;
        }

        ClearArmedPipPairState(stopTimer: true);
        await Dispatcher.BeginInvoke(() => CapturePreparedPipWindow(newWindow, tab, confirmedEvent, targetSlotNumber));
    }

    private PipSlot GetPreparedTargetSlotOrFallback(VideoTabInfo tab, int targetSlotNumber)
    {
        if (targetSlotNumber > 0)
        {
            var prepared = Slots.FirstOrDefault(slot => slot.Number == targetSlotNumber);
            if (prepared is not null)
            {
                AppLogger.Info($"Abrir/Preparar PiP: respeitando slot preparado {prepared.Number}; tabId={tab.TabId}; session={tab.VideoSessionId}; stable={tab.StableVideoKey}");
                return prepared;
            }
        }

        return GetTargetSlotForPreparedPip(tab);
    }

    private void CapturePreparedPipWindow(PipWindowInfo newWindow, VideoTabInfo tab, VideoPipEventInfo? confirmedEvent, int targetSlotNumber = 0)
    {
        var hadCapturedBefore = Slots.Any(slot => slot.Window is not null);
        var slot = GetPreparedTargetSlotOrFallback(tab, targetSlotNumber);
        var oldHandle = slot.Window?.Handle ?? IntPtr.Zero;
        var reconnectReference = GetReconnectReferenceRect(slot);
        if (oldHandle != IntPtr.Zero && oldHandle != newWindow.Handle)
        {
            _hiddenPipRects.Remove(oldHandle);
            _lockedGroupModelRects.Remove(oldHandle);
            AppLogger.Info($"Preparar PiP: sessão já vinculada ao slot {slot.Number}; atualizando HWND antigo=0x{oldHandle.ToInt64():X}, novo=0x{newWindow.Handle.ToInt64():X}");
        }
        slot.Window = newWindow;
        slot.IsHidden = false;
        StoreSlotPair(slot.Number, tab);
        RefreshVideoPickerVisualStates();
        ClearAwaitingPipSlot(slot.Number);
        ClearLostSlotState(slot);
        MarkSlotActive(slot);
        var preferredAspectRatio = tab.IntrinsicAspectRatio;
        var slotGeometryBound = BindSlotNavigationGeometryAuthority(slot, newWindow.Handle, "CapturePreparedPipWindow", preferredAspectRatio);
        if (!slotGeometryBound && oldHandle != newWindow.Handle && reconnectReference.IsValid)
            RestoreReconnectedWindowPosition(slot, oldHandle, newWindow.Handle, BuildSafeNavigationGeometry(reconnectReference, preferredAspectRatio), "CapturePreparedPipWindow");
        else if (!slotGeometryBound)
            ApplyPreparedCaptureGeometryGuard(slot, newWindow.Handle, preferredAspectRatio, "CapturePreparedPipWindow");
        ShadowMirrorPipCaptured(slot, newWindow.Handle, "CapturePreparedPipWindow");
        SelectedSlot = slot;
        SlotsList.SelectedItem = slot;

        _allHidden = false;
        VisibilityButton.Content = "Ocultar PiPs";
        _toolbar?.SetHiddenState(false);

        if (!hadCapturedBefore)
        {
            RebuildGroupFromLayout(preferPanelTemplateAnchor: true, resizeToTargets: false, saveLockedModel: _groupLocked);
        }
        else
        {
            RefreshCapturedRectsOnly();
            if (_groupLocked)
                SaveLockedGroupModelFromCurrentRects();
            EnsureVisiblePipsTopMost(force: true);
            PositionToolbar();
            RefreshPipDragTargets();
        }

        UpdateCounts();
        UpdateSelectedActions();
        UpdateSelectedPipNotice();

        var confirmText = confirmedEvent is not null ? "com confirmação da extensão" : "sem evento PiP confirmado";
        SetStatus($"PiP {slot.Number} capturado e vinculado a {tab.ShortDescription} ({confirmText})");
        AppLogger.Info($"PiP preparado capturado e vinculado: slot={slot.Number}; handle=0x{newWindow.Handle.ToInt64():X}; pairKey={tab.PairKey}; stable={tab.StableVideoKey}; tabId={tab.TabId}; title={tab.Title}; url={tab.Url}; confirmacao={(confirmedEvent is not null ? confirmedEvent.EventName : "nenhuma")}");
        CompleteAutoPairProof(slot, tab, newWindow, "CapturePreparedPipWindow");
        if (oldHandle != IntPtr.Zero && oldHandle != newWindow.Handle)
            ClassifyReconnectedNewHwnd(slot, oldHandle, newWindow.Handle, "CapturePreparedPipWindow", "prepared-capture-new-hwnd");
        CancelLegacyArmedPipFallbackAfterConfirmedCapture(slot, tab, newWindow.Handle);
        EndOpenPipAttempt(slot, tab, "captura", "hwnd-capturado");
    }

    private void CancelLegacyArmedPipFallbackAfterConfirmedCapture(PipSlot slot, VideoTabInfo tab, IntPtr confirmedHandle)
    {
        if (_armedPipPairTab is null
            || _armedPipTargetSlotNumber != slot.Number
            || !string.Equals(_armedPipPairTab.PairKey, tab.PairKey, StringComparison.OrdinalIgnoreCase))
            return;

        AppLogger.Info(
            $"armed-pip-fallback-cancelled-after-confirmation: hwnd=0x{confirmedHandle.ToInt64():X}; " +
            $"slot={slot.Number}; pairKey={tab.PairKey}; reason=capture-confirmed");
        ClearArmedPipPairState(stopTimer: true);
    }

    private void ClearArmedPipPairState(bool stopTimer = true)
    {
        unchecked { _reactorAssistedCandidateGeneration++; }
        _armedPipPairTab = null;
        _armedPipExistingHandles.Clear();
        _armedPipCandidateWindow = null;
        _armedPipCandidateDetectedUtc = DateTime.MinValue;
        _armedPipTargetSlotNumber = 0;
        _armedPipPairStartedUtc = DateTime.MinValue;
        _armedPipPairUntilUtc = DateTime.MinValue;
        ClearAwaitingPipSlot();
        if (stopTimer)
            _armedPipPairTimer.Stop();
        RefreshVideoPickerVisualStates();
        UpdatePairPreviewNotice();
    }

    private void OnPictureInPictureEvent(VideoPipEventInfo? info)
    {
        _automationCoordinator.ObserveExtensionPipEvent(info?.ToString() ?? "pip-event", 0, IntPtr.Zero);

        if (info is null)
            return;

        if (string.IsNullOrWhiteSpace(info.VideoSessionId) && string.IsNullOrWhiteSpace(info.StableVideoKey))
            return;

        var nowMs = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        _recentPipEvents.RemoveAll(item => nowMs - item.EventUnixMs > 30000);
        _recentPipEvents.Add(info);

        AppLogger.Info($"Evento PiP da extensão: event={info.EventName}; session={info.VideoSessionId}; stable={info.StableVideoKey}; tabId={info.TabId}; page={info.PageInstanceId}; element={info.ElementInstanceId}; url={info.Url}");

        if (_armedPipPairTab is not null && info.IsEnter && DoesEventMatchTab(info, _armedPipPairTab))
            SetStatus($"Evento PiP confirmado para {_armedPipPairTab.ShortDescription}. Capture/aguarde a janela PiP.");
    }

    private VideoPipEventInfo? FindRecentEnterPipEventFor(VideoTabInfo tab, DateTime sinceUtc)
    {
        var sinceMs = new DateTimeOffset(sinceUtc).ToUnixTimeMilliseconds() - 750;
        return _recentPipEvents
            .Where(info => info.IsEnter && info.EventUnixMs >= sinceMs && DoesEventMatchTab(info, tab))
            .OrderByDescending(info => info.EventUnixMs)
            .FirstOrDefault();
    }

    private static bool DoesEventMatchTab(VideoPipEventInfo info, VideoTabInfo tab)
    {
        if (!string.IsNullOrWhiteSpace(info.VideoSessionId) && string.Equals(info.VideoSessionId, tab.VideoSessionId, StringComparison.OrdinalIgnoreCase))
            return true;
        if (!string.IsNullOrWhiteSpace(info.StableVideoKey) && string.Equals(info.StableVideoKey, tab.StableVideoKey, StringComparison.OrdinalIgnoreCase))
            return true;
        if (!string.IsNullOrWhiteSpace(info.PageInstanceId) && string.Equals(info.PageInstanceId, tab.PageInstanceId, StringComparison.OrdinalIgnoreCase)
            && !string.IsNullOrWhiteSpace(info.ElementInstanceId) && string.Equals(info.ElementInstanceId, tab.ElementInstanceId, StringComparison.OrdinalIgnoreCase))
            return true;
        return false;
    }

    private void StoreSlotPair(int slotNumber, VideoTabInfo tab)
    {
        foreach (var pair in _slotVideoPairs.ToArray())
        {
            if (pair.Key == slotNumber) continue;
            var sameSession = !string.IsNullOrWhiteSpace(tab.PairKey) && string.Equals(pair.Value, tab.PairKey, StringComparison.OrdinalIgnoreCase);
            var sameStable = _slotStableVideoPairs.TryGetValue(pair.Key, out var stable)
                && !string.IsNullOrWhiteSpace(stable)
                && string.Equals(stable, tab.StableVideoKey, StringComparison.OrdinalIgnoreCase)
                && (!_slotPairedTabIds.TryGetValue(pair.Key, out var oldTabId) || oldTabId == tab.TabId || oldTabId <= 0);

            if (sameSession || sameStable)
            {
                _slotVideoPairs.Remove(pair.Key);
                _slotStableVideoPairs.Remove(pair.Key);
                _slotPairedTabIds.Remove(pair.Key);
                _slotPairDomains.Remove(pair.Key);
                _slotPairUrls.Remove(pair.Key);
                var oldSlot = Slots.FirstOrDefault(slot => slot.Number == pair.Key);
                if (oldSlot is not null)
                {
                    RefreshSlotState(oldSlot);
                    RefreshSlotPairVisual(oldSlot);
                }
                AppLogger.Info($"Vínculo duplicado removido do slot {pair.Key}; sessão agora pertence ao slot {slotNumber}");
            }
        }

        _slotVideoPairs[slotNumber] = tab.PairKey;
        if (!string.IsNullOrWhiteSpace(tab.StableVideoKey))
            _slotStableVideoPairs[slotNumber] = tab.StableVideoKey;
        if (tab.TabId > 0)
            _slotPairedTabIds[slotNumber] = tab.TabId;
        var domain = GetDomainForTab(tab);
        if (!string.IsNullOrWhiteSpace(domain))
            _slotPairDomains[slotNumber] = domain;
        if (!string.IsNullOrWhiteSpace(tab.Url))
            _slotPairUrls[slotNumber] = tab.Url;
        if (double.IsFinite(tab.IntrinsicAspectRatio)
            && tab.IntrinsicAspectRatio >= 0.20
            && tab.IntrinsicAspectRatio <= 6.00)
            _slotIntrinsicContentAspectRatios[slotNumber] = tab.IntrinsicAspectRatio;
        else
            _slotIntrinsicContentAspectRatios.Remove(slotNumber);

        var slot = Slots.FirstOrDefault(item => item.Number == slotNumber);
        if (slot is not null)
            RefreshSlotPairVisual(slot);
    }

    private PipSlot? FindExistingSlotForVideoTab(VideoTabInfo tab)
    {
        foreach (var slot in Slots.OrderBy(slot => slot.Number))
        {
            if (_slotVideoPairs.TryGetValue(slot.Number, out var pairKey) && !string.IsNullOrWhiteSpace(pairKey)
                && (string.Equals(pairKey, tab.PairKey, StringComparison.OrdinalIgnoreCase)
                    || string.Equals(pairKey, tab.VideoSessionId, StringComparison.OrdinalIgnoreCase)))
                return slot;

            if (_slotStableVideoPairs.TryGetValue(slot.Number, out var stableKey) && !string.IsNullOrWhiteSpace(stableKey)
                && string.Equals(stableKey, tab.StableVideoKey, StringComparison.OrdinalIgnoreCase)
                && (!_slotPairedTabIds.TryGetValue(slot.Number, out var tabId) || tabId == tab.TabId || tabId <= 0))
                return slot;
        }

        return null;
    }

    private PipSlot? FindActiveSlotForVideoTab(VideoTabInfo tab)
    {
        return Slots
            .OrderBy(slot => slot.Number)
            .FirstOrDefault(slot => slot.Window is not null
                && PipWindowService.IsUsable(slot.Window.Handle)
                && FindExistingSlotForVideoTab(tab)?.Number == slot.Number);
    }

    private bool BlockDuplicateActiveVideoOpen(VideoTabInfo tab, string mode)
    {
        var activeSlot = FindActiveSlotForVideoTab(tab);
        if (activeSlot is null)
            return false;

        var message = $"Esse vídeo já está aberto em PiP no slot {activeSlot.Number}.";
        SetStatus(message);
        AppLogger.Warn($"openpip-duplicate-video-blocked: mode={mode}; activeSlot={activeSlot.Number}; tabId={tab.TabId}; pairKey={tab.PairKey}; stable={tab.StableVideoKey}");
        return true;
    }

    private PipSlot GetTargetSlotForPreparedPip(VideoTabInfo tab)
    {
        var existing = FindExistingSlotForVideoTab(tab);
        if (existing is not null)
            return existing;

        return GetTargetSlotForNewPip();
    }

    private bool CanReuseSelectedSlotForOpen(PipSlot slot)
    {
        if (slot.Window is not null)
            return false;

        if (slot.State == PipSlotState.AwaitingPip || slot.State == PipSlotState.Offline)
            return true;

        if (SlotHasVideoPair(slot))
            return true;

        return slot.State == PipSlotState.Free;
    }

    private PipSlot GetTargetSlotForOpenPipWithoutPrepared(VideoTabInfo tab, string mode)
    {
        // 9.31.10:
        // Abrir PiP sem preparação ativa NÃO deve chamar GetTargetSlotForPreparedPip(tab),
        // porque esse método reaproveita vínculo antigo via FindExistingSlotForVideoTab(tab)
        // e pode forçar tudo no mesmo slot.
        //
        // Só reutiliza slot antigo quando o slot selecionado está sem HWND/aguardando/offline.
        // Se o slot selecionado já tem PiP ativo, abre em novo slot livre.
        if (SelectedSlot is not null && CanReuseSelectedSlotForOpen(SelectedSlot))
        {
            AppLogger.Info($"{mode}: usando slot selecionado apto para abrir/reabrir; slot={SelectedSlot.Number}; estado={SelectedSlot.State}; vinculado={SlotHasVideoPair(SelectedSlot)}; window={(SelectedSlot.Window is not null)}");
            return SelectedSlot;
        }

        var free = GetTargetSlotForNewPip();
        AppLogger.Info($"{mode}: sem preparação ativa; usando próximo slot livre {free.Number}; tabId={tab.TabId}; session={tab.VideoSessionId}; stable={tab.StableVideoKey}");
        return free;
    }

    private PipSlot GetTargetSlotForNewPip()
    {
        ClearGhostSlotsForNewPip("Preparar PiP");

        if (SelectedSlot is not null && SelectedSlot.Window is null && !SlotHasVideoPair(SelectedSlot) && SelectedSlot.State != PipSlotState.AwaitingPip)
            return SelectedSlot;

        var free = Slots.OrderBy(slot => slot.Number).FirstOrDefault(slot => slot.Window is null && !SlotHasVideoPair(slot) && slot.State != PipSlotState.AwaitingPip);
        if (free is not null)
            return free;

        if (Slots.Count < 10)
        {
            SetSlotCount(Slots.Count + 1);
            return Slots[^1];
        }

        return Slots.OrderBy(slot => slot.Number).FirstOrDefault(slot => slot.Window is null && slot.State != PipSlotState.AwaitingPip)
            ?? Slots.OrderBy(slot => slot.Number).First();
    }

    private void ClearSelectedPipPairButton_Click(object sender, RoutedEventArgs e)
    {
        if (SelectedSlot is null)
        {
            SetStatus("Nenhum PiP selecionado");
            return;
        }

        if (_slotVideoPairs.Remove(SelectedSlot.Number))
        {
            _slotStableVideoPairs.Remove(SelectedSlot.Number);
            _slotPairedTabIds.Remove(SelectedSlot.Number);
            _slotPairDomains.Remove(SelectedSlot.Number);
            // Base limpa: nada extra para remover além dos vínculos principais.
            RefreshSlotState(SelectedSlot);
            RefreshSlotPairVisual(SelectedSlot);
            RefreshVideoPickerVisualStates();
            UpdateSelectedPipNotice();
            SetStatus($"Vínculo do PiP {SelectedSlot.Number} removido");
        }
        else
        {
            SetStatus($"PiP {SelectedSlot.Number} não tinha vínculo");
        }
    }


    private void MarkAutoReturnPending(PipSlot slot, string reason)
    {
        // A perda do PiP precisa ser visível para o Shadow independentemente da política de AutoRetorno.
        // Apenas a criação da tentativa de reconexão depende do AutoRetorno estar habilitado.
        if (slot.Window is not null)
            ShadowMirrorPipLost(slot, slot.Window.Handle, "MarkAutoReturnPending/loss-before-policy/" + reason);

        ArmAutoAdvanceLostPipWatch(slot, reason);

        if (!ShouldAutoReturnSlot(slot, $"pending:{reason}")) return;

        var now = DateTime.UtcNow;
        if (_autoReturnCooldownUntilBySlot.TryGetValue(slot.Number, out var globalCooldown) && now < globalCooldown)
        {
            AppLogger.Info($"auto-return-pending-skipped: slot={slot.Number}; reason={reason}; skipReason=cooldown-active; cooldownUntil={globalCooldown:O}; remainingMs={(globalCooldown - now).TotalMilliseconds:0}");
            return;
        }

        if (_autoReturnStatesBySlot.TryGetValue(slot.Number, out var existing))
        {
            if (existing.InProgress)
            {
                AppLogger.Info($"auto-return-pending-skipped: slot={slot.Number}; reason={reason}; skipReason=in-progress");
                return;
            }

            if (now < existing.CooldownUntilUtc)
            {
                _autoReturnCooldownUntilBySlot[slot.Number] = existing.CooldownUntilUtc;
                AppLogger.Info($"auto-return-pending-skipped: slot={slot.Number}; reason={reason}; skipReason=state-cooldown-active; cooldownUntil={existing.CooldownUntilUtc:O}");
                return;
            }
        }

        var tabId = _slotPairedTabIds.TryGetValue(slot.Number, out var pairedTabId) ? pairedTabId : 0;
        var oldSession = _slotVideoPairs.TryGetValue(slot.Number, out var session) ? session : string.Empty;
        var oldStable = _slotStableVideoPairs.TryGetValue(slot.Number, out var stable) ? stable : string.Empty;
        var oldUrl = _slotPairUrls.TryGetValue(slot.Number, out var url) ? url : string.Empty;

        if (tabId <= 0 && string.IsNullOrWhiteSpace(oldSession) && string.IsNullOrWhiteSpace(oldStable))
            return;

        var requiresRealVideoChange = IsVideoNavigationAutoReturn(slot.Number, now, out var eligibilityMode);
        _videoSwitchPreservationBySlot.TryGetValue(slot.Number, out var navigationPreservation);

        var expectedBrowserProcess = slot.Window?.ProcessName
            ?? existing?.ExpectedBrowserProcess
            ?? string.Empty;

        var queuePosition = _autoReturnStatesBySlot.ContainsKey(slot.Number)
            ? Math.Max(1, _autoReturnStatesBySlot.Count)
            : _autoReturnStatesBySlot.Count + 1;
        var maxPendingAgeSeconds = AutoReturnBurstPolicy.GetPendingMaxAgeSeconds(
            queuePosition,
            AutoReturnMaxAgeSeconds);
        _autoReturnStatesBySlot[slot.Number] = new AutoReturnSlotState
        {
            SlotNumber = slot.Number,
            TabId = tabId,
            OldSession = oldSession,
            OldStable = oldStable,
            OldUrl = oldUrl,
            ExpectedBrowserProcess = expectedBrowserProcess,
            PendingSinceUtc = now,
            MaxPendingAgeSeconds = maxPendingAgeSeconds,
            Reason = reason,
            RequiresRealVideoChange = requiresRealVideoChange,
            EligibilityMode = eligibilityMode,
            CancellationGeneration = GetAutoReturnCancellationGeneration(slot.Number),
            BlockSameVideoFallback = requiresRealVideoChange && (navigationPreservation?.BlockSameVideoFallback ?? false),
            CommandTargetAssetId = navigationPreservation?.CommandTargetAssetId ?? string.Empty,
            CommandTargetOperationId = navigationPreservation?.CommandTargetOperationId ?? string.Empty,
            CommandTargetGeneration = navigationPreservation?.CommandTargetGeneration ?? 0,
            CommandTargetNextIndex = navigationPreservation?.CommandTargetNextIndex ?? -1
        };

        MarkVideoSwitchPreservationAutoReturnOwned(slot, reason, "MarkAutoReturnPending");

        AppLogger.Warn($"auto-return-pending: slot={slot.Number}; tabId={tabId}; reason={reason}; policy=SlotDiscrete; slotEnabled={IsAutoReturnEnabledForSlot(slot.Number)}; queueSize={_autoReturnStatesBySlot.Count}; queuePosition={queuePosition}; maxPendingAgeSeconds={maxPendingAgeSeconds}; eligibilityMode={eligibilityMode}; requiresRealVideoChange={requiresRealVideoChange}; oldSession={oldSession}; oldStable={oldStable}; oldUrl={oldUrl}; blockSameVideoFallback={_autoReturnStatesBySlot[slot.Number].BlockSameVideoFallback}; commandTargetAssetId={_autoReturnStatesBySlot[slot.Number].CommandTargetAssetId}; commandTargetGeneration={_autoReturnStatesBySlot[slot.Number].CommandTargetGeneration}; commandTargetOperationId={_autoReturnStatesBySlot[slot.Number].CommandTargetOperationId}");
        BeginFixedLayoutRecoveryCycle(slot.Number, reason);
    }

    private bool IsVideoNavigationAutoReturn(int slotNumber, DateTime now, out string eligibilityMode)
    {
        if (_videoSwitchPreservationBySlot.TryGetValue(slotNumber, out var preservation)
            && preservation.ExpiresUtc > now
            && (string.Equals(preservation.CommandType, "next", StringComparison.OrdinalIgnoreCase)
                || string.Equals(preservation.CommandType, "previous", StringComparison.OrdinalIgnoreCase)))
        {
            var ageMs = (now - preservation.StartedUtc).TotalMilliseconds;
            var correlatedWithCommand = ageMs >= 0 && ageMs <= VideoNavigationLossCorrelationMs;
            var hasObservedNavigationEvidence = preservation.NewVideoDetected;

            if (correlatedWithCommand || hasObservedNavigationEvidence)
            {
                eligibilityMode = hasObservedNavigationEvidence
                    ? "video-navigation-real-change-observed"
                    : "video-navigation-real-change-correlated";
                AppLogger.Info($"auto-return-trigger-classified-navigation: slot={slotNumber}; command={preservation.CommandType}; ageMs={ageMs:0}; correlationMs={VideoNavigationLossCorrelationMs}; newVideoDetected={preservation.NewVideoDetected}; mode={eligibilityMode}");
                return true;
            }

            AppLogger.Info($"auto-return-stale-navigation-context-ignored: slot={slotNumber}; command={preservation.CommandType}; ageMs={ageMs:0}; correlationMs={VideoNavigationLossCorrelationMs}; newVideoDetected={preservation.NewVideoDetected}; expiresUtc={preservation.ExpiresUtc:O}");
        }

        eligibilityMode = "same-video-reopen";
        return false;
    }

    private async Task AutoReturnTickAsync()
    {
        NormalizeSlotAutoReturnSettings(migrateFromGlobal: false);
        if (!IsAnySlotAutoReturnEnabled())
        {
            CancelAllAutoReturnPending("AutoReturnTickAsync/all-slots-disabled");
            return;
        }
        CancelAutoReturnPendingForDisabledSlots("AutoReturnTickAsync/disabled-slot-cleanup");
        if (!_extensionBridge.IsConnected) return;

        // Antes de desistir deste tick, libera o lock de "Abrir PiP" se ele já expirou.
        // Sem isso, um slot lento para reaparecer (ex.: player sem API de PiP) segurava
        // _openPipAttemptInProgress e travava o AutoReturn de TODOS os outros slots até
        // o watchdog ser acionado por outro caminho de código.
        ReleaseExpiredOpenPipAttemptLock();
        if (_openPipAttemptInProgress || _openAllPipsInProgress)
        {
            if (_autoReturnStatesBySlot.Count > 0)
            {
                AppLogger.InfoAggregated(
                    "auto-return-deferred-by-open-operation",
                    TimeSpan.FromSeconds(2),
                    $"auto-return-deferred-by-open-operation: checkpoint=tick; pending={_autoReturnStatesBySlot.Count}; " +
                    $"openAttempt={_openPipAttemptInProgress}; openAll={_openAllPipsInProgress}; " +
                    $"armedSlot={_armedPipTargetSlotNumber}; lockSlot={_openPipAttemptSlotNumber}");
            }
            return;
        }

        var now = DateTime.UtcNow;
        foreach (var state in _autoReturnStatesBySlot.Values
                     .OrderBy(item => item.PendingSinceUtc)
                     .ThenBy(item => item.SlotNumber)
                     .ToArray())
        {
            if (state.InProgress) continue;

            var slotPolicyProbe = Slots.FirstOrDefault(item => item.Number == state.SlotNumber);
            if (slotPolicyProbe is null || !ShouldAutoReturnSlot(slotPolicyProbe, "tick"))
            {
                _autoReturnStatesBySlot.Remove(state.SlotNumber);
                continue;
            }
            if (now < state.CooldownUntilUtc) continue;

            var stateMaxPendingAgeSeconds = state.MaxPendingAgeSeconds > 0
                ? state.MaxPendingAgeSeconds
                : AutoReturnMaxAgeSeconds;
            if ((now - state.PendingSinceUtc).TotalSeconds > stateMaxPendingAgeSeconds)
            {
                var expiredSlot = Slots.FirstOrDefault(item => item.Number == state.SlotNumber);
                if (expiredSlot is not null)
                    ShadowMirrorReconnectFailed(expiredSlot, "auto-return-expired", "AutoReturnTickAsync/expired");

                _autoReturnStatesBySlot.Remove(state.SlotNumber);
                AppLogger.Warn($"auto-return-expired: slot={state.SlotNumber}; tabId={state.TabId}; age={(now - state.PendingSinceUtc).TotalSeconds:0.0}s; maxAgeSeconds={stateMaxPendingAgeSeconds}; pendingStates={_autoReturnStatesBySlot.Count}");
                continue;
            }

            var slot = Slots.FirstOrDefault(item => item.Number == state.SlotNumber);
            if (slot is null || !SlotHasPairRecoverySignal(slot.Number))
            {
                if (slot is not null)
                    ShadowMirrorReconnectFailed(slot, "slot-missing-pair-signal", "AutoReturnTickAsync/no-pair-signal");

                _autoReturnStatesBySlot.Remove(state.SlotNumber);
                continue;
            }

            if (slot.Window is not null && PipWindowService.IsUsable(slot.Window.Handle))
            {
                if (_shadowReconnectAttemptIdBySlot.ContainsKey(slot.Number))
                {
                    ShadowMirrorReconnectSucceeded(slot, slot.Window.Handle, "AutoReturnTickAsync/already-active");
                    ShadowLogLegacyComparison(slot, "AutoReturnTickAsync/already-active", "legacy-slot-already-active");
                }

                _autoReturnStatesBySlot.Remove(state.SlotNumber);
                continue;
            }

            var tab = FindAutoReturnCandidate(state);
            if (tab is null) continue;

            if (state.TerminalPassiveWatch)
            {
                state.TerminalPassiveWatch = false;
                state.TerminalTargetUnavailableLogged = false;
                state.TerminalNavigationPendingSinceUtc = DateTime.MinValue;
                state.TerminalNavigationPendingSignature = string.Empty;
                state.ReadinessDeferrals = 0;
                AppLogger.Info($"auto-return-terminal-navigation-resumed: slot={state.SlotNumber}; tabId={tab.TabId}; terminalNavigationGeneration={state.TerminalNavigationGeneration}; session={tab.PairKey}; stable={tab.StableVideoKey}; url={tab.Url}; readyState={tab.ReadyState}; hasSource={tab.HasSource}; action=resume-physical-return");
            }

            state.InProgress = true;
            _ = TryAutoReturnSlotAsync(slot, tab, state);
            return;
        }
    }

    private VideoTabInfo ResolveFreshAutoReturnTabSnapshot(VideoTabInfo current)
    {
        var now = DateTime.UtcNow;
        var normalizedCurrentUrl = NormalizeAutoReturnIdentityUrl(current.Url);
        return _videoTabCache.Values
            .Where(value => (now - value.LastSeenUtc).TotalSeconds <= VideoTabsCacheTtlSeconds)
            .Where(value => value.Tab.TabId == current.TabId)
            .OrderByDescending(value => string.Equals(
                NormalizeAutoReturnIdentityUrl(value.Tab.Url),
                normalizedCurrentUrl,
                StringComparison.OrdinalIgnoreCase))
            .ThenByDescending(value => string.Equals(value.Tab.PairKey, current.PairKey, StringComparison.OrdinalIgnoreCase))
            .ThenByDescending(value => value.LastSeenUtc)
            .ThenByDescending(value => value.Tab.IsPlaying)
            .Select(value => value.Tab)
            .FirstOrDefault() ?? current;
    }

    private static bool IsAutoReturnTargetPlaybackReady(VideoTabInfo tab) =>
        tab.HasSource && tab.ReadyState >= 2 && !tab.IsEnded;

    private static bool IsAutoReturnTargetHardNotReady(VideoTabInfo tab) =>
        AutoReturnBurstPolicy.IsPlaybackHardNotReady(
            tab.HasSource,
            tab.ReadyState,
            tab.IsEnded);

    private bool IsCommandNavigationTargetMinimallyReady(AutoReturnSlotState state, VideoTabInfo tab) =>
        state.BlockSameVideoFallback
        && IsRealAutoReturnVideoChange(state, tab)
        && !tab.IsEnded
        && (tab.HasSource || tab.ReadyState >= 1);

    private async Task<(VideoTabInfo Tab, bool Ready)> WaitForAutoReturnTargetPlaybackReadyAsync(
        PipSlot slot,
        VideoTabInfo initialTab,
        AutoReturnSlotState state,
        string attemptId)
    {
        var tab = initialTab;
        var realChange = IsRealAutoReturnVideoChange(state, tab);
        var hardNotReady = IsAutoReturnTargetHardNotReady(tab);

        // A reabertura do mesmo vídeo pode continuar usando o caminho rápido quando
        // o elemento já possui metadados. Porém readyState 0/HAVE_NOTHING não é um
        // alvo físico válido e anteriormente gerava atalhos repetidos sem novo HWND.
        if (IsAutoReturnTargetPlaybackReady(tab) || (!realChange && !hardNotReady))
            return (tab, true);

        var startedUtc = DateTime.UtcNow;
        var nextSnapshotUtc = DateTime.MinValue;
        var poll = 0;
        AppLogger.Info($"auto-return-target-ready-wait-start: attemptId={attemptId}; slot={slot.Number}; tabId={tab.TabId}; maxWaitMs={AutoReturnTargetReadyMaxWaitMs}; pollMs={AutoReturnTargetReadyPollMs}; realChange={realChange}; hardNotReady={hardNotReady}; readyState={tab.ReadyState}; hasSource={tab.HasSource}; playing={tab.IsPlaying}; url={tab.Url}");

        while ((DateTime.UtcNow - startedUtc).TotalMilliseconds < AutoReturnTargetReadyMaxWaitMs)
        {
            if (!IsAutoReturnAttemptCurrent(slot, state, attemptId, "target-ready-wait", logCancellation: false))
                return (tab, false);

            if (DateTime.UtcNow >= nextSnapshotUtc)
            {
                nextSnapshotUtc = DateTime.UtcNow.AddMilliseconds(240);
                try { await _extensionBridge.RequestVideoSessionsSnapshotAsync(); } catch { }
            }

            await Task.Delay(AutoReturnTargetReadyPollMs);
            ApplyVideoTabsFromCache(force: true);
            var refreshed = ResolveFreshAutoReturnTabSnapshot(tab);
            if (refreshed.TabId == tab.TabId)
                tab = refreshed;

            poll++;
            realChange = IsRealAutoReturnVideoChange(state, tab);
            hardNotReady = IsAutoReturnTargetHardNotReady(tab);
            var elapsedMs = (DateTime.UtcNow - startedUtc).TotalMilliseconds;
            var minimallyReady = elapsedMs >= AutoReturnCommandNavigationMinimalReadyGraceMs
                && IsCommandNavigationTargetMinimallyReady(state, tab);
            if (IsAutoReturnTargetPlaybackReady(tab) || minimallyReady || (!realChange && !hardNotReady))
            {
                if (minimallyReady && !IsAutoReturnTargetPlaybackReady(tab))
                    AppLogger.Info($"auto-return-command-target-minimal-ready: attemptId={attemptId}; slot={slot.Number}; tabId={tab.TabId}; elapsedMs={elapsedMs:0}; readyState={tab.ReadyState}; hasSource={tab.HasSource}; action=physical-return-without-full-media-wait");
                AppLogger.Info($"auto-return-target-ready: attemptId={attemptId}; slot={slot.Number}; tabId={tab.TabId}; elapsedMs={(DateTime.UtcNow - startedUtc).TotalMilliseconds:0}; polls={poll}; realChange={realChange}; hardNotReady={hardNotReady}; readyState={tab.ReadyState}; hasSource={tab.HasSource}; playing={tab.IsPlaying}; currentTime={tab.CurrentTime:0.###}; url={tab.Url}");
                return (tab, true);
            }
        }

        realChange = IsRealAutoReturnVideoChange(state, tab);
        hardNotReady = IsAutoReturnTargetHardNotReady(tab);
        if (IsCommandNavigationTargetMinimallyReady(state, tab))
        {
            AppLogger.Info($"auto-return-command-target-minimal-ready: attemptId={attemptId}; slot={slot.Number}; tabId={tab.TabId}; elapsedMs={(DateTime.UtcNow - startedUtc).TotalMilliseconds:0}; readyState={tab.ReadyState}; hasSource={tab.HasSource}; action=physical-return-after-short-grace");
            return (tab, true);
        }
        AppLogger.Warn($"auto-return-target-ready-timeout: attemptId={attemptId}; slot={slot.Number}; tabId={tab.TabId}; elapsedMs={(DateTime.UtcNow - startedUtc).TotalMilliseconds:0}; realChange={realChange}; hardNotReady={hardNotReady}; readyState={tab.ReadyState}; hasSource={tab.HasSource}; playing={tab.IsPlaying}; url={tab.Url}; action=adaptive-deferral");
        return (tab, false);
    }

    private VideoTabInfo? FindAutoReturnCandidate(AutoReturnSlotState state)
    {
        var now = DateTime.UtcNow;
        var freshTabCandidates = _videoTabCache.Values
            .Where(value => (now - value.LastSeenUtc).TotalSeconds <= VideoTabsCacheTtlSeconds)
            .Select(value => value.Tab)
            .Where(tab => state.TabId <= 0 || tab.TabId == state.TabId)
            .ToList();
        var rejectedCollectionRoot = freshTabCandidates.FirstOrDefault(tab => IsPlaylistCollectionRootUrl(tab.Url));
        if (rejectedCollectionRoot is not null)
        {
            AppLogger.InfoAggregated(
                $"auto-return-candidate-rejected-playlist-root:{state.SlotNumber}",
                TimeSpan.FromMilliseconds(1000),
                $"auto-return-candidate-rejected-playlist-root: slot={state.SlotNumber}; tabId={rejectedCollectionRoot.TabId}; url={rejectedCollectionRoot.Url}; readyState={rejectedCollectionRoot.ReadyState}; hasSource={rejectedCollectionRoot.HasSource}; action=wait-for-real-player");
        }

        var freshTabs = freshTabCandidates
            .Where(tab => !IsPlaylistCollectionRootUrl(tab.Url))
            .OrderByDescending(tab => AutoReturnIdentityMatchScore(state, tab))
            .ThenByDescending(tab => tab.IsPlaying)
            .ThenByDescending(tab => tab.CurrentTime)
            .ThenBy(tab => tab.VideoIndex)
            .ToList();

        if (freshTabs.Count == 0) return null;

        var playlistCandidateAvailable = freshTabs.Any(tab => tab.PlaylistDetected
            || (!string.IsNullOrWhiteSpace(tab.Url)
                && tab.Url.Contains("/playlists/", StringComparison.OrdinalIgnoreCase)));
        var pendingElapsedMs = (now - state.PendingSinceUtc).TotalMilliseconds;
        var policyAllowsPlaylistSameVideoFallback = AutoReturnBurstPolicy.ShouldAllowPlaylistSameVideoFallback(
            state.RequiresRealVideoChange,
            playlistCandidateAvailable,
            pendingElapsedMs,
            AutoReturnPlaylistSameVideoFallbackMs);
        var oldPlaylistIndex = ResolvePlaylistIndexFromUrl(state.OldUrl);
        var resolverBlocksSameVideoFallback = freshTabs.Any(tab =>
        {
            var resolving = string.Equals(tab.NextTargetStatus, "RESOLVING", StringComparison.OrdinalIgnoreCase)
                || tab.NextTargetLifecycleState.StartsWith("RESOLVING", StringComparison.OrdinalIgnoreCase);
            var resolverObservedAdvance = string.Equals(tab.NextTargetStatus, "TARGET_RESOLVED", StringComparison.OrdinalIgnoreCase)
                && oldPlaylistIndex >= 0
                && ResolvePlaylistIndex(tab) > oldPlaylistIndex
                && !IsRealAutoReturnVideoChange(state, tab);
            return pendingElapsedMs < AutoReturnTargetResolverGraceMaxMs
                && (resolving || resolverObservedAdvance);
        });
        var commandGenerationBlocksSameVideoFallback = state.RequiresRealVideoChange && state.BlockSameVideoFallback;
        var allowPlaylistSameVideoFallback = policyAllowsPlaylistSameVideoFallback
            && !resolverBlocksSameVideoFallback
            && !commandGenerationBlocksSameVideoFallback;
        if (policyAllowsPlaylistSameVideoFallback && commandGenerationBlocksSameVideoFallback)
        {
            if (IsTerminalAutoNextState(state))
            {
                AppLogger.InfoAggregated(
                    $"auto-return-same-video-fallback-blocked-terminal-generation:{state.SlotNumber}",
                    TimeSpan.FromMilliseconds(750),
                    $"auto-return-same-video-fallback-blocked-terminal-generation: slot={state.SlotNumber}; tabId={state.TabId}; pendingMs={pendingElapsedMs:0}; navigationReason={state.NavigationReason}; terminalNavigationGeneration={state.TerminalNavigationGeneration}; action=wait-for-terminal-player");
            }
            else
            {
                AppLogger.InfoAggregated(
                    $"auto-return-same-video-fallback-blocked-command-generation:{state.SlotNumber}",
                    TimeSpan.FromMilliseconds(750),
                    $"auto-return-same-video-fallback-blocked-command-generation: slot={state.SlotNumber}; tabId={state.TabId}; pendingMs={pendingElapsedMs:0}; commandTargetAssetId={state.CommandTargetAssetId}; commandTargetGeneration={state.CommandTargetGeneration}; commandTargetOperationId={state.CommandTargetOperationId}; action=wait-for-command-target");
            }
        }
        if (policyAllowsPlaylistSameVideoFallback && resolverBlocksSameVideoFallback)
        {
            var resolverTab = freshTabs.FirstOrDefault(tab => string.Equals(tab.NextTargetStatus, "RESOLVING", StringComparison.OrdinalIgnoreCase)
                || tab.NextTargetLifecycleState.StartsWith("RESOLVING", StringComparison.OrdinalIgnoreCase)
                || (string.Equals(tab.NextTargetStatus, "TARGET_RESOLVED", StringComparison.OrdinalIgnoreCase)
                    && oldPlaylistIndex >= 0 && ResolvePlaylistIndex(tab) > oldPlaylistIndex));
            AppLogger.InfoAggregated(
                $"auto-return-same-video-fallback-deferred-target-resolution:{state.SlotNumber}",
                TimeSpan.FromMilliseconds(750),
                $"auto-return-same-video-fallback-deferred-target-resolution: slot={state.SlotNumber}; tabId={state.TabId}; pendingMs={pendingElapsedMs:0}; graceMs={AutoReturnPlaylistSameVideoFallbackMs}; resolverGraceMaxMs={AutoReturnTargetResolverGraceMaxMs}; targetStatus={resolverTab?.NextTargetStatus}; lifecycleState={resolverTab?.NextTargetLifecycleState}; targetGeneration={resolverTab?.NextTargetGeneration ?? 0}; oldPlaylistIndex={oldPlaylistIndex}; observedPlaylistIndex={ResolvePlaylistIndex(resolverTab)}; action=wait-for-real-video-change");
        }
        var eligible = state.RequiresRealVideoChange && !allowPlaylistSameVideoFallback
            ? freshTabs.Where(tab => IsRealAutoReturnVideoChange(state, tab)).ToList()
            : freshTabs;

        if (allowPlaylistSameVideoFallback)
        {
            AppLogger.InfoAggregated(
                $"auto-return-playlist-same-video-fallback:{state.SlotNumber}",
                TimeSpan.FromMilliseconds(1000),
                $"auto-return-playlist-same-video-fallback: slot={state.SlotNumber}; tabId={state.TabId}; pendingMs={pendingElapsedMs:0}; graceMs={AutoReturnPlaylistSameVideoFallbackMs}; reason=navigation-identity-not-updated; action=reopen-current-player");
        }

        if (eligible.Count == 0)
        {
            var best = freshTabs.FirstOrDefault();
            if (best is not null && IsTerminalAutoNextState(state) && HasAutoReturnUrlChanged(state, best))
                TrackTerminalNavigationPending(state, best, now);

            if (best is not null && state.SilentAttempts == 0 && state.FocuslessAttempts == 0)
            {
                AppLogger.InfoAggregated(
                    $"auto-return-waiting-real-change:{state.SlotNumber}",
                    TimeSpan.FromMilliseconds(1000),
                    $"auto-return-waiting-real-change: slot={state.SlotNumber}; tabId={best.TabId}; eligibilityMode={state.EligibilityMode}; oldSession={state.OldSession}; newSession={best.PairKey}; oldStable={state.OldStable}; newStable={best.StableVideoKey}; oldUrl={state.OldUrl}; newUrl={best.Url}; playing={best.IsPlaying}; readyState={best.ReadyState}; hasSource={best.HasSource}; currentTime={best.CurrentTime:0.###}");
            }
            return null;
        }

        var candidate = eligible[0];
        if (IsTerminalAutoNextState(state) && state.TerminalNavigationPendingSinceUtc != DateTime.MinValue)
        {
            var pendingAgeMs = (now - state.TerminalNavigationPendingSinceUtc).TotalMilliseconds;
            AppLogger.Info($"auto-return-terminal-navigation-ready: slot={state.SlotNumber}; tabId={candidate.TabId}; pendingAgeMs={pendingAgeMs:0}; terminalNavigationGeneration={state.TerminalNavigationGeneration}; session={candidate.PairKey}; stable={candidate.StableVideoKey}; url={candidate.Url}; readyState={candidate.ReadyState}; hasSource={candidate.HasSource}");
            state.TerminalNavigationPendingSinceUtc = DateTime.MinValue;
            state.TerminalNavigationPendingSignature = string.Empty;
            state.TerminalTargetUnavailableLogged = false;
        }
        var candidateKey = BuildAutoReturnCandidateKey(candidate);
        var realVideoChange = IsRealAutoReturnVideoChange(state, candidate);
        var candidateIsPlaylist = candidate.PlaylistDetected
            || (!string.IsNullOrWhiteSpace(candidate.Url)
                && candidate.Url.Contains("/playlists/", StringComparison.OrdinalIgnoreCase));
        var playlistUrlChanged = realVideoChange
            && candidateIsPlaylist
            && !string.Equals(
                NormalizeAutoReturnIdentityUrl(candidate.Url),
                NormalizeAutoReturnIdentityUrl(state.OldUrl),
                StringComparison.OrdinalIgnoreCase);
        var navigationRealChange = realVideoChange
            && (state.RequiresRealVideoChange
                || playlistUrlChanged
                || state.EligibilityMode.StartsWith("video-navigation-real-change", StringComparison.OrdinalIgnoreCase));
        var navigationFallback = allowPlaylistSameVideoFallback
            && candidateIsPlaylist
            && !realVideoChange;
        var requiredStabilizeMs = string.Equals(state.EligibilityMode, "terminal-auto-next-real-change", StringComparison.OrdinalIgnoreCase)
            && realVideoChange
            && candidate.IsPlaying
            && candidate.HasSource
            && candidate.ReadyState >= 1
                ? AutoReturnTerminalAdvanceStabilizeMs
                : navigationRealChange || navigationFallback
                    ? AutoReturnNavigationStabilizeMs
                    : AutoReturnStabilizeMs;

        if (!string.Equals(state.CandidateKey, candidateKey, StringComparison.OrdinalIgnoreCase))
        {
            state.CandidateKey = candidateKey;
            state.CandidateFirstSeenUtc = now;
            AppLogger.Info($"auto-return-player-stabilizing: slot={state.SlotNumber}; tabId={candidate.TabId}; eligibilityMode={state.EligibilityMode}; candidateKey={candidateKey}; waitMs={requiredStabilizeMs}; sessionChanged={!string.Equals(candidate.PairKey, state.OldSession, StringComparison.OrdinalIgnoreCase)}; stableChanged={!string.Equals(candidate.StableVideoKey, state.OldStable, StringComparison.OrdinalIgnoreCase)}; urlChanged={!string.Equals(candidate.Url, state.OldUrl, StringComparison.OrdinalIgnoreCase)}; readyState={candidate.ReadyState}; paused={candidate.IsPaused}; ended={candidate.IsEnded}; hasSource={candidate.HasSource}");
        }

        if (!state.RequiresRealVideoChange
            && !navigationRealChange
            && IsAutoAdvanceTerminalProbeActive(state.SlotNumber, now, out var probeAgeMs))
        {
            AppLogger.Info($"auto-return-terminal-probe-deferral: slot={state.SlotNumber}; tabId={candidate.TabId}; ageMs={probeAgeMs:0}; graceMs={AutoAdvanceTerminalProbeGraceMs}; playing={candidate.IsPlaying}; readyState={candidate.ReadyState}; paused={candidate.IsPaused}; ended={candidate.IsEnded}; hasSource={candidate.HasSource}");
            return null;
        }

        var stableMs = (now - state.CandidateFirstSeenUtc).TotalMilliseconds;
        if (stableMs < requiredStabilizeMs)
            return null;
        if (state.SilentAttempts == 0 && state.FocuslessAttempts == 0)
        {
            if (realVideoChange)
            {
                AppLogger.Info($"auto-return-new-video-detected: slot={state.SlotNumber}; tabId={candidate.TabId}; eligibilityMode={state.EligibilityMode}; oldSession={state.OldSession}; newSession={candidate.PairKey}; oldStable={state.OldStable}; newStable={candidate.StableVideoKey}; oldUrl={state.OldUrl}; newUrl={candidate.Url}; stableMs={stableMs:0}; playing={candidate.IsPlaying}; currentTime={candidate.CurrentTime:0.###}; title={candidate.Title}");

                var slot = Slots.FirstOrDefault(item => item.Number == state.SlotNumber);
                if (slot is not null)
                {
                    var newSessionForShadow = !string.IsNullOrWhiteSpace(candidate.VideoSessionId)
                        ? candidate.VideoSessionId
                        : candidate.PairKey;
                    ShadowMirrorVideoChanged(slot, newSessionForShadow, candidate.StableVideoKey, "FindAutoReturnCandidate/confirmed");
                    ShadowLogLegacyComparison(slot, "FindAutoReturnCandidate/VideoChanged", "legacy-autoreturn-new-video-detected");
                }
            }
            else
            {
                AppLogger.Info($"auto-return-same-video-reopen-ready: slot={state.SlotNumber}; tabId={candidate.TabId}; eligibilityMode={state.EligibilityMode}; stableMs={stableMs:0}; session={candidate.PairKey}; stable={candidate.StableVideoKey}; url={candidate.Url}; playing={candidate.IsPlaying}; currentTime={candidate.CurrentTime:0.###}; title={candidate.Title}");
            }
        }

        return candidate;
    }

    private static int AutoReturnIdentityMatchScore(AutoReturnSlotState state, VideoTabInfo tab)
    {
        var score = 0;
        if (!string.IsNullOrWhiteSpace(state.OldSession) && string.Equals(tab.PairKey, state.OldSession, StringComparison.OrdinalIgnoreCase)) score += 4;
        if (!string.IsNullOrWhiteSpace(state.OldStable) && string.Equals(tab.StableVideoKey, state.OldStable, StringComparison.OrdinalIgnoreCase)) score += 3;
        if (!string.IsNullOrWhiteSpace(state.OldUrl) && string.Equals(tab.Url, state.OldUrl, StringComparison.OrdinalIgnoreCase)) score += 2;
        return score;
    }

    private static string BuildAutoReturnCandidateKey(VideoTabInfo tab) =>
        $"{tab.TabId}|{tab.PairKey}|{NormalizeAutoReturnIdentityUrl(tab.Url)}|{tab.VideoIndex}";

    private static string NormalizeAutoReturnIdentityUrl(string? url)
    {
        if (string.IsNullOrWhiteSpace(url)) return string.Empty;
        return url.Split('#')[0].Trim();
    }

    private static bool IsTerminalAutoNextState(AutoReturnSlotState state) =>
        string.Equals(state.EligibilityMode, "terminal-auto-next-real-change", StringComparison.OrdinalIgnoreCase);

    private static bool HasAutoReturnUrlChanged(AutoReturnSlotState state, VideoTabInfo tab) =>
        !string.IsNullOrWhiteSpace(tab.Url)
        && !string.IsNullOrWhiteSpace(state.OldUrl)
        && !string.Equals(
            NormalizeAutoReturnIdentityUrl(tab.Url),
            NormalizeAutoReturnIdentityUrl(state.OldUrl),
            StringComparison.OrdinalIgnoreCase);

    private static bool IsRealAutoReturnVideoChange(AutoReturnSlotState state, VideoTabInfo tab)
    {
        var sessionChanged = !string.IsNullOrWhiteSpace(tab.PairKey)
            && !string.Equals(tab.PairKey, state.OldSession, StringComparison.OrdinalIgnoreCase);
        var urlChanged = HasAutoReturnUrlChanged(state, tab);
        var stableChanged = !string.IsNullOrWhiteSpace(tab.StableVideoKey)
            && !string.Equals(tab.StableVideoKey, state.OldStable, StringComparison.OrdinalIgnoreCase);
        // No auto-next terminal a URL/índice pode avançar antes de o site criar o novo
        // elemento de vídeo. URL isolada é apenas NAVIGATION_PENDING, nunca VIDEO_CHANGED.
        if (IsTerminalAutoNextState(state))
            return AutoReturnBurstPolicy.IsTerminalVideoChangeConfirmed(
                sessionChanged,
                stableChanged,
                urlChanged,
                tab.HasSource,
                tab.ReadyState,
                tab.IsEnded);

        // Fora do fluxo terminal, preserva a compatibilidade histórica.
        var stableChangedWithoutStrongIdentity = string.IsNullOrWhiteSpace(tab.PairKey)
            && string.IsNullOrWhiteSpace(state.OldSession)
            && stableChanged;
        return sessionChanged || urlChanged || stableChangedWithoutStrongIdentity;
    }

    private void TrackTerminalNavigationPending(AutoReturnSlotState state, VideoTabInfo tab, DateTime now)
    {
        var signature = $"{NormalizeAutoReturnIdentityUrl(tab.Url)}|{tab.PairKey}|{tab.StableVideoKey}|src={tab.HasSource}|rs={tab.ReadyState}";
        if (!string.Equals(state.TerminalNavigationPendingSignature, signature, StringComparison.OrdinalIgnoreCase))
        {
            state.TerminalNavigationPendingSignature = signature;
            state.TerminalNavigationPendingSinceUtc = now;
            state.TerminalTargetUnavailableLogged = false;
            state.TerminalPassiveWatch = false;
        }

        if (state.TerminalNavigationPendingSinceUtc == DateTime.MinValue)
            state.TerminalNavigationPendingSinceUtc = now;

        var pendingAgeMs = (now - state.TerminalNavigationPendingSinceUtc).TotalMilliseconds;
        AppLogger.InfoAggregated(
            $"auto-return-terminal-navigation-pending:{state.SlotNumber}",
            TimeSpan.FromMilliseconds(750),
            $"auto-return-terminal-navigation-pending: slot={state.SlotNumber}; tabId={tab.TabId}; terminalNavigationGeneration={state.TerminalNavigationGeneration}; pendingAgeMs={pendingAgeMs:0}; oldUrl={state.OldUrl}; observedUrl={tab.Url}; sessionChanged={!string.Equals(tab.PairKey, state.OldSession, StringComparison.OrdinalIgnoreCase)}; stableChanged={!string.Equals(tab.StableVideoKey, state.OldStable, StringComparison.OrdinalIgnoreCase)}; readyState={tab.ReadyState}; hasSource={tab.HasSource}; action=wait-for-structural-player-signal");

        if (pendingAgeMs >= AutoReturnTerminalTargetUnavailableMs && !state.TerminalTargetUnavailableLogged)
        {
            state.TerminalTargetUnavailableLogged = true;
            AppLogger.Warn($"auto-return-terminal-target-unavailable: slot={state.SlotNumber}; tabId={tab.TabId}; terminalNavigationGeneration={state.TerminalNavigationGeneration}; pendingAgeMs={pendingAgeMs:0}; readyState={tab.ReadyState}; hasSource={tab.HasSource}; url={tab.Url}; action=keep-slot-offline");
        }

        if (pendingAgeMs >= AutoReturnTerminalPassiveWatchMs)
        {
            if (!state.TerminalPassiveWatch)
                AppLogger.Warn($"auto-return-terminal-passive-watch-armed: slot={state.SlotNumber}; tabId={tab.TabId}; terminalNavigationGeneration={state.TerminalNavigationGeneration}; pendingAgeMs={pendingAgeMs:0}; readyState={tab.ReadyState}; hasSource={tab.HasSource}; url={tab.Url}; action=stop-active-readiness-probes");
            state.TerminalPassiveWatch = true;
        }

        state.CooldownUntilUtc = now.AddMilliseconds(AutoReturnTerminalPassiveCooldownMs);
        _autoReturnCooldownUntilBySlot[state.SlotNumber] = state.CooldownUntilUtc;
    }

    
    
    
private static string NormalizeSilentCooldownDomain(string? domain)
    {
        return string.IsNullOrWhiteSpace(domain)
            ? "unknown"
            : domain.Trim().ToLowerInvariant();
    }

    private static string BuildSilentReopenPreciseCooldownKey(string? domain, int frameId, string? reasonCode)
    {
        return $"{NormalizeSilentCooldownDomain(domain)}|frame={frameId}|reason={(string.IsNullOrWhiteSpace(reasonCode) ? "unknown" : reasonCode.Trim().ToLowerInvariant())}";
    }

    private static string BuildSilentReopenDomainReasonHintKey(string? domain, string? reasonCode)
    {
        return $"{NormalizeSilentCooldownDomain(domain)}|reason={(string.IsNullOrWhiteSpace(reasonCode) ? "unknown" : reasonCode.Trim().ToLowerInvariant())}";
    }

    private void RememberSilentReopenHardBlockHint(string? domain, int frameId, string? reasonCode, string attemptId, int slotNumber, string source)
    {
        var hintKey = BuildSilentReopenDomainReasonHintKey(domain, reasonCode);
        _silentReopenRecentHardBlockByDomainReason[hintKey] = DateTime.UtcNow.AddSeconds(SilentReopenDomainCooldownSeconds);
        _silentReopenRecentHardBlockFrameByDomainReason[hintKey] = frameId.ToString(System.Globalization.CultureInfo.InvariantCulture);
        AppLogger.Info($"pip-preserve-silent-precise-cooldown-hint-set: attemptId={attemptId}; slot={slotNumber}; hintKey={hintKey}; domain={NormalizeSilentCooldownDomain(domain)}; frameId={frameId}; reasonCode={reasonCode}; source={source}");
    }

    private void CleanupExpiredSilentReopenHardBlockHints()
    {
        var now = DateTime.UtcNow;
        foreach (var item in _silentReopenRecentHardBlockByDomainReason.ToList())
        {
            if (now < item.Value) continue;
            _silentReopenRecentHardBlockByDomainReason.Remove(item.Key);
            _silentReopenRecentHardBlockFrameByDomainReason.Remove(item.Key);
            AppLogger.Info($"pip-preserve-silent-precise-cooldown-hint-expired: hintKey={item.Key}; expiredAt={item.Value:O}");
        }
    }

    private bool TryGetSilentReopenHardBlockHint(string? domain, string? reasonCode, out int frameId, out string hintKey)
    {
        CleanupExpiredSilentReopenHardBlockHints();
        hintKey = BuildSilentReopenDomainReasonHintKey(domain, reasonCode);
        frameId = -1;
        if (!_silentReopenRecentHardBlockByDomainReason.TryGetValue(hintKey, out var untilUtc)) return false;
        if (DateTime.UtcNow >= untilUtc) return false;
        if (_silentReopenRecentHardBlockFrameByDomainReason.TryGetValue(hintKey, out var frameText)
            && int.TryParse(frameText, out var parsedFrameId))
            frameId = parsedFrameId;
        return frameId >= 0;
    }

    private bool IsSilentReopenDomainCooldownActive(VideoTabInfo tab, string attemptId, int slotNumber)
    {
        // 9.31.38: cooldown por domínio puro foi desativado.
        // A decisão agora depende do resultado do preflight: domain + frameId + reasonCode.
        AppLogger.Info($"pip-preserve-silent-domain-cooldown-check-skipped: attemptId={attemptId}; slot={slotNumber}; domain={NormalizeSilentCooldownDomain(tab.Domain)}; reason=precise-frame-reason-cooldown-enabled");
        return false;
    }

    private bool IsSilentReopenPreciseCooldownActive(string? domain, int frameId, string? reasonCode, string attemptId, int slotNumber)
    {
        var key = BuildSilentReopenPreciseCooldownKey(domain, frameId, reasonCode);
        if (!_silentReopenPreciseCooldownUntilUtc.TryGetValue(key, out var untilUtc))
            return false;

        if (DateTime.UtcNow >= untilUtc)
        {
            _silentReopenPreciseCooldownUntilUtc.Remove(key);
            _silentReopenPreciseCooldownReason.Remove(key);
            AppLogger.Info($"pip-preserve-silent-precise-cooldown-expired: attemptId={attemptId}; slot={slotNumber}; key={key}; expiredAt={untilUtc:O}");
            return false;
        }

        var reason = _silentReopenPreciseCooldownReason.TryGetValue(key, out var storedReason) ? storedReason : string.Empty;
        AppLogger.Info($"pip-preserve-silent-skipped-precise-cooldown: attemptId={attemptId}; slot={slotNumber}; key={key}; domain={NormalizeSilentCooldownDomain(domain)}; frameId={frameId}; reasonCode={reason}; cooldownUntil={untilUtc:O}; remainingMs={(untilUtc - DateTime.UtcNow).TotalMilliseconds:0}");
        AppLogger.Info($"pip-preserve-silent-precise-cooldown-reused: attemptId={attemptId}; slot={slotNumber}; key={key}; domain={NormalizeSilentCooldownDomain(domain)}; frameId={frameId}; reasonCode={reason}; cooldownUntil={untilUtc:O}; remainingMs={(untilUtc - DateTime.UtcNow).TotalMilliseconds:0}");
        return true;
    }

    private void SetSilentReopenDomainCooldown(VideoTabInfo tab, string reasonCode, string attemptId, int slotNumber)
    {
        // Mantém a assinatura antiga, mas agora a implementação é precisa.
        var domain = string.IsNullOrWhiteSpace(_lastSilentPreflightDomain)
            ? tab.Domain
            : _lastSilentPreflightDomain;
        var frameId = _lastSilentPreflightFrameId;
        SetSilentReopenPreciseCooldown(domain, frameId, reasonCode, attemptId, slotNumber, "compat-domain-method");
    }

    private void SetSilentReopenPreciseCooldown(string? domain, int frameId, string reasonCode, string attemptId, int slotNumber, string source)
    {
        if (string.IsNullOrWhiteSpace(reasonCode))
            return;

        var cooldownReasons = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            "pip-not-allowed",
            "pip-api-disabled",
            "pip-method-unavailable",
            "pip-disabled-by-video",
            "content-version-mismatch"
        };

        if (!cooldownReasons.Contains(reasonCode))
            return;

        var key = BuildSilentReopenPreciseCooldownKey(domain, frameId, reasonCode);
        var untilUtc = DateTime.UtcNow.AddSeconds(SilentReopenDomainCooldownSeconds);
        _silentReopenPreciseCooldownUntilUtc[key] = untilUtc;
        _silentReopenPreciseCooldownReason[key] = reasonCode;
        RememberSilentReopenHardBlockHint(domain, frameId, reasonCode, attemptId, slotNumber, source);

        AppLogger.Info($"pip-preserve-silent-precise-cooldown-set: attemptId={attemptId}; slot={slotNumber}; key={key}; domain={NormalizeSilentCooldownDomain(domain)}; frameId={frameId}; reasonCode={reasonCode}; cooldownSeconds={SilentReopenDomainCooldownSeconds}; cooldownUntil={untilUtc:O}; source={source}");
        AppLogger.Info($"pip-preserve-silent-domain-cooldown-set: attemptId={attemptId}; slot={slotNumber}; domain={NormalizeSilentCooldownDomain(domain)}; reasonCode={reasonCode}; cooldownSeconds={SilentReopenDomainCooldownSeconds}; cooldownUntil={untilUtc:O}; mode=precise-frame-reason; key={key}");
    }

    private bool ShouldTryPreserveSilentReopen(PipSlot slot, VideoSwitchPreservationState state, string attemptId)
    {
        if (state.SilentReopenAttempted)
            return false;

        if (!IsVideoSwitchPreservationStateAlive(state))
            return false;

        if (!state.NewVideoDetected)
            return false;

        if (!state.OldHwndLostSeen && state.OldHandle != IntPtr.Zero && PipWindowService.IsUsable(state.OldHandle))
            return false;

        if (!ShouldAutoReturnSlot(slot, "silent-reopen-check", logSkip: false))
            return false;

        AppLogger.Info($"pip-preserve-silent-reopen-eligible: attemptId={attemptId}; slot={slot.Number}; command={state.CommandType}; oldHandle=0x{state.OldHandle.ToInt64():X}; newVideoDetected={state.NewVideoDetected}; oldHwndLostSeen={state.OldHwndLostSeen}; autoReturnOwned={state.AutoReturnTookOwnership}; preservedConfirmed={state.PreservedSameHwndConfirmed}; ttlRemainingMs={(state.ExpiresUtc - DateTime.UtcNow).TotalMilliseconds:0}");
        return true;
    }

    private async Task<bool> TryPreserveSilentReopenOnceAsync(PipSlot slot, VideoTabInfo tab, AutoReturnSlotState autoState, string attemptId)
    {
        if (!IsAutoReturnAttemptCurrent(slot, autoState, attemptId, "silent-entry"))
            return false;

        if (!_videoSwitchPreservationBySlot.TryGetValue(slot.Number, out var preserveState))
            return false;

        if (!ShouldTryPreserveSilentReopen(slot, preserveState, attemptId))
            return false;

        if (IsSilentReopenDomainCooldownActive(tab, attemptId, slot.Number))
            return false;

        var likelyReasonCode = string.IsNullOrWhiteSpace(preserveState.SilentReopenReasonCode)
            ? "pip-api-disabled"
            : preserveState.SilentReopenReasonCode;

        if (TryGetSilentReopenHardBlockHint(tab.Domain, likelyReasonCode, out var hintedFrameId, out var hintKey)
            && IsSilentReopenPreciseCooldownActive(tab.Domain, hintedFrameId, likelyReasonCode, attemptId, slot.Number))
        {
            preserveState.SilentReopenReasonCode = likelyReasonCode;
            var reusedKey = BuildSilentReopenPreciseCooldownKey(tab.Domain, hintedFrameId, likelyReasonCode);
            AppLogger.Info($"pip-preserve-silent-precise-cooldown-reused-before-preflight: attemptId={attemptId}; slot={slot.Number}; domain={NormalizeSilentCooldownDomain(tab.Domain)}; frameId={hintedFrameId}; reasonCode={likelyReasonCode}; hintKey={hintKey}; preciseKey={reusedKey}; silentAttempted=False");
            AppLogger.Warn($"pip-preserve-silent-skipped-preflight-precise-cooldown: attemptId={attemptId}; slot={slot.Number}; key={reusedKey}; domain={NormalizeSilentCooldownDomain(tab.Domain)}; frameId={hintedFrameId}; reasonCode={likelyReasonCode}; fallback=discrete; source=before-preflight-hint");
            AppLogger.Info($"pip-preserve-silent-fallback-discrete-after-preflight: attemptId={attemptId}; slot={slot.Number}; reasonCode={likelyReasonCode}; silentAttempted=False; cooldown=precise-reused-before-preflight; key={reusedKey}");
            return false;
        }

        var preflightAttemptId = $"preflight-{DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()}-{Guid.NewGuid():N}".Substring(0, 32);
        _lastSilentPreflightAttemptId = string.Empty;
        _lastSilentPreflightReasonCode = string.Empty;
        _lastSilentPreflightReasonMessage = string.Empty;
        _lastSilentPreflightResult = string.Empty;
        _lastSilentPreflightDomain = string.Empty;
        _lastSilentPreflightTabId = 0;
        _lastSilentPreflightFrameId = -1;
        _lastSilentPreflightOk = false;

        AppLogger.Info($"pip-preserve-silent-preflight-start: attemptId={attemptId}; preflightAttemptId={preflightAttemptId}; slot={slot.Number}; tabId={tab.TabId}; domain={tab.Domain}; session={tab.VideoSessionId}; stable={tab.StableVideoKey}; url={tab.Url}");
        var preflightResultSignal = ArmSilentPreflightResultWait(preflightAttemptId);
        var preflightWaitStartedUtc = DateTime.UtcNow;
        try
        {
            if (!IsAutoReturnAttemptCurrent(slot, autoState, attemptId, "before-preflight-send"))
                return false;

            var preflightClients = await _extensionBridge.SendSilentReopenPreflightAsync(tab.VideoSessionId, tab.StableVideoKey, tab.TabId, preflightAttemptId);
            AppLogger.Info($"pip-preserve-silent-preflight-request-sent: attemptId={attemptId}; preflightAttemptId={preflightAttemptId}; slot={slot.Number}; tabId={tab.TabId}; clients={preflightClients}");

            AppLogger.Info($"pip-preserve-silent-multiframe-force-probe-from-raw-armed: attemptId={attemptId}; preflightAttemptId={preflightAttemptId}; slot={slot.Number}; tabId={tab.TabId}; reason=block53-force-probe-from-raw-onmessage");
            var completed = await Task.WhenAny(preflightResultSignal.Task, Task.Delay(SilentPreflightFallbackWaitMs));
            var signaled = ReferenceEquals(completed, preflightResultSignal.Task);
            AppLogger.Info($"pip-preserve-silent-preflight-wait-complete: attemptId={attemptId}; preflightAttemptId={preflightAttemptId}; mode={(signaled ? "signaled" : "timeout-fallback")}; elapsedMs={(DateTime.UtcNow - preflightWaitStartedUtc).TotalMilliseconds:0}; fallbackWaitMs={SilentPreflightFallbackWaitMs}");
            if (!IsAutoReturnAttemptCurrent(slot, autoState, attemptId, "after-preflight-wait"))
                return false;
        }
        catch (Exception ex)
        {
            AppLogger.Warn($"pip-preserve-silent-preflight-request-failed: attemptId={attemptId}; preflightAttemptId={preflightAttemptId}; slot={slot.Number}; tabId={tab.TabId}; reason={ex.Message}");
        }
        finally
        {
            ClearSilentPreflightResultWait(preflightAttemptId);
        }

        var preflightMatched = string.Equals(_lastSilentPreflightAttemptId, preflightAttemptId, StringComparison.OrdinalIgnoreCase);
        var preflightDomain = string.IsNullOrWhiteSpace(_lastSilentPreflightDomain) ? tab.Domain : _lastSilentPreflightDomain;
        var preflightFrameId = _lastSilentPreflightFrameId;
        var preflightKey = BuildSilentReopenPreciseCooldownKey(preflightDomain, preflightFrameId, _lastSilentPreflightReasonCode);
        AppLogger.Info($"pip-preserve-silent-preflight-app-evaluation: attemptId={attemptId}; preflightAttemptId={preflightAttemptId}; matched={preflightMatched}; ok={_lastSilentPreflightOk}; result={_lastSilentPreflightResult}; reasonCode={_lastSilentPreflightReasonCode}; reasonMessage={_lastSilentPreflightReasonMessage}; domain={preflightDomain}; frameId={preflightFrameId}; preciseKey={preflightKey}");

        if (preflightMatched && !_lastSilentPreflightOk && IsSilentPreflightReadinessReason(_lastSilentPreflightReasonCode))
        {
            AppLogger.Info($"pip-preserve-silent-readiness-recheck-wait: attemptId={attemptId}; preflightAttemptId={preflightAttemptId}; slot={slot.Number}; tabId={tab.TabId}; reasonCode={_lastSilentPreflightReasonCode}; delayMs=250");
            await Task.Delay(250);
            if (!IsAutoReturnAttemptCurrent(slot, autoState, attemptId, "before-readiness-recheck"))
                return false;

            var recheckAttemptId = $"preflight-recheck-{DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()}-{Guid.NewGuid():N}".Substring(0, 40);
            _lastSilentPreflightAttemptId = string.Empty;
            _lastSilentPreflightReasonCode = string.Empty;
            _lastSilentPreflightReasonMessage = string.Empty;
            _lastSilentPreflightResult = string.Empty;
            _lastSilentPreflightDomain = string.Empty;
            _lastSilentPreflightTabId = 0;
            _lastSilentPreflightFrameId = -1;
            _lastSilentPreflightOk = false;

            var recheckSignal = ArmSilentPreflightResultWait(recheckAttemptId);
            var recheckStartedUtc = DateTime.UtcNow;
            try
            {
                var clients = await _extensionBridge.SendSilentReopenPreflightAsync(tab.VideoSessionId, tab.StableVideoKey, tab.TabId, recheckAttemptId);
                var completed = await Task.WhenAny(recheckSignal.Task, Task.Delay(450));
                var signaled = ReferenceEquals(completed, recheckSignal.Task);
                AppLogger.Info($"pip-preserve-silent-readiness-recheck-complete: attemptId={attemptId}; preflightAttemptId={recheckAttemptId}; slot={slot.Number}; tabId={tab.TabId}; clients={clients}; mode={(signaled ? "signaled" : "timeout")}; elapsedMs={(DateTime.UtcNow - recheckStartedUtc).TotalMilliseconds:0}");
            }
            catch (Exception ex)
            {
                AppLogger.Warn($"pip-preserve-silent-readiness-recheck-failed: attemptId={attemptId}; preflightAttemptId={recheckAttemptId}; slot={slot.Number}; tabId={tab.TabId}; reason={ex.Message}");
            }
            finally
            {
                ClearSilentPreflightResultWait(recheckAttemptId);
            }

            preflightAttemptId = recheckAttemptId;
            preflightMatched = string.Equals(_lastSilentPreflightAttemptId, recheckAttemptId, StringComparison.OrdinalIgnoreCase);
            preflightDomain = string.IsNullOrWhiteSpace(_lastSilentPreflightDomain) ? tab.Domain : _lastSilentPreflightDomain;
            preflightFrameId = _lastSilentPreflightFrameId;
            preflightKey = BuildSilentReopenPreciseCooldownKey(preflightDomain, preflightFrameId, _lastSilentPreflightReasonCode);
            AppLogger.Info($"pip-preserve-silent-readiness-recheck-evaluation: attemptId={attemptId}; preflightAttemptId={recheckAttemptId}; matched={preflightMatched}; ok={_lastSilentPreflightOk}; result={_lastSilentPreflightResult}; reasonCode={_lastSilentPreflightReasonCode}; reasonMessage={_lastSilentPreflightReasonMessage}; preciseKey={preflightKey}");

            if (!preflightMatched || (!_lastSilentPreflightOk && IsSilentPreflightReadinessReason(_lastSilentPreflightReasonCode)))
            {
                preserveState.SilentReopenReasonCode = preflightMatched ? _lastSilentPreflightReasonCode : "player-not-ready";
                AppLogger.Warn($"pip-preserve-silent-readiness-recheck-blocked: attemptId={attemptId}; preflightAttemptId={recheckAttemptId}; slot={slot.Number}; tabId={tab.TabId}; reasonCode={preserveState.SilentReopenReasonCode}; fallback=discrete-immediate; silentAttempted=False");
                return false;
            }
        }

        if (preflightMatched && !_lastSilentPreflightOk && IsSilentPreflightHardBlockReason(_lastSilentPreflightReasonCode))
        {
            preserveState.SilentReopenReasonCode = _lastSilentPreflightReasonCode;

            if (IsSilentReopenPreciseCooldownActive(preflightDomain, preflightFrameId, _lastSilentPreflightReasonCode, attemptId, slot.Number))
            {
                AppLogger.Warn($"pip-preserve-silent-skipped-preflight-precise-cooldown: attemptId={attemptId}; preflightAttemptId={preflightAttemptId}; slot={slot.Number}; key={preflightKey}; domain={preflightDomain}; frameId={preflightFrameId}; reasonCode={_lastSilentPreflightReasonCode}; fallback=discrete");
                AppLogger.Info($"pip-preserve-silent-fallback-discrete-after-preflight: attemptId={attemptId}; preflightAttemptId={preflightAttemptId}; slot={slot.Number}; reasonCode={_lastSilentPreflightReasonCode}; silentAttempted=False; cooldown=precise-active; key={preflightKey}");
                return false;
            }

            SetSilentReopenPreciseCooldown(preflightDomain, preflightFrameId, _lastSilentPreflightReasonCode, attemptId, slot.Number, "preflight-hard-block");
            AppLogger.Warn($"pip-preserve-silent-preflight-hard-block: attemptId={attemptId}; preflightAttemptId={preflightAttemptId}; slot={slot.Number}; tabId={tab.TabId}; domain={preflightDomain}; frameId={preflightFrameId}; preciseKey={preflightKey}; reasonCode={_lastSilentPreflightReasonCode}; reasonMessage={_lastSilentPreflightReasonMessage}; result={_lastSilentPreflightResult}");
            AppLogger.Warn($"pip-preserve-silent-skipped-preflight-hard-block: attemptId={attemptId}; preflightAttemptId={preflightAttemptId}; slot={slot.Number}; reasonCode={_lastSilentPreflightReasonCode}; fallback=discrete; preciseKey={preflightKey}");
            AppLogger.Info($"pip-preserve-silent-fallback-discrete-after-preflight: attemptId={attemptId}; preflightAttemptId={preflightAttemptId}; slot={slot.Number}; reasonCode={_lastSilentPreflightReasonCode}; silentAttempted=False; cooldown=precise-set; key={preflightKey}");
            return false;
        }

        preserveState.SilentReopenAttempted = true;
        preserveState.SilentReopenAttemptedUtc = DateTime.UtcNow;
        preserveState.SilentReopenReasonCode = string.Empty;
        autoState.SilentAttempts++;

        var silentAttemptId = $"preserve-silent-{DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()}-{Guid.NewGuid():N}".Substring(0, 32);
        _lastSilentAttemptId = silentAttemptId;
        _lastSilentExtensionReasonCode = string.Empty;
        _lastSilentExtensionReasonMessage = string.Empty;
        _lastSilentExtensionEnterPipSeen = false;

        AppLogger.Warn($"pip-preserve-silent-reopen-start: attemptId={attemptId}; silentAttemptId={silentAttemptId}; slot={slot.Number}; tabId={tab.TabId}; command={preserveState.CommandType}; oldHandle=0x{preserveState.OldHandle.ToInt64():X}; session={tab.VideoSessionId}; stable={tab.StableVideoKey}; url={tab.Url}; preservedConfirmed={preserveState.PreservedSameHwndConfirmed}; autoReturnOwned={preserveState.AutoReturnTookOwnership}");

        if (!TryBeginOpenPipAttempt(slot, tab, "Preservação silent-reopen", seconds: 8, owner: OpenPipAttemptOwner.AutoReturn))
        {
            preserveState.SilentReopenReasonCode = "open-lock-active";
            AppLogger.Warn($"pip-preserve-silent-reopen-result: attemptId={attemptId}; silentAttemptId={silentAttemptId}; slot={slot.Number}; result=failed; reasonCode=open-lock-active; hwndCaptured=False");
            AppLogger.Warn($"pip-preserve-silent-reopen-failed-fallback-discrete: attemptId={attemptId}; silentAttemptId={silentAttemptId}; slot={slot.Number}; reasonCode=open-lock-active");
            return false;
        }

        try
        {
            StoreSlotPair(slot.Number, tab);
            MarkSlotAwaitingPip(slot);

            _armedPipTargetSlotNumber = slot.Number;
            _armedPipPairTab = tab;
            _armedPipPairStartedUtc = DateTime.UtcNow;
            _armedPipPairUntilUtc = DateTime.UtcNow.AddSeconds(35);
            _armedPipCandidateWindow = null;
            _armedPipCandidateDetectedUtc = DateTime.MinValue;
            _armedPipExistingHandles = _discovery.FindPipWindows()
                .Select(window => window.Handle)
                .Concat(Slots.Where(item => item.Window is not null).Select(item => item.Window!.Handle))
                .ToHashSet();

            _armedPipPairTimer.Start();

            int clients;
            try
            {
                if (!IsAutoReturnAttemptCurrent(slot, autoState, attemptId, "before-silent-open-send"))
                {
                    EndOpenPipAttempt(slot, tab, "Preservação silent-reopen", "cancelado");
                    return false;
                }

                clients = await _extensionBridge.SendOpenPictureInPictureReacquireAsync(tab.VideoSessionId, tab.StableVideoKey, tab.TabId, silentAttemptId, silent: true);
                AppLogger.Info($"pip-preserve-silent-fresh-target-requested: attemptId={attemptId}; silentAttemptId={silentAttemptId}; slot={slot.Number}; tabId={tab.TabId}; strategy=reacquire-best-visible-same-tab");
            }
            catch (Exception ex)
            {
                preserveState.SilentReopenReasonCode = "send-failed";
                AppLogger.Warn($"pip-preserve-silent-reopen-result: attemptId={attemptId}; silentAttemptId={silentAttemptId}; slot={slot.Number}; result=failed; reasonCode=send-failed; reasonMessage={ex.Message}; hwndCaptured=False");
                AppLogger.Warn($"pip-preserve-silent-reopen-failed-fallback-discrete: attemptId={attemptId}; silentAttemptId={silentAttemptId}; slot={slot.Number}; reasonCode=send-failed");
                EndOpenPipAttempt(slot, tab, "Preservação silent-reopen", "send-failed");
                return false;
            }

            AppLogger.Info($"pip-preserve-silent-reopen-sent: attemptId={attemptId}; silentAttemptId={silentAttemptId}; slot={slot.Number}; tabId={tab.TabId}; clients={clients}; handlesBefore={_armedPipExistingHandles.Count}");

            var capturedHandle = await WaitForAutoReturnHwndAsync(
                slot,
                attemptId,
                tryNumber: 0,
                waitMs: 3600,
                abortOnSilentFailureAttemptId: silentAttemptId);
            if (!IsAutoReturnAttemptCurrent(slot, autoState, attemptId, "after-silent-hwnd-wait"))
            {
                EndOpenPipAttempt(slot, tab, "Preservação silent-reopen", "cancelado");
                return false;
            }

            if (capturedHandle != IntPtr.Zero)
            {
                preserveState.SilentReopenConfirmed = true;
                preserveState.SilentReopenReasonCode = "confirmed";
                AppLogger.Info($"pip-preserve-silent-reopen-confirmed: attemptId={attemptId}; silentAttemptId={silentAttemptId}; slot={slot.Number}; tabId={tab.TabId}; handle=0x{capturedHandle.ToInt64():X}; oldHandle=0x{preserveState.OldHandle.ToInt64():X}");
                AppLogger.Info($"pip-preserve-silent-reopen-result: attemptId={attemptId}; silentAttemptId={silentAttemptId}; slot={slot.Number}; result=confirmed; reasonCode=; hwndCaptured=True; handle=0x{capturedHandle.ToInt64():X}; enterPipSeen={_lastSilentExtensionEnterPipSeen}; extensionReason={_lastSilentExtensionReasonCode}");

                CompleteVideoSwitchPreservationAfterAutoReturn(
                    slot,
                    tab,
                    capturedHandle,
                    attemptId,
                    "preserve-silent-reopen-confirmed");

                if (preserveState.OldHandle != IntPtr.Zero && preserveState.OldHandle != capturedHandle)
                    ClassifyReconnectedNewHwnd(slot, preserveState.OldHandle, capturedHandle, "preserve-silent-reopen", "silent-reopen-confirmed");

                EndOpenPipAttempt(slot, tab, "Preservação silent-reopen", "confirmado");
                return true;
            }

            var reasonCode = string.IsNullOrWhiteSpace(_lastSilentExtensionReasonCode)
                ? "hwnd-not-found"
                : _lastSilentExtensionReasonCode;
            var reasonMessage = string.IsNullOrWhiteSpace(_lastSilentExtensionReasonMessage)
                ? "app-did-not-capture-hwnd"
                : _lastSilentExtensionReasonMessage;

            preserveState.SilentReopenReasonCode = reasonCode;
            SetSilentReopenDomainCooldown(tab, reasonCode, attemptId, slot.Number);
            if (IsSilentReopenImmediateFallbackReason(reasonCode))
                AppLogger.Warn($"pip-preserve-silent-reopen-fast-fallback: attemptId={attemptId}; silentAttemptId={silentAttemptId}; slot={slot.Number}; reasonCode={reasonCode}; fallback=discrete-immediate; avoidedWaitMs=3600");
            AppLogger.Warn($"pip-preserve-silent-reopen-result: attemptId={attemptId}; silentAttemptId={silentAttemptId}; slot={slot.Number}; result=failed; reasonCode={reasonCode}; reasonMessage={reasonMessage}; enterPipSeen={_lastSilentExtensionEnterPipSeen}; hwndCaptured=False");
            AppLogger.Warn($"pip-preserve-silent-reopen-failed-fallback-discrete: attemptId={attemptId}; silentAttemptId={silentAttemptId}; slot={slot.Number}; reasonCode={reasonCode}; reasonMessage={reasonMessage}");
            EndOpenPipAttempt(slot, tab, "Preservação silent-reopen", reasonCode);
            return false;
        }
        catch
        {
            EndOpenPipAttempt(slot, tab, "Preservação silent-reopen", "excecao");
            throw;
        }
    }

    private bool DeferAutoReturnForOpenOperation(PipSlot slot, AutoReturnSlotState state, string attemptId, string checkpoint)
    {
        if (!_openPipAttemptInProgress && !_openAllPipsInProgress)
            return false;

        // Não conta como falha nem aumenta o backoff. O estado continua pendente e será
        // retomado quando a abertura iniciada pelo usuário liberar a autoridade física.
        state.CooldownUntilUtc = DateTime.UtcNow.AddMilliseconds(350);
        _autoReturnCooldownUntilBySlot[slot.Number] = state.CooldownUntilUtc;
        AppLogger.InfoAggregated(
            $"auto-return-deferred-by-open-operation:{slot.Number}",
            TimeSpan.FromSeconds(2),
            $"auto-return-deferred-by-open-operation: attemptId={attemptId}; slot={slot.Number}; " +
            $"checkpoint={checkpoint}; openAttempt={_openPipAttemptInProgress}; openAll={_openAllPipsInProgress}; " +
            $"armedSlot={_armedPipTargetSlotNumber}; lockSlot={_openPipAttemptSlotNumber}; retryDelayMs=350");
        return true;
    }

    private async Task TryAutoReturnSlotAsync(PipSlot slot, VideoTabInfo tab, AutoReturnSlotState state)
    {
        var attemptId = $"autoreturn-{DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()}-{Guid.NewGuid():N}".Substring(0, 32);
        var finalReason = string.Empty;
        var gateAcquired = false;
        state.PhysicalAttemptDeferredForFreshSnapshot = false;

        try
        {
            if (DeferAutoReturnForOpenOperation(slot, state, attemptId, "before-fresh-snapshot"))
                return;

            ClearUnusableAutoReturnWindow(slot, attemptId, "before-fresh-snapshot");
            var freshSnapshot = await RequestCorrelatedAutoReturnSnapshotAsync(
                tab,
                attemptId,
                slot.Number,
                checkpoint: "pre-physical-gate",
                timeoutMs: 700);

            if (!freshSnapshot.ResponseReceived)
            {
                state.ReadinessDeferrals++;
                var timeoutRetryDelayMs = SetAutoReturnReadinessCooldown(
                    slot.Number,
                    state,
                    hardNotReady: true,
                    reason: "fresh-snapshot-timeout");
                AppLogger.Info($"auto-return-fresh-snapshot-timeout-deferred: attemptId={attemptId}; slot={slot.Number}; tabId={tab.TabId}; deferral={state.ReadinessDeferrals}; retryDelayMs={timeoutRetryDelayMs}; staleCandidateRejected=True; physicalGateAcquired=False; physicalRetryBackoff={state.RetryBackoffAttempt}");
                return;
            }

            if (!freshSnapshot.CanProceed)
            {
                ClearUnusableAutoReturnWindow(slot, attemptId, freshSnapshot.ExactNoVideo ? "fresh-snapshot-no-video" : "fresh-snapshot-tab-not-ready");
                state.ReadinessDeferrals++;
                var authorityReason = freshSnapshot.ExactNoVideo ? "fresh-snapshot-no-video" : "fresh-snapshot-tab-not-ready";
                var authorityRetryDelayMs = SetAutoReturnReadinessCooldown(
                    slot.Number,
                    state,
                    hardNotReady: true,
                    reason: authorityReason);
                var discoveryStatus = freshSnapshot.Discovery?.Status ?? "tab-missing";
                var rawVideoCount = freshSnapshot.Discovery?.RawVideoCount ?? 0;
                var sessionCount = freshSnapshot.Discovery?.SessionCount ?? 0;
                AppLogger.Info($"auto-return-fresh-snapshot-no-video-deferred: attemptId={attemptId}; slot={slot.Number}; tabId={tab.TabId}; status={discoveryStatus}; rawVideoCount={rawVideoCount}; sessionCount={sessionCount}; deferral={state.ReadinessDeferrals}; retryDelayMs={authorityRetryDelayMs}; staleCandidateRejected=True; physicalGateAcquired=False; physicalRetryBackoff={state.RetryBackoffAttempt}; correlatedGeneration={freshSnapshot.Generation}; exactNoVideo={freshSnapshot.ExactNoVideo}");
                return;
            }

            tab = freshSnapshot.Tab;
            var refreshedBeforeReadiness = ResolveFreshAutoReturnTabSnapshot(tab);
            if (!ReferenceEquals(refreshedBeforeReadiness, tab))
            {
                AppLogger.Info($"auto-return-target-refreshed: attemptId={attemptId}; slot={slot.Number}; tabId={tab.TabId}; phase=pre-readiness; oldTitle={tab.Title}; newTitle={refreshedBeforeReadiness.Title}; oldUrl={tab.Url}; newUrl={refreshedBeforeReadiness.Url}; oldStable={tab.StableVideoKey}; newStable={refreshedBeforeReadiness.StableVideoKey}");
                tab = refreshedBeforeReadiness;
            }

            if (DeferAutoReturnForOpenOperation(slot, state, attemptId, "before-readiness"))
                return;
            // Player readiness is observed outside the single-flight physical gate. During a burst,
            // all slots may prepare in parallel while only the actual shortcut/HWND capture remains
            // serialized. This prevents one loading video from blocking the other nine slots.
            var readiness = await WaitForAutoReturnTargetPlaybackReadyAsync(slot, tab, state, attemptId);
            tab = readiness.Tab;
            var hardNotReady = IsAutoReturnTargetHardNotReady(tab);
            if (AutoReturnBurstPolicy.ShouldDeferPhysicalAttemptForReadiness(
                    readiness.Ready,
                    hardNotReady,
                    state.ReadinessDeferrals,
                    AutoReturnMaxReadinessDeferrals))
            {
                state.ReadinessDeferrals++;
                var readinessRetryDelayMs = SetAutoReturnReadinessCooldown(
                    slot.Number,
                    state,
                    hardNotReady,
                    "target-not-ready");
                AppLogger.Info($"auto-return-target-ready-deferred: attemptId={attemptId}; slot={slot.Number}; tabId={tab.TabId}; deferral={state.ReadinessDeferrals}; maxDeferrals={AutoReturnMaxReadinessDeferrals}; hardNotReady={hardNotReady}; readyState={tab.ReadyState}; hasSource={tab.HasSource}; retryDelayMs={readinessRetryDelayMs}; physicalGateAcquired=False; physicalRetryBackoff={state.RetryBackoffAttempt}");
                return;
            }

            if (!readiness.Ready && hardNotReady && IsTerminalAutoNextState(state))
            {
                state.TerminalPassiveWatch = true;
                state.CooldownUntilUtc = DateTime.UtcNow.AddMilliseconds(AutoReturnTerminalPassiveCooldownMs);
                _autoReturnCooldownUntilBySlot[slot.Number] = state.CooldownUntilUtc;
                AppLogger.Warn($"auto-return-terminal-readiness-bound-reached: attemptId={attemptId}; slot={slot.Number}; tabId={tab.TabId}; deferrals={state.ReadinessDeferrals}; maxDeferrals={AutoReturnMaxReadinessDeferrals}; readyState={tab.ReadyState}; hasSource={tab.HasSource}; terminalNavigationGeneration={state.TerminalNavigationGeneration}; action=passive-structural-watch");
                return;
            }

            if (!readiness.Ready)
                AppLogger.Warn($"auto-return-target-ready-fallback: attemptId={attemptId}; slot={slot.Number}; tabId={tab.TabId}; deferrals={state.ReadinessDeferrals}; hardNotReady={hardNotReady}; readyState={tab.ReadyState}; action=physical-attempt-after-bounded-deferrals");
            else
                state.ReadinessDeferrals = 0;

            if (DeferAutoReturnForOpenOperation(slot, state, attemptId, "after-readiness"))
                return;

            AppLogger.Info($"auto-return-serialization-wait: attemptId={attemptId}; slot={slot.Number}; pendingStates={_autoReturnStatesBySlot.Count}");
            await _autoReturnExecutionGate.WaitAsync();
            gateAcquired = true;

            if (DeferAutoReturnForOpenOperation(slot, state, attemptId, "after-physical-gate"))
                return;

            _activeAutoReturnAttemptId = attemptId;
            _activeAutoReturnSlotNumber = slot.Number;
            _activeAutoReturnAttemptStartedUtc = DateTime.UtcNow;
            AppLogger.Info($"auto-return-serialization-acquired: attemptId={attemptId}; slot={slot.Number}; mode=single-flight");

            if (!IsAutoReturnAttemptCurrent(slot, state, attemptId, "attempt-entry"))
                return;

            ClearUnusableAutoReturnWindow(slot, attemptId, "before-physical-attempt");
            AppLogger.Warn($"auto-return-start: attemptId={attemptId}; slot={slot.Number}; tabId={tab.TabId}; policy=SlotDiscrete; slotEnabled={IsAutoReturnEnabledForSlot(slot.Number)}; reason={state.Reason}; session={tab.VideoSessionId}; stable={tab.StableVideoKey}; title={tab.Title}");
            ShadowMirrorReconnectStarted(slot, "TryAutoReturnSlotAsync/auto-return-start");
            ShadowLogLegacyComparison(slot, "TryAutoReturnSlotAsync/ReconnectStarted", "legacy-autoreturn-started");

            StoreSlotPair(slot.Number, tab);
            MarkSlotAwaitingPip(slot);
            _armedPipTargetSlotNumber = slot.Number;
            _armedPipPairTab = tab;
            _armedPipPairStartedUtc = DateTime.UtcNow;
            _armedPipPairUntilUtc = DateTime.UtcNow.AddSeconds(35);
            _armedPipCandidateWindow = null;
            _armedPipCandidateDetectedUtc = DateTime.MinValue;
            _armedPipExistingHandles = _discovery.FindPipWindows()
                .Select(window => window.Handle)
                .Concat(Slots.Where(item => item.Window is not null).Select(item => item.Window!.Handle))
                .ToHashSet();

            _armedPipPairTimer.Start();

            AppLogger.Info($"auto-return-target-selected: attemptId={attemptId}; slot={slot.Number}; tabId={tab.TabId}; method=fresh-snapshot-candidate; session={tab.VideoSessionId}; stable={tab.StableVideoKey}; url={tab.Url}; title={tab.Title}; expectedProcess={state.ExpectedBrowserProcess}");

            if (!IsAutoReturnAttemptCurrent(slot, state, attemptId, "after-snapshot"))
                return;

            var silentReopenOk = await TryPreserveSilentReopenOnceAsync(slot, tab, state, attemptId);
            // A successful capture may remove the state through the normal capture path.
            // Treat the completed result as success before checking whether the old state still exists.
            if (silentReopenOk)
            {
                if (_autoReturnStatesBySlot.TryGetValue(slot.Number, out var currentSilentState) && ReferenceEquals(currentSilentState, state))
                    _autoReturnStatesBySlot.Remove(slot.Number);
                return;
            }

            if (!IsAutoReturnAttemptCurrent(slot, state, attemptId, "after-silent-stage"))
                return;

            state.FocuslessAttempts++;
            var silentReason = state.SilentAttempts > 0 ? "preserve-silent-reopen-failed" : "not-eligible-for-preserve-silent-reopen";
            AppLogger.Info($"auto-return-discrete-direct-start: attemptId={attemptId}; slot={slot.Number}; tabId={tab.TabId}; silentSkipped={state.SilentAttempts == 0}; silentAttempted={state.SilentAttempts > 0}; reason={silentReason}");

            var focuslessOk = await AutoReturnFocuslessOnceAsync(slot, tab, state, attemptId);
            if (!focuslessOk && state.PhysicalAttemptDeferredForFreshSnapshot)
            {
                AppLogger.Info($"auto-return-physical-attempt-deferred-by-correlated-snapshot: attemptId={attemptId}; slot={slot.Number}; tabId={tab.TabId}; physicalRetryBackoffPreserved={state.RetryBackoffAttempt}");
                return;
            }

            // The successful capture callback can legitimately consume the state before this continuation resumes.
            // Success is not cancellation; only failed/incomplete operations require the generation check below.
            if (focuslessOk)
            {
                if (_autoReturnStatesBySlot.TryGetValue(slot.Number, out var currentFocuslessState) && ReferenceEquals(currentFocuslessState, state))
                    _autoReturnStatesBySlot.Remove(slot.Number);
                return;
            }

            if (!IsAutoReturnAttemptCurrent(slot, state, attemptId, "after-focusless-stage"))
                return;

            finalReason = "focusless-failed";
            var retryDelayMs = SetAutoReturnCooldown(slot.Number, state, finalReason);
            AppLogger.Warn($"auto-return-discrete-final-failed: attemptId={attemptId}; slot={slot.Number}; tabId={tab.TabId}; reasonCode={finalReason}; retryDelayMs={retryDelayMs}");
            ShadowMirrorReconnectFailed(slot, finalReason, "TryAutoReturnSlotAsync/focusless-final-failed");
            ShadowLogLegacyComparison(slot, "TryAutoReturnSlotAsync/ReconnectFailed", "legacy-failed-focusless");
        }
        catch (Exception ex)
        {
            if (!IsAutoReturnAttemptCurrent(slot, state, attemptId, "exception", logCancellation: false))
                return;

            SetAutoReturnCooldown(slot.Number, state, "exception");
            AppLogger.Warn($"auto-return-final-result: attemptId={attemptId}; slot={slot.Number}; tabId={tab.TabId}; result=failed; method=exception; reasonCode=unknown-error; reasonMessage={ex.Message}; hwndCaptured=False");
            ShadowMirrorReconnectFailed(slot, "exception", "TryAutoReturnSlotAsync/exception");
            ShadowLogLegacyComparison(slot, "TryAutoReturnSlotAsync/ReconnectFailed", "legacy-failed-exception");
        }
        finally
        {
            state.InProgress = false;
            if (string.Equals(_activeAutoReturnAttemptId, attemptId, StringComparison.Ordinal))
            {
                _activeAutoReturnAttemptId = string.Empty;
                _activeAutoReturnSlotNumber = 0;
                _activeAutoReturnAttemptStartedUtc = DateTime.MinValue;
                foreach (var hwnd in _autoReturnCandidateAttemptByHwnd
                    .Where(item => string.Equals(item.Value, attemptId, StringComparison.Ordinal))
                    .Select(item => item.Key)
                    .ToArray())
                {
                    _autoReturnCandidateAttemptByHwnd.Remove(hwnd);
                }
            }
            if (gateAcquired)
            {
                _autoReturnExecutionGate.Release();
                AppLogger.Info($"auto-return-serialization-released: attemptId={attemptId}; slot={slot.Number}");
            }

            var remainingPending = _autoReturnStatesBySlot.Values.Count(item => !item.InProgress);
            if (remainingPending > 0)
            {
                AppLogger.Info($"auto-return-serialization-resume-pending: completedSlot={slot.Number}; remaining={remainingPending}");
                _ = Dispatcher.InvokeAsync(async () =>
                {
                    await Task.Delay(80);
                    await AutoReturnTickAsync();
                });
            }
        }
    }

    private int SetAutoReturnReadinessCooldown(
        int slotNumber,
        AutoReturnSlotState state,
        bool hardNotReady,
        string reason)
    {
        // Readiness is not a failed physical attempt. Keep the retry backoff untouched
        // so the first real shortcut still receives the normal first-attempt policy.
        var delayMs = AutoReturnBurstPolicy.GetReadinessRetryDelayMilliseconds(hardNotReady);
        var until = DateTime.UtcNow.AddMilliseconds(delayMs);
        state.CooldownUntilUtc = until;
        _autoReturnCooldownUntilBySlot[slotNumber] = until;
        AppLogger.Info($"auto-return-readiness-cooldown-set: slot={slotNumber}; until={until:O}; delayMs={delayMs}; hardNotReady={hardNotReady}; reason={reason}; physicalRetryBackoffPreserved={state.RetryBackoffAttempt}");
        QueueAutoReturnRetryAfterCooldown(slotNumber, state, delayMs, reason);
        return delayMs;
    }

    private int SetAutoReturnCooldown(int slotNumber, AutoReturnSlotState state, string reason)
    {
        state.RetryBackoffAttempt++;
        var delayMs = AutoReturnBurstPolicy.GetRetryDelayMilliseconds(state.RetryBackoffAttempt);
        var until = DateTime.UtcNow.AddMilliseconds(delayMs);
        state.CooldownUntilUtc = until;
        _autoReturnCooldownUntilBySlot[slotNumber] = until;
        AppLogger.Info($"auto-return-cooldown-set: slot={slotNumber}; until={until:O}; retry={state.RetryBackoffAttempt}; delayMs={delayMs}; reason={reason}; policy=500-1000-2000");
        QueueAutoReturnRetryAfterCooldown(slotNumber, state, delayMs, reason);
        return delayMs;
    }

    private void QueueAutoReturnRetryAfterCooldown(int slotNumber, AutoReturnSlotState state, int delayMs, string reason)
    {
        Dispatcher.BeginInvoke(new Action(async () =>
        {
            await Task.Delay(delayMs);
            if (!_autoReturnStatesBySlot.TryGetValue(slotNumber, out var current)
                || !ReferenceEquals(current, state)
                || current.InProgress
                || !IsAutoReturnEnabledForSlot(slotNumber))
                return;

            AppLogger.Info($"auto-return-adaptive-retry-ready: slot={slotNumber}; retry={state.RetryBackoffAttempt}; delayMs={delayMs}; reason={reason}; action=fast-tick");
            await AutoReturnTickAsync();
        }));
    }

    
    private async Task<bool> EnsureBrowserForegroundImmediatelyBeforeShortcutAsync(VideoTabInfo tab, string attemptId, int slotNumber, int tryNumber)
    {
        await Task.Yield();

        var foreground = GetForegroundWindow();
        var foregroundOk = IsLikelyBrowserForeground(foreground, tab, slotNumber);
        AppLogger.Warn($"auto-return-focusless-foreground-pre-shortcut-check: attemptId={attemptId}; slot={slotNumber}; tabId={tab.TabId}; try={tryNumber}; phase=initial; foregroundBrowser={foregroundOk}; foreground={DescribeForegroundWindow(foreground)}; process={GetForegroundProcessName(foreground)}");

        if (foregroundOk)
            return true;

        AppLogger.Warn($"auto-return-focusless-foreground-lost-before-shortcut: attemptId={attemptId}; slot={slotNumber}; tabId={tab.TabId}; try={tryNumber}; reasonCode=foreground-lost-before-shortcut; foreground={DescribeForegroundWindow(foreground)}; process={GetForegroundProcessName(foreground)}");

        var reactivated = await TryActivateBrowserWindowStrongAsync(tab, attemptId, slotNumber, tryNumber, focusAttempt: 99);
        AppLogger.Info($"auto-return-focusless-pre-shortcut-reactivate: attemptId={attemptId}; slot={slotNumber}; tabId={tab.TabId}; try={tryNumber}; reactivated={reactivated}");

        await Task.Delay(reactivated ? 80 : 140);

        foreground = GetForegroundWindow();
        foregroundOk = IsLikelyBrowserForeground(foreground, tab, slotNumber);
        AppLogger.Warn($"auto-return-focusless-foreground-pre-shortcut-check: attemptId={attemptId}; slot={slotNumber}; tabId={tab.TabId}; try={tryNumber}; phase=after-reactivate; foregroundBrowser={foregroundOk}; foreground={DescribeForegroundWindow(foreground)}; process={GetForegroundProcessName(foreground)}");

        if (foregroundOk)
            return true;

        AppLogger.Warn($"auto-return-focusless-shortcut-send-aborted: attemptId={attemptId}; slot={slotNumber}; tabId={tab.TabId}; try={tryNumber}; reasonCode=foreground-lost-before-shortcut; foreground={DescribeForegroundWindow(foreground)}; process={GetForegroundProcessName(foreground)}");
        return false;
    }


    private void LogAutoReturnShortcutForegroundTelemetry(string eventName, VideoTabInfo tab, string attemptId, int slotNumber, int tryNumber, DateTime preShortcutUtc)
    {
        var now = DateTime.UtcNow;
        var foreground = GetForegroundWindow();
        var foregroundBrowser = IsLikelyBrowserForeground(foreground, tab, slotNumber);
        AppLogger.Warn($"{eventName}: attemptId={attemptId}; slot={slotNumber}; tabId={tab.TabId}; try={tryNumber}; timestampUtc={now:O}; elapsedFromPreCheckMs={(now - preShortcutUtc).TotalMilliseconds:0}; foregroundBrowser={foregroundBrowser}; foreground={DescribeForegroundWindow(foreground)}; process={GetForegroundProcessName(foreground)}; domain={tab.Domain}; title={tab.Title}");
    }


    private void LogAutoReturnPostShortcutClassification(string resultClass, string reasonCode, VideoTabInfo tab, string attemptId, PipSlot slot, int tryNumber, bool shortcutSent, DateTime shortcutSentUtc, IntPtr capturedHandle, bool restoredFocus)
    {
        var now = DateTime.UtcNow;
        var elapsedAfterShortcutMs = shortcutSentUtc == DateTime.MinValue
            ? 0
            : (now - shortcutSentUtc).TotalMilliseconds;
        var foreground = GetForegroundWindow();
        var foregroundBrowser = IsLikelyBrowserForeground(foreground, tab, slot.Number);
        var slotHandle = slot.Window?.Handle ?? IntPtr.Zero;
        var hwndCaptured = capturedHandle != IntPtr.Zero;
        var currentSlotHasSameHandle = hwndCaptured && slotHandle == capturedHandle;
        var handleText = capturedHandle == IntPtr.Zero ? "0x0" : $"0x{capturedHandle.ToInt64():X}";
        var slotHandleText = slotHandle == IntPtr.Zero ? "0x0" : $"0x{slotHandle.ToInt64():X}";

        AppLogger.Warn($"auto-return-post-shortcut-classification-result: attemptId={attemptId}; slot={slot.Number}; tabId={tab.TabId}; try={tryNumber}; resultClass={resultClass}; reasonCode={reasonCode}; shortcutSent={shortcutSent}; elapsedAfterShortcutMs={elapsedAfterShortcutMs:0}; hwndCaptured={hwndCaptured}; handle={handleText}; slotHandle={slotHandleText}; reconnectedSlot={currentSlotHasSameHandle}; expectedSlot={slot.Number}; restoredFocus={restoredFocus}; foregroundAfterSend={DescribeForegroundWindow(foreground)}; processAfterSend={GetForegroundProcessName(foreground)}; foregroundBrowserAfterSend={foregroundBrowser}; domain={tab.Domain}; title={tab.Title}");
    }

private async Task<bool> AutoReturnFocuslessOnceAsync(PipSlot slot, VideoTabInfo tab, AutoReturnSlotState state, string attemptId)
    {
        var previousForeground = GetForegroundWindow();
        MainWindowNoActivateLease? mainWindowActivationLease = null;
        var restoredFocus = false;
        var finalReasonCode = "hwnd-not-found";
        const int maxDiscreteTries = 2;

        if (!IsAutoReturnAttemptCurrent(slot, state, attemptId, "focusless-entry"))
            return false;

        if (!TryBeginOpenPipAttempt(slot, tab, "Auto-retorno discreto", seconds: 14, owner: OpenPipAttemptOwner.AutoReturn))
            return false;

        mainWindowActivationLease = BeginMainWindowNoActivateLease(previousForeground, attemptId);

        try
        {
            AppLogger.Warn($"auto-return-focusless-start: attemptId={attemptId}; slot={slot.Number}; tabId={tab.TabId}; previousForeground={DescribeForegroundWindow(previousForeground)}; maxTries={maxDiscreteTries}");

            for (var tryNumber = 1; tryNumber <= maxDiscreteTries; tryNumber++)
            {
                if (!IsAutoReturnAttemptCurrent(slot, state, attemptId, $"focusless-try-{tryNumber}-start"))
                {
                    EndOpenPipAttempt(slot, tab, "Auto-retorno discreto", "cancelado");
                    return false;
                }
                if (tryNumber > 1)
                {
                    AppLogger.Warn($"auto-return-focusless-retry-start: attemptId={attemptId}; slot={slot.Number}; tabId={tab.TabId}; try={tryNumber}; previousReason={finalReasonCode}; delayMs=150");
                    await Task.Delay(150);
                }

                var foregroundOk = await EnsureBrowserForegroundForAutoReturnAsync(tab, attemptId, slot.Number, tryNumber, maxAttempts: 3);
                if (!foregroundOk)
                {
                    finalReasonCode = "browser-not-foreground";
                    continue;
                }

                var preShortcutSnapshot = await RequestCorrelatedAutoReturnSnapshotAsync(
                    tab,
                    attemptId,
                    slot.Number,
                    checkpoint: $"pre-shortcut-try-{tryNumber}",
                    timeoutMs: 700);
                if (!preShortcutSnapshot.ResponseReceived || !preShortcutSnapshot.CanProceed)
                {
                    state.PhysicalAttemptDeferredForFreshSnapshot = true;
                    state.ReadinessDeferrals++;
                    var preShortcutReason = !preShortcutSnapshot.ResponseReceived
                        ? "fresh-snapshot-timeout-before-shortcut"
                        : preShortcutSnapshot.ExactNoVideo
                            ? "fresh-snapshot-no-video-before-shortcut"
                            : "fresh-snapshot-tab-not-ready-before-shortcut";
                    var preShortcutRetryDelayMs = SetAutoReturnReadinessCooldown(
                        slot.Number,
                        state,
                        hardNotReady: true,
                        reason: preShortcutReason);
                    restoredFocus = await TryRestoreForegroundWindowVerifiedAsync(previousForeground, attemptId + "-pre-shortcut-defer", settleMs: 20);
                    var discoveryStatus = preShortcutSnapshot.Discovery?.Status ?? "no-correlated-response";
                    AppLogger.Info($"auto-return-pre-shortcut-fresh-snapshot-deferred: attemptId={attemptId}; slot={slot.Number}; tabId={tab.TabId}; try={tryNumber}; reason={preShortcutReason}; status={discoveryStatus}; exactNoVideo={preShortcutSnapshot.ExactNoVideo}; correlatedGeneration={preShortcutSnapshot.Generation}; retryDelayMs={preShortcutRetryDelayMs}; physicalShortcutSent=False; physicalGateAlreadyHeld=True; physicalRetryBackoffPreserved={state.RetryBackoffAttempt}; restoredFocus={restoredFocus}");
                    EndOpenPipAttempt(slot, tab, "Auto-retorno discreto", preShortcutReason);
                    return false;
                }

                var preShortcutUtc = DateTime.UtcNow;
                var foregroundStillOk = await EnsureBrowserForegroundImmediatelyBeforeShortcutAsync(tab, attemptId, slot.Number, tryNumber);
                if (!foregroundStillOk)
                {
                    finalReasonCode = "foreground-lost-before-shortcut";
                    LogAutoReturnPostShortcutClassification("shortcut-aborted-foreground-lost-before-shortcut", finalReasonCode, tab, attemptId, slot, tryNumber, shortcutSent: false, shortcutSentUtc: DateTime.MinValue, capturedHandle: IntPtr.Zero, restoredFocus: restoredFocus);
                    continue;
                }

                if (!IsAutoReturnAttemptCurrent(slot, state, attemptId, "immediately-before-shortcut-send"))
                {
                    EndOpenPipAttempt(slot, tab, "Auto-retorno discreto", "cancelado");
                    return false;
                }

                LogAutoReturnShortcutForegroundTelemetry("auto-return-focusless-shortcut-final-window-before-send", tab, attemptId, slot.Number, tryNumber, preShortcutUtc);
                LogAutoReturnShortcutForegroundTelemetry("auto-return-focusless-shortcut-send-start", tab, attemptId, slot.Number, tryNumber, preShortcutUtc);
                var sent = await VideoCommandService.SendOpenPictureInPictureShortcutToForegroundAsync(
                    tab.Domain,
                    tab.Title,
                    foregroundAlreadyVerified: true);
                var shortcutSentUtc = DateTime.UtcNow;
                LogAutoReturnShortcutForegroundTelemetry("auto-return-focusless-shortcut-send-finished", tab, attemptId, slot.Number, tryNumber, preShortcutUtc);
                AppLogger.Warn($"auto-return-focusless-shortcut-sent: attemptId={attemptId}; slot={slot.Number}; tabId={tab.TabId}; try={tryNumber}; ok={sent}; diagnostic={VideoCommandService.LastInputDiagnostic}");
                LogAutoReturnShortcutForegroundTelemetry("auto-return-focusless-shortcut-final-window-after-send", tab, attemptId, slot.Number, tryNumber, preShortcutUtc);

                if (!sent)
                {
                    finalReasonCode = "shortcut-send-failed";
                    AppLogger.Warn($"auto-return-focusless-shortcut-failed: attemptId={attemptId}; slot={slot.Number}; tabId={tab.TabId}; try={tryNumber}; reasonCode={finalReasonCode}");
                    LogAutoReturnPostShortcutClassification("shortcut-send-failed", finalReasonCode, tab, attemptId, slot, tryNumber, shortcutSent: false, shortcutSentUtc: shortcutSentUtc, capturedHandle: IntPtr.Zero, restoredFocus: restoredFocus);
                    continue;
                }

                // Keep the verified browser foreground briefly after sending the shortcut. Restoring
                // focus too early can cause Chromium/Firefox to finish the PiP command against the
                // wrong active window when several browser tabs and PiPs are involved.
                const int foregroundLeaseMs = 350;
                var navigationFastLease = state.RequiresRealVideoChange
                    || IsRealAutoReturnVideoChange(state, tab);
                var effectiveForegroundLeaseMs = string.Equals(state.EligibilityMode, "terminal-auto-next-real-change", StringComparison.OrdinalIgnoreCase)
                    ? 300
                    : navigationFastLease
                        ? 320
                        : foregroundLeaseMs;
                AppLogger.Info($"auto-return-focusless-foreground-lease-start: attemptId={attemptId}; slot={slot.Number}; tabId={tab.TabId}; try={tryNumber}; leaseMs={effectiveForegroundLeaseMs}; foreground={DescribeForegroundWindow(GetForegroundWindow())}");
                var capturedHandle = await WaitForAutoReturnHwndAsync(slot, attemptId, tryNumber, waitMs: effectiveForegroundLeaseMs, phase: "foreground-lease", logTimeout: false);
                if (capturedHandle == IntPtr.Zero)
                    capturedHandle = TryReconcileAutoReturnCapturedHandle(slot, attemptId, "after-foreground-lease-wait");

                var attemptCurrentAfterForegroundLease = capturedHandle != IntPtr.Zero ||
                    IsAutoReturnAttemptCurrent(slot, state, attemptId, "after-foreground-lease");

                restoredFocus = await TryRestoreForegroundWindowVerifiedAsync(previousForeground, attemptId, settleMs: 25);
                AppLogger.Info($"auto-return-focusless-foreground-lease-ended: attemptId={attemptId}; slot={slot.Number}; tabId={tab.TabId}; try={tryNumber}; restoredFocus={restoredFocus}; capturedDuringLease={capturedHandle != IntPtr.Zero}; foreground={DescribeForegroundWindow(GetForegroundWindow())}");

                if (!attemptCurrentAfterForegroundLease)
                {
                    // One last reconciliation closes the narrow race where CapturePreparedPipWindow
                    // commits after the timed wait but before cancellation is evaluated.
                    capturedHandle = TryReconcileAutoReturnCapturedHandle(slot, attemptId, "before-foreground-lease-cancel");
                    attemptCurrentAfterForegroundLease = capturedHandle != IntPtr.Zero;
                }

                if (!attemptCurrentAfterForegroundLease)
                {
                    CleanupBrowserVisibilityAfterCancelledAutoReturn(
                        tab,
                        slot,
                        previousForeground,
                        attemptId,
                        "after-foreground-lease");
                    EndOpenPipAttempt(slot, tab, "Auto-retorno discreto", "cancelado-após-foreground-lease");
                    return false;
                }

                var postRestoreWaitMs = navigationFastLease ? 450 : 600;
                AppLogger.Info($"auto-return-post-shortcut-classification-start: attemptId={attemptId}; slot={slot.Number}; tabId={tab.TabId}; try={tryNumber}; shortcutSent=True; foregroundLeaseMs={effectiveForegroundLeaseMs}; postRestoreWaitMs={postRestoreWaitMs}");
                if (capturedHandle == IntPtr.Zero)
                    capturedHandle = await WaitForAutoReturnHwndAsync(slot, attemptId, tryNumber, waitMs: postRestoreWaitMs, phase: "post-focus-restore", logTimeout: false);

                if (capturedHandle == IntPtr.Zero &&
                    !IsAutoReturnAttemptCurrent(slot, state, attemptId, "after-post-restore-wait"))
                {
                    capturedHandle = TryReconcileAutoReturnCapturedHandle(slot, attemptId, "before-post-restore-cancel");
                    if (capturedHandle == IntPtr.Zero)
                    {
                        CleanupBrowserVisibilityAfterCancelledAutoReturn(
                            tab,
                            slot,
                            previousForeground,
                            attemptId,
                            "after-post-restore");
                        EndOpenPipAttempt(slot, tab, "Auto-retorno discreto", "cancelado-após-post-restore");
                        return false;
                    }
                }

                if (capturedHandle == IntPtr.Zero)
                    capturedHandle = TryDirectedAutoReturnHwndRecovery(slot, tab, attemptId, tryNumber);

                var elapsedAfterShortcutMs = (DateTime.UtcNow - shortcutSentUtc).TotalMilliseconds;

                if (capturedHandle != IntPtr.Zero)
                {
                    var resultClass = elapsedAfterShortcutMs > 2600
                        ? "shortcut-sent-pip-late-confirmed"
                        : "shortcut-sent-pip-confirmed";

                    AppLogger.Info($"auto-return-post-shortcut-hwnd-observed: attemptId={attemptId}; slot={slot.Number}; tabId={tab.TabId}; try={tryNumber}; handle=0x{capturedHandle.ToInt64():X}; elapsedAfterShortcutMs={elapsedAfterShortcutMs:0}; resultClass={resultClass}");

                    if (elapsedAfterShortcutMs > 2600)
                        AppLogger.Warn($"auto-return-post-shortcut-hwnd-late: attemptId={attemptId}; slot={slot.Number}; tabId={tab.TabId}; try={tryNumber}; handle=0x{capturedHandle.ToInt64():X}; elapsedAfterShortcutMs={elapsedAfterShortcutMs:0}");

                    LogAutoReturnPostShortcutClassification(resultClass, string.Empty, tab, attemptId, slot, tryNumber, shortcutSent: true, shortcutSentUtc: shortcutSentUtc, capturedHandle: capturedHandle, restoredFocus: restoredFocus);

                    // Só minimiza o navegador depois que o foreground anterior estiver realmente
                    // confirmado. Isso evita o intervalo em que o Windows promovia a MainWindow.
                    var preMinimizeFocusRestored = GetForegroundWindow() == previousForeground
                        || await TryRestoreForegroundWindowVerifiedAsync(previousForeground, attemptId + "-pre-minimize", settleMs: 20);
                    restoredFocus = preMinimizeFocusRestored || restoredFocus;
                    AppLogger.Info($"auto-return-pre-minimize-focus-confirmed: attemptId={attemptId}; slot={slot.Number}; tabId={tab.TabId}; ok={preMinimizeFocusRestored}; foreground={DescribeForegroundWindow(GetForegroundWindow())}");

                    var browserMinimized = VideoCommandService.TryMinimizeExpectedBrowserWindow(tab.Domain, tab.Title);
                    AppLogger.Info($"auto-return-browser-minimized-after-confirmation: attemptId={attemptId}; slot={slot.Number}; tabId={tab.TabId}; ok={browserMinimized}; diagnostic={VideoCommandService.LastInputDiagnostic}");

                    var postMinimizeFocusRestored = await TryRestoreForegroundWindowVerifiedAsync(previousForeground, attemptId + "-post-minimize", settleMs: 35);
                    restoredFocus = postMinimizeFocusRestored || restoredFocus;
                    AppLogger.Info($"auto-return-post-minimize-focus-restore: attemptId={attemptId}; slot={slot.Number}; tabId={tab.TabId}; ok={postMinimizeFocusRestored}; foreground={DescribeForegroundWindow(GetForegroundWindow())}");

                    CompleteVideoSwitchPreservationAfterAutoReturn(
                        slot,
                        tab,
                        capturedHandle,
                        attemptId,
                        "focusless-auto-return-confirmed");

                    AppLogger.Warn($"auto-return-final-result: attemptId={attemptId}; slot={slot.Number}; tabId={tab.TabId}; result=confirmed; method=focusless; reasonCode=; hwndCaptured=True; restoredFocus={restoredFocus}; handle=0x{capturedHandle.ToInt64():X}; try={tryNumber}");
                    EndOpenPipAttempt(slot, tab, "Auto-retorno discreto", "confirmado");
                    return true;
                }

                finalReasonCode = "hwnd-not-found";
                LogAutoReturnPostShortcutClassification("shortcut-sent-no-hwnd", finalReasonCode, tab, attemptId, slot, tryNumber, shortcutSent: true, shortcutSentUtc: shortcutSentUtc, capturedHandle: IntPtr.Zero, restoredFocus: restoredFocus);
            }

            CleanupBrowserVisibilityAfterCancelledAutoReturn(
                tab,
                slot,
                previousForeground,
                attemptId,
                "final-not-confirmed");
            AppLogger.Warn($"auto-return-focusless-not-confirmed: attemptId={attemptId}; slot={slot.Number}; tabId={tab.TabId}; restoredFocus={restoredFocus}; reasonCode={finalReasonCode}; tries={maxDiscreteTries}");
            AppLogger.Warn($"auto-return-final-result: attemptId={attemptId}; slot={slot.Number}; tabId={tab.TabId}; result=failed; method=focusless; reasonCode={finalReasonCode}; hwndCaptured=False; restoredFocus={restoredFocus}; tries={maxDiscreteTries}");
            EndOpenPipAttempt(slot, tab, "Auto-retorno discreto", finalReasonCode);
            return false;
        }
        finally
        {
            if (!restoredFocus)
                _ = await TryRestoreForegroundWindowVerifiedAsync(previousForeground, attemptId + "-finally", settleMs: 20);
            EndMainWindowNoActivateLease(mainWindowActivationLease, attemptId);
        }
    }

    private void QueueAutoRecoverSlotPairs(string source, bool onlySuspicious)
    {
        if (_autoRecoverPairInProgress) return;
        if (!_extensionBridge.IsConnected) return;
        if ((DateTime.UtcNow - _lastAutoRecoverPairUtc).TotalMilliseconds < AutoRecoverPairCooldownMs) return;

        var candidates = Slots
            .Where(slot => slot.Window is not null || slot.State == PipSlotState.Offline || slot.State == PipSlotState.AwaitingPip)
            .Where(slot => SlotHasPairRecoverySignal(slot.Number))
            .Where(slot => !onlySuspicious || IsSlotPairSuspicious(slot.Number))
            .Select(slot => slot.Number)
            .Distinct()
            .ToArray();

        if (candidates.Length == 0) return;

        _lastAutoRecoverPairUtc = DateTime.UtcNow;
        _ = AutoRecoverSlotPairsAsync(candidates, source);
    }

    private bool SlotHasPairRecoverySignal(int slotNumber) =>
        _slotVideoPairs.ContainsKey(slotNumber)
        || _slotStableVideoPairs.ContainsKey(slotNumber)
        || _slotPairedTabIds.ContainsKey(slotNumber)
        || _slotPairDomains.ContainsKey(slotNumber);

    private bool IsSlotPairSuspicious(int slotNumber)
    {
        if (!_slotVideoPairs.TryGetValue(slotNumber, out var pairKey) || string.IsNullOrWhiteSpace(pairKey))
            return true;

        if (VideoTabs.Any(tab => string.Equals(tab.PairKey, pairKey, StringComparison.OrdinalIgnoreCase)
            || string.Equals(tab.VideoSessionId, pairKey, StringComparison.OrdinalIgnoreCase)))
            return false;

        if (_slotStableVideoPairs.TryGetValue(slotNumber, out var stableKey) && !string.IsNullOrWhiteSpace(stableKey))
        {
            var stableMatches = VideoTabs
                .Where(tab => string.Equals(tab.StableVideoKey, stableKey, StringComparison.OrdinalIgnoreCase))
                .ToList();

            if (stableMatches.Count == 1) return true;

            if (stableMatches.Count > 1 && _slotPairedTabIds.TryGetValue(slotNumber, out var tabId) && tabId > 0)
                return stableMatches.Count(tab => tab.TabId == tabId) == 1;
        }

        return true;
    }

    private async Task AutoRecoverSlotPairsAsync(IReadOnlyList<int> slotNumbers, string source)
    {
        if (_autoRecoverPairInProgress) return;
        _autoRecoverPairInProgress = true;

        try
        {
            try
            {
                await _extensionBridge.RequestVideoSessionsSnapshotAsync();
                await Task.Delay(450);
                ApplyVideoTabsFromCache(force: true);
            }
            catch
            {
                // Mantém o comportamento seguro: se o snapshot falhar, usa apenas o cache atual.
            }

            var recovered = 0;
            var skipped = 0;

            foreach (var slotNumber in slotNumbers)
            {
                var slot = Slots.FirstOrDefault(item => item.Number == slotNumber);
                if (slot is null) continue;
                if (!SlotHasPairRecoverySignal(slotNumber)) continue;

                var result = TryRecoverSlotPair(slotNumber);
                if (result.Tab is null)
                {
                    skipped++;
                    AppLogger.Info($"Auto-recuperar vínculo ignorado: slot={slotNumber}; origem={source}; motivo={result.Reason}");
                    RefreshSlotPairVisual(slot);
                    continue;
                }

                StoreSlotPair(slotNumber, result.Tab);
                RefreshSlotState(slot);
                RefreshSlotPairVisual(slot);
                recovered++;
                AppLogger.Info($"Auto-recuperar vínculo OK: slot={slotNumber}; origem={source}; metodo={result.Method}; session={result.Tab.VideoSessionId}; stable={result.Tab.StableVideoKey}; tabId={result.Tab.TabId}; domain={result.Tab.Domain}; title={result.Tab.Title}; url={result.Tab.Url}");
            }

            if (recovered > 0)
            {
                UpdateSelectedPipNotice();
                SetStatus($"Vínculo auto-recuperado em {recovered} slot(s)" + (skipped > 0 ? $"; {skipped} ambíguo(s) ignorado(s)" : string.Empty));
            }
        }
        finally
        {
            _autoRecoverPairInProgress = false;
        }
    }


    private async void RecoverSelectedPipPairButton_Click(object sender, RoutedEventArgs e) =>
        await RecoverSelectedPipPairAsync();

    private async Task RecoverSelectedPipPairAsync()
    {
        if (SelectedSlot is null)
        {
            SetStatus("Nenhum PiP selecionado para recuperar vínculo");
            return;
        }

        if (!_extensionBridge.IsConnected)
        {
            SetStatus("Extensão não conectada. Recarregue a extensão e tente novamente");
            return;
        }

        var slotNumber = SelectedSlot.Number;
        var hadAnySavedSignal = _slotVideoPairs.ContainsKey(slotNumber)
            || _slotStableVideoPairs.ContainsKey(slotNumber)
            || _slotPairedTabIds.ContainsKey(slotNumber)
            || _slotPairDomains.ContainsKey(slotNumber);

        if (!hadAnySavedSignal)
        {
            SetStatus($"PiP {slotNumber} não tem vínculo salvo para recuperar. Use Vincular manualmente primeiro.");
            return;
        }

        try
        {
            await _extensionBridge.RequestVideoSessionsSnapshotAsync();
            await Task.Delay(450);
            ApplyVideoTabsFromCache(force: true);
        }
        catch
        {
            // Mesmo se o snapshot falhar, tentamos com o cache atual.
        }

        var result = TryRecoverSlotPair(slotNumber);
        if (result.Tab is null)
        {
            SetStatus($"PiP {slotNumber}: vínculo não recuperado — {result.Reason}");
            AppLogger.Info($"Recuperar vínculo falhou: slot={slotNumber}; motivo={result.Reason}");
            RefreshSlotPairVisual(SelectedSlot);
            UpdateSelectedPipNotice();
            return;
        }

        StoreSlotPair(slotNumber, result.Tab);
        RefreshSlotState(SelectedSlot);
        RefreshSlotPairVisual(SelectedSlot);
        UpdateSelectedPipNotice();
        SetStatus($"PiP {slotNumber}: vínculo recuperado por {result.Method} → {result.Tab.ShortDescription}");
        AppLogger.Info($"Recuperar vínculo OK: slot={slotNumber}; metodo={result.Method}; session={result.Tab.VideoSessionId}; stable={result.Tab.StableVideoKey}; tabId={result.Tab.TabId}; domain={result.Tab.Domain}; title={result.Tab.Title}; url={result.Tab.Url}");
    }

    private sealed record SlotPairRecoveryResult(VideoTabInfo? Tab, string Method, string Reason);

    private SlotPairRecoveryResult TryRecoverSlotPair(int slotNumber)
    {
        _slotVideoPairs.TryGetValue(slotNumber, out var pairKey);
        _slotStableVideoPairs.TryGetValue(slotNumber, out var stableKey);
        _slotPairedTabIds.TryGetValue(slotNumber, out var tabId);
        _slotPairDomains.TryGetValue(slotNumber, out var savedDomain);

        var tabs = VideoTabs.ToList();
        if (tabs.Count == 0)
            return new SlotPairRecoveryResult(null, "none", "nenhuma sessão de vídeo detectada pela extensão");

        if (!string.IsNullOrWhiteSpace(pairKey))
        {
            var exact = tabs.Where(tab =>
                    string.Equals(tab.PairKey, pairKey, StringComparison.OrdinalIgnoreCase)
                    || string.Equals(tab.VideoSessionId, pairKey, StringComparison.OrdinalIgnoreCase))
                .ToList();
            if (exact.Count == 1)
                return new SlotPairRecoveryResult(exact[0], "videoSessionId", string.Empty);
            if (exact.Count > 1)
                return new SlotPairRecoveryResult(null, "videoSessionId", "videoSessionId ambíguo");
        }

        if (!string.IsNullOrWhiteSpace(stableKey))
        {
            var stableMatches = tabs
                .Where(tab => string.Equals(tab.StableVideoKey, stableKey, StringComparison.OrdinalIgnoreCase))
                .ToList();

            if (stableMatches.Count == 1)
                return new SlotPairRecoveryResult(stableMatches[0], "stableVideoKey", string.Empty);

            if (stableMatches.Count > 1 && tabId > 0)
            {
                var sameTab = stableMatches.Where(tab => tab.TabId == tabId).ToList();
                if (sameTab.Count == 1)
                    return new SlotPairRecoveryResult(sameTab[0], "stableVideoKey + tabId", string.Empty);
                return new SlotPairRecoveryResult(null, "stableVideoKey", "stableVideoKey ambíguo para a mesma aba");
            }

            if (stableMatches.Count > 1)
                return new SlotPairRecoveryResult(null, "stableVideoKey", "stableVideoKey ambíguo");
        }

        if (tabId > 0)
        {
            var sameTab = tabs.Where(tab => tab.TabId == tabId).ToList();
            if (sameTab.Count == 1)
                return new SlotPairRecoveryResult(sameTab[0], "tabId", string.Empty);
            if (sameTab.Count > 1)
                return new SlotPairRecoveryResult(null, "tabId", "a aba vinculada tem mais de um vídeo detectado");
        }

        if (!string.IsNullOrWhiteSpace(savedDomain))
        {
            var domainMatches = tabs
                .Where(tab => string.Equals(GetDomainForTab(tab), savedDomain, StringComparison.OrdinalIgnoreCase))
                .ToList();
            if (domainMatches.Count == 1)
                return new SlotPairRecoveryResult(domainMatches[0], "domínio", string.Empty);
            if (domainMatches.Count > 1)
                return new SlotPairRecoveryResult(null, "domínio", $"domínio {savedDomain} tem mais de um vídeo detectado");
        }

        return new SlotPairRecoveryResult(null, "none", "nenhum alvo único encontrado");
    }

    private (string? PairKey, string? VideoSessionId, string? StableVideoKey, int? TabId) TryGetSelectedPairedVideoTarget()
    {
        if (SelectedSlot is null) return (null, null, null, null);
        if (!_slotVideoPairs.TryGetValue(SelectedSlot.Number, out var pairKey) || string.IsNullOrWhiteSpace(pairKey))
            return (null, null, null, null);

        var tab = VideoTabs.FirstOrDefault(item => string.Equals(item.PairKey, pairKey, StringComparison.OrdinalIgnoreCase));
        if (tab is not null)
        {
            StoreSlotPair(SelectedSlot.Number, tab);
            return (pairKey, tab.VideoSessionId, tab.StableVideoKey, tab.TabId);
        }

        _slotStableVideoPairs.TryGetValue(SelectedSlot.Number, out var stableKey);
        _slotPairedTabIds.TryGetValue(SelectedSlot.Number, out var oldTabId);

        if (!string.IsNullOrWhiteSpace(stableKey))
        {
            var stableMatches = VideoTabs
                .Where(item => string.Equals(item.StableVideoKey, stableKey, StringComparison.OrdinalIgnoreCase))
                .ToList();

            if (stableMatches.Count == 1)
            {
                var reconnected = stableMatches[0];
                StoreSlotPair(SelectedSlot.Number, reconnected);
                AppLogger.Info($"Vínculo reconectado por stableVideoKey: slot={SelectedSlot.Number}; oldPair={pairKey}; newSession={reconnected.VideoSessionId}; stable={stableKey}");
                UpdateSelectedPipNotice();
                return (reconnected.PairKey, reconnected.VideoSessionId, reconnected.StableVideoKey, reconnected.TabId);
            }

            if (stableMatches.Count > 1 && oldTabId > 0)
            {
                var sameTab = stableMatches.Where(item => item.TabId == oldTabId).ToList();
                if (sameTab.Count == 1)
                {
                    var reconnected = sameTab[0];
                    StoreSlotPair(SelectedSlot.Number, reconnected);
                    AppLogger.Info($"Vínculo reconectado por stableVideoKey+tabId: slot={SelectedSlot.Number}; oldPair={pairKey}; newSession={reconnected.VideoSessionId}; stable={stableKey}; tabId={oldTabId}");
                    UpdateSelectedPipNotice();
                    return (reconnected.PairKey, reconnected.VideoSessionId, reconnected.StableVideoKey, reconnected.TabId);
                }
            }

            // O app manda session antiga + stable key; o background só executa se achar alvo único.
            return (pairKey, pairKey, stableKey, oldTabId > 0 ? oldTabId : null);
        }

        return (pairKey, pairKey, null, oldTabId > 0 ? oldTabId : null);
    }

    private void RefreshAllSlotPairVisuals()
    {
        foreach (var slot in Slots)
            RefreshSlotPairVisual(slot);
    }

    private void RefreshSlotPairVisual(PipSlot slot)
    {
        if (slot is null) return;

        var state = slot.State switch
        {
            PipSlotState.Active => "Ativo",
            PipSlotState.Hidden => "Oculto",
            PipSlotState.Offline => "Offline",
            PipSlotState.AwaitingPip => "Aguardando",
            _ => "Livre"
        };

        if (!_slotVideoPairs.TryGetValue(slot.Number, out var pairKey) || string.IsNullOrWhiteSpace(pairKey))
        {
            slot.PairDomain = string.Empty;
            slot.PairStateText = "Sem vínculo";
            slot.PairDetailText = $"Estado: {state}\nVínculo: sem vínculo com aba/vídeo";
            slot.PlaylistText = string.Empty;
            ScheduleNextPreviewUpdate();
            return;
        }

        _slotStableVideoPairs.TryGetValue(slot.Number, out var stableKey);
        _slotPairedTabIds.TryGetValue(slot.Number, out var tabId);
        _slotPairDomains.TryGetValue(slot.Number, out var savedDomain);

        var tab = VideoTabs.FirstOrDefault(item => string.Equals(item.PairKey, pairKey, StringComparison.OrdinalIgnoreCase));
        var foundBy = "videoSessionId";

        if (tab is null && !string.IsNullOrWhiteSpace(stableKey))
        {
            var stableMatches = VideoTabs
                .Where(item => string.Equals(item.StableVideoKey, stableKey, StringComparison.OrdinalIgnoreCase))
                .ToList();
            if (stableMatches.Count == 1)
            {
                tab = stableMatches[0];
                foundBy = "stableVideoKey";
            }
            else if (stableMatches.Count > 1 && tabId > 0)
            {
                var sameTab = stableMatches.Where(item => item.TabId == tabId).ToList();
                if (sameTab.Count == 1)
                {
                    tab = sameTab[0];
                    foundBy = "stableVideoKey + tabId";
                }
                else
                {
                    foundBy = "stableVideoKey ambíguo";
                }
            }
            else if (stableMatches.Count > 1)
            {
                foundBy = "stableVideoKey ambíguo";
            }
        }

        var domain = tab is not null ? GetDomainForTab(tab) : string.Empty;
        if (string.IsNullOrWhiteSpace(domain) && !string.IsNullOrWhiteSpace(savedDomain))
            domain = savedDomain;
        if (string.IsNullOrWhiteSpace(domain))
            domain = tabId > 0 ? $"aba {tabId}" : "Vínculo salvo";

        var linkState = tab is null ? "Vínculo salvo" : "Vínculo OK";
        slot.PairDomain = domain;
        slot.PairStateText = linkState;
        slot.PlaylistText = BuildSlotPlaylistText(tab);
        _ = ApplySlotPreloadSettingAsync(slot.Number, tab);
        if (!string.IsNullOrWhiteSpace(slot.PlaylistText))
        {
            var signature = $"{tab?.Url}|{slot.PlaylistText}";
            if (!_slotPlaylistLogSignatures.TryGetValue(slot.Number, out var previous) || !string.Equals(previous, signature, StringComparison.Ordinal))
            {
                _slotPlaylistLogSignatures[slot.Number] = signature;
                AppLogger.Info($"playlist-context-slot-visible: slot={slot.Number}; detectedByExtension={tab?.PlaylistDetected == true}; playlistIndex={ResolvePlaylistIndex(tab)}; currentTitle={tab?.CurrentItemTitle}; nextCount={tab?.NextTitles.Count ?? 0}; url={tab?.Url}");
            }
        }
        else
        {
            _slotPlaylistLogSignatures.Remove(slot.Number);
        }
        ScheduleNextPreviewUpdate();
        slot.PairDetailText =
            $"Estado: {state}\n" +
            $"Vínculo: {linkState}\n" +
            $"Domínio: {domain}\n" +
            $"Aba: {(tab?.TabId ?? tabId).ToString()}" + (tab is null ? string.Empty : $" / vídeo {tab.VideoIndex + 1}") + "\n" +
            (tab is null ? string.Empty : $"Título: {tab.Title}\n") +
            $"Match: {foundBy}\n" +
            $"Sessão: {ShortId(pairKey)}" +
            (string.IsNullOrWhiteSpace(stableKey) ? string.Empty : $"\nStable: {ShortId(stableKey)}");
    }

    private static string BuildSlotPlaylistText(VideoTabInfo? tab)
    {
        if (tab is null) return string.Empty;
        var inferredIndex = ResolvePlaylistIndex(tab);
        var playlistUrl = IsPlaylistUrl(tab.Url);
        if (!tab.PlaylistDetected && !playlistUrl && inferredIndex < 0) return string.Empty;
        var position = inferredIndex >= 0 ? $"#{inferredIndex + 1}" : "#?";
        var current = string.IsNullOrWhiteSpace(tab.CurrentItemTitle) ? tab.Title : tab.CurrentItemTitle;
        current = string.IsNullOrWhiteSpace(current) ? "título atual indisponível" : current.Trim();
        if (current.Length > 34) current = current[..34] + "…";
        var upcoming = tab.NextTitles
            .Select((title, index) => new { title, index })
            .Where(item => item.index < 5)
            .Select(item => item.title)
            .Select(title => title.Length > 28 ? title[..28] + "…" : title)
            .ToArray();
        return upcoming.Length == 0
            ? $"Playlist {position} • {current}"
            : $"Playlist {position} • {current}\nPróx.: {string.Join(" › ", upcoming)}";
    }

    private static int ResolvePlaylistIndex(VideoTabInfo? tab)
    {
        if (tab is null) return -1;
        if (tab.PlaylistIndex >= 0) return tab.PlaylistIndex;
        return ResolvePlaylistIndexFromUrl(tab.Url);
    }

    private static int ResolvePlaylistIndexFromUrl(string? url)
    {
        try
        {
            if (!Uri.TryCreate(url, UriKind.Absolute, out var uri)) return -1;
            var query = System.Web.HttpUtility.ParseQueryString(uri.Query);
            foreach (var key in new[] { "index", "episode", "item" })
            {
                if (int.TryParse(query[key], out var value) && value >= 0) return value;
            }
        }
        catch { }
        return -1;
    }

    private static bool IsPlaylistUrl(string? url)
    {
        if (string.IsNullOrWhiteSpace(url)) return false;
        return url.Contains("/playlist", StringComparison.OrdinalIgnoreCase)
            || url.Contains("/episodes", StringComparison.OrdinalIgnoreCase)
            || url.Contains("?index=", StringComparison.OrdinalIgnoreCase)
            || url.Contains("&index=", StringComparison.OrdinalIgnoreCase);
    }

    private static string GetDomainForTab(VideoTabInfo tab)
    {
        if (!string.IsNullOrWhiteSpace(tab.Domain))
            return tab.Domain.Trim();

        try
        {
            if (!string.IsNullOrWhiteSpace(tab.Url))
                return new Uri(tab.Url).Host.Replace("www.", string.Empty, StringComparison.OrdinalIgnoreCase);
        }
        catch { }

        return string.Empty;
    }

    private string GetPairTextForSlot(int slotNumber)
    {
        if (!_slotVideoPairs.TryGetValue(slotNumber, out var videoSessionId)) return string.Empty;
        return GetPairTextForSession(videoSessionId);
    }

    private string GetPairTextForSession(string videoSessionId)
    {
        var tab = VideoTabs.FirstOrDefault(item => item.PairKey == videoSessionId);
        if (tab is null) return $"sessão {ShortId(videoSessionId)}";
        return $"{tab.ShortDescription}";
    }

    private static string ShortId(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return "sem vínculo";
        return value.Length <= 18 ? value : value[..18] + "...";
    }

    private void MinimizeButton_Click(object sender, RoutedEventArgs e) => WindowState = WindowState.Minimized;

    private void MaximizeButton_Click(object sender, RoutedEventArgs e) =>
        WindowState = WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;

    private void CloseButton_Click(object sender, RoutedEventArgs e) => Close();

    private void SetSlotCount(int count)
    {
        count = Math.Clamp(count, 1, 10);
        while (Slots.Count < count)
        {
            var slot = new PipSlot(Slots.Count + 1);
            MarkSlotFree(slot);
            Slots.Add(slot);
        }
        while (Slots.Count > count) Slots.RemoveAt(Slots.Count - 1);
        ReconcileJogoManualPlacementSlots();
        EnsureSlotLayoutRects();
        UpdatePanelSlotVisuals();
        UpdateCounts();
    
        NormalizeSlotAutoReturnSettings(migrateFromGlobal: false);
        UpdateAutoReturnPolicyVisual();
    }

    private bool TrySetSlotCountPreservingPips(int count)
    {
        count = Math.Clamp(count, 1, 10);

        var occupied = Slots
            .Where(slot => slot.Window is not null)
            .OrderBy(slot => slot.Number)
            .Select(slot => new { slot.Window, slot.IsHidden, slot.State })
            .ToList();

        if (count < occupied.Count)
        {
            MessageBox.Show(
                $"Você tem {occupied.Count} PiP(s) capturado(s).\n\nSolte ou feche PiPs antes de reduzir para {count} slot(s).",
                "PiP Manager",
                MessageBoxButton.OK,
                MessageBoxImage.Information);
            return false;
        }

        SelectedSlot = null;
        Slots.Clear();
        for (var index = 0; index < count; index++)
        {
            var slot = new PipSlot(index + 1);
            if (index < occupied.Count)
            {
                slot.Window = occupied[index].Window;
                slot.IsHidden = occupied[index].IsHidden;
                slot.State = occupied[index].State;
            }
            else
            {
                MarkSlotFree(slot);
            }
            Slots.Add(slot);
        }

        ReconcileJogoManualPlacementSlots();
        _slotLayoutRects = _slotLayoutRects.Where(rect => rect.IsValid).Take(count).ToList();
        EnsureSlotLayoutRects();
        if (EditableSlots.Count > count)
        {
            while (EditableSlots.Count > count)
                EditableSlots.RemoveAt(EditableSlots.Count - 1);
        }
        else if (_customLayoutActive && EditableSlots.Count < count)
        {
            BuildCustomSlotOverlay(forceReset: true);
        }

        UpdatePanelSlotVisuals();
        RefreshAllSlotStates();
        if (_groupLocked)
            SaveLockedGroupModelFromCurrentRects();
        if (_fixedCustomLayoutEnabled)
            RebuildFixedAuthorityAfterEditorChange("slot-count-changed");
        return true;
    }

    private void RefreshCapturedWindows()
    {
        var changed = false;
        var lostCount = 0;
        var externallyResizedSlots = new HashSet<int>();
        var healthNow = DateTime.UtcNow;
        var refreshGeometry = (healthNow - _lastHealthGeometryRefreshUtc).TotalMilliseconds >= HealthGeometryRefreshMs;
        if (refreshGeometry)
            _lastHealthGeometryRefreshUtc = healthNow;

        List<PipWindowInfo>? discovered = null;
        HashSet<IntPtr>? usedHandles = null;

        void EnsureDiscoveryForRecovery()
        {
            if (discovered is not null && usedHandles is not null)
                return;

            discovered = _discovery.FindPipWindows();
            usedHandles = Slots
                .Where(item => item.Window is not null && PipWindowService.IsUsable(item.Window!.Handle))
                .Select(item => item.Window!.Handle)
                .ToHashSet();
        }

        foreach (var slot in Slots.Where(slot => slot.Window is not null).ToArray())
        {
            var handle = slot.Window!.Handle;
            try
            {
                if (!PipWindowService.IsUsable(handle))
                {
                    EnsureDiscoveryForRecovery();
                    if (TryReconnectSlotWindow(slot, discovered!, usedHandles!, "Monitor de PiP"))
                    {
                        changed = true;
                        continue;
                    }

                    if (!ShouldRemoveLostSlot(slot, "Monitor de PiP"))
                    {
                        lostCount++;
                        continue;
                    }

                    RemoveSlotPipFinal(slot, "Monitor de PiP");
                    changed = true;
                    lostCount++;
                    continue;
                }

                TryClassifyPreservedSameHwnd(slot, "Monitor de PiP");
                ClearLostSlotState(slot);
                if (!slot.IsHidden)
                    MarkSlotActive(slot);

                if (!refreshGeometry)
                    continue;

                var rect = PipWindowService.GetVisualRect(handle);
                if (rect.IsValid) _lastObservedRectBySlot[slot.Number] = rect;
                if (rect.IsValid && rect != slot.Window.VisualRect)
                {
                    if (TryEnforceReconnectGeometryAuthority(slot, rect, "Monitor de PiP"))
                        continue;

                    var previousRect = slot.Window.VisualRect;
                    var withinDwmTolerance = previousRect.IsValid &&
                        Math.Abs(rect.Left - previousRect.Left) <= LayoutMovePositionTolerancePx &&
                        Math.Abs(rect.Top - previousRect.Top) <= LayoutMovePositionTolerancePx &&
                        Math.Abs(rect.Width - previousRect.Width) <= LayoutMoveSizeTolerancePx &&
                        Math.Abs(rect.Height - previousRect.Height) <= LayoutMoveSizeTolerancePx;

                    if (IsLayoutTransactionActive() || withinDwmTolerance)
                    {
                        if (!withinDwmTolerance)
                            slot.RefreshWindow(slot.Window with { VisualRect = rect });
                    }
                    else
                    {
                        if (DateTime.UtcNow >= _ignoreWindowMovesUntilUtc &&
                            (Math.Abs(rect.Width - previousRect.Width) > LayoutMoveSizeTolerancePx ||
                             Math.Abs(rect.Height - previousRect.Height) > LayoutMoveSizeTolerancePx))
                        {
                            var suppressFixedLayoutEcho = _fixedCustomLayoutEnabled
                                && ShouldSuppressFixedLayoutExternalResizeEcho(slot, rect, previousRect);
                            if (!suppressFixedLayoutEcho)
                            {
                                _lastResizedSlotNumber = slot.Number;
                                externallyResizedSlots.Add(slot.Number);
                                AppLogger.Info($"PiP redimensionado externamente no slot {slot.Number}: {FormatRect(rect)}");
                            }
                        }
                        slot.RefreshWindow(slot.Window with { VisualRect = rect });
                    }
                }
            }
            catch (Exception ex)
            {
                AppLogger.Error($"Falha ao atualizar o slot {slot.Number}; mantendo temporariamente para tentar reconectar", ex);
                EnsureDiscoveryForRecovery();
                if (!TryReconnectSlotWindow(slot, discovered!, usedHandles!, "Monitor de PiP") && ShouldRemoveLostSlot(slot, "Monitor de PiP"))
                {
                    RemoveSlotPipFinal(slot, "Monitor de PiP");
                    changed = true;
                }
                lostCount++;
            }
        }

        if (changed)
        {
            if (!Slots.Any(slot => slot.Window is not null))
            {
                _allHidden = false;
                VisibilityButton.Content = "Ocultar PiPs";
                _toolbar?.SetHiddenState(false);
            }

            UpdateCounts();
            UpdateSelectedActions();
            RefreshPipDragTargets();
            PositionToolbar();
            if (_groupLocked)
                SaveLockedGroupModelFromCurrentRects();

            if (lostCount > 0)
                SetStatus($"{lostCount} PiP(s) instável(is): aguardando reconexão ou removido(s) após confirmação");

            QueueAutoRecoverSlotPairs("monitor", onlySuspicious: true);
        }

        if (externallyResizedSlots.Count > 0 && !_allHidden)
        {
            if (_fixedCustomLayoutEnabled)
                QueueFixedAspectGroupReflow(externallyResizedSlots, "monitor/external-size-change");
            else if (_groupLocked || _customLayoutActive || CurrentLayout == LayoutMode.Jogo)
                QueueMixedAspectGroupReflow(externallyResizedSlots, "monitor/external-size-change");
        }

        // O modo Travar agora é passivo: não corrige o grupo em loop.
        // Correção/realinhamento só acontece ao soltar o arraste.
        var bounds = _layoutService.GetGroupBounds(Slots);
        if (bounds.IsValid) _lastKnownGroupBounds = bounds;
    }

    private bool IsLayoutTransactionActive()
        => _layoutTransactionDepth > 0 || DateTime.UtcNow < _layoutTransactionUntilUtc;

    private int BeginLayoutTransaction(string source, int settleMs = 650)
    {
        _layoutTransactionDepth++;
        _layoutTransactionGeneration++;
        _layoutTransactionUntilUtc = DateTime.UtcNow.AddMilliseconds(Math.Max(350, settleMs));
        _ignoreWindowMovesUntilUtc = _layoutTransactionUntilUtc;
        AppLogger.Info($"layout-transaction-start: generation={_layoutTransactionGeneration}; depth={_layoutTransactionDepth}; source={source}; settleMs={settleMs}");
        return _layoutTransactionGeneration;
    }

    private void EndLayoutTransaction(int generation, string source)
    {
        _layoutTransactionDepth = Math.Max(0, _layoutTransactionDepth - 1);
        AppLogger.Info($"layout-transaction-end: generation={generation}; depth={_layoutTransactionDepth}; source={source}; suppressUntil={_layoutTransactionUntilUtc:O}");
    }

    private void EnsureVisiblePipsTopMost(bool force = false)
    {
        if (_allHidden) return;

        var now = DateTime.UtcNow;
        if (!force && (now - _lastTopMostRefreshUtc).TotalMilliseconds < TopMostRefreshMs)
            return;

        _lastTopMostRefreshUtc = now;
        var corrected = 0;
        foreach (var slot in Slots.Where(slot => slot.Window is not null && !slot.IsHidden))
        {
            try
            {
                var handle = slot.Window!.Handle;
                if (PipWindowService.IsUsable(handle)
                    && (force || !PipWindowService.IsTopMost(handle)))
                {
                    PipWindowService.SetTopMost(handle);
                    corrected++;
                }
            }
            catch (Exception ex)
            {
                AppLogger.Error($"Falha ao aplicar sempre no topo no slot {slot.Number}", ex);
            }
        }

        if (corrected > 0)
        {
            AppLogger.InfoAggregated(
                "pip-topmost-corrected",
                TimeSpan.FromSeconds(10),
                $"pip-topmost-corrected: windows={corrected}; force={force}; mode=style-check-before-async-setwindowpos");
        }
    }

    private void UpdateCounts()
    {
        var captured = Slots.Count(slot => slot.Window is not null);
        var active = 0;
        var lost = 0;

        foreach (var slot in Slots.Where(slot => slot.Window is not null))
        {
            try
            {
                if (PipWindowService.IsUsable(slot.Window!.Handle))
                    active++;
                else
                    lost++;
            }
            catch
            {
                lost++;
            }
        }

        var pendentes = _pendingLostPipsBySlot.Count;
        CountText.Text = pendentes > 0
            ? $"PiPs capturados: {captured} | ativos: {active} | reconectando: {pendentes}"
            : $"PiPs capturados: {captured} | ativos: {active} | perdidos: {lost}";
        UpdateSelectedPipNotice();
    }



    private void ClearShadowOpenAttemptForSlot(int slotNumber, string source)
    {
        if (_shadowOpenAttemptIdBySlot.Remove(slotNumber))
            AppLogger.Info($"shadow-mode-attempt-cleared: source={source}; slot={slotNumber}");
    }

    private string GetOrCreateShadowReconnectAttemptId(PipSlot slot, string source)
    {
        if (_shadowReconnectAttemptIdBySlot.TryGetValue(slot.Number, out var existing) &&
            !string.IsNullOrWhiteSpace(existing))
        {
            return existing;
        }

        var attemptId = $"shadow-reconnect-{slot.Number}-{DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()}";
        _shadowReconnectAttemptIdBySlot[slot.Number] = attemptId;
        AppLogger.Info($"shadow-mode-reconnect-attempt-created: source={source}; slot={slot.Number}; attemptId={attemptId}");
        return attemptId;
    }

    private void ClearShadowReconnectAttemptForSlot(int slotNumber, string source)
    {
        if (_shadowReconnectAttemptIdBySlot.Remove(slotNumber))
            AppLogger.Info($"shadow-mode-reconnect-attempt-cleared: source={source}; slot={slotNumber}");
    }

    private void ShadowMirrorVideoChanged(PipSlot slot, string videoSessionId, string stableVideoKey, string source)
    {
        ShadowImportSlotSnapshot(slot, source + "/before-videochanged");
        var attemptId = GetOrCreateShadowReconnectAttemptId(slot, source);
        ShadowMirrorEvent(new VideoChanged(slot.Number, videoSessionId, stableVideoKey, attemptId), source);
    }

    private void ShadowMirrorReconnectStarted(PipSlot slot, string source)
    {
        _automationCoordinator.ObserveLegacyReconnectStarted(slot.Number, source);
        var attemptId = GetOrCreateShadowReconnectAttemptId(slot, source);
        var current = _shadowModeRuntime.GetEngineSnapshot().FirstOrDefault(item => item.SlotNumber == slot.Number);
        if (current?.State == SlotState.Failed)
        {
            ShadowMirrorEvent(
                new ReconnectRetryQueued(slot.Number, attemptId),
                source + "/retry-queued-after-failed",
                "legacy-retry-normalized-to-waiting");
        }

        ShadowMirrorEvent(new ReconnectStarted(slot.Number, attemptId), source);
    }

    private void ShadowMirrorPreservedSameHwndConfirmed(PipSlot slot, IntPtr hwnd, string source)
    {
        if (hwnd == IntPtr.Zero)
            return;

        var attemptId = GetOrCreateShadowReconnectAttemptId(slot, source);
        var accepted = ShadowMirrorEvent(
            new PreservedSameHwndConfirmed(slot.Number, hwnd, attemptId),
            source,
            "legacy-preserved-same-hwnd-confirmed");

        if (accepted)
        {
            _shadowExternalCaptureSlots.Remove(slot.Number);
            ClearShadowReconnectAttemptForSlot(slot.Number, source + "/PreservedSameHwndConfirmed");
        }

        ShadowLogLegacyComparison(slot, source + "/PreservedSameHwndConfirmed", "legacy-preserved-same-hwnd-active");
    }

    private void ShadowMirrorReconnectSucceeded(PipSlot slot, IntPtr hwnd, string source)
    {
        if (hwnd == IntPtr.Zero)
            return;

        _automationCoordinator.ObserveLegacyReconnectSucceeded(slot.Number, hwnd, source);

        var attemptId = GetOrCreateShadowReconnectAttemptId(slot, source);

        // 9.33.16: caminhos alternativos podem chegar ao terminal sem Started.
        // Para o Core, sucesso/falha só são válidos em Reconnecting.
        ShadowMirrorEvent(new ReconnectStarted(slot.Number, attemptId), source + "/ensure-started-before-success", "legacy-terminal-success-ensure-started");

        var accepted = ShadowMirrorEvent(new ReconnectSucceeded(slot.Number, hwnd, attemptId), source, "legacy-reconnect-success");
        if (accepted)
        {
            _shadowExternalCaptureSlots.Remove(slot.Number);
            ClearShadowReconnectAttemptForSlot(slot.Number, source + "/ReconnectSucceeded");
        }
    }

    private void ShadowMirrorReconnectFailed(PipSlot slot, string reason, string source)
    {
        _automationCoordinator.ObserveLegacyReconnectFailed(slot.Number, reason, source);
        var attemptId = GetOrCreateShadowReconnectAttemptId(slot, source);

        // 9.33.16: garantir a ordem WaitingForReconnect -> Reconnecting -> Failed.
        ShadowMirrorEvent(new ReconnectStarted(slot.Number, attemptId), source + "/ensure-started-before-failed", "legacy-terminal-failed-ensure-started");

        var accepted = ShadowMirrorEvent(new ReconnectFailed(slot.Number, reason, attemptId), source, "legacy-reconnect-failed");
        if (accepted)
            ClearShadowReconnectAttemptForSlot(slot.Number, source + "/ReconnectFailed");
    }

    private void ShadowMirrorAutoReturnCancelled(PipSlot slot, string reason, string source)
    {
        // Desligar o AutoRetorno é uma decisão explícita do usuário, não uma falha operacional.
        // Encerramos a tentativa no Shadow por reset/cancelamento para evitar estado Failed artificial.
        ClearShadowOpenAttemptForSlot(slot.Number, source + "/cancel-open");
        ClearShadowReconnectAttemptForSlot(slot.Number, source + "/cancel-reconnect");
        _shadowExternalCaptureSlots.Remove(slot.Number);
        var attemptId = $"shadow-autoreturn-cancel-{slot.Number}-{DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()}";
        ShadowMirrorEvent(new SlotResetRequested(slot.Number, attemptId), source, $"legacy-autoreturn-disabled-cancelled:{reason}");
        ShadowLogLegacyComparison(slot, source + "/cancelled", "legacy-autoreturn-disabled-cancelled");
    }

    private void ShadowLogLegacyComparison(PipSlot slot, string source, string legacyOutcome)
    {
        try
        {
            var snapshot = _shadowModeRuntime.GetEngineSnapshot().FirstOrDefault(s => s.SlotNumber == slot.Number);
            AppLogger.Info(
                $"shadow-mode-legacy-compare: source={source}; slot={slot.Number}; legacy={legacyOutcome}; " +
                $"shadowState={snapshot?.State.ToString() ?? "null"}; shadowAutoReturn={snapshot?.AutoReturnEnabled.ToString() ?? "null"}; " +
                $"shadowHwnd={(snapshot?.PipHwnd.HasValue == true ? $"0x{snapshot.PipHwnd.Value.ToInt64():X}" : "null")}");
        }
        catch (Exception ex)
        {
            AppLogger.Warn($"shadow-mode-legacy-compare-failed: source={source}; slot={slot.Number}; reason={ex.Message}");
        }
    }

    private void ShadowImportSlotSnapshot(PipSlot slot, string source)
    {
        try
        {
            var snapshot = SlotSnapshotMapper.FromLegacy(
                slot.Number,
                slot.State.ToString(),
                slot.IsAutoReturnEnabled,
                isLocked: _groupLocked,
                pipHwnd: slot.Window?.Handle);

            _shadowModeRuntime.ImportSnapshot(snapshot);
            AppLogger.Info($"shadow-mode-snapshot-imported: source={source}; slot={slot.Number}; state={snapshot.State}; hidden={snapshot.IsHidden}; hwnd={(snapshot.PipHwnd.HasValue ? $"0x{snapshot.PipHwnd.Value.ToInt64():X}" : "null")}");
        }
        catch (Exception ex)
        {
            AppLogger.Warn($"shadow-mode-snapshot-import-ignored: source={source}; slot={slot.Number}; legacyState={slot.State}; reason={ex.Message}");
        }
    }



    private static string ShadowRedact(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return "-";
        var text = value.Replace("\r", " ").Replace("\n", " ").Trim();
        if (text.Contains("://", StringComparison.OrdinalIgnoreCase)) return "[url-redacted]";
        if (text.Length > 80) return text[..80] + "...";
        return text;
    }

    private void ShadowLogStartupVersion()
    {
        AppLogger.Info("pipmanager-startup: product=9.34.00; app=1.5.8.3400; extension=1.4.34.0; core=net8.0; mode=ShadowOnly");
    }

    private void TryRotateOperationalLog()
    {
        try
        {
            var appData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            if (string.IsNullOrWhiteSpace(appData)) return;
            var logPath = Path.Combine(appData, "PiPManagerWPF", "pip_manager.log");
            if (!File.Exists(logPath)) return;
            var info = new FileInfo(logPath);
            const long maxBytes = 5L * 1024L * 1024L;
            if (info.Length < maxBytes) return;
            var rotated = Path.Combine(info.DirectoryName ?? appData, $"pip_manager-{DateTime.Now:yyyyMMdd-HHmmss}.log");
            File.Move(logPath, rotated, overwrite: false);
        }
        catch { }
    }

    private void ShadowRecordParity(string source, string legacyOutcome, ShadowDecisionResult result)
    {
        try
        {
            _shadowParityReport.Add(source, legacyOutcome, result);
            AppLogger.Info($"shadow-parity-recorded: source={ShadowRedact(source)}; legacy={ShadowRedact(legacyOutcome)}; event={result.Event.Name}; slot={result.Event.SlotNumber}; accepted={result.Accepted}; stateChanged={result.StateChanged}; shadowState={result.Slot?.State.ToString() ?? "null"}; ignoredReason={result.IgnoredReason ?? "-"}");
        }
        catch (Exception ex)
        {
            AppLogger.Warn($"shadow-parity-record-failed: source={source}; legacy={legacyOutcome}; reason={ex.Message}");
        }
    }


    private string GetShadowParityReportDirectory()
    {
        var appData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
        if (string.IsNullOrWhiteSpace(appData))
            appData = AppDomain.CurrentDomain.BaseDirectory;

        return Path.Combine(appData, "PiPManager", "ShadowParityReports");
    }

    private void ShadowSaveParityReport(string source)
    {
        try
        {
            var path = _shadowParityReport.SaveTextReport(GetShadowParityReportDirectory());
            AppLogger.Info($"shadow-parity-report-saved: source={source}; path={path}");
        }
        catch (Exception ex)
        {
            AppLogger.Warn($"shadow-parity-report-save-failed: source={source}; reason={ex.Message}");
        }
    }

    private bool ShadowMirrorEvent(AutomationEvent ev, string source, string legacyOutcome = "legacy-observed")
    {
        try
        {
            var result = _shadowModeRuntime.Mirror(ev);
            var actions = result.PredictedActions.Count == 0
                ? "-"
                : string.Join("|", result.PredictedActions.Select(action => action.Name));

            AppLogger.Info(
                $"shadow-mode-event: source={source}; event={ev.Name}; slot={ev.SlotNumber}; attemptId={ev.AttemptId}; " +
                $"processed={result.Processed}; accepted={result.Accepted}; stateChanged={result.StateChanged}; executed={result.Executed}; " +
                $"reason={result.Reason}; ignoredReason={result.IgnoredReason ?? "-"}; actions={actions}");

            ShadowRecordParity(source, legacyOutcome, result);
            return result.Accepted;
        }
        catch (Exception ex)
        {
            AppLogger.Warn($"shadow-mode-event-failed: source={source}; event={ev.Name}; slot={ev.SlotNumber}; attemptId={ev.AttemptId}; reason={ex.Message}");
            return false;
        }
    }

    private void ShadowMirrorSlotReset(PipSlot slot, string source)
    {
        ClearShadowOpenAttemptForSlot(slot.Number, source);
        ClearShadowReconnectAttemptForSlot(slot.Number, source);
        _shadowExternalCaptureSlots.Remove(slot.Number);
        var attemptId = $"shadow-reset-{slot.Number}-{DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()}";
        ShadowMirrorEvent(new SlotResetRequested(slot.Number, attemptId), source, "legacy-slot-reset");
    }

    private void ShadowMirrorManualOpenRequested(PipSlot slot, VideoTabInfo tab, string source)
    {
        // Abertura manual aceita domina o ciclo do slot.
        // Cancela reconexão Shadow antiga para não contaminar a próxima captura.
        ClearShadowReconnectAttemptForSlot(slot.Number, source + "/manual-open-cancels-reconnect");
        _shadowExternalCaptureSlots.Remove(slot.Number);

        ShadowImportSlotSnapshot(slot, source + "/before-open");
        var attemptId = $"shadow-open-{slot.Number}-{tab.TabId}-{DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()}";
        _shadowOpenAttemptIdBySlot[slot.Number] = attemptId;
        ShadowMirrorEvent(new UserOpenPipRequested(slot.Number, tab.TabId, attemptId), source, "legacy-manual-open-accepted");
    }

    private void ShadowMirrorPipCaptured(PipSlot slot, IntPtr hwnd, string source)
    {
        if (hwnd == IntPtr.Zero)
            return;

        if (!_shadowReconnectAttemptIdBySlot.ContainsKey(slot.Number))
            _automationCoordinator.ObserveLegacyCaptured(slot.Number, hwnd, source);
        else
            AppLogger.Info($"automation-capture-deferred-to-reconnect-success: slot={slot.Number}; hwnd=0x{hwnd.ToInt64():X}; source={source}");

        // 9.33.12:
        // Não importar o snapshot pós-captura aqui. Neste ponto o legado já pode ter marcado
        // o slot como Active, e importar esse estado apagaria o Opening criado pelo hook de abertura.
        // Captura legítima deve reutilizar o AttemptId pendente da abertura aceita.
        var hasPendingAttempt = _shadowOpenAttemptIdBySlot.TryGetValue(slot.Number, out var pendingAttemptId);
        var attemptId = hasPendingAttempt && !string.IsNullOrWhiteSpace(pendingAttemptId)
            ? pendingAttemptId
            : $"shadow-external-capture-{slot.Number}-{hwnd.ToInt64():X}-{DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()}";

        if (hasPendingAttempt)
        {
            // Captura de abertura manual pendente tem prioridade sobre reconexão Shadow antiga.
            ShadowMirrorEvent(new PipWindowCaptured(slot.Number, hwnd, attemptId), source, "legacy-manual-capture-active");
        }
        else if (_shadowReconnectAttemptIdBySlot.ContainsKey(slot.Number))
        {
            ShadowMirrorReconnectSucceeded(slot, hwnd, source + "/capture-as-reconnect-success");
            ShadowLogLegacyComparison(slot, source + "/ReconnectSucceeded", "legacy-capture-active");
        }
        else
        {
            var accepted = ShadowMirrorEvent(new ExternalPipCaptured(slot.Number, hwnd, attemptId), source, "legacy-external-capture-active");
            if (accepted)
                _shadowExternalCaptureSlots.Add(slot.Number);
        }

        if (hasPendingAttempt)
            ClearShadowOpenAttemptForSlot(slot.Number, source);
    }

    private void ShadowMirrorPipLost(PipSlot slot, IntPtr oldHwnd, string source)
    {
        _automationCoordinator.ObserveLegacyLoss(slot.Number, oldHwnd, source);
        if (oldHwnd == IntPtr.Zero)
            return;

        if (_shadowExternalCaptureSlots.Contains(slot.Number) && !SlotHasPairRecoverySignal(slot.Number))
        {
            AppLogger.Info($"shadow-external-loss-without-link: source={source}; slot={slot.Number}; hwnd=0x{oldHwnd.ToInt64():X}; action=reset");
            ShadowMirrorSlotReset(slot, source + "/external-loss-without-link");
            ShadowLogLegacyComparison(slot, source + "/ExternalLossWithoutLink", "legacy-external-unlinked-slot-removed");
            return;
        }

        // 9.33.11: não forçar Active antes da perda.
        // Para perda, IsHidden é normalizado para false porque WaitingForReconnect/Failed não permite Hidden.
        try
        {
            var snapshot = SlotSnapshotMapper.FromLegacy(
                slot.Number,
                slot.State.ToString(),
                slot.IsAutoReturnEnabled,
                isLocked: _groupLocked,
                pipHwnd: oldHwnd) with
            {
                IsHidden = false,
                UpdatedAt = DateTimeOffset.UtcNow
            };

            _shadowModeRuntime.ImportSnapshot(snapshot);
            AppLogger.Info($"shadow-mode-snapshot-imported: source={source}/before-loss; slot={slot.Number}; state={snapshot.State}; hidden={snapshot.IsHidden}; hwnd=0x{oldHwnd.ToInt64():X}");
        }
        catch (Exception ex)
        {
            AppLogger.Warn($"shadow-mode-loss-snapshot-import-ignored: source={source}; slot={slot.Number}; legacyState={slot.State}; hwnd=0x{oldHwnd.ToInt64():X}; reason={ex.Message}");
        }

        ClearShadowOpenAttemptForSlot(slot.Number, source);
        var attemptId = GetOrCreateShadowReconnectAttemptId(slot, source + "/PipWindowLost");
        var accepted = ShadowMirrorEvent(
            new PipWindowLost(slot.Number, oldHwnd, attemptId),
            source,
            slot.IsAutoReturnEnabled ? "legacy-loss-autoreturn-enabled" : "legacy-loss-autoreturn-disabled");

        // Com AutoRetorno desligado, PipWindowLost aceito termina em Failed.
        // A tentativa não pode ficar pendente para uma abertura manual futura.
        if (accepted && !slot.IsAutoReturnEnabled)
            ClearShadowReconnectAttemptForSlot(slot.Number, source + "/PipWindowLost-autoreturn-disabled");

        ShadowLogLegacyComparison(slot, source + "/PipWindowLost", slot.IsAutoReturnEnabled ? "legacy-loss-autoreturn-enabled" : "legacy-loss-autoreturn-disabled");
    }



    private void AutomaticCaptureToggle_Changed(object sender, RoutedEventArgs e)
    {
        if (!_initializationComplete || _suppressAutomaticCaptureToggleEvents || AutomaticCaptureToggle is null)
            return;
        _automaticReactorCaptureEnabled = AutomaticCaptureToggle.IsChecked == true;
        SaveSettings();
        UpdateConnectionAndAutomationUx();
        SetStatus(_automaticReactorCaptureEnabled
            ? "Captura automática ligada: o Reactor pode adotar PiPs validados em slots preparados"
            : "Captura automática desligada: use Capturar ou Capturar todos manualmente");
        AppLogger.Info($"automatic-reactor-capture-setting-changed: enabled={_automaticReactorCaptureEnabled}; reactorMode={GetReactorCaptureMode()}");
    }

    private void UpdateConnectionAndAutomationUx()
    {
        if (ExtensionStatusText is null || ExtensionStatusDot is null || ReactorModeText is null || AutomaticCaptureToggle is null)
            return;

        var connected = _extensionBridge.IsConnected;
        ExtensionStatusText.Text = connected ? $"Extensão conectada {ReleaseInfoConstants.ExtensionVersion}" : "Extensão desconectada";
        ExtensionStatusDot.Fill = connected
            ? new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(34, 197, 94))
            : new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(239, 68, 68));

        var mode = GetReactorCaptureMode();
        ReactorModeText.Text = $"Reactor: {char.ToUpperInvariant(mode[0])}{mode[1..]}";
        _suppressAutomaticCaptureToggleEvents = true;
        try
        {
            AutomaticCaptureToggle.IsChecked = _automaticReactorCaptureEnabled;
            AutomaticCaptureToggle.Content = _automaticReactorCaptureEnabled ? "Captura auto: ON" : "Captura auto: OFF";
        }
        finally
        {
            _suppressAutomaticCaptureToggleEvents = false;
        }
    }

    private void UpdateOpenPipButtonsState()
    {
        var enabled = !_openPipAttemptInProgress && !_openAllPipsInProgress;
        if (PreparePipButton is not null) PreparePipButton.IsEnabled = enabled;
        if (OpenPipManualButton is not null) OpenPipManualButton.IsEnabled = enabled;
        if (OpenPipFocuslessButton is not null) OpenPipFocuslessButton.IsEnabled = enabled;
        if (OpenAllPipsButton is not null) OpenAllPipsButton.IsEnabled = enabled;
    }

    private void SetStatus(string message) => StatusText.Text = message;

    private void RestoreWindowPlacement()
    {
        if (_settings.InterfaceVersion < 4)
        {
            _settings.InterfaceVersion = 4;
            _settings.MainWidth = 500;
            _settings.MainHeight = 360;
        }
        Width = Math.Max(MinWidth, _settings.MainWidth);
        Height = Math.Max(MinHeight, _settings.MainHeight);
        if (!double.IsNaN(_settings.MainLeft) && !double.IsNaN(_settings.MainTop))
        {
            Left = _settings.MainLeft;
            Top = _settings.MainTop;
        }
        else
        {
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
        }
    }

    private void InitializeMonitorSelector()
    {
        if (LayoutMonitorCombo is null) return;
        _availableMonitors = _monitorService.GetMonitors();
        _suppressMonitorSelectionEvents = true;
        try
        {
            LayoutMonitorCombo.ItemsSource = _availableMonitors;
            LayoutMonitorCombo.SelectedItem = _availableMonitors.FirstOrDefault(m =>
                string.Equals(m.DeviceName, _settings.LayoutMonitorDeviceName, StringComparison.OrdinalIgnoreCase))
                ?? _availableMonitors.FirstOrDefault(m => m.IsPrimary)
                ?? _availableMonitors.FirstOrDefault();
        }
        finally
        {
            _suppressMonitorSelectionEvents = false;
        }
    }

    private DisplayMonitorInfo? GetSelectedLayoutMonitor()
        => LayoutMonitorCombo?.SelectedItem as DisplayMonitorInfo
           ?? _availableMonitors.FirstOrDefault(m => m.IsPrimary)
           ?? _availableMonitors.FirstOrDefault();

    private NativeRect GetMonitorLayoutAnchor(DisplayMonitorInfo? monitor, int slotCount)
    {
        var area = monitor?.WorkArea ?? PipWindowService.GetVirtualScreenBounds();
        var width = Math.Min(520, Math.Max(280, area.Width / 3));
        var height = Math.Min(420, Math.Max(180, area.Height / 3));
        return new NativeRect(area.Right - width - 16, area.Top + 16, area.Right - 16, area.Top + height + 16);
    }

    private void LayoutMonitorCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (!_initializationComplete || _suppressMonitorSelectionEvents) return;
        var monitor = GetSelectedLayoutMonitor();
        if (monitor is null) return;
        _settings.LayoutMonitorDeviceName = monitor.DeviceName;
        SaveSettings();
        if (_fixedCustomLayoutEnabled)
        {
            MoveRelativeFixedAuthorityToSelectedMonitor("monitor-changed");
            ApplyFixedLayoutToAllActive("monitor-changed");
        }
        else if (Slots.Any(slot => slot.Window is not null))
        {
            RebuildGroupFromLayout(preferPanelTemplateAnchor: true, resizeToTargets: false, saveLockedModel: _groupLocked);
        }
        SetStatus($"Monitor do layout: {monitor.Label}");
        AppLogger.Info($"Monitor do layout alterado: device={monitor.DeviceName}; label={monitor.Label}; workArea={monitor.WorkArea}");
    }

    private void MoveSelectedSlotToMonitorButton_Click(object sender, RoutedEventArgs e)
    {
        var monitor = GetSelectedLayoutMonitor();
        if (monitor is null || SelectedSlot?.Window is null)
        {
            SetStatus("Selecione um slot capturado e um monitor");
            return;
        }

        var current = PipWindowService.GetVisualRect(SelectedSlot.Window.Handle);
        if (!current.IsValid) return;
        var area = monitor.WorkArea;
        var left = area.Left + Math.Max(8, (area.Width - current.Width) / 2);
        var top = area.Top + Math.Max(8, (area.Height - current.Height) / 2);
        var target = new NativeRect(left, top, left + current.Width, top + current.Height);
        PipWindowService.MoveVisual(SelectedSlot.Window.Handle, target.Left, target.Top);
        var actual = PipWindowService.GetVisualRect(SelectedSlot.Window.Handle);
        if (actual.IsValid)
            SelectedSlot.RefreshWindow(SelectedSlot.Window with { VisualRect = actual });
        if (_fixedCustomLayoutEnabled)
            SetFixedSlotAuthorityRect(SelectedSlot.Number, actual.IsValid ? actual : target, "move-selected-slot-to-monitor");
        CaptureCurrentRectsIntoSlotLayout();
        SaveSettings();
        PositionToolbar();
        SetStatus($"Slot {SelectedSlot.Number} movido para {monitor.Label}");
        AppLogger.Info($"Slot movido para monitor: slot={SelectedSlot.Number}; device={monitor.DeviceName}; target={target}");
    }

    private void SaveSettings()
    {
        if (!_initializationComplete)
            return;

        _settings.SlotCount = Slots.Count;
        _settings.LayoutMode = CurrentLayout;
        NormalizeSlotAutoReturnSettings(migrateFromGlobal: false);
        _settings.AutoReturnPolicy = _autoReturnPolicy.ToString();
        _settings.AutomaticReactorCaptureEnabled = _automaticReactorCaptureEnabled;
        _settings.LayoutMonitorDeviceName = GetSelectedLayoutMonitor()?.DeviceName ?? string.Empty;
        _settings.NativeLayoutEngineMode = _nativeLayoutEngineMode.ToString();
        _settings.JogoManualPlacementEnabled = _jogoManualPlacementEnabled;
        _settings.JogoVisualSlotOrder = _jogoVisualSlotOrder
            .Where(number => number >= 1 && number <= Slots.Count)
            .Distinct()
            .ToList();
        _settings.JogoTopSlots = _jogoVisualSlotOrder
            .Where(number => _jogoTopSlotNumbers.Contains(number))
            .Take(JogoTopRowCapacity)
            .ToList();
        _settings.JogoFreeAreaEnabled = _jogoFreeAreaEnabled;
        _settings.JogoLayoutScale = NormalizeJogoLayoutScale(_jogoLayoutScale);
        _settings.JogoTopWidthRatio = NormalizeJogoGroupWidthRatio(_jogoTopWidthRatio);
        _settings.JogoSideWidthRatio = NormalizeJogoGroupWidthRatio(_jogoSideWidthRatio);
        _settings.JogoSpaceHideHotkeyEnabled = _jogoSpaceHideHotkeyEnabled;
        _settings.FixedCustomLayoutEnabled = _fixedCustomLayoutEnabled;
        _settings.RespectFixedLayoutAreaEnabled = _fixedCustomLayoutEnabled;
        _settings.FixedSlotLayout = HasCompleteFixedLayoutAuthority()
            ? _fixedSlotLayoutRects
                .Take(Slots.Count)
                .Select(SlotLayoutItem.FromRect)
                .ToList()
            : [];
        _settings.RelativeFixedLayout = HasCompleteFixedLayoutAuthority()
            ? _relativeFixedLayout
            : null;
        _settings.AutoReturnDiscreteBySlot = _slotAutoReturnDiscreteBySlot
            .Where(item => item.Key >= 1 && item.Key <= 10)
            .OrderBy(item => item.Key)
            .ToDictionary(item => item.Key, item => item.Value);
        _settings.NextVideoPreloadBySlot = _slotNextVideoPreloadBySlot
            .Where(item => item.Key >= 1 && item.Key <= 10)
            .OrderBy(item => item.Key)
            .ToDictionary(item => item.Key, item => item.Value);
        _settings.MainLeft = Left;
        _settings.MainTop = Top;
        _settings.MainWidth = ActualWidth;
        _settings.MainHeight = ActualHeight;
        _settings.SlotLayout = _slotLayoutRects.Select(SlotLayoutItem.FromRect).ToList();
        _settings.CustomSlotLayout = EditableSlots
            .Select(slot => new NativeRect((int)Math.Round(slot.Left), (int)Math.Round(slot.Top),
                (int)Math.Round(slot.Left + slot.Width), (int)Math.Round(slot.Top + slot.Height)))
            .Select(SlotLayoutItem.FromRect)
            .ToList();

        if (_toolbar?.TryGetManualCollapsedPosition(out var toolbarLeft, out var toolbarTop) == true)
        {
            _settings.ToolbarCollapsedLeft = toolbarLeft;
            _settings.ToolbarCollapsedTop = toolbarTop;
        }

        _settingsService.Save(_settings);
    }

    private void MainWindow_Closing(object? sender, System.ComponentModel.CancelEventArgs e)
    {
        try
        {
            // 9.32.11 Final Stable Clean Patch 1:
            // se alguma versão anterior moveu o navegador para fora da tela,
            // restaura obrigatoriamente antes de encerrar o aplicativo.
            RestoreHiddenBrowserWorkspace("app-closing-final-stable-cleanpatch1");
        }
        catch (Exception ex)
        {
            AppLogger.Warn($"hidden-browser-workspace-restore-on-close-failed: {ex.Message}");
        }

        StopFixedLayoutFeatureForClosing();
        DisposeJogoSpaceHideHotkey();
        SaveSettings();
        _windowEventMonitor.RelevantEventReceived -= OnWindowMonitorRelevantEventReceived;
        _windowEventReactor.AssistedPipCandidateReady -= OnWindowEventReactorAssistedPipCandidateReady;
        _healthTimer.Stop();
        _liveCaptureTimer.Stop();
        ClearPipDragTargets();
        _applicationHealth.SetPipDragHookActive(false);
        _pipMouseDragService.Dispose();
        // ExtensionBridgeService disposed by Generic Host.
        _toolbar?.Close();
        foreach (var preview in _nextVideoPreviewWindowsBySlot.Values) preview.Close();
        _nextVideoPreviewWindowsBySlot.Clear();
    }



    private bool ParsePipManagerBoolValue(string? value)
    {
        if (string.IsNullOrWhiteSpace(value))
            return false;

        return value.Equals("true", StringComparison.OrdinalIgnoreCase)
            || value.Equals("1", StringComparison.OrdinalIgnoreCase)
            || value.Equals("yes", StringComparison.OrdinalIgnoreCase)
            || value.Equals("sim", StringComparison.OrdinalIgnoreCase);
    }

    private int ParsePipManagerIntValue(string? value, int fallback = 0)
    {
        if (int.TryParse(value, out var parsed))
            return parsed;
        return fallback;
    }

    private double ParsePipManagerDoubleValue(string? value, double fallback = 0)
    {
        if (double.TryParse(value, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out var parsed))
            return parsed;

        if (double.TryParse(value, out parsed))
            return parsed;

        return fallback;
    }

    private void LogMultiFrameAppPlayerStateSummary(string statusText, string source)
    {
        try
        {
            var eventName = ExtractKeyValue(statusText, "event");
            if (!string.Equals(eventName, "pip-preserve-silent-player-state", StringComparison.OrdinalIgnoreCase))
                return;

            var attemptId = ExtractKeyValue(statusText, "attemptId");
            var tabId = ParsePipManagerIntValue(ExtractKeyValue(statusText, "tabId"));
            var frameId = ParsePipManagerIntValue(ExtractKeyValue(statusText, "frameId"));
            var domain = ExtractKeyValue(statusText, "domain");
            var title = ExtractKeyValue(statusText, "title");
            var videoIndex = ParsePipManagerIntValue(ExtractKeyValue(statusText, "videoIndex"));
            var result = ExtractKeyValue(statusText, "result");
            var reasonCode = ExtractKeyValue(statusText, "reasonCode");
            var match = ExtractKeyValue(statusText, "match");
            var targetStrategy = ExtractKeyValue(statusText, "targetStrategy");
            var contentVersion = ExtractKeyValue(statusText, "contentVersion");
            var readyState = ParsePipManagerIntValue(ExtractKeyValue(statusText, "readyState"));
            var paused = ParsePipManagerBoolValue(ExtractKeyValue(statusText, "paused"));
            var ended = ParsePipManagerBoolValue(ExtractKeyValue(statusText, "ended"));
            var muted = ParsePipManagerBoolValue(ExtractKeyValue(statusText, "muted"));
            var pipEnabled = ParsePipManagerBoolValue(ExtractKeyValue(statusText, "pipEnabled"));
            var alreadyInPip = ParsePipManagerBoolValue(ExtractKeyValue(statusText, "alreadyInPip"));
            var canRequest = ParsePipManagerBoolValue(ExtractKeyValue(statusText, "canRequest"));
            var disablePip = ParsePipManagerBoolValue(ExtractKeyValue(statusText, "disablePip"));
            var found = ParsePipManagerBoolValue(ExtractKeyValue(statusText, "found"));
            var size = ExtractKeyValue(statusText, "size");
            var currentTime = ParsePipManagerDoubleValue(ExtractKeyValue(statusText, "currentTime"));
            var duration = ParsePipManagerDoubleValue(ExtractKeyValue(statusText, "duration"));

            var framesAnswered = 1;
            var framesWithVideo = found ? 1 : 0;
            var videoCount = found ? 1 : 0;
            var requestableFrames = canRequest ? 1 : 0;
            var requestableVideos = canRequest ? 1 : 0;

            var bestScore = 0;
            if (found) bestScore += 100;
            if (canRequest) bestScore += 60;
            if (pipEnabled) bestScore += 25;
            if (readyState >= 1) bestScore += 10;
            if (ended) bestScore -= 80;

            var wrongFrameSuspected = false;

            AppLogger.Info(
                $"pip-preserve-silent-multiframe-app-playerstate-frame-result: " +
                $"attemptId={attemptId}; source={source}; tabId={tabId}; frameId={frameId}; domain={domain}; title={title}; " +
                $"result=derived-from-player-state; originalResult={result}; reasonCode={reasonCode}; " +
                $"match={match}; targetStrategy={targetStrategy}; videoIndex={videoIndex}; " +
                $"score={bestScore}; found={found}; readyState={readyState}; paused={paused}; ended={ended}; muted={muted}; " +
                $"pipEnabled={pipEnabled}; alreadyInPip={alreadyInPip}; canRequest={canRequest}; disablePip={disablePip}; " +
                $"size={size}; currentTime={currentTime}; duration={duration}; contentVersion={contentVersion}");

            AppLogger.Info(
                $"pip-preserve-silent-multiframe-app-playerstate-summary: " +
                $"attemptId={attemptId}; source={source}; tabId={tabId}; frameId={frameId}; domain={domain}; " +
                $"framesAnswered={framesAnswered}; framesWithVideo={framesWithVideo}; requestableFrames={requestableFrames}; " +
                $"requestableVideos={requestableVideos}; wrongFrameSuspected={wrongFrameSuspected}; videoCount={videoCount}; " +
                $"bestIndex={videoIndex}; bestScore={bestScore}; bestCanRequest={canRequest}; bestPipEnabled={pipEnabled}; " +
                $"bestReadyState={readyState}; targetIndex={videoIndex}; targetScore={bestScore}; " +
                $"reasonCode={reasonCode}; contentVersion={contentVersion}");
        }
        catch (Exception ex)
        {
            AppLogger.Warn($"pip-preserve-silent-multiframe-app-playerstate-summary-failed: source={source}; error={ex.Message}");
        }
    }


    protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
    {
        ShadowSaveParityReport("MainWindow.OnClosing");
        base.OnClosing(e);
    }


}
