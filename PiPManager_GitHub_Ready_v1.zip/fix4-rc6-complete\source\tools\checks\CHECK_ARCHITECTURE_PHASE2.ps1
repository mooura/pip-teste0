$ErrorActionPreference = "Stop"

$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$hostText = Get-Content (Join-Path $root "src\PiPManager.Wpf\Services\AppHostService.cs") -Raw
$main = Get-Content (Join-Path $root "src\PiPManager.Wpf\MainWindow.xaml.cs") -Raw
$app = Get-Content (Join-Path $root "src\PiPManager.Wpf\App.xaml.cs") -Raw
$appXaml = Get-Content (Join-Path $root "src\PiPManager.Wpf\App.xaml") -Raw
$health = Get-Content (Join-Path $root "src\PiPManager.Wpf\Services\ApplicationHealthService.cs") -Raw
$bridgeHosted = Get-Content (Join-Path $root "src\PiPManager.Wpf\Services\ExtensionBridgeHostedService.cs") -Raw
$bridge = Get-Content (Join-Path $root "src\PiPManager.Wpf\Services\ExtensionBridgeService.cs") -Raw

$registrations = @(
  "AddSingleton<SettingsService>",
  "AddSingleton<WindowDiscoveryService>",
  "AddSingleton<PipWindowService>",
  "AddSingleton<LayoutService>",
  "AddSingleton<ExtensionBridgeService>",
  "AddSingleton<VideoCommandService>",
  "AddSingleton<ApplicationHealthService>",
  "AddHostedService<ExtensionBridgeHostedService>"
)

foreach ($registration in $registrations) {
  if (!$hostText.Contains($registration)) {
    throw "Missing DI registration: $registration"
  }
}

$forbiddenMain = @(
  "private readonly WindowDiscoveryService _discovery = new();",
  "private readonly LayoutService _layoutService = new();",
  "private readonly SettingsService _settingsService = new();",
  "private readonly ExtensionBridgeService _extensionBridge = new();",
  "_extensionBridge.Start();",
  "_extensionBridge.Dispose();"
)

foreach ($forbidden in $forbiddenMain) {
  if ($main.Contains($forbidden)) {
    throw "MainWindow still owns forbidden creation/lifecycle: $forbidden"
  }
}

foreach ($required in @(
  "public MainWindow(",
  "SettingsService settingsService",
  "WindowDiscoveryService discovery",
  "LayoutService layoutService",
  "ExtensionBridgeService extensionBridge",
  "IApplicationHealthService applicationHealth",
  "_applicationHealth.SetPipDragHookActive",
  "_applicationHealth.SetSlotCount"
)) {
  if (!$main.Contains($required)) {
    throw "MainWindow missing DI/health marker: $required"
  }
}

foreach ($required in @(
  "BridgeActive",
  "ConnectedExtensionVersion",
  "PipDragHookActive",
  "SlotCount",
  "CoreExecutionMode",
  "LastOperationalError"
)) {
  if (!$health.Contains($required)) {
    throw "ApplicationHealthService missing property: $required"
  }
}

if (!$bridgeHosted.Contains("_bridge.Start()") -or !$bridgeHosted.Contains("_bridge.Dispose()")) {
  throw "ExtensionBridgeHostedService does not own bridge lifecycle"
}

if ($appXaml.Contains("StartupUri=")) {
  throw "App.xaml still uses StartupUri; MainWindow should be created through DI"
}

if (!$app.Contains("ActivatorUtilities.CreateInstance<MainWindow>")) {
  throw "App.xaml.cs does not create MainWindow through DI"
}

if (!$bridge.Contains("ReleaseInfoConstants.CompatibleExtensionVersionPrefix")) {
  throw "Bridge is not using central compatible extension prefix"
}

Write-Host "Architecture Phase 2 checks OK."
