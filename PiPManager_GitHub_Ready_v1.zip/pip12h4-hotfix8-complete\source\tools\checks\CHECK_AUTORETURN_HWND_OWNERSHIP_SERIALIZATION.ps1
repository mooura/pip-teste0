$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$main = Get-Content (Join-Path $Root 'src\PiPManager.Wpf\MainWindow.xaml.cs') -Raw
$runner = Get-Content (Join-Path $Root 'RUN_CORE_TESTS.bat') -Raw
$checks = [ordered]@{
  'single-flight AutoReturn gate' = $main.Contains('_autoReturnExecutionGate = new(1, 1)') -and $main.Contains('auto-return-serialization-acquired')
  'candidate HWND claimed by attempt' = $main.Contains('auto-return-hwnd-claimed') -and $main.Contains('_autoReturnCandidateAttemptByHwnd')
  'same HWND confirmed separately' = $main.Contains('target-slot-already-confirmed-same-hwnd')
  'different target HWND remains mismatch' = $main.Contains('auto-return-target-slot-hwnd-mismatch') -and $main.Contains('action=reassociate-expected-new-hwnd')
  'smart reconnect restricted to active attempt slot' = $main.Contains('smart-reconnect-restricted-to-active-auto-return-slot') -and $main.Contains('slot.Number == _activeAutoReturnSlotNumber')
  'reactor rejects HWND owned by another slot' = $main.Contains('action=reject-owned-by-other-slot-reactor') -and -not $main.Contains('action=release-wrong-owner-reactor')
  'fallback rejects HWND owned by another slot' = $main.Contains('action=reject-owned-by-other-slot-fallback') -and -not $main.Contains('action=release-wrong-owner')
  'directed sweep excludes HWND owned by another slot' = $main.Contains('.Where(item => item.Owner is null || item.Owner.Number == slot.Number)')
  'directed recovery prioritizes claimed free HWND' = $main.Contains('.OrderByDescending(item => item.Claimed)')
  'checker included in core gate' = $runner.Contains('CHECK_AUTORETURN_HWND_OWNERSHIP_SERIALIZATION.ps1')
}
$failed=0
foreach($item in $checks.GetEnumerator()) { if($item.Value){Write-Host "$($item.Key): OK"}else{Write-Host "$($item.Key): FAIL";$failed++}}
if($failed -gt 0){throw 'AutoReturn strict HWND ownership checks failed.'}
Write-Host 'AutoReturn strict HWND ownership checks OK.'
