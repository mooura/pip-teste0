﻿namespace PiPManager.Wpf.Services;

public static class ReleaseInfoConstants
{
    public const string ProductVersion = "9.39.03";
    public const string AppVersion = "1.5.12.3909";
    public const string CoreVersion = "net8.0";
    public const string ExtensionVersion = "1.4.39.7";
    public const string CompatibleExtensionVersionPrefix = "1.4.39.7-";
    public const string CoreExecutionMode = "ReactorCompareDefault-ManagedLayoutDefault";
    public const string BuildLine = "Consolidation Block C: Unified Authority + Measured Native Retirement; Phase 12: AutoAdvance Safety + Fresh Target Recovery; Relative Group Layout + Batched Recovery; Flush Reservation + Ten-Source Stabilization + Aspect-Aware Slots; Fix 4 RC3: Correlated Next/Previous Command Telemetry; P0 Optimization RC5: Intentional Visibility Event Suppression + Already-Owned HWND Fast Dedup; P0 Optimization RC6: Fixed Layout PiP-Only + Absolute 45s Recovery + Slot Swap Remap + No Global Recovery Reflow";
}

public interface IReleaseInfoService
{
    string ProductVersion { get; }
    string AppVersion { get; }
    string CoreVersion { get; }
    string ExtensionVersion { get; }
    string CoreExecutionMode { get; }
    string BuildLine { get; }
    string StartupBanner { get; }
}

public sealed class ReleaseInfoService : IReleaseInfoService
{
    public string ProductVersion => ReleaseInfoConstants.ProductVersion;
    public string AppVersion => ReleaseInfoConstants.AppVersion;
    public string CoreVersion => ReleaseInfoConstants.CoreVersion;
    public string ExtensionVersion => ReleaseInfoConstants.ExtensionVersion;
    public string CoreExecutionMode => ReleaseInfoConstants.CoreExecutionMode;
    public string BuildLine => ReleaseInfoConstants.BuildLine;

    public string StartupBanner =>
        $"pipmanager-startup: product={ProductVersion}; app={AppVersion}; extension={ExtensionVersion}; core={CoreVersion}; mode={CoreExecutionMode}; line={BuildLine}";
}
