# Hotfix 4 — Next Priority, Fast Return and Network Cap

Version: `1.4.39.19-next-priority-fast-return-network-cap-hotfix4`

- `Próximo` cancels and preempts `Abrir todos`.
- `Abrir todos` refuses to acquire physical authority while a next-navigation generation is active.
- AutoReturn can proceed after a 220 ms grace when the new command target has a source or metadata, without waiting for full media readiness.
- Hidden-video preload has an 1800 ms hard network window and aborts the resource fetch with `removeAttribute("src") + load()`.
- Preview and immutable CommandTarget logic from Hotfix 3 are unchanged.
