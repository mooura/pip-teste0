﻿$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$layout = Get-Content (Join-Path $root 'src\PiPManager.Wpf\MainWindow.Layout.cs') -Raw
$drag = Get-Content (Join-Path $root 'src\PiPManager.Wpf\MainWindow.PipDrag.cs') -Raw
$mouseDrag = Get-Content (Join-Path $root 'src\PiPManager.Wpf\Services\PipGroupMouseDragService.cs') -Raw
$main = Get-Content (Join-Path $root 'src\PiPManager.Wpf\MainWindow.xaml.cs') -Raw
$fixed = Get-Content (Join-Path $root 'src\PiPManager.Wpf\MainWindow.FixedLayout.cs') -Raw
$xaml = Get-Content (Join-Path $root 'src\PiPManager.Wpf\MainWindow.xaml') -Raw

$checks = [ordered]@{
  'native PiP border remains the resize authority' = $mouseDrag.Contains('WindowFromPoint') -and $mouseDrag.Contains('GetAncestor') -and $mouseDrag.Contains('nativeHitTest=True')
  'artificial external border margin was removed' = -not $mouseDrag.Contains('JogoResizeBorderHitMarginPx') -and -not $mouseDrag.Contains('source = "border-margin"')
  'live drag does not resize the group' = $drag.Contains('IsJogoManualResizeInProgress') -and -not $drag.Contains('TryPreviewJogoManualGroupResize') -and -not $drag.Contains('manual-border-resize/live')
  'manual resize records the last reference' = $drag.Contains('_lastManuallyResizedSlotNumber = slot.Number') -and $drag.Contains('jogo-manual-resize-reference-only')
  'manual resize changes no other PiP' = $drag.Contains('otherWindowsChanged=False') -and $drag.Contains('equalizeOnDemand=True')
  'fixed Jogo stores a reference instead of propagating immediately' = $fixed.Contains('authority=native-border-reference') -and $fixed.Contains('otherSlotsChanged=False')
  'Jogo resolves top and side from visual topology' = $layout.Contains('ResolveJogoVisualGroups') -and $layout.Contains('_jogoTopSlotNumbers') -and $layout.Contains('JogoTopRowCapacity')
  'equalize targets only the reference group' = $main.Contains('BuildJogoReferenceGroupEqualizeTargets') -and $main.Contains('jogo-group-equalize-from-last-resize') -and $main.Contains('groupOnly=True')
  'opposite group keeps its dimensions' = $main.Contains('otherGroupResize=False') -and $layout.Contains('var sizes = occupied.ToDictionary') -and $layout.Contains('foreach (var slot in referenceGroup)')
  'reference group is clamped without shrinking the other group' = $layout.Contains('availableTopHeight') -and $layout.Contains('availableSideHeight') -and $layout.Contains('fitScale')
  'menu explains normal border then group equalize' = $xaml.Contains('Ajuste um PiP pela borda; Igualar aplica somente ao mesmo grupo')
}

$failed = @()
foreach ($item in $checks.GetEnumerator()) {
  if ($item.Value) { Write-Host ($item.Key + ': OK') }
  else { Write-Host ($item.Key + ': FAIL'); $failed += $item.Key }
}
if ($failed.Count -gt 0) { throw "Jogo group reference equalize checks failed: $($failed -join ', ')" }
Write-Host 'JOGO GROUP REFERENCE EQUALIZE CHECK OK.'
