namespace PiPManager.Wpf.Models;

public sealed class RelativeGroupLayout
{
    public int Version { get; set; } = 1;
    public int AnchorX { get; set; }
    public int AnchorY { get; set; }
    public string MonitorDeviceName { get; set; } = string.Empty;
    public double DpiScale { get; set; } = 1.0;
    public List<RelativeSlotLayoutItem> Slots { get; set; } = [];
}

public sealed class RelativeSlotLayoutItem
{
    public int SlotNumber { get; set; }
    public int OffsetX { get; set; }
    public int OffsetY { get; set; }
    public int Width { get; set; }
    public int Height { get; set; }
}
