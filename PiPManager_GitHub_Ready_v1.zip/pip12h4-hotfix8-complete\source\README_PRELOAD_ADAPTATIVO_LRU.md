# Preload adaptativo + backoff + LRU (extensão 1.4.39.12)

Implementado em `src/PiPManager.Extension/content.js` e transportado até os logs WPF.

## Política

- Timeout: 2G = 30 s; 3G = 45 s; 4G/5G/desconhecida = 90 s.
- `saveData` ou navegador offline: preload não inicia.
- Retry: 1 tentativa inicial + 2 retries.
- Backoff: 900 ms e 1.350 ms para os dois retries; fórmula geral limitada a 5 s.
- Cache LRU: mantém até 3 elementos `<video>` aquecidos; a entrada mais antiga é descartada.
- Slot de rede: continua limitado a uma aba por vez; espera por slot também possui timeout.

## Diagnóstico

Todos os eventos `next-preload-*` incluem:

- `networkType`
- `timeoutMs`
- `backoffMs`
- `attempt`
- `delayMs`
- `bufferedSeconds`

Também podem incluir `cacheSize`, `cacheHit`, `switchLatencyMs` e `wasWarm`.

## Limitação técnica importante

O LRU mantém elementos ocultos e favorece o cache HTTP/range cache do navegador. Ele não transfere diretamente o buffer interno de um `<video>` para o player do site. Por isso, ganhos de 60% a 80% devem ser validados nos logs reais, não tratados como garantia.
