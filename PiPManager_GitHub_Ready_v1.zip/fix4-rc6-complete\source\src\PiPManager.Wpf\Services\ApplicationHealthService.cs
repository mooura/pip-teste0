﻿namespace PiPManager.Wpf.Services;

public interface IApplicationHealthService
{
    bool BridgeActive { get; }
    string ConnectedExtensionVersion { get; }
    bool PipDragHookActive { get; }
    int SlotCount { get; }
    string CoreExecutionMode { get; }
    string LastOperationalError { get; }
    bool WindowEventHookActive { get; }
    string LastWindowEvent { get; }
    long WindowEventsReceived { get; }
    long WindowEventsDiscarded { get; }
    string LastWindowEventHookFailure { get; }

    void SetBridgeActive(bool active);
    void SetPipDragHookActive(bool active);
    void SetSlotCount(int slotCount);
    void ReportOperationalError(string message);
    void SetWindowEventHookActive(bool active);
    void SetLastWindowEvent(string value);
    void SetWindowEventTotals(long received, long discarded);
    void SetWindowEventHookFailure(string value);
}

public sealed class ApplicationHealthService : IApplicationHealthService
{
    private readonly IReleaseInfoService _releaseInfo;
    private readonly ExtensionBridgeService _extensionBridge;
    private readonly object _gate = new();

    private bool _bridgeActive;
    private bool _pipDragHookActive;
    private int _slotCount;
    private string _lastOperationalError = string.Empty;
    private bool _windowEventHookActive;
    private string _lastWindowEvent = string.Empty;
    private long _windowEventsReceived;
    private long _windowEventsDiscarded;
    private string _lastWindowEventHookFailure = string.Empty;

    public ApplicationHealthService(IReleaseInfoService releaseInfo, ExtensionBridgeService extensionBridge)
    {
        _releaseInfo = releaseInfo;
        _extensionBridge = extensionBridge;
    }

    public bool BridgeActive
    {
        get { lock (_gate) return _bridgeActive && _extensionBridge.IsConnected; }
    }

    public string ConnectedExtensionVersion
    {
        get { lock (_gate) return _extensionBridge.ConnectedExtensionVersion; }
    }

    public bool PipDragHookActive
    {
        get { lock (_gate) return _pipDragHookActive; }
    }

    public int SlotCount
    {
        get { lock (_gate) return _slotCount; }
    }

    public string CoreExecutionMode => _releaseInfo.CoreExecutionMode;

    public string LastOperationalError
    {
        get { lock (_gate) return _lastOperationalError; }
    }

    public bool WindowEventHookActive
    {
        get { lock (_gate) return _windowEventHookActive; }
    }

    public string LastWindowEvent
    {
        get { lock (_gate) return _lastWindowEvent; }
    }

    public long WindowEventsReceived
    {
        get { lock (_gate) return _windowEventsReceived; }
    }

    public long WindowEventsDiscarded
    {
        get { lock (_gate) return _windowEventsDiscarded; }
    }

    public string LastWindowEventHookFailure
    {
        get { lock (_gate) return _lastWindowEventHookFailure; }
    }

    public void SetBridgeActive(bool active)
    {
        lock (_gate) _bridgeActive = active;
    }

    public void SetPipDragHookActive(bool active)
    {
        lock (_gate) _pipDragHookActive = active;
    }

    public void SetSlotCount(int slotCount)
    {
        lock (_gate) _slotCount = slotCount;
    }

    public void ReportOperationalError(string message)
    {
        lock (_gate) _lastOperationalError = message;
    }
    public void SetWindowEventHookActive(bool active)
    {
        lock (_gate) _windowEventHookActive = active;
    }

    public void SetLastWindowEvent(string value)
    {
        lock (_gate) _lastWindowEvent = value;
    }

    public void SetWindowEventTotals(long received, long discarded)
    {
        lock (_gate)
        {
            _windowEventsReceived = received;
            _windowEventsDiscarded = discarded;
        }
    }

    public void SetWindowEventHookFailure(string value)
    {
        lock (_gate) _lastWindowEventHookFailure = value;
        ReportOperationalError(value);
    }

}
