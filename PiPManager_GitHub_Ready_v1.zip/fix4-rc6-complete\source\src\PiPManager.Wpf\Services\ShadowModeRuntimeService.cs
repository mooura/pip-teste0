﻿using PiPManager.Core.Automation;
using PiPManager.Core.Shadow;
using PiPManager.Core.Slots;

namespace PiPManager.Wpf.Services;

/// <summary>
/// Serviço de runtime para Shadow Mode.
/// Criado para futura integração, mas não executa ações reais.
/// Nesta versão, ele só fornece API segura para espelhar eventos quando for chamado.
/// </summary>
public sealed class ShadowModeRuntimeService
{
    private readonly ShadowModeEventMirror _mirror = new(
        new AutomationEngine(),
        new ShadowModeOptions
        {
            Enabled = true,
            ExecuteActions = false,
            CaptureDecisions = true,
            MaxHistory = 500
        });

    public ShadowDecisionResult Mirror(AutomationEvent ev)
        => _mirror.Mirror(ev);

    public SlotSnapshot ImportSnapshot(SlotSnapshot snapshot)
        => _mirror.ImportSnapshot(snapshot);

    public IReadOnlyCollection<ShadowDecisionResult> GetHistory()
        => _mirror.History;

    public IReadOnlyCollection<SlotSnapshot> GetEngineSnapshot()
        => _mirror.GetEngineSnapshot();

    public void Clear()
        => _mirror.Clear();
}
