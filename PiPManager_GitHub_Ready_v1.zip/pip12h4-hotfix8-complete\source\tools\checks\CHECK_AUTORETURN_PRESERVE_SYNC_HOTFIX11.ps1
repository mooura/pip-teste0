$ErrorActionPreference = 'Stop'
$root = Resolve-Path (Join-Path $PSScriptRoot '..\..')
$main = Get-Content (Join-Path $root 'src\PiPManager.Wpf\MainWindow.xaml.cs') -Raw
$manifest = Get-Content (Join-Path $root 'src\PiPManager.Extension\manifest.json') -Raw | ConvertFrom-Json

$checks = [ordered]@{
  'extension runtime remains 1.4.39.25' = ([string]$manifest.version -eq '1.4.39.25')
  'AutoReturn completion method exists' = $main.Contains('CompleteVideoSwitchPreservationAfterAutoReturn')
  'completion requires AutoReturn ownership' = $main.Contains('state.AutoReturnTookOwnership') -and $main.Contains('reason=auto-return-not-owner')
  'completion validates slot HWND and tab' = $main.Contains('confirmed-hwnd-not-owned-by-slot') -and $main.Contains('reason=tab-mismatch')
  'completed preservation state is removed' = $main.Contains('_videoSwitchPreservationBySlot.Remove(slot.Number)')
  'confirmed completion telemetry is explicit' = $main.Contains('result=auto-return-confirmed') -and $main.Contains('preservedConfirmed=True')
  'false expiry is replaced by completion' = $main.Contains('completionReason=auto-return-confirmed') -and $main.Contains('expireReason=auto-return-confirmed') -and $main.Contains('timerCancelled=True')
  'focusless success synchronizes preservation' = $main.Contains('focusless-auto-return-confirmed')
  'silent success synchronizes preservation' = $main.Contains('preserve-silent-reopen-confirmed')
}

$failed = 0
foreach ($item in $checks.GetEnumerator()) {
  if ($item.Value) { Write-Host ($item.Key + ': OK') -ForegroundColor Green }
  else { Write-Host ($item.Key + ': FAIL') -ForegroundColor Red; $failed++ }
}
if ($failed -gt 0) { throw 'AutoReturn preserve synchronization Hotfix 11 checks failed.' }
Write-Host 'AutoReturn preserve synchronization Hotfix 11 checks OK.'
