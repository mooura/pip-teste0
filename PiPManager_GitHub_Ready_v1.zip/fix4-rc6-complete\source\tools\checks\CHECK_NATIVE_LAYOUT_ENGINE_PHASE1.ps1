$ErrorActionPreference = "Stop"
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$header = Get-Content (Join-Path $root "src\PiPManager.Native\PiPManager.Native.h") -Raw
$cpp = Get-Content (Join-Path $root "src\PiPManager.Native\PiPManager.Native.cpp") -Raw
$nativeProject = Get-Content (Join-Path $root "src\PiPManager.Native\PiPManager.Native.vcxproj") -Raw
$bridge = Get-Content (Join-Path $root "src\PiPManager.Wpf\Services\NativeLayoutEngine.cs") -Raw
$windows = Get-Content (Join-Path $root "src\PiPManager.Wpf\Services\PipWindowService.cs") -Raw
$settings = Get-Content (Join-Path $root "src\PiPManager.Wpf\Models\AppSettings.cs") -Raw
$xaml = Get-Content (Join-Path $root "src\PiPManager.Wpf\MainWindow.xaml") -Raw
$main = Get-Content (Join-Path $root "src\PiPManager.Wpf\MainWindow.xaml.cs") -Raw
$layout = Get-Content (Join-Path $root "src\PiPManager.Wpf\MainWindow.Layout.cs") -Raw
$project = Get-Content (Join-Path $root "src\PiPManager.Wpf\PiPManager.Wpf.csproj") -Raw
$build = Get-Content (Join-Path $root "BUILD_WINDOWS.bat") -Raw
$nativeBuild = Get-Content (Join-Path $root "BUILD_NATIVE_WINDOWS.bat") -Raw
$release = Get-Content (Join-Path $root "src\PiPManager.Wpf\Services\ReleaseInfoService.cs") -Raw
$gate = Get-Content (Join-Path $root "RUN_CORE_TESTS.bat") -Raw
$dll = Join-Path $root "src\PiPManager.Native\prebuilt\PiPManager.Native.dll"

$checks = [ordered]@{
  "C ABI version export exists" = $header.Contains('pip_native_version') -and $cpp.Contains('pip_native_version')
  "C ABI batch export exists" = $header.Contains('pip_process_window_batch') -and $cpp.Contains('pip_process_window_batch')
  "native batch is bounded" = $cpp.Contains('count > 64')
  "native visual rect uses DWM" = $cpp.Contains('DwmGetWindowAttribute') -and $cpp.Contains('DwmwaExtendedFrameBounds')
  "native atomic batch uses DeferWindowPos" = $cpp.Contains('BeginDeferWindowPos') -and $cpp.Contains('DeferWindowPos') -and $cpp.Contains('EndDeferWindowPos')
  "native internal fallback uses SetWindowPos" = $cpp.Contains('fallbackUsed') -and $cpp.Contains('SetWindowPos')
  "native release avoids external VC runtime" = $nativeProject.Contains('<RuntimeLibrary>MultiThreaded</RuntimeLibrary>')
  "managed bridge loads native dynamically" = $bridge.Contains('NativeLibrary.TryLoad') -and $bridge.Contains('Marshal.GetDelegateForFunctionPointer')
  "managed bridge imports System.IO for Path" = $bridge.Contains('using System.IO;') -and $bridge.Contains('Path.Combine')
  "managed bridge pins blittable batches" = $bridge.Contains('GCHandle.Alloc') -and $bridge.Contains('GCHandleType.Pinned')
  "native and managed ABI sizes are guarded" = $cpp.Contains('sizeof(PipNativeMove) == 24') -and $bridge.Contains('Pack = 8')
  "OFF Compare Primary modes exist" = $bridge.Contains('Off') -and $bridge.Contains('Compare') -and $bridge.Contains('Primary')
  "Compare remains managed authority" = $windows.Contains('dryRun: true') -and $windows.Contains('ApplyManagedMoveVisualBatch')
  "Primary has automatic managed fallback" = $windows.Contains('native-layout-primary-fallback') -and $windows.Contains('if (native.Available && native.Success)')
  "raw group drag is native-capable" = $windows.Contains('ProcessRawBatch') -and $windows.Contains('ApplyManagedRawPositionBatch')
  "Compare sampling avoids double-work per frame" = $windows.Contains('NativeCompareSampleIntervalMs = 250') -and $windows.Contains('ShouldSampleComparison(ref _lastRawCompareTickMs)') -and $windows.Contains('ShouldSampleComparison(ref _lastVisualCompareTickMs)')
  "visual move and resize are native-capable" = $windows.Contains('ProcessVisualBatch') -and $windows.Contains('resizeToTargets')
  "mode persists in settings" = $settings.Contains('NativeLayoutEngineMode') -and $main.Contains('_settings.NativeLayoutEngineMode')
  "visible mode selector exists" = $xaml.Contains('NativeLayoutPrimaryMenuItem') -and $layout.Contains('NativeLayoutModeMenuItem_Click')
  "strong diagnostic exposes native state" = $main.Contains('Motor nativo de layout: mode=') -and $main.Contains('NativeLayoutEngineVersion')
  "native DLL copied to publish" = $project.Contains('PiPManager.Native.dll') -and $project.Contains('CopyToPublishDirectory') -and $project.Contains('ExcludeFromSingleFile="true"')
  "native build runs before publish" = $build.Contains('call BUILD_NATIVE_WINDOWS.bat') -and $nativeBuild.Contains('Microsoft.VisualStudio.Component.VC.Tools.x86.x64')
  "validated prebuilt DLL included" = Test-Path $dll
  "release is 9.39.03" = $release.Contains('ProductVersion = "9.39.03"') -and $release.Contains('AppVersion = "1.5.12.3909"')
  "extension remains stable" = $release.Contains('ExtensionVersion = "1.4.39.7"')
  "checker included in core gate" = $gate.Contains('CHECK_NATIVE_LAYOUT_ENGINE_PHASE1.ps1')
}

$failed = @()
foreach ($item in $checks.GetEnumerator()) {
  if ($item.Value) { Write-Host ($item.Key + ": OK") }
  else { Write-Host ($item.Key + ": FAIL"); $failed += $item.Key }
}
if ($failed.Count -gt 0) { throw ("Native Layout Engine Phase 1 checks failed: " + ($failed -join ", ")) }
Write-Host "Native Layout Engine Phase 1 checks OK."
