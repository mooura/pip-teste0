﻿using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Threading;
using PiPManager.Wpf.Models;

namespace PiPManager.Wpf.Services;

internal readonly record struct DragTargetInfo(IntPtr Handle, NativeRect Rect);

internal sealed class PipGroupMouseDragService : IDisposable
{
    private const int WH_MOUSE_LL = 14;
    private const int WM_LBUTTONDOWN = 0x0201;
    private const int WM_LBUTTONUP = 0x0202;
    private const int WM_MOUSEMOVE = 0x0200;
    private const int WM_CANCELMODE = 0x001F;
    private const uint GA_ROOT = 2;

    private readonly Action<IntPtr, int, int> _started;
    private readonly Action<IntPtr, int, int> _delta;
    private readonly Action<IntPtr, int, int> _completed;
    private readonly object _sync = new();

    private LowLevelMouseProc? _proc;
    private IntPtr _hook = IntPtr.Zero;
    private DragTargetInfo[] _targets = [];
    private bool _dragging;
    private IntPtr _dragHandle = IntPtr.Zero;
    private int _startX;
    private int _startY;
    private int _lastDx;
    private int _lastDy;

    // O hook de baixo nível pode entregar centenas de WM_MOUSEMOVE por segundo.
    // Mantemos somente a posição mais recente e no máximo um callback pendente
    // no Dispatcher. Isso impede que a fila da UI continue processando posições
    // antigas depois que o cursor já avançou.
    private bool _moveDispatchPending;
    private IntPtr _latestMoveHandle = IntPtr.Zero;
    private int _latestMoveX;
    private int _latestMoveY;
    private long _latestMoveSequence;
    private long _processedMoveSequence;
    private long _dragGeneration;

    public PipGroupMouseDragService(
        Action<IntPtr, int, int> started,
        Action<IntPtr, int, int> delta,
        Action<IntPtr, int, int> completed)
    {
        _started = started;
        _delta = delta;
        _completed = completed;
    }

    public void Start()
    {
        if (_hook != IntPtr.Zero) return;
        _proc = HookCallback;
        using var process = Process.GetCurrentProcess();
        var module = process.MainModule;
        var moduleHandle = module is null ? IntPtr.Zero : GetModuleHandle(module.ModuleName);
        _hook = SetWindowsHookEx(WH_MOUSE_LL, _proc, moduleHandle, 0);
        if (_hook == IntPtr.Zero)
            AppLogger.Info("Hook de arraste por PiP não foi iniciado");
        else
            AppLogger.Info("Hook de arraste por PiP iniciado");
    }

    public void UpdateTargets(IEnumerable<DragTargetInfo> targets)
    {
        lock (_sync)
        {
            _targets = targets.Where(item => item.Handle != IntPtr.Zero && item.Rect.IsValid).ToArray();
        }
    }

    public void ClearTargets()
    {
        lock (_sync)
        {
            _targets = [];
            _dragging = false;
            _dragHandle = IntPtr.Zero;
            _dragGeneration++;
            ResetPendingMoveLocked();
        }
    }

    public void Dispose()
    {
        lock (_sync)
        {
            _dragging = false;
            _dragHandle = IntPtr.Zero;
            _dragGeneration++;
            ResetPendingMoveLocked();
        }

        if (_hook != IntPtr.Zero)
        {
            UnhookWindowsHookEx(_hook);
            _hook = IntPtr.Zero;
        }
        _proc = null;
    }

    private IntPtr HookCallback(int nCode, IntPtr wParam, IntPtr lParam)
    {
        if (nCode < 0)
            return CallNextHookEx(_hook, nCode, wParam, lParam);

        MSLLHOOKSTRUCT info;
        try
        {
            info = Marshal.PtrToStructure<MSLLHOOKSTRUCT>(lParam);
        }
        catch
        {
            return CallNextHookEx(_hook, nCode, wParam, lParam);
        }

        var message = wParam.ToInt32();
        var x = info.pt.x;
        var y = info.pt.y;

        if (message == WM_LBUTTONDOWN)
        {
            var handle = HitTest(x, y, out var hitSource);
            if (handle != IntPtr.Zero)
            {
                long generation;
                lock (_sync)
                {
                    _dragGeneration++;
                    generation = _dragGeneration;
                    _dragging = true;
                    _dragHandle = handle;
                    _startX = x;
                    _startY = y;
                    _lastDx = x;
                    _lastDy = y;
                    ResetPendingMoveLocked();
                    _latestMoveHandle = handle;
                    _latestMoveX = x;
                    _latestMoveY = y;
                }

                Dispatch(() =>
                {
                    if (!IsCurrentDragGeneration(generation))
                        return;

                    AppLogger.Info(
                        $"pip-drag-hit: hwnd=0x{handle.ToInt64():X}; source={hitSource}; " +
                        $"point={x},{y}; nativeHitTest=True");
                    _started(handle, x, y);
                });
                return CallNextHookEx(_hook, nCode, wParam, lParam);
            }
        }

        bool dragging;
        IntPtr dragHandle;
        long dragGeneration;
        lock (_sync)
        {
            dragging = _dragging;
            dragHandle = _dragHandle;
            dragGeneration = _dragGeneration;
        }

        if (!dragging || dragHandle == IntPtr.Zero)
            return CallNextHookEx(_hook, nCode, wParam, lParam);

        if (message == WM_MOUSEMOVE)
        {
            var shouldQueue = false;
            lock (_sync)
            {
                if (Math.Abs(x - _lastDx) >= 1 || Math.Abs(y - _lastDy) >= 1)
                {
                    _lastDx = x;
                    _lastDy = y;
                    _latestMoveHandle = dragHandle;
                    _latestMoveX = x;
                    _latestMoveY = y;
                    _latestMoveSequence++;

                    if (!_moveDispatchPending)
                    {
                        _moveDispatchPending = true;
                        shouldQueue = true;
                    }
                }
            }

            if (shouldQueue)
                Dispatch(() => DrainPendingMoveOnDispatcher(dragGeneration));

            return CallNextHookEx(_hook, nCode, wParam, lParam);
        }

        if (message == WM_LBUTTONUP || message == WM_CANCELMODE)
        {
            lock (_sync)
            {
                // O ponto do mouse-up pode ser mais recente que o último WM_MOUSEMOVE.
                // Ele também participa do flush final antes de concluir o gesto.
                if (x != _latestMoveX || y != _latestMoveY)
                {
                    _latestMoveHandle = dragHandle;
                    _latestMoveX = x;
                    _latestMoveY = y;
                    _latestMoveSequence++;
                }

                _dragging = false;
                _dragHandle = IntPtr.Zero;
            }

            Dispatch(() =>
            {
                FlushLatestMoveOnDispatcher(dragHandle, dragGeneration);
                _completed(dragHandle, x, y);
            });
            return CallNextHookEx(_hook, nCode, wParam, lParam);
        }

        return CallNextHookEx(_hook, nCode, wParam, lParam);
    }

    private void DrainPendingMoveOnDispatcher(long generation)
    {
        IntPtr handle;
        int x;
        int y;
        long sequence;

        lock (_sync)
        {
            // Um callback de um gesto anterior nunca pode consumir o estado do
            // arraste atual, mesmo em uma sequência muito rápida de soltar/clicar.
            if (generation != _dragGeneration)
                return;

            if (!_moveDispatchPending || _latestMoveSequence <= _processedMoveSequence)
            {
                _moveDispatchPending = false;
                return;
            }

            handle = _latestMoveHandle;
            x = _latestMoveX;
            y = _latestMoveY;
            sequence = _latestMoveSequence;
        }

        if (handle != IntPtr.Zero)
            _delta(handle, x, y);

        var queueAnotherFrame = false;
        lock (_sync)
        {
            if (generation != _dragGeneration)
                return;

            _processedMoveSequence = Math.Max(_processedMoveSequence, sequence);

            if (_dragging && _latestMoveSequence > _processedMoveSequence)
            {
                // Chegou uma posição mais nova enquanto este quadro era aplicado.
                // Agenda somente mais um quadro, ainda usando a posição mais recente.
                queueAnotherFrame = true;
            }
            else
            {
                _moveDispatchPending = false;
            }
        }

        if (queueAnotherFrame)
            Dispatch(() => DrainPendingMoveOnDispatcher(generation));
    }

    private void FlushLatestMoveOnDispatcher(IntPtr dragHandle, long generation)
    {
        IntPtr handle;
        int x;
        int y;
        long sequence;

        lock (_sync)
        {
            if (generation != _dragGeneration)
                return;

            if (_latestMoveSequence <= _processedMoveSequence)
            {
                _moveDispatchPending = false;
                return;
            }

            handle = _latestMoveHandle == IntPtr.Zero ? dragHandle : _latestMoveHandle;
            x = _latestMoveX;
            y = _latestMoveY;
            sequence = _latestMoveSequence;

            // Invalida qualquer drain que tenha sido agendado depois do callback
            // de conclusão. Ele observará que não existe movimento novo.
            _processedMoveSequence = sequence;
            _moveDispatchPending = false;
        }

        if (handle != IntPtr.Zero)
            _delta(handle, x, y);
    }

    private bool IsCurrentDragGeneration(long generation)
    {
        lock (_sync)
            return generation == _dragGeneration;
    }

    private void ResetPendingMoveLocked()
    {
        _moveDispatchPending = false;
        _latestMoveHandle = IntPtr.Zero;
        _latestMoveX = 0;
        _latestMoveY = 0;
        _latestMoveSequence++;
        _processedMoveSequence = _latestMoveSequence;
    }

    private IntPtr HitTest(int x, int y, out string source)
    {
        source = "none";

        DragTargetInfo[] targets;
        lock (_sync)
            targets = _targets.ToArray();

        if (targets.Length == 0)
            return IntPtr.Zero;

        // A moldura de redimensionamento do Firefox pode ficar alguns pixels fora
        // do retângulo visual retornado pelo DWM. WindowFromPoint identifica o HWND
        // real sob o cursor inclusive nessa moldura não cliente.
        var point = new POINT { x = x, y = y };
        var windowAtPoint = WindowFromPoint(point);
        if (windowAtPoint != IntPtr.Zero)
        {
            var root = GetAncestor(windowAtPoint, GA_ROOT);
            foreach (var target in targets)
            {
                if (target.Handle == windowAtPoint || target.Handle == root)
                {
                    source = "window-from-point";
                    return target.Handle;
                }
            }
        }

        // Mantém o comportamento anterior para cliques dentro da imagem do PiP.
        foreach (var target in targets)
        {
            if (target.Rect.Contains(x, y))
            {
                source = "visual-rect";
                return target.Handle;
            }
        }

        // Não inventa uma margem externa ao HWND. O redimensionamento permanece
        // o comportamento nativo da janela PiP; o hook apenas observa o HWND real
        // devolvido pelo Windows ou um clique dentro do retângulo visual.
        return IntPtr.Zero;
    }

    private static void Dispatch(Action action)
    {
        var dispatcher = Application.Current?.Dispatcher;
        if (dispatcher is null || dispatcher.HasShutdownStarted)
            return;

        // Render mantém o lote de movimento próximo ao próximo frame visual sem
        // competir com uma fila potencialmente enorme de eventos individuais.
        dispatcher.BeginInvoke(DispatcherPriority.Render, action);
    }

    private delegate IntPtr LowLevelMouseProc(int nCode, IntPtr wParam, IntPtr lParam);

    [StructLayout(LayoutKind.Sequential)]
    private struct POINT
    {
        public int x;
        public int y;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct MSLLHOOKSTRUCT
    {
        public POINT pt;
        public uint mouseData;
        public uint flags;
        public uint time;
        public IntPtr dwExtraInfo;
    }

    [DllImport("user32.dll", SetLastError = true)]
    private static extern IntPtr SetWindowsHookEx(int idHook, LowLevelMouseProc lpfn, IntPtr hMod, uint dwThreadId);

    [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    private static extern IntPtr GetModuleHandle(string? lpModuleName);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool UnhookWindowsHookEx(IntPtr hhk);

    [DllImport("user32.dll")]
    private static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);

    [DllImport("user32.dll")]
    private static extern IntPtr WindowFromPoint(POINT point);

    [DllImport("user32.dll")]
    private static extern IntPtr GetAncestor(IntPtr hWnd, uint gaFlags);
}
