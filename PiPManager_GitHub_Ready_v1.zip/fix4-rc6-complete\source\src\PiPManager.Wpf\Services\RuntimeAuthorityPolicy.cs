using PiPManager.Wpf.Models;

namespace PiPManager.Wpf.Services;

internal static class RuntimeAuthorityPolicy
{
    internal const string EnvironmentVariable = "PIPMANAGER_REACTOR_CAPTURE_MODE";

    internal static ReactorCaptureMode Resolve(string? configured) =>
        configured?.Trim().ToLowerInvariant() switch
        {
            "primary" => ReactorCaptureMode.Primary,
            "legacy" => ReactorCaptureMode.Legacy,
            _ => ReactorCaptureMode.Compare
        };

    internal static string ToWireValue(ReactorCaptureMode mode) => mode switch
    {
        ReactorCaptureMode.Primary => "primary",
        ReactorCaptureMode.Legacy => "legacy",
        _ => "compare"
    };

    internal static string ResolveWireValue() =>
        ToWireValue(Resolve(Environment.GetEnvironmentVariable(EnvironmentVariable)));
}

