﻿using PiPManager.Core.Automation;

namespace PiPManager.Core.Slots;

/// <summary>
/// Máquina de estados com guardas contra eventos antigos.
/// Eventos de sucesso/falha/reconexão precisam corresponder ao AttemptId atual.
/// Perda de HWND precisa corresponder ao PipHwnd atual.
/// </summary>
public sealed class SlotStateMachine
{
    public (SlotSnapshot Next, SlotTransition Transition) Apply(
        SlotSnapshot current,
        AutomationEvent ev)
    {
        return ev switch
        {
            UserOpenPipRequested e => OnUserOpenPipRequested(current, e),
            PipWindowCaptured e => OnPipWindowCaptured(current, e),
            ExternalPipCaptured e => OnExternalPipCaptured(current, e),
            VideoChanged e => OnVideoChanged(current, e),
            PipWindowLost e => OnPipWindowLost(current, e),
            ReconnectRetryQueued e => OnReconnectRetryQueued(current, e),
            ReconnectStarted e => OnReconnectStarted(current, e),
            ReconnectSucceeded e => OnReconnectSucceeded(current, e),
            PreservedSameHwndConfirmed e => OnPreservedSameHwndConfirmed(current, e),
            ReconnectFailed e => OnReconnectFailed(current, e),
            SlotResetRequested e => OnSlotResetRequested(current, e),
            _ => NoChange(current, ev, "evento não tratado nesta fundação")
        };
    }

    private static bool IsCurrentAttempt(SlotSnapshot current, string attemptId)
        => !string.IsNullOrWhiteSpace(attemptId)
           && string.Equals(current.AttemptId, attemptId, StringComparison.Ordinal);

    private static bool IsActionState(SlotSnapshot current)
        => current.State is SlotState.Opening or SlotState.Reconnecting or SlotState.WaitingForReconnect;

    private static (SlotSnapshot, SlotTransition) OnUserOpenPipRequested(
        SlotSnapshot current,
        UserOpenPipRequested ev)
    {
        if (string.IsNullOrWhiteSpace(ev.AttemptId))
            return NoChange(current, ev, "UserOpenPipRequested ignorado sem AttemptId");

        if (current.State is SlotState.Opening or SlotState.Reconnecting)
            return NoChange(current, ev, "slot já possui ação ativa");

        var next = current with
        {
            State = SlotState.Opening,
            TabId = ev.SelectedTabId ?? current.TabId,
            AttemptId = ev.AttemptId,
            FailureReason = null,
            UpdatedAt = ev.CreatedAt
        };

        return (next, SlotTransition.ChangedTo(current, SlotState.Opening, ev.Name, ev.AttemptId));
    }

    private static (SlotSnapshot, SlotTransition) OnExternalPipCaptured(
        SlotSnapshot current,
        ExternalPipCaptured ev)
    {
        if (ev.PipHwnd == IntPtr.Zero)
            return NoChange(current, ev, "captura externa ignorada: HWND zero");

        if (current.State is SlotState.Opening or SlotState.Reconnecting or SlotState.WaitingForReconnect)
            return NoChange(current, ev, "captura externa ignorada durante tentativa ativa");

        var next = current with
        {
            State = SlotState.Active,
            PipHwnd = ev.PipHwnd,
            AttemptId = ev.AttemptId,
            FailureReason = null,
            UpdatedAt = ev.CreatedAt
        };

        return (next, SlotTransition.ChangedTo(current, SlotState.Active, ev.Name, ev.AttemptId, "captura externa adotada pelo Shadow"));
    }

    private static (SlotSnapshot, SlotTransition) OnPipWindowCaptured(
        SlotSnapshot current,
        PipWindowCaptured ev)
    {
        if (ev.PipHwnd == IntPtr.Zero)
            return NoChange(current, ev, "captura de PiP ignorada: HWND zero");

        if (current.State is not (SlotState.Opening or SlotState.Reconnecting))
            return NoChange(current, ev, "captura de PiP ignorada fora de Opening/Reconnecting");

        if (!IsCurrentAttempt(current, ev.AttemptId))
            return NoChange(current, ev, "captura de PiP ignorada por AttemptId antigo");

        var next = current with
        {
            State = SlotState.Active,
            PipHwnd = ev.PipHwnd,
            AttemptId = ev.AttemptId,
            FailureReason = null,
            UpdatedAt = ev.CreatedAt
        };

        return (next, SlotTransition.ChangedTo(current, SlotState.Active, ev.Name, ev.AttemptId));
    }

    private static (SlotSnapshot, SlotTransition) OnVideoChanged(
        SlotSnapshot current,
        VideoChanged ev)
    {
        if (current.State != SlotState.Active)
            return NoChange(current, ev, "VideoChanged ignorado fora de Active");

        if (string.IsNullOrWhiteSpace(ev.VideoSessionId))
            return NoChange(current, ev, "VideoChanged ignorado sem VideoSessionId");

        if (!current.AutoReturnEnabled)
        {
            var updated = current with
            {
                VideoSessionId = ev.VideoSessionId,
                StableVideoKey = ev.StableVideoKey ?? current.StableVideoKey,
                AttemptId = ev.AttemptId,
                UpdatedAt = ev.CreatedAt
            };

            return (updated, SlotTransition.AppliedWithoutStateChange(
                updated,
                ev.Name,
                ev.AttemptId,
                "VideoChanged aplicado sem reconexão porque AutoRetorno está desativado no slot"));
        }

        var next = current with
        {
            State = SlotState.WaitingForReconnect,
            VideoSessionId = ev.VideoSessionId,
            StableVideoKey = ev.StableVideoKey ?? current.StableVideoKey,
            AttemptId = ev.AttemptId,
            FailureReason = null,
            UpdatedAt = ev.CreatedAt
        };

        return (next, SlotTransition.ChangedTo(current, SlotState.WaitingForReconnect, ev.Name, ev.AttemptId));
    }

    private static (SlotSnapshot, SlotTransition) OnPipWindowLost(
        SlotSnapshot current,
        PipWindowLost ev)
    {
        if (!current.PipHwnd.HasValue)
            return NoChange(current, ev, "PipWindowLost ignorado: slot não possui HWND atual");

        if (current.PipHwnd.Value != ev.OldHwnd)
            return NoChange(current, ev, "PipWindowLost ignorado: HWND antigo não corresponde ao PiP atual");

        if (current.State != SlotState.Active)
            return NoChange(current, ev, "PipWindowLost ignorado fora de Active");

        if (!current.AutoReturnEnabled)
        {
            var failed = current with
            {
                State = SlotState.Failed,
                PipHwnd = null,
                AttemptId = ev.AttemptId,
                FailureReason = "PiP perdido e AutoRetorno desativado",
                UpdatedAt = ev.CreatedAt
            };

            return (failed, SlotTransition.ChangedTo(current, SlotState.Failed, ev.Name, ev.AttemptId, failed.FailureReason));
        }

        var next = current with
        {
            State = SlotState.WaitingForReconnect,
            PipHwnd = null,
            AttemptId = ev.AttemptId,
            FailureReason = null,
            UpdatedAt = ev.CreatedAt
        };

        return (next, SlotTransition.ChangedTo(current, SlotState.WaitingForReconnect, ev.Name, ev.AttemptId));
    }

    private static (SlotSnapshot, SlotTransition) OnReconnectRetryQueued(
        SlotSnapshot current,
        ReconnectRetryQueued ev)
    {
        if (current.State != SlotState.Failed)
            return NoChange(current, ev, "retry de reconexão só é enfileirado a partir de Failed");

        if (string.IsNullOrWhiteSpace(ev.AttemptId))
            return NoChange(current, ev, "ReconnectRetryQueued ignorado sem AttemptId");

        var next = current with
        {
            State = SlotState.WaitingForReconnect,
            PipHwnd = null,
            AttemptId = ev.AttemptId,
            FailureReason = null,
            UpdatedAt = ev.CreatedAt
        };

        return (next, SlotTransition.ChangedTo(current, SlotState.WaitingForReconnect, ev.Name, ev.AttemptId, "retry normalizado após Failed"));
    }

    private static (SlotSnapshot, SlotTransition) OnReconnectStarted(
        SlotSnapshot current,
        ReconnectStarted ev)
    {
        if (current.State != SlotState.WaitingForReconnect)
            return NoChange(current, ev, "reconexão só inicia a partir de WaitingForReconnect");

        if (!IsCurrentAttempt(current, ev.AttemptId))
            return NoChange(current, ev, "ReconnectStarted ignorado por AttemptId antigo");

        var next = current with
        {
            State = SlotState.Reconnecting,
            AttemptId = ev.AttemptId,
            FailureReason = null,
            UpdatedAt = ev.CreatedAt
        };

        return (next, SlotTransition.ChangedTo(current, SlotState.Reconnecting, ev.Name, ev.AttemptId));
    }

    private static (SlotSnapshot, SlotTransition) OnPreservedSameHwndConfirmed(
        SlotSnapshot current,
        PreservedSameHwndConfirmed ev)
    {
        if (ev.PipHwnd == IntPtr.Zero)
            return NoChange(current, ev, "preservação same HWND ignorada: HWND zero");

        if (current.State is not (SlotState.WaitingForReconnect or SlotState.Reconnecting))
            return NoChange(current, ev, "preservação same HWND ignorada fora de reconexão");

        if (current.AttemptId != ev.AttemptId)
            return NoChange(current, ev, "preservação same HWND ignorada: AttemptId divergente");

        if (current.PipHwnd.HasValue && current.PipHwnd.Value != ev.PipHwnd)
            return NoChange(current, ev, "preservação same HWND ignorada: HWND divergente");

        var next = current with
        {
            State = SlotState.Active,
            PipHwnd = ev.PipHwnd,
            FailureReason = null,
            IsHidden = false,
            UpdatedAt = ev.CreatedAt
        };

        return (next, SlotTransition.ChangedTo(current, SlotState.Active, ev.Name, ev.AttemptId, "preserved-same-hwnd confirmado pelo legado"));
    }

    private static (SlotSnapshot, SlotTransition) OnReconnectSucceeded(
        SlotSnapshot current,
        ReconnectSucceeded ev)
    {
        if (current.State != SlotState.Reconnecting)
            return NoChange(current, ev, "ReconnectSucceeded ignorado fora de Reconnecting");

        if (!IsCurrentAttempt(current, ev.AttemptId))
            return NoChange(current, ev, "ReconnectSucceeded ignorado por AttemptId antigo");

        if (!ev.PipHwnd.HasValue || ev.PipHwnd.Value == IntPtr.Zero)
            return NoChange(current, ev, "ReconnectSucceeded ignorado sem HWND novo válido no evento");

        var next = current with
        {
            State = SlotState.Active,
            PipHwnd = ev.PipHwnd.Value,
            AttemptId = ev.AttemptId,
            FailureReason = null,
            UpdatedAt = ev.CreatedAt
        };

        return (next, SlotTransition.ChangedTo(current, SlotState.Active, ev.Name, ev.AttemptId));
    }

    private static (SlotSnapshot, SlotTransition) OnReconnectFailed(
        SlotSnapshot current,
        ReconnectFailed ev)
    {
        if (current.State != SlotState.Reconnecting)
            return NoChange(current, ev, "ReconnectFailed ignorado fora de Reconnecting");

        if (!IsCurrentAttempt(current, ev.AttemptId))
            return NoChange(current, ev, "ReconnectFailed ignorado por AttemptId antigo");

        var next = current with
        {
            State = SlotState.Failed,
            AttemptId = ev.AttemptId,
            FailureReason = ev.Reason,
            UpdatedAt = ev.CreatedAt
        };

        return (next, SlotTransition.ChangedTo(current, SlotState.Failed, ev.Name, ev.AttemptId, ev.Reason));
    }

    private static (SlotSnapshot, SlotTransition) OnSlotResetRequested(
        SlotSnapshot current,
        SlotResetRequested ev)
    {
        var next = SlotSnapshot.EmptySlot(current.SlotNumber) with
        {
            AutoReturnEnabled = current.AutoReturnEnabled,
            IsLocked = current.IsLocked,
            UpdatedAt = ev.CreatedAt
        };

        return (next, SlotTransition.ChangedTo(current, SlotState.Empty, ev.Name, ev.AttemptId));
    }

    private static (SlotSnapshot, SlotTransition) NoChange(
        SlotSnapshot current,
        AutomationEvent ev,
        string reason)
        => (current, SlotTransition.Ignored(current, ev.Name, ev.AttemptId, reason));
}
