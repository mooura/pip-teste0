param([string]$Root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path)
$ErrorActionPreference = 'Stop'
$failed = 0
function Check($name, $ok) { if ($ok) { Write-Host "$name`: OK" } else { Write-Host "$name`: FAIL"; $script:failed++ } }
$main = Get-Content (Join-Path $Root 'src\PiPManager.Wpf\MainWindow.xaml.cs') -Raw
$xaml = Get-Content (Join-Path $Root 'src\PiPManager.Wpf\MainWindow.xaml') -Raw
$settings = Get-Content (Join-Path $Root 'src\PiPManager.Wpf\Models\AppSettings.cs') -Raw
$monitor = Get-Content (Join-Path $Root 'src\PiPManager.Wpf\Services\MonitorService.cs') -Raw
$win32 = Get-Content (Join-Path $Root 'src\PiPManager.Wpf\Services\Win32.cs') -Raw
$layout = Get-Content (Join-Path $Root 'src\PiPManager.Wpf\Services\LayoutService.cs') -Raw
$appHostSource = Get-Content (Join-Path $Root 'src\PiPManager.Wpf\Services\AppHostService.cs') -Raw
$fakeTestProject = Get-Content (Join-Path $Root 'tests\PiPManager.WindowEventMonitor.Tests\PiPManager.WindowEventMonitor.Tests.csproj') -Raw
$enumDisplayMonitorDeclarations = ([regex]::Matches($win32, 'extern\s+bool\s+EnumDisplayMonitors\s*\(')).Count
$getMonitorInfoDeclarations = ([regex]::Matches($win32, 'extern\s+bool\s+GetMonitorInfo\s*\(')).Count
Check 'monitor selector visible' ($xaml.Contains('x:Name="LayoutMonitorCombo"'))
Check 'move selected slot action visible' ($xaml.Contains('x:Name="MoveSelectedSlotToMonitorButton"'))
Check 'monitor preference persisted' ($settings.Contains('LayoutMonitorDeviceName'))
Check 'monitor service registered' ($appHostSource.Contains('AddSingleton<MonitorService>'))
Check 'display monitors enumerated' ($win32.Contains('EnumDisplayMonitors') -and $win32.Contains('GetMonitorInfo'))
Check 'work area rcWork used' ($win32.Contains('rcWork') -and $monitor.Contains('GetPreferredMonitor'))
Check 'layout clamps to selected work area' ($layout.Contains('ClampGroupToWorkArea') -and $main.Contains('GetSelectedLayoutMonitor()?.WorkArea'))
Check 'monitor change reorganizes group' ($main.Contains('LayoutMonitorCombo_SelectionChanged') -and $main.Contains('RebuildGroupFromLayout(preferPanelTemplateAnchor: true'))
Check 'selected slot moves to monitor without resizing' ($main.Contains('MoveSelectedSlotToMonitorButton_Click') -and $main.Contains('PipWindowService.MoveVisual(SelectedSlot.Window.Handle, target.Left, target.Top)'))
Check 'checker included in core gate' ((Get-Content (Join-Path $Root 'RUN_CORE_TESTS.bat') -Raw).Contains('CHECK_MULTI_MONITOR_LAYOUT_UX.ps1'))
Check 'Win32 monitor P/Invokes declared once' ($enumDisplayMonitorDeclarations -eq 1 -and $getMonitorInfoDeclarations -eq 1)
Check 'DisplayMonitorInfo linked into fake tests' ($fakeTestProject.Contains('Models\DisplayMonitorInfo.cs'))
Check 'default constructor resolves MonitorService in order' ($main.Contains('App.Services.GetRequiredService<LayoutService>(),') -and $main.Contains('App.Services.GetRequiredService<MonitorService>(),') -and $main.IndexOf('App.Services.GetRequiredService<LayoutService>(),') -lt $main.IndexOf('App.Services.GetRequiredService<MonitorService>(),') -and $main.IndexOf('App.Services.GetRequiredService<MonitorService>(),') -lt $main.IndexOf('App.Services.GetRequiredService<ExtensionBridgeService>(),'))
if ($failed -gt 0) { throw 'Multi-monitor layout UX checks failed.' }
Write-Host 'Multi-monitor layout UX checks OK.'
