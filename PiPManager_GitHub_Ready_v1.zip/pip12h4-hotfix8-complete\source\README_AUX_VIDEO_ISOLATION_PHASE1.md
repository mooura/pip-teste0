# PIP FIX7 — Phase 1 preservada na extensão 1.4.39.21

Esta versão preserva no projeto completo a Fase 1, originalmente introduzida em `1.4.39.13`, dentro da extensão atual `1.4.39.21` de isolamento de vídeos auxiliares.

## Alterações

- vídeos de preload recebem marcação própria (`data-pip-manager-auxiliary` e `data-pip-manager-preload`);
- vídeos auxiliares são excluídos da descoberta operacional, pareamento, comandos, abertura de PiP e eventos terminais;
- snapshots distinguem vídeos operacionais de elementos auxiliares do DOM;
- sessões antigas do mesmo `tabId/frameId` são removidas após mudança de `pageInstanceId`;
- versão da extensão sincronizada no manifesto, aplicativo WPF, baseline, distribuição e gates estáticos.

## Escopo preservado

Esta fase não altera a geometria das janelas, o tamanho do buffer, a state machine do target resolver nem a política de AutoReturn.

## Identificador interno

`1.4.39.21-reconnect-ownership-geometry-hotfix6` (inclui integralmente a Phase 1)
