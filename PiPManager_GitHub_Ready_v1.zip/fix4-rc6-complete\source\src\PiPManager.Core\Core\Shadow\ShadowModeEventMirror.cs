﻿using PiPManager.Core.Automation;
using PiPManager.Core.Slots;

namespace PiPManager.Core.Shadow;

/// <summary>
/// Espelha eventos para o novo AutomationEngine sem executar ações reais.
/// Esta classe é segura para Shadow Mode: ela calcula decisões, registra histórico,
/// mas não chama BrowserBridge, Win32, UI, timers reais ou atalhos.
/// </summary>
public sealed class ShadowModeEventMirror
{
    private readonly object _gate = new();
    private readonly AutomationEngine _engine;
    private readonly Queue<ShadowDecisionResult> _history = new();

    private long _sequence;

    public ShadowModeEventMirror()
        : this(new AutomationEngine(), new ShadowModeOptions())
    {
    }

    public ShadowModeEventMirror(AutomationEngine engine, ShadowModeOptions options)
    {
        _engine = engine;
        Options = options;
    }

    public ShadowModeOptions Options { get; private set; }

    public IReadOnlyCollection<ShadowDecisionResult> History
    {
        get
        {
            lock (_gate)
                return _history.ToArray();
        }
    }

    public void Configure(ShadowModeOptions options)
    {
        lock (_gate)
            Options = options;
    }

    public SlotSnapshot ImportSnapshot(SlotSnapshot snapshot)
    {
        lock (_gate)
            return _engine.ImportSnapshot(snapshot);
    }

    public ShadowDecisionResult Mirror(AutomationEvent ev)
    {
        lock (_gate)
        {
            var sequence = ++_sequence;

            if (!Options.Enabled)
            {
                var ignored = ShadowDecisionResult.Ignored(sequence, ev, "Shadow Mode desativado");
                AddHistory(ignored);
                return ignored;
            }

            AutomationDecision decision;

            try
            {
                decision = _engine.Apply(ev);
            }
            catch (Exception ex)
            {
                var failed = ShadowDecisionResult.Ignored(sequence, ev, "Shadow Mode rejeitou evento: " + ex.Message);
                AddHistory(failed);
                return failed;
            }

            // Nesta fase, ações são apenas previstas quando há mudança real de estado.
            // Eventos NoChange são processados, mas marcados como Accepted=false.
            // Nunca executar ações reais pelo Shadow Mode.
            var result = ShadowDecisionResult.FromDecision(
                sequence,
                decision,
                executed: false,
                reason: Options.ExecuteActions
                    ? "Shadow Mode calculou ações, mas execução real permanece bloqueada nesta fase"
                    : "Shadow Mode somente leitura");

            AddHistory(result);
            return result;
        }
    }

    public IReadOnlyCollection<SlotSnapshot> GetEngineSnapshot()
        => _engine.GetSnapshot();

    public void Clear()
    {
        lock (_gate)
        {
            _engine.Clear();
            _history.Clear();
            _sequence = 0;
        }
    }

    private void AddHistory(ShadowDecisionResult result)
    {
        if (!Options.CaptureDecisions)
            return;

        _history.Enqueue(result);

        var max = Math.Max(1, Options.MaxHistory);
        while (_history.Count > max)
            _history.Dequeue();
    }
}
