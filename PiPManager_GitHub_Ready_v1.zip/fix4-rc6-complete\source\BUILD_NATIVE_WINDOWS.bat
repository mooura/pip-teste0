@echo off
setlocal
cd /d "%~dp0"

set "NATIVE_PROJECT=%~dp0src\PiPManager.Native\PiPManager.Native.vcxproj"
set "NATIVE_BUILD_DLL=%~dp0src\PiPManager.Native\bin\x64\Release\PiPManager.Native.dll"
set "NATIVE_PREBUILT_DLL=%~dp0src\PiPManager.Native\prebuilt\PiPManager.Native.dll"
set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
set "MSBUILD_EXE="

if exist "%VSWHERE%" (
  for /f "usebackq delims=" %%I in (`"%VSWHERE%" -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -find MSBuild\**\Bin\MSBuild.exe`) do (
    if not defined MSBUILD_EXE set "MSBUILD_EXE=%%I"
  )
)

if not defined MSBUILD_EXE (
  if exist "%NATIVE_PREBUILT_DLL%" (
    echo Native C++ workload not found. Using validated prebuilt PiPManager.Native.dll.
    exit /b 0
  )
  echo.
  echo NATIVE_BUILD_FAILED: Visual Studio 2022 Desktop development with C++ was not found.
  echo Install Microsoft.VisualStudio.Component.VC.Tools.x86.x64 or restore the prebuilt DLL.
  exit /b 1
)

echo Building PiPManager.Native.dll with %MSBUILD_EXE%...
"%MSBUILD_EXE%" "%NATIVE_PROJECT%" /m /t:Build /p:Configuration=Release /p:Platform=x64 /v:minimal
if errorlevel 1 (
  echo.
  echo NATIVE_BUILD_FAILED: MSBuild returned an error.
  exit /b 1
)

if not exist "%NATIVE_BUILD_DLL%" (
  echo.
  echo NATIVE_BUILD_FAILED: %NATIVE_BUILD_DLL% was not produced.
  exit /b 1
)

if not exist "%~dp0src\PiPManager.Native\prebuilt" mkdir "%~dp0src\PiPManager.Native\prebuilt"
copy /y "%NATIVE_BUILD_DLL%" "%NATIVE_PREBUILT_DLL%" >nul
if errorlevel 1 (
  echo NATIVE_BUILD_FAILED: could not refresh validated prebuilt DLL.
  exit /b 1
)

echo Native build OK: %NATIVE_PREBUILT_DLL%
exit /b 0
