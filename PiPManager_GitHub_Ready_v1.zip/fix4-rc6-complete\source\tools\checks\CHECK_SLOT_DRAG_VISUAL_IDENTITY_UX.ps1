param([string]$Root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path)
$ErrorActionPreference = 'Stop'
$failed=0
function Check($name,$ok){ if($ok){Write-Host "${name}: OK"}else{Write-Host "${name}: FAIL";$script:failed++}}
$xaml=Get-Content (Join-Path $Root 'src\PiPManager.Wpf\MainWindow.xaml') -Raw
$main=Get-Content (Join-Path $Root 'src\PiPManager.Wpf\MainWindow.xaml.cs') -Raw
$model=Get-Content (Join-Path $Root 'src\PiPManager.Wpf\Models\PipSlot.cs') -Raw
$gate=Get-Content (Join-Path $Root 'RUN_CORE_TESTS.bat') -Raw
Check 'slot drag handlers wired' ($xaml.Contains('MouseMove="SlotItem_MouseMove"') -and $xaml.Contains('Drop="SlotItem_Drop"'))
Check 'drag swap has transient-state guard' ($main.Contains('CanSwapSlots') -and $main.Contains('reconexão em andamento'))
Check 'slot assignment dictionaries move together' ($main.Contains('SwapDictionaryValues(_slotVideoPairs') -and $main.Contains('SwapDictionaryValues(_slotAutoReturnDiscreteBySlot'))
Check 'slot windows move to destination rect' ($main.Contains('GetSlotDropTargetRect') -and $main.Contains('slot-drag-swap-completed'))
Check 'visual slot label' ($model.Contains('SlotLabel') -and $xaml.Contains('Text="{Binding SlotLabel}"'))
Check 'visual state badge' ($model.Contains('StateBadgeText') -and $xaml.Contains('Text="{Binding StateBadgeText}"'))
Check 'visual source identity' ($model.Contains('VisualIdentityText') -and $xaml.Contains('Text="{Binding VisualIdentityText}"'))
Check 'checker included in core gate' ($gate.Contains('CHECK_SLOT_DRAG_VISUAL_IDENTITY_UX.ps1'))
Check 'slot auto-return visuals use existing refresh path' ($main.Contains('NormalizeSlotAutoReturnSettings(migrateFromGlobal: false);') -and $main.Contains('UpdateAutoReturnPolicyVisual();') -and -not $main.Contains('UpdateSlotAutoReturnVisuals();'))
if($failed -gt 0){throw 'Slot drag and visual identity UX checks failed.'}
Write-Host 'Slot drag and visual identity UX checks OK.'
