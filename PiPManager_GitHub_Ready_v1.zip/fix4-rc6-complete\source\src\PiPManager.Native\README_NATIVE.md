# PiPManager.Native

Núcleo C++ experimental para movimentação atômica das janelas PiP.

- ABI pública em C (`pip_native_version` e `pip_process_window_batch`).
- Sem estado de AutoReturn e sem decisões de negócio.
- O modo Compare apenas calcula o plano nativo; o C# continua aplicando.
- O modo Primary aplica o lote em C++ e volta automaticamente ao C# se houver falha.

Para recompilar, instale o workload **Desktop development with C++** do Visual Studio 2022 e execute `BUILD_NATIVE_WINDOWS.bat` na raiz.
