﻿using System.Collections.Concurrent;

namespace PiPManager.Wpf.Services;

public sealed record WindowEventFlowControlSnapshot(
    long SuppressedInternalMovements,
    int ArmedHandles,
    int LastGeneration,
    string LastSource);

public interface IWindowEventFlowControlService
{
    void ArmInternalMovementSuppression(IEnumerable<IntPtr> handles, int generation, TimeSpan duration, string source);
    bool ShouldSuppressMovement(IntPtr hwnd, DateTimeOffset now, out int generation, out string source);
    WindowEventFlowControlSnapshot GetSnapshot();
}

/// <summary>
/// Shared event-flow gate used by layout and the WinEvent monitor. Layout-generated movement is
/// discarded before it reaches the Reactor, Shadow, polling comparison or the WPF Dispatcher.
/// </summary>
public sealed class WindowEventFlowControlService : IWindowEventFlowControlService
{
    private sealed record SuppressionLease(DateTimeOffset UntilUtc, int Generation, string Source);

    private readonly ConcurrentDictionary<IntPtr, SuppressionLease> _movementSuppressionByHwnd = new();
    private long _suppressedInternalMovements;
    private int _lastGeneration;
    private string _lastSource = string.Empty;

    public void ArmInternalMovementSuppression(IEnumerable<IntPtr> handles, int generation, TimeSpan duration, string source)
    {
        var now = DateTimeOffset.UtcNow;
        var until = now.Add(duration < TimeSpan.FromMilliseconds(350)
            ? TimeSpan.FromMilliseconds(350)
            : duration);

        var distinctHandles = handles
            .Where(handle => handle != IntPtr.Zero)
            .Distinct()
            .ToArray();

        foreach (var handle in distinctHandles)
            _movementSuppressionByHwnd[handle] = new SuppressionLease(until, generation, source);

        Volatile.Write(ref _lastGeneration, generation);
        _lastSource = source;
        CleanupExpired(now);
    }

    public bool ShouldSuppressMovement(IntPtr hwnd, DateTimeOffset now, out int generation, out string source)
    {
        generation = 0;
        source = string.Empty;

        if (hwnd == IntPtr.Zero || !_movementSuppressionByHwnd.TryGetValue(hwnd, out var lease))
            return false;

        if (now > lease.UntilUtc)
        {
            _movementSuppressionByHwnd.TryRemove(hwnd, out _);
            return false;
        }

        generation = lease.Generation;
        source = lease.Source;
        Interlocked.Increment(ref _suppressedInternalMovements);
        return true;
    }

    public WindowEventFlowControlSnapshot GetSnapshot()
    {
        CleanupExpired(DateTimeOffset.UtcNow);
        return new WindowEventFlowControlSnapshot(
            Interlocked.Read(ref _suppressedInternalMovements),
            _movementSuppressionByHwnd.Count,
            Volatile.Read(ref _lastGeneration),
            _lastSource);
    }

    private void CleanupExpired(DateTimeOffset now)
    {
        foreach (var item in _movementSuppressionByHwnd.Where(item => item.Value.UntilUtc < now).Take(64))
            _movementSuppressionByHwnd.TryRemove(item.Key, out _);
    }
}
