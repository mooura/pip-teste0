$ErrorActionPreference = "Stop"
$root = $PSScriptRoot
$product = "9.39.01"; $app = "1.5.12.3901"; $extension = "1.4.39.25"
$distRoot = Join-Path $root "DIST"; $dist = Join-Path $distRoot "PiPManager_9.39.01"
if (Test-Path $dist) { Remove-Item $dist -Recurse -Force }
New-Item -ItemType Directory -Force -Path $dist | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $dist "Extension") | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $dist "HISTORY") | Out-Null
$publishCandidates = @((Join-Path $root "src\PiPManager.Wpf\bin\Release\net8.0-windows\win-x64\publish"))
$publish = $publishCandidates | Where-Object { Test-Path $_ } | Select-Object -First 1
if ($publish) { Copy-Item (Join-Path $publish "*") $dist -Recurse -Force } else { Write-Host "Publish folder not found yet. DIST will include metadata and extension only." }
if (Test-Path (Join-Path $root "src\PiPManager.Extension")) { Copy-Item (Join-Path $root "src\PiPManager.Extension\*") (Join-Path $dist "Extension") -Recurse -Force }
Copy-Item (Join-Path $root "VERSION_STABLE.txt") $dist -Force
if (Test-Path (Join-Path $root "HISTORY")) {
    Copy-Item (Join-Path $root "HISTORY\*") (Join-Path $dist "HISTORY") -Recurse -Force
}
@"
PiP Manager Release
ProductVersion=$product
AppVersion=$app
ExtensionVersion=$extension
Core=net8.0
Mode=ReactorCompareDefault-ManagedLayoutDefault
NativeLayoutEngine=PiPManager.Native.dll ABI 100
GeneratedAt=$(Get-Date -Format o)
"@ | Set-Content -Encoding UTF8 (Join-Path $dist "README_RELEASE.txt")
$checksums = Join-Path $dist "CHECKSUMS_SHA256.txt"
Get-ChildItem $dist -Recurse -File | Where-Object { $_.Name -ne "CHECKSUMS_SHA256.txt" } | Sort-Object FullName | ForEach-Object { $hash = Get-FileHash $_.FullName -Algorithm SHA256; $rel = $_.FullName.Substring($dist.Length + 1); "$($hash.Hash)  $rel" } | Set-Content -Encoding ASCII $checksums
Write-Host "DIST created: $dist"
