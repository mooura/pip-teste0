# Consolidação — Bloco B: fases 5 a 8

Este bloco inicia a decomposição física dos arquivos monolíticos sem alterar regras funcionais.

## Fase 5 — redução de responsabilidades do MainWindow

Foram removidos do code-behind os tipos de dados que não pertencem à apresentação:

- `AutoReturnPolicy`
- `AutoReturnSlotState`
- `VideoSwitchPreservationState`
- `BrowserWindowCandidate`

Eles agora ficam em `Models`. Os métodos de UI continuam no `MainWindow` para preservar a ordem e os contratos dos fluxos existentes.

## Fase 6 — fronteira do AutoRetorno

- A persistência e compatibilidade dos nomes de política foram extraídas para `AutoReturnPolicyCodec`.
- Valores legados `Silent` e `Silencioso` continuam migrando para `Discrete`.
- O estado mutável passou a ter um modelo independente do code-behind.
- Testes determinísticos cobrem parse, migração e formatação da política.

A máquina operacional completa ainda será migrada gradualmente; removê-la de uma só vez quebraria a caracterização baseada na baseline.

## Fase 7 — protocolo da extensão

- Leitura defensiva de JSON foi extraída para `ExtensionProtocolReader`.
- A ponte preserva suas assinaturas e delega o parsing ao componente novo.
- Testes cobrem string, inteiro, default, double, booleano e limite de cinco títulos.

## Fase 8 — perfis por capacidade

- Os comportamentos são classificados como playlist indexada, playlist estruturada,
  controles semânticos do player ou rotação ao vivo em `Extension/site-profiles.js`.
- `manifest.json` carrega o registro antes de `content.js`.
- O perfil genérico não utiliza atalhos nem reescrita de índice.
- Testes Node validam a seleção por capacidades e a ausência de vazamento entre estratégias.

## Comportamento preservado

- Versões do aplicativo e da extensão não mudaram.
- Estratégias Próximo/Voltar permanecem iguais.
- Playlist, preview, preload, AutoRetorno e anti-ad permanecem iguais.
- A dívida funcional do AutoRetorno em players com controles semânticos não foi corrigida neste bloco.
