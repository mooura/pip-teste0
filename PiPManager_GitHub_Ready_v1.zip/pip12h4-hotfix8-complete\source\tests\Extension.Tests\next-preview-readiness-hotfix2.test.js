'use strict';

const fs = require('fs');
const path = require('path');
function assert(condition, message) { if (!condition) throw new Error(`TEST FAILED: ${message}`); }
const root = path.join(__dirname, '..', '..');
const content = fs.readFileSync(path.join(root, 'src', 'PiPManager.Extension', 'content.js'), 'utf8');
const background = fs.readFileSync(path.join(root, 'src', 'PiPManager.Extension', 'background.js'), 'utf8');
const main = fs.readFileSync(path.join(root, 'src', 'PiPManager.Wpf', 'MainWindow.xaml.cs'), 'utf8');
const model = fs.readFileSync(path.join(root, 'src', 'PiPManager.Wpf', 'Models', 'VideoTabInfo.cs'), 'utf8');
const bridge = fs.readFileSync(path.join(root, 'src', 'PiPManager.Wpf', 'Services', 'ExtensionBridgeService.cs'), 'utf8');
const release = fs.readFileSync(path.join(root, 'src', 'PiPManager.Wpf', 'Services', 'ReleaseInfoService.cs'), 'utf8');
const runner = fs.readFileSync(path.join(root, 'RUN_CORE_TESTS.bat'), 'utf8');
const manifest = JSON.parse(fs.readFileSync(path.join(root, 'src', 'PiPManager.Extension', 'manifest.json'), 'utf8'));

assert(manifest.version === '1.4.39.25', 'manifest must be 1.4.39.25');
assert(release.includes('ExtensionVersion = "1.4.39.25"'), 'release metadata must be synchronized');
assert(content.includes("CONTENT_VERSION = '1.4.39.25-command-target-root-guard-hotfix10'"), 'content identifier must be synchronized');
assert(background.includes("BRIDGE_VERSION = '1.4.39.25-command-target-root-guard-hotfix10'"), 'background identifier must be synchronized');
assert(background.includes("nextPreviewAssetId: session.nextPreviewAssetId || ''"), 'background snapshot signature must forward preview asset identity');
assert(content.includes('function buildAuthoritativePreviewPayload('), 'authoritative preview builder must exist');
assert(content.includes('function readNextPagePreviewMetadata('), 'next page metadata parser must exist');
assert(content.includes('nextPreviewAssetId:'), 'extension must publish explicit preview asset identity');
assert(content.includes('pipManagerLastResolvedNextTarget = pipManagerNextTargetState'), 'resolved metadata must refresh the retained authoritative target');
assert(model.includes('NextPreviewAssetId'), 'WPF model must carry preview asset identity');
assert(bridge.includes('NextPreviewAssetId = GetString(item, "nextPreviewAssetId")'), 'bridge must deserialize preview asset identity');
assert(main.includes('IsAuthoritativeNextPreview('), 'WPF must gate preview by authoritative asset identity');
assert(main.includes('preview-asset-not-authoritative'), 'WPF must reject stale preview assets');
assert(main.includes('pip-preserve-silent-readiness-recheck-wait'), 'one bounded readiness recheck must exist');
assert(main.includes('Task.Delay(250)'), 'readiness recheck delay must be 250 ms');
assert(main.includes('Task.Delay(450)'), 'readiness response wait must be bounded');
assert(main.includes('pip-preserve-silent-readiness-recheck-blocked'), 'failed readiness recheck must skip silent open');
assert(main.includes('string.Equals(reasonCode, "player-not-ready"'), 'player-not-ready must be immediate fallback capable');
assert(main.includes('string.Equals(reasonCode, "video-not-ready"'), 'video-not-ready must be immediate fallback capable');
assert(runner.includes('next-preview-readiness-hotfix2.test.js'), 'Hotfix 2 regression must be wired');
console.log('Authoritative Preview + Silent Readiness Hotfix 2 tests: OK');
