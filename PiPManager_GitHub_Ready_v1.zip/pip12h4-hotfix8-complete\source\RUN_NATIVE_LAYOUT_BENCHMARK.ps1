param(
    [int]$WindowCount = 10,
    [int]$Iterations = 1000
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$output = Join-Path $root 'docs\consolidation\native-layout-benchmark.json'

dotnet run --project (Join-Path $root 'benchmarks\PiPManager.LayoutBenchmarks\PiPManager.LayoutBenchmarks.csproj') -c Release -- $output $WindowCount $Iterations
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

Write-Host "Native layout benchmark saved to $output"
