# Validação final no Windows — PiP Manager 9.39.03 P0 RC6

Use uma pasta nova. Não misture arquivos da extensão 1.4.39.6 com a 1.4.39.7.

## 1. Gate automatizado

1. Feche o PiP Manager.
2. Execute `BUILD_WINDOWS.bat`.
3. Confirme a mensagem `BUILD P0 RC6 APROVADO`.
4. Confirme a existência de:
   `DIST\PiPManager_9.39.03\PiPManager.Wpf.exe`.
5. Recarregue a extensão de
   `DIST\PiPManager_9.39.03\Extension`.

Interrompa a validação se houver falha de build, teste, check ou handshake.

## 2. Teste Próximo

1. Abra uma playlist e crie um PiP vinculado.
2. Selecione esse slot e acione `Próximo`.
3. Confirme que o player avança.
4. Se o navegador mantiver o mesmo HWND, confirme que o slot permanece estável.
5. Se o navegador fechar o PiP, confirme que o AutoReturn abre o vídeo novo, não
   o índice anterior.
6. Repita pelo menos cinco vezes.
7. Em pelo menos uma repetição, aguarde mais de 2,2 segundos antes do fechamento
   do PiP e confirme que o vídeo anterior não é reaberto.

No log, procure a mesma sequência de `operationId`:

- `video-command-requested`;
- `video-command-dispatched`;
- `video-command-confirmed`;
- `video-command-final-result`;
- `pip-preserve-state-created`;
- `pip-preserve-command-confirmed`;
- `pip-preserve-video-change-detected`;
- confirmação de preservação ou AutoReturn do novo vídeo.

Não deve aparecer fallback do mesmo vídeo depois de um comando confirmado.

Quando a perda ocorrer depois da janela curta, o log deve manter:

```text
eligibilityMode=video-navigation-confirmed-operation
requiresRealVideoChange=True
navigationCommandResultReceived=True
navigationCommandConfirmed=True
```

## 3. Teste Anterior

1. Com o slot ainda vinculado, acione `Anterior` duas vezes.
2. Confirme que o histórico muda sempre na aba vinculada.
3. Repita com preload ativo e, se possível, com mais de um elemento de vídeo na
   aba.

O resultado esperado no log é:

```text
video-command-requested: ... command=previous
video-command-dispatched: ... command=previous
video-command-confirmed: ... command=previous; ... method=tabs-goBack-linked-tab-authoritative
video-command-final-result: ... command=previous; ... result=confirmed
method=tabs-goBack-linked-tab-authoritative
match=linked-tab-authoritative
```

Os quatro registros devem carregar exatamente o mesmo `operationId`.

Não deve aparecer `retry-blocked-same-tab-ambiguous` para esse comando.

## 4. Regressão geral

Com 4 a 10 PiPs, valide:

- Capturar todos e captura individual;
- seleção e troca de slots;
- horizontal, vertical, grade, livre e Jogo;
- Travar/Fixar conjunto, mover grupo e Igualar;
- Ocultar/Mostrar;
- fechar e reabrir vários PiPs para testar AutoReturn;
- restauração das posições e always-on-top.

## 5. Fixar layout — validação RC6

1. Abra de 5 a 10 PiPs e também um jogo ou aplicativo comum, como o EA SPORTS FC 26.
2. Ative **Fixar layout**.
3. Mova ou maximize o aplicativo comum e confirme que o PiP Manager não altera sua posição nem seu tamanho.
4. Feche dois PiPs vinculados e aguarde o AutoReturn. Cada janela recuperada deve voltar somente ao próprio slot, mantendo seu tamanho.
5. Durante a recuperação, arraste um conteúdo de um slot para outro. O ciclo deve acompanhar o novo número do slot.
6. Deixe um slot indisponível e confirme que o ciclo encerra em até 45 segundos.
7. Observe os demais PiPs: conclusão ou timeout não pode provocar salto, lote global ou reorganização geral.

No log, procure:

```text
fixed-layout-recovery-slot-membership-remapped
fixed-layout-recovery-slot-placed-once: ... resize=False; sizesPreserved=True
fixed-layout-recovery-cycle-finalized: ... timeoutMs=45000; ... globalReflowSuppressed=True
```

Não deve aparecer:

```text
fixed-layout-window-constrained: ... process=FC26.exe
batchAppliedOnce=True
timeoutMs=101000
```

## 6. Prontidão adaptativa do AutoReturn

No Stripchat ou em outro player que reporte `readyState=0` enquanto toca:

1. acione `Anterior` ou provoque a perda do PiP;
2. confirme no log `playing=True` e `hasSource=True`;
3. confirme a ocorrência de
   `auto-return-target-ready-passive-playing-confirmed`;
4. confirme que o AutoReturn recupera o PiP antes do vencimento do estado.

Uma única amostra não pode liberar a tentativa. Fonte ausente ou vídeo encerrado
também devem continuar bloqueados.

## 7. Aprovação

A release está aprovada quando:

- o gate automatizado passa integralmente;
- Próximo nunca reabre o vídeo antigo após confirmação;
- Anterior não é bloqueado por ambiguidade da mesma aba;
- readyState 0 não causa expiração quando duas amostras novas comprovam
  reprodução ativa com fonte;
- nenhum comportamento da regressão geral muda;
- Fixar layout nunca controla aplicativos externos;
- a recuperação do layout encerra em até 45 segundos e não move PiPs estáveis.

Se houver falha, preserve o log completo e volte para a base cujo SHA-256 está
em `BASELINE_ROLLBACK_SHA256.txt`.
