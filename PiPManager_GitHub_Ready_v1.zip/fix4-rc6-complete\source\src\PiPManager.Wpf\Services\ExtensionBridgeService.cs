﻿using System.Collections.Concurrent;
using System.IO;
using System.Net;
using System.Net.WebSockets;
using System.Text;
using System.Text.Json;
using PiPManager.Wpf.Models;

namespace PiPManager.Wpf.Services;

public sealed class ExtensionBridgeService : IDisposable
{
        private readonly System.Collections.Concurrent.ConcurrentDictionary<string, byte> _block411CSharpProbeAttemptIds = new();

    private readonly HttpListener _listener = new();
    private readonly ConcurrentDictionary<Guid, WebSocket> _clients = new();
    private readonly ConcurrentDictionary<Guid, string> _authenticatedClients = new();
    private readonly ConcurrentDictionary<Guid, bool> _challengeSentClients = new();
    private static string CompatibleBridgeVersionPrefix => ReleaseInfoConstants.CompatibleExtensionVersionPrefix;
    private readonly SemaphoreSlim _sendGate = new(1, 1);
    private readonly SemaphoreSlim _snapshotRequestGate = new(1, 1);
    private readonly ConcurrentDictionary<string, long> _lastContentDiagnosticLogUnixMsByKey =
        new(StringComparer.OrdinalIgnoreCase);
    private long _lastSnapshotRequestUnixMs;
    private int _lastSnapshotRequestClientCount;
    private long _suppressedContentDiagnosticCount;
    private const int SnapshotRequestCoalesceMs = 250;
    private const int ContentDiagnosticLogThrottleMs = 15_000;
    private readonly string _sessionHandshakeToken = Guid.NewGuid().ToString("N");
    private CancellationTokenSource? _cts;
    private Task? _serverTask;

    internal event Action<string>? StatusChanged;
    internal event Action<IReadOnlyList<VideoTabInfo>>? VideoTabsUpdated;
    internal event Action<string, IReadOnlyList<TabDiscoveryInfo>>? TabDiscoveryUpdated;
    internal event Action<VideoPipEventInfo>? PictureInPictureEventReceived;
    internal event Action<VideoPlaybackTerminalInfo>? PlaybackTerminalReceived;
    internal event Action<VideoCommandResultInfo>? CommandResultReceived;

    private static bool IsCompatibleExtensionVersion(string? version)
    {
        return !string.IsNullOrWhiteSpace(version) &&
            version.StartsWith(CompatibleBridgeVersionPrefix, StringComparison.OrdinalIgnoreCase);
    }

    internal bool IsConnected => _clients.Any(kv => kv.Value.State == WebSocketState.Open && _authenticatedClients.ContainsKey(kv.Key));
    internal string ConnectedExtensionVersion => _authenticatedClients.Values.LastOrDefault() ?? string.Empty;

    internal void Start()
    {
        if (_cts is not null) return;

        _cts = new CancellationTokenSource();
        _listener.Prefixes.Add("http://127.0.0.1:45151/");

        try
        {
            _listener.Start();
            StatusChanged?.Invoke("Ponte da extensão ativa em ws://127.0.0.1:45151/ws");
            _serverTask = Task.Run(() => AcceptLoopAsync(_cts.Token));
        }
        catch (Exception ex)
        {
            StatusChanged?.Invoke($"Falha ao iniciar ponte da extensão: {ex.Message}");
            Dispose();
        }
    }

    internal async Task<int> SendVideoCommandAsync(VideoCommandKind command, string operationId, string? targetVideoSessionId = null, string? targetStableVideoKey = null, int? targetTabId = null, bool allowNoVideoTarget = false, bool allowSameTabNavigation = false)
    {
        var payload = JsonSerializer.Serialize(new
        {
            type = "videoCommand",
            operationId,
            command = command == VideoCommandKind.Next ? "next" : "previous",
            targetVideoSessionId,
            targetStableVideoKey,
            targetTabId,
            allowNoVideoTarget,
            allowSameTabNavigation,
            ts = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()
        });

        return await SendTextToOpenClientsAsync(payload).ConfigureAwait(false);
    }

    internal Task<int> SendNextVideoPreloadSettingAsync(bool enabled, int targetTabId = 0)
    {
        var payload = JsonSerializer.Serialize(new
        {
            type = "nextVideoPreloadSetting",
            enabled,
            targetTabId,
            ts = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()
        });
        return SendTextToOpenClientsAsync(payload);
    }

    internal Task<int> SendOccupiedSlotsNotificationAsync(string payload)
    {
        return SendTextToOpenClientsAsync(payload);
    }

    internal async Task<int> SendOpenPictureInPictureAsync(string targetVideoSessionId, string targetStableVideoKey, int targetTabId)
    {
        var payload = JsonSerializer.Serialize(new
        {
            type = "openPictureInPicture",
            targetVideoSessionId,
            targetStableVideoKey,
            targetTabId,
            ts = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()
        });

        return await SendTextToOpenClientsAsync(payload).ConfigureAwait(false);
    }

    internal async Task<int> SendOpenPictureInPictureSilentAsync(string targetVideoSessionId, string targetStableVideoKey, int targetTabId, string? attemptId = null)
    {
        var payload = JsonSerializer.Serialize(new
        {
            type = "openPictureInPictureSilent",
            targetVideoSessionId,
            targetStableVideoKey,
            targetTabId,
            attemptId,
            ts = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()
        });

        return await SendTextToOpenClientsAsync(payload).ConfigureAwait(false);
    }


    internal async Task<int> SendSilentMultiFrameProbeAsync(string targetVideoSessionId, string targetStableVideoKey, int targetTabId, string? attemptId = null)
    {
        var payload = JsonSerializer.Serialize(new
        {
            type = "silentMultiFrameProbe",
            targetVideoSessionId,
            targetStableVideoKey,
            targetTabId,
            tabId = targetTabId,
            attemptId = string.IsNullOrWhiteSpace(attemptId) ? $"mfprobe-{DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()}" : attemptId,
            ts = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()
        });

        return await SendTextToOpenClientsAsync(payload).ConfigureAwait(false);
    }

    internal async Task<int> SendSilentReopenPreflightAsync(string targetVideoSessionId, string targetStableVideoKey, int targetTabId, string? attemptId = null)
    {
        var payload = JsonSerializer.Serialize(new
        {
            type = "silentReopenPreflight",
            targetVideoSessionId,
            targetStableVideoKey,
            targetTabId,
            attemptId,
            ts = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()
        });

        return await SendTextToOpenClientsAsync(payload).ConfigureAwait(false);
    }

    internal async Task<int> SendOpenPictureInPictureReacquireAsync(string targetVideoSessionId, string targetStableVideoKey, int targetTabId, string? attemptId = null, bool silent = true)
    {
        var payload = JsonSerializer.Serialize(new
        {
            type = "openPictureInPictureReacquire",
            targetVideoSessionId,
            targetStableVideoKey,
            targetTabId,
            attemptId,
            silent,
            ts = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()
        });

        return await SendTextToOpenClientsAsync(payload).ConfigureAwait(false);
    }

    internal async Task<int> FocusVideoTabAsync(int targetTabId)
    {
        var payload = JsonSerializer.Serialize(new
        {
            type = "focusVideoTab",
            targetTabId,
            ts = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()
        });

        return await SendTextToOpenClientsAsync(payload).ConfigureAwait(false);
    }

    internal async Task<int> RequestVideoSessionsSnapshotAsync(bool force = false, string correlationId = "")
    {
        await _snapshotRequestGate.WaitAsync().ConfigureAwait(false);
        try
        {
            var nowUnixMs = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
            var previousUnixMs = Interlocked.Read(ref _lastSnapshotRequestUnixMs);
            if (!force && previousUnixMs > 0 && nowUnixMs - previousUnixMs < SnapshotRequestCoalesceMs)
                return Volatile.Read(ref _lastSnapshotRequestClientCount);

            var payload = JsonSerializer.Serialize(new
            {
                type = "requestVideoSessionsSnapshot",
                requestId = correlationId ?? string.Empty,
                ts = nowUnixMs
            });

            var clients = await SendTextToOpenClientsAsync(payload).ConfigureAwait(false);
            Interlocked.Exchange(ref _lastSnapshotRequestUnixMs, nowUnixMs);
            Volatile.Write(ref _lastSnapshotRequestClientCount, clients);
            return clients;
        }
        finally
        {
            _snapshotRequestGate.Release();
        }
    }

    private async Task AcceptLoopAsync(CancellationToken token)
    {
        while (!token.IsCancellationRequested && _listener.IsListening)
        {
            HttpListenerContext? context = null;
            try
            {
                context = await _listener.GetContextAsync().ConfigureAwait(false);

                if (!context.Request.IsWebSocketRequest || context.Request.Url?.AbsolutePath != "/ws")
                {
                    context.Response.StatusCode = 404;
                    context.Response.Close();
                    continue;
                }

                var origin = context.Request.Headers["Origin"] ?? string.Empty;
                if (!IsAllowedWebSocketOrigin(origin))
                {
                    context.Response.StatusCode = 403;
                    context.Response.Close();
                    StatusChanged?.Invoke($"Cliente WebSocket recusado por Origin inválida: {origin}");
                    continue;
                }

                var wsContext = await context.AcceptWebSocketAsync(subProtocol: null).ConfigureAwait(false);
                var id = Guid.NewGuid();
                _clients[id] = wsContext.WebSocket;
                StatusChanged?.Invoke("Cliente WebSocket conectado; aguardando handshake da extensão");
                _ = Task.Run(() => ReceiveLoopAsync(id, wsContext.WebSocket, token), token);
            }
            catch (ObjectDisposedException)
            {
                break;
            }
            catch (HttpListenerException)
            {
                break;
            }
            catch (Exception ex)
            {
                StatusChanged?.Invoke($"Erro na ponte da extensão: {ex.Message}");
                try { context?.Response.Close(); } catch { }
            }
        }
    }

    private void SendHandshakeChallenge(Guid clientId, string version)
    {
        try
        {
            if (!_clients.TryGetValue(clientId, out var socket) ||
                socket.State != WebSocketState.Open)
            {
                return;
            }

            var payload = JsonSerializer.Serialize(new
            {
                type = "authChallenge",
                version,
                token = _sessionHandshakeToken,
                product = "PiPManager",
                ts = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()
            });

            var bytes = Encoding.UTF8.GetBytes(payload);
            _ = SendRawSerializedAsync(socket, bytes);
        }
        catch (Exception ex)
        {
            AppLogger.Warn($"extension-bridge-auth-challenge-failed: {ex.Message}");
        }
    }

    private async Task SendRawSerializedAsync(WebSocket socket, byte[] bytes)
    {
        AppLogger.Info("extension-bridge-send-serialized-cleanpatch4");
        await _sendGate.WaitAsync().ConfigureAwait(false);
        try
        {
            if (socket.State == WebSocketState.Open)
            {
                await socket.SendAsync(
                    bytes,
                    WebSocketMessageType.Text,
                    endOfMessage: true,
                    cancellationToken: CancellationToken.None).ConfigureAwait(false);
            }
        }
        catch (Exception ex)
        {
            AppLogger.Warn($"extension-bridge-serialized-send-failed: {ex.Message}");
        }
        finally
        {
            _sendGate.Release();
        }
    }

    private static bool IsAllowedWebSocketOrigin(string origin)
    {
        if (string.IsNullOrWhiteSpace(origin) ||
            origin.Equals("null", StringComparison.OrdinalIgnoreCase))
        {
            return true;
        }

        return origin.StartsWith("moz-extension://", StringComparison.OrdinalIgnoreCase)
            || origin.StartsWith("chrome-extension://", StringComparison.OrdinalIgnoreCase)
            || origin.StartsWith("ms-browser-extension://", StringComparison.OrdinalIgnoreCase);
    }

    private async Task ReceiveLoopAsync(Guid id, WebSocket socket, CancellationToken token)
    {
        var buffer = new byte[16384];
        try
        {
            while (!token.IsCancellationRequested && socket.State == WebSocketState.Open)
            {
                using var messageBuffer = new MemoryStream();
                WebSocketReceiveResult result;

                do
                {
                    result = await socket.ReceiveAsync(new ArraySegment<byte>(buffer), token).ConfigureAwait(false);

                    if (result.MessageType == WebSocketMessageType.Close)
                        return;

                    if (result.MessageType != WebSocketMessageType.Text)
                        break;

                    if (result.Count > 0)
                        messageBuffer.Write(buffer, 0, result.Count);

                    // Proteção simples contra snapshot/log grande demais ou cliente com comportamento errado.
                    if (messageBuffer.Length > 4 * 1024 * 1024)
                    {
                        StatusChanged?.Invoke("Mensagem da extensão ignorada: maior que 4 MB");
                        break;
                    }
                }
                while (!result.EndOfMessage && !token.IsCancellationRequested && socket.State == WebSocketState.Open);

                if (result.MessageType == WebSocketMessageType.Text && result.EndOfMessage && messageBuffer.Length > 0)
                {
                    var text = Encoding.UTF8.GetString(messageBuffer.ToArray());
                    HandleClientMessage(id, text);
                }
            }
        }
        catch
        {
            // Cliente desconectou ou navegador reiniciou.
        }
        finally
        {
            _clients.TryRemove(id, out _);
            _authenticatedClients.TryRemove(id, out _);
            _challengeSentClients.TryRemove(id, out _);
            try
            {
                if (socket.State == WebSocketState.Open || socket.State == WebSocketState.CloseReceived)
                    await socket.CloseAsync(WebSocketCloseStatus.NormalClosure, "closed", CancellationToken.None).ConfigureAwait(false);
            }
            catch { }
            socket.Dispose();
            StatusChanged?.Invoke("Extensão desconectada da ponte local");
        }
    }

    private static string ShortId(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return string.Empty;
        return value.Length <= 16 ? value : value[..16];
    }

    private void HandleClientMessage(Guid clientId, string text)
    {
        try
        {
            using var doc = JsonDocument.Parse(text);
            if (!doc.RootElement.TryGetProperty("type", out var typeProperty))
                return;

            var type = typeProperty.GetString();
            if (type == "hello")
            {
                var version = GetString(doc.RootElement, "version");

                if (!IsCompatibleExtensionVersion(version))
                {
                    var rejected = string.IsNullOrWhiteSpace(version)
                        ? "sem versão"
                        : version;

                    StatusChanged?.Invoke($"Handshake da extensão recusado — versão incompatível: {rejected}");
                    AppLogger.Warn($"extension-bridge-handshake-rejected: client={clientId}; version={rejected}");
                    return;
                }

                _challengeSentClients[clientId] = true;
                SendHandshakeChallenge(clientId, version);
                StatusChanged?.Invoke($"Handshake recebido — desafio enviado para extensão {version}");
                return;
            }

            if (type == "authConfirm")
            {
                var version = GetString(doc.RootElement, "version");
                var token = GetString(doc.RootElement, "token");

                if (!_challengeSentClients.ContainsKey(clientId) ||
                    !IsCompatibleExtensionVersion(version) ||
                    !string.Equals(token, _sessionHandshakeToken, StringComparison.Ordinal))
                {
                    StatusChanged?.Invoke("Handshake da extensão recusado — token inválido.");
                    AppLogger.Warn($"extension-bridge-token-rejected: client={clientId}; version={version}");
                    return;
                }

                _authenticatedClients[clientId] = version;

                var msg = $"Extensão conectada e autenticada — versão {version}";
                try { TryLogBridgePlayerStateSummary(msg, "ExtensionBridgeService.StatusChanged"); } catch { }
                StatusChanged?.Invoke(msg);
                AppLogger.Info(msg);
                return;
            }

            if (!_authenticatedClients.ContainsKey(clientId))
            {
                StatusChanged?.Invoke("Mensagem WebSocket ignorada: cliente sem handshake válido.");
                return;
            }

            if (type == "pipManagerNextPreloadDiagnostic")
            {
                var eventName = GetString(doc.RootElement, "event");
                var assetId = GetString(doc.RootElement, "assetId");
                var tabId = GetInt(doc.RootElement, "tabId");
                var readyState = GetInt(doc.RootElement, "readyState");
                var enabled = GetBool(doc.RootElement, "enabled");
                // switchLatencyMs/wasWarm só vêm preenchidos no evento "switch-observed":
                // é aí que sabemos, de fato, se o preload adiantou algo (elemento continuava
                // "quente" quando a troca real aconteceu) e quanto tempo ficou esperando.
                var switchLatencyMs = GetIntOrDefault(doc.RootElement, "switchLatencyMs", -1);
                var suffix = switchLatencyMs >= 0
                    ? $"; switchLatencyMs={switchLatencyMs}; wasWarm={GetBool(doc.RootElement, "wasWarm")}"
                    : string.Empty;
                AppLogger.InfoAggregated($"next-preload:{tabId}:{eventName}:{assetId}", TimeSpan.FromSeconds(5),
                    $"next-preload-{eventName}: enabled={enabled}; tabId={tabId}; assetId={assetId}; readyState={readyState}{suffix}");
                return;
            }


            if (type == "pipManagerContentDiagnostic")
            {
                var version = GetString(doc.RootElement, "version");
                var reason = GetString(doc.RootElement, "reason");
                var tabId = GetInt(doc.RootElement, "tabId");
                var frameId = GetInt(doc.RootElement, "frameId");
                var domain = GetString(doc.RootElement, "domain");
                var title = GetString(doc.RootElement, "title");

                // Content scripts run in the top document and in many iframes. During navigation,
                // AutoNext or AutoReturn, a single snapshot can produce hundreds of diagnostics.
                // These messages are useful for support, but they must never flood the WPF
                // Dispatcher or perform one synchronous file write per frame.
                var nowUnixMs = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
                var key = $"{version}|{tabId}|{frameId}|{domain}|{reason}";
                var lastUnixMs = _lastContentDiagnosticLogUnixMsByKey.TryGetValue(key, out var previous)
                    ? previous
                    : 0;
                var shouldLog = frameId == 0 &&
                    (lastUnixMs <= 0 || nowUnixMs - lastUnixMs >= ContentDiagnosticLogThrottleMs);

                if (shouldLog)
                {
                    _lastContentDiagnosticLogUnixMsByKey[key] = nowUnixMs;
                    var suppressed = Interlocked.Exchange(ref _suppressedContentDiagnosticCount, 0);
                    var msg = $"Content script ativo: versão={version}; reason={reason}; tabId={tabId}; frameId={frameId}; domain={domain}; title={title}; suppressedSinceLast={suppressed}";
                    try { TryLogBridgePlayerStateSummary(msg, "ExtensionBridgeService.ContentDiagnosticThrottled"); } catch { }
                    AppLogger.Info(msg);
                }
                else
                {
                    Interlocked.Increment(ref _suppressedContentDiagnosticCount);
                }

                // Connection state is already represented by the authenticated bridge.
                // Do not post diagnostic chatter to StatusChanged/UI.
                return;
            }

            if (type == "playbackTerminal")
            {
                var info = new VideoPlaybackTerminalInfo
                {
                    Reason = GetString(doc.RootElement, "reason"),
                    VideoSessionId = GetString(doc.RootElement, "videoSessionId"),
                    StableVideoKey = GetString(doc.RootElement, "stableVideoKey"),
                    TabId = GetInt(doc.RootElement, "tabId"),
                    FrameId = GetInt(doc.RootElement, "frameId"),
                    VideoIndex = GetInt(doc.RootElement, "videoIndex"),
                    PageInstanceId = GetString(doc.RootElement, "pageInstanceId"),
                    ElementInstanceId = GetString(doc.RootElement, "elementInstanceId"),
                    Title = GetString(doc.RootElement, "title"),
                    Url = GetString(doc.RootElement, "url"),
                    Domain = GetString(doc.RootElement, "domain"),
                    CurrentTime = GetDouble(doc.RootElement, "currentTime"),
                    Duration = GetDouble(doc.RootElement, "duration"),
                    ReadyState = GetInt(doc.RootElement, "readyState"),
                    IsPaused = GetBool(doc.RootElement, "paused"),
                    IsEnded = GetBool(doc.RootElement, "ended"),
                    HasSource = GetBool(doc.RootElement, "hasSource"),
                    EventUnixMs = GetLong(doc.RootElement, "eventUnixMs")
                };

                PlaybackTerminalReceived?.Invoke(info);
                AppLogger.Warn($"playback-terminal-received: reason={info.Reason}; tabId={info.TabId}; frameId={info.FrameId}; session={info.VideoSessionId}; stable={info.StableVideoKey}; ended={info.IsEnded}; paused={info.IsPaused}; readyState={info.ReadyState}; hasSource={info.HasSource}; title={info.Title}");
                return;
            }

            if (type == "pictureInPictureEvent")
            {
                var info = new VideoPipEventInfo
                {
                    EventName = GetString(doc.RootElement, "eventName"),
                    VideoSessionId = GetString(doc.RootElement, "videoSessionId"),
                    StableVideoKey = GetString(doc.RootElement, "stableVideoKey"),
                    TabId = GetInt(doc.RootElement, "tabId"),
                    FrameId = GetInt(doc.RootElement, "frameId"),
                    PageInstanceId = GetString(doc.RootElement, "pageInstanceId"),
                    ElementInstanceId = GetString(doc.RootElement, "elementInstanceId"),
                    Title = GetString(doc.RootElement, "title"),
                    Url = GetString(doc.RootElement, "url"),
                    Domain = GetString(doc.RootElement, "domain"),
                    CurrentTime = GetDouble(doc.RootElement, "currentTime"),
                    EventUnixMs = GetLong(doc.RootElement, "eventUnixMs")
                };

                PictureInPictureEventReceived?.Invoke(info);
                if (info.IsEnter)
                    StatusChanged?.Invoke($"Evento PiP detectado: {info.ShortDescription}");
                return;
            }

            if (type == "pipAutoReopenAttempt")
            {
                var phase = GetString(doc.RootElement, "phase");
                var ok = GetBool(doc.RootElement, "ok");
                var reason = GetString(doc.RootElement, "reason");
                var method = GetString(doc.RootElement, "method");
                var shortcut = GetString(doc.RootElement, "shortcut");
                var delayMs = GetInt(doc.RootElement, "delayMs");
                var domain = GetString(doc.RootElement, "domain");
                var current = GetDouble(doc.RootElement, "currentTime");

                var detailText = string.Join("; ", new[]
                {
                    string.IsNullOrWhiteSpace(method) ? string.Empty : $"method={method}",
                    string.IsNullOrWhiteSpace(shortcut) ? string.Empty : $"shortcut={shortcut}",
                    string.IsNullOrWhiteSpace(reason) ? string.Empty : $"reason={reason}"
                }.Where(item => !string.IsNullOrWhiteSpace(item)));

                var msg = $"Reabrir PiP pós-Próximo: phase={phase}; ok={ok}; delay={delayMs}ms; domain={domain}; current={current:0.0}" +
                          (string.IsNullOrWhiteSpace(detailText) ? string.Empty : $"; {detailText}");
                try { TryLogBridgePlayerStateSummary(msg, "ExtensionBridgeService.StatusChanged"); } catch { }
                StatusChanged?.Invoke(msg);
                AppLogger.Info(msg);
                return;
            }

            if (type == "commandResult")
            {
                var operationId = GetString(doc.RootElement, "operationId");
                var command = GetString(doc.RootElement, "command");
                var ok = GetBool(doc.RootElement, "ok");
                var tabId = GetInt(doc.RootElement, "tabId");
                var target = GetString(doc.RootElement, "targetVideoSessionId");
                var stable = GetString(doc.RootElement, "targetStableVideoKey");
                var method = GetString(doc.RootElement, "method");
                var reason = GetString(doc.RootElement, "reason");
                var match = GetString(doc.RootElement, "match");
                var targetText = string.IsNullOrWhiteSpace(target + stable)
                    ? string.Empty
                    : $" para {(string.IsNullOrWhiteSpace(stable) ? ShortId(target) : ShortId(stable))}";
                var detailText = string.Join("; ", new[] { method, match, reason }.Where(item => !string.IsNullOrWhiteSpace(item)));
                AppLogger.Info(
                    $"video-command-result-received: operationId={operationId}; command={command}; ok={ok}; tabId={tabId}; " +
                    $"targetSession={target}; targetStable={stable}; method={method}; match={match}; reason={reason}");

                if (ok)
                {
                    StatusChanged?.Invoke($"Comando {command} confirmado pela extensão" + (string.IsNullOrWhiteSpace(detailText) ? string.Empty : $" ({detailText})"));
                }
                else
                {
                    // Falha aqui significa apenas que a extensão não confirmou o alvo/comando.
                    // Em alguns sites o vídeo ainda pode avançar por fallback local, atalho ou ação do player.
                    StatusChanged?.Invoke($"Extensão não confirmou {command}{targetText}" + (string.IsNullOrWhiteSpace(detailText) ? string.Empty : $" — {detailText}"));
                    AppLogger.Warn($"Comando {command} sem confirmação da extensão; target={target}; stable={stable}; method={method}; match={match}; reason={reason}");
                }

                CommandResultReceived?.Invoke(new VideoCommandResultInfo
                {
                    OperationId = operationId,
                    Command = command,
                    Ok = ok,
                    TabId = tabId,
                    Method = method,
                    Reason = reason,
                    Match = match,
                    TargetVideoSessionId = target,
                    TargetStableVideoKey = stable
                });
                return;
            }

            if (type == "tabDiscoveryDiagnostic")
            {
                var requestId = GetString(doc.RootElement, "requestId");
                var totalHttpTabs = GetInt(doc.RootElement, "totalHttpTabs");
                var readyTabs = GetInt(doc.RootElement, "readyTabs");
                var unavailableTabs = GetInt(doc.RootElement, "unavailableTabs");
                var details = new List<string>();
                var discovery = new List<TabDiscoveryInfo>();
                if (doc.RootElement.TryGetProperty("tabs", out var discoveryTabs)
                    && discoveryTabs.ValueKind == JsonValueKind.Array)
                {
                    foreach (var tab in discoveryTabs.EnumerateArray())
                    {
                        var tabId = GetInt(tab, "tabId");
                        var status = GetString(tab, "status");
                        var sessions = GetInt(tab, "sessionCount");
                        var rawVideos = GetInt(tab, "rawVideoCount");
                        if (tabId > 0)
                        {
                            discovery.Add(new TabDiscoveryInfo
                            {
                                TabId = tabId,
                                Status = status,
                                RawVideoCount = rawVideos,
                                SessionCount = sessions
                            });
                        }

                        if (!string.Equals(status, "video-ready", StringComparison.OrdinalIgnoreCase))
                            details.Add($"tab={tabId}:{status}:raw={rawVideos}:sessions={sessions}");
                    }
                }

                AppLogger.Info(
                    $"extension-tab-discovery: totalHttpTabs={totalHttpTabs}; readyTabs={readyTabs}; " +
                    $"unavailableTabs={unavailableTabs}; missing={Math.Max(0, totalHttpTabs - readyTabs)}; " +
                    $"details={(details.Count == 0 ? "none" : string.Join(",", details.Take(12)))}");
                TabDiscoveryUpdated?.Invoke(requestId, discovery);
                return;
            }

            if (type == "silentDiagnostic")
            {
                var eventName = GetString(doc.RootElement, "event");
                var attemptId = GetString(doc.RootElement, "attemptId");
                var silent = GetBool(doc.RootElement, "silent");
                var ok = GetBool(doc.RootElement, "ok");
                var result = GetString(doc.RootElement, "result");
                var reasonCode = GetString(doc.RootElement, "reasonCode");
                var reason = GetString(doc.RootElement, "reason");
                var reasonMessage = GetString(doc.RootElement, "reasonMessage");
                var method = GetString(doc.RootElement, "method");
                var match = GetString(doc.RootElement, "match");
                var strategy = GetString(doc.RootElement, "strategy");
                var targetStrategy = GetString(doc.RootElement, "targetStrategy");
                var tabId = GetInt(doc.RootElement, "tabId");
                var attempt = GetInt(doc.RootElement, "attempt");
                var found = GetBool(doc.RootElement, "found");
                var requestAttempted = GetBool(doc.RootElement, "requestAttempted");
                var enterPipSeen = GetBool(doc.RootElement, "enterPipSeen");
                var title = GetString(doc.RootElement, "title");
                var domain = GetString(doc.RootElement, "domain");
                var videoIndex = GetInt(doc.RootElement, "videoIndex");
                var currentTime = GetDouble(doc.RootElement, "currentTime");
                var duration = GetDouble(doc.RootElement, "duration");

                var diagnosticsText = string.Empty;
                if (doc.RootElement.TryGetProperty("diagnostics", out var diag) && diag.ValueKind == JsonValueKind.Object)
                {
                    var readyState = GetInt(diag, "readyState");
                    var paused = GetBool(diag, "paused");
                    var pipEnabled = GetBool(diag, "pipEnabled");
                    var alreadyInPip = GetBool(diag, "inPictureInPicture");
                    var canRequest = GetBool(diag, "canRequest");
                    var disablePip = GetBool(diag, "disablePictureInPicture");
                    var width = GetInt(diag, "width");
                    var height = GetInt(diag, "height");
                    var ended = GetBool(diag, "ended");
                    var muted = GetBool(diag, "muted");
                    diagnosticsText = $"; readyState={readyState}; paused={paused}; ended={ended}; muted={muted}; pipEnabled={pipEnabled}; alreadyInPip={alreadyInPip}; canRequest={canRequest}; disablePip={disablePip}; size={width}x{height}";
                }

                var enterText = string.Empty;
                if (doc.RootElement.TryGetProperty("enter", out var enter) && enter.ValueKind == JsonValueKind.Object)
                {
                    var enterOk = GetBool(enter, "ok");
                    var enterMethod = GetString(enter, "method");
                    var enterCode = GetString(enter, "reasonCode");
                    enterText = $"; enterOk={enterOk}; enterMethod={enterMethod}; enterReasonCode={enterCode}";
                }

                                var frameId = GetInt(doc.RootElement, "frameId");
                var contentVersion = GetString(doc.RootElement, "contentVersion");
                var expectedContentVersion = GetString(doc.RootElement, "expectedContentVersion");
                var hasReacquireBestVisible = GetBool(doc.RootElement, "hasReacquireBestVisible");
                var hasUserActivation = GetBool(doc.RootElement, "hasUserActivation");
                var isActiveUserActivation = GetBool(doc.RootElement, "isActiveUserActivation");
                var documentPictureInPicture = GetBool(doc.RootElement, "documentPictureInPicture");

                                {
                    var __silentDiagnosticLine49_0 = $"silent-diagnostic: event={eventName}; attemptId={attemptId}; silent={silent}; attempt={attempt}; ok={ok}; result={result}; found={found}; requestAttempted={requestAttempted}; enterPipSeen={enterPipSeen}; reasonCode={reasonCode}; reason={reason}; reasonMessage={reasonMessage}; method={method}; match={match}; strategy={strategy}; targetStrategy={targetStrategy}; tabId={tabId}; frameId={frameId}; domain={domain}; title={title}; videoIndex={videoIndex}; currentTime={currentTime:0.###}; duration={duration:0.###}; contentVersion={contentVersion}; expectedContentVersion={expectedContentVersion}; hasReacquireBestVisible={hasReacquireBestVisible}; hasUserActivation={hasUserActivation}; isActiveUserActivation={isActiveUserActivation}; documentPictureInPicture={documentPictureInPicture}{diagnosticsText}{enterText}";
                    try { TryLogDirectSilentDiagnosticPlayerStateSummary(__silentDiagnosticLine49_0, "direct-AppLogger.Info-wrapper"); } catch { }
                    if (string.Equals(eventName, "pip-preserve-ws-raw-message-received-block52", StringComparison.OrdinalIgnoreCase)
                        && !silent
                        && string.IsNullOrWhiteSpace(attemptId))
                    {
                        AppLogger.InfoAggregated("silent-diagnostic-raw-nonsilent", TimeSpan.FromSeconds(3), __silentDiagnosticLine49_0);
                    }
                    else
                    {
                        AppLogger.Info(__silentDiagnosticLine49_0);
                    }
                }

                if (string.Equals(eventName, "pip-preserve-silent-preflight-result", StringComparison.OrdinalIgnoreCase))
                {
                    StatusChanged?.Invoke($"SilentPreflight attemptId={attemptId}; ok={ok}; result={result}; reasonCode={reasonCode}; reasonMessage={reasonMessage}; domain={domain}; tabId={tabId}; frameId={frameId}");
                }

                return;
            }

            if (type == "openPipResult")
            {
                var ok = GetBool(doc.RootElement, "ok");
                var method = GetString(doc.RootElement, "method");
                var reason = GetString(doc.RootElement, "reason");
                var reasonCode = GetString(doc.RootElement, "reasonCode");
                var title = GetString(doc.RootElement, "title");
                var silent = GetBool(doc.RootElement, "silent");
                var attemptId = GetString(doc.RootElement, "attemptId");
                var match = GetString(doc.RootElement, "match");
                var targetStrategy = GetString(doc.RootElement, "targetStrategy");
                var tabId = GetInt(doc.RootElement, "tabId");
                var frameId = GetInt(doc.RootElement, "frameId");
                var contentVersion = GetString(doc.RootElement, "contentVersion");
                var enterPipSeen = GetBool(doc.RootElement, "enterPipSeen");
                var attemptsCount = doc.RootElement.TryGetProperty("attempts", out var attemptsElement) && attemptsElement.ValueKind == JsonValueKind.Array
                    ? attemptsElement.GetArrayLength()
                    : 0;
                var candidatesCount = doc.RootElement.TryGetProperty("candidates", out var candidatesElement) && candidatesElement.ValueKind == JsonValueKind.Array
                    ? candidatesElement.GetArrayLength()
                    : 0;

                AppLogger.Info($"openPipResult: silent={silent}; attemptId={attemptId}; ok={ok}; reasonCode={reasonCode}; reason={reason}; method={method}; match={match}; targetStrategy={targetStrategy}; tabId={tabId}; title={title}; frameId={frameId}; contentVersion={contentVersion}; enterPipSeen={enterPipSeen}; attempts={attemptsCount}; candidates={candidatesCount}");

                var prefix = silent ? "Silencioso" : "Extensão";
                StatusChanged?.Invoke(ok
                    ? $"{prefix} abriu PiP para {(string.IsNullOrWhiteSpace(title) ? "vídeo selecionado" : title)} ({method})"
                    : $"{prefix} não confirmou PiP"
                        + (string.IsNullOrWhiteSpace(reasonCode) ? string.Empty : $" [{reasonCode}]")
                        + (string.IsNullOrWhiteSpace(reason) ? string.Empty : $" — {reason}"));
                return;
            }

            if (type != "videoSessionsSnapshot" && type != "videoTabsSnapshot")
                return;

            JsonElement tabsElement;
            if (doc.RootElement.TryGetProperty("sessions", out var sessionsElement) && sessionsElement.ValueKind == JsonValueKind.Array)
                tabsElement = sessionsElement;
            else if (doc.RootElement.TryGetProperty("tabs", out var legacyTabsElement) && legacyTabsElement.ValueKind == JsonValueKind.Array)
                tabsElement = legacyTabsElement;
            else
                return;

            var tabs = new List<VideoTabInfo>();
            foreach (var item in tabsElement.EnumerateArray())
            {
                var tabId = GetInt(item, "tabId");
                if (tabId <= 0) continue;
                var videoIndex = GetInt(item, "videoIndex");
                var sessionId = GetString(item, "videoSessionId");
                if (string.IsNullOrWhiteSpace(sessionId))
                    sessionId = $"tab-{tabId}-video-{videoIndex}";

                tabs.Add(new VideoTabInfo
                {
                    VideoSessionId = sessionId,
                    StableVideoKey = GetString(item, "stableVideoKey"),
                    TabId = tabId,
                    BrowserWindowId = GetInt(item, "windowId"),
                    FrameId = GetInt(item, "frameId"),
                    VideoIndex = videoIndex,
                    DomIndex = GetInt(item, "domIndex"),
                    VisualRank = GetInt(item, "visualRank"),
                    PageInstanceId = GetString(item, "pageInstanceId"),
                    ElementInstanceId = GetString(item, "elementInstanceId"),
                    Title = GetString(item, "title"),
                    Url = GetString(item, "url"),
                    Domain = GetString(item, "domain"),
                    VideoCount = GetInt(item, "videoCount"),
                    IntrinsicVideoWidth = GetInt(item, "intrinsicVideoWidth"),
                    IntrinsicVideoHeight = GetInt(item, "intrinsicVideoHeight"),
                    IsPlaying = GetBool(item, "isPlaying"),
                    ReadyState = GetInt(item, "readyState"),
                    IsPaused = GetBool(item, "paused"),
                    IsEnded = GetBool(item, "ended"),
                    HasSource = GetBool(item, "hasSource"),
                    IsActiveTab = GetBool(item, "isActiveTab"),
                    CurrentTime = GetDouble(item, "currentTime"),
                    Duration = GetDouble(item, "duration"),
                    PlaylistDetected = GetBool(item, "playlistDetected"),
                    SiteProfileId = GetString(item, "siteProfileId"),
                    SiteContentKind = GetString(item, "siteContentKind"),
                    SiteNextStrategy = GetString(item, "siteNextStrategy"),
                    PlaylistTitle = GetString(item, "playlistTitle"),
                    PlaylistIndex = GetIntOrDefault(item, "playlistIndex", -1),
                    CurrentItemTitle = GetString(item, "currentItemTitle"),
                    NextTitles = GetStringList(item, "nextTitles"),
                    NextPreviewTitle = GetString(item, "nextPreviewTitle"),
                    NextPreviewThumbnailUrl = GetString(item, "nextPreviewThumbnailUrl"),
                    NextPreviewVideoUrl = GetString(item, "nextPreviewVideoUrl"),
                    NextPreviewDuration = GetString(item, "nextPreviewDuration"),
                    NextPreviewIndex = GetIntOrDefault(item, "nextPreviewIndex", -1),
                    LastSeenUnixMs = GetLong(item, "lastSeenUnixMs")
                });
            }

            VideoTabsUpdated?.Invoke(tabs
                .OrderByDescending(tab => tab.IsPlaying)
                .ThenByDescending(tab => tab.IsActiveTab)
                .ThenBy(tab => tab.Domain)
                .ThenBy(tab => tab.VideoIndex)
                .ToList());
        }
        catch (Exception ex)
        {
            StatusChanged?.Invoke($"Mensagem inválida da extensão: {ex.Message}");
        }
    }

    private static string GetString(JsonElement element, string property)
        => ExtensionProtocolReader.GetString(element, property);

    private static int GetInt(JsonElement element, string property)
        => ExtensionProtocolReader.GetInt(element, property);

    private static int GetIntOrDefault(JsonElement element, string property, int defaultValue)
        => ExtensionProtocolReader.GetInt(element, property, defaultValue);

    private static IReadOnlyList<string> GetStringList(JsonElement element, string property)
        => ExtensionProtocolReader.GetStringList(element, property);

    private static double GetDouble(JsonElement element, string property)
        => ExtensionProtocolReader.GetDouble(element, property);

    private static long GetLong(JsonElement element, string property)
        => ExtensionProtocolReader.GetLong(element, property);

    private static bool GetBool(JsonElement element, string property)
        => ExtensionProtocolReader.GetBool(element, property);

    private async Task<int> SendTextToOpenClientsAsync(string text)
    {
        var data = Encoding.UTF8.GetBytes(text);
        var sent = 0;

        await _sendGate.WaitAsync().ConfigureAwait(false);
        try
        {
        foreach (var pair in _clients.ToArray())
        {
            var socket = pair.Value;

            if (!_authenticatedClients.ContainsKey(pair.Key))
                continue;

            if (socket.State != WebSocketState.Open)
            {
                _clients.TryRemove(pair.Key, out _);
                _authenticatedClients.TryRemove(pair.Key, out _);
                _challengeSentClients.TryRemove(pair.Key, out _);
                continue;
            }

            try
            {
                await socket.SendAsync(data, WebSocketMessageType.Text, endOfMessage: true, CancellationToken.None).ConfigureAwait(false);
                sent++;
            }
            catch
            {
                _clients.TryRemove(pair.Key, out _);
                _authenticatedClients.TryRemove(pair.Key, out _);
            }
        }
        }
        finally
        {
            _sendGate.Release();
        }

        return sent;
    }

    public void Dispose()
    {
        try { _cts?.Cancel(); } catch { }
        try { if (_listener.IsListening) _listener.Stop(); } catch { }
        try { _listener.Close(); } catch { }

        foreach (var pair in _clients.ToArray())
        {
            _clients.TryRemove(pair.Key, out _);
            try { pair.Value.Dispose(); } catch { }
        }

        _cts?.Dispose();
        _cts = null;
    }


        private string ExtractBridgeValue(string text, string key)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(text) || string.IsNullOrWhiteSpace(key))
                    return string.Empty;

                var pattern = key + "=";
                var index = text.IndexOf(pattern, StringComparison.OrdinalIgnoreCase);
                if (index < 0)
                    return string.Empty;

                index += pattern.Length;
                var end = text.IndexOf(';', index);
                if (end < 0)
                    end = text.Length;

                return text.Substring(index, end - index).Trim();
            }
            catch
            {
                return string.Empty;
            }
        }

        private bool ParseBridgeBool(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return false;

            return value.Equals("true", StringComparison.OrdinalIgnoreCase)
                || value.Equals("1", StringComparison.OrdinalIgnoreCase)
                || value.Equals("yes", StringComparison.OrdinalIgnoreCase)
                || value.Equals("sim", StringComparison.OrdinalIgnoreCase);
        }

        private int ParseBridgeInt(string value, int fallback = 0)
        {
            if (int.TryParse(value, out var parsed))
                return parsed;
            return fallback;
        }

        private double ParseBridgeDouble(string value, double fallback = 0)
        {
            if (double.TryParse(value, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out var parsed))
                return parsed;

            if (double.TryParse(value, out parsed))
                return parsed;

            return fallback;
        }

        private void TryLogBridgePlayerStateSummary(string text, string source)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(text))
                    return;

                if (!text.Contains("event=pip-preserve-silent-player-state", StringComparison.OrdinalIgnoreCase))
                    return;

                var attemptId = ExtractBridgeValue(text, "attemptId");
                var tabId = ParseBridgeInt(ExtractBridgeValue(text, "tabId"));
                var frameId = ParseBridgeInt(ExtractBridgeValue(text, "frameId"));
                var domain = ExtractBridgeValue(text, "domain");
                var title = ExtractBridgeValue(text, "title");
                var videoIndex = ParseBridgeInt(ExtractBridgeValue(text, "videoIndex"));
                var result = ExtractBridgeValue(text, "result");
                var reasonCode = ExtractBridgeValue(text, "reasonCode");
                var match = ExtractBridgeValue(text, "match");
                var targetStrategy = ExtractBridgeValue(text, "targetStrategy");
                var contentVersion = ExtractBridgeValue(text, "contentVersion");
                var readyState = ParseBridgeInt(ExtractBridgeValue(text, "readyState"));
                var paused = ParseBridgeBool(ExtractBridgeValue(text, "paused"));
                var ended = ParseBridgeBool(ExtractBridgeValue(text, "ended"));
                var muted = ParseBridgeBool(ExtractBridgeValue(text, "muted"));
                var pipEnabled = ParseBridgeBool(ExtractBridgeValue(text, "pipEnabled"));
                var alreadyInPip = ParseBridgeBool(ExtractBridgeValue(text, "alreadyInPip"));
                var canRequest = ParseBridgeBool(ExtractBridgeValue(text, "canRequest"));
                var disablePip = ParseBridgeBool(ExtractBridgeValue(text, "disablePip"));
                var found = ParseBridgeBool(ExtractBridgeValue(text, "found"));
                var size = ExtractBridgeValue(text, "size");
                var currentTime = ParseBridgeDouble(ExtractBridgeValue(text, "currentTime"));
                var duration = ParseBridgeDouble(ExtractBridgeValue(text, "duration"));

                var framesAnswered = 1;
                var framesWithVideo = found ? 1 : 0;
                var videoCount = found ? 1 : 0;
                var requestableFrames = canRequest ? 1 : 0;
                var requestableVideos = canRequest ? 1 : 0;

                var bestScore = 0;
                if (found) bestScore += 100;
                if (canRequest) bestScore += 60;
                if (pipEnabled) bestScore += 25;
                if (readyState >= 1) bestScore += 10;
                if (ended) bestScore -= 80;

                var wrongFrameSuspected = false;

                AppLogger.Info(
                    $"pip-preserve-silent-multiframe-bridge-playerstate-frame-result: " +
                    $"attemptId={attemptId}; source={source}; tabId={tabId}; frameId={frameId}; domain={domain}; title={title}; " +
                    $"result=derived-from-player-state; originalResult={result}; reasonCode={reasonCode}; " +
                    $"match={match}; targetStrategy={targetStrategy}; videoIndex={videoIndex}; " +
                    $"score={bestScore}; found={found}; readyState={readyState}; paused={paused}; ended={ended}; muted={muted}; " +
                    $"pipEnabled={pipEnabled}; alreadyInPip={alreadyInPip}; canRequest={canRequest}; disablePip={disablePip}; " +
                    $"size={size}; currentTime={currentTime}; duration={duration}; contentVersion={contentVersion}");

                AppLogger.Info(
                    $"pip-preserve-silent-multiframe-bridge-playerstate-summary: " +
                    $"attemptId={attemptId}; source={source}; tabId={tabId}; frameId={frameId}; domain={domain}; " +
                    $"framesAnswered={framesAnswered}; framesWithVideo={framesWithVideo}; requestableFrames={requestableFrames}; " +
                    $"requestableVideos={requestableVideos}; wrongFrameSuspected={wrongFrameSuspected}; videoCount={videoCount}; " +
                    $"bestIndex={videoIndex}; bestScore={bestScore}; bestCanRequest={canRequest}; bestPipEnabled={pipEnabled}; " +
                    $"bestReadyState={readyState}; targetIndex={videoIndex}; targetScore={bestScore}; " +
                    $"reasonCode={reasonCode}; contentVersion={contentVersion}");
            }
            catch (Exception ex)
            {
                AppLogger.Warn($"pip-preserve-silent-multiframe-bridge-playerstate-summary-failed: source={source}; error={ex.Message}");
            }
        }




        private void TryLogDirectSilentDiagnosticPlayerStateSummary(string text, string source)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(text))
                    return;

                if (!text.Contains("silent-diagnostic:", StringComparison.OrdinalIgnoreCase))
                    return;

                if (!text.Contains("event=pip-preserve-silent-player-state", StringComparison.OrdinalIgnoreCase))
                    return;

                var attemptId = ExtractBridgeValue(text, "attemptId");
                var tabId = ParseBridgeInt(ExtractBridgeValue(text, "tabId"));
                var frameId = ParseBridgeInt(ExtractBridgeValue(text, "frameId"));
                var domain = ExtractBridgeValue(text, "domain");
                var title = ExtractBridgeValue(text, "title");
                var videoIndex = ParseBridgeInt(ExtractBridgeValue(text, "videoIndex"));
                var result = ExtractBridgeValue(text, "result");
                var reasonCode = ExtractBridgeValue(text, "reasonCode");
                var match = ExtractBridgeValue(text, "match");
                var targetStrategy = ExtractBridgeValue(text, "targetStrategy");
                var contentVersion = ExtractBridgeValue(text, "contentVersion");
                var readyState = ParseBridgeInt(ExtractBridgeValue(text, "readyState"));
                var paused = ParseBridgeBool(ExtractBridgeValue(text, "paused"));
                var ended = ParseBridgeBool(ExtractBridgeValue(text, "ended"));
                var muted = ParseBridgeBool(ExtractBridgeValue(text, "muted"));
                var pipEnabled = ParseBridgeBool(ExtractBridgeValue(text, "pipEnabled"));
                var alreadyInPip = ParseBridgeBool(ExtractBridgeValue(text, "alreadyInPip"));
                var canRequest = ParseBridgeBool(ExtractBridgeValue(text, "canRequest"));
                var disablePip = ParseBridgeBool(ExtractBridgeValue(text, "disablePip"));
                var found = ParseBridgeBool(ExtractBridgeValue(text, "found"));
                var size = ExtractBridgeValue(text, "size");
                var currentTime = ParseBridgeDouble(ExtractBridgeValue(text, "currentTime"));
                var duration = ParseBridgeDouble(ExtractBridgeValue(text, "duration"));

                var framesAnswered = 1;
                var framesWithVideo = found ? 1 : 0;
                var videoCount = found ? 1 : 0;
                var requestableFrames = canRequest ? 1 : 0;
                var requestableVideos = canRequest ? 1 : 0;

                var bestScore = 0;
                if (found) bestScore += 100;
                if (canRequest) bestScore += 60;
                if (pipEnabled) bestScore += 25;
                if (readyState >= 1) bestScore += 10;
                if (ended) bestScore -= 80;

                var wrongFrameSuspected = false;

                AppLogger.Info(
                    $"pip-preserve-silent-multiframe-directlog-playerstate-frame-result: " +
                    $"attemptId={attemptId}; source={source}; tabId={tabId}; frameId={frameId}; domain={domain}; title={title}; " +
                    $"result=derived-from-direct-silent-diagnostic-log; originalResult={result}; reasonCode={reasonCode}; " +
                    $"match={match}; targetStrategy={targetStrategy}; videoIndex={videoIndex}; " +
                    $"score={bestScore}; found={found}; readyState={readyState}; paused={paused}; ended={ended}; muted={muted}; " +
                    $"pipEnabled={pipEnabled}; alreadyInPip={alreadyInPip}; canRequest={canRequest}; disablePip={disablePip}; " +
                    $"size={size}; currentTime={currentTime}; duration={duration}; contentVersion={contentVersion}");

                AppLogger.Info(
                    $"pip-preserve-silent-multiframe-directlog-playerstate-summary: " +
                    $"attemptId={attemptId}; source={source}; tabId={tabId}; frameId={frameId}; domain={domain}; " +
                    $"framesAnswered={framesAnswered}; framesWithVideo={framesWithVideo}; requestableFrames={requestableFrames}; " +
                    $"requestableVideos={requestableVideos}; wrongFrameSuspected={wrongFrameSuspected}; videoCount={videoCount}; " +
                    $"bestIndex={videoIndex}; bestScore={bestScore}; bestCanRequest={canRequest}; bestPipEnabled={pipEnabled}; " +
                    $"bestReadyState={readyState}; targetIndex={videoIndex}; targetScore={bestScore}; " +
                    $"reasonCode={reasonCode}; contentVersion={contentVersion}");
                try
                {
                    TriggerCSharpMultiFrameProbeFromPlayerStateBlock411(text, "block411-csharp-trigger-after-directlog-summary");
                }
                catch { }

            }
            catch (Exception ex)
            {
                AppLogger.Warn($"pip-preserve-silent-multiframe-directlog-playerstate-summary-failed: source={source}; error={ex.Message}");
            }
        }




        private void TriggerCSharpMultiFrameProbeFromPlayerStateBlock411(string text, string source)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(text))
                    return;

                if (!text.Contains("event=pip-preserve-silent-player-state", StringComparison.OrdinalIgnoreCase))
                    return;

                var sourceAttemptId = ExtractBridgeValue(text, "attemptId");
                if (string.IsNullOrWhiteSpace(sourceAttemptId))
                    sourceAttemptId = $"preflight-unknown-{DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()}";

                if (!_block411CSharpProbeAttemptIds.TryAdd(sourceAttemptId, 1))
                {
                    AppLogger.Info($"pip-preserve-silent-multiframe-csharp-trigger-deduped: sourceAttemptId={sourceAttemptId}; source={source}");
                    return;
                }

                var tabId = ParseBridgeInt(ExtractBridgeValue(text, "tabId"));
                var videoIndex = ParseBridgeInt(ExtractBridgeValue(text, "videoIndex"));
                var targetVideoSessionId = ExtractBridgeValue(text, "targetVideoSessionId");
                var targetStableVideoKey = ExtractBridgeValue(text, "targetStableVideoKey");

                // Alguns player-state atuais não carregam explicitamente targetVideoSessionId/targetStableVideoKey.
                // Nesses casos, o background ainda consegue usar videoIndex/fallback, mas logamos a ausência.
                var probeAttemptId = $"mf411-{sourceAttemptId}";

                var payload = System.Text.Json.JsonSerializer.Serialize(new
                {
                    type = "silentMultiFrameProbe",
                    targetVideoSessionId,
                    targetStableVideoKey,
                    targetTabId = tabId,
                    tabId,
                    videoIndex,
                    attemptId = probeAttemptId,
                    sourceAttemptId,
                    source = "csharp-directlog-playerstate",
                    ts = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()
                });
                AppLogger.Info(
                    $"pip-preserve-silent-multiframe-csharp-trigger-payload-block52: " +
                    $"sourceAttemptId={sourceAttemptId}; tabId={tabId}; videoIndex={videoIndex}; " +
                    $"payloadLength={payload.Length}; hasSession={!string.IsNullOrWhiteSpace(targetVideoSessionId)}; hasStable={!string.IsNullOrWhiteSpace(targetStableVideoKey)}");


                _ = Task.Run(async () =>
                {
                    try
                    {
                        var clients = await SendTextToOpenClientsAsync(payload).ConfigureAwait(false);
                        AppLogger.Info(
                            $"pip-preserve-silent-multiframe-csharp-trigger-sent: " +
                            $"attemptId={probeAttemptId}; sourceAttemptId={sourceAttemptId}; tabId={tabId}; videoIndex={videoIndex}; " +
                            $"clients={clients}; hasSession={!string.IsNullOrWhiteSpace(targetVideoSessionId)}; hasStable={!string.IsNullOrWhiteSpace(targetStableVideoKey)}; source={source}");
                    }
                    catch (Exception ex)
                    {
                        AppLogger.Warn(
                            $"pip-preserve-silent-multiframe-csharp-trigger-send-failed: " +
                            $"attemptId={probeAttemptId}; sourceAttemptId={sourceAttemptId}; tabId={tabId}; error={ex.Message}; source={source}");
                    }
                });
            }
            catch (Exception ex)
            {
                AppLogger.Warn($"pip-preserve-silent-multiframe-csharp-trigger-failed: source={source}; error={ex.Message}");
            }
        }


}
