﻿@echo off
echo Compilando pipmanagerV1_extension_pairing_corefix_step1_extension_preparepip_pairing_extension_openpip_pairing...
cd /d "%~dp0"

echo Building native layout engine...
call BUILD_NATIVE_WINDOWS.bat
if errorlevel 1 (
  echo.
  echo BUILD_ABORTED: Native layout engine build failed.
  pause
  exit /b 1
)

echo Running Core tests before publish...
call RUN_CORE_TESTS.bat --ci
if errorlevel 1 (
  echo.
  echo BUILD_ABORTED: Core tests failed.
  pause
  exit /b 1
)

echo Compilando pipmanagerV1_extension_pairing_corefix_step1_extension_preparepip_pairing_ws_extension_phase2_strong...
dotnet publish src\PiPManager.Wpf\PiPManager.Wpf.csproj -c Release -r win-x64 --self-contained true
if errorlevel 1 (
    echo.
    echo ERRO: A compilacao falhou.
    pause
    exit /b 1
)
echo.
echo Build concluido.
echo Saida: src\PiPManager.Wpf\bin\Release\net8.0-windows\win-x64\publish\PiPManager.Wpf.exe
pause


echo.
echo Creating clean DIST release package...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0CREATE_DIST_RELEASE.ps1"
if errorlevel 1 (
  echo.
  echo WARNING: DIST package generation failed.
)
