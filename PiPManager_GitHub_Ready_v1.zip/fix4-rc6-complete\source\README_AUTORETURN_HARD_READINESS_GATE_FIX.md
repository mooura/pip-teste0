# AutoReturn Hard Readiness Gate Fix

Base: PiPManager 9.39.01 FINAL STABLE MOVE GROUP FIX.

## Problema confirmado pelo log

O caminho `same-video-reopen` considerava o alvo pronto sem validar `readyState`.
Quando o player estava em `HAVE_NOTHING` (`readyState=0`), o programa enviava dois
atalhos físicos, não encontrava um novo HWND e consumia o backoff. O PiP só era
recuperado depois que o site disponibilizava um vídeo real.

## Correção

- `readyState=0` bloqueia inicialmente a tentativa física.
- A RC2 permite uma exceção limitada somente após duas amostras novas e
  consecutivas com `playing=true`, source válido e `ended=false`.
- Ausência de source ou `ended=true` continuam bloqueando qualquer tentativa.
- O AutoReturn continua observando o player e tenta novamente a cada 900 ms.
- Espera por readiness não aumenta o backoff de falha física.
- O caminho rápido do mesmo vídeo permanece disponível a partir de metadata (`readyState>=1`).
- O fallback limitado para estados parcialmente carregados foi preservado.
- Layout, arraste, interface, extensão, pareamento e áudio não foram alterados.
