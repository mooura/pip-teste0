﻿$ErrorActionPreference = "Stop"
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$main = Get-Content -Raw (Join-Path $root 'src\PiPManager.Wpf\MainWindow.xaml.cs')
$policy = Get-Content -Raw (Join-Path $root 'src\PiPManager.Core\Core\Automation\AutoReturnBurstPolicy.cs')
$tests = Get-Content -Raw (Join-Path $root 'tests\PiPManager.Core.Tests\Program.cs')
$run = Get-Content -Raw (Join-Path $root 'RUN_CORE_TESTS.bat')

$waitStart = $main.IndexOf('private async Task<(VideoTabInfo Tab, bool Ready)> WaitForAutoReturnTargetPlaybackReadyAsync(')
$waitEnd = if ($waitStart -ge 0) { $main.IndexOf('private VideoTabInfo? FindAutoReturnCandidate(', $waitStart) } else { -1 }
$waitMethod = if ($waitStart -ge 0 -and $waitEnd -gt $waitStart) { $main.Substring($waitStart, $waitEnd - $waitStart) } else { '' }

$checks = [ordered]@{
  'hard readiness policy exists' = $policy.Contains('IsPlaybackHardNotReady') -and $policy.Contains('readyState <= 0')
  'same-video path blocks HAVE_NOTHING' = $waitMethod.Contains('(!realChange && !hardNotReady)') -and $waitMethod.Contains('IsAutoReturnTargetHardNotReady')
  'passive playing exception requires fresh proof' = $policy.Contains('HasConfirmedActivePlayback') -and $policy.Contains('consecutiveFreshSamples >= Math.Max(2, requiredFreshSamples)') -and $waitMethod.Contains('auto-return-target-ready-passive-playing-confirmed')
  'identity is recomputed while waiting' = $waitMethod.Contains('realChange = IsRealAutoReturnVideoChange(state, tab);')
  'hard not ready keeps deferring' = $policy.Contains('hardNotReady || readinessDeferrals') -and $main.Contains('ShouldDeferPhysicalAttemptForReadiness')
  'readiness does not consume physical backoff' = $main.Contains('SetAutoReturnReadinessCooldown') -and $main.Contains('physicalRetryBackoffPreserved')
  'hard readiness retry is not a tight loop' = $policy.Contains('hardNotReady ? 900 : 500')
  'core regression covers HAVE_NOTHING' = $tests.Contains('HAVE_NOTHING must block a physical AutoReturn shortcut')
  'core regression covers two fresh samples' = $tests.Contains('two fresh playing/source samples must prove active playback')
  'checker included in core gate' = $run.Contains('CHECK_AUTORETURN_HARD_READINESS_GATE.ps1')
}

$failed = @()
foreach ($item in $checks.GetEnumerator()) {
  if ($item.Value) { Write-Host ($item.Key + ': OK') }
  else { Write-Host ($item.Key + ': FAIL'); $failed += $item.Key }
}
if ($failed.Count -gt 0) { throw "AutoReturn hard readiness checks failed: $($failed -join ', ')" }
Write-Host 'AutoReturn hard readiness gate checks OK.'
