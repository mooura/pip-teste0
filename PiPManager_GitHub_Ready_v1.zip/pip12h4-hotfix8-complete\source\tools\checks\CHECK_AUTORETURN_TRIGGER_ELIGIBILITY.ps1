$ErrorActionPreference = "Stop"
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$main = Get-Content (Join-Path $root "src\PiPManager.Wpf\MainWindow.xaml.cs") -Raw
$coreTests = Get-Content (Join-Path $root "RUN_CORE_TESTS.bat") -Raw
$checks = [ordered]@{
  "state records real-change requirement" = $main.Contains("RequiresRealVideoChange")
  "normal close mode" = $main.Contains('eligibilityMode = "same-video-reopen"')
  "navigation correlated mode" = $main.Contains('"video-navigation-real-change-correlated"')
  "navigation observed mode" = $main.Contains('"video-navigation-real-change-observed"')
  "navigation mode selected by evidence" = $main.Contains('hasObservedNavigationEvidence') -and $main.Contains('? "video-navigation-real-change-observed"') -and $main.Contains(': "video-navigation-real-change-correlated"')
  "navigation checks preservation command" = $main.Contains('preservation.CommandType, "next"') -and $main.Contains('preservation.CommandType, "previous"')
  "same video bypasses real-change filter" = $main.Contains('state.RequiresRealVideoChange && !allowPlaylistSameVideoFallback') -and $main.Contains('? freshTabs.Where(tab => IsRealAutoReturnVideoChange(state, tab)).ToList()')
  "playlist same-video fallback is bounded" = $main.Contains("AutoReturnPlaylistSameVideoFallbackMs = 2200") -and $main.Contains("auto-return-playlist-same-video-fallback")
  "same video readiness log" = $main.Contains("auto-return-same-video-reopen-ready")
  "real change waiting retained" = $main.Contains("auto-return-waiting-real-change")
  "identity prioritization" = $main.Contains("AutoReturnIdentityMatchScore")
  "checker included in core gate" = $coreTests.Contains("CHECK_AUTORETURN_TRIGGER_ELIGIBILITY.ps1")
}
$failed = @($checks.GetEnumerator() | Where-Object { -not $_.Value })
$checks.GetEnumerator() | ForEach-Object { "{0}: {1}" -f $_.Key, $(if ($_.Value) {"OK"} else {"FAIL"}) }
if ($failed.Count -gt 0) { throw "AutoReturn trigger eligibility checks failed." }
"AutoReturn trigger eligibility checks OK."
