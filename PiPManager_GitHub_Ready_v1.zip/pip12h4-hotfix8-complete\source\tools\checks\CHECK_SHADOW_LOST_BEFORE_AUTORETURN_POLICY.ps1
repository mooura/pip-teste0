$ErrorActionPreference = "Stop"
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$main = Get-Content (Join-Path $root "src\PiPManager.Wpf\MainWindow.xaml.cs") -Raw

$methodStart = $main.IndexOf("private void MarkAutoReturnPending")
if ($methodStart -lt 0) {
  throw "MarkAutoReturnPending not found"
}

$methodEnd = $main.IndexOf("private async Task AutoReturnTickAsync", $methodStart)
if ($methodEnd -lt 0) {
  throw "AutoReturnTickAsync anchor not found"
}

$method = $main.Substring($methodStart, $methodEnd - $methodStart)

$shadowIndex = $method.IndexOf("ShadowMirrorPipLost(slot, slot.Window.Handle, ""MarkAutoReturnPending/loss-before-policy/")
$policyIndex = $method.IndexOf("ShouldAutoReturnSlot(slot, $""pending:{reason}""")

if ($shadowIndex -lt 0) {
  throw "Shadow loss before policy marker missing"
}

if ($policyIndex -lt 0) {
  throw "AutoReturn policy check missing"
}

if ($shadowIndex -gt $policyIndex) {
  throw "Shadow loss must be recorded before AutoReturn policy check"
}

$lateLegacy = $method.IndexOf("ShadowMirrorPipLost(slot, slot.Window.Handle, ""MarkAutoReturnPending/"" + reason)")
if ($lateLegacy -ge 0) {
  throw "Legacy late ShadowMirrorPipLost call still present"
}

Write-Host "Shadow lost before AutoReturn policy checks OK."
