﻿using System;
using PiPManager.Core.Slots;

namespace PiPManager.Core.Mapping;

/// <summary>
/// Mapeia o modelo legado de slots para o novo SlotSnapshot.
/// Importante: no legado, Hidden pode ser estado; no novo modelo, Hidden é propriedade.
/// </summary>
public static class SlotSnapshotMapper
{
    public static SlotSnapshot FromLegacy(
        int slotNumber,
        string? legacyStateName,
        bool autoReturnEnabled,
        bool isLocked,
        IntPtr? pipHwnd,
        int? tabId = null,
        string? videoSessionId = null,
        string? stableVideoKey = null,
        string? attemptId = null)
    {
        var normalized = legacyStateName?.Trim() ?? string.Empty;
        var hasValidInputHwnd = pipHwnd.HasValue && pipHwnd.Value != IntPtr.Zero;
        var isHidden = hasValidInputHwnd &&
            (normalized.Equals("Hidden", StringComparison.OrdinalIgnoreCase)
            || normalized.Equals("Oculto", StringComparison.OrdinalIgnoreCase));

        var hasValidHwnd = pipHwnd.HasValue && pipHwnd.Value != IntPtr.Zero;

        var state = normalized switch
        {
            var s when s.Equals("Empty", StringComparison.OrdinalIgnoreCase) => SlotState.Empty,
            var s when s.Equals("Livre", StringComparison.OrdinalIgnoreCase) => SlotState.Empty,
            var s when s.Equals("Prepared", StringComparison.OrdinalIgnoreCase) => SlotState.Prepared,
            var s when s.Equals("Opening", StringComparison.OrdinalIgnoreCase) => SlotState.Opening,
            var s when s.Equals("Active", StringComparison.OrdinalIgnoreCase) => SlotState.Active,
            var s when s.Equals("Occupied", StringComparison.OrdinalIgnoreCase) => SlotState.Active,
            var s when s.Equals("Ocupado", StringComparison.OrdinalIgnoreCase) => SlotState.Active,
            var s when s.Equals("Hidden", StringComparison.OrdinalIgnoreCase) => SlotState.Active,
            var s when s.Equals("Oculto", StringComparison.OrdinalIgnoreCase) => SlotState.Active,
            var s when s.Equals("WaitingForReconnect", StringComparison.OrdinalIgnoreCase) => SlotState.WaitingForReconnect,
            var s when s.Equals("Reconnecting", StringComparison.OrdinalIgnoreCase) => SlotState.Reconnecting,
            var s when s.Equals("Failed", StringComparison.OrdinalIgnoreCase) => SlotState.Failed,
            _ => hasValidHwnd ? SlotState.Active : SlotState.Empty
        };

        return new SlotSnapshot
        {
            SlotNumber = slotNumber,
            State = state,
            AutoReturnEnabled = autoReturnEnabled,
            IsHidden = isHidden,
            IsLocked = isLocked,
            PipHwnd = pipHwnd,
            TabId = tabId,
            VideoSessionId = videoSessionId,
            StableVideoKey = stableVideoKey,
            AttemptId = attemptId,
            UpdatedAt = DateTimeOffset.UtcNow
        };
    }
}
