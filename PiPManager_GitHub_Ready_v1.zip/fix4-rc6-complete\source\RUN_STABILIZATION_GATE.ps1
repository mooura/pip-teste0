param(
    [ValidateSet('Navigation', 'OpenAll', 'AutoReturn', 'Layout', 'Discovery', 'All')]
    [string]$Layer = 'All',
    [switch]$Full
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path

function Run-PowerShellCheck([string]$name) {
    Write-Host "`nRunning $name..." -ForegroundColor Cyan
    & powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $root "tools\checks\$name")
    if ($LASTEXITCODE -ne 0) { throw "$name failed with exit code $LASTEXITCODE" }
}

Run-PowerShellCheck 'CHECK_STABILIZATION_BOUNDARIES.ps1'

if ($Layer -in @('Navigation', 'All')) {
    Run-PowerShellCheck 'CHECK_MANUAL_NEXT_SAME_TAB.ps1'
    Run-PowerShellCheck 'CHECK_VIDEO_COMMAND_TELEMETRY.ps1'
    & node --check (Join-Path $root 'src\PiPManager.Extension\background.js')
    if ($LASTEXITCODE -ne 0) { throw 'Extension/background.js syntax check failed' }
    & node (Join-Path $root 'tests\Extension.Tests\site-profiles.test.js')
    if ($LASTEXITCODE -ne 0) { throw 'Extension site profile tests failed' }
    & node (Join-Path $root 'tests\Extension.Tests\navigation-transaction.test.js')
    if ($LASTEXITCODE -ne 0) { throw 'Extension navigation transaction tests failed' }
}

if ($Layer -in @('OpenAll', 'All')) {
    Run-PowerShellCheck 'CHECK_TEN_SLOT_COVERAGE.ps1'
}

if ($Layer -in @('AutoReturn', 'All')) {
    Run-PowerShellCheck 'CHECK_AUTORETURN_TRIGGER_ELIGIBILITY.ps1'
    Run-PowerShellCheck 'CHECK_AUTORETURN_INFLIGHT_CANCELLATION.ps1'
    Run-PowerShellCheck 'CHECK_AUTORETURN_HWND_OWNERSHIP_SERIALIZATION.ps1'
}

if ($Layer -in @('Layout', 'All')) {
    Run-PowerShellCheck 'CHECK_RELATIVE_GROUP_LAYOUT_RECOVERY.ps1'
    Run-PowerShellCheck 'CHECK_MIXED_ASPECT_LAYOUT_STABILITY.ps1'
    Run-PowerShellCheck 'CHECK_ATOMIC_LAYOUT_DWM_GAP_STABILIZATION.ps1'
}

if ($Layer -in @('Discovery', 'All')) {
    & node (Join-Path $root 'tests\Extension.Tests\tab-discovery.test.js')
    if ($LASTEXITCODE -ne 0) { throw 'Extension tab discovery tests failed' }
    Run-PowerShellCheck 'CHECK_PLAYLIST_CONTEXT_DETECTION.ps1'
}

Write-Host "`nBuilding application..." -ForegroundColor Cyan
& dotnet build (Join-Path $root 'src\PiPManager.Wpf\PiPManager.Wpf.csproj') -c Release --no-restore
if ($LASTEXITCODE -ne 0) { throw 'Application build failed' }

if ($Full) {
    Write-Host "`nRunning canonical full regression gate..." -ForegroundColor Cyan
    & cmd /c (Join-Path $root 'RUN_CORE_TESTS.bat')
    if ($LASTEXITCODE -ne 0) { throw 'Canonical full regression gate failed' }
}

Write-Host "`nSTABILIZATION GATE PASSED: layer=$Layer; full=$Full" -ForegroundColor Green
