$ErrorActionPreference = "Stop"
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$path = Join-Path $root "src\PiPManager.Wpf\MainWindow.xaml.cs"
$text = Get-Content $path -Raw

$checks = @(
  @{ Name = "VideoChanged call"; Pattern = "ShadowMirrorVideoChanged\(slot,"; Minimum = 2 },
  @{ Name = "ReconnectStarted call"; Pattern = "ShadowMirrorReconnectStarted\(slot,"; Minimum = 1 },
  @{ Name = "ReconnectSucceeded call"; Pattern = "ShadowMirrorReconnectSucceeded\(slot,"; Minimum = 1 },
  @{ Name = "ReconnectFailed call"; Pattern = "ShadowMirrorReconnectFailed\(slot,"; Minimum = 3 },
  @{ Name = "Legacy compare"; Pattern = "ShadowLogLegacyComparison\(slot,"; Minimum = 4 },
  @{ Name = "Ensure Started before success"; Pattern = "ensure-started-before-success"; Minimum = 1 },
  @{ Name = "Ensure Started before failed"; Pattern = "ensure-started-before-failed"; Minimum = 1 },
  @{ Name = "Manual open cancels reconnect"; Pattern = "manual-open-cancels-reconnect"; Minimum = 1 },
  @{ Name = "Manual capture priority"; Pattern = "legacy-manual-capture-active"; Minimum = 1 },
  @{ Name = "AutoReturn off clears reconnect"; Pattern = "PipWindowLost-autoreturn-disabled"; Minimum = 1 },
  @{ Name = "External capture adoption"; Pattern = "ExternalPipCaptured"; Minimum = 1 },
  @{ Name = "Preserved same HWND hook"; Pattern = "PreservedSameHwndConfirmed"; Minimum = 1 },
  @{ Name = "External loss without link"; Pattern = "external-loss-without-link"; Minimum = 1 }
)

foreach ($check in $checks) {
  $count = ([regex]::Matches($text, $check.Pattern)).Count
  Write-Host "$($check.Name): $count"
  if ($count -lt $check.Minimum) {
    throw "Shadow hook binding failed: $($check.Name) expected at least $($check.Minimum), got $count"
  }
}

Write-Host "Shadow hook bindings OK."
