﻿# Perfil Jogo — ajuste nativo e Igualar por grupo

Esta versão restaura o redimensionamento normal das janelas PiP pelo Firefox/Zen.

- Arrastar a borda altera somente o PiP escolhido.
- O PiP ajustado passa a ser a referência mais recente do botão **Igualar**.
- No perfil **Jogo**, Igualar afeta somente o grupo visual da referência:
  - referência no topo: iguala apenas a fileira superior;
  - referência na lateral: iguala apenas o trilho lateral.
- O grupo oposto conserva suas dimensões e apenas pode ser reposicionado para manter o L conectado.
- Fora do perfil Jogo, Igualar mantém o comportamento global anterior.
- A margem artificial de captura ao redor do PiP foi removida; o hook apenas observa o HWND nativo real.
