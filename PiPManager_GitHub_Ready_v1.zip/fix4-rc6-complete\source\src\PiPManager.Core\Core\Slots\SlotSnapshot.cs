﻿using System;

namespace PiPManager.Core.Slots;

/// <summary>
/// Foto imutável do estado de um slot.
/// Esta classe é a base para tirar a decisão de automação da MainWindow.
/// </summary>
public sealed record SlotSnapshot
{
    public int SlotNumber { get; init; }
    public SlotState State { get; init; } = SlotState.Empty;

    public bool AutoReturnEnabled { get; init; }
    public bool IsHidden { get; init; }
    public bool IsLocked { get; init; }

    public IntPtr? PipHwnd { get; init; }
    public int? TabId { get; init; }
    public string? VideoSessionId { get; init; }
    public string? StableVideoKey { get; init; }

    public string? AttemptId { get; init; }
    public string? FailureReason { get; init; }

    public DateTimeOffset UpdatedAt { get; init; } = DateTimeOffset.UtcNow;

    public static SlotSnapshot EmptySlot(int slotNumber) => new()
    {
        SlotNumber = slotNumber,
        State = SlotState.Empty,
        UpdatedAt = DateTimeOffset.UtcNow
    };
}
