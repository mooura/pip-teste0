﻿using Microsoft.Extensions.Hosting;

namespace PiPManager.Wpf.Services;

public sealed class ExtensionBridgeHostedService : IHostedService
{
    private readonly ExtensionBridgeService _bridge;
    private readonly IApplicationHealthService _health;

    public ExtensionBridgeHostedService(ExtensionBridgeService bridge, IApplicationHealthService health)
    {
        _bridge = bridge;
        _health = health;
    }

    public Task StartAsync(CancellationToken cancellationToken)
    {
        _bridge.Start();
        _health.SetBridgeActive(true);
        return Task.CompletedTask;
    }

    public Task StopAsync(CancellationToken cancellationToken)
    {
        _health.SetBridgeActive(false);
        _bridge.Dispose();
        return Task.CompletedTask;
    }
}
