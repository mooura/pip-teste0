$ErrorActionPreference = "Stop"
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$main = Get-Content -Raw (Join-Path $root "src\PiPManager.Wpf\MainWindow.xaml.cs")
$bridge = Get-Content -Raw (Join-Path $root "src\PiPManager.Wpf\Services\ExtensionBridgeService.cs")
$background = Get-Content -Raw (Join-Path $root "src\PiPManager.Extension\background.js")
$content = Get-Content -Raw (Join-Path $root "src\PiPManager.Extension\content.js")
$profiles = Get-Content -Raw (Join-Path $root "src\PiPManager.Extension\site-profiles.js")

$checks = @(
    @{ Name = "manual next opts into exact-tab navigation"; Ok = $main.Contains("allowSameTabNavigation: command == VideoCommandKind.Next") },
    @{ Name = "exact-tab option crosses managed bridge"; Ok = $bridge.Contains("bool allowSameTabNavigation = false") -and $bridge.Contains("allowSameTabNavigation,") },
    @{ Name = "background receives exact-tab option"; Ok = $background.Contains("!!message.allowSameTabNavigation") },
    @{ Name = "manual next fallback remains tab-scoped"; Ok = $background.Contains("match = 'manual-same-tab-navigation'") -and $background.Contains("Number(targetTabId || 0) > 0") },
    @{ Name = "missing transient video is allowed only for exact tab"; Ok = $background.Contains("permitMissingVideoForExactTab") -and $background.Contains("match === 'manual-same-tab-navigation'") },
    @{ Name = "next command targets the confirmed video frame"; Ok = $background.Contains("sendMessageToTabFrame(tabId, targetFrameId") -and $background.Contains("sendMessageToTabFrame(tabId, retryFrameId") },
    @{ Name = "manual retry retains exact-tab missing-video permission"; Ok = $background.Contains("allowNoVideoTarget: !!allowSameTabNavigation") },
    @{ Name = "automatic terminal path remains distinct"; Ok = $background.Contains("terminal-same-tab-no-video-target") },
    @{ Name = "manual next has semantic live-control fallback"; Ok = $content.Contains("clickSemanticNavigationControl('next', targetVideo)") -and $content.Contains("profile-semantic-next") },
    @{ Name = "semantic live-control matching remains domain independent"; Ok = $profiles.Contains("scoreNavigationDescriptor") -and $profiles.Contains("next-room") -and $profiles.Contains("next-model") },
    @{ Name = "semantic next excludes seek controls"; Ok = $profiles.Contains("'seek'") -and $profiles.Contains("'seconds'") }
)

$failed = 0
foreach ($check in $checks) {
    if ($check.Ok) { Write-Host ($check.Name + ": OK") }
    else { Write-Host ($check.Name + ": FAIL"); $failed++ }
}

if ($failed -gt 0) { throw "Manual next same-tab checks failed." }
Write-Host "Manual next same-tab checks OK."
