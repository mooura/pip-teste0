﻿namespace PiPManager.Wpf.Services;

// Minimal contract required by WindowsEventMonitorService fake tests.
// Kept in the test assembly so it does not reference the self-contained WPF executable.
public interface IApplicationHealthService
{
    bool BridgeActive { get; }
    string ConnectedExtensionVersion { get; }
    bool PipDragHookActive { get; }
    int SlotCount { get; }
    string CoreExecutionMode { get; }
    string LastOperationalError { get; }
    bool WindowEventHookActive { get; }
    string LastWindowEvent { get; }
    long WindowEventsReceived { get; }
    long WindowEventsDiscarded { get; }
    string LastWindowEventHookFailure { get; }

    void SetBridgeActive(bool active);
    void SetPipDragHookActive(bool active);
    void SetSlotCount(int slotCount);
    void ReportOperationalError(string message);
    void SetWindowEventHookActive(bool active);
    void SetLastWindowEvent(string value);
    void SetWindowEventTotals(long received, long discarded);
    void SetWindowEventHookFailure(string value);
}
