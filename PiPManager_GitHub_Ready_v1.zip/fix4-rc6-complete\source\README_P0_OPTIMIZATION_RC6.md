# PiP Manager P0 Optimization RC6

## Objetivo

Corrigir o modo **Fixar layout** sem alterar o protocolo da extensão ou a lógica
central do AutoReturn.

## Correções

1. Autoridade PiP-only: jogos, navegadores e aplicativos externos nunca são
   movidos ou redimensionados pelo layout fixo.
2. Deadline absoluta: a recuperação encerra em no máximo 45 segundos para uma
   ou dez janelas.
3. Troca de slots: os conjuntos esperado e recuperado acompanham o conteúdo
   movido durante o ciclo.
4. Recuperação localizada: cada HWND recuperado é movido uma única vez para seu
   slot e mantém o tamanho atual.
5. Encerramento estável: conclusão ou timeout não disparam lote global nem reflow
   de aspecto capaz de deslocar PiPs estáveis.

## Build obrigatório no Windows

Execute `BUILD_WINDOWS.bat`. A fonte somente deve ser promovida após todos os
checks e a validação manual passarem.
