# Consolidação — Fase 1: linha de base

Esta fase congela e descreve o comportamento da versão funcional antes de qualquer extração arquitetural. Ela não muda regras de negócio, transporte, motor de layout ou interface.

## Identidade da baseline

- Produto: `9.39.01`
- Aplicativo: `1.5.12.3901`
- Extensão: `1.4.39.5`
- Runtime: `.NET 8 / Windows x64`
- UI: WPF
- Navegador validado: Firefox
- Extensão: WebExtension Manifest V2
- Transporte: WebSocket autenticado em localhost
- Motor padrão: Native Layout `Compare`
- ABI nativa: `100`

## Componentes preservados

1. `PiPManager.Wpf`: UI, coordenação de slots e integração Windows.
2. `PiPManager.Core`: contratos e lógica já extraída/testável.
3. `PiPManager.Native.dll`: motor experimental de layout em lote.
4. `Extension/content.js`: descoberta de players e adaptadores de site.
5. `Extension/background.js`: sessões, roteamento e ponte WebSocket.
6. `PiPManager.Core.Tests` e `PiPManager.WindowEventMonitor.Tests`.
7. Todos os `CHECK_*.ps1` registrados no gate principal.

## Matriz funcional observada

| Site | PiP | Próximo | Voltar | Playlist | Preview | Preload | AutoRetorno | Anti-ad |
|---|---|---|---|---|---|---|---|---|
| perfil de playlist indexada | operacional | operacional | operacional | operacional | MP4 animado | por slot | operacional | não aplicável |
| perfil de controles do player | operacional | operacional | operacional | operacional | sequência CDN implementada; validar em runtime | por slot | operacional com retentativa | regra ultrawide curta implementada; validar em runtime |
| perfil de rotação ao vivo | operacional | operacional | histórico da aba | não aplicável | não aplicável | não aplicável | operacional | filtro genérico |

## Cenários críticos que não podem regredir

- Abrir entre 1 e 10 PiPs sem duplicar uma sessão já capturada.
- Vincular cada PiP ao slot, aba, sessão e chave estável corretos.
- Arrastar e reorganizar o grupo em um ou mais monitores.
- Preservar identidade durante Próximo e Voltar.
- Reabrir o PiP perdido somente no slot dono da sessão.
- Cancelar AutoRetorno ao desabilitar a política do slot.
- Não promover vídeo classificado como anúncio a candidato normal.
- Não aplicar estratégia de um site em outro perfil.
- Exibir preview apenas no slot vinculado e apenas durante hover.
- Manter Preview, Preload e AutoRetorno configuráveis por slot.
- Falhar com fallback gerenciado se a DLL nativa não estiver disponível.
- Rejeitar cliente WebSocket sem handshake/origem válidos.

## Limitações conhecidas na baseline

- `MainWindow.xaml.cs`, `content.js`, `background.js` e `ExtensionBridgeService.cs` concentram responsabilidades demais.
- AutoRetorno ainda combina máquina de estados, temporizadores, UI, Win32 e transporte.
- Regras por site ainda residem principalmente em um único `content.js`.
- A maioria dos checks comportamentais usa inspeção estrutural de texto.
- Não há workflow de CI dentro do projeto.
- O motor C++ duplica parte do caminho C# e ainda precisa de decisão baseada em benchmark.
- Manifest V2 limita Chromium; Firefox permanece o alvo funcional desta baseline.
- Native Messaging ainda não substituiu o WebSocket local.

## Política para as próximas fases

- Refatoração e funcionalidade nova não entram no mesmo passo.
- Cada extração começa com testes de caracterização.
- O caminho antigo só é removido depois de paridade comprovada.
- Toda regressão recebe fixture ou teste reproduzível.
- Regras específicas de site não entram no núcleo genérico.
- Cada fase deve compilar, passar o gate completo e produzir pacote recuperável.

## Critério de conclusão desta fase

- Manifesto da baseline versionado.
- Matriz funcional e limitações conhecidas registradas.
- Gate confirma versões, arquivos essenciais e cobertura dos scripts existentes.
- Build e suíte completa continuam verdes sem mudança comportamental.

