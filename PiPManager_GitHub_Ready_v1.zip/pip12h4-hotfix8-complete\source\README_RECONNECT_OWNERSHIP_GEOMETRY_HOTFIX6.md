# Cross-Browser HWND Ownership + Reconnect Geometry Authority Hotfix 6

Version: `1.4.39.21-reconnect-ownership-geometry-hotfix6`

- Rejects a PiP candidate when its browser process differs from the process owned by the reserved slot.
- Restores both position and size from the last real pre-loss rectangle.
- Keeps a 4.2-second geometry authority with corrections at 220, 850, 1800 and 3200 ms.
- Prevents Firefox/Zen late intrinsic-aspect updates from expanding a replacement PiP to a large fraction of the screen.
- A real mouse resize cancels the temporary authority immediately.
- Re-resolves `CommandTarget` before a manual Next and blocks playlist navigation when the target is still empty.
