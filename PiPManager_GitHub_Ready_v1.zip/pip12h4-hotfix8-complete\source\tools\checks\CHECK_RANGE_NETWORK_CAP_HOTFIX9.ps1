$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$content = Get-Content (Join-Path $root 'src\PiPManager.Extension\content.js') -Raw
$background = Get-Content (Join-Path $root 'src\PiPManager.Extension\background.js') -Raw
$manifest = Get-Content (Join-Path $root 'src\PiPManager.Extension\manifest.json') -Raw | ConvertFrom-Json
$main = Get-Content (Join-Path $root 'src\PiPManager.Wpf\MainWindow.xaml.cs') -Raw
$layout = Get-Content (Join-Path $root 'src\PiPManager.Wpf\MainWindow.Layout.cs') -Raw
$drag = Get-Content (Join-Path $root 'src\PiPManager.Wpf\MainWindow.PipDrag.cs') -Raw

$checks = [ordered]@{
  'manifest is 1.4.39.25' = ([string]$manifest.version -eq '1.4.39.25')
  'range hotfix identifiers synchronized' = $content.Contains("CONTENT_VERSION = '1.4.39.25-command-target-root-guard-hotfix10'") -and $background.Contains("BRIDGE_VERSION = '1.4.39.25-command-target-root-guard-hotfix10'")
  'background requests explicit byte range' = $background.Contains('Range: `bytes=0-${maxBytes - 1}`')
  'range request uses AbortController' = $background.Contains('const controller = new AbortController()')
  'byte and time caps are explicit' = $background.Contains("active.abortReason = 'byte-cap'") -and $background.Contains("active.abortReason = 'time-cap'")
  'temporary cache is bounded' = $background.Contains('RANGE_PRELOAD_CACHE_MAX_ENTRIES = 3') -and $background.Contains('RANGE_PRELOAD_CACHE_TTL_MS = 90000')
  'strict streaming avoids unbounded arrayBuffer' = -not $background.Contains('await response.arrayBuffer()')
  'content delegates preload to range controller' = $content.Contains("type: 'pipManagerStartRangePreload'")
  'handoff records and consumes cached bytes' = $content.Contains('rangeCachePreserved: cachedBytes > 0') -and $content.Contains("type: 'pipManagerConsumeRangePreload'")
  'trusted geometry remains present' = $main.Contains('_lastManualUserRectBySlot') -and $main.Contains('slot-navigation-geometry-safe-fallback') -and $layout.Contains('ClampLayoutTargetToGeometryAuthority') -and $drag.Contains('_lastManualUserRectBySlot[slot.Number] = finalRect')
}

$failed = $false
foreach ($entry in $checks.GetEnumerator()) {
  $status = if ($entry.Value) { 'OK' } else { $failed = $true; 'FAIL' }
  Write-Host ("{0}: {1}" -f $entry.Key, $status)
}
if ($failed) { throw 'Range network cap Hotfix 9 checks failed.' }
Write-Host 'Range network cap Hotfix 9 checks OK.'
