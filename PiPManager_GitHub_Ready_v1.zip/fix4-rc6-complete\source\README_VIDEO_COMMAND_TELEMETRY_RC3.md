# Hotfix de telemetria Próximo/Anterior — RC3

Esta candidata preserva a navegação validada na RC2 e acrescenta um ciclo
estruturado de log independente do estado de preservação e do AutoReturn.

Cada clique aceito gera um `operationId` único e usa o mesmo identificador nos
seguintes marcadores:

1. `video-command-requested`
2. `video-command-dispatched`
3. `video-command-confirmed`
4. `video-command-final-result`

Os registros incluem comando, slot, aba, sessão, stable key, URL conhecida,
transporte, método e resultado. O fluxo autoritativo de Anterior continua sendo
`tabs-goBack-linked-tab-authoritative`.

Falhas anteriores ao envio, ausência de extensão, exceções de transporte e
fallback local também produzem `video-command-final-result`, evitando operações
sem desfecho observável.

Não houve alteração na lógica de navegação, no AutoReturn, no preload, nos
layouts, na captura ou no núcleo nativo.
