﻿using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Threading;
using PiPManager.Wpf.Models;

namespace PiPManager.Wpf;

public partial class FloatingToolbarWindow : Window
{
    private const int Gap = 6;
    private const int CollapsedTouchGap = 0;
    private const double ExpandedWidth = 170;
    private const double CollapsedWidth = 34;
    private const double DragThreshold = 10;

    private bool _userDragging;
    private bool _programmaticMove;
    private bool _isCollapsed;
    private bool _handlePressed;
    private bool _handleDragged;
    private bool _collapsedClickArmed;
    private bool _moveGroupOnDrag;
    private bool _collapsedManualPosition;
    private bool _hiddenState;
    private double _manualCollapsedLeft = double.NaN;
    private double _manualCollapsedTop = double.NaN;
    private readonly DispatcherTimer _collapsedSingleClickTimer;
    private Point _handlePressPoint;
    private double _lastLeft;
    private double _lastTop;
    private double _dragStartLeft;
    private double _dragStartTop;

    public Action? ArrangeRequested { get; init; }
    public Action? EqualizeRequested { get; init; }
    public Action? VisibilityRequested { get; init; }
    public Action? ExpandRequested { get; init; }
    public Action<int, int>? GroupMoveRequested { get; init; }
    public Action? AutoPositionRequested { get; init; }
    public Action? ToolbarStateChanged { get; init; }

    public FloatingToolbarWindow()
    {
        InitializeComponent();

        _collapsedSingleClickTimer = new DispatcherTimer
        {
            // Espera uma janela curta para diferenciar clique simples de duplo clique.
            // Evita depender de SystemParameters.DoubleClickTime, que não existe em WPF.
            Interval = TimeSpan.FromMilliseconds(550)
        };
        _collapsedSingleClickTimer.Tick += (_, _) =>
        {
            _collapsedSingleClickTimer.Stop();
        };

        LocationChanged += FloatingToolbarWindow_LocationChanged;
        Loaded += (_, _) =>
        {
            _lastLeft = Left;
            _lastTop = Top;
            ApplyIconTheme();
            ApplyCollapsedState(false);
        };
    }

    private enum IconKind
    {
        Equalize,
        Lock,
        Unlock,
        Eye,
        EyeOff,
        Panel
    }

    private void ApplyIconTheme()
    {
        // Apenas 4 ações principais na barra:
        // Travar, Igualar, Ocultar/Mostrar e Painel.
        // Ocultar/Mostrar fica com alvo levemente maior para acesso rápido.
        LockStateButton.Content = CreateIcon(IconKind.Unlock);
        EqualizeIconButton.Content = CreateIcon(IconKind.Equalize);
        VisibilityButton.Content = CreateIcon(IconKind.EyeOff);
        PanelIconButton.Content = CreateIcon(IconKind.Panel);

        SetButtonState(LockStateButton, active: false);
        SetButtonState(EqualizeIconButton, active: false);
        SetButtonState(VisibilityButton, active: false);
        SetButtonState(PanelIconButton, active: false);
        SetButtonState(ToggleHandle, active: false);
    }

    private static FrameworkElement CreateIcon(IconKind kind)
    {
        var grid = new Grid
        {
            Width = 18,
            Height = 18,
            HorizontalAlignment = HorizontalAlignment.Center,
            VerticalAlignment = VerticalAlignment.Center,
            IsHitTestVisible = false
        };

        switch (kind)
        {
            case IconKind.Equalize:
                // Quatro cantos: igualar/ajustar tamanho.
                AddLine(grid, 3, 6, 3, 3);
                AddLine(grid, 3, 3, 6, 3);
                AddLine(grid, 12, 3, 15, 3);
                AddLine(grid, 15, 3, 15, 6);
                AddLine(grid, 3, 12, 3, 15);
                AddLine(grid, 3, 15, 6, 15);
                AddLine(grid, 12, 15, 15, 15);
                AddLine(grid, 15, 15, 15, 12);
                break;
            case IconKind.Lock:
                AddRect(grid, 4.5, 8, 9, 7, 1.6);
                AddPath(grid, "M6.2,8 L6.2,6.8 C6.2,5.1 7.4,3.9 9,3.9 C10.6,3.9 11.8,5.1 11.8,6.8 L11.8,8", 1.7);
                AddEllipse(grid, 9, 11.2, 0.95, 1.3);
                break;

            case IconKind.Unlock:
                AddRect(grid, 4.5, 8, 9, 7, 1.6);
                AddPath(grid, "M11.8,8 L11.8,6.8 C11.8,5.1 10.6,3.9 9,3.9 C7.4,3.9 6.2,5.1 6.2,6.8", 1.7);
                AddEllipse(grid, 9, 11.2, 0.95, 1.3);
                break;

            case IconKind.Eye:
                AddPath(grid, "M1.5,9 C3.2,5.9 5.8,4.4 9,4.4 C12.2,4.4 14.8,5.9 16.5,9 C14.8,12.1 12.2,13.6 9,13.6 C5.8,13.6 3.2,12.1 1.5,9 Z", 1.5);
                AddEllipse(grid, 9, 9, 2.3, 1.5);
                break;

            case IconKind.EyeOff:
                AddPath(grid, "M1.5,9 C3.2,5.9 5.8,4.4 9,4.4 C12.2,4.4 14.8,5.9 16.5,9 C15.7,10.4 14.8,11.4 13.7,12.2", 1.5);
                AddPath(grid, "M11,13.2 C10.4,13.5 9.7,13.6 9,13.6 C5.8,13.6 3.2,12.1 1.5,9 C2.2,7.8 3,6.8 4,6", 1.5);
                AddEllipse(grid, 9, 9, 2.2, 1.5);
                AddLine(grid, 3, 15, 15, 3, 1.7);
                break;

            case IconKind.Panel:
                AddRect(grid, 3, 4, 12, 10, 1.5);
                AddLine(grid, 9, 4, 9, 14, 1.5);
                break;
        }

        return grid;
    }

    private static void AddLine(Grid grid, double x1, double y1, double x2, double y2, double thickness = 1.7)
    {
        grid.Children.Add(new System.Windows.Shapes.Line
        {
            X1 = x1,
            Y1 = y1,
            X2 = x2,
            Y2 = y2,
            Stroke = Brushes.White,
            StrokeThickness = thickness,
            StrokeStartLineCap = PenLineCap.Round,
            StrokeEndLineCap = PenLineCap.Round,
            Opacity = 0.84
        });
    }

    private static void AddPath(Grid grid, string data, double thickness)
    {
        grid.Children.Add(new System.Windows.Shapes.Path
        {
            Data = Geometry.Parse(data),
            Stroke = Brushes.White,
            StrokeThickness = thickness,
            StrokeStartLineCap = PenLineCap.Round,
            StrokeEndLineCap = PenLineCap.Round,
            StrokeLineJoin = PenLineJoin.Round,
            Fill = Brushes.Transparent,
            Opacity = 0.84
        });
    }

    private static void AddRect(Grid grid, double x, double y, double width, double height, double thickness)
    {
        var rect = new System.Windows.Shapes.Rectangle
        {
            Width = width,
            Height = height,
            Stroke = Brushes.White,
            StrokeThickness = thickness,
            RadiusX = 1.5,
            RadiusY = 1.5,
            Fill = Brushes.Transparent,
            Opacity = 0.84
        };
        Canvas.SetLeft(rect, x);
        Canvas.SetTop(rect, y);

        var canvas = grid.Children.OfType<Canvas>().FirstOrDefault();
        if (canvas == null)
        {
            canvas = new Canvas { Width = 18, Height = 18, IsHitTestVisible = false };
            grid.Children.Add(canvas);
        }

        canvas.Children.Add(rect);
    }

    private static void AddEllipse(Grid grid, double centerX, double centerY, double radius, double thickness)
    {
        var ellipse = new System.Windows.Shapes.Ellipse
        {
            Width = radius * 2,
            Height = radius * 2,
            Stroke = Brushes.White,
            StrokeThickness = thickness,
            Fill = Brushes.Transparent,
            Opacity = 0.84
        };
        Canvas.SetLeft(ellipse, centerX - radius);
        Canvas.SetTop(ellipse, centerY - radius);

        var canvas = grid.Children.OfType<Canvas>().FirstOrDefault();
        if (canvas == null)
        {
            canvas = new Canvas { Width = 18, Height = 18, IsHitTestVisible = false };
            grid.Children.Add(canvas);
        }

        canvas.Children.Add(ellipse);
    }


    private static readonly Brush NormalButtonBackground = Brushes.Transparent;
    private static readonly Brush ActiveButtonBackground = new SolidColorBrush(Color.FromArgb(0x58, 0x13, 0x3A, 0x4D));
    private static readonly Brush WarningButtonBackground = new SolidColorBrush(Color.FromArgb(0x45, 0x54, 0x37, 0x12));
    private static readonly Brush NormalButtonBorder = Brushes.Transparent;
    private static readonly Brush ActiveButtonBorder = new SolidColorBrush(Color.FromRgb(0x38, 0xBD, 0xF8));
    private static readonly Brush WarningButtonBorder = new SolidColorBrush(Color.FromRgb(0xF6, 0xC4, 0x53));

    private static readonly Brush ShellNormalBackground = new SolidColorBrush(Color.FromArgb(0xF0, 0x06, 0x0A, 0x12));
    private static readonly Brush ShellNormalBorder = new SolidColorBrush(Color.FromRgb(0x26, 0x38, 0x4C));
    private static readonly Brush ShellActiveBorder = new SolidColorBrush(Color.FromRgb(0x2C, 0x60, 0x78));
    private static readonly Brush ShellCollapsedBackground = new SolidColorBrush(Color.FromArgb(0xF4, 0x06, 0x0A, 0x12));
    private static readonly Brush ShellCollapsedBorder = new SolidColorBrush(Color.FromRgb(0x2A, 0x3B, 0x50));
    private static readonly Brush ShellCollapsedWarningBorder = new SolidColorBrush(Color.FromRgb(0xC9, 0x95, 0x3C));

    private static void SetButtonState(Button button, bool active, bool warning = false)
    {
        button.Background = warning ? WarningButtonBackground : active ? ActiveButtonBackground : NormalButtonBackground;
        button.BorderBrush = warning ? WarningButtonBorder : active ? ActiveButtonBorder : NormalButtonBorder;
        button.BorderThickness = active || warning ? new Thickness(1) : new Thickness(0);
        button.Opacity = active || warning ? 1.0 : 0.86;
    }

    private FrameworkElement CreateCollapsedHandleContent(bool hidden)
    {
        var grid = new Grid
        {
            Width = 20,
            Height = 18,
            IsHitTestVisible = false,
            HorizontalAlignment = HorizontalAlignment.Center,
            VerticalAlignment = VerticalAlignment.Center
        };

        // Seta = clique esquerdo abre a barra.
        grid.Children.Add(new TextBlock
        {
            Text = "›",
            Foreground = Brushes.White,
            FontSize = 14,
            FontWeight = FontWeights.Bold,
            HorizontalAlignment = HorizontalAlignment.Left,
            VerticalAlignment = VerticalAlignment.Center,
            Margin = new Thickness(2, -1, 0, 0),
            Opacity = 0.92,
            IsHitTestVisible = false
        });

        // Ponto de estado = atalho rápido de ocultar/mostrar pelo botão direito.
        var dot = new System.Windows.Shapes.Ellipse
        {
            Width = hidden ? 6.0 : 5.0,
            Height = hidden ? 6.0 : 5.0,
            Fill = hidden ? WarningButtonBorder : ActiveButtonBorder,
            Opacity = hidden ? 0.98 : 0.78,
            HorizontalAlignment = HorizontalAlignment.Right,
            VerticalAlignment = VerticalAlignment.Center,
            Margin = new Thickness(0, 0, 1, 0),
            IsHitTestVisible = false
        };
        grid.Children.Add(dot);
        return grid;
    }

    private void ApplyCollapsedShellVisual(bool hidden)
    {
        ToolbarShell.CornerRadius = new CornerRadius(17);
        ToolbarShell.Padding = new Thickness(3);
        ToolbarShell.Background = ShellCollapsedBackground;
        ToolbarShell.BorderBrush = hidden ? ShellCollapsedWarningBorder : ShellCollapsedBorder;
        ToolbarShell.BorderThickness = new Thickness(1);

        ToggleHandle.Width = 28;
        ToggleHandle.Height = 26;
        ToggleHandle.Margin = new Thickness(0);
    }

    private void ApplyExpandedShellVisual()
    {
        ToolbarShell.CornerRadius = new CornerRadius(17);
        ToolbarShell.Padding = new Thickness(3);
        ToolbarShell.Background = ShellNormalBackground;
        ToolbarShell.BorderBrush = ShellNormalBorder;
        ToolbarShell.BorderThickness = new Thickness(1);

        ToggleHandle.Width = 24;
        ToggleHandle.Height = 26;
        ToggleHandle.Margin = new Thickness(0, 0, 2, 0);
    }

    public void SetHiddenState(bool hidden)
    {
        _hiddenState = hidden;

        // Olho aberto = comando para mostrar; olho cortado = comando para ocultar.
        VisibilityButton.Content = CreateIcon(hidden ? IconKind.Eye : IconKind.EyeOff);
        VisibilityButton.ToolTip = hidden ? "Mostrar PiPs" : "Ocultar PiPs";
        SetButtonState(VisibilityButton, active: false, warning: hidden);

        // Feedback discreto no botão de ocultar/mostrar.
        VisibilityButton.BeginAnimation(OpacityProperty, new DoubleAnimation
        {
            From = hidden ? 0.72 : 0.82,
            To = hidden ? 1.0 : 0.86,
            Duration = TimeSpan.FromMilliseconds(140),
            EasingFunction = new QuadraticEase { EasingMode = EasingMode.EaseOut }
        });

        if (_isCollapsed)
            ApplyCollapsedQuickButtonIcon();
    }


    private void ApplyCollapsedQuickButtonIcon()
    {
        ApplyCollapsedShellVisual(_hiddenState);
        ToggleHandle.Content = CreateCollapsedHandleContent(_hiddenState);
        ToggleHandle.ToolTip = _hiddenState
            ? "Clique esquerdo: abrir barra. Botão direito: MOSTRAR PiPs. Arraste: mover."
            : "Clique esquerdo: abrir barra. Botão direito: OCULTAR PiPs. Arraste: mover.";
        SetButtonState(ToggleHandle, active: false, warning: _hiddenState);
    }

    public void SetLockState(bool locked)
    {
        // Cadeado aberto = PiPs soltos; cadeado fechado = grupo travado.
        LockStateButton.Content = CreateIcon(locked ? IconKind.Lock : IconKind.Unlock);
        LockStateButton.ToolTip = locked
            ? "Soltar grupo"
            : "Travar grupo";
        SetButtonState(LockStateButton, active: locked);

        if (!_isCollapsed)
            ToolbarShell.BorderBrush = locked ? ShellActiveBorder : ShellNormalBorder;
    }

    public bool IsDragging => _userDragging;
    public bool IsCollapsed => _isCollapsed;


    public bool HasManualCollapsedPosition => _collapsedManualPosition
        && !double.IsNaN(_manualCollapsedLeft)
        && !double.IsNaN(_manualCollapsedTop);

    public bool TryGetManualCollapsedPosition(out double left, out double top)
    {
        if (HasManualCollapsedPosition)
        {
            left = _manualCollapsedLeft;
            top = _manualCollapsedTop;
            return true;
        }

        left = double.NaN;
        top = double.NaN;
        return false;
    }

    public void RestoreManualCollapsedPosition(double left, double top)
    {
        if (double.IsNaN(left) || double.IsNaN(top)) return;

        _collapsedManualPosition = true;
        _manualCollapsedLeft = left;
        _manualCollapsedTop = top;
    }

    private void MoveToManualCollapsedPosition()
    {
        if (!HasManualCollapsedPosition) return;

        _programmaticMove = true;
        Left = _manualCollapsedLeft;
        Top = _manualCollapsedTop;
        _lastLeft = Left;
        _lastTop = Top;
        _programmaticMove = false;
    }

    public NativeRect GetBoundsInPixels()
    {
        var dpi = VisualTreeHelper.GetDpi(this);
        var widthPx = (int)Math.Ceiling(Math.Max(ActualWidth, Width) * dpi.DpiScaleX);
        var heightPx = (int)Math.Ceiling(Math.Max(ActualHeight, Height) * dpi.DpiScaleY);
        var leftPx = (int)Math.Round(Left * dpi.DpiScaleX);
        var topPx = (int)Math.Round(Top * dpi.DpiScaleY);
        return new NativeRect(leftPx, topPx, leftPx + widthPx, topPx + heightPx);
    }

    public void PositionNextTo(NativeRect groupBounds, NativeRect workArea)
    {
        if (!groupBounds.IsValid || !workArea.IsValid) return;

        // Se o usuário ajustou manualmente a barrinha recolhida,
        // não fica puxando ela de volta a cada atualização automática.
        if (_isCollapsed && _collapsedManualPosition) return;

        var dpi = VisualTreeHelper.GetDpi(this);
        var widthPx = (int)Math.Ceiling(Math.Max(ActualWidth, Width) * dpi.DpiScaleX);
        var heightPx = (int)Math.Ceiling(Math.Max(ActualHeight, Height) * dpi.DpiScaleY);
        var target = _isCollapsed
            ? FindCollapsedTouchingRect(groupBounds, workArea, widthPx, heightPx)
            : FindBestExpandedRect(groupBounds, workArea, widthPx, heightPx);

        _programmaticMove = true;
        Left = target.Left / dpi.DpiScaleX;
        Top = target.Top / dpi.DpiScaleY;
        _lastLeft = Left;
        _lastTop = Top;
        _programmaticMove = false;
    }

    private static NativeRect FindBestExpandedRect(NativeRect groupBounds, NativeRect screenBounds, int widthPx, int heightPx)
    {
        var topSpace = Math.Max(0, groupBounds.Top - screenBounds.Top);
        var bottomSpace = Math.Max(0, screenBounds.Bottom - groupBounds.Bottom);
        var rightSpace = Math.Max(0, screenBounds.Right - groupBounds.Right);
        var leftSpace = Math.Max(0, groupBounds.Left - screenBounds.Left);

        var candidates = new (NativeRect Rect, int Score)[]
        {
            // Barra expandida: procura primeiro o lado com espaço real disponível.
            (BuildRect(groupBounds.CenterX - widthPx / 2, groupBounds.Top - heightPx - Gap, widthPx, heightPx), 1000 + topSpace),
            (BuildRect(groupBounds.CenterX - widthPx / 2, groupBounds.Bottom + Gap, widthPx, heightPx), 980 + bottomSpace),
            (BuildRect(groupBounds.Right + Gap, groupBounds.CenterY - heightPx / 2, widthPx, heightPx), 940 + rightSpace),
            (BuildRect(groupBounds.Left - widthPx - Gap, groupBounds.CenterY - heightPx / 2, widthPx, heightPx), 920 + leftSpace),
            (BuildRect(groupBounds.Left, groupBounds.Top - heightPx - Gap, widthPx, heightPx), 850 + topSpace),
            (BuildRect(groupBounds.Right - widthPx, groupBounds.Top - heightPx - Gap, widthPx, heightPx), 840 + topSpace),
            (BuildRect(groupBounds.Left, groupBounds.Bottom + Gap, widthPx, heightPx), 830 + bottomSpace),
            (BuildRect(groupBounds.Right - widthPx, groupBounds.Bottom + Gap, widthPx, heightPx), 820 + bottomSpace),
        };

        foreach (var candidate in candidates.OrderByDescending(item => item.Score))
        {
            var clamped = ClampToScreen(candidate.Rect, screenBounds);
            if (!clamped.Intersects(groupBounds))
                return clamped;
        }

        return candidates
            .Select(item => ClampToScreen(item.Rect, screenBounds))
            .OrderBy(rect => rect.IntersectionArea(groupBounds))
            .ThenBy(rect => DistanceSquared(rect, groupBounds))
            .FirstOrDefault();
    }

    private static NativeRect FindCollapsedTouchingRect(NativeRect groupBounds, NativeRect screenBounds, int widthPx, int heightPx)
    {
        var topSpace = Math.Max(0, groupBounds.Top - screenBounds.Top);
        var bottomSpace = Math.Max(0, screenBounds.Bottom - groupBounds.Bottom);
        var rightSpace = Math.Max(0, screenBounds.Right - groupBounds.Right);
        var leftSpace = Math.Max(0, groupBounds.Left - screenBounds.Left);

        var candidates = new (NativeRect Rect, int Score)[]
        {
            // Barra recolhida: encosta nos PiPs, sem folga visual.
            (BuildRect(groupBounds.CenterX - widthPx / 2, groupBounds.Bottom + CollapsedTouchGap, widthPx, heightPx), 1000 + bottomSpace),
            (BuildRect(groupBounds.CenterX - widthPx / 2, groupBounds.Top - heightPx - CollapsedTouchGap, widthPx, heightPx), 980 + topSpace),
            (BuildRect(groupBounds.Right + CollapsedTouchGap, groupBounds.CenterY - heightPx / 2, widthPx, heightPx), 940 + rightSpace),
            (BuildRect(groupBounds.Left - widthPx - CollapsedTouchGap, groupBounds.CenterY - heightPx / 2, widthPx, heightPx), 920 + leftSpace),
            (BuildRect(groupBounds.Right - widthPx, groupBounds.Bottom + CollapsedTouchGap, widthPx, heightPx), 860 + bottomSpace),
            (BuildRect(groupBounds.Left, groupBounds.Bottom + CollapsedTouchGap, widthPx, heightPx), 850 + bottomSpace),
            (BuildRect(groupBounds.Right - widthPx, groupBounds.Top - heightPx - CollapsedTouchGap, widthPx, heightPx), 840 + topSpace),
            (BuildRect(groupBounds.Left, groupBounds.Top - heightPx - CollapsedTouchGap, widthPx, heightPx), 830 + topSpace),
        };

        foreach (var candidate in candidates.OrderByDescending(item => item.Score))
        {
            var clamped = ClampToScreen(candidate.Rect, screenBounds);
            if (!clamped.Intersects(groupBounds))
                return clamped;
        }

        return candidates
            .Select(item => ClampToScreen(item.Rect, screenBounds))
            .OrderBy(rect => rect.IntersectionArea(groupBounds))
            .ThenBy(rect => DistanceSquared(rect, groupBounds))
            .FirstOrDefault();
    }

    private static NativeRect BuildRect(int left, int top, int width, int height) =>
        new(left, top, left + Math.Max(1, width), top + Math.Max(1, height));

    private static NativeRect ClampToScreen(NativeRect rect, NativeRect screenBounds)
    {
        var maxLeft = Math.Max(screenBounds.Left, screenBounds.Right - rect.Width);
        var maxTop = Math.Max(screenBounds.Top, screenBounds.Bottom - rect.Height);
        var left = Math.Clamp(rect.Left, screenBounds.Left, maxLeft);
        var top = Math.Clamp(rect.Top, screenBounds.Top, maxTop);
        return new NativeRect(left, top, left + rect.Width, top + rect.Height);
    }

    private static int DistanceSquared(NativeRect rect, NativeRect groupBounds)
    {
        var dx = rect.CenterX - groupBounds.CenterX;
        var dy = rect.CenterY - groupBounds.CenterY;
        return (dx * dx) + (dy * dy);
    }

    private void ToggleHandle_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (e.LeftButton != MouseButtonState.Pressed) return;

        _handlePressed = true;
        _handleDragged = false;
        _handlePressPoint = PointToScreen(e.GetPosition(this));
        _dragStartLeft = Left;
        _dragStartTop = Top;
        _lastLeft = Left;
        _lastTop = Top;
        _moveGroupOnDrag = false;
        _collapsedSingleClickTimer.Stop();

        // Recolhida: clique esquerdo abre; arraste move apenas a barrinha; botão direito vira atalho de ocultar/mostrar.
        _collapsedClickArmed = _isCollapsed;

        try { ToggleHandle.CaptureMouse(); } catch { }
        e.Handled = true;
    }

    private void ToggleHandle_PreviewMouseMove(object sender, MouseEventArgs e)
    {
        if (!_handlePressed || e.LeftButton != MouseButtonState.Pressed) return;

        var current = PointToScreen(e.GetPosition(this));
        var dx = current.X - _handlePressPoint.X;
        var dy = current.Y - _handlePressPoint.Y;

        if (!_handleDragged)
        {
            if (Math.Abs(dx) < DragThreshold && Math.Abs(dy) < DragThreshold)
                return;

            _handleDragged = true;
            _userDragging = true;

            if (_isCollapsed)
            {
                // Recolhida: ao arrastar, cancela o clique rápido e permite ajustar
                // somente a posição da barrinha.
                _collapsedClickArmed = false;
                _moveGroupOnDrag = false;
                _collapsedManualPosition = true;
            }
            else
            {
                // Expandida: arrastar continua movendo o grupo de PiPs.
                _moveGroupOnDrag = true;
            }
        }

        // Arraste manual: evita conflito do DragMove com clique curto.
        Left = _dragStartLeft + dx;
        Top = _dragStartTop + dy;
        e.Handled = true;
    }

    private void ToggleHandle_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
    {
        try
        {
            if (ToggleHandle.IsMouseCaptured)
                ToggleHandle.ReleaseMouseCapture();
        }
        catch
        {
            // Ignora falha de captura.
        }

        var wasCollapsed = _isCollapsed;
        var wasDragged = _handleDragged;

        _handlePressed = false;
        _handleDragged = false;
        _userDragging = false;
        _moveGroupOnDrag = false;

        if (wasCollapsed)
        {
            // Recolhida:
            // - clique esquerdo curto = abrir a barra;
            // - arraste = ajustar a posição da barrinha;
            // - botão direito = atalho rápido de ocultar/mostrar.
            if (_collapsedClickArmed && !wasDragged)
            {
                _collapsedSingleClickTimer.Stop();
                ExpandFromCollapsed();
            }
            else if (wasDragged)
            {
                _manualCollapsedLeft = Left;
                _manualCollapsedTop = Top;
                ToolbarStateChanged?.Invoke();
            }

            _collapsedClickArmed = false;
            e.Handled = true;
            return;
        }

        _collapsedClickArmed = false;

        // Expandida: clique curto recolhe; arraste moveu a barra/grupo.
        if (!wasDragged)
            CollapseFromExpanded();

        e.Handled = true;
    }

    private void ToggleHandle_PreviewMouseRightButtonUp(object sender, MouseButtonEventArgs e)
    {
        // Recolhida: botão direito vira atalho rápido de ocultar/mostrar.
        // Expandida: botão direito não faz nada, para evitar ações acidentais.
        _collapsedSingleClickTimer.Stop();

        if (_isCollapsed)
        {
            VisibilityRequested?.Invoke();
            ToolbarStateChanged?.Invoke();
        }

        e.Handled = true;
    }

    private void ToggleCollapsed()
    {
        if (_isCollapsed)
            ExpandFromCollapsed();
        else
            CollapseFromExpanded();
    }

    private void ExpandFromCollapsed()
    {
        _collapsedSingleClickTimer.Stop();
        ApplyCollapsedState(false);
        ToolbarStateChanged?.Invoke();

        // Deixa o WPF recalcular largura/visibilidade antes de procurar espaco.
        Dispatcher.BeginInvoke(new Action(() =>
        {
            UpdateLayout();
            AutoPositionRequested?.Invoke();
        }), DispatcherPriority.Render);
    }

    private void CollapseFromExpanded()
    {
        ApplyCollapsedState(true);
        ToolbarStateChanged?.Invoke();

        Dispatcher.BeginInvoke(new Action(() =>
        {
            UpdateLayout();

            // Se o usuário já posicionou manualmente a barrinha recolhida,
            // ela volta exatamente para esse ponto. Se não, encosta nos PiPs.
            if (HasManualCollapsedPosition)
                MoveToManualCollapsedPosition();
            else
                AutoPositionRequested?.Invoke();
        }), DispatcherPriority.Render);
    }

    private void ApplyCollapsedState(bool collapsed)
    {
        _isCollapsed = collapsed;
        ToolbarActions.Visibility = collapsed ? Visibility.Collapsed : Visibility.Visible;

        var targetWidth = collapsed ? CollapsedWidth : ExpandedWidth;
        MinWidth = targetWidth;
        MaxWidth = targetWidth;
        Width = targetWidth;

        SizeToContent = SizeToContent.Manual;
        InvalidateMeasure();
        InvalidateArrange();

        // Animação leve: não muda layout nem lógica, só dá feedback visual rápido.
        BeginAnimation(OpacityProperty, new DoubleAnimation
        {
            From = 0.88,
            To = 1.0,
            Duration = TimeSpan.FromMilliseconds(120),
            EasingFunction = new QuadraticEase { EasingMode = EasingMode.EaseOut }
        });

        if (collapsed)
        {
            ApplyCollapsedQuickButtonIcon();
        }
        else
        {
            ApplyExpandedShellVisual();
            ToggleHandle.Content = "‹";
            ToggleHandle.FontSize = 14;
            ToggleHandle.FontWeight = FontWeights.Bold;
            ToggleHandle.ToolTip = "Clique esquerdo: recolher barra. Arraste: mover grupo.";
            SetButtonState(ToggleHandle, active: false);
        }
    }

    private void FloatingToolbarWindow_LocationChanged(object? sender, EventArgs e)
    {
        if (!_userDragging || _programmaticMove) return;
        var dpi = VisualTreeHelper.GetDpi(this);
        var deltaX = (int)Math.Round((Left - _lastLeft) * dpi.DpiScaleX);
        var deltaY = (int)Math.Round((Top - _lastTop) * dpi.DpiScaleY);
        _lastLeft = Left;
        _lastTop = Top;
        if (_moveGroupOnDrag)
            GroupMoveRequested?.Invoke(deltaX, deltaY);
    }

    private void RunActionAndCollapse(Action? action)
    {
        action?.Invoke();

        // Mantém a dock aberta após o comando para o estado visual continuar claro.
        // O usuário recolhe pelo handle quando quiser.
        ToolbarStateChanged?.Invoke();
    }

    private void ArrangeButton_Click(object sender, RoutedEventArgs e) => RunActionAndCollapse(ArrangeRequested);
    private void EqualizeButton_Click(object sender, RoutedEventArgs e) => RunActionAndCollapse(EqualizeRequested);
    private void VisibilityButton_Click(object sender, RoutedEventArgs e) => RunActionAndCollapse(VisibilityRequested);
    private void ExpandButton_Click(object sender, RoutedEventArgs e) => RunActionAndCollapse(ExpandRequested);
}
