﻿$ErrorActionPreference = 'Stop'

$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$settings = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\Models\AppSettings.cs') -Raw
$layoutService = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\Services\LayoutService.cs') -Raw
$layout = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\MainWindow.Layout.cs') -Raw
$main = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\MainWindow.xaml.cs') -Raw
$fixed = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\MainWindow.FixedLayout.cs') -Raw
$xaml = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\MainWindow.xaml') -Raw

$checks = [ordered]@{
    'free-area toggle persists' = $settings.Contains('JogoFreeAreaEnabled') -and $main.Contains('_settings.JogoFreeAreaEnabled = _jogoFreeAreaEnabled')
    'uniform scale persists' = $settings.Contains('JogoLayoutScale') -and $main.Contains('_settings.JogoLayoutScale = NormalizeJogoLayoutScale(_jogoLayoutScale)')
    'scale is bounded from 55 to 100 percent' = $layout.Contains('JogoMinimumLayoutScale = 0.55') -and $layout.Contains('JogoMaximumLayoutScale = 1.00')
    'Jogo builder receives effective scale' = $layout.Contains('jogoLayoutScale: ResolveJogoLayoutScale()') -and $layout.Contains('NormalizeJogoGroupWidthRatio(_jogoTopWidthRatio)')
    'layout scale is uniform and top-right anchored' = $layoutService.Contains('ScaleJogoTargetsToTopRight') -and $layoutService.Contains('screen.Right - value') -and $layoutService.Contains('value - screen.Top')
    'shared seams use coordinate transform' = $layoutService.Contains('ScaleX(target.Left)') -and $layoutService.Contains('ScaleX(target.Right)') -and $layoutService.Contains('ScaleY(target.Top)') -and $layoutService.Contains('ScaleY(target.Bottom)')
    'free-area controls are exposed in Layout menu' = $xaml.Contains('x:Name="JogoFreeAreaMenuItem"') -and $xaml.Contains('JogoMoreFreeAreaMenuItem_Click') -and $xaml.Contains('JogoLessFreeAreaMenuItem_Click')
    'adjustment immediately reapplies Jogo authority' = $layout.Contains('ApplyJogoFreeAreaAdjustment') -and $layout.Contains('BuildJogoContentAwareTargets(occupied, sourceRects, workArea)') -and $layout.Contains('fixedAuthorityRefreshed=True')
    'fixed layout label exposes free scale' = $fixed.Contains('Livre: {JogoFreeAreaText}')
    'automatic mode remains exact legacy behavior' = $layout.Contains('=> _jogoFreeAreaEnabled ? NormalizeJogoLayoutScale(_jogoLayoutScale) : 1.0') -and $layoutService.Contains('if (scale >= 0.9995)')
}

$failed = @()
foreach ($entry in $checks.GetEnumerator()) {
    if ($entry.Value) { Write-Host ($entry.Key + ': OK') }
    else { Write-Host ($entry.Key + ': FAIL'); $failed += $entry.Key }
}
if ($failed.Count -gt 0) { throw "Jogo free-area scale checks failed: $($failed -join ', ')" }
Write-Host 'JOGO FREE AREA SCALE CHECK OK.'
