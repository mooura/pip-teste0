$ErrorActionPreference = "Stop"

$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$hostText = Get-Content (Join-Path $root "src\PiPManager.Wpf\Services\AppHostService.cs") -Raw
$monitor = Get-Content (Join-Path $root "src\PiPManager.Wpf\Services\WindowsEventMonitorService.cs") -Raw
$fake = Get-Content (Join-Path $root "src\PiPManager.Wpf\Services\FakeWindowEventMonitorSource.cs") -Raw
$health = Get-Content (Join-Path $root "src\PiPManager.Wpf\Services\ApplicationHealthService.cs") -Raw
$main = Get-Content (Join-Path $root "src\PiPManager.Wpf\MainWindow.xaml.cs") -Raw

foreach ($required in @(
  "AddSingleton<WindowsEventMonitorService>",
  "AddSingleton<IWindowEventMonitorService>",
  "AddHostedService(sp => sp.GetRequiredService<WindowsEventMonitorService>())",
  "AddSingleton<FakeWindowEventMonitorSource>"
)) {
  if (!$hostText.Contains($required)) {
    throw "Phase 3 missing Host registration: $required"
  }
}

foreach ($required in @(
  "SetWinEventHook",
  "HookEvents",
  "ResolveIdentityForDestroyedWindow",
  "RedactTitle(title, relevant)",
  "pip-title-or-pip-class",
  "MozillaDialogClass",
  "allHooks=true",
  "partial-hook-start",
  "ConcurrentDictionary<IntPtr, CachedWindowIdentity>",
  "TryMapEventKind",
  "UnhookWinEvent",
  "EVENT_OBJECT_CREATE",
  "EVENT_OBJECT_DESTROY",
  "EVENT_OBJECT_SHOW",
  "EVENT_OBJECT_HIDE",
  "EVENT_OBJECT_LOCATIONCHANGE",
  "EVENT_OBJECT_NAMECHANGE",
  "EVENT_SYSTEM_FOREGROUND",
  "ConcurrentQueue<WindowMonitorEvent>",
  "ConcurrentDictionary<string, DateTimeOffset>",
  "MarkPollingObserved",
  "window-event-monitor-event",
  "window-event-monitor-polling-compare"
)) {
  if (!$monitor.Contains($required)) {
    throw "Phase 3 monitor missing marker: $required"
  }
}

foreach ($required in @(
  "WindowEventHookActive",
  "LastWindowEvent",
  "WindowEventsReceived",
  "WindowEventsDiscarded",
  "LastWindowEventHookFailure",
  "SetWindowEventHookActive",
  "SetWindowEventTotals"
)) {
  if (!$health.Contains($required)) {
    throw "ApplicationHealthService missing window event marker: $required"
  }
}

foreach ($required in @(
  "FakeWindowEventMonitorSource",
  "EmitCreate",
  "EmitMove",
  "EmitDestroy",
  "RecordFakeEvent"
)) {
  if (!$fake.Contains($required)) {
    throw "Fake monitor source missing marker: $required"
  }
}

if (!$main.Contains("IWindowEventMonitorService windowEventMonitor") -or
    !$main.Contains("MarkPollingObserved(""health-timer-after-refresh-captured-windows"")")) {
  throw "MainWindow is not comparing polling with window events"
}

if (!(Test-Path (Join-Path $root "tests\PiPManager.WindowEventMonitor.Tests\PiPManager.WindowEventMonitor.Tests.csproj"))) {
  throw "WindowEventMonitor fake test project is missing"
}

Write-Host "Architecture Phase 3 checks OK."
