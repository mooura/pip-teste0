$ErrorActionPreference = "Stop"
$root = $PSScriptRoot

$releasePath = Join-Path $root "src\PiPManager.Wpf\Services\ReleaseInfoService.cs"
$manifestPath = Join-Path $root "src\PiPManager.Extension\manifest.json"
$release = Get-Content $releasePath -Raw
$manifest = Get-Content $manifestPath -Raw | ConvertFrom-Json

function Read-ReleaseConstant([string]$name) {
    $match = [regex]::Match($release, $name + '\s*=\s*"([^"]+)"')
    if (!$match.Success) { throw "Nao foi possivel ler $name em ReleaseInfoService.cs." }
    return $match.Groups[1].Value
}

$product = Read-ReleaseConstant "ProductVersion"
$app = Read-ReleaseConstant "AppVersion"
$extension = Read-ReleaseConstant "ExtensionVersion"
if ([string]$manifest.version -ne $extension) {
    throw "Versao da extensao divergente: release=$extension; manifest=$($manifest.version)."
}

$distRoot = Join-Path $root "DIST"
$dist = Join-Path $distRoot ("PiPManager_" + $product)
$publish = Join-Path $root "src\PiPManager.Wpf\bin\Release\net8.0-windows\win-x64\publish"
$exe = Join-Path $publish "PiPManager.Wpf.exe"
if (!(Test-Path $exe)) {
    throw "Publish final nao encontrado em $exe. Execute BUILD_WINDOWS.bat."
}

if (Test-Path $dist) { Remove-Item $dist -Recurse -Force }
New-Item -ItemType Directory -Force -Path $dist | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $dist "Extension") | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $dist "HISTORY") | Out-Null

Copy-Item (Join-Path $publish "*") $dist -Recurse -Force
Copy-Item (Join-Path $root "src\PiPManager.Extension\*") (Join-Path $dist "Extension") -Recurse -Force
Copy-Item (Join-Path $root "VERSION_STABLE.txt") $dist -Force
Copy-Item (Join-Path $root "FINAL_RELEASE_NOTES.md") $dist -Force
Copy-Item (Join-Path $root "VALIDACAO_FINAL_WINDOWS.md") $dist -Force
Copy-Item (Join-Path $root "LOCAL_VALIDATION_REPORT.md") $dist -Force
if (Test-Path (Join-Path $root "HISTORY")) {
    Copy-Item (Join-Path $root "HISTORY\*") (Join-Path $dist "HISTORY") -Recurse -Force
}

@"
PiP Manager Release
ProductVersion=$product
AppVersion=$app
ExtensionVersion=$extension
Core=net8.0
Mode=ReactorCompareDefault-ManagedLayoutDefault
NativeLayoutEngine=PiPManager.Native.dll ABI 100
Validation=RUN_CORE_TESTS.bat --ci passed before publish
GeneratedAt=$(Get-Date -Format o)
"@ | Set-Content -Encoding UTF8 (Join-Path $dist "README_RELEASE.txt")

$checksums = Join-Path $dist "CHECKSUMS_SHA256.txt"
Get-ChildItem $dist -Recurse -File |
    Where-Object { $_.Name -ne "CHECKSUMS_SHA256.txt" } |
    Sort-Object FullName |
    ForEach-Object {
        $hash = Get-FileHash $_.FullName -Algorithm SHA256
        $relative = $_.FullName.Substring($dist.Length + 1)
        "$($hash.Hash)  $relative"
    } |
    Set-Content -Encoding ASCII $checksums

Write-Host "DIST final criado: $dist"
