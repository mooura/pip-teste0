# Relatório de validação local — PiP Manager 9.39.03 RC3

Data: 2026-07-31

## Resultado

A RC3 foi preparada sobre a RC2 que partiu diretamente da Fix4 fornecida.
Todos os testes portáveis executáveis neste ambiente passaram.

## Base conferida

- Arquivo: `PIP_FIX4_preload_melhorado(3).zip`
- SHA-256:
  `77626c87607f280664dd33014d474a3a9b720c316eb0e4d29f443f5ffeb59d00`

## Casos de regressão adicionados

- comando confirmado continua exigindo vídeo novo aos 6.957 ms, mesmo com a
  correlação curta configurada em 2.200 ms;
- comando rejeitado não exige vídeo novo;
- comando ainda sem resposta conserva somente a correlação curta;
- duas amostras novas com `playing=true`, `hasSource=true` e `ended=false`
  comprovam reprodução ativa;
- uma amostra ou fonte ausente não liberam o gate;
- o resultado só atualiza um AutoReturn com o mesmo `operationId`.

## Evidência adicional do teste P0 no Windows

- nenhum `[ERROR]` foi registrado no log analisado;
- o reator manteve `dropped=0` nos lotes observados;
- capturas manuais e reconexões do AutoReturn foram confirmadas;
- os avisos repetidos de geometria inválida foram isolados a HWNDs já perdidos,
  preservados para recuperação;
- a RC3 exclui esses HWNDs do modelo físico do arraste e consolida a publicação
  dos totais de WinEvent em 250 ms.


## Evidência do bug de layout fixo e correção RC6

- o log mostrou `fixed-layout-window-constrained` sobre `FC26.exe`, removido da
  autoridade do layout fixo;
- o ciclo permaneceu 101.012 ms porque o timeout escalava por slots; agora a
  deadline é absoluta em 45.000 ms;
- uma troca do slot 9 para o slot 5 durante a recuperação não atualizava os
  conjuntos do ciclo; agora ambos são remapeados;
- o timeout executava `ApplyFixedLayoutToAllActive`, movendo todos os PiPs; agora
  apenas o HWND recuperado recebe uma aplicação move-only.

## Verificações aprovadas

- sintaxe de `background.js`, `content.js` e `site-profiles.js`;
- sintaxe dos arquivos C# alterados validada por parser independente;
- `tests/Extension.Tests/site-profiles.test.js`;
- `tests/Extension.Tests/tab-discovery.test.js`;
- `tests/Extension.Tests/navigation-transaction.test.js`;
- parsing JSON do manifesto;
- coerência de produto `9.39.03`, app `1.5.12.3909` e extensão `1.4.39.7`;
- presença dos quatro marcadores de telemetria e do contexto independente por
  `operationId`;
- diretório da extensão, núcleo nativo e superfícies de layout preservados sem
  alteração em relação à RC2;
- inclusão dos checks alterados no gate principal;
- revisão do diff funcional contra a candidata 9.39.02;
- integridade do núcleo nativo e das superfícies de layout preservadas.

## Superfície preservada por comparação binária

Os seguintes componentes permanecem byte a byte idênticos à candidata anterior:

- `src/PiPManager.Native` completo;
- `src/PiPManager.Wpf/MainWindow.Layout.cs`;
- `src/PiPManager.Wpf/MainWindow.xaml`;
- `src/PiPManager.Wpf/Services/PipWindowService.cs`;
- `src/PiPManager.Wpf/Services/NativeLayoutEngine.cs`.

SHA-256 da DLL nativa preservada:

```text
9d4526cc29827233ea73e7244217ef2980c738a499e35e74b857546cb285c219
```

## Gate pendente obrigatório

Este ambiente não contém .NET SDK, WPF, PowerShell nem Windows. Portanto ainda
precisam ser executados no Windows:

- compilação e publish do aplicativo WPF;
- `PiPManager.Core.Tests`, incluindo os novos casos;
- `PiPManager.WindowEventMonitor.Tests`;
- todos os checks PowerShell;
- teste real com navegador e janelas PiP.

Execute `BUILD_WINDOWS.bat` e depois `VALIDACAO_FINAL_WINDOWS.md`. A RC3 somente
deve ser promovida a release estável quando ambos passarem sem regressão.
