'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');
function assert(condition, message) { if (!condition) throw new Error(`TEST FAILED: ${message}`); }
const root = path.join(__dirname, '..', '..');
const content = fs.readFileSync(path.join(root, 'src', 'PiPManager.Extension', 'content.js'), 'utf8');
const background = fs.readFileSync(path.join(root, 'src', 'PiPManager.Extension', 'background.js'), 'utf8');
const main = fs.readFileSync(path.join(root, 'src', 'PiPManager.Wpf', 'MainWindow.xaml.cs'), 'utf8');
const bridge = fs.readFileSync(path.join(root, 'src', 'PiPManager.Wpf', 'Services', 'ExtensionBridgeService.cs'), 'utf8');
const autoState = fs.readFileSync(path.join(root, 'src', 'PiPManager.Wpf', 'Models', 'AutoReturnSlotState.cs'), 'utf8');
const videoTab = fs.readFileSync(path.join(root, 'src', 'PiPManager.Wpf', 'Models', 'VideoTabInfo.cs'), 'utf8');
const release = fs.readFileSync(path.join(root, 'src', 'PiPManager.Wpf', 'Services', 'ReleaseInfoService.cs'), 'utf8');
const runner = fs.readFileSync(path.join(root, 'RUN_CORE_TESTS.bat'), 'utf8');
const manifest = JSON.parse(fs.readFileSync(path.join(root, 'src', 'PiPManager.Extension', 'manifest.json'), 'utf8'));
assert(manifest.version === '1.4.39.25', 'manifest must be 1.4.39.25');
assert(release.includes('ExtensionVersion = "1.4.39.25"'), 'release metadata must be synchronized');
assert(content.includes("CONTENT_VERSION = '1.4.39.25-command-target-root-guard-hotfix10'"), 'content identifier must be synchronized');
assert(background.includes("BRIDGE_VERSION = '1.4.39.25-command-target-root-guard-hotfix10'"), 'background identifier must be synchronized');
assert(content.includes('function freezeNextCommandTarget('), 'immutable command target must exist');
assert(content.includes('function tryNavigateFrozenCommandTarget('), 'frozen command target must drive navigation');
assert(content.includes("previewState: 'STALE'"), 'command must stale the previous preview immediately');
assert(content.includes('if (commandTarget) markNextPreviewStaleForCommand(commandTarget);'), 'preview must become stale before any navigation strategy runs');
assert(content.includes("previewState: 'RESOLVING_TARGET'"), 'resolving target preview state must exist');
assert(content.includes("'READY_METADATA', 'READY_ANIMATED'"), 'ready preview states must gate rendering');
assert(content.includes('const NEXT_VIDEO_PRELOAD_TARGET_BUFFER_SECONDS = 10'), 'preload buffer target must be 10 seconds');
assert(content.includes('pipManagerNextOperationContextById'), 'diagnostic operation context must persist');
assert(background.includes('commandTarget'), 'background must forward command target');
assert(bridge.includes('commandTarget = commandTarget is null ? null'), 'WPF bridge must serialize command target');
assert(videoTab.includes('NextPreviewState') && videoTab.includes('NextTargetPageUrl'), 'WPF model must carry preview lifecycle and page URL');
assert(main.includes('ArmNextPreviewCommandBarrier('), 'WPF must clear stale preview at command start');
assert(main.includes('IsNextPreviewCommandBarrierActive('), 'WPF must keep preview empty until the new target resolves');
assert(main.includes('command-target-unresolved') && main.includes('NextPreviewCommandBarrierMaxAgeSeconds = 12'), 'unresolved commands must keep stale preview blocked with bounded expiry');
assert(main.includes('auto-return-same-video-fallback-blocked-command-generation'), 'same-video fallback must be blocked from command start');
assert(autoState.includes('BlockSameVideoFallback'), 'AutoReturn state must persist the command barrier');
assert(runner.includes('next-command-target-preview-hotfix3.test.js'), 'Hotfix 3 test must be wired');

function extractFunction(source, name) {
  const start = source.indexOf(`function ${name}(`);
  if (start < 0) throw new Error(`function ${name} not found`);
  const brace = source.indexOf('{', start);
  let depth = 0;
  let quote = '';
  let escaped = false;
  for (let i = brace; i < source.length; i += 1) {
    const ch = source[i];
    if (quote) {
      if (escaped) escaped = false;
      else if (ch === '\\') escaped = true;
      else if (ch === quote) quote = '';
      continue;
    }
    if (ch === '"' || ch === "'" || ch === '`') { quote = ch; continue; }
    if (ch === '{') depth += 1;
    else if (ch === '}') {
      depth -= 1;
      if (depth === 0) return source.slice(start, i + 1);
    }
  }
  throw new Error(`function ${name} is incomplete`);
}

const helperContext = {
  URL,
  Date,
  Object,
  Number,
  String,
  location: { href: 'https://pmvhaven.com/playlists/abc?index=3' },
  normalizeCandidateUrl: value => String(value || ''),
  extractMediaAssetId: value => (String(value || '').match(/[a-f0-9]{20,64}/i) || [''])[0]
};
vm.createContext(helperContext);
vm.runInContext(`${extractFunction(content, 'freezeNextCommandTarget')}\n${extractFunction(content, 'buildFrozenCommandNavigationUrl')}`, helperContext);
const frozen = helperContext.freezeNextCommandTarget({
  currentAssetId: 'aaaaaaaaaaaaaaaaaaaaaaaa',
  nextAssetId: 'bbbbbbbbbbbbbbbbbbbbbbbb',
  currentIndex: 3,
  nextIndex: 4,
  pageUrl: 'https://pmvhaven.com/video/bbbbbbbbbbbbbbbbbbbbbbbb',
  generation: 7,
  operationId: 'next-target-7-test'
});
assert(frozen && Object.isFrozen(frozen), 'command target must be frozen at runtime');
assert(frozen.nextAssetId === 'bbbbbbbbbbbbbbbbbbbbbbbb' && frozen.nextIndex === 4, 'frozen target must preserve asset and index');
assert(helperContext.buildFrozenCommandNavigationUrl(frozen) === 'https://pmvhaven.com/playlists/abc?index=4', 'playlist navigation must use the frozen next index');
assert(helperContext.freezeNextCommandTarget({ currentAssetId: 'aaaaaaaaaaaaaaaaaaaaaaaa', nextAssetId: 'aaaaaaaaaaaaaaaaaaaaaaaa', nextIndex: 4 }) === null, 'same-as-current command target must be rejected');
console.log('Immutable Command Target + Explicit Preview State Hotfix 3 tests: OK');
