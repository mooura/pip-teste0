$ErrorActionPreference = "Stop"
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$windows = Get-Content (Join-Path $root "src\PiPManager.Wpf\Services\PipWindowService.cs") -Raw
$main = Get-Content (Join-Path $root "src\PiPManager.Wpf\MainWindow.xaml.cs") -Raw
$release = Get-Content (Join-Path $root "src\PiPManager.Wpf\Services\ReleaseInfoService.cs") -Raw
$gate = Get-Content (Join-Path $root "RUN_CORE_TESTS.bat") -Raw

$checks = [ordered]@{
  "visual Compare has independent 250 ms sample clock" =
    $windows.Contains('_lastVisualCompareTickMs') -and
    $windows.Contains('NativeCompareSampleIntervalMs = 250') -and
    $windows.Contains('ShouldSampleComparison(ref _lastVisualCompareTickMs)')
  "raw Compare retains independent 250 ms sample clock" =
    $windows.Contains('_lastRawCompareTickMs') -and
    $windows.Contains('ShouldSampleComparison(ref _lastRawCompareTickMs)')
  "unsampled visual Compare skips native dry-run" =
    $windows.Contains('if (sampledComparison)') -and
    $windows.Contains('comparison = NativeEngine.ProcessVisualBatch') -and
    $windows.Contains('if (sampledComparison)') -and
    $windows.Contains('LogNativeComparison(operation, comparison, managedPrepared, source.Length)')
  "managed authority remains continuous in Compare" =
    $windows.Contains('ApplyManagedMoveAndResizeVisualBatch') -and
    $windows.Contains('ApplyManagedMoveVisualBatch')
  "toolbar group move builds one batch" =
    $main.Contains('var moves = new List<(IntPtr Handle, NativeRect Target)>(occupied.Length);') -and
    $main.Contains('moves.Add((slot.Window!.Handle, target));') -and
    $main.Contains('PipWindowService.MoveVisualBatch(moves, pixelThreshold: 0);')
  "toolbar group move no longer calls one native path per slot" =
    -not $main.Contains('PipWindowService.MoveVisual(slot.Window!.Handle, target.Left, target.Top);')
  "release is 9.39.01" =
    $release.Contains('ProductVersion = "9.39.01"') -and
    $release.Contains('AppVersion = "1.5.12.3901"')
  "build line records measured native retirement" =
    $release.Contains('Consolidation Block C: Unified Authority + Measured Native Retirement')
  "checker included in core gate" =
    $gate.Contains('CHECK_NATIVE_LAYOUT_ENGINE_PHASE1_1.ps1')
}

$failed = @()
foreach ($item in $checks.GetEnumerator()) {
  if ($item.Value) { Write-Host ($item.Key + ": OK") }
  else { Write-Host ($item.Key + ": FAIL"); $failed += $item.Key }
}
if ($failed.Count -gt 0) {
  throw ("Native Layout Engine Phase 1.1 checks failed: " + ($failed -join ", "))
}
Write-Host "Native Layout Engine Phase 1.1 checks OK."
