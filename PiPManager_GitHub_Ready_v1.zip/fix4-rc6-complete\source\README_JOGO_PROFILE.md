﻿# Perfil Jogo — 10 PiPs

## Forma padrão

Sem vídeos verticais, o perfil mantém a formação:

```text
[1][2][3][4][5][6]
               [7]
               [8]
               [9]
              [10]
```

## Trilho automático para vídeos de celular

No perfil **Jogo**, um PiP é classificado como vertical quando a proporção intrínseca do vídeo é menor que `0,90` (`videoWidth / videoHeight`).

Quando isso acontece:

- o PiP vertical sai automaticamente da faixa superior;
- ele é colocado no trilho lateral direito, encostado em `WorkArea.Right`;
- o próximo PiP horizontal disponível ocupa o espaço liberado na faixa superior;
- horizontais excedentes ficam primeiro na lateral;
- os PiPs verticais ficam nas últimas posições, na parte inferior do trilho, sempre alinhados pela borda direita;
- se o vídeo voltar ao formato horizontal, ele volta a disputar a faixa superior pela ordem original dos slots;
- a identidade do slot, o vínculo com a aba, o AutoReturn e os comandos do player não são trocados — somente a posição visual muda.

Exemplo: se o slot 3 ficar vertical e o slot 7 estiver horizontal:

```text
[1][2][4][5][6][7]
                  [3 vertical]
                  [8]
                  [9]
```

## Regras de encaixe

- Ao selecionar **Layout > Jogo**, o programa ajusta a quantidade para 10 slots.
- A primeira aplicação preserva os tamanhos atuais; o botão **Igualar** cria o início com tamanhos iguais.
- A mudança de proporção é confirmada em múltiplas leituras antes do refluxo, evitando formatos intermediários do Firefox.
- Com seis PiPs horizontais na faixa superior, o conjunto cresce ou reduz proporcionalmente para encostar nas bordas esquerda, superior e direita da área útil.
- O trilho lateral sempre termina exatamente na borda direita da área útil.
- Se a altura for o limite, o conjunto é reduzido proporcionalmente para não invadir a barra de tarefas.
- O perfil Jogo não usa a margem genérica de 8 px.

## Autoridade separada

O reflow do perfil Jogo usa uma autoridade própria. O reflow misto genérico continua estritamente `move-only`, preservando as dimensões confirmadas pelo navegador.


## Proporção intrínseca e bordas pretas

O perfil Jogo usa `HTMLVideoElement.videoWidth` e `videoHeight` como autoridade de proporção. A dimensão atual da janela PiP continua sendo lida pelo DWM para movimento e diagnóstico, mas não pode mais transformar artificialmente um vídeo horizontal em vertical.

- Cada alvo mantém a proporção real do stream.
- Vídeos verticais são classificados pelo conteúdo e vão para o trilho direito.
- Uma janela temporariamente deformada pelo navegador é corrigida para a proporção do conteúdo.
- Mudanças reais de resolução/proporção recebidas pela extensão disparam um reflow com debounce.
- A troca visual não altera slot, aba, sessão, comandos ou AutoReturn.

Depois de compilar, recarregue a extensão do Firefox para que os novos campos `intrinsicVideoWidth` e `intrinsicVideoHeight` sejam enviados ao aplicativo.


## Correção de Jogo + Fixar layout + Igualar

- **Fixar layout** não troca mais o perfil Jogo silenciosamente para Personalizado.
- **Igualar** usa a proporção intrínseca de cada vídeo e grava o resultado como única autoridade.
- O fiscalizador periódico compara somente posição porque sua operação é move-only.
- Diferenças de altura não geram mais uma correção a cada 250 ms.
- Ajustes manuais e arraste com o grupo travado terminam em uma única reconstrução do perfil Jogo, evitando deslocamento cumulativo.
## Correção do gate de autoridade fixa

O gate `CHECK_JOGO_FIXED_LAYOUT_AUTHORITY.ps1` analisa somente o método `EqualizeCaptured`. Isso evita confundir ramos de layout fixo pertencentes a outros métodos, sem reduzir a cobertura do caminho Jogo → proporção intrínseca → commit da autoridade → retorno antes da grade uniforme.


## Troca manual entre topo e lateral

No painel principal, arraste o cartão de um slot sobre o cartão de outro slot. No perfil **Jogo**, essa ação troca os conteúdos entre as duas posições visuais.

- Um PiP da lateral pode ser colocado no topo.
- Um PiP do topo pode ser colocado na lateral.
- A proporção intrínseca continua preservada, mesmo quando um vídeo vertical é colocado manualmente no topo.
- A escolha manual não é desfeita por **Igualar**, **Fixar layout**, mudança de proporção, AutoReturn ou reinicialização do programa.
- Antes da primeira troca manual, o perfil continua automático: até seis horizontais no topo, horizontais excedentes na lateral e verticais no fim da lateral.

A posição é vinculada ao número do slot. Por isso, a troca deve ser feita arrastando os cartões dos slots no PiP Manager, não arrastando a janela de vídeo diretamente.


## Correção de propriedade ao abrir todos

Durante **Abrir todos**, a operação agora possui autoridade física exclusiva sobre criação e captura de HWND. Reconexão inteligente e AutoReturn ficam temporariamente adiados até o fim do lote. A proteção usa o lock de abertura e o estado global do lote, não apenas o campo transitório de preparação, evitando que um slot offline capture a janela criada para outro slot.
