$ErrorActionPreference = "Stop"
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$main = Get-Content (Join-Path $root "src\PiPManager.Wpf\MainWindow.xaml.cs") -Raw

foreach ($required in @(
  "CancelAutoReturnPendingForSlot",
  "CancelAutoReturnPendingForDisabledSlots",
  "CancelAllAutoReturnPending",
  "auto-return-disabled-cancelled-pending",
  "auto-return-disabled",
  "ClearShadowReconnectAttemptForSlot(slotNumber, ""CancelAutoReturnPendingForSlot/",
  "_armedPipPairTimer.Stop()",
  "CancelAllAutoReturnPending(""AutoReturnTickAsync/all-slots-disabled"")",
  "CancelAutoReturnPendingForDisabledSlots(""AutoReturnTickAsync/disabled-slot-cleanup"")",
  "CancelAutoReturnPendingForSlot(slotNumber, ""slot-policy-disabled/"" + source)",
  "CancelAllAutoReturnPending(""all-slots-policy-disabled"")"
)) {
  if (!$main.Contains($required)) {
    throw "AutoReturn disable cancellation marker missing: $required"
  }
}

$methodStart = $main.IndexOf("private async Task AutoReturnTickAsync")
$methodEnd = $main.IndexOf("private VideoTabInfo? FindAutoReturnCandidate", $methodStart)
$method = $main.Substring($methodStart, $methodEnd - $methodStart)

$cancelIndex = $method.IndexOf("CancelAllAutoReturnPending(""AutoReturnTickAsync/all-slots-disabled"")")
$returnIndex = $method.IndexOf("return;", $method.IndexOf("if (!IsAnySlotAutoReturnEnabled())"))
if ($cancelIndex -lt 0 -or $returnIndex -lt 0 -or $cancelIndex -gt $returnIndex) {
  throw "AutoReturnTickAsync must cancel all pending states before returning when all slots are disabled"
}

Write-Host "AutoReturn disable cancellation checks OK."
