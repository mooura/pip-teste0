$ErrorActionPreference = "Stop"
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$main = Get-Content -Raw (Join-Path $root "src\PiPManager.Wpf\MainWindow.xaml.cs")
$fixed = Get-Content -Raw (Join-Path $root "src\PiPManager.Wpf\MainWindow.FixedLayout.cs")

$checks = [ordered]@{
  "reconnect position helper exists" = $main.Contains('RestoreReconnectedWindowPosition(')
  "restore uses the saved reference position outside fixed mode" = $main.Contains('PipWindowService.MoveVisual(newHandle, referenceRect.Left, referenceRect.Top)')
  "restore preserves browser size in every mode" = $main.Contains('fixedAuthorityPosition={fixedAuthorityPosition}; sizePreserved=True; resize=False') -and -not $main.Contains('PipWindowService.MoveAndResizeVisual(newHandle, referenceRect)')
  "fixed layout restores position without forcing size" = $main.Contains('PipWindowService.MoveVisual(newHandle, referenceRect.Left, referenceRect.Top)') -and $fixed.Contains('ResolveReconnectGeometryTarget')
  "Firefox late position change is verified once" = $main.Contains('VerifyReconnectedWindowPositionAsync') -and $main.Contains('Task.Delay(220)') -and $main.Contains('phase=verify-220ms')
  "delayed verification remains bound to the same slot and HWND" = $main.Contains('slot.Window.Handle != newHandle') -and $main.Contains('reason=slot-or-hwnd-changed')
  "stable capture replacement restores position" = $main.Contains('RestoreReconnectedWindowPosition(slot, handle, replacement.Handle, reconnectReference, "CapturePipsStable")')
  "intelligent reconnect restores position" = $main.Contains('RestoreReconnectedWindowPosition(slot, oldHandle, replacement.Handle, reconnectReference, $"ApplyIntelligentReconnect/{source}")')
  "monitor reconnect restores position" = $main.Contains('RestoreReconnectedWindowPosition(slot, handle, replacement.Handle, reconnectReference, $"TryReconnectSlotWindow/{source}")')
  "prepared AutoReturn capture restores position before layout persistence" = $main.Contains('RestoreReconnectedWindowPosition(slot, oldHandle, newWindow.Handle, reconnectReference, "CapturePreparedPipWindow")')
}

$failed = @()
foreach ($item in $checks.GetEnumerator()) {
  if ($item.Value) { Write-Host ($item.Key + ": OK") }
  else { Write-Host ($item.Key + ": FAIL"); $failed += $item.Key }
}

if ($failed.Count -gt 0) {
  throw "Reconnect position restore checks failed: $($failed -join ', ')"
}

Write-Host "Reconnect position restore checks OK."
