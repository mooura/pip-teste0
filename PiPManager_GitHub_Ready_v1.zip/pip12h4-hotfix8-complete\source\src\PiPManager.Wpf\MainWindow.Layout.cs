﻿using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Markup;
using PiPManager.Wpf.Models;
using PiPManager.Wpf.Services;

namespace PiPManager.Wpf;

public partial class MainWindow
{
    private bool _editorSlotDragChanged;
    private readonly Dictionary<int, double> _slotIntrinsicContentAspectRatios = [];
    private bool _jogoManualPlacementEnabled;
    private readonly List<int> _jogoVisualSlotOrder = [];
    private readonly HashSet<int> _jogoTopSlotNumbers = [];
    private bool _jogoFreeAreaEnabled;
    private double _jogoLayoutScale = 0.85;
    private double _jogoTopWidthRatio;
    private double _jogoSideWidthRatio;
    private bool _suppressJogoFreeAreaMenuEvents;
    private const int JogoTopRowCapacity = 6;
    private const double JogoPortraitContentThreshold = 0.90;
    private const double JogoMinimumLayoutScale = 0.55;
    private const double JogoMaximumLayoutScale = 1.00;
    private const double JogoLayoutScaleStep = 0.05;
    private const double JogoMinimumGroupWidthRatio = 0.04;
    private void EnsureSlotLayoutRects()
    {
        if (_slotLayoutRects.Count == Slots.Count) return;

        var sourceRects = _slotLayoutRects.Where(rect => rect.IsValid).ToList();
        if (sourceRects.Count == 0)
            sourceRects = CreateDefaultSlotLayout(Slots.Count).ToList();

        if (sourceRects.Count < Slots.Count)
        {
            var fillRects = _layoutService.BuildLayoutRects(sourceRects, CurrentLayout, GetBounds(sourceRects));
            sourceRects = fillRects.ToList();
        }

        _slotLayoutRects = sourceRects.Take(Slots.Count).ToList();
        if (_slotLayoutRects.Count < Slots.Count)
            _slotLayoutRects = CreateDefaultSlotLayout(Slots.Count).ToList();
    }

    private IReadOnlyList<NativeRect> CreateDefaultSlotLayout(int count)
    {
        var screen = PipWindowService.GetVirtualScreenBounds();
        var baseRects = Enumerable.Range(0, count)
            .Select(_ => new NativeRect(screen.Right - 340, screen.Top + 70, screen.Right - 80, screen.Top + 220))
            .ToArray();
        return _layoutService.BuildLayoutRects(baseRects, CurrentLayout, new NativeRect(screen.Right - 540, screen.Top + 70, screen.Right - 80, screen.Top + 220));
    }

    private IReadOnlyList<NativeRect> GetReferenceRects()
    {
        var activeRects = Slots.Where(slot => slot.Window is not null)
            .Select(slot => PipWindowService.GetVisualRect(slot.Window!.Handle))
            .Where(rect => rect.IsValid)
            .ToArray();

        if (activeRects.Length == Slots.Count(slot => slot.Window is not null) && activeRects.Length > 0)
            return activeRects;

        EnsureSlotLayoutRects();
        return _slotLayoutRects.Count > 0 ? _slotLayoutRects : CreateDefaultSlotLayout(Slots.Count);
    }

    private PipSlot? GetEqualizeReferenceSlot(IReadOnlyList<PipSlot> occupied)
    {
        if (_lastManuallyResizedSlotNumber is int lastNumber)
        {
            var lastResized = occupied.FirstOrDefault(slot => slot.Number == lastNumber);
            if (lastResized is not null)
                return lastResized;
        }

        if (SelectedSlot is not null && occupied.Contains(SelectedSlot))
            return SelectedSlot;

        return occupied.LastOrDefault();
    }

    private NativeRect GetSlotLayoutBounds() => GetBounds(_slotLayoutRects);

    private static NativeRect GetBounds(IReadOnlyList<NativeRect> rects)
    {
        var valid = rects.Where(rect => rect.IsValid).ToArray();
        return valid.Length == 0
            ? default
            : new NativeRect(valid.Min(rect => rect.Left), valid.Min(rect => rect.Top), valid.Max(rect => rect.Right), valid.Max(rect => rect.Bottom));
    }



    private void CaptureCurrentRectsIntoSlotLayout()
    {
        var occupiedSlots = GetOccupiedSlotsInNumberOrder();
        var occupied = new List<NativeRect>();

        foreach (var slot in occupiedSlots)
        {
            if (slot.Window is null) continue;
            if (_lockedGroupModelRects.TryGetValue(slot.Window.Handle, out var modelRect) && modelRect.IsValid)
                occupied.Add(modelRect);
            else
            {
                var rect = PipWindowService.GetVisualRect(slot.Window.Handle);
                if (rect.IsValid) occupied.Add(rect);
            }
        }

        if (occupied.Count > 0)
            _slotLayoutRects = occupied;
    }

    private void HideCustomModeEditor()
    {
        SlotsList.Visibility = Visibility.Visible;
        FreeSlotsOverlay.Visibility = Visibility.Collapsed;
        CustomModeButton.IsEnabled = true;
    }

    private void ShowCustomModeEditor()
    {
        SyncEditableSlotStates();
        SlotsList.Visibility = Visibility.Collapsed;
        FreeSlotsOverlay.Visibility = Visibility.Visible;
        CustomModeButton.IsEnabled = true;
    }

    private PipSlot[] GetOccupiedSlotsInNumberOrder() =>
        Slots.Where(slot => slot.Window is not null).OrderBy(slot => slot.Number).ToArray();

    private void ApplyTargetsToOccupiedSlots(IReadOnlyList<PipSlot> slots, IReadOnlyList<NativeRect> targets, bool resizeToTargets)
    {
        var count = Math.Min(slots.Count, targets.Count);
        if (count == 0) return;

        var generation = BeginLayoutTransaction(resizeToTargets ? "apply-targets-resize" : "apply-targets-move");
        try
        {
            var effectiveTargets = Enumerable.Range(0, count)
                .Select(index => ClampLayoutTargetToGeometryAuthority(
                    slots[index],
                    targets[index],
                    resizeToTargets ? "apply-targets-resize" : "apply-targets-move"))
                .ToArray();
            var batch = Enumerable.Range(0, count)
                .Where(index => slots[index].Window is not null && effectiveTargets[index].IsValid)
                .Select(index => (Handle: slots[index].Window!.Handle, Target: effectiveTargets[index]))
                .ToArray();

            // Firefox emits delayed LOCATIONCHANGE waves after its internal aspect-ratio pass.
            // Arm the shared gate before moving the HWNDs so those internal waves never reach
            // Reactor, Shadow, polling comparison or the WPF Dispatcher.
            var movementSuppressionMs = resizeToTargets ? 3200 : 1800;
            var flowBefore = _windowEventFlowControl.GetSnapshot();
            _windowEventFlowControl.ArmInternalMovementSuppression(
                batch.Select(item => item.Handle),
                generation,
                TimeSpan.FromMilliseconds(movementSuppressionMs),
                resizeToTargets ? "layout-resize" : "layout-move");
            QueueLayoutMovementSuppressionSummary(
                generation,
                movementSuppressionMs,
                flowBefore.SuppressedInternalMovements,
                batch.Length,
                resizeToTargets);
            AppLogger.Info($"layout-movement-suppression-armed: generation={generation}; windows={batch.Length}; resize={resizeToTargets}; durationMs={movementSuppressionMs}");

            if (resizeToTargets)
                PipWindowService.MoveAndResizeVisualBatch(batch, pixelThreshold: 1);
            else
                PipWindowService.MoveVisualBatch(batch, pixelThreshold: 1);

            var appliedRects = new List<NativeRect>(count);
            for (var index = 0; index < count; index++)
            {
                var slot = slots[index];
                var target = effectiveTargets[index];
                if (slot.Window is not null && target.IsValid)
                {
                    var applied = resizeToTargets
                        ? target
                        : PipWindowService.GetVisualRect(slot.Window.Handle);
                    if (!applied.IsValid)
                        applied = new NativeRect(
                            target.Left,
                            target.Top,
                            target.Left + slot.Window.VisualRect.Width,
                            target.Top + slot.Window.VisualRect.Height);
                    slot.RefreshWindow(slot.Window with { VisualRect = applied });
                    appliedRects.Add(applied);
                }
            }

            _lastKnownGroupBounds = GetBounds(appliedRects);
            EnsureVisiblePipsTopMost(force: true);
            PositionToolbar();
            SyncEditableSlotStates();
            SaveSettings();
            AppLogger.Info($"layout-atomic-batch-applied: generation={generation}; windows={batch.Length}; resize={resizeToTargets}; bounds={_lastKnownGroupBounds}");
        }
        finally
        {
            EndLayoutTransaction(generation, "apply-targets-complete");
        }
    }


    private async Task LogLayoutMovementSuppressionSummaryAsync(
        int summaryGeneration,
        int layoutGeneration,
        int durationMs,
        long suppressedBefore,
        int windowCount,
        bool resizeToTargets)
    {
        await Task.Delay(durationMs + 150).ConfigureAwait(false);
        var after = _windowEventFlowControl.GetSnapshot();
        var suppressed = Math.Max(0, after.SuppressedInternalMovements - suppressedBefore);
        AppLogger.Info(
            $"layout-movement-suppression-summary: summaryGeneration={summaryGeneration}; layoutGeneration={layoutGeneration}; " +
            $"windows={windowCount}; resize={resizeToTargets}; durationMs={durationMs}; suppressedMovements={suppressed}; " +
            $"remainingArmedHandles={after.ArmedHandles}");
    }

    private void QueueLayoutMovementSuppressionSummary(
        int layoutGeneration,
        int durationMs,
        long suppressedBefore,
        int windowCount,
        bool resizeToTargets)
    {
        var summaryGeneration = Interlocked.Increment(ref _layoutSuppressionSummaryGeneration);
        _ = LogLayoutMovementSuppressionSummaryAsync(
            summaryGeneration,
            layoutGeneration,
            durationMs,
            suppressedBefore,
            windowCount,
            resizeToTargets);
    }

    private VideoTabInfo? ResolvePairedVideoTabForAspect(int slotNumber)
    {
        var tabs = _videoTabCache.Values.Select(value => value.Tab).ToArray();
        if (tabs.Length == 0) return null;

        _slotVideoPairs.TryGetValue(slotNumber, out var pairKey);
        _slotStableVideoPairs.TryGetValue(slotNumber, out var stableKey);
        _slotPairedTabIds.TryGetValue(slotNumber, out var tabId);

        if (!string.IsNullOrWhiteSpace(pairKey))
        {
            var exactSession = tabs
                .Where(tab => string.Equals(tab.VideoSessionId, pairKey, StringComparison.OrdinalIgnoreCase)
                    || string.Equals(tab.PairKey, pairKey, StringComparison.OrdinalIgnoreCase))
                .ToArray();
            if (exactSession.Length == 1)
                return exactSession[0];
        }

        if (!string.IsNullOrWhiteSpace(stableKey))
        {
            var stableMatches = tabs
                .Where(tab => string.Equals(tab.StableVideoKey, stableKey, StringComparison.OrdinalIgnoreCase)
                    && (tabId <= 0 || tab.TabId == tabId))
                .ToArray();
            if (stableMatches.Length == 1)
                return stableMatches[0];
        }

        if (tabId > 0)
        {
            var sameTab = tabs.Where(tab => tab.TabId == tabId).ToArray();
            if (sameTab.Length == 1)
                return sameTab[0];
        }

        return null;
    }

    private double ResolveSlotIntrinsicContentAspect(PipSlot slot, NativeRect fallbackRect)
    {
        var tab = ResolvePairedVideoTabForAspect(slot.Number);
        var intrinsicAspect = tab?.IntrinsicAspectRatio ?? 0.0;
        if (double.IsFinite(intrinsicAspect) && intrinsicAspect >= 0.20 && intrinsicAspect <= 6.00)
        {
            _slotIntrinsicContentAspectRatios[slot.Number] = intrinsicAspect;
            return intrinsicAspect;
        }

        if (_slotIntrinsicContentAspectRatios.TryGetValue(slot.Number, out var cached)
            && double.IsFinite(cached)
            && cached >= 0.20
            && cached <= 6.00)
            return cached;

        return fallbackRect.IsValid && fallbackRect.Height > 0
            ? Math.Clamp(fallbackRect.Width / (double)fallbackRect.Height, 0.20, 6.00)
            : 16.0 / 9.0;
    }

    private double[] ResolveJogoIntrinsicContentAspects(
        IReadOnlyList<PipSlot> occupied,
        IReadOnlyList<NativeRect> sourceRects)
    {
        var output = new double[occupied.Count];
        for (var i = 0; i < occupied.Count; i++)
            output[i] = ResolveSlotIntrinsicContentAspect(occupied[i], sourceRects[i]);
        return output;
    }

    private void InitializeJogoFreeAreaAdjustment()
    {
        _jogoFreeAreaEnabled = _settings.JogoFreeAreaEnabled;
        _jogoLayoutScale = NormalizeJogoLayoutScale(_settings.JogoLayoutScale);
        _jogoTopWidthRatio = NormalizeJogoGroupWidthRatio(_settings.JogoTopWidthRatio);
        _jogoSideWidthRatio = NormalizeJogoGroupWidthRatio(_settings.JogoSideWidthRatio);
        UpdateJogoFreeAreaUi();
    }

    private static double NormalizeJogoLayoutScale(double value)
        => double.IsFinite(value)
            ? Math.Clamp(value, JogoMinimumLayoutScale, JogoMaximumLayoutScale)
            : 0.85;

    private static double NormalizeJogoGroupWidthRatio(double value)
        => double.IsFinite(value) && value >= JogoMinimumGroupWidthRatio
            ? Math.Clamp(value, JogoMinimumGroupWidthRatio, 1.0)
            : 0.0;

    private double ResolveJogoLayoutScale()
        => _jogoFreeAreaEnabled ? NormalizeJogoLayoutScale(_jogoLayoutScale) : 1.0;

    private double ResolveJogoTopWidthRatio()
        => _jogoFreeAreaEnabled ? NormalizeJogoGroupWidthRatio(_jogoTopWidthRatio) : 0.0;

    private double ResolveJogoSideWidthRatio()
        => _jogoFreeAreaEnabled ? NormalizeJogoGroupWidthRatio(_jogoSideWidthRatio) : 0.0;

    private int JogoLayoutScalePercent
        => (int)Math.Round(ResolveJogoLayoutScale() * 100.0);

    private int JogoTopWidthPercent
        => (int)Math.Round(NormalizeJogoGroupWidthRatio(_jogoTopWidthRatio) * 100.0);

    private int JogoSideWidthPercent
        => (int)Math.Round(NormalizeJogoGroupWidthRatio(_jogoSideWidthRatio) * 100.0);

    private string JogoFreeAreaText
    {
        get
        {
            var top = JogoTopWidthPercent > 0 ? $"Topo {JogoTopWidthPercent}%" : "Topo automático";
            var side = JogoSideWidthPercent > 0 ? $"Lateral {JogoSideWidthPercent}%" : "Lateral automática";
            return $"{top} • {side}";
        }
    }

    private void UpdateJogoFreeAreaUi()
    {
        if (JogoFreeAreaMenuItem is null)
            return;

        _suppressJogoFreeAreaMenuEvents = true;
        try
        {
            var isJogo = CurrentLayout == LayoutMode.Jogo;
            var effectivePercent = JogoLayoutScalePercent;
            JogoFreeAreaMenuItem.IsEnabled = isJogo;
            JogoFreeAreaMenuItem.Header = _jogoFreeAreaEnabled
                ? $"Jogo livre — {JogoFreeAreaText}"
                : "Jogo livre — Automático";
            JogoFreeAreaEnabledMenuItem.IsChecked = _jogoFreeAreaEnabled;
            JogoFreeAreaScaleStatusMenuItem.Header = _jogoFreeAreaEnabled
                ? $"Escala conjunta: {effectivePercent}%"
                : "Escala conjunta: automático (100%)";
            JogoTopGroupStatusMenuItem.Header = JogoTopWidthPercent > 0
                ? $"Grupo superior: largura {JogoTopWidthPercent}% da tela"
                : "Grupo superior: tamanho automático";
            JogoSideGroupStatusMenuItem.Header = JogoSideWidthPercent > 0
                ? $"Grupo lateral: largura {JogoSideWidthPercent}% da tela"
                : "Grupo lateral: tamanho automático";
            JogoResetTopGroupMenuItem.IsEnabled = isJogo && JogoTopWidthPercent > 0;
            JogoResetSideGroupMenuItem.IsEnabled = isJogo && JogoSideWidthPercent > 0;
            JogoMoreFreeAreaMenuItem.IsEnabled = isJogo
                && (!_jogoFreeAreaEnabled || _jogoLayoutScale > JogoMinimumLayoutScale + 0.001);
            JogoLessFreeAreaMenuItem.IsEnabled = isJogo
                && (!_jogoFreeAreaEnabled || _jogoLayoutScale < JogoMaximumLayoutScale - 0.001);
            JogoMaximumSizeMenuItem.IsEnabled = isJogo
                && (!_jogoFreeAreaEnabled || _jogoLayoutScale < JogoMaximumLayoutScale - 0.001);
            JogoAutomaticAreaMenuItem.IsEnabled = isJogo && _jogoFreeAreaEnabled;
        }
        finally
        {
            _suppressJogoFreeAreaMenuEvents = false;
        }
    }

    private void JogoFreeAreaEnabledMenuItem_Click(object sender, RoutedEventArgs e)
    {
        if (_suppressJogoFreeAreaMenuEvents)
            return;

        _jogoFreeAreaEnabled = JogoFreeAreaEnabledMenuItem.IsChecked;
        ApplyJogoFreeAreaAdjustment("toggle");
    }

    private void JogoMoreFreeAreaMenuItem_Click(object sender, RoutedEventArgs e)
        => ChangeJogoLayoutScale(-JogoLayoutScaleStep, "more-free-area");

    private void JogoLessFreeAreaMenuItem_Click(object sender, RoutedEventArgs e)
        => ChangeJogoLayoutScale(JogoLayoutScaleStep, "less-free-area");

    private void JogoMaximumSizeMenuItem_Click(object sender, RoutedEventArgs e)
    {
        _jogoFreeAreaEnabled = true;
        _jogoLayoutScale = JogoMaximumLayoutScale;
        _jogoTopWidthRatio = 0.0;
        _jogoSideWidthRatio = 0.0;
        ApplyJogoFreeAreaAdjustment("maximum-pip-size");
    }

    private void JogoResetTopGroupMenuItem_Click(object sender, RoutedEventArgs e)
    {
        _jogoTopWidthRatio = 0.0;
        ApplyJogoFreeAreaAdjustment("reset-top-group");
    }

    private void JogoResetSideGroupMenuItem_Click(object sender, RoutedEventArgs e)
    {
        _jogoSideWidthRatio = 0.0;
        ApplyJogoFreeAreaAdjustment("reset-side-group");
    }

    private void JogoAutomaticAreaMenuItem_Click(object sender, RoutedEventArgs e)
    {
        _jogoFreeAreaEnabled = false;
        _jogoLayoutScale = JogoMaximumLayoutScale;
        _jogoTopWidthRatio = 0.0;
        _jogoSideWidthRatio = 0.0;
        ApplyJogoFreeAreaAdjustment("automatic");
    }

    private void ChangeJogoLayoutScale(double delta, string source)
    {
        if (!_jogoFreeAreaEnabled)
            _jogoFreeAreaEnabled = true;

        _jogoLayoutScale = NormalizeJogoLayoutScale(_jogoLayoutScale + delta);
        ApplyJogoFreeAreaAdjustment(source);
    }

    private void ApplyJogoFreeAreaAdjustment(string source)
    {
        UpdateJogoFreeAreaUi();
        RefreshLayoutText();
        SaveSettings();

        if (CurrentLayout == LayoutMode.Jogo
            && Slots.Any(slot => slot.Window is not null && PipWindowService.IsUsable(slot.Window.Handle)))
        {
            var occupied = GetOccupiedSlotsInNumberOrder()
                .Where(slot => slot.Window is not null && PipWindowService.IsUsable(slot.Window.Handle))
                .ToArray();
            var sourceRects = occupied
                .Select(slot => PipWindowService.GetVisualRect(slot.Window!.Handle))
                .ToArray();
            var workArea = GetSelectedLayoutMonitor()?.WorkArea
                ?? PipWindowService.GetVirtualScreenBounds();
            if (sourceRects.Length == occupied.Length && sourceRects.All(rect => rect.IsValid))
            {
                var targets = BuildJogoContentAwareTargets(occupied, sourceRects, workArea).ToArray();
                if (targets.Length == occupied.Length && targets.All(rect => rect.IsValid))
                {
                    ApplyTargetsToOccupiedSlots(occupied, targets, resizeToTargets: true);
                    CaptureCurrentRectsIntoSlotLayout();
                    CommitJogoTargetsAsFixedAuthority(occupied, targets, source);
                    SaveLockedGroupModel(occupied, targets);
                    _lastKnownGroupBounds = GetBounds(targets);
                    PositionToolbar();
                    RefreshPipDragTargets();
                }
            }
        }

        var percent = JogoLayoutScalePercent;
        SetStatus(_jogoFreeAreaEnabled
            ? $"Jogo livre aplicado: PiPs em {percent}% — área livre ajustável"
            : "Perfil Jogo automático restaurado");
        AppLogger.Info(
            $"jogo-free-area-adjusted: source={source}; enabled={_jogoFreeAreaEnabled}; " +
            $"scale={ResolveJogoLayoutScale():0.00}; percent={percent}; " +
            $"topWidthRatio={NormalizeJogoGroupWidthRatio(_jogoTopWidthRatio):0.000}; " +
            $"sideWidthRatio={NormalizeJogoGroupWidthRatio(_jogoSideWidthRatio):0.000}; anchor=top-right; " +
            "dualGroupAuthority=True; intrinsicAspectPreserved=True; fixedAuthorityRefreshed=True");
    }

    private HashSet<int> ResolveJogoTopGroupSlotNumbers(
        IReadOnlyList<PipSlot> occupied,
        IReadOnlyList<NativeRect> sourceRects)
        => ResolveJogoVisualGroups(occupied, sourceRects)
            .Top
            .Select(slot => slot.Number)
            .ToHashSet();

    private (PipSlot[] Top, PipSlot[] Side) ResolveJogoVisualGroups(
        IReadOnlyList<PipSlot> occupied,
        IReadOnlyList<NativeRect> sourceRects)
    {
        if (occupied.Count == 0 || occupied.Count != sourceRects.Count)
            return ([], []);

        if (_jogoManualPlacementEnabled)
        {
            ReconcileJogoManualPlacementSlots();
            var occupiedByNumber = occupied.ToDictionary(slot => slot.Number);
            var ordered = _jogoVisualSlotOrder
                .Where(occupiedByNumber.ContainsKey)
                .Select(number => occupiedByNumber[number])
                .ToList();
            ordered.AddRange(occupied.Where(slot => ordered.All(item => item.Number != slot.Number)));

            var top = ordered
                .Where(slot => _jogoTopSlotNumbers.Contains(slot.Number))
                .Take(JogoTopRowCapacity)
                .ToArray();
            var topNumbers = top.Select(slot => slot.Number).ToHashSet();
            var side = ordered.Where(slot => !topNumbers.Contains(slot.Number)).ToArray();
            return (top, side);
        }

        var aspects = ResolveJogoIntrinsicContentAspects(occupied, sourceRects);
        var indexed = occupied
            .Select((slot, index) => new
            {
                Slot = slot,
                Aspect = aspects[index],
                IsPortrait = aspects[index] < JogoPortraitContentThreshold
            })
            .ToArray();
        var landscape = indexed.Where(item => !item.IsPortrait).ToArray();
        var portrait = indexed.Where(item => item.IsPortrait).ToArray();
        return (
            landscape.Take(JogoTopRowCapacity).Select(item => item.Slot).ToArray(),
            landscape.Skip(JogoTopRowCapacity).Concat(portrait).Select(item => item.Slot).ToArray());
    }

    private IReadOnlyList<NativeRect> BuildJogoReferenceGroupEqualizeTargets(
        IReadOnlyList<PipSlot> occupied,
        IReadOnlyList<NativeRect> sourceRects,
        PipSlot reference,
        NativeRect workArea,
        out bool referenceIsTop)
    {
        referenceIsTop = false;
        if (occupied.Count == 0
            || occupied.Count != sourceRects.Count
            || !workArea.IsValid
            || sourceRects.Any(rect => !rect.IsValid))
            return [];

        var groups = ResolveJogoVisualGroups(occupied, sourceRects);
        referenceIsTop = groups.Top.Any(slot => slot.Number == reference.Number);
        var referenceGroup = referenceIsTop ? groups.Top : groups.Side;
        if (referenceGroup.Length == 0)
            return [];

        var inputIndexBySlot = occupied
            .Select((slot, index) => new { slot.Number, Index = index })
            .ToDictionary(item => item.Number, item => item.Index);
        if (!inputIndexBySlot.TryGetValue(reference.Number, out var referenceIndex))
            return [];

        var referenceRect = sourceRects[referenceIndex];
        var sizes = occupied.ToDictionary(
            slot => slot.Number,
            slot =>
            {
                var rect = sourceRects[inputIndexBySlot[slot.Number]];
                return (Width: Math.Max(1, rect.Width), Height: Math.Max(1, rect.Height));
            });

        var targetWidth = Math.Max(1, referenceRect.Width);
        var targetHeight = Math.Max(1, referenceRect.Height);
        double fitScale;
        if (referenceIsTop)
        {
            var sideHeight = groups.Side.Sum(slot => sizes[slot.Number].Height);
            var availableTopHeight = Math.Max(1, workArea.Height - sideHeight);
            var maximumTopWidth = Math.Max(1, workArea.Width / Math.Max(1, groups.Top.Length));
            fitScale = Math.Min(
                1.0,
                Math.Min(
                    maximumTopWidth / (double)targetWidth,
                    availableTopHeight / (double)targetHeight));
        }
        else
        {
            var topHeight = groups.Top.Length == 0
                ? 0
                : groups.Top.Max(slot => sizes[slot.Number].Height);
            var availableSideHeight = Math.Max(1, workArea.Height - topHeight);
            var maximumSideHeight = Math.Max(1, availableSideHeight / Math.Max(1, groups.Side.Length));
            fitScale = Math.Min(
                1.0,
                Math.Min(
                    workArea.Width / (double)targetWidth,
                    maximumSideHeight / (double)targetHeight));
        }

        targetWidth = Math.Max(1, (int)Math.Round(targetWidth * fitScale));
        targetHeight = Math.Max(1, (int)Math.Round(targetHeight * fitScale));
        foreach (var slot in referenceGroup)
            sizes[slot.Number] = (targetWidth, targetHeight);

        var output = new NativeRect[occupied.Count];
        var topTotalWidth = groups.Top.Sum(slot => sizes[slot.Number].Width);
        var x = Math.Max(workArea.Left, workArea.Right - topTotalWidth);
        var topRowHeight = 0;
        foreach (var slot in groups.Top)
        {
            var size = sizes[slot.Number];
            var right = Math.Min(workArea.Right, x + size.Width);
            var bottom = Math.Min(workArea.Bottom, workArea.Top + size.Height);
            output[inputIndexBySlot[slot.Number]] = new NativeRect(
                x,
                workArea.Top,
                Math.Max(x + 1, right),
                Math.Max(workArea.Top + 1, bottom));
            topRowHeight = Math.Max(topRowHeight, bottom - workArea.Top);
            x = right;
        }

        var y = workArea.Top + topRowHeight;
        foreach (var slot in groups.Side)
        {
            var size = sizes[slot.Number];
            var left = Math.Max(workArea.Left, workArea.Right - size.Width);
            var bottom = Math.Min(workArea.Bottom, y + size.Height);
            output[inputIndexBySlot[slot.Number]] = new NativeRect(
                left,
                y,
                workArea.Right,
                Math.Max(y + 1, bottom));
            y = bottom;
        }

        return output;
    }

    private void InitializeJogoManualPlacement()
    {
        _jogoManualPlacementEnabled = _settings.JogoManualPlacementEnabled;
        _jogoVisualSlotOrder.Clear();
        _jogoVisualSlotOrder.AddRange(
            (_settings.JogoVisualSlotOrder ?? [])
                .Where(number => number >= 1 && number <= Slots.Count)
                .Distinct());

        _jogoTopSlotNumbers.Clear();
        foreach (var number in (_settings.JogoTopSlots ?? [])
                     .Where(number => number >= 1 && number <= Slots.Count)
                     .Distinct())
            _jogoTopSlotNumbers.Add(number);

        ReconcileJogoManualPlacementSlots();
    }

    private void ReconcileJogoManualPlacementSlots()
    {
        var validNumbers = Slots
            .Select(slot => slot.Number)
            .OrderBy(number => number)
            .ToArray();
        var validSet = validNumbers.ToHashSet();

        var normalizedOrder = _jogoVisualSlotOrder
            .Where(validSet.Contains)
            .Distinct()
            .ToList();
        normalizedOrder.AddRange(validNumbers.Where(number => !normalizedOrder.Contains(number)));
        _jogoVisualSlotOrder.Clear();
        _jogoVisualSlotOrder.AddRange(normalizedOrder);

        _jogoTopSlotNumbers.RemoveWhere(number => !validSet.Contains(number));
        if (_jogoTopSlotNumbers.Count > JogoTopRowCapacity)
        {
            var keep = _jogoVisualSlotOrder
                .Where(_jogoTopSlotNumbers.Contains)
                .Take(JogoTopRowCapacity)
                .ToHashSet();
            _jogoTopSlotNumbers.RemoveWhere(number => !keep.Contains(number));
        }

        if (_jogoManualPlacementEnabled && _jogoVisualSlotOrder.Count == 0)
            _jogoManualPlacementEnabled = false;
    }

    private void EnableJogoManualPlacementFromCurrentTopology(
        IReadOnlyList<PipSlot> occupied,
        IReadOnlyList<NativeRect> sourceRects,
        string source)
    {
        if (_jogoManualPlacementEnabled)
        {
            ReconcileJogoManualPlacementSlots();
            return;
        }

        if (occupied.Count == 0 || occupied.Count != sourceRects.Count)
            return;

        var aspects = ResolveJogoIntrinsicContentAspects(occupied, sourceRects);
        var indexed = occupied
            .Select((slot, index) => new
            {
                SlotNumber = slot.Number,
                Aspect = aspects[index],
                IsPortrait = aspects[index] < JogoPortraitContentThreshold
            })
            .ToArray();
        var landscape = indexed.Where(item => !item.IsPortrait).ToArray();
        var portrait = indexed.Where(item => item.IsPortrait).ToArray();
        var top = landscape.Take(JogoTopRowCapacity).ToArray();
        var side = landscape.Skip(JogoTopRowCapacity).Concat(portrait).ToArray();

        _jogoVisualSlotOrder.Clear();
        _jogoVisualSlotOrder.AddRange(top.Select(item => item.SlotNumber));
        _jogoVisualSlotOrder.AddRange(side.Select(item => item.SlotNumber));
        _jogoVisualSlotOrder.AddRange(
            Slots.Select(slot => slot.Number)
                .Where(number => !_jogoVisualSlotOrder.Contains(number)));

        _jogoTopSlotNumbers.Clear();
        foreach (var item in top)
            _jogoTopSlotNumbers.Add(item.SlotNumber);

        _jogoManualPlacementEnabled = true;
        ReconcileJogoManualPlacementSlots();
        AppLogger.Info(
            $"jogo-manual-placement-enabled: source={source}; " +
            $"topSlots={string.Join(',', _jogoVisualSlotOrder.Where(_jogoTopSlotNumbers.Contains))}; " +
            $"visualOrder={string.Join(',', _jogoVisualSlotOrder)}; portraitBottom=True");
    }

    private IReadOnlyList<NativeRect> BuildJogoContentAwareTargets(
        IReadOnlyList<PipSlot> occupied,
        IReadOnlyList<NativeRect> sourceRects,
        NativeRect workArea)
    {
        var aspects = ResolveJogoIntrinsicContentAspects(occupied, sourceRects);
        if (!_jogoManualPlacementEnabled)
            return _layoutService.BuildJogoContentAwareRects(
                sourceRects,
                aspects,
                workArea,
                jogoLayoutScale: ResolveJogoLayoutScale(),
                jogoTopWidthRatio: ResolveJogoTopWidthRatio(),
                jogoSideWidthRatio: ResolveJogoSideWidthRatio());

        ReconcileJogoManualPlacementSlots();
        var inputIndexBySlot = occupied
            .Select((slot, index) => new { slot.Number, Index = index })
            .ToDictionary(item => item.Number, item => item.Index);
        var occupiedNumbers = inputIndexBySlot.Keys.ToHashSet();
        var topSlots = _jogoVisualSlotOrder
            .Where(number => occupiedNumbers.Contains(number) && _jogoTopSlotNumbers.Contains(number))
            .ToArray();
        var sideSlots = _jogoVisualSlotOrder
            .Where(number => occupiedNumbers.Contains(number) && !_jogoTopSlotNumbers.Contains(number))
            .ToArray();
        var orderedSlots = topSlots.Concat(sideSlots).Distinct().ToList();
        orderedSlots.AddRange(occupied.Select(slot => slot.Number).Where(number => !orderedSlots.Contains(number)));

        if (orderedSlots.Count != occupied.Count)
            return _layoutService.BuildJogoContentAwareRects(
                sourceRects,
                aspects,
                workArea,
                jogoLayoutScale: ResolveJogoLayoutScale(),
                jogoTopWidthRatio: ResolveJogoTopWidthRatio(),
                jogoSideWidthRatio: ResolveJogoSideWidthRatio());

        var manualVisualOrder = orderedSlots
            .Select(number => inputIndexBySlot[number])
            .ToArray();
        return _layoutService.BuildJogoContentAwareRects(
            sourceRects,
            aspects,
            workArea,
            manualVisualOrder,
            topSlots.Length,
            ResolveJogoLayoutScale(),
            ResolveJogoTopWidthRatio(),
            ResolveJogoSideWidthRatio());
    }

    private void QueueJogoIntrinsicAspectReflowIfNeeded(string source)
    {
        if (CurrentLayout != LayoutMode.Jogo || _allHidden) return;

        var changedSlots = new List<int>();
        foreach (var slot in GetOccupiedSlotsInNumberOrder())
        {
            if (slot.Window is null || !PipWindowService.IsUsable(slot.Window.Handle))
                continue;

            var tab = ResolvePairedVideoTabForAspect(slot.Number);
            var currentAspect = tab?.IntrinsicAspectRatio ?? 0.0;
            if (!double.IsFinite(currentAspect) || currentAspect < 0.20 || currentAspect > 6.00)
                continue;

            if (!_slotIntrinsicContentAspectRatios.TryGetValue(slot.Number, out var previous)
                || Math.Abs(previous - currentAspect) >= 0.015)
            {
                _slotIntrinsicContentAspectRatios[slot.Number] = currentAspect;
                changedSlots.Add(slot.Number);
            }
        }

        if (changedSlots.Count > 0)
        {
            AppLogger.Info(
                $"jogo-intrinsic-aspect-change-detected: source={source}; slots={string.Join(',', changedSlots)}; " +
                "authority=video.videoWidth/video.videoHeight");
            QueueMixedAspectGroupReflow(changedSlots, source);
        }
    }

    private void QueueMixedAspectGroupReflow(IEnumerable<int> resizedSlots, string source)
    {
        // O layout Livre/Personalizado também é um mosaico. O navegador pode
        // corrigir a proporção de um PiP alguns segundos depois de "Igualar";
        // nesse caso preservamos o tamanho aceito pelo navegador e apenas
        // reposicionamos o conjunto segundo o desenho do usuário. Bloquear este
        // caminho em Custom deixava o PiP vertical sobre os vizinhos.
        var jogoProfileActive = CurrentLayout == LayoutMode.Jogo;
        if ((!_groupLocked && !_customLayoutActive && !jogoProfileActive) || _allHidden) return;
        if (Slots.Count(slot => slot.Window is not null && PipWindowService.IsUsable(slot.Window.Handle)) < 2) return;

        // Uma leitura de proporção nova substitui qualquer reorganização automática
        // anterior. Duas filas concorrentes eram a causa dos três formatos sucessivos
        // observados no mesmo segundo.
        _stableGroupLayoutDebounceCts?.Cancel();
        _stableGroupLayoutDebounceGeneration++;
        _mixedAspectReflowDebounceCts?.Cancel();
        _mixedAspectReflowDebounceCts?.Dispose();
        var cts = new System.Threading.CancellationTokenSource();
        _mixedAspectReflowDebounceCts = cts;
        var generation = ++_mixedAspectReflowDebounceGeneration;
        var changedSlots = resizedSlots.Distinct().OrderBy(number => number).ToArray();
        var slotList = string.Join(",", changedSlots);
        AppLogger.Info($"mixed-aspect-layout-reflow-queued: generation={generation}; source={source}; slots={slotList}; debounceMs={MixedAspectReflowDebounceMs}");
        _ = ApplyMixedAspectGroupReflowAsync(generation, source, changedSlots, cts);
    }

    private async Task ApplyMixedAspectGroupReflowAsync(
        int generation,
        string source,
        IReadOnlyCollection<int> changedSlots,
        System.Threading.CancellationTokenSource cts)
    {
        var slotList = string.Join(",", changedSlots.Order());
        try
        {
            await Task.Delay(MixedAspectReflowDebounceMs, cts.Token);
            if (cts.IsCancellationRequested || generation != _mixedAspectReflowDebounceGeneration) return;

            if (IsLayoutTransactionActive())
            {
                await Task.Delay(450, cts.Token);
                if (cts.IsCancellationRequested || generation != _mixedAspectReflowDebounceGeneration) return;
            }

            var occupied = GetOccupiedSlotsInNumberOrder()
                .Where(slot => slot.Window is not null && PipWindowService.IsUsable(slot.Window.Handle))
                .ToArray();
            if (occupied.Length < 2) return;

            // Confirma a geometria natural em duas leituras. O navegador pode emitir
            // uma dimensão intermediária antes de chegar à proporção final do vídeo.
            var naturalBySlot = occupied.ToDictionary(
                slot => slot.Number,
                slot => PipWindowService.GetVisualRect(slot.Window!.Handle));
            if (naturalBySlot.Values.Any(rect => !rect.IsValid)) return;

            await Task.Delay(NaturalAspectStableSampleMs, cts.Token);
            if (cts.IsCancellationRequested || generation != _mixedAspectReflowDebounceGeneration) return;
            var confirmedBySlot = occupied.ToDictionary(
                slot => slot.Number,
                slot => PipWindowService.GetVisualRect(slot.Window!.Handle));
            if (confirmedBySlot.Values.Any(rect => !rect.IsValid)) return;

            var unstableSlots = naturalBySlot.Keys
                .Where(number => Math.Abs(naturalBySlot[number].Width - confirmedBySlot[number].Width) > LayoutMoveSizeTolerancePx
                    || Math.Abs(naturalBySlot[number].Height - confirmedBySlot[number].Height) > LayoutMoveSizeTolerancePx)
                .ToArray();
            if (unstableSlots.Length > 0)
            {
                AppLogger.Info($"mixed-aspect-layout-reflow-resampled: generation={generation}; source={source}; slots={string.Join(',', unstableSlots)}; waitMs={NaturalAspectStableSampleMs}");
                await Task.Delay(NaturalAspectStableSampleMs, cts.Token);
                if (cts.IsCancellationRequested || generation != _mixedAspectReflowDebounceGeneration) return;
                confirmedBySlot = occupied.ToDictionary(
                    slot => slot.Number,
                    slot => PipWindowService.GetVisualRect(slot.Window!.Handle));
                if (confirmedBySlot.Values.Any(rect => !rect.IsValid)) return;
            }

            var workArea = GetSelectedLayoutMonitor()?.WorkArea ?? PipWindowService.GetVirtualScreenBounds();

            if (CurrentLayout == LayoutMode.Jogo)
            {
                // O perfil Jogo possui uma autoridade de topologia separada do
                // reflow misto genérico. Horizontais preenchem a faixa superior;
                // verticais migram para o trilho direito sem perder a identidade.
                var naturalInSlotOrder = occupied
                    .Select(slot => confirmedBySlot[slot.Number])
                    .ToArray();
                var intrinsicAspects = ResolveJogoIntrinsicContentAspects(occupied, naturalInSlotOrder);
                var jogoTargets = BuildJogoContentAwareTargets(
                        occupied,
                        naturalInSlotOrder,
                        workArea)
                    .ToArray();
                if (jogoTargets.Length != occupied.Length) return;

                var portraitCount = intrinsicAspects.Count(aspect => aspect < 0.90);
                var resizeForContentAspect = TargetsRequireResize(naturalInSlotOrder, jogoTargets);
                ApplyTargetsToOccupiedSlots(occupied, jogoTargets, resizeToTargets: resizeForContentAspect);
                CaptureCurrentRectsIntoSlotLayout();
                CommitJogoTargetsAsFixedAuthority(
                    occupied,
                    jogoTargets,
                    $"mixed-aspect-reflow/{source}");
                SaveLockedGroupModel(occupied, jogoTargets);
                _lastKnownGroupBounds = GetBounds(jogoTargets);
                PositionToolbar();
                RefreshPipDragTargets();
                AppLogger.Info($"jogo-layout-reflow-applied: generation={generation}; source={source}; slots={slotList}; windows={occupied.Length}; portraitCount={portraitCount}; bounds={_lastKnownGroupBounds}; sizesPreserved={!resizeForContentAspect}; moveOnly={!resizeForContentAspect}; resizedForIntrinsicAspect={resizeForContentAspect}; aspectAuthority=intrinsic-video; topology=landscape-top-row/portrait-right-rail/overflow-below");
                return;
            }

            // Autoridade exclusiva de tamanho do reflow misto original: as
            // dimensões finais vêm do DWM/navegador. O motor apenas move os
            // retângulos que colidem ou ficaram desconectados.
            var repaired = _groupTransformEngine.ReflowNaturalSizesAsConnectedMosaic(
                confirmedBySlot,
                changedSlots,
                workArea);
            if (repaired.Count != occupied.Length) return;
            var targets = occupied.Select(slot => repaired[slot.Number]).ToArray();

            ApplyTargetsToOccupiedSlots(occupied, targets, resizeToTargets: false);
            CaptureCurrentRectsIntoSlotLayout();
            SaveLockedGroupModel(occupied, targets);
            _lastKnownGroupBounds = GetBounds(targets.ToArray());
            PositionToolbar();
            RefreshPipDragTargets();
            AppLogger.Info($"mixed-aspect-layout-reflow-applied: generation={generation}; source={source}; slots={slotList}; windows={occupied.Length}; layout={CurrentLayout}; bounds={_lastKnownGroupBounds}; sizesPreserved=True; moveOnly=True; connectedMosaic=True");
        }
        catch (TaskCanceledException)
        {
            AppLogger.Info($"mixed-aspect-layout-reflow-cancelled: generation={generation}; source={source}; slots={slotList}");
        }
        finally
        {
            if (ReferenceEquals(_mixedAspectReflowDebounceCts, cts))
            {
                _mixedAspectReflowDebounceCts = null;
                cts.Dispose();
            }
        }
    }

    private void UpdatePanelSlotVisuals()
    {
        if (_customLayoutActive)
        {
            ShowCustomModeEditor();
            return;
        }

        HideCustomModeEditor();
        SlotsList.ItemsPanel = BuildItemsPanelTemplate(CurrentLayout);
    }

    private static ItemsPanelTemplate BuildItemsPanelTemplate(LayoutMode mode)
    {
        var factory = new FrameworkElementFactory(typeof(UniformGrid));
        switch (mode)
        {
            case LayoutMode.Vertical:
                factory.SetValue(UniformGrid.ColumnsProperty, 1);
                break;
            case LayoutMode.Horizontal:
                factory.SetValue(UniformGrid.RowsProperty, 1);
                break;
            case LayoutMode.Jogo:
                factory.SetValue(UniformGrid.ColumnsProperty, 6);
                break;
            default:
                factory.SetValue(UniformGrid.ColumnsProperty, 2);
                break;
        }

        return new ItemsPanelTemplate(factory);
    }

    private void SlotWorkspace_SizeChanged(object sender, SizeChangedEventArgs e)
    {
        if (_customLayoutActive)
        {
            ClampEditableSlotsToWorkspace();
            ShowCustomModeEditor();
        }
    }

    private void BuildCustomSlotOverlay(bool forceReset = false)
    {
        if (!forceReset && EditableSlots.Count == Slots.Count)
        {
            SyncEditableSlotStates();
            ClampEditableSlotsToWorkspace();
            return;
        }

        EditableSlots.Clear();
        foreach (var rect in BuildPanelSlotRects(Slots.Count, LayoutMode.GridTwoColumns))
        {
            var number = EditableSlots.Count + 1;
            var editable = new EditableSlotRect(
                number,
                rect.Left,
                rect.Top,
                rect.Width,
                rect.Height);

            var slot = Slots.FirstOrDefault(item => item.Number == number);
            if (slot is not null)
                editable.State = slot.State;

            EditableSlots.Add(editable);
        }
    }

    private void SyncEditableSlotStates()
    {
        if (EditableSlots.Count == 0) return;

        var fixedAspectChanges = new List<int>();

        foreach (var editable in EditableSlots)
        {
            var slot = Slots.FirstOrDefault(item => item.Number == editable.Number);
            editable.State = slot?.State ?? PipSlotState.Free;
            editable.IsAutoReturnEnabled = slot?.IsAutoReturnEnabled
                ?? (_slotAutoReturnDiscreteBySlot.TryGetValue(editable.Number, out var enabled) && enabled);

            var visualRect = slot?.Window is not null && PipWindowService.IsUsable(slot.Window.Handle)
                ? PipWindowService.GetVisualRect(slot.Window.Handle)
                : slot?.Window?.VisualRect ?? default;
            var ratio = visualRect.IsValid
                ? visualRect.Width / (double)Math.Max(1, visualRect.Height)
                : editable.State == PipSlotState.Free
                    ? 16.0 / 9.0
                    : editable.SourceAspectRatio;
            if (editable.UpdatePreviewAspect(ratio))
            {
                AppLogger.Info(
                    $"slot-appearance-aspect-updated: slot={editable.Number}; kind={editable.AspectText}; " +
                    $"ratio={editable.SourceAspectRatio:0.000}; sourceRect={visualRect}; " +
                    $"preview={editable.PreviewWidth:0.#}x{editable.PreviewHeight:0.#}");

                if (_fixedCustomLayoutEnabled && visualRect.IsValid
                    && TryGetFixedSlotRect(editable.Number, out var fixedRect))
                {
                    var fixedRatio = fixedRect.Width / (double)Math.Max(1, fixedRect.Height);
                    if (Math.Abs(fixedRatio - ratio) >= 0.12)
                        fixedAspectChanges.Add(editable.Number);
                }
            }
        }

        if (fixedAspectChanges.Count > 0)
            QueueFixedAspectGroupReflow(fixedAspectChanges, "slot-appearance/aspect-change");
    }

    private List<NativeRect> BuildPanelSlotRects(int count, LayoutMode mode)
    {
        var workspaceWidth = Math.Max(120, (int)Math.Round(SlotWorkspace.ActualWidth - 16));
        var workspaceHeight = Math.Max(80, (int)Math.Round(SlotWorkspace.ActualHeight - 16));
        if (workspaceWidth <= 0 || workspaceHeight <= 0)
            return [];

        if (mode == LayoutMode.Jogo)
            return BuildJogoPanelSlotRects(count, workspaceWidth, workspaceHeight);

        var columns = mode switch
        {
            LayoutMode.Vertical => 1,
            LayoutMode.Horizontal => Math.Max(1, count),
            _ => Math.Min(2, Math.Max(1, count))
        };
        var rows = mode == LayoutMode.Horizontal ? 1 : (int)Math.Ceiling(count / (double)Math.Max(1, columns));
        var totalWidth = (columns * PanelSlotWidth) + (Math.Max(0, columns - 1) * PanelSlotGap);
        var totalHeight = (rows * PanelSlotHeight) + (Math.Max(0, rows - 1) * PanelSlotGap);
        var startX = Math.Max(PanelSlotPadding, (workspaceWidth - totalWidth) / 2);
        var startY = Math.Max(PanelSlotPadding, (workspaceHeight - totalHeight) / 2);

        var rects = new List<NativeRect>(count);
        for (var index = 0; index < count; index++)
        {
            var column = mode == LayoutMode.Vertical ? 0 : mode == LayoutMode.Horizontal ? index : index % columns;
            var row = mode == LayoutMode.Horizontal ? 0 : index / columns;
            var left = startX + (column * (PanelSlotWidth + PanelSlotGap));
            var top = startY + (row * (PanelSlotHeight + PanelSlotGap));
            rects.Add(new NativeRect(left, top, left + PanelSlotWidth, top + PanelSlotHeight));
        }

        return rects;
    }

    private List<NativeRect> BuildJogoPanelSlotRects(int count, int workspaceWidth, int workspaceHeight)
    {
        if (count <= 0) return [];

        const int topCapacity = 6;
        var topCount = Math.Min(topCapacity, count);
        var tailCount = Math.Max(0, count - topCapacity);
        var rawWidth = (topCount * PanelSlotWidth) + (Math.Max(0, topCount - 1) * PanelSlotGap);
        var rawHeight = PanelSlotHeight + (tailCount * (PanelSlotHeight + PanelSlotGap));
        var availableWidth = Math.Max(1, workspaceWidth - (PanelSlotPadding * 2));
        var availableHeight = Math.Max(1, workspaceHeight - (PanelSlotPadding * 2));
        var scale = Math.Min(1.0, Math.Min(availableWidth / (double)Math.Max(1, rawWidth), availableHeight / (double)Math.Max(1, rawHeight)));
        var width = Math.Max(16, (int)Math.Round(PanelSlotWidth * scale));
        var height = Math.Max(10, (int)Math.Round(PanelSlotHeight * scale));
        var gap = Math.Max(1, (int)Math.Round(PanelSlotGap * scale));
        var totalWidth = (topCount * width) + (Math.Max(0, topCount - 1) * gap);
        var totalHeight = height + (tailCount * (height + gap));
        var startX = Math.Max(PanelSlotPadding, (workspaceWidth - totalWidth) / 2);
        var startY = Math.Max(PanelSlotPadding, (workspaceHeight - totalHeight) / 2);

        var rects = new List<NativeRect>(count);
        for (var index = 0; index < topCount; index++)
        {
            var left = startX + (index * (width + gap));
            rects.Add(new NativeRect(left, startY, left + width, startY + height));
        }

        if (tailCount > 0)
        {
            var tailLeft = rects[topCount - 1].Left;
            for (var tailIndex = 0; tailIndex < tailCount; tailIndex++)
            {
                var top = startY + height + gap + (tailIndex * (height + gap));
                rects.Add(new NativeRect(tailLeft, top, tailLeft + width, top + height));
            }
        }

        return rects;
    }

    private static bool TargetsRequireResize(IReadOnlyList<NativeRect> source, IReadOnlyList<NativeRect> targets)
    {
        if (source.Count != targets.Count) return true;
        for (var index = 0; index < source.Count; index++)
        {
            if (Math.Abs(source[index].Width - targets[index].Width) > LayoutMoveSizeTolerancePx
                || Math.Abs(source[index].Height - targets[index].Height) > LayoutMoveSizeTolerancePx)
                return true;
        }
        return false;
    }

    private void EditorMoveThumb_DragDelta(object sender, DragDeltaEventArgs e)
    {
        if (sender is not Thumb { DataContext: EditableSlotRect slot }) return;

        if (Math.Abs(e.HorizontalChange) < 0.01 && Math.Abs(e.VerticalChange) < 0.01)
            return;
        _editorSlotDragChanged = true;

        var maxLeft = Math.Max(PanelSlotPadding, SlotWorkspace.ActualWidth - 24 - slot.Width);
        var maxTop = Math.Max(PanelSlotPadding, SlotWorkspace.ActualHeight - 24 - slot.Height);

        var proposedLeft = Math.Clamp(slot.Left + e.HorizontalChange, PanelSlotPadding, maxLeft);
        var proposedTop = Math.Clamp(slot.Top + e.VerticalChange, PanelSlotPadding, maxTop);

        var snapped = SnapEditableSlot(slot, proposedLeft, proposedTop, maxLeft, maxTop);
        slot.Left = snapped.Left;
        slot.Top = snapped.Top;
        SaveSettings();

        // Não mexe nos PiPs durante o arraste do slot. Isso evita travadas no vídeo.
        // O layout personalizado é aplicado automaticamente quando o usuário solta o slot.
    }

    private void EditorMoveThumb_DragCompleted(object sender, DragCompletedEventArgs e)
    {
        if (!_editorSlotDragChanged)
            return;
        _editorSlotDragChanged = false;
        if (_fixedCustomLayoutEnabled)
        {
            RebuildFixedAuthorityAfterEditorChange("manual-slot-drag-completed");
            SetStatus("Layout fixo atualizado ao soltar o slot");
        }
        else if (_customLayoutActive && Slots.Any(current => current.Window is not null) && !_allHidden)
        {
            RebuildGroupFromLayout(preferPanelTemplateAnchor: false, resizeToTargets: false, saveLockedModel: _groupLocked);
            SetStatus("Personalizado aplicado ao soltar o slot");
        }
    }

    private (double Left, double Top) SnapEditableSlot(EditableSlotRect movingSlot, double proposedLeft, double proposedTop, double maxLeft, double maxTop)
    {
        var left = proposedLeft;
        var top = proposedTop;
        var width = Math.Max(1, movingSlot.Width);
        var height = Math.Max(1, movingSlot.Height);

        foreach (var other in EditableSlots.Where(slot => slot != movingSlot))
        {
            var otherLeft = other.Left;
            var otherTop = other.Top;
            var otherRight = other.Left + other.Width;
            var otherBottom = other.Top + other.Height;
            var right = left + width;
            var bottom = top + height;

            // Ímã horizontal: borda esquerda/direita cola na borda do outro slot.
            if (Math.Abs(left - otherRight) <= SlotSnapDistance)
                left = otherRight;
            else if (Math.Abs(right - otherLeft) <= SlotSnapDistance)
                left = otherLeft - width;
            else if (Math.Abs(left - otherLeft) <= SlotSnapDistance)
                left = otherLeft;
            else if (Math.Abs(right - otherRight) <= SlotSnapDistance)
                left = otherRight - width;

            // Ímã vertical: borda superior/inferior cola na borda do outro slot.
            right = left + width;
            bottom = top + height;
            if (Math.Abs(top - otherBottom) <= SlotSnapDistance)
                top = otherBottom;
            else if (Math.Abs(bottom - otherTop) <= SlotSnapDistance)
                top = otherTop - height;
            else if (Math.Abs(top - otherTop) <= SlotSnapDistance)
                top = otherTop;
            else if (Math.Abs(bottom - otherBottom) <= SlotSnapDistance)
                top = otherBottom - height;

            // Ao colar lado a lado, também alinha a linha; ao colar embaixo/cima, também alinha a coluna.
            var horizontallyTouching = Math.Abs(left - otherRight) <= 1.0 || Math.Abs((left + width) - otherLeft) <= 1.0;
            var verticallyTouching = Math.Abs(top - otherBottom) <= 1.0 || Math.Abs((top + height) - otherTop) <= 1.0;

            if (horizontallyTouching)
            {
                if (Math.Abs(top - otherTop) <= SlotSnapDistance * 2)
                    top = otherTop;
                else if (Math.Abs((top + height) - otherBottom) <= SlotSnapDistance * 2)
                    top = otherBottom - height;
            }

            if (verticallyTouching)
            {
                if (Math.Abs(left - otherLeft) <= SlotSnapDistance * 2)
                    left = otherLeft;
                else if (Math.Abs((left + width) - otherRight) <= SlotSnapDistance * 2)
                    left = otherRight - width;
            }
        }

        left = Math.Clamp(left, PanelSlotPadding, maxLeft);
        top = Math.Clamp(top, PanelSlotPadding, maxTop);

        // Evita sobreposição final. Se encostar demais em outro slot, empurra para a borda livre mais próxima.
        var candidate = new Rect(left, top, width, height);
        foreach (var other in EditableSlots.Where(slot => slot != movingSlot))
        {
            var otherRect = new Rect(other.Left, other.Top, other.Width, other.Height);
            if (!candidate.IntersectsWith(otherRect))
                continue;

            var pushRight = Math.Abs(candidate.Left - otherRect.Right);
            var pushLeft = Math.Abs(candidate.Right - otherRect.Left);
            var pushDown = Math.Abs(candidate.Top - otherRect.Bottom);
            var pushUp = Math.Abs(candidate.Bottom - otherRect.Top);
            var best = new[]
            {
                (Distance: pushRight, Left: otherRect.Right, Top: top),
                (Distance: pushLeft, Left: otherRect.Left - width, Top: top),
                (Distance: pushDown, Left: left, Top: otherRect.Bottom),
                (Distance: pushUp, Left: left, Top: otherRect.Top - height),
            }
            .OrderBy(item => item.Distance)
            .First();

            left = Math.Clamp(best.Left, PanelSlotPadding, maxLeft);
            top = Math.Clamp(best.Top, PanelSlotPadding, maxTop);
            candidate = new Rect(left, top, width, height);
        }

        return (left, top);
    }

    private IReadOnlyList<NativeRect> BuildTargetsForOccupiedSlots(
        IReadOnlyList<PipSlot> occupied,
        IReadOnlyList<NativeRect> sourceRects,
        NativeRect anchor,
        NativeRect? workArea = null)
    {
        if (_customLayoutActive && EditableSlots.Count >= sourceRects.Count)
            return BuildCustomLayoutTargets(sourceRects, anchor);

        var targetArea = workArea is { IsValid: true } area
            ? area
            : PipWindowService.GetVirtualScreenBounds();

        if (CurrentLayout == LayoutMode.Jogo && occupied.Count == sourceRects.Count)
            return BuildJogoContentAwareTargets(occupied, sourceRects, targetArea);

        return _layoutService.BuildLayoutRects(sourceRects, CurrentLayout, anchor, targetArea);
    }

    private IReadOnlyList<NativeRect> BuildCustomLayoutTargets(IReadOnlyList<NativeRect> sourceRects, NativeRect anchor)
    {
        var templateItems = EditableSlots
            .Take(sourceRects.Count)
            .Select((slot, index) => new TemplateLayoutItem(
                new Rect(slot.Left, slot.Top, slot.Width, slot.Height),
                sourceRects[index].Width,
                sourceRects[index].Height,
                index))
            .ToArray();

        if (templateItems.Length == 0)
            return _layoutService.BuildLayoutRects(sourceRects, CurrentLayout, anchor);

        // Personalizado = molde visual.
        // O usuário desenha a forma nos slots, por exemplo um L. Ao travar, nós compactamos
        // esse desenho em linhas/colunas, encostando os PiPs sem sobreposição e preservando
        // a topologia do desenho. Os slots do painel não são modificados por esta função.
        var rowIndexes = BuildClusterIndexes(templateItems, vertical: true);
        var colIndexes = BuildClusterIndexes(templateItems, vertical: false);
        var rowCount = rowIndexes.Length == 0 ? 0 : rowIndexes.Max() + 1;
        var colCount = colIndexes.Length == 0 ? 0 : colIndexes.Max() + 1;

        if (rowCount <= 0 || colCount <= 0)
            return _layoutService.BuildLayoutRects(sourceRects, CurrentLayout, anchor);

        var rowHeights = new int[rowCount];
        var colWidths = new int[colCount];

        for (var i = 0; i < templateItems.Length; i++)
        {
            var row = rowIndexes[i];
            var col = colIndexes[i];
            rowHeights[row] = Math.Max(rowHeights[row], templateItems[i].Height);
            colWidths[col] = Math.Max(colWidths[col], templateItems[i].Width);
        }

        for (var i = 0; i < rowHeights.Length; i++) rowHeights[i] = Math.Max(1, rowHeights[i]);
        for (var i = 0; i < colWidths.Length; i++) colWidths[i] = Math.Max(1, colWidths[i]);

        var totalWidth = CompactTotal(colWidths);
        var totalHeight = CompactTotal(rowHeights);
        var screen = PipWindowService.GetVirtualScreenBounds();
        var baseLeft = Math.Clamp(anchor.Left, screen.Left + 8, Math.Max(screen.Left + 8, screen.Right - totalWidth - 8));
        var baseTop = Math.Clamp(anchor.Top, screen.Top + 8, Math.Max(screen.Top + 8, screen.Bottom - totalHeight - 8));

        var xOffsets = new int[colCount];
        for (var i = 1; i < colCount; i++)
            xOffsets[i] = xOffsets[i - 1] + StepSize(colWidths[i - 1]);

        var yOffsets = new int[rowCount];
        for (var i = 1; i < rowCount; i++)
            yOffsets[i] = yOffsets[i - 1] + StepSize(rowHeights[i - 1]);

        var targets = new NativeRect[templateItems.Length];
        for (var i = 0; i < templateItems.Length; i++)
        {
            var item = templateItems[i];
            var left = baseLeft + xOffsets[colIndexes[i]];
            var top = baseTop + yOffsets[rowIndexes[i]];
            targets[item.Index] = new NativeRect(left, top, left + item.Width, top + item.Height);
        }

        return _groupTransformEngine.EnsureSingleConnectedMosaic(
            targets,
            GetSelectedLayoutMonitor()?.WorkArea ?? PipWindowService.GetVirtualScreenBounds());
    }

    private static int[] BuildClusterIndexes(IReadOnlyList<TemplateLayoutItem> items, bool vertical)
    {
        if (items.Count == 0) return [];

        double Coordinate(TemplateLayoutItem item) => vertical
            ? item.Rect.Top + (item.Rect.Height / 2.0)
            : item.Rect.Left + (item.Rect.Width / 2.0);

        double Size(TemplateLayoutItem item) => vertical ? item.Rect.Height : item.Rect.Width;

        var tolerance = Math.Max(18.0, items.Average(Size) * 0.60);
        var ordered = items
            .Select((item, index) => new { Item = item, Index = index, Coord = Coordinate(item) })
            .OrderBy(item => item.Coord)
            .ToList();

        var clusters = new List<List<(int Index, double Coord)>>();
        foreach (var item in ordered)
        {
            var placed = false;
            foreach (var cluster in clusters)
            {
                var center = cluster.Average(entry => entry.Coord);
                if (Math.Abs(item.Coord - center) <= tolerance)
                {
                    cluster.Add((item.Index, item.Coord));
                    placed = true;
                    break;
                }
            }

            if (!placed)
                clusters.Add([(item.Index, item.Coord)]);
        }

        var result = new int[items.Count];
        var orderedClusters = clusters
            .OrderBy(cluster => cluster.Average(entry => entry.Coord))
            .ToList();

        for (var clusterIndex = 0; clusterIndex < orderedClusters.Count; clusterIndex++)
            foreach (var entry in orderedClusters[clusterIndex])
                result[entry.Index] = clusterIndex;

        return result;
    }

    private void LoadCustomSlotRects()
    {
        EditableSlots.Clear();
        var source = _settings.CustomSlotLayout
            .Select(item => item.ToRect())
            .Where(rect => rect.IsValid)
            .ToList();

        if (source.Count == Slots.Count)
        {
            for (var index = 0; index < source.Count; index++)
            {
                var rect = source[index];
                EditableSlots.Add(new EditableSlotRect(index + 1, rect.Left, rect.Top, rect.Width, rect.Height));
            }
        }
    }

    private NativeRect GetPanelTemplateAnchorBounds(int count)
    {
        if (count <= 0 || !SlotWorkspace.IsLoaded)
            return default;

        var dpi = System.Windows.Media.VisualTreeHelper.GetDpi(this);
        var topLeft = SlotWorkspace.PointToScreen(new Point(0, 0));

        if (_customLayoutActive && EditableSlots.Count >= count)
        {
            var customRects = EditableSlots
                .Take(count)
                .Select(slot => new NativeRect(
                    (int)Math.Round(topLeft.X * dpi.DpiScaleX + slot.Left * dpi.DpiScaleX),
                    (int)Math.Round(topLeft.Y * dpi.DpiScaleY + slot.Top * dpi.DpiScaleY),
                    (int)Math.Round(topLeft.X * dpi.DpiScaleX + (slot.Left + slot.Width) * dpi.DpiScaleX),
                    (int)Math.Round(topLeft.Y * dpi.DpiScaleY + (slot.Top + slot.Height) * dpi.DpiScaleY)))
                .ToArray();
            return GetBounds(customRects);
        }

        var panelRects = BuildPanelSlotRects(count, CurrentLayout)
            .Select(rect => new NativeRect(
                (int)Math.Round(topLeft.X * dpi.DpiScaleX + rect.Left * dpi.DpiScaleX),
                (int)Math.Round(topLeft.Y * dpi.DpiScaleY + rect.Top * dpi.DpiScaleY),
                (int)Math.Round(topLeft.X * dpi.DpiScaleX + rect.Right * dpi.DpiScaleX),
                (int)Math.Round(topLeft.Y * dpi.DpiScaleY + rect.Bottom * dpi.DpiScaleY)))
            .ToArray();
        return GetBounds(panelRects);
    }

    private static List<List<TemplateLayoutItem>> GroupCustomTemplateRows(IEnumerable<TemplateLayoutItem> templateItems)
    {
        var ordered = templateItems
            .OrderBy(item => item.Rect.Top + (item.Rect.Height / 2.0))
            .ThenBy(item => item.Rect.Left)
            .ToList();
        var rows = new List<List<TemplateLayoutItem>>();
        var referenceHeight = ordered.Count == 0 ? 66 : ordered.Max(item => (double)item.Rect.Height);
        var tolerance = Math.Max(24, (int)Math.Round(referenceHeight * 0.70));

        foreach (var item in ordered)
        {
            List<TemplateLayoutItem>? selectedRow = null;
            double? bestDistance = null;
            var centerY = item.Rect.Top + (item.Rect.Height / 2.0);

            foreach (var row in rows)
            {
                var rowCenterY = row.Average(current => current.Rect.Top + (current.Rect.Height / 2.0));
                var distance = Math.Abs(centerY - rowCenterY);
                if (distance <= tolerance && (bestDistance is null || distance < bestDistance))
                {
                    selectedRow = row;
                    bestDistance = distance;
                }
            }

            if (selectedRow is null)
            {
                rows.Add([item]);
            }
            else
            {
                selectedRow.Add(item);
            }
        }

        foreach (var row in rows)
            row.Sort((left, right) => left.Rect.Left.CompareTo(right.Rect.Left));

        rows.Sort((top, bottom) =>
        {
            var topValue = top.Count == 0 ? 0 : top.Min(item => item.Rect.Top);
            var bottomValue = bottom.Count == 0 ? 0 : bottom.Min(item => item.Rect.Top);
            return topValue.CompareTo(bottomValue);
        });
        return rows;
    }

    private static int StepSize(int value) => LayoutService.StepSize(value);

    private static int CompactTotal(IReadOnlyList<int> values)
    {
        if (values.Count == 0) return 1;
        var total = 0;
        for (var i = 0; i < values.Count; i++)
            total += i == values.Count - 1 ? Math.Max(1, values[i]) : StepSize(values[i]);
        return Math.Max(1, total);
    }

    private void ClampEditableSlotsToWorkspace()
    {
        foreach (var slot in EditableSlots)
        {
            var maxLeft = Math.Max(PanelSlotPadding, SlotWorkspace.ActualWidth - 24 - slot.Width);
            var maxTop = Math.Max(PanelSlotPadding, SlotWorkspace.ActualHeight - 24 - slot.Height);
            slot.Left = Math.Clamp(slot.Left, PanelSlotPadding, maxLeft);
            slot.Top = Math.Clamp(slot.Top, PanelSlotPadding, maxTop);
        }
    }
}

// Native Layout Engine Phase 1: selector and reversible authority control.
public partial class MainWindow
{
    private static NativeLayoutEngineMode ParseNativeLayoutEngineMode(string? value) =>
        Enum.TryParse<NativeLayoutEngineMode>(value, ignoreCase: true, out var parsed)
            ? parsed
            : NativeLayoutEngineMode.Off;

    private void InitializeNativeLayoutEngineSelector()
    {
        UpdateNativeLayoutEngineMenuChecks();
        UpdateNativeLayoutEngineMenuToolTips();
    }

    private void UpdateNativeLayoutEngineMenuChecks()
    {
        _suppressNativeLayoutModeEvents = true;
        try
        {
            NativeLayoutOffMenuItem.IsChecked = _nativeLayoutEngineMode == NativeLayoutEngineMode.Off;
            NativeLayoutCompareMenuItem.IsChecked = _nativeLayoutEngineMode == NativeLayoutEngineMode.Compare;
            NativeLayoutPrimaryMenuItem.IsChecked = _nativeLayoutEngineMode == NativeLayoutEngineMode.Primary;
        }
        finally
        {
            _suppressNativeLayoutModeEvents = false;
        }
    }

    private void UpdateNativeLayoutEngineMenuToolTips()
    {
        var available = PipWindowService.NativeLayoutEngineAvailable;
        var version = PipWindowService.NativeLayoutEngineVersion;
        var failure = PipWindowService.NativeLayoutEngineFailure;
        var common = $"DLL disponível: {available}; ABI: {version}. " +
                     (available ? string.Empty : $"Fallback C# ativo: {failure}");
        NativeLayoutOffMenuItem.ToolTip = "Usa somente o motor C# congelado da 9.38.02. " + common;
        NativeLayoutCompareMenuItem.ToolTip = "C++ calcula o lote em dry-run; o C# continua aplicando. " + common;
        NativeLayoutPrimaryMenuItem.ToolTip = "C++ aplica o lote; qualquer falha retorna automaticamente ao C#. " + common;
    }

    private void NativeLayoutModeMenuItem_Click(object sender, RoutedEventArgs e)
    {
        if (_suppressNativeLayoutModeEvents || sender is not MenuItem item)
            return;

        var mode = ParseNativeLayoutEngineMode(item.Tag?.ToString());
        _nativeLayoutEngineMode = mode;
        PipWindowService.ConfigureNativeLayoutEngine(mode);
        UpdateNativeLayoutEngineMenuChecks();
        UpdateNativeLayoutEngineMenuToolTips();

        if (!_initializationComplete)
            return;

        SaveSettings();
        var available = PipWindowService.NativeLayoutEngineAvailable;
        SetStatus(mode switch
        {
            NativeLayoutEngineMode.Off => "Agrupamento usando motor C#.",
            NativeLayoutEngineMode.Compare when available => "Motor C++ em comparação; C# continua aplicando os layouts.",
            NativeLayoutEngineMode.Primary when available => "Motor C++ assumiu os layouts, com fallback automático para C#.",
            _ => "DLL nativa indisponível; fallback C# permanece ativo."
        });
    }
}
