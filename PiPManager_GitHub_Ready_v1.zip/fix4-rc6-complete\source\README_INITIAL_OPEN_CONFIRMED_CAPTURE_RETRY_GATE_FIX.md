# Initial Open Confirmed-Capture Retry Gate Fix

Base: `PiPManager_9_39_01_STABLE_FLUIDEZ_AUTORETURN_READY_GATE_TEST_SOURCE`.

## Problema confirmado pelo log

Durante `Abrir todos`, a primeira janela PiP foi capturada, vinculada e aprovada pelo
`auto-pair-proof`. A captura assistida, porém, ocupou a thread de interface por tempo
suficiente para ultrapassar a janela de espera de 700 ms. Quando o fluxo de abertura
retomou, interpretou o timeout como ausência de HWND e enviou um segundo atalho físico.
Isso criou uma segunda janela da mesma fonte e fez o lote terminar em `PARTIAL` (9/10).

## Correção

- A confirmação do HWND agora exige janela utilizável e identidade do slot compatível
  com a aba esperada (`pairKey` ou `stableVideoKey`, além do `tabId`).
- `WaitForInitialOpenHwndAsync` faz uma verificação final depois do timeout, cobrindo o
  caso em que a captura ocorreu enquanto o Dispatcher estava ocupado.
- Antes de iniciar o retry, antes de enviar o segundo atalho e antes do fallback da
  extensão, o fluxo verifica novamente se o slot já foi confirmado.
- Quando confirmado, o retry é cancelado com o log
  `initial-open-physical-shortcut-retry-cancelled: reason=slot-already-confirmed`.
- O fluxo de retry legítimo permanece disponível quando nenhum HWND foi realmente
  capturado.
- Ready Gate do AutoReturn, layout, arraste, interface e extensão não foram alterados.
