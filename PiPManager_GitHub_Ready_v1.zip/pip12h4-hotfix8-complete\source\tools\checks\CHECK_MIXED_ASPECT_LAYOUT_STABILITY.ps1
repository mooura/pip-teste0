$ErrorActionPreference = 'Stop'

$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$layout = Get-Content -Raw -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\Services\LayoutService.cs')
$main = Get-Content -Raw -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\MainWindow.xaml.cs')
$mainLayout = Get-Content -Raw -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\MainWindow.Layout.cs')
$fixedLayout = Get-Content -Raw -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\MainWindow.FixedLayout.cs')
$pipDrag = Get-Content -Raw -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\MainWindow.PipDrag.cs')
$groupTransform = Get-Content -Raw -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\Services\GroupTransformEngine.cs')

$checks = [ordered]@{
    'mixed aspect detector exists' = $layout.Contains('HasMixedAspectRatios')
    'mixed aspect masonry exists' = $layout.Contains('BuildMixedAspectMasonryTwoColumns')
    'mixed layout uses real dimensions' = $layout.Contains('var rect = rects[i];')
    'shortest column preserves compact order' = $layout.Contains('nextTop[0] <= nextTop[1] ? 0 : 1')
    'mixed layout disables seam overlap' = $layout.Contains('seamCompensationPx: 0')
    'left column aligns to center seam' = $layout.Contains('centerSeam - rect.Width')
    'columns stack independently' = $layout.Contains('nextTop[col] += StepSize(rects[i].Height, seamCompensationPx: 0)')
    'external size changes are collected' = $main.Contains('externallyResizedSlots.Add(slot.Number)')
    'external size changes queue reflow' = $main.Contains('QueueMixedAspectGroupReflow(externallyResizedSlots')
    'reflow debounce exists' = $mainLayout.Contains('MixedAspectReflowDebounceMs')
    'reflow rereads DWM rectangles' = $mainLayout.Contains('PipWindowService.GetVisualRect(slot.Window!.Handle)')
    'natural aspect waits for a confirming sample' = $mainLayout.Contains('NaturalAspectStableSampleMs') -and $mainLayout.Contains('mixed-aspect-layout-reflow-resampled')
    'reflow only moves windows' = $mainLayout.Contains('ApplyTargetsToOccupiedSlots(occupied, targets, resizeToTargets: false)')
    'reflow preserves browser dimensions and reconnects the mosaic' = $groupTransform.Contains('ReflowNaturalSizesAsConnectedMosaic') -and $mainLayout.Contains('sizesPreserved=True; moveOnly=True; connectedMosaic=True')
    'stable capture layout does not resize again' = $main.Contains('RebuildGroupFromLayout(preferPanelTemplateAnchor: false, resizeToTargets: false, saveLockedModel: _groupLocked)')
    'reflow diagnostic emitted' = $mainLayout.Contains('mixed-aspect-layout-reflow-applied')
    'fixed layout observes automatic aspect changes' = $mainLayout.Contains('QueueFixedAspectGroupReflow(fixedAspectChanges')
    'fixed layout external resize queues group reflow' = $main.Contains('QueueFixedAspectGroupReflow(externallyResizedSlots')
    'fixed aspect reflow anchors changed slots' = $fixedLayout.Contains('ReplaceFixedAuthorityAfterAspectChange(authority, changedSlots')
    'pending natural aspect suspends old size enforcement' = $fixedLayout.Contains('reason=natural-aspect-stabilizing')
    'automatic editor updates cannot become manual drag' = $mainLayout.Contains('_editorSlotDragChanged')
    'equalize reference is exclusively manual or selected' = $mainLayout.Contains('_lastManuallyResizedSlotNumber') -and -not $mainLayout.Contains('if (_lastResizedSlotNumber is int lastNumber)')
    'fixed enforcement yields to a manual PiP gesture' = $fixedLayout.Contains('reason=manual-pip-gesture-active')
    'fixed automatic placement is move only' = $fixedLayout.Contains('ApplyFixedLayoutToAllActive(string source, bool resizeToTargets = false)') -and $fixedLayout.Contains('PipWindowService.MoveVisual(handle, target.Left, target.Top)')
    'equalize remains the explicit resize authority' = $main.Contains('ApplyFixedLayoutToAllActive("equalize-request-fixed-authority", resizeToTargets: true)') -and $main.Contains('ApplyTargetsToOccupiedSlots(occupiedInOrder, targets, resizeToTargets: true)')
    'manual PiP size becomes fixed authority before equalize' = $fixedLayout.Contains('CommitManualFixedSlotResize') -and $pipDrag.Contains('CommitManualFixedSlotResize(slot.Number, finalRect)')
    'free layout is forced into one connected mosaic' = $groupTransform.Contains('EnsureSingleConnectedMosaic') -and $mainLayout.Contains('_groupTransformEngine.EnsureSingleConnectedMosaic')
    'recovery does not reposition stable slots repeatedly' = $fixedLayout.Contains('reason=already-recovered')
    'fixed aspect reflow applies one final group batch' = $fixedLayout.Contains('batchAppliedOnce=True; overlapFree=True')
    'relative engine propagates only collisions from changed slots' = $groupTransform.Contains('ReflowFromChangedSlots') -and $groupTransform.Contains('changed.Contains(otherNumber)')
    'destroyed drag callback preserves AutoReturn identity' = $pipDrag.Contains('natural-anchor-drag-ignored-destroyed-hwnd') -and $pipDrag.Contains('pairMetadataPreserved=True')
    'drag purge preserves linked AutoReturn pairs before pending admission' = $pipDrag.Contains('preserveForAutoReturn') -and $pipDrag.Contains('AutoReturnBurstPolicy.ShouldPreserveLostSlot') -and $pipDrag.Contains('lossDebounceReserved')
}

$failed = @()
foreach ($item in $checks.GetEnumerator()) {
    if ($item.Value) {
        Write-Host "$($item.Key): OK"
    }
    else {
        Write-Host "$($item.Key): FAIL"
        $failed += $item.Key
    }
}

if ($failed.Count -gt 0) {
    throw "Mixed-aspect layout stability checks failed: $($failed -join ', ')"
}

Write-Host 'Mixed-aspect layout stability checks OK.'
