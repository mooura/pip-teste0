﻿$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$main = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\MainWindow.xaml.cs') -Raw
$bridge = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\Services\ExtensionBridgeService.cs') -Raw
$background = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Extension\background.js') -Raw
$autoReturnState = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\Models\AutoReturnSlotState.cs') -Raw
$eventSource = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Core\Core\Automation\AutomationEvent.cs') -Raw
$stateMachine = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Core\Core\Slots\SlotStateMachine.cs') -Raw

function Check([string]$name, [bool]$condition) {
    if (-not $condition) {
        Write-Host "FAIL: $name" -ForegroundColor Red
        exit 1
    }
    Write-Host "PASS: $name" -ForegroundColor Green
}

Check 'tab discovery event is exposed' ($bridge.Contains('Action<string, IReadOnlyList<TabDiscoveryInfo>>') -and $bridge.Contains('TabDiscoveryUpdated?.Invoke(requestId, discovery)'))
Check 'snapshot request carries correlation id' ($bridge.Contains('RequestVideoSessionsSnapshotAsync(bool force = false, string correlationId = "")') -and $bridge.Contains('requestId = correlationId ?? string.Empty'))
$echoesSnapshotRequestId = $background.Contains("requestAllVideoStates(String(message.requestId ||")
$echoesDiagnosticRequestId = $background.Contains("requestId: requestId ||")
Check 'extension echoes correlation id' ($echoesSnapshotRequestId -and $echoesDiagnosticRequestId)
Check 'tab discovery includes raw and session counts' ($bridge.Contains('RawVideoCount = rawVideos') -and $bridge.Contains('SessionCount = sessions'))
Check 'fresh no-video authority exists' ($main.Contains('TryGetFreshNoVideoTabAuthority'))
Check 'stale candidate is rejected before physical gate' ($main.Contains('auto-return-fresh-snapshot-no-video-deferred') -and $main.Contains('staleCandidateRejected=True') -and $main.Contains('physicalGateAcquired=False'))
Check 'invalid HWND is cleared while preserving pair' ($main.Contains('auto-return-stale-hwnd-cleared') -and $main.Contains('pairPreserved='))
$autoReturnMethodStart = $main.IndexOf('private async Task TryAutoReturnSlotAsync')
$freshGateIndex = $main.IndexOf('auto-return-fresh-snapshot-no-video-deferred', $autoReturnMethodStart)
$physicalGateIndex = $main.IndexOf('_autoReturnExecutionGate.WaitAsync', $autoReturnMethodStart)
Check 'fresh gate precedes physical semaphore' ($autoReturnMethodStart -ge 0 -and $freshGateIndex -gt $autoReturnMethodStart -and $physicalGateIndex -gt $freshGateIndex)
Check 'correlated response is mandatory' ($main.Contains('_extensionTabDiscoveryCorrelationId') -and $main.Contains('string.Equals(_extensionTabDiscoveryCorrelationId, correlationId, StringComparison.Ordinal)') -and $main.Contains('auto-return-fresh-snapshot-timeout-deferred'))
$focuslessStart = $main.IndexOf('private async Task<bool> AutoReturnFocuslessOnceAsync')
$preShortcutGate = $main.IndexOf('auto-return-pre-shortcut-fresh-snapshot-deferred', $focuslessStart)
$shortcutSend = $main.IndexOf('SendOpenPictureInPictureShortcutToForegroundAsync', $focuslessStart)
Check 'correlated pre-shortcut gate precedes key send' ($focuslessStart -ge 0 -and $preShortcutGate -gt $focuslessStart -and $shortcutSend -gt $preShortcutGate)
Check 'pre-shortcut deferral does not consume physical retry' ($autoReturnState.Contains('PhysicalAttemptDeferredForFreshSnapshot') -and $main.Contains('auto-return-physical-attempt-deferred-by-correlated-snapshot') -and $main.Contains('physicalShortcutSent=False'))
Check 'retry queue event exists' ($eventSource.Contains('ReconnectRetryQueued'))
Check 'retry queue transitions Failed to WaitingForReconnect' ($stateMachine.Contains('OnReconnectRetryQueued') -and $stateMachine.Contains('retry normalizado após Failed'))

Write-Host 'AUTORETURN FRESH SNAPSHOT NO-VIDEO GATE CHECK OK.' -ForegroundColor Green
