# Molde relativo, transformação de grupo e recuperação

## Escopo

Esta mudança consolida apenas posicionamento, transformação e aplicação do grupo de
PiPs. Captura, playlist, identidade de vídeo, vínculo com slots e seleção de alvo do
AutoReturn continuam usando o comportamento anterior.

## Autoridade de layout

`RelativeGroupLayout` persiste uma âncora do grupo e, para cada slot, deslocamento,
largura e altura. `GroupTransformEngine` materializa esse molde no monitor atual por
translação única, preservando toda a topologia.

Layouts absolutos antigos são migrados no carregamento. Depois da migração, o molde
relativo passa a ser a autoridade persistida.

## Travar conjunto

Durante o arraste, o HWND usado como alça acompanha o movimento natural do Windows e
os demais PiPs são atualizados por lote. Ao terminar, todos os HWNDs ativos, inclusive
a alça, são consolidados em uma aplicação única via `BeginDeferWindowPos`,
`DeferWindowPos` e `EndDeferWindowPos`.

## Fixar layout e área reservada

Ao ativar `Fixar layout`, as posições visuais atuais são capturadas sem mover os PiPs.
A aplicação mantém internamente o retângulo de exclusão do grupo e reposiciona janelas
comuns que invadirem essa área. Isso é uma reserva administrada pelo PiP Manager, não
uma AppBar do Windows.

## AutoReturn

Quando começa uma recuperação, o motor registra o conjunto de slots esperados. Cada
PiP recuperado é encaixado uma vez no seu próprio retângulo, sem reorganizar o grupo.
Após todos os slots esperados retornarem, ou após 45 segundos, é executado somente um
lote final. O debounce ordinário e a fiscalização periódica de layout ficam suspensos
durante esse ciclo.

## Regressão

`CHECK_RELATIVE_GROUP_LAYOUT_RECOVERY.ps1` verifica a integração estrutural. Os testes
executáveis de `PiPManager.WindowEventMonitor.Tests` cobrem captura do molde, translação,
encaixe exato e contenção no monitor sem deformação.
