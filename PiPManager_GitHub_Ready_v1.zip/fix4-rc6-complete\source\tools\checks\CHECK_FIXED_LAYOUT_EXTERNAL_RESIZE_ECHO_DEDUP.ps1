﻿$ErrorActionPreference = 'Stop'

$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$main = Get-Content -Raw -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\MainWindow.xaml.cs')
$fixedLayout = Get-Content -Raw -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\MainWindow.FixedLayout.cs')
$pipDrag = Get-Content -Raw -LiteralPath (Join-Path $root 'src\PiPManager.Wpf\MainWindow.PipDrag.cs')
$runCore = Get-Content -Raw -LiteralPath (Join-Path $root 'RUN_CORE_TESTS.bat')

$checks = [ordered]@{
    'persistent HWND echo cache exists' = $fixedLayout.Contains('_fixedLayoutResizeEchoByHwnd') -and $fixedLayout.Contains('FixedLayoutResizeEchoState')
    'echo identity stores slot rect and layout generation' = $fixedLayout.Contains('int SlotNumber') -and $fixedLayout.Contains('NativeRect NaturalRect') -and $fixedLayout.Contains('int FirstObservedLayoutGeneration')
    'visual rectangle comparison uses two-pixel tolerance' = $fixedLayout.Contains('FixedLayoutExternalResizeEchoTolerancePx = 2') -and $fixedLayout.Contains('RectsEqualWithinTolerance(')
    'repeated browser geometry is explicitly ignored' = $fixedLayout.Contains('fixed-layout-external-size-echo-ignored') -and $fixedLayout.Contains('manualGestureActive=False; reflowQueued=False')
    'first unseen browser geometry remains eligible for one reflow' = $fixedLayout.Contains('fixed-layout-external-size-observation-recorded') -and $fixedLayout.Contains('reflowQueued=True')
    'native manual resize bypasses echo classification' = $fixedLayout.Contains('fixed-layout-external-size-manual-gesture-observed') -and $fixedLayout.Contains('authorityCommittedOnMouseUp=True')
    'polling gate runs before resized slot admission' = $main.Contains('ShouldSuppressFixedLayoutExternalResizeEcho(slot, rect, previousRect)') -and $main.Contains('if (!suppressFixedLayoutEcho)')
    'manual resize commit clears stale echo state' = $pipDrag.Contains('ClearFixedLayoutExternalResizeEcho(handle, "manual-resize-committed")')
    'destroyed or removed HWND clears echo state' = $main.Contains('ClearFixedLayoutExternalResizeEcho(handle, "slot-window-removed")')
    'fixed layout toggle resets echo cache' = $fixedLayout.Contains('ClearAllFixedLayoutExternalResizeEchoes("fixed-layout-enabled")') -and $fixedLayout.Contains('ClearAllFixedLayoutExternalResizeEchoes("fixed-layout-disabled")')
    'runtime diagnostic carries generations and age' = $fixedLayout.Contains('firstObservedGeneration=') -and $fixedLayout.Contains('currentGeneration=') -and $fixedLayout.Contains('ageMs=')
    'checker is included in core gate' = $runCore.Contains('CHECK_FIXED_LAYOUT_EXTERNAL_RESIZE_ECHO_DEDUP.ps1')
}

$failed = @()
foreach ($item in $checks.GetEnumerator()) {
    if ($item.Value) {
        Write-Host "$($item.Key): OK"
    }
    else {
        Write-Host "$($item.Key): FAIL"
        $failed += $item.Key
    }
}

if ($failed.Count -gt 0) {
    throw "Fixed-layout external resize echo checks failed: $($failed -join ', ')"
}

Write-Host 'Fixed-layout external resize echo dedup checks OK.'
