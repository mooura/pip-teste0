# Validação local — P0 Optimization RC2

## Falha recebida do Windows

O log confirmou:

- build do `PiPManager.Native.dll`: aprovado;
- `PiPManager.Core.Tests`: aprovado;
- checks da extensão, AutoReturn, layouts, fluidez e motor nativo: aprovados;
- única falha: `current app version matches release` no gate de consolidação.

## Correção aplicada

A versão corrente foi uniformizada como `1.5.12.3905` em:

- projeto WPF;
- `ReleaseInfoService.cs`;
- `VERSION_STABLE.txt`;
- checks que fixam a versão da linha 9.39.03;
- documentação corrente.

O baseline histórico da Fase 1 (`1.5.12.3901`) foi preservado, pois documenta a
versão de origem e não representa a versão atual do aplicativo.

## Limitação local

Este ambiente não possui Windows, PowerShell nem SDK .NET. A validação final do
WPF e dos gates PowerShell deve ser executada com `BUILD_WINDOWS.bat` no Windows.
