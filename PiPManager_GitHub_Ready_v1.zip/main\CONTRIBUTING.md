# Contributing to PiPManager

Thank you for your interest in contributing to PiPManager! This document provides guidelines and instructions for contributing to the project.

## Code of Conduct

- Be respectful and inclusive
- Focus on the code, not the person
- Help others learn and grow
- Report issues appropriately

## Getting Started

### Prerequisites
- Windows 10 or later
- Visual Studio 2022 or later
- .NET 8 SDK
- Git
- Firefox (for extension testing)

### Development Setup

1. **Fork the repository**
   ```bash
   git clone https://github.com/your-username/PiPManager.git
   cd PiPManager
   ```

2. **Choose your branch**
   ```bash
   git checkout fix4-rc6          # For stable development
   # OR
   git checkout pip12h4-hotfix8   # For cutting-edge features
   ```

3. **Build the project**
   - See `SETUP_FIX4_RC6.md` or `SETUP_PIP12H4.md` in your branch

4. **Create a feature branch**
   ```bash
   git checkout -b feature/your-feature-name
   git checkout -b fix/your-fix-name
   ```

## Development Workflow

### Before Starting

1. Check existing issues and pull requests
2. Discuss major changes in an issue first
3. Follow the existing code style and conventions

### Making Changes

1. **Keep commits focused**
   - One logical change per commit
   - Clear, descriptive commit messages

2. **Code Standards**
   - Use meaningful variable and method names
   - Add comments for complex logic
   - Follow C# and JavaScript conventions
   - No trailing whitespace

3. **Testing**
   - Test your changes locally
   - Ensure existing tests still pass
   - Add tests for new functionality
   - Test in Firefox for extension changes

4. **Documentation**
   - Update README files if relevant
   - Document API changes
   - Add inline comments for non-obvious code

### Submitting Changes

1. **Push to your fork**
   ```bash
   git push origin feature/your-feature-name
   ```

2. **Create a Pull Request**
   - Link to related issues
   - Describe what changed and why
   - Include test results
   - Add screenshots/GIFs for UI changes

3. **PR Title Format**
   ```
   [fix4-rc6] Fix crash when switching tabs
   [pip12h4-hotfix8] Add support for new video platform
   [docs] Update build instructions
   ```

4. **PR Description Template**
   ```markdown
   ## Description
   Brief description of changes

   ## Type of Change
   - [ ] Bug fix
   - [ ] New feature
   - [ ] Enhancement
   - [ ] Documentation
   - [ ] Refactoring

   ## Related Issues
   Closes #(issue number)

   ## Testing
   - [ ] Tested in fix4-rc6 branch
   - [ ] Tested in pip12h4-hotfix8 branch
   - [ ] Firefox extension tested
   - [ ] WPF application tested

   ## Screenshots
   (if applicable)
   ```

## Branch-Specific Guidelines

### fix4-rc6 (Stable Branch)
- Minimal changes
- Bug fixes and critical improvements only
- Thoroughly tested before PR
- Backward compatible changes only

### pip12h4-hotfix8 (Development Branch)
- New features welcome
- More experimental changes acceptable
- Still require testing and documentation
- Should eventually stabilize into fix4-rc6

## Review Process

1. **Automated Checks**
   - Code builds successfully
   - No new compiler warnings
   - Tests pass

2. **Code Review**
   - Maintainers review for:
     - Code quality
     - Architecture fit
     - Test coverage
     - Documentation
   - Be prepared to make requested changes

3. **Approval & Merge**
   - At least one approval required
   - All CI checks must pass
   - Maintainer merges PR

## Reporting Issues

### Bug Reports
Include:
- Clear, descriptive title
- Steps to reproduce
- Expected vs. actual behavior
- System information (Windows version, .NET version)
- Branch affected (fix4-rc6 or pip12h4-hotfix8)
- Error logs or screenshots

### Feature Requests
Include:
- Clear description of desired feature
- Use case and benefits
- Potential implementation approach
- Mockups or examples (if applicable)

## Project Structure

### Desktop Application (WPF)
```
PiPManager/
├── Core/
│   ├── Services/          # Business logic
│   ├── Models/            # Data models
│   └── Utilities/         # Helper functions
├── UI/
│   ├── Views/             # XAML windows
│   ├── ViewModels/        # View logic
│   └── Resources/         # Styles, templates
├── Configuration/         # Settings, preferences
└── Tests/                 # Unit and integration tests
```

### Firefox Extension
```
Extension/
├── content/               # Content scripts
├── background/            # Service workers
├── popup/                 # Popup UI
├── options/               # Settings page
├── manifest.json          # Extension manifest
└── tests/                 # Extension tests
```

## Coding Conventions

### C# (.NET)
```csharp
// Classes and methods
public class VideoManager
{
    private string _videoId;
    
    public void Initialize(string videoId)
    {
        // Implementation
    }
}

// Use meaningful names
// Use async/await for I/O
// Handle exceptions appropriately
```

### JavaScript (Firefox Extension)
```javascript
// Use modern ES6+ syntax
const handleVideoChange = (videoId) => {
  // Implementation
};

// Clear, descriptive names
// Proper error handling
// Consistent indentation
```

## Performance Considerations

- Minimize memory usage
- Optimize video detection algorithms
- Reduce browser extension overhead
- Profile before and after changes

## Security

- Don't commit secrets or credentials
- Validate user input
- Follow browser extension security best practices
- Report security issues responsibly

## Questions?

- Open an issue for discussions
- Check existing documentation
- Ask in PR comments for specific guidance

## License

By contributing, you agree that your contributions will be licensed under the same license as the project (MIT License).

---

**Thank you for contributing to PiPManager!** 🎉

Your efforts help make PiPManager better for everyone.
