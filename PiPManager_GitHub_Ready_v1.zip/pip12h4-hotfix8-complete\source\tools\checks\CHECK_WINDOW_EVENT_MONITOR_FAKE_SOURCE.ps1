$ErrorActionPreference = "Stop"
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$fakePath = Join-Path $root "src\PiPManager.Wpf\Services\FakeWindowEventMonitorSource.cs"
$monitorPath = Join-Path $root "src\PiPManager.Wpf\Services\WindowsEventMonitorService.cs"
$testPath = Join-Path $root "tests\PiPManager.WindowEventMonitor.Tests\Program.cs"
$testProject = Join-Path $root "tests\PiPManager.WindowEventMonitor.Tests\PiPManager.WindowEventMonitor.Tests.csproj"

$fake = Get-Content $fakePath -Raw
$monitor = Get-Content $monitorPath -Raw
$test = Get-Content $testPath -Raw
$testProjectSource = Get-Content $testProject -Raw

foreach ($required in @(
  "EmitCreateMoveDuplicateDestroyForTest",
  "GetSnapshotForTest",
  "WindowMonitorEventKind.Created",
  "WindowMonitorEventKind.MovedOrResized",
  "WindowMonitorEventKind.Destroyed"
)) {
  if (!$fake.Contains($required) -and !$monitor.Contains($required) -and !$test.Contains($required)) {
    throw "Fake source coverage missing: $required"
  }
}

foreach ($required in @(
  "expected 3 received events",
  "expected 1 discarded duplicate",
  "LastEventKind == WindowMonitorEventKind.Destroyed.ToString()",
  "destroy should be identified from HWND cache",
  "FakeHealthService",
  "suppressed movement should not be received",
  "flow control suppression count mismatch",
  "WindowEventMonitor movement flow-control sequence OK."
)) {
  if (!$test.Contains($required)) {
    throw "Fake test missing assertion: $required"
  }
}

if (!(Test-Path $testProject)) {
  throw "Window event monitor fake test project missing"
}

if (!$testProjectSource.Contains('WindowEventFlowControlService.cs" Link=')) {
  throw "Fake test project missing movement flow-control source link"
}

Write-Host "Window event monitor fake source checks OK."
