# Correção do gate de build da extensão 1.4.39.12

O pacote já declarava a extensão `1.4.39.12` no `manifest.json`, no bridge e no aplicativo WPF, mas três verificações de regressão ainda exigiam a versão antiga `1.4.39.5`.

Foram atualizados:

- `CHECK_ADVERTISEMENT_VIDEO_ISOLATION.ps1`
- `CHECK_PLAYBACK_FLUENCY_GUARDS.ps1`
- `CHECK_NATIVE_LAYOUT_ENGINE_PHASE1.ps1`

A alteração corrige apenas o contrato de versão dos testes. Nenhuma lógica de preload, layout, AutoReturn ou isolamento de anúncios foi modificada.

## Correção complementar da baseline de consolidação

O gate `CHECK_CONSOLIDATION_PHASE1_BASELINE.ps1` também compara a versão declarada em `docs/consolidation/baseline.json` com o `manifest.json` e o `ReleaseInfoService.cs`. A baseline ativa e sua documentação foram sincronizadas de `1.4.39.5` para `1.4.39.12`.

Esta correção altera somente metadados e documentação de versão; não modifica a execução da extensão.
