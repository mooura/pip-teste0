﻿using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls.Primitives;
using PiPManager.Wpf.Models;

namespace PiPManager.Wpf;

public partial class SlotLayoutEditorWindow : Window
{
    private readonly NativeRect _screenBoundsPx;

    public ObservableCollection<EditableSlotRect> Slots { get; } = [];

    public SlotLayoutEditorWindow(NativeRect screenBoundsPx, IReadOnlyList<NativeRect> slotRectsPx)
    {
        InitializeComponent();
        _screenBoundsPx = screenBoundsPx;
        DataContext = this;

        var dpiX = 1.0;
        var dpiY = 1.0;
        Left = screenBoundsPx.Left / dpiX;
        Top = screenBoundsPx.Top / dpiY;
        Width = screenBoundsPx.Width / dpiX;
        Height = screenBoundsPx.Height / dpiY;

        for (var index = 0; index < slotRectsPx.Count; index++)
        {
            var rect = slotRectsPx[index];
            Slots.Add(new EditableSlotRect(
                index + 1,
                rect.Left - screenBoundsPx.Left,
                rect.Top - screenBoundsPx.Top,
                rect.Width,
                rect.Height));
        }
    }

    public IReadOnlyList<NativeRect> ExportRects()
    {
        return Slots
            .Select(slot => new NativeRect(
                _screenBoundsPx.Left + (int)Math.Round(slot.Left),
                _screenBoundsPx.Top + (int)Math.Round(slot.Top),
                _screenBoundsPx.Left + (int)Math.Round(slot.Left + slot.Width),
                _screenBoundsPx.Top + (int)Math.Round(slot.Top + slot.Height)))
            .ToArray();
    }

    private void MoveThumb_DragDelta(object sender, DragDeltaEventArgs e)
    {
        if (sender is not Thumb { DataContext: EditableSlotRect slot }) return;

        slot.Left = Math.Clamp(slot.Left + e.HorizontalChange, 0, Math.Max(0, _screenBoundsPx.Width - slot.Width));
        slot.Top = Math.Clamp(slot.Top + e.VerticalChange, 0, Math.Max(0, _screenBoundsPx.Height - slot.Height));
    }

    private void ResizeThumb_DragDelta(object sender, DragDeltaEventArgs e)
    {
        if (sender is not Thumb { DataContext: EditableSlotRect slot }) return;

        slot.Width = Math.Clamp(slot.Width + e.HorizontalChange, 120, Math.Max(120, _screenBoundsPx.Width - slot.Left));
        slot.Height = Math.Clamp(slot.Height + e.VerticalChange, 70, Math.Max(70, _screenBoundsPx.Height - slot.Top));
    }
}
