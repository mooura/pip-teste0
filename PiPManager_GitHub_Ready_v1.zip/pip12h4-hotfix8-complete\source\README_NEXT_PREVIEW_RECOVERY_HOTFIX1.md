# PIP FIX7 Hotfix 1 — recuperação de Next e preview

Versão da extensão: `1.4.39.17-next-preview-readiness-hotfix2`.

## Regressão confirmada pelo log

A Fase 3 podia responder `site-profile-next-not-found` ao comando Próximo e, quando a página ainda não expunha a playlist, publicava imediatamente `TARGET_NOT_FOUND / playlist-not-detected`. Como o WPF só mostra preview para `TARGET_RESOLVED`, o preview era removido e não voltava.

## Correções

- usa primeiro a URL do alvo autoritativo já resolvido para navegar;
- amplia a descoberta do cartão/link **Up Next**, aceitando botão, link e card;
- trata `playlist-not-detected` como transitório antes de desistir;
- executa retries limitados em 300, 600 e 900 ms;
- preserva por até cinco minutos o último alvo resolvido seguro durante revalidação;
- cancela retries e operações antigas quando a geração muda ou a página descarrega;
- preserva a state machine, o generation token e o guard do AutoReturn da Fase 3.

## Resultado esperado

O comando Próximo não deve depender exclusivamente de um seletor do perfil do site. Durante uma mudança temporária de DOM, o preview seguro permanece visível; somente após esgotar os retries o estado passa definitivamente para `TARGET_NOT_FOUND`.

## Validação disponível

- `tests/Extension.Tests/next-preview-recovery-hotfix1.test.js`
- `tools/checks/CHECK_NEXT_PREVIEW_RECOVERY_HOTFIX1.ps1`

O build Windows deve ser executado pelo usuário por meio de `BUILD_WINDOWS.bat`.
