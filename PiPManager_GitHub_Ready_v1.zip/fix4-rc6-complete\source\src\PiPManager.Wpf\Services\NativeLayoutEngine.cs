﻿using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using PiPManager.Wpf.Models;

namespace PiPManager.Wpf.Services;

public enum NativeLayoutEngineMode
{
    Off,
    Compare,
    Primary
}

internal readonly record struct NativeLayoutMove(IntPtr Handle, NativeRect Target);

internal readonly record struct NativeLayoutBatchExecution(
    bool Available,
    bool Success,
    int Attempted,
    int Prepared,
    int Applied,
    int Skipped,
    int Failed,
    bool FallbackUsed,
    int NativeVersion,
    double ElapsedMs,
    string FailureReason)
{
    public static NativeLayoutBatchExecution Unavailable(string reason, double elapsedMs = 0) =>
        new(false, false, 0, 0, 0, 0, 0, false, 0, elapsedMs, reason);
}

internal sealed class NativeLayoutEngine : IDisposable
{
    private const string LibraryName = "PiPManager.Native.dll";
    private const string VersionExport = "pip_native_version";
    private const string ProcessExport = "pip_process_window_batch";

    [StructLayout(LayoutKind.Sequential, Pack = 8)]
    private struct NativeMove
    {
        public long Hwnd;
        public int Left;
        public int Top;
        public int Right;
        public int Bottom;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 8)]
    private struct NativePreparedMove
    {
        public long Hwnd;
        public int RawLeft;
        public int RawTop;
        public int RawWidth;
        public int RawHeight;
        public int Status;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 8)]
    private struct NativeBatchResult
    {
        public int Attempted;
        public int Prepared;
        public int Applied;
        public int Skipped;
        public int Failed;
        public int FallbackUsed;
        public int NativeVersion;
    }

    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    private delegate int NativeVersionDelegate();

    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    private delegate int ProcessWindowBatchDelegate(
        IntPtr moves,
        int count,
        int pixelThreshold,
        int resizeToTarget,
        int coordinateMode,
        int dryRun,
        IntPtr preparedMoves,
        int preparedCapacity,
        IntPtr result);

    private readonly object _sync = new();
    private IntPtr _libraryHandle;
    private NativeVersionDelegate? _version;
    private ProcessWindowBatchDelegate? _process;
    private bool _loadAttempted;
    private string _loadFailure = string.Empty;
    private bool _disposed;

    public bool IsAvailable
    {
        get
        {
            EnsureLoaded();
            return _process is not null;
        }
    }

    public int Version
    {
        get
        {
            EnsureLoaded();
            try { return _version?.Invoke() ?? 0; }
            catch { return 0; }
        }
    }

    public string LoadFailure
    {
        get
        {
            EnsureLoaded();
            return _loadFailure;
        }
    }

    public NativeLayoutBatchExecution ProcessVisualBatch(
        IReadOnlyList<NativeLayoutMove> moves,
        int pixelThreshold,
        bool resizeToTargets,
        bool dryRun) =>
        ProcessBatch(moves, pixelThreshold, resizeToTargets, coordinateMode: 0, dryRun);

    public NativeLayoutBatchExecution ProcessRawBatch(
        IReadOnlyList<NativeLayoutMove> moves,
        int pixelThreshold,
        bool resizeToTargets,
        bool dryRun) =>
        ProcessBatch(moves, pixelThreshold, resizeToTargets, coordinateMode: 1, dryRun);

    private NativeLayoutBatchExecution ProcessBatch(
        IReadOnlyList<NativeLayoutMove> moves,
        int pixelThreshold,
        bool resizeToTargets,
        int coordinateMode,
        bool dryRun)
    {
        var stopwatch = Stopwatch.StartNew();
        EnsureLoaded();
        var process = _process;
        if (process is null)
            return NativeLayoutBatchExecution.Unavailable(string.IsNullOrWhiteSpace(_loadFailure) ? "native-library-unavailable" : _loadFailure, stopwatch.Elapsed.TotalMilliseconds);

        if (moves.Count == 0)
            return new NativeLayoutBatchExecution(true, true, 0, 0, 0, 0, 0, false, Version, stopwatch.Elapsed.TotalMilliseconds, string.Empty);

        if (moves.Count > 64)
            return NativeLayoutBatchExecution.Unavailable("native-batch-capacity-exceeded", stopwatch.Elapsed.TotalMilliseconds);

        var nativeMoves = new NativeMove[moves.Count];
        for (var index = 0; index < moves.Count; index++)
        {
            var move = moves[index];
            nativeMoves[index] = new NativeMove
            {
                Hwnd = move.Handle.ToInt64(),
                Left = move.Target.Left,
                Top = move.Target.Top,
                Right = move.Target.Right,
                Bottom = move.Target.Bottom
            };
        }

        var prepared = new NativePreparedMove[moves.Count];
        var result = new NativeBatchResult[1];
        GCHandle moveHandle = default;
        GCHandle preparedHandle = default;
        GCHandle resultHandle = default;

        try
        {
            moveHandle = GCHandle.Alloc(nativeMoves, GCHandleType.Pinned);
            preparedHandle = GCHandle.Alloc(prepared, GCHandleType.Pinned);
            resultHandle = GCHandle.Alloc(result, GCHandleType.Pinned);

            var returnCode = process(
                moveHandle.AddrOfPinnedObject(),
                nativeMoves.Length,
                Math.Max(0, pixelThreshold),
                resizeToTargets ? 1 : 0,
                coordinateMode,
                dryRun ? 1 : 0,
                preparedHandle.AddrOfPinnedObject(),
                prepared.Length,
                resultHandle.AddrOfPinnedObject());

            stopwatch.Stop();
            var value = result[0];
            return new NativeLayoutBatchExecution(
                Available: true,
                Success: returnCode != 0 && value.Failed == 0,
                Attempted: value.Attempted,
                Prepared: value.Prepared,
                Applied: value.Applied,
                Skipped: value.Skipped,
                Failed: value.Failed,
                FallbackUsed: value.FallbackUsed != 0,
                NativeVersion: value.NativeVersion,
                ElapsedMs: stopwatch.Elapsed.TotalMilliseconds,
                FailureReason: returnCode != 0 && value.Failed == 0 ? string.Empty : $"native-return={returnCode};failed={value.Failed}");
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            return NativeLayoutBatchExecution.Unavailable($"native-call-failed:{ex.GetType().Name}:{ex.Message}", stopwatch.Elapsed.TotalMilliseconds);
        }
        finally
        {
            if (resultHandle.IsAllocated) resultHandle.Free();
            if (preparedHandle.IsAllocated) preparedHandle.Free();
            if (moveHandle.IsAllocated) moveHandle.Free();
        }
    }

    private void EnsureLoaded()
    {
        lock (_sync)
        {
            if (_loadAttempted || _disposed)
                return;

            _loadAttempted = true;
            if (!OperatingSystem.IsWindows())
            {
                _loadFailure = "native-engine-requires-windows";
                return;
            }

            var candidates = new[]
            {
                Path.Combine(AppContext.BaseDirectory, LibraryName),
                LibraryName
            };

            foreach (var candidate in candidates)
            {
                try
                {
                    if (!NativeLibrary.TryLoad(candidate, out _libraryHandle) || _libraryHandle == IntPtr.Zero)
                        continue;

                    var versionPtr = NativeLibrary.GetExport(_libraryHandle, VersionExport);
                    var processPtr = NativeLibrary.GetExport(_libraryHandle, ProcessExport);
                    _version = Marshal.GetDelegateForFunctionPointer<NativeVersionDelegate>(versionPtr);
                    _process = Marshal.GetDelegateForFunctionPointer<ProcessWindowBatchDelegate>(processPtr);
                    _loadFailure = string.Empty;
                    return;
                }
                catch (Exception ex)
                {
                    if (_libraryHandle != IntPtr.Zero)
                    {
                        try { NativeLibrary.Free(_libraryHandle); } catch { }
                        _libraryHandle = IntPtr.Zero;
                    }
                    _version = null;
                    _process = null;
                    _loadFailure = $"native-load-failed:{ex.GetType().Name}:{ex.Message}";
                }
            }

            if (string.IsNullOrWhiteSpace(_loadFailure))
                _loadFailure = $"{LibraryName}-not-found";
        }
    }

    public void Dispose()
    {
        lock (_sync)
        {
            if (_disposed) return;
            _disposed = true;
            _process = null;
            _version = null;
            if (_libraryHandle != IntPtr.Zero)
            {
                try { NativeLibrary.Free(_libraryHandle); } catch { }
                _libraryHandle = IntPtr.Zero;
            }
        }
    }
}
