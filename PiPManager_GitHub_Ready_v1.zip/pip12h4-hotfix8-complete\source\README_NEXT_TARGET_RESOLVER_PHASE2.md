# Next Target Resolver — Phase 2

Versão da extensão: `1.4.39.14-next-target-resolver-phase2`.

## Objetivo

Separar a decisão de **qual é o próximo item** da execução de preview e preload.

## Regras

- `currentAssetId` e `nextAssetId` são resolvidos antes do preload.
- `nextAssetId` vazio produz `TARGET_NOT_FOUND`.
- `nextAssetId == currentAssetId` produz `TARGET_SAME_AS_CURRENT`.
- Apenas `TARGET_RESOLVED` pode iniciar resolução de mídia e preload.
- O cache não escolhe mais o último asset armazenado quando o preload é habilitado.
- Uma resolução assíncrona só publica mídia se ainda corresponder ao alvo atual.
- Preview inválido ou igual ao vídeo atual é descartado.

## Novos diagnósticos

- `next-preload-target-resolved`
- `next-preload-target-rejected`
- `next-preload-target-media-resolution-start`
- `next-preload-target-media-resolved`
- `next-preload-target-media-resolution-stale`
- `next-preload-skipped-unresolved-target`
- `next-preload-skipped-same-as-current`

## Escopo não alterado nesta fase

- retry visual com placeholder;
- state machine completa com generation token e AbortController;
- persistência integral do contexto diagnóstico entre eventos;
- redução do buffer para 8–12 segundos;
- geometria das janelas PiP.
