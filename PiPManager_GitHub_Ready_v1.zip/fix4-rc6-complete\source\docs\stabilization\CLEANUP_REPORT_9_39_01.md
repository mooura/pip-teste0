# Stabilization cleanup 9.39.01

## Scope

This cleanup is organizational only. Runtime behavior, navigation, AutoReturn,
Open All, layout, slot ownership and extension protocol are unchanged.

## Frozen recovery point

- Commit: `8f74b9f9892a776259f697ee72c5b55f52a48c4d`
- Tag: `v9.39.01-stable-navigation-baseline`

## Removed from the active tree

- 727 generated files under build/test output directories (`bin`, `obj`,
  `TestResults`, `artifacts`, `publish`) before the cleanup.
- Four obsolete consolidation gate logs.
- 237 historical text documents.

## Preserved externally

The historical documents are stored in `PiPManager_9_39_01_HISTORY_ARCHIVE.zip`.
Its file count and SHA-256 are recorded in `history-archive.json`. The original
files also remain recoverable from the frozen Git tag.

History archive SHA-256:
`B87240B93DF77FB6A84EAE13248F638C75903963DEC1C72CBADB805B4AD1AA56`.

## Active file inventory

`FILE_INVENTORY_9_39_01.csv` classifies the active files (the inventory file
itself is intentionally excluded) with disposition, reason, byte size and
SHA-256. No active file is marked for removal.

## Explicitly preserved in the active tree

- All runtime source and project files.
- All `CHECK_*.ps1` regression guards.
- Core, extension and Window Event tests.
- Native source, benchmark and validated native DLL.
- The validated DLL is stored at `src/PiPManager.Native/prebuilt/PiPManager.Native.dll`, not
  under an ignored build-output directory.

Validated native DLL SHA-256:
`9D4526CC29827233EA73E7244217EF2980C738A499E35E74B857546CB285C219`.
- Consolidation architecture documents and machine-readable manifests.

## Bloco 3

Os verificadores foram organizados em `tools/checks`, e os documentos em
`docs/consolidation` e `docs/stabilization`. Os projetos e arquivos do runtime
continuam em seus caminhos originais. A evidência detalhada está em
`BLOCK_03_STRUCTURE.md`.

## Deferred work

The projects now use the `src`, `tests` and `benchmarks` hierarchy documented in
`PART_04_PROJECT_STRUCTURE.md`. Splitting the large MainWindow/extension files
remains a separate refactor and must not be mixed with this structural baseline.

## Post-structure stabilization

The first functional correction after the structural baseline protects linked
slots from being deleted during simultaneous PiP loss and gives each queued
AutoReturn attempt a bounded per-slot lifetime. The diagnosis, invariants and
regression coverage are recorded in `AUTORETURN_BURST_RECOVERY_9_39_01.md`.

The same stabilization was subsequently accelerated without weakening HWND
ownership: readiness is parallel across slots, physical capture remains
single-flight, and failed attempts use a capped 500/1000/2000 ms per-slot
backoff instead of the previous fixed ten-second cooldown.
