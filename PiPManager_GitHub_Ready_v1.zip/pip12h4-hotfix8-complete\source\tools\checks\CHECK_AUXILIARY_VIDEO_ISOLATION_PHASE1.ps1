$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$content = Get-Content -Raw (Join-Path $root 'src\PiPManager.Extension\content.js')
$background = Get-Content -Raw (Join-Path $root 'src\PiPManager.Extension\background.js')
$manifest = Get-Content -Raw (Join-Path $root 'src\PiPManager.Extension\manifest.json') | ConvertFrom-Json
$release = Get-Content -Raw (Join-Path $root 'src\PiPManager.Wpf\Services\ReleaseInfoService.cs')
$runner = Get-Content -Raw (Join-Path $root 'RUN_CORE_TESTS.bat')

$checks = [ordered]@{
  'manifest is 1.4.39.25' = ([string]$manifest.version -eq '1.4.39.25')
  'release metadata is 1.4.39.25' = $release.Contains('ExtensionVersion = "1.4.39.25"')
  'phase identifier is synchronized' = $content.Contains("CONTENT_VERSION = '1.4.39.25-command-target-root-guard-hotfix10'") -and $background.Contains("BRIDGE_VERSION = '1.4.39.25-command-target-root-guard-hotfix10'")
  'preload transport remains isolated' = $content.Contains("video.dataset.pipManagerAuxiliary = '1'") -and ($content.Contains("video.dataset.pipManagerPreload = '1'") -or $content.Contains("type: 'pipManagerStartRangePreload'"))
  'auxiliary videos cannot enter PiP' = $content.Contains('video.disablePictureInPicture = true')
  'operational discovery filters auxiliary videos' = $content.Contains('.filter(video => !isPipManagerAuxiliaryVideo(video))')
  'snapshot telemetry separates DOM and auxiliary counts' = $content.Contains('domVideoCount') -and $content.Contains('auxiliaryVideoCount')
  'old document sessions are purged per tab and frame' = $background.Contains('sameTab && sameFrame && differentDocument')
  'node regression test is wired' = $runner.Contains('aux-video-isolation.test.js')
}

$failed = @()
foreach ($item in $checks.GetEnumerator()) {
  if ($item.Value) { Write-Host ($item.Key + ': OK') }
  else { Write-Host ($item.Key + ': FAIL'); $failed += $item.Key }
}
if ($failed.Count -gt 0) { throw ('Auxiliary video isolation Phase 1 checks failed: ' + ($failed -join ', ')) }
Write-Host 'Auxiliary video isolation Phase 1 checks OK.'
