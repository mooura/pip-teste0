﻿using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Windows;
using PiPManager.Wpf.Models;

namespace PiPManager.Wpf.Services;

internal readonly record struct DragTargetInfo(IntPtr Handle, NativeRect Rect);

internal sealed class PipGroupMouseDragService : IDisposable
{
    private const int WH_MOUSE_LL = 14;
    private const int WM_LBUTTONDOWN = 0x0201;
    private const int WM_LBUTTONUP = 0x0202;
    private const int WM_MOUSEMOVE = 0x0200;
    private const int WM_CANCELMODE = 0x001F;
    private const uint GA_ROOT = 2;

    private readonly Action<IntPtr, int, int> _started;
    private readonly Action<IntPtr, int, int> _delta;
    private readonly Action<IntPtr, int, int> _completed;
    private readonly object _sync = new();

    private LowLevelMouseProc? _proc;
    private IntPtr _hook = IntPtr.Zero;
    private DragTargetInfo[] _targets = [];
    private bool _dragging;
    private IntPtr _dragHandle = IntPtr.Zero;
    private int _startX;
    private int _startY;
    private int _lastDx;
    private int _lastDy;

    public PipGroupMouseDragService(
        Action<IntPtr, int, int> started,
        Action<IntPtr, int, int> delta,
        Action<IntPtr, int, int> completed)
    {
        _started = started;
        _delta = delta;
        _completed = completed;
    }

    public void Start()
    {
        if (_hook != IntPtr.Zero) return;
        _proc = HookCallback;
        using var process = Process.GetCurrentProcess();
        var module = process.MainModule;
        var moduleHandle = module is null ? IntPtr.Zero : GetModuleHandle(module.ModuleName);
        _hook = SetWindowsHookEx(WH_MOUSE_LL, _proc, moduleHandle, 0);
        if (_hook == IntPtr.Zero)
            AppLogger.Info("Hook de arraste por PiP não foi iniciado");
        else
            AppLogger.Info("Hook de arraste por PiP iniciado");
    }

    public void UpdateTargets(IEnumerable<DragTargetInfo> targets)
    {
        lock (_sync)
        {
            _targets = targets.Where(item => item.Handle != IntPtr.Zero && item.Rect.IsValid).ToArray();
        }
    }

    public void ClearTargets()
    {
        lock (_sync)
        {
            _targets = [];
            _dragging = false;
            _dragHandle = IntPtr.Zero;
        }
    }

    public void Dispose()
    {
        if (_hook != IntPtr.Zero)
        {
            UnhookWindowsHookEx(_hook);
            _hook = IntPtr.Zero;
        }
        _proc = null;
    }

    private IntPtr HookCallback(int nCode, IntPtr wParam, IntPtr lParam)
    {
        if (nCode < 0)
            return CallNextHookEx(_hook, nCode, wParam, lParam);

        MSLLHOOKSTRUCT info;
        try
        {
            info = Marshal.PtrToStructure<MSLLHOOKSTRUCT>(lParam);
        }
        catch
        {
            return CallNextHookEx(_hook, nCode, wParam, lParam);
        }

        var message = wParam.ToInt32();
        var x = info.pt.x;
        var y = info.pt.y;

        if (message == WM_LBUTTONDOWN)
        {
            var handle = HitTest(x, y, out var hitSource);
            if (handle != IntPtr.Zero)
            {
                lock (_sync)
                {
                    _dragging = true;
                    _dragHandle = handle;
                    _startX = x;
                    _startY = y;
                    _lastDx = x;
                    _lastDy = y;
                }

                Dispatch(() =>
                {
                    AppLogger.Info(
                        $"pip-drag-hit: hwnd=0x{handle.ToInt64():X}; source={hitSource}; " +
                        $"point={x},{y}; nativeHitTest=True");
                    _started(handle, x, y);
                });
                return CallNextHookEx(_hook, nCode, wParam, lParam);
            }
        }

        bool dragging;
        IntPtr dragHandle;
        lock (_sync)
        {
            dragging = _dragging;
            dragHandle = _dragHandle;
        }

        if (!dragging || dragHandle == IntPtr.Zero)
            return CallNextHookEx(_hook, nCode, wParam, lParam);

        if (message == WM_MOUSEMOVE)
        {
            var shouldDispatch = false;
            lock (_sync)
            {
                if (Math.Abs(x - _lastDx) >= 1 || Math.Abs(y - _lastDy) >= 1)
                {
                    _lastDx = x;
                    _lastDy = y;
                    shouldDispatch = true;
                }
            }
            if (shouldDispatch)
                Dispatch(() => _delta(dragHandle, x, y));
            return CallNextHookEx(_hook, nCode, wParam, lParam);
        }

        if (message == WM_LBUTTONUP || message == WM_CANCELMODE)
        {
            lock (_sync)
            {
                _dragging = false;
                _dragHandle = IntPtr.Zero;
            }
            Dispatch(() => _completed(dragHandle, x, y));
            return CallNextHookEx(_hook, nCode, wParam, lParam);
        }

        return CallNextHookEx(_hook, nCode, wParam, lParam);
    }

    private IntPtr HitTest(int x, int y, out string source)
    {
        source = "none";

        DragTargetInfo[] targets;
        lock (_sync)
            targets = _targets.ToArray();

        if (targets.Length == 0)
            return IntPtr.Zero;

        // A moldura de redimensionamento do Firefox pode ficar alguns pixels fora
        // do retângulo visual retornado pelo DWM. WindowFromPoint identifica o HWND
        // real sob o cursor inclusive nessa moldura não cliente.
        var point = new POINT { x = x, y = y };
        var windowAtPoint = WindowFromPoint(point);
        if (windowAtPoint != IntPtr.Zero)
        {
            var root = GetAncestor(windowAtPoint, GA_ROOT);
            foreach (var target in targets)
            {
                if (target.Handle == windowAtPoint || target.Handle == root)
                {
                    source = "window-from-point";
                    return target.Handle;
                }
            }
        }

        // Mantém o comportamento anterior para cliques dentro da imagem do PiP.
        foreach (var target in targets)
        {
            if (target.Rect.Contains(x, y))
            {
                source = "visual-rect";
                return target.Handle;
            }
        }

        // Não inventa uma margem externa ao HWND. O redimensionamento permanece
        // o comportamento nativo da janela PiP; o hook apenas observa o HWND real
        // devolvido pelo Windows ou um clique dentro do retângulo visual.
        return IntPtr.Zero;
    }

    private static void Dispatch(Action action)
    {
        var dispatcher = Application.Current?.Dispatcher;
        if (dispatcher is null || dispatcher.HasShutdownStarted)
            return;
        dispatcher.BeginInvoke(action);
    }

    private delegate IntPtr LowLevelMouseProc(int nCode, IntPtr wParam, IntPtr lParam);

    [StructLayout(LayoutKind.Sequential)]
    private struct POINT
    {
        public int x;
        public int y;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct MSLLHOOKSTRUCT
    {
        public POINT pt;
        public uint mouseData;
        public uint flags;
        public uint time;
        public IntPtr dwExtraInfo;
    }

    [DllImport("user32.dll", SetLastError = true)]
    private static extern IntPtr SetWindowsHookEx(int idHook, LowLevelMouseProc lpfn, IntPtr hMod, uint dwThreadId);

    [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    private static extern IntPtr GetModuleHandle(string? lpModuleName);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool UnhookWindowsHookEx(IntPtr hhk);

    [DllImport("user32.dll")]
    private static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);

    [DllImport("user32.dll")]
    private static extern IntPtr WindowFromPoint(POINT point);

    [DllImport("user32.dll")]
    private static extern IntPtr GetAncestor(IntPtr hWnd, uint gaFlags);
}
