﻿@echo off
setlocal
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_JOGO_PROFILE_LAYOUT.ps1"
if errorlevel 1 (
  echo.
  echo JOGO PROFILE CHECK FAILED.
  pause
  exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_JOGO_FIXED_LAYOUT_AUTHORITY.ps1"
if errorlevel 1 (
  echo.
  echo JOGO FIXED LAYOUT AUTHORITY CHECK FAILED.
  pause
  exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\checks\CHECK_JOGO_SPACE_HIDE_HOTKEY.ps1"
if errorlevel 1 (
  echo.
  echo JOGO SPACE HIDE/SHOW HOTKEY CHECK FAILED.
  pause
  exit /b 1
)

echo.
echo JOGO PROFILE CHECK OK.
pause
exit /b 0
