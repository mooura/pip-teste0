namespace PiPManager.Wpf.Models;

internal enum ReactorCaptureMode
{
    Legacy,
    Compare,
    Primary
}

