$ErrorActionPreference='Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$main=Get-Content (Join-Path $root 'src\PiPManager.Wpf\MainWindow.xaml.cs') -Raw
$cloakIndex = $main.IndexOf('manual-open-browser-prefocus-cloak')
$focusIndex = $main.IndexOf('var focusClients = await _extensionBridge.FocusVideoTabAsync(tab.TabId);')
$checks=@(
  [pscustomobject]@{ Name='manual pre-focus cloak marker'; Pass=$cloakIndex -ge 0 }
  [pscustomobject]@{ Name='cloak before focus command'; Pass=$cloakIndex -ge 0 -and $focusIndex -ge 0 -and $cloakIndex -lt $focusIndex }
  [pscustomobject]@{ Name='retry pre-focus cloak marker'; Pass=$main.Contains('manual-open-browser-retry-prefocus-cloak') }
  [pscustomobject]@{ Name='manual flow uses shared cloak service'; Pass=$main.Contains('VideoCommandService.PrepareBrowserForegroundCloak(manualPreFocusBrowserHwnd)') }
  [pscustomobject]@{ Name='DWM synchronized before manual focus'; Pass=$main.Contains('_ = Win32.DwmFlush();') }
)
$failed=0
foreach($c in $checks){if($c.Pass){Write-Host ($c.Name+': OK')}else{Write-Host ($c.Name+': FAIL');$failed++}}
if($failed -gt 0){throw 'Manual open pre-focus cloak checks failed.'}
Write-Host 'Manual open pre-focus cloak checks OK.'
