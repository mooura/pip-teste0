namespace PiPManager.Core.Automation;

/// <summary>
/// Regras puras que impedem uma troca manual/automática de vídeo de ser
/// reinterpretada como um segundo avanço automático.
/// </summary>
public static class AutoAdvanceSafetyPolicy
{
    public static bool ShouldArmLostPipWatch(bool navigationInProgress) =>
        !navigationInProgress;

    public static bool ShouldAcceptPlaybackTerminal(bool navigationInProgress) =>
        !navigationInProgress;

    public static bool IsProvenTerminalSnapshot(
        bool isEnded,
        bool isPlaying,
        int readyState,
        bool hasSource) =>
        isEnded && !isPlaying;
}
