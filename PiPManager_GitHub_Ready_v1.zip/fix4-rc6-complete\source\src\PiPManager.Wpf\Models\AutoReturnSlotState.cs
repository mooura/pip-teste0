namespace PiPManager.Wpf.Models;

internal sealed class AutoReturnSlotState
{
    public int SlotNumber { get; init; }
    public int TabId { get; init; }
    public string OldSession { get; init; } = string.Empty;
    public string OldStable { get; init; } = string.Empty;
    public string OldUrl { get; init; } = string.Empty;
    public string ExpectedBrowserProcess { get; init; } = string.Empty;
    public DateTime PendingSinceUtc { get; init; } = DateTime.UtcNow;
    public int MaxPendingAgeSeconds { get; init; }
    public DateTime CooldownUntilUtc { get; set; } = DateTime.MinValue;
    public bool InProgress { get; set; }
    public int SilentAttempts { get; set; }
    public int FocuslessAttempts { get; set; }
    public int RetryBackoffAttempt { get; set; }
    public int ReadinessDeferrals { get; set; }
    public bool PhysicalAttemptDeferredForFreshSnapshot { get; set; }
    public string Reason { get; set; } = string.Empty;
    public bool RequiresRealVideoChange { get; set; }
    public string EligibilityMode { get; set; } = "same-video-reopen";
    public string NavigationOperationId { get; set; } = string.Empty;
    public bool NavigationCommandResultReceived { get; set; }
    public bool NavigationCommandConfirmed { get; set; }
    public string CandidateKey { get; set; } = string.Empty;
    public DateTime CandidateFirstSeenUtc { get; set; } = DateTime.MinValue;
    public int CancellationGeneration { get; init; }
}
