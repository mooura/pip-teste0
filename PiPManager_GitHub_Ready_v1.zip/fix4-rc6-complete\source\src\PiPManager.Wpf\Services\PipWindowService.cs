﻿using PiPManager.Wpf.Models;

namespace PiPManager.Wpf.Services;

public sealed class PipWindowService
{
    private static readonly NativeLayoutEngine NativeEngine = new();
    private static NativeLayoutEngineMode _nativeLayoutMode = NativeLayoutEngineMode.Off;
    private static long _lastRawCompareTickMs;
    private static long _lastVisualCompareTickMs;
    private const int NativeCompareSampleIntervalMs = 250;

    public static NativeLayoutEngineMode NativeLayoutMode => _nativeLayoutMode;

    public static bool NativeLayoutEngineAvailable => NativeEngine.IsAvailable;

    public static int NativeLayoutEngineVersion => NativeEngine.Version;

    public static string NativeLayoutEngineFailure => NativeEngine.LoadFailure;

    public static void ConfigureNativeLayoutEngine(NativeLayoutEngineMode mode)
    {
        _nativeLayoutMode = mode;
        var available = mode != NativeLayoutEngineMode.Off && NativeEngine.IsAvailable;
        AppLogger.Info(
            $"native-layout-engine-configured: mode={mode}; available={available}; " +
            $"version={(available ? NativeEngine.Version : 0)}; failure={(available ? string.Empty : NativeEngine.LoadFailure)}");
    }

    public static bool IsUsable(IntPtr hWnd)
    {
        try
        {
            return hWnd != IntPtr.Zero && Win32.IsWindow(hWnd) && !Win32.IsIconic(hWnd);
        }
        catch { return false; }
    }

    public static NativeRect GetVisualRect(IntPtr hWnd) => Win32.GetWindowVisualRect(hWnd);

    public static bool IsTopMost(IntPtr hWnd)
    {
        try
        {
            if (hWnd == IntPtr.Zero || !Win32.IsWindow(hWnd))
                return false;

            var exStyle = Win32.GetWindowLongPtr(hWnd, Win32.GWL_EXSTYLE).ToInt64();
            return (exStyle & Win32.WS_EX_TOPMOST) != 0;
        }
        catch
        {
            return false;
        }
    }

    public static NativeRect GetRawRect(IntPtr hWnd) => Win32.GetWindowRectActual(hWnd);

    public static NativeRect GetVirtualScreenBounds() => Win32.GetVirtualScreenBounds();

    public static void MoveVisual(IntPtr hWnd, int left, int top)
    {
        if (!IsUsable(hWnd)) return;
        var current = GetVisualRect(hWnd);
        if (!current.IsValid) return;
        MoveVisualBatch(new[]
        {
            (Handle: hWnd, Target: new NativeRect(left, top, left + current.Width, top + current.Height))
        }, pixelThreshold: 0);
    }

    public static void MoveAndResizeVisual(IntPtr hWnd, NativeRect target)
    {
        if (!IsUsable(hWnd) || !target.IsValid) return;
        MoveAndResizeVisualBatch(new[] { (Handle: hWnd, Target: target) }, pixelThreshold: 0);
    }

    public static void ResizeVisual(IntPtr hWnd, int width, int height)
    {
        if (!IsUsable(hWnd)) return;
        var current = GetVisualRect(hWnd);
        if (!current.IsValid) return;
        MoveAndResizeVisual(hWnd, new NativeRect(current.Left, current.Top,
            current.Left + Math.Max(80, width), current.Top + Math.Max(45, height)));
    }

    public static void MoveRawPositionBatch(IEnumerable<(IntPtr Handle, int RawLeft, int RawTop)> moves)
    {
        var source = moves
            .Where(item => item.Handle != IntPtr.Zero && Win32.IsWindow(item.Handle))
            .Select(item => new NativeLayoutMove(
                item.Handle,
                new NativeRect(item.RawLeft, item.RawTop, item.RawLeft + 1, item.RawTop + 1)))
            .ToArray();

        if (source.Length == 0) return;

        if (_nativeLayoutMode == NativeLayoutEngineMode.Primary)
        {
            var native = NativeEngine.ProcessRawBatch(source, pixelThreshold: 0, resizeToTargets: false, dryRun: false);
            LogNativePrimary("raw-move", native, source.Length);
            if (native.Available && native.Success)
                return;

            AppLogger.WarnAggregated(
                "native-layout-primary-fallback-raw",
                TimeSpan.FromSeconds(10),
                $"native-layout-primary-fallback: operation=raw-move; requested={source.Length}; reason={native.FailureReason}; available={native.Available}");
        }

        NativeLayoutBatchExecution comparison = default;
        var sampledComparison = _nativeLayoutMode == NativeLayoutEngineMode.Compare
            && ShouldSampleComparison(ref _lastRawCompareTickMs);
        if (sampledComparison)
            comparison = NativeEngine.ProcessRawBatch(source, pixelThreshold: 0, resizeToTargets: false, dryRun: true);

        var managedPrepared = ApplyManagedRawPositionBatch(source);
        if (sampledComparison)
            LogNativeComparison("raw-move", comparison, managedPrepared, source.Length);
    }

    public static void MoveVisualBatch(IEnumerable<(IntPtr Handle, NativeRect Target)> moves, int pixelThreshold = 1)
    {
        ProcessVisualBatch(moves, pixelThreshold, resizeToTargets: false);
    }

    public static void MoveAndResizeVisualBatch(IEnumerable<(IntPtr Handle, NativeRect Target)> moves, int pixelThreshold = 1)
    {
        ProcessVisualBatch(moves, pixelThreshold, resizeToTargets: true);
    }

    private static void ProcessVisualBatch(
        IEnumerable<(IntPtr Handle, NativeRect Target)> moves,
        int pixelThreshold,
        bool resizeToTargets)
    {
        var source = moves
            .Where(item => item.Handle != IntPtr.Zero && item.Target.IsValid)
            .Select(item => new NativeLayoutMove(item.Handle, item.Target))
            .ToArray();

        if (source.Length == 0) return;

        var operation = resizeToTargets ? "visual-move-resize" : "visual-move";
        if (_nativeLayoutMode == NativeLayoutEngineMode.Primary)
        {
            var native = NativeEngine.ProcessVisualBatch(source, pixelThreshold, resizeToTargets, dryRun: false);
            LogNativePrimary(operation, native, source.Length);
            if (native.Available && native.Success)
                return;

            AppLogger.WarnAggregated(
                $"native-layout-primary-fallback-{operation}",
                TimeSpan.FromSeconds(10),
                $"native-layout-primary-fallback: operation={operation}; requested={source.Length}; reason={native.FailureReason}; available={native.Available}");
        }

        NativeLayoutBatchExecution comparison = default;
        var sampledComparison = _nativeLayoutMode == NativeLayoutEngineMode.Compare
            && ShouldSampleComparison(ref _lastVisualCompareTickMs);
        if (sampledComparison)
            comparison = NativeEngine.ProcessVisualBatch(source, pixelThreshold, resizeToTargets, dryRun: true);

        var managedPrepared = resizeToTargets
            ? ApplyManagedMoveAndResizeVisualBatch(source, pixelThreshold)
            : ApplyManagedMoveVisualBatch(source, pixelThreshold);

        if (sampledComparison)
            LogNativeComparison(operation, comparison, managedPrepared, source.Length);
    }

    private static int ApplyManagedRawPositionBatch(IReadOnlyList<NativeLayoutMove> moves)
    {
        if (moves.Count == 0) return 0;

        const uint flags = Win32.SWP_NOSIZE | Win32.SWP_NOZORDER | Win32.SWP_NOACTIVATE | Win32.SWP_ASYNCWINDOWPOS;
        var defer = Win32.BeginDeferWindowPos(moves.Count);
        if (defer == IntPtr.Zero)
        {
            foreach (var item in moves)
                Win32.SetWindowPos(item.Handle, IntPtr.Zero, item.Target.Left, item.Target.Top, 0, 0, flags);
            return moves.Count;
        }

        foreach (var item in moves)
        {
            var next = Win32.DeferWindowPos(defer, item.Handle, IntPtr.Zero, item.Target.Left, item.Target.Top, 0, 0, flags);
            if (next == IntPtr.Zero)
            {
                Win32.EndDeferWindowPos(defer);
                foreach (var fallback in moves)
                    Win32.SetWindowPos(fallback.Handle, IntPtr.Zero, fallback.Target.Left, fallback.Target.Top, 0, 0, flags);
                return moves.Count;
            }
            defer = next;
        }

        Win32.EndDeferWindowPos(defer);
        return moves.Count;
    }

    private static int ApplyManagedMoveVisualBatch(IReadOnlyList<NativeLayoutMove> moves, int pixelThreshold)
    {
        var prepared = new List<(IntPtr Handle, int RawLeft, int RawTop)>();

        foreach (var item in moves)
        {
            var hWnd = item.Handle;
            var target = item.Target;
            if (!IsUsable(hWnd) || !target.IsValid) continue;

            var raw = GetRawRect(hWnd);
            var visual = GetVisualRect(hWnd);
            if (!raw.IsValid || !visual.IsValid) continue;

            if (Math.Abs(visual.Left - target.Left) <= pixelThreshold &&
                Math.Abs(visual.Top - target.Top) <= pixelThreshold)
                continue;

            var offsetX = raw.Left - visual.Left;
            var offsetY = raw.Top - visual.Top;
            prepared.Add((hWnd, target.Left + offsetX, target.Top + offsetY));
        }

        if (prepared.Count == 0) return 0;

        var defer = Win32.BeginDeferWindowPos(prepared.Count);
        if (defer == IntPtr.Zero)
        {
            foreach (var item in prepared)
                Win32.SetWindowPos(item.Handle, Win32.HWND_TOPMOST, item.RawLeft, item.RawTop, 0, 0,
                    Win32.SWP_NOSIZE | Win32.SWP_NOACTIVATE);
            return prepared.Count;
        }

        foreach (var item in prepared)
        {
            var next = Win32.DeferWindowPos(defer, item.Handle, Win32.HWND_TOPMOST, item.RawLeft, item.RawTop, 0, 0,
                Win32.SWP_NOSIZE | Win32.SWP_NOACTIVATE);
            if (next == IntPtr.Zero)
            {
                Win32.EndDeferWindowPos(defer);
                foreach (var fallback in prepared)
                    Win32.SetWindowPos(fallback.Handle, Win32.HWND_TOPMOST, fallback.RawLeft, fallback.RawTop, 0, 0,
                        Win32.SWP_NOSIZE | Win32.SWP_NOACTIVATE);
                return prepared.Count;
            }
            defer = next;
        }

        Win32.EndDeferWindowPos(defer);
        return prepared.Count;
    }

    private static int ApplyManagedMoveAndResizeVisualBatch(IReadOnlyList<NativeLayoutMove> moves, int pixelThreshold)
    {
        var prepared = new List<(IntPtr Handle, int RawLeft, int RawTop, int RawWidth, int RawHeight)>();

        foreach (var item in moves)
        {
            var hWnd = item.Handle;
            var target = item.Target;
            if (!IsUsable(hWnd) || !target.IsValid) continue;

            var raw = GetRawRect(hWnd);
            var visual = GetVisualRect(hWnd);
            if (!raw.IsValid || !visual.IsValid) continue;

            if (Math.Abs(visual.Left - target.Left) <= pixelThreshold &&
                Math.Abs(visual.Top - target.Top) <= pixelThreshold &&
                Math.Abs(visual.Width - target.Width) <= pixelThreshold &&
                Math.Abs(visual.Height - target.Height) <= pixelThreshold)
                continue;

            var offsetX = raw.Left - visual.Left;
            var offsetY = raw.Top - visual.Top;
            var extraW = Math.Max(0, raw.Width - visual.Width);
            var extraH = Math.Max(0, raw.Height - visual.Height);
            prepared.Add((hWnd,
                target.Left + offsetX,
                target.Top + offsetY,
                Math.Max(80, target.Width + extraW),
                Math.Max(45, target.Height + extraH)));
        }

        if (prepared.Count == 0) return 0;

        const uint flags = Win32.SWP_NOACTIVATE;
        var defer = Win32.BeginDeferWindowPos(prepared.Count);
        if (defer == IntPtr.Zero)
        {
            foreach (var item in prepared)
                Win32.SetWindowPos(item.Handle, Win32.HWND_TOPMOST, item.RawLeft, item.RawTop, item.RawWidth, item.RawHeight, flags);
            return prepared.Count;
        }

        foreach (var item in prepared)
        {
            var next = Win32.DeferWindowPos(defer, item.Handle, Win32.HWND_TOPMOST,
                item.RawLeft, item.RawTop, item.RawWidth, item.RawHeight, flags);
            if (next == IntPtr.Zero)
            {
                Win32.EndDeferWindowPos(defer);
                foreach (var fallback in prepared)
                    Win32.SetWindowPos(fallback.Handle, Win32.HWND_TOPMOST,
                        fallback.RawLeft, fallback.RawTop, fallback.RawWidth, fallback.RawHeight, flags);
                return prepared.Count;
            }
            defer = next;
        }

        Win32.EndDeferWindowPos(defer);
        return prepared.Count;
    }

    private static bool ShouldSampleComparison(ref long lastCompareTickMs)
    {
        var now = Environment.TickCount64;
        while (true)
        {
            var last = Volatile.Read(ref lastCompareTickMs);
            if (now - last < NativeCompareSampleIntervalMs)
                return false;
            if (Interlocked.CompareExchange(ref lastCompareTickMs, now, last) == last)
                return true;
        }
    }

    private static void LogNativeComparison(
        string operation,
        NativeLayoutBatchExecution native,
        int managedPrepared,
        int requested)
    {
        var parity = native.Available && native.Success && native.Prepared == managedPrepared;
        AppLogger.InfoAggregated(
            $"native-layout-compare-{operation}",
            TimeSpan.FromSeconds(10),
            $"native-layout-compare: operation={operation}; requested={requested}; available={native.Available}; " +
            $"nativePrepared={native.Prepared}; managedPrepared={managedPrepared}; parity={parity}; " +
            $"nativeMs={native.ElapsedMs:F3}; nativeVersion={native.NativeVersion}; reason={native.FailureReason}");
    }

    private static void LogNativePrimary(string operation, NativeLayoutBatchExecution native, int requested)
    {
        AppLogger.InfoAggregated(
            $"native-layout-primary-{operation}",
            TimeSpan.FromSeconds(10),
            $"native-layout-primary: operation={operation}; requested={requested}; available={native.Available}; success={native.Success}; " +
            $"prepared={native.Prepared}; applied={native.Applied}; skipped={native.Skipped}; failed={native.Failed}; " +
            $"fallbackInsideNative={native.FallbackUsed}; nativeMs={native.ElapsedMs:F3}; nativeVersion={native.NativeVersion}; reason={native.FailureReason}");
    }

    public static void SetTopMost(IntPtr hWnd)
    {
        if (hWnd != IntPtr.Zero && Win32.IsWindow(hWnd))
            Win32.SetWindowPos(hWnd, Win32.HWND_TOPMOST, 0, 0, 0, 0,
                Win32.SWP_NOMOVE | Win32.SWP_NOSIZE | Win32.SWP_NOACTIVATE | Win32.SWP_ASYNCWINDOWPOS);
    }

    public static void Close(IntPtr hWnd)
    {
        if (hWnd != IntPtr.Zero && Win32.IsWindow(hWnd))
            Win32.PostMessage(hWnd, Win32.WM_CLOSE, IntPtr.Zero, IntPtr.Zero);
    }

    public static void Hide(IntPtr hWnd)
    {
        if (hWnd != IntPtr.Zero && Win32.IsWindow(hWnd)) Win32.ShowWindow(hWnd, Win32.SW_HIDE);
    }

    public static void Show(IntPtr hWnd)
    {
        if (hWnd != IntPtr.Zero && Win32.IsWindow(hWnd))
        {
            Win32.ShowWindow(hWnd, Win32.SW_SHOW);
            Win32.SetWindowPos(hWnd, Win32.HWND_TOPMOST, 0, 0, 0, 0,
                Win32.SWP_NOMOVE | Win32.SWP_NOSIZE | Win32.SWP_NOACTIVATE);
        }
    }
}
