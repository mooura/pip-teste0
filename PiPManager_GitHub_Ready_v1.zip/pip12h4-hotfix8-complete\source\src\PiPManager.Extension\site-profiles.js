'use strict';

// Perfis por capacidade observável. Nenhum domínio é autoridade: a página é
// classificada pelo contexto de playlist, controles expostos e tipo de mídia.
const commonNextSelectors = Object.freeze([
  '[class*="player" i] [class*="next" i]', '[class*="controls" i] [class*="next" i]',
  '[data-action="next" i]', '[data-command="next" i]', '[data-testid*="next" i]',
  '[class*="next-model" i]', '[class*="next-room" i]', '[class*="next-stream" i]',
  '[class*="next-performer" i]', '[aria-label*="next" i]', '[aria-label*="próxim" i]',
  '[title*="next" i]', '[title*="próxim" i]', 'a[rel="next"]'
]);
const commonPreviousSelectors = Object.freeze([
  '[class*="player" i] [class*="prev" i]', '[class*="controls" i] [class*="prev" i]',
  '[data-action="previous" i]', '[data-command="previous" i]', '[data-testid*="previous" i]',
  'button[aria-label*="previous" i]', 'button[aria-label*="anterior" i]'
]);

const profiles = Object.freeze([
  Object.freeze({
    id: 'indexed-playlist',
    capability: 'numeric-playlist-position',
    contentKind: 'playlist',
    preferUrlIndexAdvance: true,
    allowUrlIndexAdvance: true,
    nextShortcut: { key: 'N', code: 'KeyN', keyCode: 78, shiftKey: true },
    previousShortcut: { key: 'P', code: 'KeyP', keyCode: 80, shiftKey: true },
    upNextLabels: ['up next', 'a seguir', 'próximo', 'proximo']
  }),
  Object.freeze({
    id: 'structured-playlist',
    capability: 'ordered-playlist-dom',
    contentKind: 'playlist-capable',
    nextSelectors: commonNextSelectors,
    previousSelectors: commonPreviousSelectors,
    structuredPlaylist: true,
    upNextLabels: ['up next', 'a seguir', 'próximo', 'proximo']
  }),
  Object.freeze({
    id: 'player-controls',
    capability: 'semantic-media-controls',
    contentKind: 'playlist-capable',
    nextSelectors: commonNextSelectors,
    previousSelectors: commonPreviousSelectors,
    restrictPlaylistRoots: true,
    upNextLabels: ['up next', 'a seguir', 'próximo', 'proximo']
  }),
  Object.freeze({
    id: 'live-rotation',
    capability: 'live-item-rotation',
    contentKind: 'live',
    playlistDisabled: true,
    preferDomNext: true,
    forceBrowserHistoryPrevious: true,
    nextSelectors: commonNextSelectors,
    previousSelectors: commonPreviousSelectors
  })
]);

function safeQuery(documentObject, selector) {
  try { return Boolean(documentObject?.querySelector?.(selector)); }
  catch (_) { return false; }
}

function normalizeSemanticText(value) {
  return String(value || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[_-]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

// Pontua descritores observáveis do controle, sem conhecer domínio ou produto.
// Isso cobre botões compostos apenas por SVG/ícone, comuns em páginas de rotação
// ao vivo, que não correspondem aos seletores CSS diretos acima.
function scoreNavigationDescriptor(direction, descriptor) {
  const text = normalizeSemanticText([
    descriptor?.ariaLabel,
    descriptor?.title,
    descriptor?.testId,
    descriptor?.action,
    descriptor?.command,
    descriptor?.name,
    descriptor?.id,
    descriptor?.className,
    descriptor?.text,
    descriptor?.icon
  ].filter(Boolean).join(' '));

  if (!text) return 0;

  const isNext = direction === 'next';
  const primary = isNext
    ? ['next', 'proximo', 'seguinte', 'forward', 'skip next', 'step forward']
    : ['previous', 'prev', 'anterior', 'voltar', 'backward', 'step backward'];
  const liveContext = ['model', 'room', 'stream', 'performer', 'profile', 'broadcast'];
  const iconDirection = isNext
    ? ['arrow right', 'chevron right', 'angle right', 'caret right']
    : ['arrow left', 'chevron left', 'angle left', 'caret left'];
  const opposite = isNext
    ? ['previous', 'prev', 'anterior', 'arrow left', 'chevron left']
    : ['next', 'proximo', 'seguinte', 'arrow right', 'chevron right'];
  const unsafe = ['seek', 'seconds', 'segundos', '10 sec', '15 sec', '30 sec', 'advert', ' anuncio ', 'carousel'];

  if (opposite.some(token => text.includes(token))) return -200;
  if (unsafe.some(token => (` ${text} `).includes(token))) return -150;

  let score = 0;
  if (primary.some(token => text.includes(token))) score += 70;
  if (liveContext.some(token => text.includes(token))) score += 35;
  if (iconDirection.some(token => text.includes(token))) score += 45;
  if (descriptor?.disabled === true) score -= 200;
  return score;
}

function readContext(input) {
  if (input && typeof input === 'object') {
    const locationObject = input.location || {};
    return {
      href: String(input.href || locationObject.href || ''),
      pathname: String(input.pathname || locationObject.pathname || ''),
      documentObject: input.document || null,
      capabilities: input.capabilities || {}
    };
  }
  return { href: '', pathname: '', documentObject: null, capabilities: {} };
}

function getProfile(input) {
  const context = readContext(input);
  const capabilities = context.capabilities;
  let indexValue = null;
  try { indexValue = new URL(context.href).searchParams.get('index'); } catch (_) {}

  const playlistDom = capabilities.hasPlaylistDom === true || safeQuery(
    context.documentObject,
    '[data-playlist],[data-playlist-item],[class*="playlist" i],[aria-current],[aria-selected="true"]');
  const indexedPlaylist = capabilities.hasNumericPlaylistIndex === true ||
    (/^-?\d+$/.test(String(indexValue ?? '')) && (playlistDom || /playlist|queue|collection/i.test(context.pathname)));
  if (indexedPlaylist) return profiles[0];

  const liveRotation = capabilities.hasLiveRotationControls === true || safeQuery(
    context.documentObject,
    '[data-testid*="next-model" i],[data-testid*="next-room" i],[aria-label*="next model" i],[aria-label*="next room" i]');
  if (liveRotation) return profiles[3];

  const structuredPlaylist = capabilities.hasStructuredPlaylist === true || safeQuery(
    context.documentObject,
    '[role="listbox"] [aria-selected],[data-playlist-item][aria-current],[class*="playlist" i] [aria-selected]');
  if (structuredPlaylist) return profiles[1];

  const playerControls = capabilities.hasSemanticMediaControls === true || safeQuery(
    context.documentObject,
    commonNextSelectors.join(','));
  if (playerControls) return profiles[2];

  return Object.freeze({
    id: 'generic-player',
    capability: 'unclassified-media',
    contentKind: 'unknown',
    nextSelectors: commonNextSelectors,
    previousSelectors: commonPreviousSelectors,
    upNextLabels: ['up next', 'a seguir', 'próximo', 'proximo']
  });
}

globalThis.PipManagerSiteProfiles = Object.freeze({ profiles, getProfile, scoreNavigationDescriptor });
