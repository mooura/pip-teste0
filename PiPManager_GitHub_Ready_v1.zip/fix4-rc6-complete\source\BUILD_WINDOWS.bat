@echo off
setlocal
cd /d "%~dp0"

echo ============================================================
echo PiP Manager 9.39.03 P0 RC6 - build, validacao e pacote candidato
echo ============================================================

where dotnet >nul 2>&1
if errorlevel 1 (
  echo.
  echo ERRO: .NET SDK 8 nao foi encontrado no PATH.
  goto :failed
)

where node >nul 2>&1
if errorlevel 1 (
  echo.
  echo ERRO: Node.js nao foi encontrado no PATH.
  goto :failed
)

echo.
echo [1/4] Preparando nucleo nativo...
call BUILD_NATIVE_WINDOWS.bat
if errorlevel 1 goto :failed

echo.
echo [2/4] Executando todos os testes e checks...
call RUN_CORE_TESTS.bat --ci
if errorlevel 1 goto :failed

echo.
echo [3/4] Publicando aplicativo Windows x64...
dotnet publish src\PiPManager.Wpf\PiPManager.Wpf.csproj -c Release -r win-x64 --self-contained true
if errorlevel 1 goto :failed

echo.
echo [4/4] Criando pacote DIST com checksums...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0CREATE_DIST_RELEASE.ps1"
if errorlevel 1 goto :failed

echo.
echo BUILD P0 RC6 APROVADO.
echo Aplicativo: src\PiPManager.Wpf\bin\Release\net8.0-windows\win-x64\publish\PiPManager.Wpf.exe
echo Pacote: DIST\PiPManager_9.39.03
pause
exit /b 0

:failed
echo.
echo BUILD P0 RC6 REPROVADO. Nenhum pacote deve ser testado ou distribuido.
pause
exit /b 1
