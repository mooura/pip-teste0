﻿@echo off
setlocal
set "PIPMANAGER_REACTOR_CAPTURE_MODE=primary"
set "APP=%~dp0DIST\PiPManager_9.39.03\PiPManager.Wpf.exe"
if not exist "%APP%" (
  echo Executavel nao encontrado: %APP%
  echo Execute BUILD_WINDOWS.bat primeiro.
  pause
  exit /b 1
)
echo Iniciando PiPManager com Reactor como autoridade primaria...
start "" "%APP%"
endlocal
