namespace PiPManager.Wpf.Models;

internal sealed class VideoSwitchPreservationState
{
    public int SlotNumber { get; init; }
    public int? TabId { get; init; }
    public string OldSession { get; init; } = string.Empty;
    public string OldStable { get; init; } = string.Empty;
    public string OldUrl { get; init; } = string.Empty;
    public IntPtr OldHandle { get; init; }
    public string OperationId { get; init; } = string.Empty;
    public string CommandType { get; init; } = string.Empty;
    public string Reason { get; init; } = string.Empty;
    public DateTime StartedUtc { get; init; } = DateTime.UtcNow;
    public DateTime ExpiresUtc { get; init; } = DateTime.UtcNow;
    public bool CommandResultReceived { get; set; }
    public bool CommandConfirmed { get; set; }
    public DateTime CommandConfirmedUtc { get; set; } = DateTime.MinValue;
    public string CommandResultMethod { get; set; } = string.Empty;
    public string CommandResultReason { get; set; } = string.Empty;
    public bool NewVideoDetected { get; set; }
    public bool SameHwndStillAliveSeen { get; set; }
    public bool OldHwndLostSeen { get; set; }
    public bool NewHwndCandidateSeen { get; set; }
    public bool AutoReturnTookOwnership { get; set; }
    public bool PreserveFailedHwndLostLogged { get; set; }
    public bool FallbackOwnedByAutoReturnLogged { get; set; }
    public bool PreservedSameHwndConfirmed { get; set; }
    public bool PreservedFinalLogged { get; set; }
    public bool FailedAfterConfirmedLogged { get; set; }
    public bool SilentReopenAttempted { get; set; }
    public bool SilentReopenConfirmed { get; set; }
    public DateTime SilentReopenAttemptedUtc { get; set; } = DateTime.MinValue;
    public string SilentReopenReasonCode { get; set; } = string.Empty;
    public DateTime PreservedConfirmedUtc { get; set; } = DateTime.MinValue;
    public DateTime AutoReturnOwnershipUtc { get; set; } = DateTime.MinValue;
    public string AutoReturnOwnershipReason { get; set; } = string.Empty;
    public DateTime NewVideoDetectedUtc { get; set; } = DateTime.MinValue;
    public DateTime SameHwndStableSinceUtc { get; set; } = DateTime.MinValue;
    public DateTime LastObservedUtc { get; set; } = DateTime.MinValue;
    public string LastObserverReason { get; set; } = string.Empty;
    public bool FallbackAllowed { get; init; } = true;
}

