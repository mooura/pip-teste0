﻿using PiPManager.Wpf.Models;
using PiPManager.Wpf.Services;

namespace PiPManager.Wpf;

public partial class MainWindow
{
    private void PositionToolbar()
    {
        if (_toolbar is null || !_toolbar.IsLoaded) return;
        var bounds = _layoutService.GetGroupBounds(Slots);
        if (!bounds.IsValid || _allHidden) return;
        _lastKnownGroupBounds = bounds;
        _toolbar.PositionNextTo(bounds, PipWindowService.GetVirtualScreenBounds());
    }

    private void EnsureToolbarOutsidePips()
    {
        if (_toolbar is null || !_toolbar.IsLoaded || _toolbar.IsDragging) return;
        var bounds = _layoutService.GetGroupBounds(Slots);
        if (!bounds.IsValid) return;
        var toolbarBounds = _toolbar.GetBoundsInPixels();
        if (!toolbarBounds.Intersects(bounds)) return;
        _toolbar.PositionNextTo(bounds, PipWindowService.GetVirtualScreenBounds());
    }

    private LayoutMode CurrentLayout => _settings.LayoutMode;

}
