$ErrorActionPreference = 'Stop'

$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path

function Assert-True([bool]$condition, [string]$message) {
    if (-not $condition) { throw "FAIL: $message" }
    Write-Host "$message`: OK"
}

$required = @(
    '.github\workflows\ci.yml',
    'RUN_CI.ps1',
    'docs\consolidation\PHASE_03_04_BLOCK_A.md',
    'docs\consolidation\architecture-map.json',
    'docs\consolidation\test-migration.json'
)
foreach ($relative in $required) {
    Assert-True (Test-Path -LiteralPath (Join-Path $root $relative)) "required Block A file $relative"
}

$ci = Get-Content -LiteralPath (Join-Path $root '.github\workflows\ci.yml') -Raw
$ciRunner = Get-Content -LiteralPath (Join-Path $root 'RUN_CI.ps1') -Raw
$runner = Get-Content -LiteralPath (Join-Path $root 'RUN_CORE_TESTS.bat') -Raw
$architecture = Get-Content -LiteralPath (Join-Path $root 'docs\consolidation\architecture-map.json') -Raw | ConvertFrom-Json
$migration = Get-Content -LiteralPath (Join-Path $root 'docs\consolidation\test-migration.json') -Raw | ConvertFrom-Json
$coreProject = Get-Content -LiteralPath (Join-Path $root 'src\PiPManager.Core\PiPManager.Core.csproj') -Raw

Assert-True ($ci -match 'runs-on:\s*windows-latest') 'CI uses a Windows runner'
Assert-True ($ci -match [regex]::Escape('.\RUN_CI.ps1')) 'CI uses the local canonical entry point'
Assert-True ($ciRunner -match 'RUN_CORE_TESTS\.bat --ci') 'CI entry runs the complete regression gate'
Assert-True ($ciRunner -match 'dotnet build') 'CI entry builds the WPF application'
Assert-True ($runner -match 'CHECK_CONSOLIDATION_BLOCK_A\.ps1') 'Block A checker is wired into the core gate'
Assert-True (@($architecture.layers).Count -ge 7) 'architecture map contains all principal layers'
Assert-True (@($architecture.layers.id) -contains 'core') 'architecture map owns the deterministic core'
Assert-True (@($architecture.layers.id) -contains 'web-extension') 'architecture map owns site adapters'
Assert-True (@($architecture.forbiddenDependencies).Count -ge 5) 'forbidden dependency directions are explicit'
Assert-True (@($migration.migrationPriority).Count -ge 5) 'structural checks have a behavioral migration backlog'
Assert-True ($coreProject -notmatch '<UseWPF>true</UseWPF>') 'Core remains independent from WPF'
Assert-True ($coreProject -notmatch 'ProjectReference') 'Core has no project dependency on infrastructure'

Write-Host 'Consolidation Block A checks OK.' -ForegroundColor Green

