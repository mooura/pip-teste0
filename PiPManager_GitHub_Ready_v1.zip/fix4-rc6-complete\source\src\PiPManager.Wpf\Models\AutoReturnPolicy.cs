namespace PiPManager.Wpf.Models;

internal enum AutoReturnPolicy
{
    Off,
    Silent,
    Discrete
}

