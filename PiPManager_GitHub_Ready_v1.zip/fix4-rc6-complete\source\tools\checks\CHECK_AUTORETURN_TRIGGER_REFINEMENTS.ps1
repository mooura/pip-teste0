$ErrorActionPreference = "Stop"
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$main = Get-Content (Join-Path $root "src\PiPManager.Wpf\MainWindow.xaml.cs") -Raw
$runner = Get-Content (Join-Path $root "RUN_CORE_TESTS.bat") -Raw
$checks = [ordered]@{
  "Short navigation correlation window" = $main.Contains("VideoNavigationLossCorrelationMs = 2200")
  "Observed navigation evidence retained" = $main.Contains("hasObservedNavigationEvidence = preservation.NewVideoDetected")
  "Confirmed navigation survives short correlation window" = $main.Contains("ShouldRequireRealVideoChangeForNavigation") -and $main.Contains("video-navigation-confirmed-operation")
  "Navigation authority is copied into AutoReturn" = $main.Contains("NavigationCommandResultReceived = navigationCommandResultReceived") -and $main.Contains("NavigationCommandConfirmed = navigationCommandConfirmed")
  "Stale navigation ignored" = $main.Contains("auto-return-stale-navigation-context-ignored")
  "Intentional disable uses cancellation" = $main.Contains("ShadowMirrorAutoReturnCancelled(slot")
  "Intentional disable is not reconnect failure" = -not $main.Contains('ShadowMirrorReconnectFailed(slot, "auto-return-disabled"')
  "Cancellation maps to reset event" = $main.Contains("legacy-autoreturn-disabled-cancelled")
  "Checker linked to core tests" = $runner.Contains("CHECK_AUTORETURN_TRIGGER_REFINEMENTS.ps1")
}
$failed = @($checks.GetEnumerator() | Where-Object { -not $_.Value })
$checks.GetEnumerator() | ForEach-Object { "{0}: {1}" -f $_.Key, $(if ($_.Value) {"OK"} else {"FAIL"}) }
if ($failed.Count -gt 0) { throw "AutoReturn trigger refinements checks failed." }
Write-Host "AutoReturn trigger refinements checks OK."
