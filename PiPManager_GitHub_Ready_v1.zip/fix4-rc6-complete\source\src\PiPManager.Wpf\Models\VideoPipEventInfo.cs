﻿namespace PiPManager.Wpf.Models;

public sealed class VideoPipEventInfo
{
    public string EventName { get; init; } = string.Empty;
    public string VideoSessionId { get; init; } = string.Empty;
    public string StableVideoKey { get; init; } = string.Empty;
    public int TabId { get; init; }
    public int FrameId { get; init; }
    public string PageInstanceId { get; init; } = string.Empty;
    public string ElementInstanceId { get; init; } = string.Empty;
    public string Title { get; init; } = string.Empty;
    public string Url { get; init; } = string.Empty;
    public string Domain { get; init; } = string.Empty;
    public double CurrentTime { get; init; }
    public long EventUnixMs { get; init; }

    public bool IsEnter => string.Equals(EventName, "enter", StringComparison.OrdinalIgnoreCase)
        || string.Equals(EventName, "enterpictureinpicture", StringComparison.OrdinalIgnoreCase);

    public string ShortDescription
    {
        get
        {
            var domain = string.IsNullOrWhiteSpace(Domain) ? "site" : Domain;
            var time = CurrentTime <= 0 || double.IsNaN(CurrentTime) || double.IsInfinity(CurrentTime)
                ? "00:00"
                : TimeSpan.FromSeconds(CurrentTime).TotalHours >= 1
                    ? $"{(int)TimeSpan.FromSeconds(CurrentTime).TotalHours}:{TimeSpan.FromSeconds(CurrentTime).Minutes:00}:{TimeSpan.FromSeconds(CurrentTime).Seconds:00}"
                    : $"{TimeSpan.FromSeconds(CurrentTime).Minutes:00}:{TimeSpan.FromSeconds(CurrentTime).Seconds:00}";
            return $"{domain} {time}";
        }
    }
}
