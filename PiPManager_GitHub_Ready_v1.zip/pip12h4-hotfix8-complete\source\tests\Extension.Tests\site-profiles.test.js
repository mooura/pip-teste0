'use strict';

const path = require('path');
require(path.join(__dirname, '..', '..', 'src', 'PiPManager.Extension', 'site-profiles.js'));

const registry = globalThis.PipManagerSiteProfiles;

function assert(condition, message) {
  if (!condition) throw new Error(`TEST FAILED: ${message}`);
}

assert(registry && typeof registry.getProfile === 'function', 'profile registry must be exported');
assert(registry.profiles.length === 4, 'four capability profiles must exist');

const indexed = registry.getProfile({ href: 'https://media.invalid/playlist/demo?index=4', pathname: '/playlist/demo' });
assert(indexed.id === 'indexed-playlist', 'numeric playlist context must select indexed capability');
assert(indexed.nextShortcut.shiftKey === true, 'indexed playlist keyboard fallback must remain scoped');

const controls = registry.getProfile({ capabilities: { hasSemanticMediaControls: true } });
assert(controls.id === 'player-controls', 'semantic controls must select player-controls capability');
assert(!controls.nextShortcut, 'indexed shortcut must not leak into semantic controls');

const live = registry.getProfile({ capabilities: { hasLiveRotationControls: true } });
assert(live.id === 'live-rotation', 'live rotation controls must select live capability');
assert(live.playlistDisabled === true, 'live capability must not expose playlist UI');
assert(live.forceBrowserHistoryPrevious === true, 'live previous strategy must remain explicit');

const structured = registry.getProfile({ capabilities: { hasStructuredPlaylist: true } });
assert(structured.id === 'structured-playlist', 'ordered DOM list must select structured playlist capability');

const generic = registry.getProfile({ href: 'https://example.invalid/video' });
assert(generic.id === 'generic-player', 'unclassified pages must use the generic capability profile');
assert(!generic.nextShortcut, 'generic profile must never guess a keyboard shortcut');
assert(!generic.allowUrlIndexAdvance, 'generic profile must never rewrite playlist indices');

const score = registry.scoreNavigationDescriptor;
assert(typeof score === 'function', 'semantic navigation scorer must be exported');
assert(score('next', { testId: 'rotate-next-model-button' }) >= 70,
  'live next-model control must be recognized without a domain profile');
assert(score('next', { icon: 'chevron-right', ariaLabel: 'next room' }) >= 70,
  'icon-only live next-room control must be recognized');
assert(score('next', { ariaLabel: 'seek forward 10 seconds' }) < 0,
  'seek-forward control must not be mistaken for next item');
assert(score('next', { ariaLabel: 'previous room' }) < 0,
  'opposite navigation control must be rejected');

console.log('Extension capability profile isolation tests: OK');
