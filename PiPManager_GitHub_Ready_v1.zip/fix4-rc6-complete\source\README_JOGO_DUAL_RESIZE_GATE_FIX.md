﻿# Correção do gate do redimensionamento duplo do perfil Jogo

O redimensionamento manual independente do topo e da lateral substituiu o caminho antigo que normalizava um único slot.

O checker `CHECK_JOGO_FIXED_LAYOUT_AUTHORITY.ps1` ainda procurava os marcadores antigos:

- `jogo-fixed-manual-resize-normalized`
- `manual-pip-resize/jogo-profile`

O gate agora valida o fluxo atual:

1. o gesto final parte de `manual-border-resize/final`;
2. o redimensionamento fixo é delegado à autoridade dos dois grupos;
3. a largura é convertida para uma razão relativa à área útil do monitor;
4. somente a autoridade do topo ou da lateral é atualizada;
5. todos os alvos do perfil Jogo são reconstruídos em uma única transação;
6. a autoridade fixa, o modelo travado e as configurações são salvos.

Nenhum código funcional do redimensionamento foi removido ou alterado nesta correção.
