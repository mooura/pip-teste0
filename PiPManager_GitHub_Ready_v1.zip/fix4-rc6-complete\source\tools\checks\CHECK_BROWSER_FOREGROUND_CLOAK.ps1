$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$video = Get-Content (Join-Path $root 'src\PiPManager.Wpf\Services\VideoCommandService.cs') -Raw
$win32 = Get-Content (Join-Path $root 'src\PiPManager.Wpf\Services\Win32.cs') -Raw
$main = Get-Content (Join-Path $root 'src\PiPManager.Wpf\MainWindow.xaml.cs') -Raw
$failed = 0
function Check($name, $ok) { if($ok){ Write-Host "$name`: OK" } else { Write-Host "$name`: FAIL"; $script:failed++ } }
Check 'layered style only' ($win32.Contains('WS_EX_LAYERED') -and -not $video.Contains('WS_EX_TRANSPARENT'))
Check 'full original style restored' ($video.Contains('OriginalExStyle') -and $video.Contains('SetWindowLongPtr(lease.Hwnd, Win32.GWL_EXSTYLE, lease.OriginalExStyle)'))
Check 'layered attributes preserved' ($video.Contains('GetLayeredWindowAttributes') -and $video.Contains('OriginalLayeredFlags'))
Check 'idempotent restore' ($video.Contains('Interlocked.Exchange(ref lease.Restored, 1)'))
Check 'safety timeout' ($video.Contains('BrowserCloakSafetyTimeoutMs') -and $video.Contains('safety-timeout'))
Check 'failure finally restore' ($video.Contains('shortcut-finally-failure'))
Check 'restore after minimize' ($video.Contains('after-minimize'))
Check 'PID validation' ($video.Contains('Win32.GetProcessId(lease.Hwnd) == lease.ProcessId'))
Check 'retry lease reuse' ($video.Contains('browser-foreground-cloak-reused'))
Check 'cloak before extension focus' ($main.Contains('auto-return-browser-prefocus-cloak') -and $main.IndexOf('PrepareBrowserForegroundCloak(preFocusBrowserHwnd)') -lt $main.IndexOf('_extensionBridge.FocusVideoTabAsync(tab.TabId)'))
Check 'strong activation reuses cloak' ($main.Contains('auto-return-browser-activate-cloak') -and $main.Contains('PrepareBrowserForegroundCloak(hWnd)'))
if($failed -gt 0){ throw 'Browser foreground cloak checks failed.' }
Write-Host 'Browser foreground cloak checks OK.'
