﻿using System;

namespace PiPManager.Core.Automation;

/// <summary>
/// Evento de automação. Todo evento agora carrega SlotNumber no contrato base.
/// Isso remove o fallback perigoso para slot 0.
/// </summary>
public abstract record AutomationEvent(
    Guid EventId,
    DateTimeOffset CreatedAt,
    int SlotNumber,
    string AttemptId)
{
    public virtual string Name => GetType().Name;
}

public sealed record UserOpenPipRequested(
    int SlotNumber,
    int? SelectedTabId,
    string AttemptId)
    : AutomationEvent(Guid.NewGuid(), DateTimeOffset.UtcNow, SlotNumber, AttemptId);

public sealed record PipWindowCaptured(
    int SlotNumber,
    IntPtr PipHwnd,
    string AttemptId)
    : AutomationEvent(Guid.NewGuid(), DateTimeOffset.UtcNow, SlotNumber, AttemptId);

public sealed record ExternalPipCaptured(
    int SlotNumber,
    IntPtr PipHwnd,
    string AttemptId)
    : AutomationEvent(Guid.NewGuid(), DateTimeOffset.UtcNow, SlotNumber, AttemptId);


public sealed record VideoChanged(
    int SlotNumber,
    string VideoSessionId,
    string? StableVideoKey,
    string AttemptId)
    : AutomationEvent(Guid.NewGuid(), DateTimeOffset.UtcNow, SlotNumber, AttemptId);

public sealed record PipWindowLost(
    int SlotNumber,
    IntPtr OldHwnd,
    string AttemptId)
    : AutomationEvent(Guid.NewGuid(), DateTimeOffset.UtcNow, SlotNumber, AttemptId);

public sealed record ReconnectRetryQueued(
    int SlotNumber,
    string AttemptId)
    : AutomationEvent(Guid.NewGuid(), DateTimeOffset.UtcNow, SlotNumber, AttemptId);

public sealed record ReconnectStarted(
    int SlotNumber,
    string AttemptId)
    : AutomationEvent(Guid.NewGuid(), DateTimeOffset.UtcNow, SlotNumber, AttemptId);

public sealed record ReconnectSucceeded(
    int SlotNumber,
    IntPtr? PipHwnd,
    string AttemptId)
    : AutomationEvent(Guid.NewGuid(), DateTimeOffset.UtcNow, SlotNumber, AttemptId);

public sealed record ReconnectFailed(
    int SlotNumber,
    string Reason,
    string AttemptId)
    : AutomationEvent(Guid.NewGuid(), DateTimeOffset.UtcNow, SlotNumber, AttemptId);

public sealed record SlotResetRequested(
    int SlotNumber,
    string AttemptId)
    : AutomationEvent(Guid.NewGuid(), DateTimeOffset.UtcNow, SlotNumber, AttemptId);


public sealed record PreservedSameHwndConfirmed(
    int SlotNumber,
    IntPtr PipHwnd,
    string AttemptId)
    : AutomationEvent(Guid.NewGuid(), DateTimeOffset.UtcNow, SlotNumber, AttemptId);
