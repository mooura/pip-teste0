﻿# PiP Manager Bridge - Open PiP Pairing

Esta extensão conversa com o app local em:

ws://127.0.0.1:45151/ws

## Comandos recebidos

- `videoCommand`: executa próximo/anterior no player alvo.
- `openPictureInPicture`: tenta abrir PiP no player alvo usando `requestPictureInPicture()`.

## Fluxo recomendado

1. App escolhe uma sessão de vídeo.
2. App envia `openPictureInPicture`.
3. Extensão tenta abrir PiP naquele `<video>`.
4. App captura a nova janela do Windows.
5. App vincula o novo PiP ao `stableVideoKey` / `videoSessionId` escolhido.

