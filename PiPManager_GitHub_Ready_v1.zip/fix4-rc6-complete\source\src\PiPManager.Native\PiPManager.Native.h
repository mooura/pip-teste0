#pragma once

#include <stdint.h>

#ifdef _WIN32
#define PIP_API extern "C" __declspec(dllexport)
#define PIP_CALL __cdecl
#else
#define PIP_API extern "C"
#define PIP_CALL
#endif

struct PipNativeMove
{
    int64_t hwnd;
    int32_t left;
    int32_t top;
    int32_t right;
    int32_t bottom;
};

struct PipNativePreparedMove
{
    int64_t hwnd;
    int32_t rawLeft;
    int32_t rawTop;
    int32_t rawWidth;
    int32_t rawHeight;
    int32_t status;
};

struct PipNativeBatchResult
{
    int32_t attempted;
    int32_t prepared;
    int32_t applied;
    int32_t skipped;
    int32_t failed;
    int32_t fallbackUsed;
    int32_t nativeVersion;
};

enum PipNativeCoordinateMode : int32_t
{
    PipNativeVisualCoordinates = 0,
    PipNativeRawCoordinates = 1
};

PIP_API int32_t PIP_CALL pip_native_version();

PIP_API int32_t PIP_CALL pip_process_window_batch(
    const PipNativeMove* moves,
    int32_t count,
    int32_t pixelThreshold,
    int32_t resizeToTarget,
    int32_t coordinateMode,
    int32_t dryRun,
    PipNativePreparedMove* preparedMoves,
    int32_t preparedCapacity,
    PipNativeBatchResult* result);
