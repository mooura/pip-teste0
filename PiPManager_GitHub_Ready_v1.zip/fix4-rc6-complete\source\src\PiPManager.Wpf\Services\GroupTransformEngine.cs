using PiPManager.Wpf.Models;

namespace PiPManager.Wpf.Services;

public sealed class GroupTransformEngine
{
    /// <summary>
    /// Une componentes desconectados sem alterar a topologia interna de cada um.
    /// O menor deslocamento possível é escolhido até todos os retângulos formarem
    /// um único mosaico conectado por bordas, sem lacunas e sem sobreposição.
    /// </summary>
    public IReadOnlyList<NativeRect> EnsureSingleConnectedMosaic(
        IReadOnlyList<NativeRect> source,
        NativeRect workArea,
        int margin = 8)
    {
        var result = source.ToArray();
        if (result.Length < 2 || result.Any(rect => !rect.IsValid))
            return result;

        var connected = new HashSet<int> { 0 };
        ExpandConnected(result, connected);
        while (connected.Count < result.Length)
        {
            var seed = Enumerable.Range(0, result.Length).First(index => !connected.Contains(index));
            var component = new HashSet<int> { seed };
            ExpandConnected(result, component, connected);

            (int Dx, int Dy, long Cost)? best = null;
            foreach (var movingIndex in component)
            foreach (var fixedIndex in connected)
            foreach (var candidate in BuildAttachmentCandidates(result[movingIndex], result[fixedIndex]))
            {
                var shifted = component.ToDictionary(index => index, index => result[index].Offset(candidate.Dx, candidate.Dy));
                if (shifted.Any(item => Enumerable.Range(0, result.Length)
                        .Any(other => !component.Contains(other) && Overlaps(item.Value, result[other]))))
                    continue;
                if (!shifted.Any(item => connected.Any(fixedSlot => TouchesByEdge(item.Value, result[fixedSlot]))))
                    continue;

                var cost = ((long)candidate.Dx * candidate.Dx) + ((long)candidate.Dy * candidate.Dy);
                if (best is null || cost < best.Value.Cost)
                    best = (candidate.Dx, candidate.Dy, cost);
            }

            if (best is null)
                break;

            foreach (var index in component)
                result[index] = result[index].Offset(best.Value.Dx, best.Value.Dy);
            connected.UnionWith(component);
            ExpandConnected(result, connected);
        }

        if (!workArea.IsValid)
            return result;

        var bounds = BoundsOf(result);
        var dx = bounds.Left < workArea.Left + margin
            ? workArea.Left + margin - bounds.Left
            : bounds.Right > workArea.Right - margin ? workArea.Right - margin - bounds.Right : 0;
        var dy = bounds.Top < workArea.Top + margin
            ? workArea.Top + margin - bounds.Top
            : bounds.Bottom > workArea.Bottom - margin ? workArea.Bottom - margin - bounds.Bottom : 0;
        return dx == 0 && dy == 0 ? result : result.Select(rect => rect.Offset(dx, dy)).ToArray();
    }

    private static void ExpandConnected(
        IReadOnlyList<NativeRect> rects,
        HashSet<int> component,
        IReadOnlySet<int>? excluded = null)
    {
        var changed = true;
        while (changed)
        {
            changed = false;
            foreach (var candidate in Enumerable.Range(0, rects.Count))
            {
                if (component.Contains(candidate) || excluded?.Contains(candidate) == true)
                    continue;
                if (!component.Any(existing => TouchesByEdge(rects[existing], rects[candidate])))
                    continue;
                component.Add(candidate);
                changed = true;
            }
        }
    }

    private static IEnumerable<(int Dx, int Dy)> BuildAttachmentCandidates(NativeRect moving, NativeRect fixedRect)
    {
        var verticalCorrection = moving.Bottom <= fixedRect.Top
            ? fixedRect.Top - moving.Bottom + 1
            : moving.Top >= fixedRect.Bottom ? fixedRect.Bottom - moving.Top - 1 : 0;
        var horizontalCorrection = moving.Right <= fixedRect.Left
            ? fixedRect.Left - moving.Right + 1
            : moving.Left >= fixedRect.Right ? fixedRect.Right - moving.Left - 1 : 0;

        yield return (fixedRect.Right - moving.Left, verticalCorrection);
        yield return (fixedRect.Left - moving.Right, verticalCorrection);
        yield return (horizontalCorrection, fixedRect.Bottom - moving.Top);
        yield return (horizontalCorrection, fixedRect.Top - moving.Bottom);
    }

    public RelativeGroupLayout Capture(
        IReadOnlyDictionary<int, NativeRect> rectsBySlot,
        string monitorDeviceName,
        double dpiScale = 1.0)
    {
        var valid = rectsBySlot
            .Where(item => item.Key > 0 && item.Value.IsValid)
            .OrderBy(item => item.Key)
            .ToArray();
        if (valid.Length == 0)
            return new RelativeGroupLayout { MonitorDeviceName = monitorDeviceName, DpiScale = NormalizeDpi(dpiScale) };

        var anchorX = valid.Min(item => item.Value.Left);
        var anchorY = valid.Min(item => item.Value.Top);
        return new RelativeGroupLayout
        {
            AnchorX = anchorX,
            AnchorY = anchorY,
            MonitorDeviceName = monitorDeviceName ?? string.Empty,
            DpiScale = NormalizeDpi(dpiScale),
            Slots = valid.Select(item => new RelativeSlotLayoutItem
            {
                SlotNumber = item.Key,
                OffsetX = item.Value.Left - anchorX,
                OffsetY = item.Value.Top - anchorY,
                Width = item.Value.Width,
                Height = item.Value.Height
            }).ToList()
        };
    }

    public IReadOnlyDictionary<int, NativeRect> Materialize(
        RelativeGroupLayout? template,
        NativeRect workArea,
        int margin = 8)
    {
        if (template is null || template.Slots.Count == 0)
            return new Dictionary<int, NativeRect>();

        var slots = template.Slots
            .Where(item => item.SlotNumber > 0 && item.Width > 0 && item.Height > 0)
            .OrderBy(item => item.SlotNumber)
            .ToArray();
        if (slots.Length == 0)
            return new Dictionary<int, NativeRect>();

        var anchorX = template.AnchorX;
        var anchorY = template.AnchorY;
        var right = slots.Max(item => item.OffsetX + item.Width);
        var bottom = slots.Max(item => item.OffsetY + item.Height);
        var scale = 1.0;

        if (workArea.IsValid)
        {
            var minX = workArea.Left + margin;
            var minY = workArea.Top + margin;
            var availableWidth = Math.Max(1, workArea.Width - (margin * 2));
            var availableHeight = Math.Max(1, workArea.Height - (margin * 2));

            // Um molde salvo pode ter sido criado com outra resolução/DPI. Só
            // limitar a âncora não basta quando o grupo inteiro é maior que a
            // área útil: o navegador limita a janela, enquanto o timer do layout
            // tenta devolvê-la, produzindo a piscada observada. Escalar todas as
            // arestas pela mesma razão preserva o desenho e as emendas exatas.
            scale = Math.Min(1.0, Math.Min(
                availableWidth / (double)Math.Max(1, right),
                availableHeight / (double)Math.Max(1, bottom)));
            var fittedRight = Math.Max(1, (int)Math.Round(right * scale));
            var fittedBottom = Math.Max(1, (int)Math.Round(bottom * scale));
            var maxX = Math.Max(minX, workArea.Right - margin - fittedRight);
            var maxY = Math.Max(minY, workArea.Bottom - margin - fittedBottom);
            anchorX = Math.Clamp(anchorX, minX, maxX);
            anchorY = Math.Clamp(anchorY, minY, maxY);
        }

        return slots.ToDictionary(
            item => item.SlotNumber,
            item =>
            {
                var left = anchorX + (int)Math.Round(item.OffsetX * scale);
                var top = anchorY + (int)Math.Round(item.OffsetY * scale);
                var rightEdge = anchorX + (int)Math.Round((item.OffsetX + item.Width) * scale);
                var bottomEdge = anchorY + (int)Math.Round((item.OffsetY + item.Height) * scale);
                return new NativeRect(
                    left,
                    top,
                    Math.Max(left + 1, rightEdge),
                    Math.Max(top + 1, bottomEdge));
            });
    }

    public RelativeGroupLayout Translate(RelativeGroupLayout template, int dx, int dy) => new()
    {
        Version = template.Version,
        AnchorX = template.AnchorX + dx,
        AnchorY = template.AnchorY + dy,
        MonitorDeviceName = template.MonitorDeviceName,
        DpiScale = template.DpiScale,
        Slots = template.Slots.Select(item => new RelativeSlotLayoutItem
        {
            SlotNumber = item.SlotNumber,
            OffsetX = item.OffsetX,
            OffsetY = item.OffsetY,
            Width = item.Width,
            Height = item.Height
        }).ToList()
    };

    /// <summary>
    /// Preserva a topologia relativa e afasta somente os retângulos que passaram a
    /// se sobrepor após uma mudança externa de proporção/tamanho do PiP. O eixo do
    /// afastamento é escolhido pela posição relativa original (linha ou coluna),
    /// mantendo as bordas exatamente encostadas e aplicando uma única translação ao
    /// grupo quando ele precisa voltar para a área útil do monitor.
    /// </summary>
    public IReadOnlyDictionary<int, NativeRect> ReflowWithoutOverlap(
        IReadOnlyDictionary<int, NativeRect> rectsBySlot,
        NativeRect workArea,
        int margin = 8)
    {
        var ordered = rectsBySlot
            .Where(item => item.Key > 0 && item.Value.IsValid)
            .OrderBy(item => item.Key)
            .ToArray();
        if (ordered.Length == 0)
            return new Dictionary<int, NativeRect>();

        var placed = new Dictionary<int, NativeRect>();
        foreach (var item in ordered)
        {
            var current = item.Value;
            // Um retângulo pode tocar mais de um anterior. Repetir a passagem deixa
            // o resultado determinístico inclusive em colunas com alturas mistas.
            for (var pass = 0; pass < ordered.Length; pass++)
            {
                var moved = false;
                foreach (var previous in placed.Values)
                {
                    if (!Overlaps(current, previous))
                        continue;

                    var centerDx = current.CenterX - previous.CenterX;
                    var centerDy = current.CenterY - previous.CenterY;
                    if (Math.Abs(centerDx) > Math.Abs(centerDy))
                    {
                        var dx = centerDx >= 0
                            ? previous.Right - current.Left
                            : previous.Left - current.Right;
                        current = current.Offset(dx, 0);
                    }
                    else
                    {
                        var dy = centerDy >= 0
                            ? previous.Bottom - current.Top
                            : previous.Top - current.Bottom;
                        current = current.Offset(0, dy);
                    }
                    moved = true;
                }

                if (!moved)
                    break;
            }

            placed[item.Key] = current;
        }

        if (!workArea.IsValid)
            return placed;

        var bounds = BoundsOf(placed.Values);
        var minLeft = workArea.Left + margin;
        var minTop = workArea.Top + margin;
        var maxRight = workArea.Right - margin;
        var maxBottom = workArea.Bottom - margin;
        var translateX = bounds.Left < minLeft
            ? minLeft - bounds.Left
            : bounds.Right > maxRight ? maxRight - bounds.Right : 0;
        var translateY = bounds.Top < minTop
            ? minTop - bounds.Top
            : bounds.Bottom > maxBottom ? maxBottom - bounds.Bottom : 0;

        return translateX == 0 && translateY == 0
            ? placed
            : placed.ToDictionary(item => item.Key, item => item.Value.Offset(translateX, translateY));
    }

    /// <summary>
    /// Mantém os retângulos alterados ancorados e propaga somente as colisões
    /// causadas por eles. Assim, uma mudança de proporção não redesenha o molde
    /// inteiro nem desloca slots que continuam válidos.
    /// </summary>
    public IReadOnlyDictionary<int, NativeRect> ReflowFromChangedSlots(
        IReadOnlyDictionary<int, NativeRect> rectsBySlot,
        IEnumerable<int> changedSlots,
        NativeRect workArea,
        int margin = 8)
    {
        var result = rectsBySlot
            .Where(item => item.Key > 0 && item.Value.IsValid)
            .ToDictionary(item => item.Key, item => item.Value);
        var changed = changedSlots.Where(result.ContainsKey).Distinct().ToHashSet();
        if (result.Count == 0 || changed.Count == 0)
            return result;

        var queue = new Queue<int>(changed.Order());
        var maximumMoves = Math.Max(1, result.Count * result.Count * 2);
        var moves = 0;
        while (queue.Count > 0 && moves < maximumMoves)
        {
            var anchorNumber = queue.Dequeue();
            var anchor = result[anchorNumber];
            foreach (var otherNumber in result.Keys.Order().ToArray())
            {
                // Se dois slots mudaram ao mesmo tempo, o de menor número fica como
                // primeira âncora e o posterior pode ser transladado. Isso mantém o
                // resultado sem sobreposição sem alterar o tamanho natural de nenhum.
                if (otherNumber == anchorNumber || (changed.Contains(otherNumber) && otherNumber < anchorNumber))
                    continue;

                var other = result[otherNumber];
                if (!Overlaps(anchor, other))
                    continue;

                var originalAnchor = rectsBySlot[anchorNumber];
                var originalOther = rectsBySlot[otherNumber];
                var centerDx = originalOther.CenterX - originalAnchor.CenterX;
                var centerDy = originalOther.CenterY - originalAnchor.CenterY;
                if (Math.Abs(centerDx) >= Math.Abs(centerDy))
                {
                    var dx = centerDx >= 0
                        ? anchor.Right - other.Left
                        : anchor.Left - other.Right;
                    other = other.Offset(dx, 0);
                }
                else
                {
                    var dy = centerDy >= 0
                        ? anchor.Bottom - other.Top
                        : anchor.Top - other.Bottom;
                    other = other.Offset(0, dy);
                }

                result[otherNumber] = other;
                queue.Enqueue(otherNumber);
                moves++;
            }
        }

        if (!workArea.IsValid)
            return result;

        var bounds = BoundsOf(result.Values);
        var dxGroup = bounds.Left < workArea.Left + margin
            ? workArea.Left + margin - bounds.Left
            : bounds.Right > workArea.Right - margin ? workArea.Right - margin - bounds.Right : 0;
        var dyGroup = bounds.Top < workArea.Top + margin
            ? workArea.Top + margin - bounds.Top
            : bounds.Bottom > workArea.Bottom - margin ? workArea.Bottom - margin - bounds.Bottom : 0;
        return dxGroup == 0 && dyGroup == 0
            ? result
            : result.ToDictionary(item => item.Key, item => item.Value.Offset(dxGroup, dyGroup));
    }

    /// <summary>
    /// Recompõe um mosaico depois que o navegador alterou naturalmente o tamanho de
    /// um ou mais PiPs. Nenhuma largura ou altura é calculada pelo Manager: primeiro
    /// propagamos apenas as colisões e depois aproximamos os componentes que ficaram
    /// separados pela redução de um PiP. O resultado conserva exatamente as dimensões
    /// recebidas do navegador e modifica somente Left/Top.
    /// </summary>
    public IReadOnlyDictionary<int, NativeRect> ReflowNaturalSizesAsConnectedMosaic(
        IReadOnlyDictionary<int, NativeRect> naturalRectsBySlot,
        IEnumerable<int> changedSlots,
        NativeRect workArea,
        int margin = 8)
    {
        var orderedSlots = naturalRectsBySlot
            .Where(item => item.Key > 0 && item.Value.IsValid)
            .OrderBy(item => item.Key)
            .Select(item => item.Key)
            .ToArray();
        if (orderedSlots.Length == 0)
            return new Dictionary<int, NativeRect>();

        var collisionFree = ReflowFromChangedSlots(
            naturalRectsBySlot,
            changedSlots,
            workArea: default,
            margin);
        var naturalSizes = orderedSlots.ToDictionary(
            slotNumber => slotNumber,
            slotNumber => (Width: naturalRectsBySlot[slotNumber].Width, Height: naturalRectsBySlot[slotNumber].Height));
        var connected = EnsureSingleConnectedMosaic(
            orderedSlots.Select(slotNumber => collisionFree[slotNumber]).ToArray(),
            workArea,
            margin);

        var result = new Dictionary<int, NativeRect>(orderedSlots.Length);
        for (var index = 0; index < orderedSlots.Length; index++)
        {
            var slotNumber = orderedSlots[index];
            var rect = connected[index];
            var size = naturalSizes[slotNumber];
            result[slotNumber] = new NativeRect(
                rect.Left,
                rect.Top,
                rect.Left + size.Width,
                rect.Top + size.Height);
        }
        return result;
    }

    public bool IsComplete(RelativeGroupLayout? template, int slotCount) =>
        template is not null
        && slotCount > 0
        && template.Slots.Count == slotCount
        && template.Slots.Select(item => item.SlotNumber).Distinct().Count() == slotCount
        && template.Slots.All(item => item.SlotNumber >= 1 && item.SlotNumber <= slotCount && item.Width > 0 && item.Height > 0);

    private static double NormalizeDpi(double value) =>
        double.IsFinite(value) && value > 0.25 && value < 8 ? value : 1.0;

    private static bool Overlaps(NativeRect left, NativeRect right) =>
        left.Left < right.Right
        && left.Right > right.Left
        && left.Top < right.Bottom
        && left.Bottom > right.Top;

    private static bool TouchesByEdge(NativeRect left, NativeRect right)
    {
        var verticalOverlap = Math.Min(left.Bottom, right.Bottom) - Math.Max(left.Top, right.Top);
        var horizontalOverlap = Math.Min(left.Right, right.Right) - Math.Max(left.Left, right.Left);
        return (verticalOverlap > 0 && (left.Right == right.Left || right.Right == left.Left))
            || (horizontalOverlap > 0 && (left.Bottom == right.Top || right.Bottom == left.Top));
    }

    private static NativeRect BoundsOf(IEnumerable<NativeRect> rects)
    {
        var items = rects.Where(rect => rect.IsValid).ToArray();
        return items.Length == 0
            ? default
            : new NativeRect(
                items.Min(rect => rect.Left),
                items.Min(rect => rect.Top),
                items.Max(rect => rect.Right),
                items.Max(rect => rect.Bottom));
    }
}
