$ErrorActionPreference = "Stop"
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$main = Get-Content (Join-Path $root "src\PiPManager.Wpf\MainWindow.xaml.cs") -Raw
$servicePath = Join-Path $root "src\PiPManager.Wpf\Services\ShadowParityReportService.cs"

if (!(Test-Path $servicePath)) {
  throw "ShadowParityReportService.cs not found"
}

$service = Get-Content $servicePath -Raw

$checks = @(
  @{ Name = "Parity service field"; Text = "_shadowParityReport" },
  @{ Name = "Parity record call"; Text = "ShadowRecordParity" },
  @{ Name = "Report save helper"; Text = "ShadowSaveParityReport" },
  @{ Name = "Report saved log"; Text = "shadow-parity-report-saved" },
  @{ Name = "Parity recorded log"; Text = "shadow-parity-recorded" },
  @{ Name = "Closing save call"; Text = "ShadowSaveParityReport(""MainWindow.OnClosing"")" },
  @{ Name = "Writable report directory"; Text = "Environment.SpecialFolder.LocalApplicationData" },
  @{ Name = "Report directory helper"; Text = "GetShadowParityReportDirectory" }
)

foreach ($check in $checks) {
  if (!$main.Contains($check.Text)) {
    throw "Missing MainWindow parity check: $($check.Name)"
  }
}

foreach ($required in @("BuildTextReport", "SaveTextReport", "PotentialDivergences", "FinalStateBySlot", "finalExpectedFailure", "INCONCLUSIVE", "autoreturn-disabled", "RawRecords", "ByEvent", "BySource", "IsPotentialDivergenceForTest", "ensure-started-before")) {
  if (!$service.Contains($required)) {
    throw "Missing parity service feature: $required"
  }
}

Write-Host "Shadow parity report checks OK."
