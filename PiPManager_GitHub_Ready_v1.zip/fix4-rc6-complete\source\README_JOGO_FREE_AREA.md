# Perfil Jogo livre — área ajustável

O perfil **Jogo** mantém o modo automático original por padrão.

No menu **Layout > Jogo livre** é possível ativar uma escala uniforme entre 55% e 100%:

- **Mais área livre** reduz todos os PiPs em 5%;
- **Menos área livre** aumenta todos os PiPs em 5%;
- **Tamanho máximo** usa 100%;
- **Voltar ao automático** restaura exatamente o comportamento anterior.

A transformação é feita em torno do canto superior direito. A topologia em L, as costuras, a proporção intrínseca, a ordem manual e a autoridade do layout fixo são preservadas. A preferência é salva nas configurações.
